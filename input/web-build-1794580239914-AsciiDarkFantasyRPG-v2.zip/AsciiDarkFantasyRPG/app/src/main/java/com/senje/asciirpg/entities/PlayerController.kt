package com.senje.asciirpg.entities

import com.senje.asciirpg.data.SaveManager
import com.senje.asciirpg.world.WorldGenerator
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Handles Knight & White Steed locomotion, dodge dash, sword slash arcs,
 * and a 6-node Verlet physics chain for flowing ASCII horse mane/tail & knight cape.
 */
class PlayerController(initial: SaveManager.PlayerSaveData) {

    var name: String = initial.name
    var level: Int = initial.level
    var xp: Int = initial.xp
    var maxXp: Int = initial.maxXp
    var hp: Int = initial.hp
    var maxHp: Int = initial.maxHp
    var mp: Int = initial.mp
    var maxMp: Int = initial.maxMp
    var gold: Int = initial.gold
    var equippedHelmMetal: String = initial.equippedHelmMetal

    var posX: Float = initial.posX
    var posY: Float = 0f
    var posZ: Float = initial.posZ
    var facingAngle: Float = 0f
    var isMounted: Boolean = initial.isMounted

    var moveInputX: Float = 0f
    var moveInputZ: Float = 0f

    var animTime: Float = 0f
    var attackTimer: Float = 0f
    var dodgeTimer: Float = 0f
    var currentSpeed: Float = 0f

    // 6-node Verlet chain for steed tail & knight cloak hair physics
    val tailNodesX = FloatArray(6) { posX }
    val tailNodesY = FloatArray(6) { 0.8f }
    val tailNodesZ = FloatArray(6) { posZ - it * 0.16f }

    fun triggerAttack() {
        if (attackTimer <= 0f) {
            attackTimer = 0.38f
            mp = (mp - 6).coerceAtLeast(0)
        }
    }

    fun triggerDodge() {
        if (dodgeTimer <= 0f) {
            dodgeTimer = 0.32f
        }
    }

    fun toggleSteed() {
        isMounted = !isMounted
    }

    fun update(dt: Float, world: WorldGenerator) {
        animTime += dt
        if (attackTimer > 0f) attackTimer = (attackTimer - dt).coerceAtLeast(0f)
        if (dodgeTimer > 0f) dodgeTimer = (dodgeTimer - dt).coerceAtLeast(0f)

        // Passive MP regeneration
        if (mp < maxMp && (animTime * 10f).toInt() % 8 == 0) {
            mp = (mp + 1).coerceAtMost(maxMp)
        }

        val inputLen = sqrt(moveInputX * moveInputX + moveInputZ * moveInputZ)
        val baseSpeed = if (isMounted) 5.6f else 3.5f
        val dashBoost = if (dodgeTimer > 0f) 2.2f else 1.0f

        if (inputLen > 0.05f || dodgeTimer > 0f) {
            val dirX: Float
            val dirZ: Float
            if (inputLen > 0.05f) {
                dirX = moveInputX / inputLen
                dirZ = moveInputZ / inputLen
                facingAngle = atan2(dirX, dirZ)
            } else {
                dirX = sin(facingAngle)
                dirZ = cos(facingAngle)
            }

            currentSpeed = baseSpeed * dashBoost * (if (inputLen > 0.05f) inputLen.coerceAtMost(1f) else 1f)
            val nextX = (posX + dirX * currentSpeed * dt).coerceIn(-20f, 20f)
            val nextZ = (posZ + dirZ * currentSpeed * dt).coerceIn(-20f, 20f)
            posX = nextX
            posZ = nextZ
        } else {
            currentSpeed = 0f
        }

        posY = world.getTerrainHeight(posX, posZ)

        // Update Verlet hair/tail physics nodes trailing behind the mount/knight
        val backX = -sin(facingAngle)
        val backZ = -cos(facingAngle)
        val anchorHeight = if (isMounted) 0.92f else 0.78f
        val anchorOffset = if (isMounted) 0.52f else 0.22f

        tailNodesX[0] = posX + backX * anchorOffset
        tailNodesY[0] = posY + anchorHeight
        tailNodesZ[0] = posZ + backZ * anchorOffset

        val segLen = 0.16f
        val windWave = sin(animTime * 5.2f) * 0.04f
        for (i in 1 until 6) {
            // Pull gently toward trailing direction + gravity + wind flutter
            val targetX = tailNodesX[i - 1] + backX * segLen + cos(facingAngle) * windWave * i
            val targetY = (tailNodesY[i - 1] - 0.07f + sin(animTime * 9f + i) * 0.015f)
                .coerceAtLeast(posY + 0.12f)
            val targetZ = tailNodesZ[i - 1] + backZ * segLen - sin(facingAngle) * windWave * i

            val stiffness = (14f * dt).coerceIn(0.15f, 0.75f)
            tailNodesX[i] += (targetX - tailNodesX[i]) * stiffness
            tailNodesY[i] += (targetY - tailNodesY[i]) * stiffness
            tailNodesZ[i] += (targetZ - tailNodesZ[i]) * stiffness
        }
    }
}
