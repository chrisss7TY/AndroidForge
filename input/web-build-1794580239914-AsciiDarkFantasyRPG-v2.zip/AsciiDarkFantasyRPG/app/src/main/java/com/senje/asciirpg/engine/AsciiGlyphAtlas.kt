package com.senje.asciirpg.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.opengl.GLES30
import android.opengl.GLUtils

/**
 * Generates a 16x16 monospace glyph texture atlas on GPU startup so zero external font assets
 * can ever go missing. Row 0 holds luminance-sorted fill glyphs (dark -> bright), and Row 1
 * holds directional Sobel edge glyphs (|, -, /, \) plus HUD icons.
 */
object AsciiGlyphAtlas {

    // 16 luminance levels from deep shadow to specular highlight
    const val LUMINANCE_RAMP = " .,:;~-=+*o08QM@"
    // 4 directional edge glyphs for Sobel contours
    const val EDGE_GLYPHS = "|-/\\"

    fun createAtlasTexture(): Int {
        val cols = 16
        val rows = 16
        val cellSize = 32
        val bmp = Bitmap.createBitmap(cols * cellSize, rows * cellSize, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.BLACK)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 25f
            typeface = Typeface.MONOSPACE
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val fontMetrics = paint.fontMetrics
        val baselineOffset = -(fontMetrics.ascent + fontMetrics.descent) * 0.5f

        // Row 0: Luminance ramp (indices 0..15)
        for (i in LUMINANCE_RAMP.indices) {
            val cx = i * cellSize + cellSize * 0.5f
            val cy = cellSize * 0.5f + baselineOffset
            canvas.drawText(LUMINANCE_RAMP[i].toString(), cx, cy, paint)
        }

        // Row 1: Sobel Edge glyphs (indices 0..3)
        for (i in EDGE_GLYPHS.indices) {
            val cx = i * cellSize + cellSize * 0.5f
            val cy = cellSize * 1.5f + baselineOffset
            canvas.drawText(EDGE_GLYPHS[i].toString(), cx, cy, paint)
        }

        // Rows 2..7: Standard printable ASCII (32..126) for crisp HUD text rendering
        for (ascii in 32..126) {
            val idx = ascii - 32
            val col = idx % 16
            val row = 2 + (idx / 16)
            val cx = col * cellSize + cellSize * 0.5f
            val cy = row * cellSize + cellSize * 0.5f + baselineOffset
            canvas.drawText(ascii.toChar().toString(), cx, cy, paint)
        }

        val texIds = IntArray(1)
        GLES30.glGenTextures(1, texIds, 0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, texIds[0])
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0)
        bmp.recycle()

        return texIds[0]
    }
}
