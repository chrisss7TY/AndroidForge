package com.ashveil.abyss;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

/**
 * Dense, curved, living grass + drifting pollen sparkles (the look of the reference video).
 *
 * Every blade is a 2-segment curve (base -> bent middle -> tip) so it reads as a bowed blade, not a stick.
 * Blades sway in a travelling wind field and are shoved aside / flattened by "pushers" (the horse, the hero,
 * enemies), so the grass visibly parts around whatever walks through it and trails behind fast movers.
 * Everything is a pure function of world position + time, so it never flickers when the camera scrolls.
 */
final class GrassFx {
    static final int MAX_PUSHERS = 12;
    private static final int MAX_BLADES = 10000;
    private static final int TONES = 3;

    // pushers: world pos, velocity, radius (world units)
    private final float[] pushX = new float[MAX_PUSHERS];
    private final float[] pushY = new float[MAX_PUSHERS];
    private final float[] pushVx = new float[MAX_PUSHERS];
    private final float[] pushVy = new float[MAX_PUSHERS];
    private final float[] pushR = new float[MAX_PUSHERS];
    private int pushCount = 0;

    // 2 segments (8 floats) per blade, bucketed by tone so each tone is a single drawLines call
    private final float[][] seg = new float[TONES][MAX_BLADES * 8 / TONES + 64];
    private final int[] segN = new int[TONES];
    private final float[] tip = new float[MAX_BLADES * 4 / 2];
    private int tipN = 0;

    private final Paint[] tonePaint = new Paint[TONES];
    private final Paint tipPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint starPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float[] dots = new float[900 * 2];
    private final float[] stars = new float[300 * 8];
    private final float[] sample = new float[3];

    GrassFx() {
        int[] cols = {Color.rgb(16, 38, 27), Color.rgb(30, 70, 48), Color.rgb(52, 104, 70)};
        for (int i = 0; i < TONES; i++) {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(cols[i]);
            tonePaint[i] = p;
        }
        tipPaint.setStyle(Paint.Style.STROKE);
        tipPaint.setStrokeCap(Paint.Cap.ROUND);
        tipPaint.setColor(Color.argb(150, 150, 190, 160));
        dotPaint.setStyle(Paint.Style.STROKE);
        dotPaint.setStrokeCap(Paint.Cap.ROUND);
        dotPaint.setColor(Color.rgb(236, 244, 240));
        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setColor(Color.rgb(226, 238, 234));
        starPaint.setStyle(Paint.Style.STROKE);
        starPaint.setStrokeCap(Paint.Cap.ROUND);
        starPaint.setColor(Color.rgb(240, 246, 244));
    }

    void clearPushers() {
        pushCount = 0;
    }

    void addPusher(float x, float y, float vx, float vy, float radius) {
        if (pushCount >= MAX_PUSHERS) return;
        pushX[pushCount] = x;
        pushY[pushCount] = y;
        pushVx[pushCount] = vx;
        pushVy[pushCount] = vy;
        pushR[pushCount] = radius;
        pushCount++;
    }

    private static int hash(int x, int y) {
        int h = x * 374761393 + y * 668265263;
        h = (h ^ (h >>> 13)) * 1274126177;
        return h ^ (h >>> 16);
    }

    /**
     * Grass over the whole screen (call before the entities are drawn).
     */
    void drawField(Canvas canvas, WorldGen gen, float camX, float camY, float cx, float cy, float ppu,
                   float halfW, float halfH, float time, float windScale) {
        generate(gen, camX - halfW, camX + halfW, camY - halfH, camY + halfH,
                camX, camY, cx, cy, ppu, time, windScale, 1.0f, true);
        flush(canvas, ppu);
    }

    /**
     * A thin strip of short grass in front of the hero's hooves so the legs sink into the meadow.
     */
    void drawForeground(Canvas canvas, WorldGen gen, float heroX, float heroY, float camX, float camY,
                        float cx, float cy, float ppu, float time, float windScale) {
        generate(gen, heroX - 2.0f, heroX + 2.0f, heroY + 0.42f, heroY + 1.05f,
                camX, camY, cx, cy, ppu, time, windScale, 0.78f, false);
        flush(canvas, ppu);
    }

    private void generate(WorldGen gen, float minX, float maxX, float minY, float maxY,
                          float camX, float camY, float cx, float cy, float ppu,
                          float t, float windScale, float lenMul, boolean tips) {
        segN[0] = segN[1] = segN[2] = 0;
        tipN = 0;

        float area = (maxX - minX) * (maxY - minY);
        float cell = Math.max(0.15f, (float) Math.sqrt(area / (MAX_BLADES * 0.82f)));
        final float coarse = cell * 3.0f;

        float baseLen = Math.max(11.0f, ppu * 0.36f) * lenMul;

        int cx0 = (int) Math.floor(minX / coarse);
        int cx1 = (int) Math.floor(maxX / coarse);
        int cy0 = (int) Math.floor(minY / coarse);
        int cy1 = (int) Math.floor(maxY / coarse);

        for (int gy = cy0; gy <= cy1; gy++) {
            for (int gx = cx0; gx <= cx1; gx++) {
                gen.sample((gx + 0.5f) * coarse, (gy + 0.5f) * coarse, sample);
                if (sample[1] > 0.0f || sample[0] > WorldGen.CLIFF_LEVEL) continue;
                float lush = 0.75f + 0.5f * Math.max(0.0f, Math.min(1.0f, sample[2] * 1.4f));

                for (int jy = 0; jy < 3; jy++) {
                    for (int jx = 0; jx < 3; jx++) {
                        int ix = gx * 3 + jx;
                        int iy = gy * 3 + jy;
                        int h = hash(ix, iy);
                        float bx = (ix + (h & 255) / 255.0f) * cell;
                        float by = (iy + ((h >> 8) & 255) / 255.0f) * cell;
                        if (bx < minX || bx > maxX || by < minY || by > maxY) continue;
                        if (((h >> 24) & 15) == 0) continue; // a few bald spots

                        float lenF = (0.55f + ((h >> 16) & 255) / 255.0f * 0.75f) * lush;
                        float len = baseLen * lenF;
                        float lean = (((h >> 20) & 255) / 255.0f - 0.5f) * 0.9f;

                        // travelling wind: broad swell + faster ripple
                        float w = (float) Math.sin(bx * 0.55f + by * 0.32f + t * 1.7f * windScale) * 0.55f
                                + (float) Math.sin(bx * 1.9f - by * 1.3f + t * 3.1f * windScale) * 0.22f
                                + 0.25f * windScale;
                        float tipDx = (lean + w * 0.85f * windScale) * len * 0.62f;
                        float tipDy = -len * (1.0f - 0.22f * Math.min(1.0f, Math.abs(tipDx) / len));

                        // shove aside / flatten around anything walking through
                        for (int pi = 0; pi < pushCount; pi++) {
                            float dx = bx - pushX[pi];
                            float dy = (by - pushY[pi]) * 1.5f;
                            float r = pushR[pi];
                            float d2 = dx * dx + dy * dy;
                            if (d2 >= r * r) continue;
                            float d = (float) Math.sqrt(d2) + 1e-4f;
                            float f = 1.0f - d / r;
                            f *= f;
                            tipDx += (dx / d) * f * len * 1.35f + pushVx[pi] * f * len * 0.10f;
                            tipDy += (dy / d) * f * len * 0.55f * 0.66f;
                            tipDy *= 1.0f - 0.50f * f;
                        }

                        float sx = cx + (bx - camX) * ppu;
                        float sy = cy + (by - camY) * ppu;
                        float mx = sx + tipDx * 0.28f;
                        float my = sy + tipDy * 0.58f;
                        float tx = sx + tipDx;
                        float ty = sy + tipDy;

                        int tone = ((h >> 4) & 255) % TONES;
                        // the near / lit blades are a touch lighter
                        int n = segN[tone];
                        if (n + 8 > seg[tone].length) continue;
                        float[] a = seg[tone];
                        a[n] = sx;
                        a[n + 1] = sy;
                        a[n + 2] = mx;
                        a[n + 3] = my;
                        a[n + 4] = mx;
                        a[n + 5] = my;
                        a[n + 6] = tx;
                        a[n + 7] = ty;
                        segN[tone] = n + 8;

                        if (tips && ((h >> 12) & 7) == 0 && tipN + 4 <= tip.length) {
                            tip[tipN] = mx;
                            tip[tipN + 1] = my;
                            tip[tipN + 2] = tx;
                            tip[tipN + 3] = ty;
                            tipN += 4;
                        }
                    }
                }
            }
        }
    }

    private void flush(Canvas canvas, float ppu) {
        float sw = Math.max(1.3f, ppu * 0.021f);
        for (int i = 0; i < TONES; i++) {
            if (segN[i] == 0) continue;
            tonePaint[i].setStrokeWidth(sw * (i == 2 ? 0.85f : 1.0f));
            canvas.drawLines(seg[i], 0, segN[i], tonePaint[i]);
        }
        if (tipN > 0) {
            tipPaint.setStrokeWidth(sw * 0.8f);
            canvas.drawLines(tip, 0, tipN, tipPaint);
        }
    }

    /**
     * Drifting pollen: round dots, hollow rings and tiny four-point stars that twinkle on and off.
     */
    void drawSparkles(Canvas canvas, WorldGen gen, float camX, float camY, float cx, float cy, float ppu,
                      float halfW, float halfH, float time) {
        final float cell = 0.62f;
        int ix0 = (int) Math.floor((camX - halfW) / cell);
        int ix1 = (int) Math.floor((camX + halfW) / cell);
        int iy0 = (int) Math.floor((camY - halfH) / cell);
        int iy1 = (int) Math.floor((camY + halfH) / cell);
        int dn = 0;
        int sn = 0;
        float dotR = Math.max(1.3f, ppu * 0.026f);

        ringPaint.setStrokeWidth(Math.max(1.0f, ppu * 0.014f));
        dotPaint.setStrokeWidth(dotR * 2.0f);
        starPaint.setStrokeWidth(Math.max(1.0f, ppu * 0.013f));

        // rings are few; draw them directly
        for (int iy = iy0; iy <= iy1; iy++) {
            for (int ix = ix0; ix <= ix1; ix++) {
                int h = hash(ix + 7919, iy - 104729);
                if ((h & 7) > 2) continue;
                float wx = (ix + ((h >> 3) & 255) / 255.0f) * cell + (float) Math.sin(time * 0.6f + (h & 63)) * 0.06f;
                float wy = (iy + ((h >> 11) & 255) / 255.0f) * cell + (float) Math.cos(time * 0.5f + (h & 31)) * 0.05f;
                float tw = 0.5f + 0.5f * (float) Math.sin(time * (1.4f + (h & 3) * 0.5f) + ((h >> 19) & 63));
                if (tw < 0.28f) continue;
                gen.sample(wx, wy, sample);
                if (sample[1] > 0.12f) continue;
                float sx = cx + (wx - camX) * ppu;
                float sy = cy + (wy - camY) * ppu;
                int kind = (h >> 26) & 3;
                int a = (int) (70 + 170 * tw);
                if (kind == 0) {
                    ringPaint.setAlpha(a);
                    canvas.drawCircle(sx, sy, dotR * 1.9f, ringPaint);
                } else if (kind == 1 && sn + 8 <= stars.length) {
                    float r = dotR * 2.1f * (0.6f + tw * 0.6f);
                    stars[sn++] = sx - r; stars[sn++] = sy; stars[sn++] = sx + r; stars[sn++] = sy;
                    stars[sn++] = sx; stars[sn++] = sy - r; stars[sn++] = sx; stars[sn++] = sy + r;
                } else if (dn + 2 <= dots.length) {
                    dots[dn++] = sx;
                    dots[dn++] = sy;
                }
            }
        }
        dotPaint.setAlpha(215);
        if (dn > 0) canvas.drawPoints(dots, 0, dn, dotPaint);
        starPaint.setAlpha(225);
        if (sn > 0) canvas.drawLines(stars, 0, sn, starPaint);
    }
}
