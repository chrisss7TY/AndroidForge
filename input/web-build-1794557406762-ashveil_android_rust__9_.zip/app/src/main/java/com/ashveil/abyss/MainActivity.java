package com.ashveil.abyss;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.opengl.GLES30;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.opengl.Matrix;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MainActivity extends Activity {
    private static boolean sRustLoaded = false;
    static {
        try {
            System.loadLibrary("ashveil_ascii_3d");
            sRustLoaded = true;
        } catch (Throwable ignored) {
            sRustLoaded = false;
        }
    }

    public static native long nativeInit(long seed);
    public static native int nativeStep(long handle, float dt);
    public static native void nativeTouch(long handle, int action, long pointerId, float normX, float normY);
    public static native void nativeDestroy(long handle);

    private GLSurfaceView mGlView;
    private HudOverlayView mHudView;
    private GameState mState;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );

        mState = new GameState();
        FrameLayout root = new FrameLayout(this);

        mGlView = new GLSurfaceView(this);
        mGlView.setEGLContextClientVersion(3);
        mGlView.setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        AsciiGlRenderer renderer = new AsciiGlRenderer(mState);
        mGlView.setRenderer(renderer);
        mGlView.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);

        mHudView = new HudOverlayView(this, mState);

        root.addView(mGlView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));
        root.addView(mHudView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mGlView != null) mGlView.onResume();
    }

    @Override
    protected void onPause() {
        if (mGlView != null) mGlView.onPause();
        super.onPause();
    }

    // =========================================================================
    // SHARED REAL-TIME 3D RPG & MULTIPLAYER-READY WORLD STATE
    // =========================================================================
    private static final class GameState {
        // Starts directly in the playable 3D ASCII world (Stage 1 requirement!)
        volatile int screenMode = 1; // 1 = 3D World, 2 = 3D Chainmail & Rune Equipment Menu
        volatile boolean mounted = false;
        volatile boolean cursorViewMode = true;
        volatile int qualityPreset = 2; // 0=Low (8k grass), 1=Med (16k), 2=Ultra (24k instanced grass)
        volatile int zoomPreset = 1;
        volatile float cameraZoom = 1.0f;
        volatile float camYaw = 0.0f;

        // Player 3D Transform & Physics
        volatile float playerX = 0.0f;
        volatile float playerY = 0.0f;
        volatile float playerZ = 4.0f;
        volatile float velX = 0.0f;
        volatile float velY = 0.0f;
        volatile float velZ = 0.0f;
        volatile float facingX = 0.0f;
        volatile float facingZ = -1.0f;
        volatile float bodyYaw = (float) Math.PI;
        volatile float turnVel = 0.0f;
        volatile float gaitPhase = 0.0f;
        volatile float timeSec = 0.0f;
        volatile float slashTimer = 0.0f;
        volatile float slashCooldown = 0.0f;
        volatile float dodgeTimer = 0.0f;
        volatile float dodgeCooldown = 0.0f;
        volatile float dodgeDirX = 0.0f;
        volatile float dodgeDirZ = -1.0f;
        volatile float hurtFlash = 0.0f;

        // Cursor View offset (normalized screen coords)
        volatile float cursorX = 0.56f;
        volatile float cursorY = 0.46f;
        volatile float inputX = 0.0f;
        volatile float inputZ = 0.0f;

        // RPG Progression & Stats (Matching `Senje` screenshot: HP 1612/1612, MP 134/134, LV 13, 5194g)
        volatile String playerName = "Senje";
        volatile int level = 13;
        volatile int xp = 1943;
        volatile int xpNext = 6995;
        volatile int hp = 1612;
        volatile int maxHp = 1612;
        volatile int mp = 134;
        volatile int maxMp = 134;
        volatile int gold = 5194;
        volatile int statPoints = 3;
        volatile int vit = 18;
        volatile int str = 22;
        volatile int dex = 16;
        volatile int potions = 3;
        volatile int herbMoon = 3;
        volatile int herbMoss = 2;
        volatile int cinderShards = 2;

        // Quest System
        volatile int questKills = 0;
        volatile int questTarget = 5;
        volatile boolean questCompleted = false;

        // Equipment & Material System (Helm, Shoulders, Chest, Gloves, Legs, Boots + 10 Metals + Runes)
        volatile int selectedSlot = 0; // 0=Helm, 1=Shoulders, 2=Chest, 3=Gloves, 4=Legs, 5=Boots
        final int[] slotMetal = new int[]{0, 1, 1, 0, 1, 0}; // Iron/Steel default per slot
        volatile int activeMetal = 0; // 0=Iron..9=Emberstone
        volatile int runeSlot1 = -1;
        volatile int runeSlot2 = -1;
        volatile float previewYaw = 0.4f;
        volatile float previewZoom = 1.0f;

        static final String[] SLOT_NAMES = {"Helm", "Shoulders", "Chest", "Gloves", "Legs", "Boots"};
        static final String[] RUNE_GLYPHS = {"^", "*", "z", "~", ">", "/", "x", "v", "o", "\u00a7", "+"};
        static final String[] METAL_NAMES = {
                "#%: Iron", "@%. Steel", "&o, Bronze", "$s. Silver", "0o. Gold",
                "O*. Moonsteel", "Nightglass", "88: Bloodiron", "=-. Ossite", "*+. Emberstone"
        };
        static final String[] METAL_SHORT = {
                "Iron", "Steel", "Bronze", "Silver", "Gold",
                "Moonsteel", "Nightglass", "Bloodiron", "Ossite", "Emberstone"
        };
        static final float[][] METAL_RGB = {
                {0.76f, 0.79f, 0.82f}, // Iron
                {0.88f, 0.91f, 0.95f}, // Steel
                {0.84f, 0.60f, 0.38f}, // Bronze
                {0.95f, 0.97f, 1.00f}, // Silver
                {0.98f, 0.84f, 0.36f}, // Gold
                {0.62f, 0.84f, 1.00f}, // Moonsteel
                {0.58f, 0.50f, 0.82f}, // Nightglass
                {0.90f, 0.30f, 0.34f}, // Bloodiron
                {0.90f, 0.87f, 0.78f}, // Ossite
                {1.00f, 0.56f, 0.28f}  // Emberstone
        };

        // 3D Enemies (Idle at post until player within 7.5 units)
        static final int NUM_ENEMIES = 10;
        final float[] enemyX = new float[NUM_ENEMIES];
        final float[] enemyZ = new float[NUM_ENEMIES];
        final float[] enemyHomeX = new float[NUM_ENEMIES];
        final float[] enemyHomeZ = new float[NUM_ENEMIES];
        final float[] enemyYaw = new float[NUM_ENEMIES];
        final float[] enemyGait = new float[NUM_ENEMIES];
        final float[] enemyWindup = new float[NUM_ENEMIES];
        final float[] enemyCooldown = new float[NUM_ENEMIES];
        final float[] enemyHurt = new float[NUM_ENEMIES];
        final int[] enemyHp = new int[NUM_ENEMIES];
        final int[] enemyMaxHp = new int[NUM_ENEMIES];
        final int[] enemyMetal = new int[NUM_ENEMIES];
        final boolean[] enemyAggro = new boolean[NUM_ENEMIES];

        // 3D Loot Drops
        static final int MAX_LOOT = 12;
        final float[] lootX = new float[MAX_LOOT];
        final float[] lootZ = new float[MAX_LOOT];
        final int[] lootMetal = new int[MAX_LOOT];
        final boolean[] lootActive = new boolean[MAX_LOOT];

        // Status & Floating Popups
        volatile String statusBanner = "Explore the 3D ASCII World • Moonlit Cave North • River South";
        volatile float bannerTimer = 4.5f;

        // Server-Authoritative Multiplayer Sync Queue (Ready for WebSocket/UDP Packet Relay)
        static final class NetEntityPacket {
            long entityId;
            float x, y, z, yaw;
            int animState, hp, maxHp;
        }
        final NetEntityPacket[] netPeers = new NetEntityPacket[8];
        volatile int connectedPeers = 0;

        GameState() {
            for (int i = 0; i < 8; i++) netPeers[i] = new NetEntityPacket();
            for (int i = 0; i < NUM_ENEMIES; i++) {
                spawnEnemy(i, i < 3);
            }
        }

        float riverCenterZ(float wx) {
            return -6.5f + (float) Math.sin(wx * 0.14f) * 2.2f;
        }

        boolean isInsideCave(float wx, float wz) {
            float dx = wx - 0.0f;
            float dz = wz - (-18.0f);
            return (dx * dx + dz * dz) < 11.0f * 11.0f;
        }

        float cliffHeight(float wx, float wz) {
            // Keep player spawn meadow & river bed clear
            if (wx * wx + (wz - 4.0f) * (wz - 4.0f) < 15.0f) return 0.0f;
            if (Math.abs(wz - riverCenterZ(wx)) < 3.2f) return 0.0f;
            // Moonlit Cave entrance archway at (0, -13.5) leading into cave chamber at (0, -18)
            if (Math.abs(wx) < 2.6f && wz < -10.5f && wz > -22.0f) return 0.0f;

            float n = (float) (Math.sin(wx * 0.22f + 0.7f) * Math.cos(wz * 0.19f - 0.4f)
                    + 0.48f * Math.sin(wx * 0.49f - wz * 0.35f));
            if (n > 0.62f) {
                return (n - 0.62f) * 9.5f;
            }
            return 0.0f;
        }

        boolean isBlocked(float wx, float wz) {
            return cliffHeight(wx, wz) > 0.35f;
        }

        void spawnEnemy(int i, boolean near) {
            float ang = i * 0.95f + 0.6f;
            float dist = near ? (6.5f + i * 2.2f) : (10.5f + (i % 5) * 3.5f);
            float ex = (float) Math.cos(ang) * dist;
            float ez = 4.0f + (float) Math.sin(ang) * dist;
            if (isBlocked(ex, ez)) {
                ex = 5.5f + (i % 3) * 2.0f;
                ez = 6.5f + (i / 3) * 2.0f;
            }
            enemyX[i] = enemyHomeX[i] = ex;
            enemyZ[i] = enemyHomeZ[i] = ez;
            enemyYaw[i] = (float) Math.PI;
            enemyGait[i] = i * 0.8f;
            enemyWindup[i] = 0.0f;
            enemyCooldown[i] = 0.5f;
            enemyHurt[i] = 0.0f;
            enemyMaxHp[i] = 120 + level * 16 + (i % 3) * 40;
            enemyHp[i] = enemyMaxHp[i];
            enemyMetal[i] = (i + 1) % METAL_RGB.length;
            enemyAggro[i] = false;
        }

        void triggerSlash() {
            if (slashCooldown > 0.0f) return;
            slashTimer = 0.28f;
            slashCooldown = 0.34f;

            int weaponBonus = (slotMetal[0] + slotMetal[1] + slotMetal[2]) * 6;
            int runeBonus = (runeSlot1 >= 0 ? 18 : 0) + (runeSlot2 >= 0 ? 18 : 0);
            int dmg = 42 + str * 3 + weaponBonus + runeBonus;

            for (int i = 0; i < NUM_ENEMIES; i++) {
                float dx = enemyX[i] - playerX;
                float dz = enemyZ[i] - playerZ;
                float d2 = dx * dx + dz * dz;
                if (d2 < 3.6f * 3.6f) {
                    enemyHp[i] -= dmg;
                    enemyHurt[i] = 0.25f;
                    enemyAggro[i] = true;
                    float d = (float) Math.sqrt(d2 + 0.001f);
                    enemyX[i] += (dx / d) * 0.65f;
                    enemyZ[i] += (dz / d) * 0.65f;
                    if (enemyHp[i] <= 0) {
                        int xpGain = 185 + level * 35;
                        int goldGain = 65 + (i * 23) % 80;
                        xp += xpGain;
                        gold += goldGain;
                        cinderShards++;
                        if (!questCompleted) {
                            questKills++;
                            if (questKills >= questTarget) {
                                questCompleted = true;
                                gold += 500;
                                xp += 1000;
                                statusBanner = "QUEST COMPLETE: Moonlit Wardens (+500g, +1000 XP)";
                                bannerTimer = 4.0f;
                            }
                        }
                        if (xp >= xpNext) {
                            xp -= xpNext;
                            level++;
                            xpNext = (int) (xpNext * 1.25f);
                            statPoints += 3;
                            maxHp += 110;
                            hp = maxHp;
                            maxMp += 18;
                            mp = maxMp;
                            statusBanner = "LEVEL UP! LV " + level + " (+3 Stat Pts)";
                            bannerTimer = 3.5f;
                        } else if (!questCompleted) {
                            statusBanner = "Slain Ash-Stalker (+" + xpGain + " XP, +" + goldGain + "g)";
                            bannerTimer = 2.6f;
                        }
                        for (int l = 0; l < MAX_LOOT; l++) {
                            if (!lootActive[l]) {
                                lootActive[l] = true;
                                lootX[l] = enemyX[i];
                                lootZ[l] = enemyZ[i];
                                lootMetal[l] = (enemyMetal[i] + 1) % METAL_RGB.length;
                                break;
                            }
                        }
                        spawnEnemy(i, false);
                    }
                }
            }
        }

        void triggerJump() {
            if (playerY <= 0.01f) {
                velY = 6.2f;
            }
        }

        void triggerDodge() {
            if (dodgeCooldown > 0.0f) return;
            dodgeTimer = 0.28f;
            dodgeCooldown = 0.85f;
            float len = (float) Math.sqrt(inputX * inputX + inputZ * inputZ);
            if (len > 0.15f) {
                dodgeDirX = inputX / len;
                dodgeDirZ = inputZ / len;
            } else {
                dodgeDirX = facingX;
                dodgeDirZ = facingZ;
            }
            facingX = dodgeDirX;
            facingZ = dodgeDirZ;
        }

        void stepSimulation(float dt) {
            timeSec += dt;
            if (bannerTimer > 0.0f) bannerTimer -= dt;
            if (slashTimer > 0.0f) slashTimer -= dt;
            if (slashCooldown > 0.0f) slashCooldown -= dt;
            if (dodgeTimer > 0.0f) dodgeTimer -= dt;
            if (dodgeCooldown > 0.0f) dodgeCooldown -= dt;
            if (hurtFlash > 0.0f) hurtFlash -= dt;

            if (screenMode == 2) {
                previewYaw += dt * 0.65f;
                return;
            }

            // Camera-relative movement vector
            float cosY = (float) Math.cos(camYaw);
            float sinY = (float) Math.sin(camYaw);
            float worldInX = inputX * cosY - inputZ * sinY;
            float worldInZ = inputX * sinY + inputZ * cosY;

            if (dodgeTimer > 0.0f) {
                float dashSpd = mounted ? 14.5f : 11.8f;
                velX = dodgeDirX * dashSpd;
                velZ = dodgeDirZ * dashSpd;
            } else {
                float topSpd = mounted ? 7.2f : 4.8f;
                float accel = Math.min(1.0f, dt * 11.0f);
                velX += (worldInX * topSpd - velX) * accel;
                velZ += (worldInZ * topSpd - velZ) * accel;
            }

            float nx = playerX + velX * dt;
            float nz = playerZ + velZ * dt;
            if (!isBlocked(nx, playerZ)) playerX = nx;
            if (!isBlocked(playerX, nz)) playerZ = nz;

            // Vertical Jump & Gravity Physics
            if (playerY > 0.0f || velY > 0.0f) {
                playerY += velY * dt;
                velY -= 16.5f * dt;
                if (playerY < 0.0f) {
                    playerY = 0.0f;
                    velY = 0.0f;
                }
            }

            float spd = (float) Math.sqrt(velX * velX + velZ * velZ);
            if (spd > 0.20f) {
                facingX = velX / spd;
                facingZ = velZ / spd;
                float targetYaw = (float) Math.atan2(facingX, facingZ);
                float diff = targetYaw - bodyYaw;
                while (diff > Math.PI) diff -= (float) (Math.PI * 2.0);
                while (diff < -Math.PI) diff += (float) (Math.PI * 2.0);
                turnVel = diff;
                bodyYaw += diff * Math.min(1.0f, dt * 12.0f);
                gaitPhase += dt * (mounted ? 5.8f + spd * 1.9f : 5.2f + spd * 2.5f);
            } else {
                turnVel *= 0.85f;
                gaitPhase += dt * 1.8f;
            }

            // Loot pickup
            for (int l = 0; l < MAX_LOOT; l++) {
                if (lootActive[l]) {
                    float dx = lootX[l] - playerX;
                    float dz = lootZ[l] - playerZ;
                    if (dx * dx + dz * dz < 1.35f * 1.35f) {
                        lootActive[l] = false;
                        int m = lootMetal[l];
                        slotMetal[m % 6] = m;
                        activeMetal = m;
                        statusBanner = "Equipped " + METAL_SHORT[m] + " " + SLOT_NAMES[m % 6] + "!";
                        bannerTimer = 3.0f;
                    }
                }
            }

            // Enemy AI (Guard post until player within 7.5 units)
            for (int i = 0; i < NUM_ENEMIES; i++) {
                if (enemyHurt[i] > 0.0f) enemyHurt[i] -= dt;
                if (enemyCooldown[i] > 0.0f) enemyCooldown[i] -= dt;

                float dx = playerX - enemyX[i];
                float dz = playerZ - enemyZ[i];
                float dist = (float) Math.sqrt(dx * dx + dz * dz + 0.001f);

                if (!enemyAggro[i] && dist < 7.2f) {
                    enemyAggro[i] = true;
                } else if (enemyAggro[i] && dist > 13.5f) {
                    enemyAggro[i] = false;
                }

                if (!enemyAggro[i]) {
                    float hx = enemyHomeX[i] - enemyX[i];
                    float hz = enemyHomeZ[i] - enemyZ[i];
                    float hd = (float) Math.sqrt(hx * hx + hz * hz);
                    if (hd > 0.35f) {
                        enemyYaw[i] = (float) Math.atan2(hx, hz);
                        enemyGait[i] += dt * 5.0f;
                        enemyX[i] += (hx / hd) * 1.4f * dt;
                        enemyZ[i] += (hz / hd) * 1.4f * dt;
                    } else {
                        enemyGait[i] += dt * 1.4f;
                    }
                    continue;
                }

                enemyYaw[i] = (float) Math.atan2(dx, dz);
                if (enemyWindup[i] > 0.0f) {
                    enemyWindup[i] -= dt;
                    if (enemyWindup[i] <= 0.0f) {
                        if (dist < 2.3f && dodgeTimer <= 0.0f) {
                            int eDmg = 22 + level * 2 + (i % 3) * 6;
                            hp = Math.max(0, hp - eDmg);
                            hurtFlash = 0.25f;
                            if (hp <= 0) {
                                hp = maxHp;
                                playerX = 0.0f;
                                playerZ = 4.0f;
                                statusBanner = "Revived at Meadow Sanctuary";
                                bannerTimer = 3.0f;
                            }
                        }
                        enemyCooldown[i] = 1.25f;
                    }
                } else if (dist > 1.55f) {
                    enemyGait[i] += dt * 8.2f;
                    float ex = enemyX[i] + (dx / dist) * 2.2f * dt;
                    float ez = enemyZ[i] + (dz / dist) * 2.2f * dt;
                    if (!isBlocked(ex, ez)) {
                        enemyX[i] = ex;
                        enemyZ[i] = ez;
                    }
                } else if (enemyCooldown[i] <= 0.0f) {
                    enemyWindup[i] = 0.42f;
                }
            }
        }
    }

    // =========================================================================
    // OPENGL ES 3.0 REAL-TIME 3D ASCII ENGINE (INSTANCED GRASS + GLSL SHADERS)
    // =========================================================================
    private static final class AsciiGlRenderer implements GLSurfaceView.Renderer {
        private final GameState mState;
        private long mLastNs = System.nanoTime();
        private int mWidth = 1280;
        private int mHeight = 720;

        // OpenGL Shader Programs
        private int mProgMeshAscii = 0;
        private int mProgGrassInstanced = 0;
        private int mProgWaterAscii = 0;

        // 16x6 Character Glyph Atlas Texture (96 glyphs: density ramp + chainmail + grass)
        private int mGlyphAtlasTex = 0;

        // Planar Water Reflection Framebuffer Object (FBO)
        private int mReflectFbo = 0;
        private int mReflectTex = 0;
        private int mReflectDepthRb = 0;
        private static final int REFLECT_W = 512;
        private static final int REFLECT_H = 512;

        // 3D Sphere/Capsule Unit Mesh VBO/IBO (for 3D Humanoid Characters, Cliffs, Trees, Coif)
        private FloatBuffer mUnitSphereVerts;
        private ShortBuffer mUnitSphereIndices;
        private int mSphereIndexCount = 0;

        // 3D Ground & Water Grid Mesh
        private FloatBuffer mQuadVerts;

        // GPU Instanced 3D Grass & Wildflower Buffer (24,000 3D blades in ONE glDrawArraysInstanced call!)
        private static final int MAX_GRASS_INSTANCES = 24000;
        private int mGrassRibbonVbo = 0;
        private int mGrassInstanceVbo = 0;

        // Matrices
        private final float[] mProjMatrix = new float[16];
        private final float[] mViewMatrix = new float[16];
        private final float[] mVpMatrix = new float[16];
        private final float[] mReflectViewMatrix = new float[16];
        private final float[] mReflectVpMatrix = new float[16];
        private final float[] mModelMatrix = new float[16];
        private final float[] mMvpMatrix = new float[16];

        // Static 3D World Cliffs, Trees, and Cave Pillars
        private static final int NUM_CLIFF_PILLARS = 44;
        private final float[] mPillarX = new float[NUM_CLIFF_PILLARS];
        private final float[] mPillarY = new float[NUM_CLIFF_PILLARS];
        private final float[] mPillarZ = new float[NUM_CLIFF_PILLARS];
        private final float[] mPillarSx = new float[NUM_CLIFF_PILLARS];
        private final float[] mPillarSy = new float[NUM_CLIFF_PILLARS];
        private final float[] mPillarSz = new float[NUM_CLIFF_PILLARS];

        AsciiGlRenderer(GameState state) {
            mState = state;
            initStatic3DWorldGeometry();
        }

        private void initStatic3DWorldGeometry() {
            int idx = 0;
            // Sculpted 3D Cliff Monoliths & Moonlit Cave Archway
            for (int gz = -24; gz <= 20 && idx < NUM_CLIFF_PILLARS; gz += 3) {
                for (int gx = -24; gx <= 24 && idx < NUM_CLIFF_PILLARS; gx += 3) {
                    float h = mState.cliffHeight(gx, gz);
                    if (h > 0.5f) {
                        mPillarX[idx] = gx;
                        mPillarY[idx] = h * 0.45f;
                        mPillarZ[idx] = gz;
                        mPillarSx[idx] = 1.85f + (Math.abs(gx * 7 + gz * 13) % 10) * 0.12f;
                        mPillarSy[idx] = h;
                        mPillarSz[idx] = 1.85f + (Math.abs(gx * 11 + gz * 5) % 10) * 0.12f;
                        idx++;
                    }
                }
            }
            while (idx < NUM_CLIFF_PILLARS) {
                mPillarX[idx] = 14.0f + idx * 0.5f;
                mPillarY[idx] = 2.5f;
                mPillarZ[idx] = -14.0f;
                mPillarSx[idx] = 2.0f;
                mPillarSy[idx] = 5.0f;
                mPillarSz[idx] = 2.0f;
                idx++;
            }
        }

        @Override
        public void onSurfaceCreated(GL10 gl, EGLConfig config) {
            GLES30.glClearColor(0.025f, 0.042f, 0.038f, 1.0f);
            GLES30.glEnable(GLES30.GL_DEPTH_TEST);
            GLES30.glDepthFunc(GLES30.GL_LEQUAL);
            GLES30.glEnable(GLES30.GL_BLEND);
            GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA);

            mGlyphAtlasTex = createAsciiGlyphAtlasTexture();
            buildUnitSphereMesh(12, 16);
            buildQuadMesh();
            buildInstancedGrassBuffers();
            initReflectionFbo();
            compileAllShaders();
        }

        @Override
        public void onSurfaceChanged(GL10 gl, int width, int height) {
            mWidth = Math.max(1, width);
            mHeight = Math.max(1, height);
            GLES30.glViewport(0, 0, mWidth, mHeight);
        }

        @Override
        public void onDrawFrame(GL10 gl) {
            long nowNs = System.nanoTime();
            float dt = (nowNs - mLastNs) / 1_000_000_000.0f;
            mLastNs = nowNs;
            if (dt > 0.05f) dt = 0.05f;
            if (dt < 0.001f) dt = 0.001f;

            mState.stepSimulation(dt);

            if (mState.screenMode == 2) {
                render3DChainmailEquipmentScene();
            } else {
                render3DOpenWorldScene();
            }
        }

        // ---------------------------------------------------------------------
        // BUILD 16x6 ASCII GLYPH TEXTURE ATLAS (CRISP MONOSPACE CELL BITMAP)
        // ---------------------------------------------------------------------
        private int createAsciiGlyphAtlasTexture() {
            int cols = 16;
            int rows = 6;
            int cellW = 32;
            int cellH = 32;
            Bitmap bmp = Bitmap.createBitmap(cols * cellW, rows * cellH, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bmp);
            c.drawColor(Color.TRANSPARENT);

            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
            p.setTextSize(26.0f);
            p.setColor(Color.WHITE);
            p.setTextAlign(Paint.Align.CENTER);

            // Row 0..1: 32-char 3D surface luminance ASCII ramp (light -> dense `@WM#B8&%$0QOZmwqpdbkhao*+=-:;,. `)
            // Row 2: Chainmail weave characters (`S8$#c()350Qo*+=~`)
            // Row 3: Grass & flower glyphs (`|/\}]{[*o+.,:;~^`)
            String atlasChars =
                    " .,:;-=+*oahkbdp" +
                    "qwmZOQ0N$%&8B#MW" +
                    "@S8$#c()350Qo*+=" +
                    "|/\\*o+.,:;~^v<>#" +
                    "0Q8B@WM#%&80aaqQ" +
                    "()[]{}$#@*+=-~:;.";

            Paint.FontMetrics fm = p.getFontMetrics();
            float baselineOff = -(fm.ascent + fm.descent) * 0.5f;

            for (int r = 0; r < rows; r++) {
                for (int col = 0; col < cols; col++) {
                    int idx = r * cols + col;
                    char ch = (idx < atlasChars.length()) ? atlasChars.charAt(idx) : '@';
                    float cx = col * cellW + cellW * 0.5f;
                    float cy = r * cellH + cellH * 0.5f + baselineOff;
                    c.drawText(String.valueOf(ch), cx, cy, p);
                }
            }

            int[] tex = new int[1];
            GLES30.glGenTextures(1, tex, 0);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex[0]);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);
            GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0);
            bmp.recycle();
            return tex[0];
        }

        private void buildUnitSphereMesh(int latBands, int lonBands) {
            int vertCount = (latBands + 1) * (lonBands + 1);
            float[] verts = new float[vertCount * 8]; // pos(3), normal(3), uv(2)
            int vPtr = 0;
            for (int lat = 0; lat <= latBands; lat++) {
                float theta = (float) (lat * Math.PI / latBands);
                float sinT = (float) Math.sin(theta);
                float cosT = (float) Math.cos(theta);
                for (int lon = 0; lon <= lonBands; lon++) {
                    float phi = (float) (lon * 2.0 * Math.PI / lonBands);
                    float nx = (float) Math.cos(phi) * sinT;
                    float ny = cosT;
                    float nz = (float) Math.sin(phi) * sinT;
                    verts[vPtr++] = nx * 0.5f;
                    verts[vPtr++] = ny * 0.5f;
                    verts[vPtr++] = nz * 0.5f;
                    verts[vPtr++] = nx;
                    verts[vPtr++] = ny;
                    verts[vPtr++] = nz;
                    verts[vPtr++] = lon / (float) lonBands;
                    verts[vPtr++] = lat / (float) latBands;
                }
            }

            short[] indices = new short[latBands * lonBands * 6];
            int iPtr = 0;
            for (int lat = 0; lat < latBands; lat++) {
                for (int lon = 0; lon < lonBands; lon++) {
                    int first = (lat * (lonBands + 1)) + lon;
                    int second = first + lonBands + 1;
                    indices[iPtr++] = (short) first;
                    indices[iPtr++] = (short) second;
                    indices[iPtr++] = (short) (first + 1);
                    indices[iPtr++] = (short) second;
                    indices[iPtr++] = (short) (second + 1);
                    indices[iPtr++] = (short) (first + 1);
                }
            }
            mSphereIndexCount = indices.length;

            mUnitSphereVerts = ByteBuffer.allocateDirect(verts.length * 4)
                    .order(ByteOrder.nativeOrder()).asFloatBuffer();
            mUnitSphereVerts.put(verts).position(0);

            mUnitSphereIndices = ByteBuffer.allocateDirect(indices.length * 2)
                    .order(ByteOrder.nativeOrder()).asShortBuffer();
            mUnitSphereIndices.put(indices).position(0);
        }

        private void buildQuadMesh() {
            float[] q = new float[]{
                    -1f, 0f, -1f, 0f, 1f, 0f, 0f, 0f,
                     1f, 0f, -1f, 0f, 1f, 0f, 1f, 0f,
                    -1f, 0f,  1f, 0f, 1f, 0f, 0f, 1f,
                     1f, 0f, -1f, 0f, 1f, 0f, 1f, 0f,
                     1f, 0f,  1f, 0f, 1f, 0f, 1f, 1f,
                    -1f, 0f,  1f, 0f, 1f, 0f, 0f, 1f
            };
            mQuadVerts = ByteBuffer.allocateDirect(q.length * 4)
                    .order(ByteOrder.nativeOrder()).asFloatBuffer();
            mQuadVerts.put(q).position(0);
        }

        private void buildInstancedGrassBuffers() {
            // Single 3D grass/flower billboard quad (6 vertices: localX, localY, u, v)
            float[] ribbon = new float[]{
                    -0.5f, 0.0f, 0.0f, 1.0f,
                     0.5f, 0.0f, 1.0f, 1.0f,
                    -0.5f, 1.0f, 0.0f, 0.0f,
                     0.5f, 0.0f, 1.0f, 1.0f,
                     0.5f, 1.0f, 1.0f, 0.0f,
                    -0.5f, 1.0f, 0.0f, 0.0f
            };
            FloatBuffer rb = ByteBuffer.allocateDirect(ribbon.length * 4)
                    .order(ByteOrder.nativeOrder()).asFloatBuffer();
            rb.put(ribbon).position(0);

            // 24,000 instances: (offsetX, offsetZ, heightScale, glyphAndColorSeed)
            float[] inst = new float[MAX_GRASS_INSTANCES * 4];
            int seed = 918273645;
            for (int i = 0; i < MAX_GRASS_INSTANCES; i++) {
                seed = seed * 1664525 + 1013904223;
                float rx = (((seed >>> 16) & 0xFFFF) / 65535.0f - 0.5f) * 32.0f;
                seed = seed * 1664525 + 1013904223;
                float rz = (((seed >>> 16) & 0xFFFF) / 65535.0f - 0.5f) * 32.0f;
                seed = seed * 1664525 + 1013904223;
                boolean isFlower = ((i % 24) == 0);
                float hScale = isFlower ? 0.28f : (0.36f + ((seed >>> 12) & 15) * 0.022f);
                float typeSeed = isFlower ? (100.0f + (i % 5)) : (i % 16);

                int o = i * 4;
                inst[o] = rx;
                inst[o + 1] = rz;
                inst[o + 2] = hScale;
                inst[o + 3] = typeSeed;
            }
            FloatBuffer ib = ByteBuffer.allocateDirect(inst.length * 4)
                    .order(ByteOrder.nativeOrder()).asFloatBuffer();
            ib.put(inst).position(0);

            int[] vbos = new int[2];
            GLES30.glGenBuffers(2, vbos, 0);
            mGrassRibbonVbo = vbos[0];
            mGrassInstanceVbo = vbos[1];

            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, mGrassRibbonVbo);
            GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, ribbon.length * 4, rb, GLES30.GL_STATIC_DRAW);

            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, mGrassInstanceVbo);
            GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, inst.length * 4, ib, GLES30.GL_STATIC_DRAW);
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0);
        }

        private void initReflectionFbo() {
            int[] fbo = new int[1];
            int[] tex = new int[1];
            int[] rb = new int[1];
            GLES30.glGenFramebuffers(1, fbo, 0);
            GLES30.glGenTextures(1, tex, 0);
            GLES30.glGenRenderbuffers(1, rb, 0);

            mReflectFbo = fbo[0];
            mReflectTex = tex[0];
            mReflectDepthRb = rb[0];

            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, mReflectTex);
            GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, REFLECT_W, REFLECT_H, 0,
                    GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);

            GLES30.glBindRenderbuffer(GLES30.GL_RENDERBUFFER, mReflectDepthRb);
            GLES30.glRenderbufferStorage(GLES30.GL_RENDERBUFFER, GLES30.GL_DEPTH_COMPONENT16, REFLECT_W, REFLECT_H);

            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, mReflectFbo);
            GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, mReflectTex, 0);
            GLES30.glFramebufferRenderbuffer(GLES30.GL_FRAMEBUFFER, GLES30.GL_DEPTH_ATTACHMENT, GLES30.GL_RENDERBUFFER, mReflectDepthRb);
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
        }

        // ---------------------------------------------------------------------
        // GLSL ES 3.0 SHADERS (3D SURFACE-CONTOUR ASCII + GPU INSTANCED GRASS + NORMAL-MAPPED WATER)
        // ---------------------------------------------------------------------
        private void compileAllShaders() {
            // 1. 3D Mesh Surface-Contour ASCII Shader (Cliffs, 3D Humanoids, Armor, Chainmail Coif, Ground Matrix)
            String vsMesh =
                    "#version 300 es\n" +
                    "layout(location = 0) in vec3 aPos;\n" +
                    "layout(location = 1) in vec3 aNormal;\n" +
                    "layout(location = 2) in vec2 aUv;\n" +
                    "uniform mat4 uMVP;\n" +
                    "uniform mat4 uModel;\n" +
                    "out vec3 vWorldPos;\n" +
                    "out vec3 vNormal;\n" +
                    "out vec2 vUv;\n" +
                    "void main() {\n" +
                    "    vec4 wp = uModel * vec4(aPos, 1.0);\n" +
                    "    vWorldPos = wp.xyz;\n" +
                    "    vNormal = normalize(mat3(uModel) * aNormal);\n" +
                    "    vUv = aUv;\n" +
                    "    gl_Position = uMVP * vec4(aPos, 1.0);\n" +
                    "}\n";

            String fsMesh =
                    "#version 300 es\n" +
                    "precision mediump float;\n" +
                    "in vec3 vWorldPos;\n" +
                    "in vec3 vNormal;\n" +
                    "in vec2 vUv;\n" +
                    "uniform sampler2D uAtlas;\n" +
                    "uniform vec3 uBaseColor;\n" +
                    "uniform vec3 uCamPos;\n" +
                    "uniform float uCellScale;\n" +
                    "uniform int uMaterialMode;\n" + // 0=Cliff ASCII, 1=Chainmail Coif, 2=0Q8B Ground, 3=Dark-Armored 3D Adventurer (Reference!)
                    "uniform float uTime;\n" +
                    "out vec4 fragColor;\n" +
                    "void main() {\n" +
                    "    vec3 N = normalize(vNormal);\n" +
                    "    vec3 L = normalize(vec3(-0.55, 0.78, 0.38));\n" +
                    "    vec3 V = normalize(uCamPos - vWorldPos);\n" +
                    "    vec3 H = normalize(L + V);\n" +
                    "    float diff = max(0.04, dot(N, L));\n" +
                    "    float spec = pow(max(0.0, dot(N, H)), 18.0);\n" +
                    "    float rim = pow(1.0 - max(0.0, dot(N, V)), 2.4);\n" +
                    "    if (uMaterialMode == 3) {\n" +
                    "        vec2 scGrid = gl_FragCoord.xy / max(5.5, uCellScale);\n" +
                    "        vec2 cellId = floor(scGrid);\n" +
                    "        vec2 cellUv = fract(scGrid);\n" +
                    "        float armorSeams = 0.85 + 0.15 * sin(vWorldPos.y * 28.0 + vWorldPos.x * 16.0);\n" +
                    "        float lum = clamp((diff * 0.42 + spec * 0.95 + rim * 0.55) * armorSeams, 0.02, 0.99);\n" +
                    "        float idx;\n" +
                    "        if (spec > 0.38 || rim > 0.62) {\n" +
                    "            idx = 22.0 + floor(clamp(spec + rim * 0.5, 0.0, 0.99) * 9.0);\n" +
                    "        } else if (diff > 0.42) {\n" +
                    "            idx = 8.0 + floor(lum * 13.0);\n" +
                    "        } else {\n" +
                    "            idx = 2.0 + floor(lum * 6.0);\n" +
                    "        }\n" +
                    "        float glyphCol = mod(idx, 16.0);\n" +
                    "        float glyphRow = floor(idx / 16.0);\n" +
                    "        vec2 atlasUv = (vec2(glyphCol, glyphRow) + cellUv) / vec2(16.0, 6.0);\n" +
                    "        float mask = texture(uAtlas, atlasUv).a;\n" +
                    "        vec3 obsidianBack = vec3(0.015, 0.020, 0.024);\n" +
                    "        vec3 glyphColRgb = (spec > 0.35 || rim > 0.58)\n" +
                    "                ? vec3(0.96, 0.98, 1.0)\n" +
                    "                : (uBaseColor * (0.28 + 0.82 * lum));\n" +
                    "        fragColor = vec4(mix(obsidianBack, glyphColRgb, mask), 1.0);\n" +
                    "        return;\n" +
                    "    }\n" +
                    "    float lum = clamp(diff * 0.82 + rim * 0.45, 0.05, 0.99);\n" +
                    "    vec2 gridCoord = (uMaterialMode == 2) ? (vWorldPos.xz * uCellScale) : (gl_FragCoord.xy / max(7.5, uCellScale));\n" +
                    "    vec2 cellId = floor(gridCoord);\n" +
                    "    vec2 cellUv = fract(gridCoord);\n" +
                    "    float glyphCol;\n" +
                    "    float glyphRow;\n" +
                    "    if (uMaterialMode == 1) {\n" +
                    "        float h = fract(sin(dot(cellId, vec2(12.9898, 78.233))) * 43758.5453);\n" +
                    "        glyphCol = floor(h * 16.0);\n" +
                    "        glyphRow = 2.0;\n" +
                    "    } else if (uMaterialMode == 2) {\n" +
                    "        float h = fract(sin(dot(cellId, vec2(37.1, 61.7))) * 43758.5453);\n" +
                    "        if (h < 0.42) { fragColor = vec4(0.025, 0.042, 0.038, 1.0); return; }\n" +
                    "        glyphCol = floor(h * 16.0);\n" +
                    "        glyphRow = 4.0;\n" +
                    "    } else {\n" +
                    "        float h = fract(sin(dot(cellId, vec2(19.19, 73.73))) * 43758.5453);\n" +
                    "        float idx = clamp(floor((lum * 0.75 + h * 0.25) * 31.0), 1.0, 31.0);\n" +
                    "        glyphCol = mod(idx, 16.0);\n" +
                    "        glyphRow = floor(idx / 16.0);\n" +
                    "    }\n" +
                    "    vec2 atlasUv = (vec2(glyphCol, glyphRow) + cellUv) / vec2(16.0, 6.0);\n" +
                    "    float mask = texture(uAtlas, atlasUv).a;\n" +
                    "    vec3 darkBack = vec3(0.022, 0.030, 0.036);\n" +
                    "    vec3 litGlyph = uBaseColor * (0.30 + 0.85 * lum);\n" +
                    "    vec3 col = mix(darkBack, litGlyph, mask);\n" +
                    "    float dist = length(vWorldPos.xz - uCamPos.xz);\n" +
                    "    float fog = clamp((dist - 16.0) / 26.0, 0.0, 0.68);\n" +
                    "    vec3 fogCol = vec3(0.55, 0.62, 0.64);\n" +
                    "    fragColor = vec4(mix(col, fogCol, fog), 1.0);\n" +
                    "}\n";

            // 2. GPU Instanced 3D ASCII Grass & Wildflower Shader (24,000 3D blades in 1 draw call!)
            String vsGrass =
                    "#version 300 es\n" +
                    "layout(location = 0) in vec4 aRibbon;\n" + // x, y, u, v
                    "layout(location = 1) in vec4 aInst;\n" +   // rx, rz, hScale, seed
                    "uniform mat4 uVP;\n" +
                    "uniform vec3 uPlayerPos;\n" +
                    "uniform vec3 uCamRight;\n" +
                    "uniform float uTime;\n" +
                    "out vec2 vUv;\n" +
                    "out vec3 vColor;\n" +
                    "out vec2 vAtlasCell;\n" +
                    "out float vFog;\n" +
                    "void main() {\n" +
                    "    vec2 tile = floor((uPlayerPos.xz - aInst.xy + 16.0) / 32.0) * 32.0 + aInst.xy;\n" +
                    "    float riverZ = -6.5 + sin(tile.x * 0.14) * 2.2;\n" +
                    "    if (abs(tile.y - riverZ) < 2.55) {\n" +
                    "        gl_Position = vec4(0.0, 0.0, -2.0, 1.0);\n" +
                    "        return;\n" +
                    "    }\n" +
                    "    float cNoise = sin(tile.x * 0.22 + 0.7) * cos(tile.y * 0.19 - 0.4) + 0.48 * sin(tile.x * 0.49 - tile.y * 0.35);\n" +
                    "    if (cNoise > 0.62 && dot(tile - vec2(0.0, 4.0), tile - vec2(0.0, 4.0)) > 15.0) {\n" +
                    "        gl_Position = vec4(0.0, 0.0, -2.0, 1.0);\n" +
                    "        return;\n" +
                    "    }\n" +
                    "    bool isFlower = (aInst.w >= 100.0);\n" +
                    "    float sway = sin(tile.x * 0.55 + tile.y * 0.45 - uTime * 2.8) * 0.16 * aRibbon.y;\n" +
                    "    float wScale = isFlower ? 0.22 : 0.15;\n" +
                    "    vec3 worldPos = vec3(tile.x, 0.0, tile.y)\n" +
                    "                  + uCamRight * (aRibbon.x * wScale + sway)\n" +
                    "                  + vec3(0.0, aRibbon.y * aInst.z, 0.0);\n" +
                    "    float dPlayer = length(tile - (uPlayerPos.xz + vec2(0.35, 0.25)));\n" +
                    "    float shadow = smoothstep(0.45, 1.35, dPlayer);\n" +
                    "    if (isFlower) {\n" +
                    "        float fType = mod(aInst.w - 100.0, 5.0);\n" +
                    "        vAtlasCell = vec2(3.0 + mod(fType, 3.0), 3.0);\n" +
                    "        vec3 fCol = (fType < 1.5) ? vec3(0.76, 0.60, 0.94)\n" +
                    "                  : (fType < 3.0 ? vec3(0.96, 0.97, 0.92) : vec3(0.66, 0.52, 0.86));\n" +
                    "        vColor = fCol * (0.45 + 0.55 * shadow);\n" +
                    "    } else {\n" +
                    "        vAtlasCell = vec2(mod(aInst.w, 3.0), 3.0);\n" +
                    "        float shade = fract(aInst.w * 0.173);\n" +
                    "        vec3 rootCol = vec3(0.05, 0.14, 0.07);\n" +
                    "        vec3 tipCol = mix(vec3(0.14, 0.42, 0.18), vec3(0.42, 0.72, 0.36), shade);\n" +
                    "        vColor = mix(rootCol, tipCol, aRibbon.y) * (0.28 + 0.72 * shadow);\n" +
                    "    }\n" +
                    "    vUv = aRibbon.zw;\n" +
                    "    float distCam = length(tile - uPlayerPos.xz);\n" +
                    "    vFog = clamp((distCam - 11.0) / 18.0, 0.0, 0.55);\n" +
                    "    gl_Position = uVP * vec4(worldPos, 1.0);\n" +
                    "}\n";

            String fsGrass =
                    "#version 300 es\n" +
                    "precision mediump float;\n" +
                    "in vec2 vUv;\n" +
                    "in vec3 vColor;\n" +
                    "in vec2 vAtlasCell;\n" +
                    "in float vFog;\n" +
                    "uniform sampler2D uAtlas;\n" +
                    "out vec4 fragColor;\n" +
                    "void main() {\n" +
                    "    vec2 atlasUv = (vAtlasCell + vUv) / vec2(16.0, 6.0);\n" +
                    "    float a = texture(uAtlas, atlasUv).a;\n" +
                    "    if (a < 0.22) discard;\n" +
                    "    vec3 col = mix(vColor, vec3(0.62, 0.69, 0.71), vFog);\n" +
                    "    fragColor = vec4(col, a);\n" +
                    "}\n";

            // 3. Normal-Mapped 3D Water & Planar ASCII Reflection Shader (Matching 1000461483.jpg & 1000461484.jpg!)
            String vsWater =
                    "#version 300 es\n" +
                    "layout(location = 0) in vec3 aPos;\n" +
                    "uniform mat4 uMVP;\n" +
                    "uniform mat4 uModel;\n" +
                    "out vec3 vWorldPos;\n" +
                    "out vec4 vClipPos;\n" +
                    "void main() {\n" +
                    "    vec4 wp = uModel * vec4(aPos, 1.0);\n" +
                    "    vWorldPos = wp.xyz;\n" +
                    "    vClipPos = uMVP * vec4(aPos, 1.0);\n" +
                    "    gl_Position = vClipPos;\n" +
                    "}\n";

            String fsWater =
                    "#version 300 es\n" +
                    "precision mediump float;\n" +
                    "in vec3 vWorldPos;\n" +
                    "in vec4 vClipPos;\n" +
                    "uniform sampler2D uAtlas;\n" +
                    "uniform sampler2D uReflectTex;\n" +
                    "uniform float uTime;\n" +
                    "out vec4 fragColor;\n" +
                    "void main() {\n" +
                    "    vec2 p = vWorldPos.xz;\n" +
                    "    float w1 = sin(p.x * 1.4 + p.y * 0.9 - uTime * 2.6);\n" +
                    "    float w2 = cos(p.x * 0.8 - p.y * 1.7 + uTime * 1.9);\n" +
                    "    float w3 = sin((p.x + p.y) * 2.3 - uTime * 3.4);\n" +
                    "    vec3 N = normalize(vec3(w1 * 0.25 + w3 * 0.15, 1.0, w2 * 0.25 - w3 * 0.15));\n" +
                    "    vec3 L = normalize(vec3(-0.45, 0.65, 0.60));\n" +
                    "    float spec = pow(max(0.0, dot(N, L)), 14.0);\n" +
                    "    vec2 ndc = (vClipPos.xy / max(0.001, vClipPos.w)) * 0.5 + 0.5;\n" +
                    "    vec2 reflUv = clamp(vec2(ndc.x, 1.0 - ndc.y) + N.xz * 0.035, 0.01, 0.99);\n" +
                    "    vec3 reflCol = texture(uReflectTex, reflUv).rgb;\n" +
                    "    vec2 cellUv = fract(p * 3.8);\n" +
                    "    float glyphIdx = floor(clamp((spec * 1.6 + length(reflCol) * 0.5), 0.0, 0.99) * 15.0);\n" +
                    "    vec2 atlasUv = (vec2(glyphIdx, 5.0) + cellUv) / vec2(16.0, 6.0);\n" +
                    "    float gMask = texture(uAtlas, atlasUv).a;\n" +
                    "    vec3 deepWater = vec3(0.024, 0.038, 0.062);\n" +
                    "    vec3 streakCol = vec3(0.78, 0.86, 0.96) * gMask * smoothstep(0.32, 0.88, spec + w1 * 0.25);\n" +
                    "    vec3 col = deepWater + reflCol * (0.45 + 0.35 * gMask) + streakCol;\n" +
                    "    fragColor = vec4(col, 0.94);\n" +
                    "}\n";

            mProgMeshAscii = linkProgram(vsMesh, fsMesh);
            mProgGrassInstanced = linkProgram(vsGrass, fsGrass);
            mProgWaterAscii = linkProgram(vsWater, fsWater);
        }

        private int linkProgram(String vsSrc, String fsSrc) {
            int vs = GLES30.glCreateShader(GLES30.GL_VERTEX_SHADER);
            GLES30.glShaderSource(vs, vsSrc);
            GLES30.glCompileShader(vs);

            int fs = GLES30.glCreateShader(GLES30.GL_FRAGMENT_SHADER);
            GLES30.glShaderSource(fs, fsSrc);
            GLES30.glCompileShader(fs);

            int prog = GLES30.glCreateProgram();
            GLES30.glAttachShader(prog, vs);
            GLES30.glAttachShader(prog, fs);
            GLES30.glLinkProgram(prog);
            return prog;
        }

        // ---------------------------------------------------------------------
        // RENDER 3D OPEN WORLD (REFLECTION PASS + MAIN 3D SCENE PASS)
        // ---------------------------------------------------------------------
        private void render3DOpenWorldScene() {
            float aspect = mWidth / (float) mHeight;
            Matrix.perspectiveM(mProjMatrix, 0, 42.0f / mState.cameraZoom, aspect, 0.5f, 90.0f);

            // Cursor-View camera offset (matching "Fog testing + Cursor view"!)
            float cursorOffX = mState.cursorViewMode ? (mState.cursorX - 0.5f) * 3.2f : 0.0f;
            float cursorOffZ = mState.cursorViewMode ? (mState.cursorY - 0.5f) * 3.2f : 0.0f;
            float targetX = mState.playerX + cursorOffX;
            float targetZ = mState.playerZ + cursorOffZ;

            float camDist = 10.2f / mState.cameraZoom;
            float camHeight = 9.4f / mState.cameraZoom;
            float eyeX = targetX + (float) Math.sin(mState.camYaw) * camDist;
            float eyeY = camHeight;
            float eyeZ = targetZ + (float) Math.cos(mState.camYaw) * camDist;

            // 1. Planar Water Reflection FBO Pass (renders inverted 3D world into mReflectTex!)
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, mReflectFbo);
            GLES30.glViewport(0, 0, REFLECT_W, REFLECT_H);
            GLES30.glClearColor(0.02f, 0.03f, 0.045f, 1.0f);
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT | GLES30.GL_DEPTH_BUFFER_BIT);

            Matrix.setLookAtM(mReflectViewMatrix, 0,
                    eyeX, -eyeY * 0.65f, eyeZ,
                    targetX, 0.0f, targetZ,
                    0f, 1f, 0f);
            Matrix.multiplyMM(mReflectVpMatrix, 0, mProjMatrix, 0, mReflectViewMatrix, 0);
            draw3DEntitiesAndCliffs(mReflectVpMatrix, eyeX, -eyeY * 0.65f, eyeZ, true);

            // 2. Main Screen Pass
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
            GLES30.glViewport(0, 0, mWidth, mHeight);
            boolean inCave = mState.isInsideCave(mState.playerX, mState.playerZ);
            if (inCave) {
                GLES30.glClearColor(0.012f, 0.016f, 0.024f, 1.0f);
            } else {
                GLES30.glClearColor(0.025f, 0.042f, 0.038f, 1.0f);
            }
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT | GLES30.GL_DEPTH_BUFFER_BIT);

            Matrix.setLookAtM(mViewMatrix, 0,
                    eyeX, eyeY, eyeZ,
                    targetX, 0.35f, targetZ,
                    0f, 1f, 0f);
            Matrix.multiplyMM(mVpMatrix, 0, mProjMatrix, 0, mViewMatrix, 0);

            // 2a. Ground 0Q8B Matrix Plane
            drawGroundMatrixPlane(mVpMatrix, eyeX, eyeY, eyeZ);

            // 2b. Normal-Mapped 3D River Water Surface with Real-Time Planar Reflections
            drawWaterSurface(mVpMatrix);

            // 2c. 3D Sculpted ASCII Cliffs, Trees, 3D Humanoid Player, 3D Enemies & Loot
            draw3DEntitiesAndCliffs(mVpMatrix, eyeX, eyeY, eyeZ, false);

            // 2d. GPU-Instanced 3D ASCII Grass & Moonlit Lavender Flowers (24,000 instances in 1 draw call!)
            drawInstanced3DGrass(mVpMatrix, eyeX, eyeZ);
        }

        private void drawGroundMatrixPlane(float[] vp, float eyeX, float eyeY, float eyeZ) {
            GLES30.glUseProgram(mProgMeshAscii);
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, mGlyphAtlasTex);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgMeshAscii, "uAtlas"), 0);
            GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uCamPos"), eyeX, eyeY, eyeZ);
            GLES30.glUniform1f(GLES30.glGetUniformLocation(mProgMeshAscii, "uCellScale"), 1.6f);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgMeshAscii, "uMaterialMode"), 2);
            GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uBaseColor"), 0.32f, 0.42f, 0.50f);

            Matrix.setIdentityM(mModelMatrix, 0);
            Matrix.translateM(mModelMatrix, 0, mState.playerX, -0.02f, mState.playerZ);
            Matrix.scaleM(mModelMatrix, 0, 32.0f, 1.0f, 32.0f);
            Matrix.multiplyMM(mMvpMatrix, 0, vp, 0, mModelMatrix, 0);

            GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(mProgMeshAscii, "uMVP"), 1, false, mMvpMatrix, 0);
            GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(mProgMeshAscii, "uModel"), 1, false, mModelMatrix, 0);

            bindAndDrawQuad();
        }

        private void drawWaterSurface(float[] vp) {
            GLES30.glUseProgram(mProgWaterAscii);
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, mGlyphAtlasTex);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgWaterAscii, "uAtlas"), 0);

            GLES30.glActiveTexture(GLES30.GL_TEXTURE1);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, mReflectTex);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgWaterAscii, "uReflectTex"), 1);
            GLES30.glUniform1f(GLES30.glGetUniformLocation(mProgWaterAscii, "uTime"), mState.timeSec);

            for (int seg = -4; seg <= 4; seg++) {
                float wx = mState.playerX + seg * 6.0f;
                float wz = mState.riverCenterZ(wx);
                Matrix.setIdentityM(mModelMatrix, 0);
                Matrix.translateM(mModelMatrix, 0, wx, 0.02f, wz);
                Matrix.scaleM(mModelMatrix, 0, 3.2f, 1.0f, 2.75f);
                Matrix.multiplyMM(mMvpMatrix, 0, vp, 0, mModelMatrix, 0);

                GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(mProgWaterAscii, "uMVP"), 1, false, mMvpMatrix, 0);
                GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(mProgWaterAscii, "uModel"), 1, false, mModelMatrix, 0);
                bindAndDrawQuad();
            }
        }

        private void bindAndDrawQuad() {
            mQuadVerts.position(0);
            GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 32, mQuadVerts);
            GLES30.glEnableVertexAttribArray(0);
            mQuadVerts.position(3);
            GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 32, mQuadVerts);
            GLES30.glEnableVertexAttribArray(1);
            mQuadVerts.position(6);
            GLES30.glVertexAttribPointer(2, 2, GLES30.GL_FLOAT, false, 32, mQuadVerts);
            GLES30.glEnableVertexAttribArray(2);
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 6);
        }

        private void draw3DEntitiesAndCliffs(float[] vp, float eyeX, float eyeY, float eyeZ, boolean reflectionPass) {
            GLES30.glUseProgram(mProgMeshAscii);
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, mGlyphAtlasTex);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgMeshAscii, "uAtlas"), 0);
            GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uCamPos"), eyeX, eyeY, eyeZ);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgMeshAscii, "uMaterialMode"), 0);

            mUnitSphereVerts.position(0);
            GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 32, mUnitSphereVerts);
            GLES30.glEnableVertexAttribArray(0);
            mUnitSphereVerts.position(3);
            GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 32, mUnitSphereVerts);
            GLES30.glEnableVertexAttribArray(1);
            mUnitSphereVerts.position(6);
            GLES30.glVertexAttribPointer(2, 2, GLES30.GL_FLOAT, false, 32, mUnitSphereVerts);
            GLES30.glEnableVertexAttribArray(2);

            // 1. 3D Sculpted ASCII Cliffs & Moonlit Cave Walls
            GLES30.glUniform1f(GLES30.glGetUniformLocation(mProgMeshAscii, "uCellScale"), 18.0f);
            GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uBaseColor"), 0.82f, 0.86f, 0.92f);
            for (int i = 0; i < NUM_CLIFF_PILLARS; i++) {
                float dx = mPillarX[i] - mState.playerX;
                float dz = mPillarZ[i] - mState.playerZ;
                if (dx * dx + dz * dz > 28.0f * 28.0f) continue;
                drawSpherePart(vp, mPillarX[i], mPillarY[i], mPillarZ[i], 0f, mPillarSx[i], mPillarSy[i], mPillarSz[i]);
            }

            // 2. 22-Part Articulated 3D Medieval Adventurer (Exact Reference Silhouette & Proportions!)
            float spd = (float) Math.sqrt(mState.velX * mState.velX + mState.velZ * mState.velZ);
            drawArticulated3DHumanoid(vp, mState.playerX, mState.playerY, mState.playerZ, mState.bodyYaw,
                    mState.gaitPhase, Math.min(1.2f, spd / 4.0f), mState.slashTimer / 0.28f,
                    mState.dodgeTimer > 0.0f, mState.playerY > 0.05f, mState.turnVel,
                    mState.slotMetal, mState.mounted, mState.hurtFlash > 0.0f, true);

            // 3. 22-Part Articulated 3D Humanoid Enemies
            for (int i = 0; i < GameState.NUM_ENEMIES; i++) {
                float dx = mState.enemyX[i] - mState.playerX;
                float dz = mState.enemyZ[i] - mState.playerZ;
                if (dx * dx + dz * dz > 24.0f * 24.0f) continue;
                float eMove = (mState.enemyAggro[i] && mState.enemyWindup[i] <= 0.0f) ? 0.85f : 0.0f;
                int eMet = mState.enemyMetal[i];
                int[] eSlots = new int[]{eMet, eMet, eMet, eMet, eMet, eMet};
                drawArticulated3DHumanoid(vp, mState.enemyX[i], 0.0f, mState.enemyZ[i], mState.enemyYaw[i],
                        mState.enemyGait[i], eMove, mState.enemyWindup[i] / 0.42f,
                        false, false, 0.0f, eSlots, false, mState.enemyHurt[i] > 0.0f, false);
            }

            // 4. 3D Glowing Loot Crystals
            if (!reflectionPass) {
                GLES30.glUniform1f(GLES30.glGetUniformLocation(mProgMeshAscii, "uCellScale"), 10.0f);
                for (int l = 0; l < GameState.MAX_LOOT; l++) {
                    if (mState.lootActive[l]) {
                        float[] rgb = GameState.METAL_RGB[mState.lootMetal[l]];
                        GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uBaseColor"), rgb[0], rgb[1], rgb[2]);
                        float bob = 0.35f + (float) Math.sin(mState.timeSec * 3.5f + l) * 0.12f;
                        drawSpherePart(vp, mState.lootX[l], bob, mState.lootZ[l], mState.timeSec * 90f, 0.45f, 0.65f, 0.45f);
                    }
                }
            }
        }

        private void drawArticulated3DHumanoid(
                float[] vp, float wx, float wy, float wz, float yawRad,
                float gait, float moveAmt, float slashProg, boolean dodging,
                boolean jumping, float turnVel, int[] slotMetals, boolean mounted,
                boolean hurtFlash, boolean isPlayer
        ) {
            // Switch to Dark-Armored 3D Adventurer Surface-Contour ASCII Shader (MaterialMode 3)
            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgMeshAscii, "uMaterialMode"), 3);
            GLES30.glUniform1f(GLES30.glGetUniformLocation(mProgMeshAscii, "uCellScale"), isPlayer ? 6.5f : 7.5f);

            float scale = isPlayer ? 1.38f : 1.22f;
            float yawDeg = (float) Math.toDegrees(yawRad);
            float sinY = (float) Math.sin(yawRad);
            float cosY = (float) Math.cos(yawRad);
            float rightX = cosY;
            float rightZ = -sinY;

            // Idle breathing + Walk/Run bounce + Dodge crouch
            float breathe = (float) Math.sin(mState.timeSec * 2.6f) * 0.032f;
            float strideBounce = (float) Math.abs(Math.sin(gait)) * 0.12f * moveAmt;
            float crouch = dodging ? 0.28f : 0.0f;
            float mountOffset = mounted ? 0.85f : 0.0f;
            float baseH = wy + mountOffset - crouch;

            // 0. 3D Ground Shadow Blob underneath character (cast to bottom-right like 6df93fa4.jpeg!)
            GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uBaseColor"), 0.02f, 0.03f, 0.03f);
            drawSpherePart(vp, wx + 0.28f * scale, 0.02f, wz + 0.18f * scale, yawDeg,
                    0.85f * scale, 0.04f, 0.65f * scale);

            // Optional 3D ASCII Steed underneath rider
            if (mounted) {
                GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uBaseColor"), 0.88f, 0.92f, 0.96f);
                drawSpherePart(vp, wx, wy + 0.72f + strideBounce, wz, yawDeg, 0.72f, 0.62f, 1.55f);
                drawSpherePart(vp, wx + sinY * 0.72f, wy + 1.18f + strideBounce, wz + cosY * 0.72f, yawDeg, 0.44f, 0.68f, 0.50f);
                for (int leg = 0; leg < 4; leg++) {
                    float lx = (leg % 2 == 0 ? -0.28f : 0.28f);
                    float lz = (leg < 2 ? 0.52f : -0.52f);
                    float sw = (float) Math.sin(gait + leg * 1.57f) * 0.34f * moveAmt;
                    drawSpherePart(vp,
                            wx + rightX * lx + sinY * (lz + sw),
                            wy + 0.36f,
                            wz + rightZ * lx + cosY * (lz + sw),
                            yawDeg, 0.22f, 0.72f, 0.22f);
                }
            }

            // 1. Articulated Thighs, Knees, Greaves/Shins & Armored Sabatons/Boots (Slots 4 & 5)
            float legGeoBonus = 1.0f + (slotMetals[4] % 3) * 0.08f;
            float bootGeoBonus = 1.0f + (slotMetals[5] % 3) * 0.10f;
            for (int leg = 0; leg < 2; leg++) {
                float side = (leg == 0 ? -0.19f : 0.19f) * scale;
                float ph = gait + (leg == 1 ? (float) Math.PI : 0.0f);
                float hipSwing = jumping ? (leg == 0 ? 0.25f : -0.18f) : ((float) Math.sin(ph) * 0.38f * moveAmt);
                float kneeLift = jumping ? 0.24f : (Math.max(0.0f, (float) Math.cos(ph)) * 0.22f * moveAmt);

                // Thigh (Cuisse)
                setPartColor(slotMetals[4], hurtFlash);
                float tx = wx + rightX * side + sinY * (hipSwing * 0.45f) * scale;
                float ty = baseH + (0.66f + kneeLift * 0.35f) * scale;
                float tz = wz + rightZ * side + cosY * (hipSwing * 0.45f) * scale;
                drawSpherePart(vp, tx, ty, tz, yawDeg, 0.22f * scale * legGeoBonus, 0.38f * scale, 0.24f * scale * legGeoBonus);

                // Knee Poleyn (bright joint highlight)
                float kx = wx + rightX * side + sinY * (hipSwing * 0.80f) * scale;
                float ky = baseH + (0.46f + kneeLift * 0.70f) * scale;
                float kz = wz + rightZ * side + cosY * (hipSwing * 0.80f) * scale;
                drawSpherePart(vp, kx, ky, kz, yawDeg, 0.18f * scale, 0.18f * scale, 0.20f * scale);

                // Lower Shin / Greave
                float sx = wx + rightX * side + sinY * (hipSwing * 0.92f) * scale;
                float sy = baseH + (0.28f + kneeLift * 0.85f) * scale;
                float sz = wz + rightZ * side + cosY * (hipSwing * 0.92f) * scale;
                drawSpherePart(vp, sx, sy, sz, yawDeg, 0.18f * scale * legGeoBonus, 0.34f * scale, 0.20f * scale * legGeoBonus);

                // Sabaton / Boot (Slot 5)
                setPartColor(slotMetals[5], hurtFlash);
                float bx = sx + sinY * 0.08f * scale;
                float by = baseH + (0.10f + kneeLift) * scale;
                float bz = sz + cosY * 0.08f * scale;
                drawSpherePart(vp, bx, by, bz, yawDeg, 0.20f * scale * bootGeoBonus, 0.16f * scale, 0.32f * scale * bootGeoBonus);
            }

            // 2. Armored Pelvis / Fauld & Waist Belt
            float pelvisY = baseH + (0.86f + strideBounce * 0.6f) * scale;
            setPartColor(slotMetals[4], hurtFlash);
            drawSpherePart(vp, wx, pelvisY, wz, yawDeg, 0.42f * scale, 0.24f * scale, 0.32f * scale);

            // 3. Sculpted Abdomen & Upper Ribcage Cuirass (Slot 2 — equipment metal changes silhouette!)
            float chestGeoBonus = 1.0f + (slotMetals[2] % 3) * 0.09f;
            float leanFwd = (moveAmt * 0.12f + (dodging ? 0.26f : 0.0f)) * scale;
            float torsoX = wx + sinY * leanFwd;
            float torsoZ = wz + cosY * leanFwd;
            float abdomenY = pelvisY + 0.20f * scale;
            float chestY = pelvisY + (0.42f + breathe) * scale;
            float slashTwistDeg = (slashProg > 0.0f) ? ((0.5f - slashProg) * 42.0f) : (turnVel * 18.0f);

            setPartColor(slotMetals[2], hurtFlash);
            drawSpherePart(vp, torsoX * 0.5f + wx * 0.5f, abdomenY, torsoZ * 0.5f + wz * 0.5f,
                    yawDeg + slashTwistDeg * 0.5f, 0.38f * scale, 0.28f * scale, 0.30f * scale);
            drawSpherePart(vp, torsoX, chestY, torsoZ,
                    yawDeg + slashTwistDeg, 0.50f * scale * chestGeoBonus, 0.38f * scale, 0.38f * scale * chestGeoBonus);

            // 4. Flowing Dark Traveler Cloak / Backpack Silhouette on Left/Back (Exact match to `Senje` in `6df93fa4.jpeg`!)
            GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uBaseColor"), 0.36f, 0.40f, 0.44f);
            float cloakSway = (float) Math.sin(gait * 0.5f + mState.timeSec * 2.2f) * 0.08f * (0.4f + moveAmt);
            float packX = torsoX - sinY * 0.20f * scale - rightX * 0.14f * scale;
            float packZ = torsoZ - cosY * 0.20f * scale - rightZ * 0.14f * scale;
            drawSpherePart(vp, packX, chestY - 0.04f * scale, packZ, yawDeg, 0.44f * scale, 0.52f * scale, 0.34f * scale);
            drawSpherePart(vp, packX - sinY * (0.10f + cloakSway) * scale, pelvisY - 0.08f * scale,
                    packZ - cosY * (0.10f + cloakSway) * scale, yawDeg, 0.48f * scale, 0.56f * scale, 0.24f * scale);

            // 5. Layered Pauldrons / Shoulder Armor (Slot 1 — tiered size by metal!)
            setPartColor(slotMetals[1], hurtFlash);
            float shldrSpan = (0.34f + (slotMetals[1] % 3) * 0.04f) * scale;
            float shldrRadius = (0.24f + (slotMetals[1] % 4) * 0.03f) * scale;
            for (int s = -1; s <= 1; s += 2) {
                float sx = torsoX + rightX * (s * shldrSpan);
                float sz = torsoZ + rightZ * (s * shldrSpan);
                drawSpherePart(vp, sx, chestY + 0.12f * scale, sz, yawDeg + slashTwistDeg,
                        shldrRadius, shldrRadius * 0.92f, shldrRadius);
            }

            // 6. Neck Gorget & Articulated Helmet / Hooded Barbute (Slot 0 — changes shape per helm metal!)
            setPartColor(slotMetals[0], hurtFlash);
            float headX = torsoX + sinY * 0.04f * scale;
            float headY = chestY + 0.34f * scale;
            float headZ = torsoZ + cosY * 0.04f * scale;
            drawSpherePart(vp, headX, chestY + 0.21f * scale, headZ, yawDeg, 0.20f * scale, 0.14f * scale, 0.20f * scale);
            drawSpherePart(vp, headX, headY, headZ, yawDeg, 0.30f * scale, 0.34f * scale, 0.32f * scale);
            // Helm Crest / Visor Ridge (bright horizontal visor highlight like `6df93fa4.jpeg`!)
            GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uBaseColor"), 0.95f, 0.98f, 1.0f);
            float crestH = (0.08f + (slotMetals[0] % 3) * 0.04f) * scale;
            drawSpherePart(vp, headX + sinY * 0.11f * scale, headY + 0.05f * scale, headZ + cosY * 0.11f * scale,
                    yawDeg, 0.26f * scale, crestH, 0.18f * scale);

            // 7. Left Upper Arm, Forearm & Shield/Vambrace (Slot 3)
            setPartColor(slotMetals[3], hurtFlash);
            float armSwing = (float) Math.sin(gait) * 0.28f * moveAmt;
            float lShX = torsoX - rightX * shldrSpan;
            float lShZ = torsoZ - rightZ * shldrSpan;
            float lElbX = lShX - rightX * 0.08f * scale - sinY * (armSwing * 0.5f) * scale;
            float lElbY = chestY - 0.10f * scale;
            float lElbZ = lShZ - rightZ * 0.08f * scale - cosY * (armSwing * 0.5f) * scale;
            drawSpherePart(vp, lElbX, lElbY, lElbZ, yawDeg, 0.18f * scale, 0.32f * scale, 0.18f * scale);
            float lHandX = lElbX + sinY * (0.14f - armSwing * 0.8f) * scale;
            float lHandY = lElbY - 0.22f * scale;
            float lHandZ = lElbZ + cosY * (0.14f - armSwing * 0.8f) * scale;
            drawSpherePart(vp, lHandX, lHandY, lHandZ, yawDeg, 0.17f * scale, 0.28f * scale, 0.20f * scale);

            // 8. Right Upper Arm, Forearm, Gauntlet & Extended Sword/Rapier (angled down-right like `6df93fa4.jpeg`!)
            float rShX = torsoX + rightX * shldrSpan;
            float rShZ = torsoZ + rightZ * shldrSpan;
            float slashAng = (slashProg > 0.0f) ? (-1.55f + (1.0f - slashProg) * 3.1f) : (0.52f + armSwing * 0.45f);
            float swordDirX = (float) Math.sin(yawRad + slashAng);
            float swordDirZ = (float) Math.cos(yawRad + slashAng);

            float rElbX = rShX + rightX * 0.08f * scale + swordDirX * 0.16f * scale;
            float rElbY = chestY - 0.08f * scale;
            float rElbZ = rShZ + rightZ * 0.08f * scale + swordDirZ * 0.16f * scale;
            drawSpherePart(vp, rElbX, rElbY, rElbZ, yawDeg, 0.18f * scale, 0.32f * scale, 0.18f * scale);

            float rHandX = rElbX + swordDirX * 0.22f * scale;
            float rHandY = rElbY - 0.18f * scale;
            float rHandZ = rElbZ + swordDirZ * 0.22f * scale;
            drawSpherePart(vp, rHandX, rHandY, rHandZ, yawDeg, 0.17f * scale, 0.24f * scale, 0.17f * scale);

            // 9. Crossguard & Gleaming 3D Blade extending out from right hand (Matches `6df93fa4.jpeg`!)
            GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uBaseColor"), 0.96f, 0.99f, 1.0f);
            float swordYawDeg = (float) Math.toDegrees(yawRad + slashAng);
            drawSpherePart(vp, rHandX + swordDirX * 0.10f * scale, rHandY - 0.02f * scale, rHandZ + swordDirZ * 0.10f * scale,
                    swordYawDeg, 0.28f * scale, 0.08f * scale, 0.08f * scale);
            float bladeLen = (0.95f + (slotMetals[3] % 4) * 0.12f) * scale;
            drawSpherePart(vp, rHandX + swordDirX * (bladeLen * 0.55f), rHandY - 0.08f * scale, rHandZ + swordDirZ * (bladeLen * 0.55f),
                    swordYawDeg, 0.09f * scale, 0.09f * scale, bladeLen);

            // Restore MaterialMode 0 for world objects
            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgMeshAscii, "uMaterialMode"), 0);
        }

        private void setPartColor(int metalIdx, boolean hurtFlash) {
            if (hurtFlash) {
                GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uBaseColor"), 1.0f, 0.28f, 0.28f);
            } else {
                float[] rgb = GameState.METAL_RGB[Math.max(0, Math.min(9, metalIdx))];
                GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uBaseColor"), rgb[0], rgb[1], rgb[2]);
            }
        }

        private void drawSpherePart(float[] vp, float x, float y, float z, float yawDeg, float sx, float sy, float sz) {
            Matrix.setIdentityM(mModelMatrix, 0);
            Matrix.translateM(mModelMatrix, 0, x, y, z);
            if (yawDeg != 0.0f) {
                Matrix.rotateM(mModelMatrix, 0, yawDeg, 0f, 1f, 0f);
            }
            Matrix.scaleM(mModelMatrix, 0, sx, sy, sz);
            Matrix.multiplyMM(mMvpMatrix, 0, vp, 0, mModelMatrix, 0);

            GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(mProgMeshAscii, "uMVP"), 1, false, mMvpMatrix, 0);
            GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(mProgMeshAscii, "uModel"), 1, false, mModelMatrix, 0);
            mUnitSphereIndices.position(0);
            GLES30.glDrawElements(GLES30.GL_TRIANGLES, mSphereIndexCount, GLES30.GL_UNSIGNED_SHORT, mUnitSphereIndices);
        }

        private void drawInstanced3DGrass(float[] vp, float eyeX, float eyeZ) {
            GLES30.glUseProgram(mProgGrassInstanced);
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, mGlyphAtlasTex);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgGrassInstanced, "uAtlas"), 0);
            GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(mProgGrassInstanced, "uVP"), 1, false, vp, 0);
            GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgGrassInstanced, "uPlayerPos"), mState.playerX, 0.0f, mState.playerZ);
            GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgGrassInstanced, "uCamRight"),
                    (float) Math.cos(mState.camYaw), 0.0f, -(float) Math.sin(mState.camYaw));
            GLES30.glUniform1f(GLES30.glGetUniformLocation(mProgGrassInstanced, "uTime"), mState.timeSec);

            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, mGrassRibbonVbo);
            GLES30.glEnableVertexAttribArray(0);
            GLES30.glVertexAttribPointer(0, 4, GLES30.GL_FLOAT, false, 16, 0);
            GLES30.glVertexAttribDivisor(0, 0);

            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, mGrassInstanceVbo);
            GLES30.glEnableVertexAttribArray(1);
            GLES30.glVertexAttribPointer(1, 4, GLES30.GL_FLOAT, false, 16, 0);
            GLES30.glVertexAttribDivisor(1, 1);

            int count = (mState.qualityPreset == 0) ? 8000 : (mState.qualityPreset == 1 ? 16000 : MAX_GRASS_INSTANCES);
            GLES30.glDrawArraysInstanced(GLES30.GL_TRIANGLES, 0, 6, count);

            GLES30.glVertexAttribDivisor(1, 0);
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0);
        }

        // ---------------------------------------------------------------------
        // RENDER 3D CHAINMAIL COIF & ARMOR PREVIEW IN EQUIPMENT MENU (1000461485.jpg)
        // ---------------------------------------------------------------------
        private void render3DChainmailEquipmentScene() {
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
            GLES30.glViewport(0, 0, mWidth, mHeight);
            GLES30.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT | GLES30.GL_DEPTH_BUFFER_BIT);

            float aspect = mWidth / (float) mHeight;
            Matrix.perspectiveM(mProjMatrix, 0, 38.0f / mState.previewZoom, aspect, 0.5f, 30.0f);
            Matrix.setLookAtM(mViewMatrix, 0, 0.65f, 0.35f, 4.2f, 0.45f, -0.15f, 0.0f, 0f, 1f, 0f);
            Matrix.multiplyMM(mVpMatrix, 0, mProjMatrix, 0, mViewMatrix, 0);

            GLES30.glUseProgram(mProgMeshAscii);
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, mGlyphAtlasTex);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgMeshAscii, "uAtlas"), 0);
            GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uCamPos"), 0.65f, 0.35f, 4.2f);
            GLES30.glUniform1f(GLES30.glGetUniformLocation(mProgMeshAscii, "uCellScale"), 22.0f);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgMeshAscii, "uMaterialMode"), 1); // Chainmail weave!

            mUnitSphereVerts.position(0);
            GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 32, mUnitSphereVerts);
            GLES30.glEnableVertexAttribArray(0);
            mUnitSphereVerts.position(3);
            GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 32, mUnitSphereVerts);
            GLES30.glEnableVertexAttribArray(1);
            mUnitSphereVerts.position(6);
            GLES30.glVertexAttribPointer(2, 2, GLES30.GL_FLOAT, false, 32, mUnitSphereVerts);
            GLES30.glEnableVertexAttribArray(2);

            setPartColor(mState.activeMetal, false);
            float yawDeg = (float) Math.toDegrees(mState.previewYaw);

            // Sculpted 3D Chainmail Coif Dome + Neck Drape + Shoulders
            drawSpherePart(mVpMatrix, -0.35f, 0.28f, 0.0f, yawDeg, 0.95f, 1.05f, 0.95f);
            drawSpherePart(mVpMatrix, -0.35f, -0.38f, 0.0f, yawDeg, 1.55f, 0.85f, 1.35f);
            drawSpherePart(mVpMatrix, -0.35f, -0.68f, 0.0f, yawDeg, 1.95f, 0.45f, 1.65f);
        }
    }

    // =========================================================================
    // CRISP MONOSPACE HUD, HOTBAR & EQUIPMENT OVERLAY (MATCHING SCREENSHOTS!)
    // =========================================================================
    private static final class HudOverlayView extends View {
        private final GameState mState;
        private final Paint mTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mBoxPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF mRect = new RectF();

        private static final String[] SENJE_PORTRAIT = {
                "  .---.  ",
                "  |===|  ",
                " .|===|. ",
                " ||===|| ",
                " ||===|| ",
                "  || ||  ",
                "  || ||  "
        };

        private int mMovePointerId = -1;
        private int mCamPointerId = -1;
        private float mJoyBaseX = 0f, mJoyBaseY = 0f, mJoyCurrX = 0f, mJoyCurrY = 0f;
        private float mLastCamX = 0f;

        HudOverlayView(Context context, GameState state) {
            super(context);
            mState = state;
            mTextPaint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
            mBoxPaint.setStyle(Paint.Style.FILL);
            mBorderPaint.setStyle(Paint.Style.STROKE);
            mBorderPaint.setStrokeWidth(2.0f);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();

            if (mState.screenMode == 2) {
                drawEquipmentMenuOverlay(canvas, w, h);
            } else {
                drawWorldHudOverlay(canvas, w, h);
            }
            postInvalidateOnAnimation();
        }

        private void drawWorldHudOverlay(Canvas canvas, int w, int h) {
            // 1. Top-Left `Senje` Portrait & Status Box (Exact clone of 1000461482.jpg!)
            float boxW = Math.min(w * 0.38f, 420.0f);
            float boxH = Math.min(h * 0.22f, 138.0f);
            float x0 = 16.0f;
            float y0 = 16.0f;

            mBoxPaint.setColor(Color.argb(235, 6, 8, 9));
            canvas.drawRect(x0, y0, x0 + boxW, y0 + boxH, mBoxPaint);
            mBorderPaint.setColor(Color.rgb(175, 182, 180));
            canvas.drawRect(x0, y0, x0 + boxW, y0 + boxH, mBorderPaint);

            // ASCII Portrait on left
            float pSize = boxH * 0.115f;
            mTextPaint.setTextAlign(Paint.Align.LEFT);
            mTextPaint.setTextSize(pSize);
            mTextPaint.setColor(Color.rgb(205, 212, 210));
            for (int r = 0; r < SENJE_PORTRAIT.length; r++) {
                canvas.drawText(SENJE_PORTRAIT[r], x0 + 10f, y0 + 24f + r * (pSize * 1.05f), mTextPaint);
            }

            float tx = x0 + boxW * 0.24f;
            float titleSize = boxH * 0.17f;
            mTextPaint.setTextSize(titleSize);
            mTextPaint.setColor(Color.rgb(242, 245, 244));
            canvas.drawText(mState.playerName, tx, y0 + titleSize * 1.35f, mTextPaint);

            float barSize = boxH * 0.135f;
            mTextPaint.setTextSize(barSize);
            mTextPaint.setColor(Color.rgb(222, 228, 226));
            canvas.drawText("HP |||||||||||||||||||| " + mState.hp + "/" + mState.maxHp, tx, y0 + titleSize * 2.55f, mTextPaint);
            canvas.drawText("MP |||||||||||||||||||| " + mState.mp + "/" + mState.maxMp, tx, y0 + titleSize * 3.65f, mTextPaint);
            canvas.drawText("LV " + mState.level + "  \u00b7  " + mState.gold + "g", tx, y0 + titleSize * 4.85f, mTextPaint);

            // 2. Cursor-View Crosshair `+` & Player Nameplate in 3D World
            mTextPaint.setTextAlign(Paint.Align.CENTER);
            mTextPaint.setTextSize(15.0f);
            mTextPaint.setColor(Color.rgb(235, 240, 238));
            canvas.drawText(mState.playerName, w * 0.5f, h * 0.41f, mTextPaint);

            if (mState.cursorViewMode) {
                mTextPaint.setTextSize(24.0f);
                mTextPaint.setColor(Color.argb(220, 235, 242, 240));
                canvas.drawText("+", mState.cursorX * w, mState.cursorY * h, mTextPaint);
            }

            // 3. Top-Right Minimalist Monospace Controls: [FORGE / EQUIP], [ZOOM], [STEED], [QUALITY]
            float pillW = Math.min(w * 0.16f, 158.0f);
            float pillH = 34.0f;
            float px = w - pillW - 16.0f;
            String qLabel = mState.qualityPreset == 2 ? "ULTRA" : (mState.qualityPreset == 1 ? "MED" : "LOW");
            String[] pills = {"[EQUIP / FORGE]", "[ZOOM]", mState.mounted ? "[DISMOUNT]" : "[STEED]", "[GFX: " + qLabel + "]"};
            mTextPaint.setTextSize(13.0f);
            for (int i = 0; i < pills.length; i++) {
                float py = y0 + i * (pillH + 6.0f);
                mBoxPaint.setColor(Color.argb(220, 8, 10, 11));
                canvas.drawRect(px, py, px + pillW, py + pillH, mBoxPaint);
                mBorderPaint.setColor(Color.rgb(135, 145, 142));
                canvas.drawRect(px, py, px + pillW, py + pillH, mBorderPaint);
                mTextPaint.setColor(Color.rgb(235, 240, 238));
                canvas.drawText(pills[i], px + pillW * 0.5f, py + pillH * 0.66f, mTextPaint);
            }

            // 4. Bottom XP Bar + 1..0 Numbered Hotbar (Exact clone of 1000461485.jpg!)
            float hbW = Math.min(w * 0.54f, 520.0f);
            float hbX = (w - hbW) * 0.5f;
            float hbY = h - 48.0f;

            mBoxPaint.setColor(Color.argb(230, 8, 10, 11));
            canvas.drawRect(hbX, hbY - 18.0f, hbX + hbW, hbY - 3.0f, mBoxPaint);
            mBorderPaint.setColor(Color.rgb(115, 125, 122));
            canvas.drawRect(hbX, hbY - 18.0f, hbX + hbW, hbY - 3.0f, mBorderPaint);

            float xpRatio = Math.max(0f, Math.min(1f, mState.xp / (float) Math.max(1, mState.xpNext)));
            mBoxPaint.setColor(Color.rgb(205, 165, 78));
            canvas.drawRect(hbX + 2f, hbY - 16.0f, hbX + (hbW - 4f) * xpRatio, hbY - 5.0f, mBoxPaint);

            mTextPaint.setTextSize(11.0f);
            mTextPaint.setColor(Color.rgb(238, 242, 240));
            canvas.drawText("LV " + mState.level + " \u00b7 " + mState.xp + " / " + mState.xpNext + " XP", w * 0.5f, hbY - 6.5f, mTextPaint);

            float slotW = hbW / 10.0f;
            for (int s = 0; s < 10; s++) {
                float sx = hbX + s * slotW;
                mBoxPaint.setColor(Color.argb(235, 6, 8, 9));
                canvas.drawRect(sx, hbY, sx + slotW, hbY + 38.0f, mBoxPaint);
                mBorderPaint.setColor(Color.rgb(105, 115, 112));
                canvas.drawRect(sx, hbY, sx + slotW, hbY + 38.0f, mBorderPaint);
                mTextPaint.setColor(Color.rgb(210, 218, 215));
                canvas.drawText(String.valueOf((s + 1) % 10), sx + slotW * 0.5f, hbY + 13.0f, mTextPaint);
                if (s == 0 && mState.potions > 0) {
                    mTextPaint.setColor(Color.rgb(218, 92, 92));
                    canvas.drawText("HPx" + mState.potions, sx + slotW * 0.5f, hbY + 30.0f, mTextPaint);
                } else {
                    canvas.drawText("\u00b7", sx + slotW * 0.5f, hbY + 28.0f, mTextPaint);
                }
            }

            // 5. Bottom-Right Mobile Action Buttons: [ATK] & [DODGE]
            float atkR = Math.min(w, h) * 0.085f;
            float atkCx = w - atkR - 24.0f;
            float atkCy = h - atkR - 24.0f;
            mBoxPaint.setColor(mState.slashTimer > 0f ? Color.argb(235, 48, 82, 62) : Color.argb(220, 8, 11, 10));
            mBorderPaint.setColor(Color.rgb(195, 208, 202));
            canvas.drawCircle(atkCx, atkCy, atkR, mBoxPaint);
            canvas.drawCircle(atkCx, atkCy, atkR, mBorderPaint);
            mTextPaint.setTextSize(15.0f);
            mTextPaint.setColor(Color.rgb(242, 246, 244));
            canvas.drawText("[ATK]", atkCx, atkCy + 5.0f, mTextPaint);

            float dodgeR = Math.min(w, h) * 0.068f;
            float dodgeCx = atkCx - atkR - dodgeR - 18.0f;
            float dodgeCy = h - dodgeR - 24.0f;
            mBoxPaint.setColor(mState.dodgeTimer > 0f ? Color.argb(235, 36, 82, 88) : Color.argb(220, 8, 11, 12));
            mBorderPaint.setColor(Color.rgb(165, 215, 210));
            canvas.drawCircle(dodgeCx, dodgeCy, dodgeR, mBoxPaint);
            canvas.drawCircle(dodgeCx, dodgeCy, dodgeR, mBorderPaint);
            mTextPaint.setTextSize(13.0f);
            String dTxt = mState.dodgeCooldown > 0f ? (((int) (mState.dodgeCooldown * 10f + 0.9f) / 10f) + "s") : "[DODGE]";
            canvas.drawText(dTxt, dodgeCx, dodgeCy + 4.5f, mTextPaint);

            float jumpR = Math.min(w, h) * 0.062f;
            float jumpCx = atkCx - jumpR * 0.35f;
            float jumpCy = atkCy - atkR - jumpR - 14.0f;
            mBoxPaint.setColor(mState.playerY > 0.02f ? Color.argb(235, 52, 78, 96) : Color.argb(220, 8, 11, 12));
            mBorderPaint.setColor(Color.rgb(185, 215, 235));
            canvas.drawCircle(jumpCx, jumpCy, jumpR, mBoxPaint);
            canvas.drawCircle(jumpCx, jumpCy, jumpR, mBorderPaint);
            mTextPaint.setTextSize(12.5f);
            canvas.drawText("[JUMP]", jumpCx, jumpCy + 4.5f, mTextPaint);

            // Virtual Joystick Ring
            if (mMovePointerId != -1) {
                mBorderPaint.setColor(Color.argb(145, 205, 225, 215));
                canvas.drawCircle(mJoyBaseX, mJoyBaseY, Math.min(w, h) * 0.11f, mBorderPaint);
                canvas.drawCircle(mJoyCurrX, mJoyCurrY, Math.min(w, h) * 0.035f, mBorderPaint);
            }

            if (mState.bannerTimer > 0f) {
                mTextPaint.setTextSize(14.0f);
                mTextPaint.setColor(Color.rgb(235, 232, 195));
                canvas.drawText(mState.statusBanner, w * 0.5f, hbY - 26.0f, mTextPaint);
            }
        }

        private void drawEquipmentMenuOverlay(Canvas canvas, int w, int h) {
            // Exact Dark Minimalist Monospace Equipment & Chainmail Interface (1000461485.jpg!)
            mTextPaint.setTextAlign(Paint.Align.LEFT);
            mTextPaint.setTextSize(14.0f);
            mTextPaint.setColor(Color.rgb(225, 230, 228));
            canvas.drawText(GameState.METAL_SHORT[mState.activeMetal] + " Mail " + GameState.SLOT_NAMES[mState.selectedSlot], 18f, 24f, mTextPaint);

            // Slot Tabs: Helm, Shoulders, Chest, Gloves, Legs, Boots
            float slotW = (w * 0.72f) / 6.0f;
            for (int i = 0; i < 6; i++) {
                float sx = 18f + i * slotW;
                mBoxPaint.setColor(i == mState.selectedSlot ? Color.rgb(32, 38, 28) : Color.rgb(10, 12, 14));
                canvas.drawRect(sx, 34f, sx + slotW - 6f, 64f, mBoxPaint);
                mBorderPaint.setColor(i == mState.selectedSlot ? Color.rgb(210, 205, 138) : Color.rgb(75, 82, 86));
                canvas.drawRect(sx, 34f, sx + slotW - 6f, 64f, mBorderPaint);
                mTextPaint.setTextAlign(Paint.Align.CENTER);
                mTextPaint.setColor(Color.rgb(235, 238, 236));
                canvas.drawText(GameState.SLOT_NAMES[i], sx + (slotW - 6f) * 0.5f, 54f, mTextPaint);
            }

            // Rune Row: ^ * z ~ > / x v o § +
            mTextPaint.setTextAlign(Paint.Align.LEFT);
            mTextPaint.setColor(Color.rgb(155, 165, 162));
            canvas.drawText("- tap a rune to inscribe into enchant slot", 18f, 82f, mTextPaint);
            float rW = (w * 0.66f) / 11.0f;
            for (int i = 0; i < 11; i++) {
                float rx = 18f + i * rW;
                mBoxPaint.setColor(Color.rgb(8, 10, 12));
                canvas.drawRect(rx, 90f, rx + rW - 4f, 124f, mBoxPaint);
                mBorderPaint.setColor(Color.rgb(65, 72, 76));
                canvas.drawRect(rx, 90f, rx + rW - 4f, 124f, mBorderPaint);
                mTextPaint.setTextAlign(Paint.Align.CENTER);
                mTextPaint.setColor(i % 2 == 0 ? Color.rgb(110, 225, 165) : Color.rgb(215, 145, 235));
                canvas.drawText(GameState.RUNE_GLYPHS[i], rx + (rW - 4f) * 0.5f, 112f, mTextPaint);
            }

            // Metal Selector Rows (Iron, Steel, Bronze, Silver, Gold / Moonsteel, Nightglass, Bloodiron, Ossite, Emberstone)
            float mW = (w * 0.72f) / 5.0f;
            for (int i = 0; i < 10; i++) {
                int row = i / 5;
                int col = i % 5;
                float mx = 18f + col * mW;
                float my = 136f + row * 34f;
                mBoxPaint.setColor(i == mState.activeMetal ? Color.rgb(28, 34, 26) : Color.rgb(8, 10, 12));
                canvas.drawRect(mx, my, mx + mW - 6f, my + 28f, mBoxPaint);
                float[] rgb = GameState.METAL_RGB[i];
                int mCol = Color.rgb((int) (rgb[0] * 255), (int) (rgb[1] * 255), (int) (rgb[2] * 255));
                mBorderPaint.setColor(i == mState.activeMetal ? mCol : Color.rgb(62, 68, 72));
                canvas.drawRect(mx, my, mx + mW - 6f, my + 28f, mBorderPaint);
                mTextPaint.setTextAlign(Paint.Align.CENTER);
                mTextPaint.setColor(mCol);
                canvas.drawText(GameState.METAL_NAMES[i], mx + (mW - 6f) * 0.5f, my + 19f, mTextPaint);
            }

            // Right Divider & Enchant Slots Panel
            float divX = w * 0.75f;
            mBorderPaint.setColor(Color.rgb(75, 82, 86));
            canvas.drawLine(divX, 34f, divX, h - 50f, mBorderPaint);

            mTextPaint.setTextAlign(Paint.Align.LEFT);
            mTextPaint.setColor(Color.rgb(185, 195, 192));
            canvas.drawText("Enchant slots", divX + 18f, 60f, mTextPaint);
            for (int e = 0; e < 2; e++) {
                float ex = divX + 18f + e * 64f;
                canvas.drawRect(ex, 72f, ex + 52f, 124f, mBorderPaint);
                int rIdx = (e == 0) ? mState.runeSlot1 : mState.runeSlot2;
                mTextPaint.setTextAlign(Paint.Align.CENTER);
                mTextPaint.setColor(rIdx >= 0 ? Color.rgb(145, 245, 205) : Color.rgb(115, 125, 122));
                canvas.drawText(rIdx >= 0 ? GameState.RUNE_GLYPHS[rIdx] : "+", ex + 26f, 104f, mTextPaint);
            }

            mTextPaint.setTextAlign(Paint.Align.LEFT);
            mTextPaint.setColor(Color.rgb(175, 185, 182));
            canvas.drawText("Metal: " + GameState.METAL_SHORT[mState.activeMetal], divX + 18f, 152f, mTextPaint);
            int rCount = (mState.runeSlot1 >= 0 ? 1 : 0) + (mState.runeSlot2 >= 0 ? 1 : 0);
            canvas.drawText("Runes: " + rCount + " / 2", divX + 18f, 174f, mTextPaint);
            canvas.drawText("Quest: " + mState.questKills + "/" + mState.questTarget + " Wardens", divX + 18f, 204f, mTextPaint);

            // Return to 3D World Button
            mBoxPaint.setColor(Color.rgb(22, 42, 32));
            canvas.drawRect(divX + 18f, h - 76f, w - 18f, h - 24f, mBoxPaint);
            mBorderPaint.setColor(Color.rgb(165, 225, 185));
            canvas.drawRect(divX + 18f, h - 76f, w - 18f, h - 24f, mBorderPaint);
            mTextPaint.setTextAlign(Paint.Align.CENTER);
            mTextPaint.setColor(Color.rgb(238, 245, 240));
            canvas.drawText("[ RETURN TO WORLD ]", (divX + w) * 0.5f, h - 44f, mTextPaint);

            mTextPaint.setTextAlign(Paint.Align.LEFT);
            mTextPaint.setColor(Color.rgb(145, 155, 152));
            canvas.drawText("drag center to turn 3D ASCII coif \u00b7 tap metal or rune to forge", 18f, h - 18f, mTextPaint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            int action = event.getActionMasked();
            int idx = event.getActionIndex();
            int pId = event.getPointerId(idx);
            float x = event.getX(idx);
            float y = event.getY(idx);
            float w = Math.max(1f, getWidth());
            float h = Math.max(1f, getHeight());

            if (mState.screenMode == 2) {
                if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                    if (x > w * 0.75f && y > h - 84f) {
                        mState.screenMode = 1;
                        return true;
                    }
                    if (y >= 34f && y <= 64f && x < w * 0.73f) {
                        int s = (int) ((x - 18f) / ((w * 0.72f) / 6.0f));
                        if (s >= 0 && s < 6) {
                            mState.selectedSlot = s;
                            mState.activeMetal = mState.slotMetal[s];
                        }
                        return true;
                    }
                    if (y >= 90f && y <= 124f && x < w * 0.68f) {
                        int r = (int) ((x - 18f) / ((w * 0.66f) / 11.0f));
                        if (r >= 0 && r < 11) {
                            if (mState.runeSlot1 == -1) mState.runeSlot1 = r;
                            else if (mState.runeSlot2 == -1) mState.runeSlot2 = r;
                            else { mState.runeSlot1 = r; mState.runeSlot2 = -1; }
                            mState.str += 2;
                        }
                        return true;
                    }
                    if (y >= 136f && y <= 204f && x < w * 0.73f) {
                        int col = (int) ((x - 18f) / ((w * 0.72f) / 5.0f));
                        int row = (y >= 170f) ? 1 : 0;
                        int m = row * 5 + Math.max(0, Math.min(4, col));
                        mState.activeMetal = m;
                        mState.slotMetal[mState.selectedSlot] = m;
                        return true;
                    }
                    mLastCamX = x;
                } else if (action == MotionEvent.ACTION_MOVE) {
                    mState.previewYaw += (x - mLastCamX) * 0.01f;
                    mLastCamX = x;
                }
                return true;
            }

            // World Mode Controls
            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                float pillW = Math.min(w * 0.16f, 158.0f);
                float pillH = 34.0f;
                float px = w - pillW - 16.0f;
                float y0 = 16.0f;

                if (x >= px && x <= px + pillW && y <= y0 + 4 * (pillH + 6f)) {
                    int btn = (int) ((y - y0) / (pillH + 6f));
                    if (btn == 0) {
                        mMovePointerId = -1;
                        mState.inputX = 0f;
                        mState.inputZ = 0f;
                        mState.screenMode = 2;
                    } else if (btn == 1) {
                        mState.zoomPreset = (mState.zoomPreset + 1) % 3;
                        mState.cameraZoom = (mState.zoomPreset == 0) ? 1.35f : (mState.zoomPreset == 1 ? 1.0f : 0.75f);
                    } else if (btn == 2) {
                        mState.mounted = !mState.mounted;
                    } else if (btn == 3) {
                        mState.qualityPreset = (mState.qualityPreset + 1) % 3;
                    }
                    return true;
                }

                // Tap Senje Portrait Box -> Open 3D Equipment & Chainmail Forge
                if (x < w * 0.38f && y < h * 0.24f) {
                    mMovePointerId = -1;
                    mState.inputX = 0f;
                    mState.inputZ = 0f;
                    mState.screenMode = 2;
                    return true;
                }

                // Bottom Hotbar Slot 1 -> Drink Potion
                float hbW = Math.min(w * 0.54f, 520.0f);
                float hbX = (w - hbW) * 0.5f;
                float hbY = h - 48.0f;
                if (y >= hbY && x >= hbX && x <= hbX + hbW) {
                    int s = (int) ((x - hbX) / (hbW / 10.0f));
                    if (s == 0 && mState.potions > 0) {
                        mState.potions--;
                        mState.hp = Math.min(mState.maxHp, mState.hp + 450);
                        mState.mp = Math.min(mState.maxMp, mState.mp + 60);
                        mState.statusBanner = "Restored +450 HP, +60 MP";
                        mState.bannerTimer = 2.0f;
                    }
                    return true;
                }

                // Bottom-Right [ATK] & [DODGE]
                float atkR = Math.min(w, h) * 0.085f;
                float atkCx = w - atkR - 24.0f;
                float atkCy = h - atkR - 24.0f;
                if ((x - atkCx) * (x - atkCx) + (y - atkCy) * (y - atkCy) <= (atkR * 1.25f) * (atkR * 1.25f)) {
                    mState.triggerSlash();
                    return true;
                }

                float dodgeR = Math.min(w, h) * 0.068f;
                float dodgeCx = atkCx - atkR - dodgeR - 18.0f;
                float dodgeCy = h - dodgeR - 24.0f;
                if ((x - dodgeCx) * (x - dodgeCx) + (y - dodgeCy) * (y - dodgeCy) <= (dodgeR * 1.25f) * (dodgeR * 1.25f)) {
                    mState.triggerDodge();
                    return true;
                }

                float jumpR = Math.min(w, h) * 0.062f;
                float jumpCx = atkCx - jumpR * 0.35f;
                float jumpCy = atkCy - atkR - jumpR - 14.0f;
                if ((x - jumpCx) * (x - jumpCx) + (y - jumpCy) * (y - jumpCy) <= (jumpR * 1.25f) * (jumpR * 1.25f)) {
                    mState.triggerJump();
                    return true;
                }

                // Left Half -> Virtual Movement Joystick; Right Half -> Cursor-View & Camera Orbit
                if (x < w * 0.48f) {
                    mMovePointerId = pId;
                    mJoyBaseX = mJoyCurrX = x;
                    mJoyBaseY = mJoyCurrY = y;
                    mState.inputX = 0f;
                    mState.inputZ = 0f;
                } else {
                    mCamPointerId = pId;
                    mLastCamX = x;
                    mState.cursorX = x / w;
                    mState.cursorY = y / h;
                }
            } else if (action == MotionEvent.ACTION_MOVE) {
                int count = event.getPointerCount();
                for (int i = 0; i < count; i++) {
                    int id = event.getPointerId(i);
                    float px = event.getX(i);
                    float py = event.getY(i);
                    if (id == mMovePointerId) {
                        mJoyCurrX = px;
                        mJoyCurrY = py;
                        float dx = px - mJoyBaseX;
                        float dy = py - mJoyBaseY;
                        float maxR = Math.min(w, h) * 0.12f;
                        float len = (float) Math.sqrt(dx * dx + dy * dy);
                        if (len > 4f) {
                            float mag = Math.min(1f, len / maxR);
                            mState.inputX = (dx / len) * mag;
                            mState.inputZ = (dy / len) * mag;
                        } else {
                            mState.inputX = 0f;
                            mState.inputZ = 0f;
                        }
                    } else if (id == mCamPointerId) {
                        mState.camYaw -= (px - mLastCamX) * 0.0045f;
                        mLastCamX = px;
                        mState.cursorX = px / w;
                        mState.cursorY = py / h;
                    }
                }
            } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP || action == MotionEvent.ACTION_CANCEL) {
                if (pId == mMovePointerId) {
                    mMovePointerId = -1;
                    mState.inputX = 0f;
                    mState.inputZ = 0f;
                } else if (pId == mCamPointerId) {
                    mCamPointerId = -1;
                }
            }
            return true;
        }
    }
}
