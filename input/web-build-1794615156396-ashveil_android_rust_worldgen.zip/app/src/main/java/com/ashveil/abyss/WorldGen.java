package com.ashveil.abyss;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Seeded, stateless, infinite terrain generator (Minecraft-style).
 *
 * Same seed -> same world, every time, in any direction you walk. Nothing is stored:
 * every query is a pure function of (seed, x, y), so chunks can be rebuilt on demand.
 *
 * Layers:
 *   elevation  - continental noise. Low = lakes, high = rock massifs / cliffs.
 *   moisture   - decides grove vs. moor look, flower clusters, fog density.
 *   rivers     - ridged noise carved through low/mid ground.
 *   objects    - standing-stone pillars, boulders, cottages, shrines, moonlit caves,
 *                placed per 12x12 region cell from a hash of (seed, cell).
 *
 * Pure Java (no android.*) so it can be unit-tested on a desktop JVM.
 */
final class WorldGen {

    // ---- object kinds -------------------------------------------------------------
    static final int PILLAR = 0;   // tall standing stone (the dark glyph-filled monoliths)
    static final int BOULDER = 1;  // low wide rock cluster
    static final int HOUSE = 2;    // cottage with amber brazier
    static final int SHRINE = 3;   // cyan runestone
    static final int CAVE = 4;     // moonlit cave mouth in a rock face

    static final float CELL = 12.0f;

    // ---- thresholds (tuned with the preview renderer, see WorldGenPreview) ---------
    static final float SEA_LEVEL = 0.33f;
    static final float DEEP_LEVEL = 0.255f;
    static final float CLIFF_LEVEL = 0.665f;

    static final class Obj {
        int kind;
        float x, y;      // base position (feet) in world units
        float w, h;      // footprint width, visual height (world units)
        int variant;     // stable per-object random number for shape / glyph jitter
        long id;         // stable unique id (for sprite caches)
    }

    final long seed;
    private final int[] perm = new int[512];
    private final float[] ofs = new float[16];

    float spawnX, spawnY;

    private final HashMap<Long, Obj[]> cellCache = new HashMap<Long, Obj[]>();

    WorldGen(long seed) {
        this.seed = seed;
        long s = mix64(seed ^ 0x9E3779B97F4A7C15L);
        // Shuffled permutation table, Fisher-Yates driven by the seed.
        int[] p = new int[256];
        for (int i = 0; i < 256; i++) p[i] = i;
        for (int i = 255; i > 0; i--) {
            s = mix64(s + 0x9E3779B97F4A7C15L);
            int j = (int) ((s >>> 33) % (i + 1));
            int t = p[i];
            p[i] = p[j];
            p[j] = t;
        }
        for (int i = 0; i < 512; i++) perm[i] = p[i & 255];
        for (int i = 0; i < ofs.length; i++) {
            s = mix64(s + 0x9E3779B97F4A7C15L);
            ofs[i] = ((s >>> 40) & 0xFFFF) / 8.0f; // 0..8192 offsets decorrelate the fields
        }
        findSpawn();
    }

    // ===============================================================================
    // Noise
    // ===============================================================================

    static long mix64(long z) {
        z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
        z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
        return z ^ (z >>> 31);
    }

    /** Stable hash of (seed, a, b, salt) -> 0..1 */
    float hash01(int a, int b, int salt) {
        long h = mix64(seed + a * 0x632BE59BD9B4E019L + b * 0x9E3779B97F4A7C15L + salt * 0xD1B54A32D192ED03L);
        return ((h >>> 40) & 0xFFFFFF) / 16777216.0f;
    }

    long hashBits(int a, int b, int salt) {
        return mix64(seed + a * 0x632BE59BD9B4E019L + b * 0x9E3779B97F4A7C15L + salt * 0xD1B54A32D192ED03L);
    }

    private static float fade(float t) {
        return t * t * t * (t * (t * 6.0f - 15.0f) + 10.0f);
    }

    private float grad(int h, float x, float y) {
        switch (h & 7) {
            case 0: return x + y;
            case 1: return x - y;
            case 2: return -x + y;
            case 3: return -x - y;
            case 4: return x;
            case 5: return -x;
            case 6: return y;
            default: return -y;
        }
    }

    /** Classic 2D Perlin gradient noise, roughly -1..1 */
    float perlin(float x, float y) {
        int xi = (int) Math.floor(x);
        int yi = (int) Math.floor(y);
        float xf = x - xi;
        float yf = y - yi;
        xi &= 255;
        yi &= 255;
        float u = fade(xf);
        float v = fade(yf);
        int aa = perm[perm[xi] + yi];
        int ab = perm[perm[xi] + yi + 1];
        int ba = perm[perm[xi + 1] + yi];
        int bb = perm[perm[xi + 1] + yi + 1];
        float x1 = grad(aa, xf, yf) + u * (grad(ba, xf - 1, yf) - grad(aa, xf, yf));
        float x2 = grad(ab, xf, yf - 1) + u * (grad(bb, xf - 1, yf - 1) - grad(ab, xf, yf - 1));
        return (x1 + v * (x2 - x1)) * 1.4142f;
    }

    /** fBm in 0..1 */
    float fbm(float x, float y, int octaves, float freq, int field) {
        float sum = 0.0f;
        float amp = 0.5f;
        float norm = 0.0f;
        float ox = ofs[field * 2 & 15];
        float oy = ofs[(field * 2 + 1) & 15];
        for (int o = 0; o < octaves; o++) {
            sum += amp * perlin((x + ox) * freq, (y + oy) * freq);
            norm += amp;
            amp *= 0.5f;
            freq *= 2.03f;
            ox += 17.3f;
            oy += 31.7f;
        }
        return Math.max(0.0f, Math.min(1.0f, 0.5f + 0.5f * sum / norm * 1.35f));
    }

    // ===============================================================================
    // Terrain fields
    // ===============================================================================

    float elevation(float x, float y) {
        // large continents + a little ridge detail
        float e = fbm(x, y, 5, 0.018f, 0);
        return e;
    }

    float moisture(float x, float y) {
        return fbm(x, y, 3, 0.022f, 1);
    }

    /** 0 on land. >0 in water: 0..0.35 shallows (walkable, foam), >0.35 deep (blocked). */
    float waterDepth(float x, float y) {
        return waterFrom(elevation(x, y), x, y);
    }

    private float waterFrom(float e, float x, float y) {
        float d = 0.0f;
        if (e < SEA_LEVEL) {
            d = (SEA_LEVEL - e) / (SEA_LEVEL - DEEP_LEVEL) * 0.35f + 0.02f;
        }
        // Rivers: thin bands where a ridged noise field crosses zero. Fade out in the highlands.
        float r = Math.abs(perlin((x + ofs[4]) * 0.021f, (y + ofs[5]) * 0.021f)
                + 0.28f * perlin((x + ofs[6]) * 0.07f, (y + ofs[7]) * 0.07f));
        float width = 0.050f;
        if (e < CLIFF_LEVEL - 0.05f && r < width) {
            float t = 1.0f - r / width; // 1 at centre
            float rd = 0.05f + t * 0.38f;
            if (rd > d) d = rd;
        }
        return d;
    }

    boolean isWater(float x, float y) {
        return waterDepth(x, y) > 0.0f;
    }

    boolean isDeepWater(float x, float y) {
        return waterDepth(x, y) > 0.36f;
    }

    /** Rock massif density. > CLIFF_LEVEL = solid cliff. Slightly warped so edges are organic. */
    float cliff(float x, float y) {
        return cliffFrom(elevation(x, y), x, y);
    }

    private float cliffFrom(float e, float x, float y) {
        float detail = perlin((x + ofs[8]) * 0.11f, (y + ofs[9]) * 0.11f) * 0.045f;
        float v = e + detail;
        // keep a clear meadow around spawn
        float dx = x - spawnX;
        float dy = y - spawnY;
        float d2 = dx * dx + dy * dy;
        if (d2 < 49.0f) v -= (49.0f - d2) / 49.0f * 0.5f;
        return v;
    }

    /** One-shot sampler for the chunk painter: out[0]=cliff value, out[1]=water depth, out[2]=moisture. */
    void sample(float x, float y, float[] out) {
        float e = elevation(x, y);
        out[0] = cliffFrom(e, x, y);
        out[1] = waterFrom(e, x, y);
        out[2] = moisture(x, y);
    }

    boolean isCliff(float x, float y) {
        return cliff(x, y) > CLIFF_LEVEL;
    }

    /** Standing on something you can't walk through (terrain only, not objects). */
    boolean terrainBlocked(float x, float y) {
        return isCliff(x, y) || isDeepWater(x, y);
    }

    /** Full collision including pillars, boulders, houses, shrines. */
    boolean blocked(float x, float y) {
        if (terrainBlocked(x, y)) return true;
        int cx = (int) Math.floor(x / CELL);
        int cy = (int) Math.floor(y / CELL);
        for (int j = -1; j <= 1; j++) {
            for (int i = -1; i <= 1; i++) {
                Obj[] cell = cell(cx + i, cy + j);
                for (int k = 0; k < cell.length; k++) {
                    Obj o = cell[k];
                    if (o.kind == CAVE) continue; // cave mouth is walk-in
                    float rx = o.w * 0.5f;
                    float ry = (o.kind == HOUSE) ? 0.9f : Math.min(o.w * 0.32f, 0.9f);
                    float dx = (x - o.x) / rx;
                    float dy = (y - o.y) / ry;
                    if (dx * dx + dy * dy < 1.0f) return true;
                }
            }
        }
        return false;
    }

    /** Distance-ish to the nearest shore for foam; negative on land, positive in water. */
    float shoreSigned(float x, float y) {
        float d = waterDepth(x, y);
        return d > 0.0f ? d : -1.0f;
    }

    // ===============================================================================
    // Objects (placed per cell from hash(seed, cell))
    // ===============================================================================

    private Obj[] cell(int cx, int cy) {
        long key = ((long) cx << 32) ^ (cy & 0xFFFFFFFFL);
        Obj[] got = cellCache.get(key);
        if (got != null) return got;
        if (cellCache.size() > 600) cellCache.clear();
        got = buildCell(cx, cy);
        cellCache.put(key, got);
        return got;
    }

    private Obj make(int kind, float x, float y, float w, float h, int cx, int cy, int idx) {
        Obj o = new Obj();
        o.kind = kind;
        o.x = x;
        o.y = y;
        o.w = w;
        o.h = h;
        long bits = hashBits(cx, cy, 100 + idx);
        o.variant = (int) (bits >>> 20) & 0x7FFFFFFF;
        o.id = bits;
        return o;
    }

    /** Grass the player could stand on, with a little margin from water and rock. */
    private boolean openGround(float x, float y, float margin) {
        if (isWater(x, y) || isCliff(x, y)) return false;
        float m = margin;
        return !isWater(x + m, y) && !isWater(x - m, y) && !isWater(x, y + m) && !isWater(x, y - m)
                && !isCliff(x + m, y) && !isCliff(x - m, y) && !isCliff(x, y + m) && !isCliff(x, y - m);
    }

    private Obj[] buildCell(int cx, int cy) {
        ArrayList<Obj> list = new ArrayList<Obj>(8);
        float bx = cx * CELL;
        float by = cy * CELL;

        // --- standing stones: denser where a low-frequency "ancient" noise field is high
        float ancient = fbm(bx + CELL * 0.5f, by + CELL * 0.5f, 2, 0.035f, 2);
        int nStones = 0;
        float sr = hash01(cx, cy, 1);
        if (ancient > 0.62f) nStones = 2 + (sr > 0.5f ? 1 : 0);
        else if (ancient > 0.50f) nStones = (sr > 0.35f) ? 1 : 0;
        else if (sr > 0.82f) nStones = 1;
        for (int s = 0; s < nStones; s++) {
            float px = bx + 1.0f + hash01(cx, cy, 10 + s * 3) * (CELL - 2.0f);
            float py = by + 1.0f + hash01(cx, cy, 11 + s * 3) * (CELL - 2.0f);
            if (!openGround(px, py, 1.4f)) continue;
            if (dist2(px, py, spawnX, spawnY) < 30.0f) continue;
            boolean pillar = hash01(cx, cy, 12 + s * 3) > 0.42f;
            float w = pillar ? 1.9f + hash01(cx, cy, 40 + s) * 1.1f : 2.6f + hash01(cx, cy, 40 + s) * 1.8f;
            float h = pillar ? 4.6f + hash01(cx, cy, 50 + s) * 2.6f : 1.5f + hash01(cx, cy, 50 + s) * 1.0f;
            list.add(make(pillar ? PILLAR : BOULDER, px, py, w, h, cx, cy, s));
        }

        // --- cottage: rare, on flat open meadow
        if (hash01(cx, cy, 2) > 0.905f) {
            float px = bx + 3.0f + hash01(cx, cy, 20) * (CELL - 6.0f);
            float py = by + 3.0f + hash01(cx, cy, 21) * (CELL - 6.0f);
            if (openGround(px, py, 2.4f) && dist2(px, py, spawnX, spawnY) > 16.0f && clearOf(list, px, py, 3.4f)) {
                list.add(make(HOUSE, px, py, 3.2f, 2.2f, cx, cy, 20));
            }
        }

        // --- cyan runestone shrine
        if (hash01(cx, cy, 3) > 0.935f) {
            float px = bx + 2.0f + hash01(cx, cy, 22) * (CELL - 4.0f);
            float py = by + 2.0f + hash01(cx, cy, 23) * (CELL - 4.0f);
            if (openGround(px, py, 1.0f) && clearOf(list, px, py, 2.6f)) {
                list.add(make(SHRINE, px, py, 0.9f, 1.0f, cx, cy, 30));
            }
        }

        // --- moonlit cave: scan the cell for a rock face that opens southward onto grass
        if (hash01(cx, cy, 4) > 0.78f) {
            for (int t = 0; t < 18; t++) {
                float px = bx + hash01(cx, cy, 60 + t * 2) * CELL;
                float py = by + hash01(cx, cy, 61 + t * 2) * CELL;
                if (!isCliff(px, py)) continue;
                // walk south until we leave the rock; the mouth sits at the last rock cell
                float qy = py;
                int steps = 0;
                while (steps < 14 && isCliff(px, qy + 0.35f)) {
                    qy += 0.35f;
                    steps++;
                }
                if (steps >= 14) continue; // too deep inside a massif
                float gx = px;
                float gy = qy + 1.5f;
                if (isWater(gx, gy) || isCliff(gx, gy) || isCliff(gx - 1.4f, gy) && isCliff(gx + 1.4f, gy)) continue;
                list.add(make(CAVE, px, qy, 3.4f, 2.4f, cx, cy, 40 + t));
                break;
            }
        }

        return list.toArray(new Obj[0]);
    }

    private static float dist2(float ax, float ay, float bx, float by) {
        float dx = ax - bx;
        float dy = ay - by;
        return dx * dx + dy * dy;
    }

    private static boolean clearOf(ArrayList<Obj> list, float x, float y, float r) {
        for (int i = 0; i < list.size(); i++) {
            Obj o = list.get(i);
            if (dist2(x, y, o.x, o.y) < (r + o.w * 0.5f) * (r + o.w * 0.5f)) return false;
        }
        return true;
    }

    /** Fill 'out' with every object whose cell overlaps the rectangle (plus margin). */
    void objectsIn(float x0, float y0, float x1, float y1, ArrayList<Obj> out) {
        out.clear();
        int cx0 = (int) Math.floor((x0 - 4.0f) / CELL);
        int cx1 = (int) Math.floor((x1 + 4.0f) / CELL);
        int cy0 = (int) Math.floor((y0 - 8.0f) / CELL); // pillars are tall; look a bit further up
        int cy1 = (int) Math.floor((y1 + 4.0f) / CELL);
        for (int cy = cy0; cy <= cy1; cy++) {
            for (int cx = cx0; cx <= cx1; cx++) {
                Obj[] cell = cell(cx, cy);
                for (int k = 0; k < cell.length; k++) out.add(cell[k]);
            }
        }
    }

    // ===============================================================================
    // Spawn
    // ===============================================================================

    /** Spiral outward from the origin until we find a roomy patch of open meadow. */
    private void findSpawn() {
        spawnX = 0.0f;
        spawnY = 0.0f;
        // while searching, 'cliff' keeps its (0,0) clearing, which is fine for the first pass
        float best = -1.0f;
        float bx = 0.0f;
        float by = 0.0f;
        for (int ring = 0; ring < 90; ring++) {
            int pts = Math.max(1, ring * 6);
            for (int k = 0; k < pts; k++) {
                float a = (float) (k * (Math.PI * 2.0) / pts);
                float x = (float) Math.cos(a) * ring * 1.5f;
                float y = (float) Math.sin(a) * ring * 1.5f;
                if (!roomy(x, y)) continue;
                bx = x;
                by = y;
                best = 1.0f;
                break;
            }
            if (best > 0.0f) break;
        }
        spawnX = bx;
        spawnY = by;
    }

    private boolean roomy(float x, float y) {
        for (int j = -3; j <= 3; j++) {
            for (int i = -3; i <= 3; i++) {
                float px = x + i * 1.6f;
                float py = y + j * 1.6f;
                float e = elevation(px, py);
                if (e < SEA_LEVEL + 0.05f || e > CLIFF_LEVEL - 0.12f) return false;
                if (waterDepth(px, py) > 0.0f) return false;
            }
        }
        return true;
    }

    /** Random walkable point at roughly [minD, maxD] from (cx, cy). Returns null after 40 misses. */
    float[] randomOpenPoint(java.util.Random rng, float cx, float cy, float minD, float maxD) {
        for (int t = 0; t < 40; t++) {
            float a = rng.nextFloat() * 6.2831853f;
            float d = minD + rng.nextFloat() * (maxD - minD);
            float x = cx + (float) Math.cos(a) * d;
            float y = cy + (float) Math.sin(a) * d;
            if (!blocked(x, y) && !isWater(x, y)) return new float[]{x, y};
        }
        return null;
    }

    /** Random water point (for fish). Returns null after 40 misses. */
    float[] randomWaterPoint(java.util.Random rng, float cx, float cy, float minD, float maxD) {
        for (int t = 0; t < 40; t++) {
            float a = rng.nextFloat() * 6.2831853f;
            float d = minD + rng.nextFloat() * (maxD - minD);
            float x = cx + (float) Math.cos(a) * d;
            float y = cy + (float) Math.sin(a) * d;
            if (waterDepth(x, y) > 0.08f) return new float[]{x, y};
        }
        return null;
    }

    /** Minecraft-style seed text: digits -> that number, any other text -> its String.hashCode(). */
    static long seedFromText(String text) {
        if (text == null) return randomSeed();
        String t = text.trim();
        if (t.length() == 0) return randomSeed();
        try {
            return Long.parseLong(t);
        } catch (NumberFormatException e) {
            return t.hashCode();
        }
    }

    static long randomSeed() {
        return mix64(System.nanoTime() ^ (System.currentTimeMillis() * 0x9E3779B97F4A7C15L)) % 1000000000L;
    }
}
