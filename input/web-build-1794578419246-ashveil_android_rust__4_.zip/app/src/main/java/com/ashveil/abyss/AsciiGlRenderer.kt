package com.ashveil.abyss

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Real-time OpenGL ES 3.0 3D ASCII Rendering Engine for ASHVEIL.
 * - Custom GLSL #version 300 es shaders with normal-map perturbation, volumetric mist & rim lighting
 * - Continuous Lofted Anatomical 3D Humanoid Meshes (Torso/Cuirass, Visored Sallet Helm + Crest,
 *   Curved Pauldrons, Joint-Pivoted Sculpted Arms, Joint-Pivoted Sculpted Thighs/Calves,
 *   Sabaton Boots, Draped Pleated Traveler Cloak, Curved Kite Shield & Diamond Greatsword)
 * - Sculpted Craggy Multi-Faceted Rock Formations & Tree Trunks/Canopies (Zero cubes, zero sphere-men)
 * - 32,000 GPU-instanced 3D ASCII grass blades & biome-aware wildflowers (44m x 44m coverage)
 * - 512x512 Planar Water Reflection FBO with distorted ASCII wave reflections
 */
class AsciiGlRenderer(private val state: GameState) : GLSurfaceView.Renderer {

    private var lastNs: Long = System.nanoTime()
    private var width: Int = 1280
    private var height: Int = 720

    // OpenGL Shader Programs
    private var progMeshAscii: Int = 0
    private var progGrassInstanced: Int = 0
    private var progWaterAscii: Int = 0

    // 16x6 High-Resolution Monospace Glyph Atlas Texture
    private var glyphAtlasTex: Int = 0

    // Planar Water Reflection Framebuffer Object (FBO)
    private var reflectFbo: Int = 0
    private var reflectTex: Int = 0
    private var reflectDepthRb: Int = 0

    // Sculpted Anatomical Humanoid & Environment GPU VBOs/IBOs
    private var torsoVbo: Int = 0
    private var torsoIbo: Int = 0
    private var torsoIndexCount: Int = 0

    private var helmVbo: Int = 0
    private var helmIbo: Int = 0
    private var helmIndexCount: Int = 0

    private var pauldronVbo: Int = 0
    private var pauldronIbo: Int = 0
    private var pauldronIndexCount: Int = 0

    private var armVbo: Int = 0
    private var armIbo: Int = 0
    private var armIndexCount: Int = 0

    private var legVbo: Int = 0
    private var legIbo: Int = 0
    private var legIndexCount: Int = 0

    private var bootVbo: Int = 0
    private var bootIbo: Int = 0
    private var bootIndexCount: Int = 0

    private var cloakVbo: Int = 0
    private var cloakIbo: Int = 0
    private var cloakIndexCount: Int = 0

    private var shieldVbo: Int = 0
    private var shieldIbo: Int = 0
    private var shieldIndexCount: Int = 0

    private var bladeVbo: Int = 0
    private var bladeIbo: Int = 0
    private var bladeIndexCount: Int = 0

    private var rockVbo: Int = 0
    private var rockIbo: Int = 0
    private var rockIndexCount: Int = 0

    private var trunkVbo: Int = 0
    private var trunkIbo: Int = 0
    private var trunkIndexCount: Int = 0

    private var sphereVbo: Int = 0
    private var sphereIbo: Int = 0
    private var sphereIndexCount: Int = 0

    private var quadVbo: Int = 0

    // GPU Instanced 3D Grass & Wildflower Buffers
    private var grassRibbonVbo: Int = 0
    private var grassInstanceVbo: Int = 0

    // Transformation Matrices (Pre-allocated to avoid GC in render loop)
    private val projMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val vpMatrix = FloatArray(16)
    private val reflectViewMatrix = FloatArray(16)
    private val reflectVpMatrix = FloatArray(16)
    private val modelMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0.020f, 0.032f, 0.028f, 1.0f)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glDepthFunc(GLES30.GL_LEQUAL)
        GLES30.glDisable(GLES30.GL_CULL_FACE)

        glyphAtlasTex = createAsciiGlyphAtlasTexture()
        buildUnitSphereVbo(14, 18)
        buildAnatomicalHumanMeshes()
        buildCloakAndShieldMeshes()
        buildBladeVbo()
        buildOrganicRockAndTrunkMeshes()
        buildQuadVbo()
        buildInstancedGrassBuffers()
        initReflectionFbo()
        compileAllShaders()
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        width = max(1, w)
        height = max(1, h)
        GLES30.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        val nowNs = System.nanoTime()
        var dt = (nowNs - lastNs) / 1_000_000_000.0f
        lastNs = nowNs
        if (dt > 0.05f) dt = 0.05f
        if (dt < 0.001f) dt = 0.001f

        state.stepSimulation(dt)

        if (state.screenMode == 2) {
            render3DChainmailEquipmentScene()
        } else {
            render3DOpenWorldScene()
        }
    }

    private fun createAsciiGlyphAtlasTexture(): Int {
        val cols = 16
        val rows = 6
        val cellW = 48
        val cellH = 48
        val bmp = Bitmap.createBitmap(cols * cellW, rows * cellH, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.TRANSPARENT)

        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        p.textSize = 37.0f
        p.color = Color.WHITE
        p.textAlign = Paint.Align.CENTER

        val atlasChars =
            " .,:;~-=+*oahkbd" +
            "pqwmZOQ0N\$%&8B#W" +
            "@S8\$#c()350Qo*+=" +
            "|/\\,;'*o+.^v~:;#" +
            "0Q8B@WM#%&80aaqQ" +
            "-~=:.o0*+@\u00a7^v<>#"

        val fm = p.fontMetrics
        val baselineOff = -(fm.ascent + fm.descent) * 0.5f

        for (r in 0 until rows) {
            for (col in 0 until cols) {
                val idx = r * cols + col
                val ch = if (idx < atlasChars.length) atlasChars[idx] else '@'
                val cx = col * cellW + cellW * 0.5f
                val cy = r * cellH + cellH * 0.5f + baselineOff
                c.drawText(ch.toString(), cx, cy, p)
            }
        }

        val tex = IntArray(1)
        GLES30.glGenTextures(1, tex, 0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex[0])
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0)
        bmp.recycle()
        return tex[0]
    }

    private fun uploadIndexedMesh(verts: FloatArray, indices: ShortArray): IntArray {
        val vb = ByteBuffer.allocateDirect(verts.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
        vb.put(verts).position(0)

        val ib = ByteBuffer.allocateDirect(indices.size * 2)
            .order(ByteOrder.nativeOrder()).asShortBuffer()
        ib.put(indices).position(0)

        val bufs = IntArray(2)
        GLES30.glGenBuffers(2, bufs, 0)

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, bufs[0])
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, verts.size * 4, vb, GLES30.GL_STATIC_DRAW)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)

        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, bufs[1])
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, indices.size * 2, ib, GLES30.GL_STATIC_DRAW)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, 0)
        return bufs
    }

    /**
     * Builds a smooth lofted 3D tubular mesh from anatomical cross-section rings:
     * Each ring is floatArrayOf(y, radiusX, radiusZ, offsetZ).
     */
    private fun buildLoftedMesh(
        profile: Array<FloatArray>,
        segs: Int,
        chestContour: Boolean = false
    ): IntArray {
        val rings = profile.size
        val vertCount = rings * (segs + 1)
        val verts = FloatArray(vertCount * 8)
        var vPtr = 0

        for (rIdx in 0 until rings) {
            val y = profile[rIdx][0]
            val rx = profile[rIdx][1]
            val rz = profile[rIdx][2]
            val oz = profile[rIdx][3]

            val dy: Float
            val dr: Float
            if (rIdx == 0) {
                dy = profile[1][0] - y
                dr = ((profile[1][1] - rx) + (profile[1][2] - rz)) * 0.5f
            } else if (rIdx == rings - 1) {
                dy = y - profile[rings - 2][0]
                dr = ((rx - profile[rings - 2][1]) + (rz - profile[rings - 2][2])) * 0.5f
            } else {
                dy = profile[rIdx + 1][0] - profile[rIdx - 1][0]
                dr = ((profile[rIdx + 1][1] - profile[rIdx - 1][1]) + (profile[rIdx + 1][2] - profile[rIdx - 1][2])) * 0.5f
            }
            val signDy = if (dy >= 0f) 1.0f else -1.0f
            val nyRaw = (-dr / max(0.001f, abs(dy)) * signDy).coerceIn(-0.85f, 0.85f)

            for (s in 0..segs) {
                val phi = (s * 2.0 * PI / segs).toFloat()
                val cs = cos(phi)
                val sn = sin(phi)

                // Subtle anatomical muscle / breastplate sculpting when chestContour is active
                val contour = if (chestContour && y in 0.15f..0.48f) {
                    1.0f + 0.045f * cos(phi * 2.0f)
                } else {
                    1.0f
                }

                val vx = cs * rx * contour
                val vy = y
                val vz = sn * rz * contour + oz

                var nx = cs / max(0.01f, rx)
                var nz = sn / max(0.01f, rz)
                val nHoriz = sqrt(nx * nx + nz * nz)
                nx /= max(0.001f, nHoriz)
                nz /= max(0.001f, nHoriz)
                val ny = nyRaw
                val nLen = sqrt(nx * nx + ny * ny + nz * nz)

                verts[vPtr++] = vx
                verts[vPtr++] = vy
                verts[vPtr++] = vz
                verts[vPtr++] = nx / nLen
                verts[vPtr++] = ny / nLen
                verts[vPtr++] = nz / nLen
                verts[vPtr++] = s / segs.toFloat()
                verts[vPtr++] = rIdx / max(1, rings - 1).toFloat()
            }
        }

        val indices = ShortArray((rings - 1) * segs * 6)
        var iPtr = 0
        val stride = segs + 1
        for (r in 0 until (rings - 1)) {
            for (s in 0 until segs) {
                val b0 = r * stride + s
                val b1 = b0 + 1
                val t0 = (r + 1) * stride + s
                val t1 = t0 + 1
                indices[iPtr++] = b0.toShort()
                indices[iPtr++] = t0.toShort()
                indices[iPtr++] = b1.toShort()
                indices[iPtr++] = b1.toShort()
                indices[iPtr++] = t0.toShort()
                indices[iPtr++] = t1.toShort()
            }
        }
        val bufs = uploadIndexedMesh(verts, indices)
        return intArrayOf(bufs[0], bufs[1], indices.size)
    }

    /**
     * Builds the continuous sculpted 3D human knight meshes:
     * 1. Torso & Cuirass (hip pelvis -> tapered waist -> pectoral breastplate -> broad shoulders -> neck)
     * 2. Visored Sallet Helmet + Pointed Crest
     * 3. Curved Shoulder Pauldron Dome
     * 4. Sculpted Arm & Gauntlet (pivoting at shoulder socket y=0.0)
     * 5. Sculpted Thigh, Knee Poleyn & Calf Greave (pivoting at hip socket y=0.0)
     * 6. Sculpted Armored Sabaton Boot (sharing the leg's hip socket pivot y=0.0)
     */
    private fun buildAnatomicalHumanMeshes() {
        // 1. Sculpted Human Torso & Cuirass (y = -0.05 to 0.59)
        val torsoProfile = arrayOf(
            floatArrayOf(-0.05f, 0.020f, 0.020f, 0.000f), // sealed pelvic base
            floatArrayOf(-0.02f, 0.145f, 0.105f, 0.000f), // lower pelvis
            floatArrayOf( 0.05f, 0.175f, 0.125f, 0.000f), // hip tassets flare
            floatArrayOf( 0.14f, 0.135f, 0.100f, 0.000f), // narrow athletic waist
            floatArrayOf( 0.24f, 0.165f, 0.120f, 0.008f), // lower ribcage
            floatArrayOf( 0.36f, 0.215f, 0.150f, 0.018f), // sculpted breastplate pectorals
            floatArrayOf( 0.46f, 0.240f, 0.145f, 0.010f), // broad heroic shoulders
            floatArrayOf( 0.51f, 0.180f, 0.115f, 0.000f), // trapezius slope
            floatArrayOf( 0.55f, 0.082f, 0.082f, 0.000f), // gorget collar
            floatArrayOf( 0.60f, 0.072f, 0.074f, 0.004f)  // neck column
        )
        val tRes = buildLoftedMesh(torsoProfile, 22, true)
        torsoVbo = tRes[0]
        torsoIbo = tRes[1]
        torsoIndexCount = tRes[2]

        // 2. Sculpted Visored Knight Helmet + Pointed Crest (y = 0.58 to 0.88)
        val helmProfile = arrayOf(
            floatArrayOf(0.58f, 0.070f, 0.072f,  0.004f), // neck join
            floatArrayOf(0.63f, 0.094f, 0.108f,  0.014f), // helmet chin & jaw guard
            floatArrayOf(0.69f, 0.106f, 0.126f,  0.022f), // sharp visor ridge (+Z)
            floatArrayOf(0.75f, 0.102f, 0.120f,  0.008f), // brow & temple guard
            floatArrayOf(0.81f, 0.082f, 0.102f, -0.006f), // upper helm dome
            floatArrayOf(0.85f, 0.042f, 0.065f, -0.012f), // helm ridge crest
            floatArrayOf(0.88f, 0.012f, 0.028f, -0.016f)  // pointed knight crest tip
        )
        val hRes = buildLoftedMesh(helmProfile, 20, false)
        helmVbo = hRes[0]
        helmIbo = hRes[1]
        helmIndexCount = hRes[2]

        // 3. Curved Layered Shoulder Pauldron Cap (around shoulder origin y=0.0)
        val pauldronProfile = arrayOf(
            floatArrayOf(-0.08f, 0.112f, 0.110f, 0.0f),
            floatArrayOf(-0.03f, 0.118f, 0.115f, 0.0f),
            floatArrayOf( 0.02f, 0.106f, 0.105f, 0.0f),
            floatArrayOf( 0.06f, 0.072f, 0.072f, 0.0f),
            floatArrayOf( 0.08f, 0.015f, 0.015f, 0.0f)
        )
        val pRes = buildLoftedMesh(pauldronProfile, 16, false)
        pauldronVbo = pRes[0]
        pauldronIbo = pRes[1]
        pauldronIndexCount = pRes[2]

        // 4. Sculpted Human Arm + Elbow Couter + Forearm Vambrace + Gauntlet Fist (pivots at shoulder y=0.0)
        val armProfile = arrayOf(
            floatArrayOf( 0.05f, 0.015f, 0.015f, 0.000f), // sealed shoulder socket cap
            floatArrayOf( 0.02f, 0.088f, 0.088f, 0.000f), // deltoid head
            floatArrayOf(-0.06f, 0.082f, 0.084f, 0.000f), // upper bicep
            floatArrayOf(-0.16f, 0.070f, 0.072f, 0.004f), // mid bicep/tricep
            floatArrayOf(-0.26f, 0.064f, 0.068f, 0.014f), // elbow joint & couter
            floatArrayOf(-0.37f, 0.068f, 0.072f, 0.034f), // forearm vambrace
            floatArrayOf(-0.47f, 0.054f, 0.058f, 0.052f), // tapered wrist
            floatArrayOf(-0.54f, 0.064f, 0.068f, 0.062f), // armored gauntlet fist
            floatArrayOf(-0.57f, 0.015f, 0.015f, 0.062f)  // sealed knuckles cap
        )
        val aRes = buildLoftedMesh(armProfile, 16, false)
        armVbo = aRes[0]
        armIbo = aRes[1]
        armIndexCount = aRes[2]

        // 5. Sculpted Thigh Cuisse + Knee Poleyn + Calf Greave (pivots at hip socket y=0.0 down to ankle y=-0.66)
        val legProfile = arrayOf(
            floatArrayOf( 0.05f, 0.015f, 0.015f,  0.000f), // sealed hip ball cap
            floatArrayOf( 0.02f, 0.088f, 0.088f,  0.000f), // hip ball joint
            floatArrayOf(-0.08f, 0.104f, 0.110f,  0.005f), // upper thigh cuisse
            floatArrayOf(-0.22f, 0.090f, 0.096f,  0.010f), // mid thigh muscle
            floatArrayOf(-0.35f, 0.072f, 0.078f,  0.012f), // knee joint + poleyn ridge
            floatArrayOf(-0.44f, 0.078f, 0.085f, -0.006f), // upper calf greave
            floatArrayOf(-0.54f, 0.080f, 0.090f, -0.014f), // calf muscle belly
            floatArrayOf(-0.66f, 0.056f, 0.062f,  0.000f)  // tapered ankle join
        )
        val lRes = buildLoftedMesh(legProfile, 18, false)
        legVbo = lRes[0]
        legIbo = lRes[1]
        legIndexCount = lRes[2]

        // 6. Sculpted Armored Sabaton Boot (shares hip pivot y=0.0; spans ankle y=-0.65 to sole y=-0.82)
        val bootProfile = arrayOf(
            floatArrayOf(-0.65f, 0.056f, 0.062f, 0.000f), // ankle cuff
            floatArrayOf(-0.71f, 0.062f, 0.082f, 0.018f), // heel & arch
            floatArrayOf(-0.76f, 0.068f, 0.112f, 0.042f), // armored instep
            floatArrayOf(-0.80f, 0.070f, 0.136f, 0.058f), // sabaton toe & sole
            floatArrayOf(-0.82f, 0.015f, 0.040f, 0.058f)  // sealed sole bottom
        )
        val bRes = buildLoftedMesh(bootProfile, 16, false)
        bootVbo = bRes[0]
        bootIbo = bRes[1]
        bootIndexCount = bRes[2]
    }

    /**
     * Builds the draped, pleated 3D Traveler Cloak mesh and curved Medieval Kite Shield mesh.
     */
    private fun buildCloakAndShieldMeshes() {
        val rows = 14
        val cols = 14
        val verts = FloatArray((rows + 1) * (cols + 1) * 8)
        var vPtr = 0
        for (r in 0..rows) {
            val v = r / rows.toFloat()
            val y = 0.48f - v * 0.92f
            val w = 0.20f + v * 0.19f
            // Sits cleanly behind the sculpted back (-0.165..-0.32) with zero back poke-through
            val zCurve = -0.165f - v * 0.145f - sin(v * PI.toFloat()) * 0.035f
            for (c in 0..cols) {
                val u = (c / cols.toFloat()) * 2.0f - 1.0f
                val fold = sin(u * PI.toFloat() * 3.0f) * 0.025f * (0.15f + 0.85f * v)
                val vx = u * w
                val vy = y
                val vz = zCurve + fold
                val nx = u * 0.35f + cos(u * PI.toFloat() * 3.0f) * 0.28f * v
                val ny = 0.18f
                val nz = -0.92f
                val nLen = sqrt(nx * nx + ny * ny + nz * nz)
                verts[vPtr++] = vx
                verts[vPtr++] = vy
                verts[vPtr++] = vz
                verts[vPtr++] = nx / nLen
                verts[vPtr++] = ny / nLen
                verts[vPtr++] = nz / nLen
                verts[vPtr++] = c / cols.toFloat()
                verts[vPtr++] = v
            }
        }
        val indices = ShortArray(rows * cols * 6)
        var iPtr = 0
        val stride = cols + 1
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val b0 = r * stride + c
                val b1 = b0 + 1
                val t0 = (r + 1) * stride + c
                val t1 = t0 + 1
                indices[iPtr++] = b0.toShort()
                indices[iPtr++] = t0.toShort()
                indices[iPtr++] = b1.toShort()
                indices[iPtr++] = b1.toShort()
                indices[iPtr++] = t0.toShort()
                indices[iPtr++] = t1.toShort()
            }
        }
        val cBufs = uploadIndexedMesh(verts, indices)
        cloakVbo = cBufs[0]
        cloakIbo = cBufs[1]
        cloakIndexCount = indices.size

        // Curved Medieval Kite Shield (mounted on left forearm, matching `1000461482.jpg`)
        val shieldProfile = arrayOf(
            floatArrayOf(-0.24f, 0.015f, 0.015f, 0.00f), // bottom point of kite shield
            floatArrayOf(-0.14f, 0.095f, 0.035f, 0.01f),
            floatArrayOf( 0.00f, 0.145f, 0.045f, 0.02f), // shield boss center
            floatArrayOf( 0.14f, 0.160f, 0.042f, 0.01f), // broad upper shield rim
            floatArrayOf( 0.18f, 0.020f, 0.015f, 0.00f)  // sealed top edge
        )
        val sRes = buildLoftedMesh(shieldProfile, 14, false)
        shieldVbo = sRes[0]
        shieldIbo = sRes[1]
        shieldIndexCount = sRes[2]
    }

    /**
     * Builds craggy, faceted 3D rock formations & tapered organic tree trunks
     * so rocks and trees look like natural 3D formations (neither cubes nor balls).
     */
    private fun buildOrganicRockAndTrunkMeshes() {
        val rings = 11
        val segs = 16
        val verts = FloatArray(rings * (segs + 1) * 8)
        var vPtr = 0
        val yLevels = floatArrayOf(-0.50f, -0.38f, -0.24f, -0.10f, 0.04f, 0.16f, 0.27f, 0.36f, 0.43f, 0.48f, 0.50f)
        val baseRadii = floatArrayOf(0.54f, 0.52f, 0.49f, 0.46f, 0.43f, 0.39f, 0.34f, 0.28f, 0.19f, 0.09f, 0.01f)

        for (r in 0 until rings) {
            val y = yLevels[r]
            val rad = baseRadii[r]
            for (s in 0..segs) {
                val phi = (s * 2.0 * PI / segs).toFloat()
                val crag = if (r == rings - 1) 1.0f else (
                    1.0f + 0.14f * sin(phi * 3.0f + r * 1.1f)
                         + 0.09f * cos(phi * 5.0f - r * 1.7f)
                )
                val rx = rad * crag
                val vx = cos(phi) * rx
                val vz = sin(phi) * rx
                val nx = cos(phi) + 0.22f * cos(phi * 3.0f + r)
                val ny = if (r >= 7) 0.55f else 0.18f
                val nz = sin(phi) - 0.22f * sin(phi * 5.0f - r)
                val nLen = sqrt(nx * nx + ny * ny + nz * nz)
                verts[vPtr++] = vx
                verts[vPtr++] = y
                verts[vPtr++] = vz
                verts[vPtr++] = nx / nLen
                verts[vPtr++] = ny / nLen
                verts[vPtr++] = nz / nLen
                verts[vPtr++] = s / segs.toFloat()
                verts[vPtr++] = r / (rings - 1).toFloat()
            }
        }
        val indices = ShortArray((rings - 1) * segs * 6)
        var iPtr = 0
        val stride = segs + 1
        for (r in 0 until (rings - 1)) {
            for (s in 0 until segs) {
                val b0 = r * stride + s
                val b1 = b0 + 1
                val t0 = (r + 1) * stride + s
                val t1 = t0 + 1
                indices[iPtr++] = b0.toShort()
                indices[iPtr++] = t0.toShort()
                indices[iPtr++] = b1.toShort()
                indices[iPtr++] = b1.toShort()
                indices[iPtr++] = t0.toShort()
                indices[iPtr++] = t1.toShort()
            }
        }
        val rBufs = uploadIndexedMesh(verts, indices)
        rockVbo = rBufs[0]
        rockIbo = rBufs[1]
        rockIndexCount = indices.size

        // Tapered organic tree trunk with flared roots
        val trunkProfile = arrayOf(
            floatArrayOf(-0.50f, 0.62f, 0.62f, 0.0f),
            floatArrayOf(-0.35f, 0.48f, 0.48f, 0.0f),
            floatArrayOf( 0.00f, 0.42f, 0.42f, 0.0f),
            floatArrayOf( 0.35f, 0.36f, 0.36f, 0.0f),
            floatArrayOf( 0.50f, 0.30f, 0.30f, 0.0f)
        )
        val trRes = buildLoftedMesh(trunkProfile, 12, false)
        trunkVbo = trRes[0]
        trunkIbo = trRes[1]
        trunkIndexCount = trRes[2]
    }

    private fun buildUnitSphereVbo(latBands: Int, lonBands: Int) {
        val vertCount = (latBands + 1) * (lonBands + 1)
        val verts = FloatArray(vertCount * 8)
        var vPtr = 0
        for (lat in 0..latBands) {
            val theta = (lat * PI / latBands).toFloat()
            val sinT = sin(theta)
            val cosT = cos(theta)
            for (lon in 0..lonBands) {
                val phi = (lon * 2.0 * PI / lonBands).toFloat()
                val nx = cos(phi) * sinT
                val ny = cosT
                val nz = sin(phi) * sinT
                verts[vPtr++] = nx * 0.5f
                verts[vPtr++] = ny * 0.5f
                verts[vPtr++] = nz * 0.5f
                verts[vPtr++] = nx
                verts[vPtr++] = ny
                verts[vPtr++] = nz
                verts[vPtr++] = lon / lonBands.toFloat()
                verts[vPtr++] = lat / latBands.toFloat()
            }
        }

        val indices = ShortArray(latBands * lonBands * 6)
        var iPtr = 0
        for (lat in 0 until latBands) {
            for (lon in 0 until lonBands) {
                val first = (lat * (lonBands + 1)) + lon
                val second = first + lonBands + 1
                indices[iPtr++] = first.toShort()
                indices[iPtr++] = second.toShort()
                indices[iPtr++] = (first + 1).toShort()
                indices[iPtr++] = second.toShort()
                indices[iPtr++] = (second + 1).toShort()
                indices[iPtr++] = (first + 1).toShort()
            }
        }
        sphereIndexCount = indices.size
        val bufs = uploadIndexedMesh(verts, indices)
        sphereVbo = bufs[0]
        sphereIbo = bufs[1]
    }

    private fun buildBladeVbo() {
        val verts = floatArrayOf(
            0.0f,  0.5f, 0.0f,  0f,  1f, 0f, 0.5f, 0f,
            0.5f,  0.0f, 0.0f,  1f,  0f, 0f, 1.0f, 0.5f,
            0.0f, -0.5f, 0.0f,  0f, -1f, 0f, 0.5f, 1f,
           -0.5f,  0.0f, 0.0f, -1f,  0f, 0f, 0.0f, 0.5f,
            0.0f,  0.38f, 0.72f,  0f,  1f, 0.2f, 0.5f, 0f,
            0.38f, 0.0f,  0.72f,  1f,  0f, 0.2f, 1.0f, 0.5f,
            0.0f, -0.38f, 0.72f,  0f, -1f, 0.2f, 0.5f, 1f,
           -0.38f, 0.0f,  0.72f, -1f,  0f, 0.2f, 0.0f, 0.5f,
            0.0f, 0.0f, 1.0f, 0f, 0f, 1f, 0.5f, 0.5f
        )
        val indices = shortArrayOf(
            0, 1, 5, 0, 5, 4,
            1, 2, 6, 1, 6, 5,
            2, 3, 7, 2, 7, 6,
            3, 0, 4, 3, 4, 7,
            4, 5, 8,
            5, 6, 8,
            6, 7, 8,
            7, 4, 8
        )
        bladeIndexCount = indices.size
        val bufs = uploadIndexedMesh(verts, indices)
        bladeVbo = bufs[0]
        bladeIbo = bufs[1]
    }

    private fun buildQuadVbo() {
        val q = floatArrayOf(
            -1f, 0f, -1f, 0f, 1f, 0f, 0f, 0f,
             1f, 0f, -1f, 0f, 1f, 0f, 1f, 0f,
            -1f, 0f,  1f, 0f, 1f, 0f, 0f, 1f,
             1f, 0f, -1f, 0f, 1f, 0f, 1f, 0f,
             1f, 0f,  1f, 0f, 1f, 0f, 1f, 1f,
            -1f, 0f,  1f, 0f, 1f, 0f, 0f, 1f
        )
        val qb = ByteBuffer.allocateDirect(q.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
        qb.put(q).position(0)

        val bufs = IntArray(1)
        GLES30.glGenBuffers(1, bufs, 0)
        quadVbo = bufs[0]
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, quadVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, q.size * 4, qb, GLES30.GL_STATIC_DRAW)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
    }

    private fun buildInstancedGrassBuffers() {
        val ribbon = floatArrayOf(
            -0.5f, 0.0f, 0.0f, 1.0f,
             0.5f, 0.0f, 1.0f, 1.0f,
            -0.5f, 1.0f, 0.0f, 0.0f,
             0.5f, 0.0f, 1.0f, 1.0f,
             0.5f, 1.0f, 1.0f, 0.0f,
            -0.5f, 1.0f, 0.0f, 0.0f
        )
        val rb = ByteBuffer.allocateDirect(ribbon.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
        rb.put(ribbon).position(0)

        val inst = FloatArray(MAX_GRASS_INSTANCES * 4)
        var seed = 918273645
        for (i in 0 until MAX_GRASS_INSTANCES) {
            seed = seed * 1664525 + 1013904223
            val rx = (((seed ushr 16) and 0xFFFF) / 65535.0f - 0.5f) * 44.0f
            seed = seed * 1664525 + 1013904223
            val rz = (((seed ushr 16) and 0xFFFF) / 65535.0f - 0.5f) * 44.0f
            seed = seed * 1664525 + 1013904223
            val isFlower = (i % 24 == 0)
            val hScale = if (isFlower) 0.26f else (0.32f + ((seed ushr 12) and 15) * 0.018f)
            val typeSeed = if (isFlower) (100.0f + (i % 6)) else (i % 16).toFloat()

            val o = i * 4
            inst[o] = rx
            inst[o + 1] = rz
            inst[o + 2] = hScale
            inst[o + 3] = typeSeed
        }
        val ib = ByteBuffer.allocateDirect(inst.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
        ib.put(inst).position(0)

        val vbos = IntArray(2)
        GLES30.glGenBuffers(2, vbos, 0)
        grassRibbonVbo = vbos[0]
        grassInstanceVbo = vbos[1]

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, grassRibbonVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, ribbon.size * 4, rb, GLES30.GL_STATIC_DRAW)

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, grassInstanceVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, inst.size * 4, ib, GLES30.GL_STATIC_DRAW)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
    }

    private fun initReflectionFbo() {
        val fbo = IntArray(1)
        val tex = IntArray(1)
        val rb = IntArray(1)
        GLES30.glGenFramebuffers(1, fbo, 0)
        GLES30.glGenTextures(1, tex, 0)
        GLES30.glGenRenderbuffers(1, rb, 0)

        reflectFbo = fbo[0]
        reflectTex = tex[0]
        reflectDepthRb = rb[0]

        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, reflectTex)
        GLES30.glTexImage2D(
            GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, REFLECT_W, REFLECT_H, 0,
            GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null
        )
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)

        GLES30.glBindRenderbuffer(GLES30.GL_RENDERBUFFER, reflectDepthRb)
        GLES30.glRenderbufferStorage(GLES30.GL_RENDERBUFFER, GLES30.GL_DEPTH_COMPONENT16, REFLECT_W, REFLECT_H)

        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, reflectFbo)
        GLES30.glFramebufferTexture2D(
            GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, reflectTex, 0
        )
        GLES30.glFramebufferRenderbuffer(
            GLES30.GL_FRAMEBUFFER, GLES30.GL_DEPTH_ATTACHMENT, GLES30.GL_RENDERBUFFER, reflectDepthRb
        )
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
    }

    private fun compileAllShaders() {
        val vsMesh = """
            #version 300 es
            layout(location = 0) in vec3 aPos;
            layout(location = 1) in vec3 aNormal;
            layout(location = 2) in vec2 aUv;
            uniform mat4 uMVP;
            uniform mat4 uModel;
            out vec3 vWorldPos;
            out vec3 vNormal;
            out vec2 vUv;
            void main() {
                vec4 wp = uModel * vec4(aPos, 1.0);
                vWorldPos = wp.xyz;
                mat3 normalMat = transpose(inverse(mat3(uModel)));
                vNormal = normalize(normalMat * aNormal);
                vUv = aUv;
                gl_Position = uMVP * vec4(aPos, 1.0);
            }
        """.trimIndent()

        val fsMesh = """
            #version 300 es
            precision mediump float;
            in vec3 vWorldPos;
            in vec3 vNormal;
            in vec2 vUv;
            uniform sampler2D uAtlas;
            uniform vec3 uBaseColor;
            uniform vec3 uCamPos;
            uniform float uCellScale;
            uniform int uMaterialMode;
            uniform int uDebugSolid;
            uniform float uTime;
            out vec4 fragColor;

            float hash12(vec2 p) {
                return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
            }

            void main() {
                vec3 bump = vec3(
                    sin(vWorldPos.x * 4.5 + vWorldPos.z * 2.2) * cos(vWorldPos.y * 3.8),
                    cos(vWorldPos.x * 3.2 - vWorldPos.z * 4.1),
                    sin(vWorldPos.z * 4.8 - vWorldPos.x * 2.5)
                ) * ((uMaterialMode == 0 || uMaterialMode == 2) ? 0.22 : 0.04);

                vec3 N = normalize(vNormal + bump);
                vec3 L = normalize(vec3(-0.52, 0.80, 0.34));
                vec3 V = normalize(uCamPos - vWorldPos);
                vec3 H = normalize(L + V);
                float diff = max(0.06, dot(N, L));
                float spec = pow(max(0.0, dot(N, H)), 18.0);
                float rim = pow(1.0 - max(0.0, dot(N, V)), 2.3);

                if (uDebugSolid == 1) {
                    vec3 solidCol = uBaseColor * (0.25 + 0.75 * diff) + vec3(spec * 0.35 + rim * 0.2);
                    fragColor = vec4(solidCol, 1.0);
                    return;
                }

                if (uMaterialMode == 5) {
                    vec2 uvCentered = (vUv - vec2(0.5)) * 2.0;
                    float r = length(uvCentered);
                    if (r > 0.98 || r < 0.42) discard;
                    float ringBand = smoothstep(0.42, 0.56, r) * (1.0 - smoothstep(0.84, 0.98, r));
                    float ang = atan(uvCentered.y, uvCentered.x) + uTime * 1.8;
                    float seg = floor(mod(ang * 4.5, 16.0));
                    vec2 gUv = fract(vec2(ang * 3.8, (r - 0.42) * 3.2));
                    vec2 aUv = (vec2(seg, 5.0) + gUv) / vec2(16.0, 6.0);
                    float m = texture(uAtlas, aUv).a;
                    float spark = pow(max(0.0, cos(ang - uTime * 3.2)), 8.0);
                    vec3 glowCol = mix(vec3(0.68, 0.56, 0.95), vec3(1.0, 0.96, 0.82), spark + m * 0.5);
                    if (m * ringBand < 0.12 && spark < 0.4) discard;
                    fragColor = vec4(glowCol * (0.55 + 0.75 * m + spark * 0.8), 1.0);
                    return;
                }

                if (uMaterialMode == 2) {
                    bool inCave = (vWorldPos.z < -8.5);
                    vec2 gCoord = vWorldPos.xz * (inCave ? 3.2 : 2.3);
                    vec2 cId = floor(gCoord);
                    vec2 cUv = fract(gCoord);
                    float h = hash12(cId);
                    vec3 soil = inCave ? vec3(0.016, 0.020, 0.028) : vec3(0.020, 0.033, 0.028);
                    float ridge = max(0.0, sin(vWorldPos.x * 1.3 + sin(vWorldPos.z * 0.9) * 2.0) * cos(vWorldPos.z * 1.1));
                    if (!inCave && h < 0.52) {
                        fragColor = vec4(soil, 1.0);
                        return;
                    }
                    float gCol = floor(clamp(h * 10.0 + ridge * 6.0, 0.0, 15.0));
                    vec2 aUv = (vec2(gCol, 4.0) + cUv) / vec2(16.0, 6.0);
                    float m = texture(uAtlas, aUv).a;
                    vec3 glyphTone = inCave
                        ? mix(vec3(0.18, 0.23, 0.32), vec3(0.68, 0.76, 0.88), pow(ridge, 2.0))
                        : vec3(0.16, 0.24, 0.28);
                    vec3 col = mix(soil, glyphTone, m * (inCave ? (0.35 + 0.65 * ridge) : 0.55));
                    fragColor = vec4(col, 1.0);
                    return;
                }

                // Fine, high-density micro-ASCII cells on characters (4.2px) vs bold glyphs on cliffs (8.5px)
                vec2 cellDim = vec2(max(3.8, uCellScale), max(5.0, uCellScale * 1.30));
                vec2 scGrid = gl_FragCoord.xy / cellDim;
                vec2 cellId = floor(scGrid);
                vec2 cellUv = fract(scGrid);
                cellUv.y = 1.0 - cellUv.y;

                if (uMaterialMode == 3 || uMaterialMode == 4) {
                    float lum = clamp(diff * 0.54 + spec * 0.96 + rim * 0.58, 0.05, 0.99);
                    float idx = (spec > 0.32 || rim > 0.54) ? (22.0 + floor(lum * 9.0))
                              : (diff > 0.34 ? (8.0 + floor(lum * 13.0)) : (3.0 + floor(lum * 6.0)));
                    vec2 atlasUv = (vec2(mod(idx, 16.0), floor(idx / 16.0)) + cellUv) / vec2(16.0, 6.0);
                    float mask = texture(uAtlas, atlasUv).a;
                    vec3 obsidianBack = vec3(0.012, 0.016, 0.020);
                    vec3 glyphRgb;
                    if (uMaterialMode == 4) {
                        glyphRgb = (rim > 0.60) ? vec3(0.96, 0.55, 0.55) : (uBaseColor * (0.42 + 0.85 * lum));
                    } else {
                        glyphRgb = (spec > 0.32 || rim > 0.54) ? vec3(0.96, 0.98, 1.0) : (uBaseColor * (0.38 + 0.80 * lum));
                    }
                    // Subtle underlying 3D armor shading + crisp ASCII glyph highlight so human contours stay 100% readable
                    vec3 baseShade = uBaseColor * (0.14 + 0.24 * diff + 0.22 * rim);
                    vec3 finalRgb = mix(max(obsidianBack, baseShade * 0.45), glyphRgb, clamp(mask * 1.15, 0.0, 1.0));
                    fragColor = vec4(finalRgb, 1.0);
                    return;
                }

                if (uMaterialMode == 1) {
                    float lum = clamp(diff * 0.82 + spec * 0.45 + rim * 0.38, 0.05, 0.99);
                    float ringRow = floor(vUv.y * 26.0);
                    float ringCol = floor(vUv.x * 38.0 + mod(ringRow, 2.0) * 0.5);
                    float h = hash12(vec2(ringCol, ringRow) + cellId * 0.15);
                    float glyphCol = floor(clamp(lum * 11.0 + h * 5.0, 1.0, 15.0));
                    vec2 atlasUv = (vec2(glyphCol, 2.0) + cellUv) / vec2(16.0, 6.0);
                    float mask = texture(uAtlas, atlasUv).a;
                    vec3 litGlyph = uBaseColor * (0.22 + 0.92 * lum);
                    fragColor = vec4(mix(vec3(0.01, 0.012, 0.015), litGlyph, mask), 1.0);
                    return;
                }

                float lum = clamp(diff * 0.76 + rim * 0.48 + spec * 0.25, 0.05, 0.99);
                float h = hash12(cellId);
                float idx = clamp(floor((lum * 0.78 + h * 0.22) * 31.0), 2.0, 31.0);
                float glyphCol = mod(idx, 16.0);
                float glyphRow = floor(idx / 16.0);

                vec2 atlasUv = (vec2(glyphCol, glyphRow) + cellUv) / vec2(16.0, 6.0);
                float mask = texture(uAtlas, atlasUv).a;
                vec3 darkBack = vec3(0.014, 0.019, 0.025);
                vec3 litGlyph = uBaseColor * (0.26 + 0.86 * lum);
                vec3 col = mix(darkBack, litGlyph, mask);

                float dist = length(vWorldPos.xz - uCamPos.xz);
                float mistWave = sin(vWorldPos.x * 0.35 + vWorldPos.z * 0.28 - uTime * 0.55)
                               * cos(vWorldPos.x * 0.22 - vWorldPos.z * 0.41 + uTime * 0.38);
                float lowMist = clamp((1.6 - vWorldPos.y) * 0.45, 0.0, 1.0) * smoothstep(0.15, 0.75, mistWave * 0.5 + 0.5) * 0.28;
                float fog = clamp((dist - 19.0) / 28.0, 0.0, 0.52) + lowMist;
                fragColor = vec4(mix(col, vec3(0.52, 0.60, 0.63), clamp(fog, 0.0, 0.65)), 1.0);
            }
        """.trimIndent()

        val vsGrass = """
            #version 300 es
            layout(location = 0) in vec4 aRibbon;
            layout(location = 1) in vec4 aInst;
            uniform mat4 uVP;
            uniform vec3 uPlayerPos;
            uniform vec3 uCamRight;
            uniform float uTime;
            uniform float uRiverPhase;
            uniform float uRiverAmp;
            uniform float uRiverHalfW;
            out vec2 vUv;
            out vec3 vColor;
            out vec2 vAtlasCell;
            out float vFog;
            void main() {
                vec2 tile = floor((uPlayerPos.xz - aInst.xy + 22.0) / 44.0) * 44.0 + aInst.xy;
                float riverZ = -6.5 + sin(tile.x * 0.13 + uRiverPhase) * uRiverAmp
                             + cos(tile.x * 0.055 - uRiverPhase * 0.5) * 1.35;
                if (uRiverHalfW > 0.01 && abs(tile.y - riverZ) < uRiverHalfW + 0.15) {
                    gl_Position = vec4(0.0, 0.0, -2.0, 1.0);
                    return;
                }
                vec2 dCave = tile - vec2(0.0, -19.5);
                if (dot(dCave, dCave) < 6.8 * 6.8) {
                    gl_Position = vec4(0.0, 0.0, -2.0, 1.0);
                    return;
                }

                bool nearCaveMouth = (tile.y < -7.0 && tile.y > -14.5 && abs(tile.x) < 9.5);
                bool isFlower = (aInst.w >= 100.0) || (nearCaveMouth && mod(aInst.w, 4.0) < 1.0);

                float sway = sin(tile.x * 0.55 + tile.y * 0.45 - uTime * 2.4) * 0.11 * aRibbon.y;
                float wScale = isFlower ? 0.18 : 0.115;
                vec3 worldPos = vec3(tile.x, uPlayerPos.y, tile.y)
                              + uCamRight * (aRibbon.x * wScale + sway)
                              + vec3(0.0, aRibbon.y * aInst.z, 0.0);

                float dPlayer = length(tile - (uPlayerPos.xz + vec2(0.32, 0.22)));
                float shadow = smoothstep(0.32, 1.30, dPlayer);
                float canyonShadow = smoothstep(1.6, 3.4, length(tile - vec2(-4.2, 3.5)))
                                   * smoothstep(1.6, 3.4, length(tile - vec2(5.4, 2.8)));
                shadow *= (0.45 + 0.55 * canyonShadow);

                if (isFlower) {
                    float fType = mod(aInst.w, 5.0);
                    vAtlasCell = vec2(6.0 + mod(fType, 4.0), 3.0);
                    vec3 fCol = (fType < 2.0) ? vec3(0.76, 0.60, 0.95)
                              : (fType < 3.5 ? vec3(0.94, 0.96, 0.92) : vec3(0.66, 0.50, 0.88));
                    vColor = fCol * (0.45 + 0.55 * shadow);
                } else {
                    vAtlasCell = vec2(mod(aInst.w, 6.0), 3.0);
                    float shade = fract(aInst.w * 0.173 + sin(tile.x * 0.25 + tile.y * 0.25) * 0.2);
                    vec3 rootCol = vec3(0.03, 0.10, 0.045);
                    vec3 tipCol = mix(vec3(0.13, 0.37, 0.16), vec3(0.36, 0.65, 0.31), shade);
                    vColor = mix(rootCol, tipCol, aRibbon.y) * (0.28 + 0.72 * shadow);
                }

                float m1 = sin(tile.x * 0.32 + tile.y * 0.24 - uTime * 0.62);
                float m2 = cos(tile.x * 0.19 - tile.y * 0.37 + uTime * 0.44);
                float mistRibbon = smoothstep(0.35, 0.88, m1 * m2 + 0.35) * 0.44;
                float distCam = length(tile - uPlayerPos.xz);
                vFog = clamp((distCam - 15.0) / 22.0, 0.0, 0.46) + mistRibbon;
                vUv = aRibbon.zw;
                gl_Position = uVP * vec4(worldPos, 1.0);
            }
        """.trimIndent()

        val fsGrass = """
            #version 300 es
            precision mediump float;
            in vec2 vUv;
            in vec3 vColor;
            in vec2 vAtlasCell;
            in float vFog;
            uniform sampler2D uAtlas;
            out vec4 fragColor;
            void main() {
                vec2 atlasUv = (vAtlasCell + vUv) / vec2(16.0, 6.0);
                float a = texture(uAtlas, atlasUv).a;
                if (a < 0.24) discard;
                vec3 col = mix(vColor, vec3(0.56, 0.64, 0.66), clamp(vFog, 0.0, 0.68));
                fragColor = vec4(col, 1.0);
            }
        """.trimIndent()

        val vsWater = """
            #version 300 es
            layout(location = 0) in vec3 aPos;
            uniform mat4 uMVP;
            uniform mat4 uModel;
            out vec3 vWorldPos;
            out vec4 vClipPos;
            void main() {
                vec4 wp = uModel * vec4(aPos, 1.0);
                vWorldPos = wp.xyz;
                vClipPos = uMVP * vec4(aPos, 1.0);
                gl_Position = vClipPos;
            }
        """.trimIndent()

        val fsWater = """
            #version 300 es
            precision mediump float;
            in vec3 vWorldPos;
            in vec4 vClipPos;
            uniform sampler2D uAtlas;
            uniform sampler2D uReflectTex;
            uniform float uTime;
            out vec4 fragColor;
            void main() {
                vec2 p = vWorldPos.xz;
                float w1 = sin(p.x * 1.6 + p.y * 1.1 - uTime * 2.5);
                float w2 = cos(p.x * 0.9 - p.y * 1.9 + uTime * 1.9);
                vec3 N = normalize(vec3(w1 * 0.26, 1.0, w2 * 0.26));
                vec3 L = normalize(vec3(-0.45, 0.65, 0.60));
                float spec = pow(max(0.0, dot(N, L)), 14.0);

                vec2 ndc = (vClipPos.xy / max(0.001, vClipPos.w)) * 0.5 + 0.5;
                vec2 reflUv = clamp(vec2(ndc.x, 1.0 - ndc.y) + N.xz * 0.032, 0.01, 0.99);
                vec3 reflCol = texture(uReflectTex, reflUv).rgb;

                vec2 cellUv = fract(vec2(p.x * 4.2, p.y * 5.6));
                float glyphIdx = floor(clamp((spec * 1.4 + length(reflCol) * 0.55), 0.0, 0.99) * 15.0);
                vec2 atlasUv = (vec2(glyphIdx, 5.0) + cellUv) / vec2(16.0, 6.0);
                float gMask = texture(uAtlas, atlasUv).a;

                vec3 deepWater = vec3(0.018, 0.028, 0.048);
                vec3 streakCol = vec3(0.76, 0.85, 0.95) * gMask * smoothstep(0.32, 0.86, spec + w1 * 0.24);
                vec3 asciiRefl = reflCol * (0.35 + 0.65 * gMask);
                vec3 col = deepWater + asciiRefl * 0.85 + streakCol;
                fragColor = vec4(col, 1.0);
            }
        """.trimIndent()

        progMeshAscii = linkProgram(vsMesh, fsMesh)
        progGrassInstanced = linkProgram(vsGrass, fsGrass)
        progWaterAscii = linkProgram(vsWater, fsWater)
    }

    private fun linkProgram(vsSrc: String, fsSrc: String): Int {
        val vs = GLES30.glCreateShader(GLES30.GL_VERTEX_SHADER)
        GLES30.glShaderSource(vs, vsSrc)
        GLES30.glCompileShader(vs)

        val fs = GLES30.glCreateShader(GLES30.GL_FRAGMENT_SHADER)
        GLES30.glShaderSource(fs, fsSrc)
        GLES30.glCompileShader(fs)

        val prog = GLES30.glCreateProgram()
        GLES30.glAttachShader(prog, vs)
        GLES30.glAttachShader(prog, fs)
        GLES30.glLinkProgram(prog)
        return prog
    }

    private fun render3DOpenWorldScene() {
        val aspect = width / height.toFloat()
        Matrix.perspectiveM(projMatrix, 0, 40.0f / state.cameraZoom, aspect, 0.5f, 120.0f)

        val cursorOffX = if (state.cursorViewMode) (state.cursorX - 0.5f) * 2.4f else 0.0f
        val cursorOffZ = if (state.cursorViewMode) (state.cursorY - 0.5f) * 2.4f else 0.0f
        val targetX = state.playerX + cursorOffX
        val targetZ = state.playerZ + cursorOffZ

        val camDist = 9.8f / state.cameraZoom
        val camHeight = state.groundY + 9.0f / state.cameraZoom
        val eyeX = targetX + sin(state.camYaw) * camDist
        val eyeY = camHeight
        val eyeZ = targetZ + cos(state.camYaw) * camDist

        if (state.genRivers) {
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, reflectFbo)
            GLES30.glViewport(0, 0, REFLECT_W, REFLECT_H)
            GLES30.glClearColor(0.015f, 0.024f, 0.038f, 1.0f)
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

            Matrix.setLookAtM(
                reflectViewMatrix, 0,
                eyeX, -eyeY * 0.65f, eyeZ,
                targetX, 0.0f, targetZ,
                0f, 1f, 0f
            )
            Matrix.multiplyMM(reflectVpMatrix, 0, projMatrix, 0, reflectViewMatrix, 0)
            draw3DEntitiesAndLandscape(reflectVpMatrix, eyeX, -eyeY * 0.65f, eyeZ)
        }

        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        GLES30.glViewport(0, 0, width, height)
        GLES30.glClearColor(0.020f, 0.032f, 0.028f, 1.0f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

        Matrix.setLookAtM(
            viewMatrix, 0,
            eyeX, eyeY, eyeZ,
            targetX, state.groundY + 0.45f, targetZ,
            0f, 1f, 0f
        )
        Matrix.multiplyMM(vpMatrix, 0, projMatrix, 0, viewMatrix, 0)

        drawGroundPlane(vpMatrix, eyeX, eyeY, eyeZ)
        if (state.genRivers) {
            drawWaterSurface(vpMatrix)
        }
        draw3DEntitiesAndLandscape(vpMatrix, eyeX, eyeY, eyeZ)
        if (!state.debugSolidMode) {
            drawInstanced3DGrass(vpMatrix)
        }
    }

    private fun bindQuadVbo() {
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, quadVbo)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 32, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 32, 12)
        GLES30.glEnableVertexAttribArray(2)
        GLES30.glVertexAttribPointer(2, 2, GLES30.GL_FLOAT, false, 32, 24)
    }

    private fun bindIndexedVbo(vbo: Int, ibo: Int) {
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 32, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 32, 12)
        GLES30.glEnableVertexAttribArray(2)
        GLES30.glVertexAttribPointer(2, 2, GLES30.GL_FLOAT, false, 32, 24)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, ibo)
    }

    private fun drawGroundPlane(vp: FloatArray, eyeX: Float, eyeY: Float, eyeZ: Float) {
        GLES30.glUseProgram(progMeshAscii)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, glyphAtlasTex)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uAtlas"), 0)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uCamPos"), eyeX, eyeY, eyeZ)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progMeshAscii, "uCellScale"), 8.0f)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uMaterialMode"), 2)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uDebugSolid"), if (state.debugSolidMode) 1 else 0)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progMeshAscii, "uTime"), state.timeSec)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 0.08f, 0.16f, 0.10f)

        bindQuadVbo()
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, state.playerX, state.groundY - 0.02f, state.playerZ)
        Matrix.scaleM(modelMatrix, 0, 90.0f, 1.0f, 90.0f)
        Matrix.multiplyMM(mvpMatrix, 0, vp, 0, modelMatrix, 0)

        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(progMeshAscii, "uMVP"), 1, false, mvpMatrix, 0)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(progMeshAscii, "uModel"), 1, false, modelMatrix, 0)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 6)

        if (state.vortexActiveTimer > 0.0f) {
            GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uMaterialMode"), 5)
            Matrix.setIdentityM(modelMatrix, 0)
            Matrix.translateM(modelMatrix, 0, state.vortexX, state.vortexY + 0.02f, state.vortexZ)
            Matrix.scaleM(modelMatrix, 0, 1.45f, 1.0f, 1.45f)
            Matrix.multiplyMM(mvpMatrix, 0, vp, 0, modelMatrix, 0)
            GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(progMeshAscii, "uMVP"), 1, false, mvpMatrix, 0)
            GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(progMeshAscii, "uModel"), 1, false, modelMatrix, 0)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 6)
        }

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
    }

    private fun drawWaterSurface(vp: FloatArray) {
        GLES30.glUseProgram(progWaterAscii)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, glyphAtlasTex)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progWaterAscii, "uAtlas"), 0)

        GLES30.glActiveTexture(GLES30.GL_TEXTURE1)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, reflectTex)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progWaterAscii, "uReflectTex"), 1)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progWaterAscii, "uTime"), state.timeSec)

        val halfW = WorldGenerator.riverHalfWidth(state.worldType, state.genRivers)
        bindQuadVbo()
        for (seg in -8..8) {
            val wx = state.playerX + seg * 5.2f
            val wz = WorldGenerator.riverCenterZ(wx, state.worldSeed, state.worldType)
            Matrix.setIdentityM(modelMatrix, 0)
            Matrix.translateM(modelMatrix, 0, wx, 0.01f, wz)
            Matrix.scaleM(modelMatrix, 0, 2.8f, 1.0f, halfW)
            Matrix.multiplyMM(mvpMatrix, 0, vp, 0, modelMatrix, 0)

            GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(progWaterAscii, "uMVP"), 1, false, mvpMatrix, 0)
            GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(progWaterAscii, "uModel"), 1, false, modelMatrix, 0)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 6)
        }
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
    }

    private fun draw3DEntitiesAndLandscape(vp: FloatArray, eyeX: Float, eyeY: Float, eyeZ: Float) {
        GLES30.glUseProgram(progMeshAscii)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, glyphAtlasTex)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uAtlas"), 0)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uCamPos"), eyeX, eyeY, eyeZ)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uDebugSolid"), if (state.debugSolidMode) 1 else 0)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progMeshAscii, "uTime"), state.timeSec)

        // 1. Render Seeded Procedural Chunks using Organic Craggy Rock & Tree Meshes
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uMaterialMode"), 0)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progMeshAscii, "uCellScale"), 8.5f)

        bindIndexedVbo(rockVbo, rockIbo)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 0.78f, 0.85f, 0.92f)
        for (cIdx in 0 until WorldGenerator.MAX_CACHED_CHUNKS) {
            val chunk = WorldGenerator.chunkGrid[cIdx]
            if (chunk.builtSeed == Long.MIN_VALUE) continue
            for (rIdx in 0 until chunk.rockCount) {
                val rf = chunk.rocks[rIdx]
                val dx = rf.x - state.playerX
                val dz = rf.z - state.playerZ
                if (dx * dx + dz * dz > 46.0f * 46.0f) continue
                drawPart(vp, rockIndexCount, rf.x, rf.y + rf.heightY * 0.35f, rf.z, (rIdx * 37).toFloat(), 0f, rf.radiusX, rf.heightY, rf.radiusZ)
            }
            if (chunk.hasShrine) {
                val dx = chunk.shrineX - state.playerX
                val dz = chunk.shrineZ - state.playerZ
                if (dx * dx + dz * dz < 42.0f * 42.0f) {
                    GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 0.92f, 0.84f, 0.56f)
                    drawPart(vp, rockIndexCount, chunk.shrineX, chunk.shrineY + 1.15f, chunk.shrineZ, 0f, 0f, 0.75f, 2.6f, 0.75f)
                    GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 0.78f, 0.85f, 0.92f)
                }
            }
        }

        // Tapered Organic Tree Trunks
        bindIndexedVbo(trunkVbo, trunkIbo)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 0.42f, 0.34f, 0.26f)
        for (cIdx in 0 until WorldGenerator.MAX_CACHED_CHUNKS) {
            val chunk = WorldGenerator.chunkGrid[cIdx]
            if (chunk.builtSeed == Long.MIN_VALUE) continue
            for (tIdx in 0 until chunk.treeCount) {
                val tr = chunk.trees[tIdx]
                val dx = tr.x - state.playerX
                val dz = tr.z - state.playerZ
                if (dx * dx + dz * dz > 44.0f * 44.0f) continue
                drawPart(vp, trunkIndexCount, tr.x, tr.y + tr.heightY * 0.45f, tr.z, 0f, 0f, 0.55f, tr.heightY, 0.55f)
            }
        }

        // Layered Tree Canopies
        bindIndexedVbo(sphereVbo, sphereIbo)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 0.24f, 0.60f, 0.28f)
        for (cIdx in 0 until WorldGenerator.MAX_CACHED_CHUNKS) {
            val chunk = WorldGenerator.chunkGrid[cIdx]
            if (chunk.builtSeed == Long.MIN_VALUE) continue
            for (tIdx in 0 until chunk.treeCount) {
                val tr = chunk.trees[tIdx]
                val dx = tr.x - state.playerX
                val dz = tr.z - state.playerZ
                if (dx * dx + dz * dz > 44.0f * 44.0f) continue
                drawPart(vp, sphereIndexCount, tr.x, tr.y + tr.heightY * 0.92f, tr.z, 0f, 0f, tr.radiusX, tr.radiusX * 0.85f, tr.radiusX)
                drawPart(vp, sphereIndexCount, tr.x - 0.38f, tr.y + tr.heightY * 1.15f, tr.z + 0.28f, 0f, 0f, tr.radiusX * 0.76f, tr.radiusX * 0.72f, tr.radiusX * 0.76f)
            }
        }

        // Bioluminescent Cave Crystals & Loot Drops
        bindIndexedVbo(bladeVbo, bladeIbo)
        for (cIdx in 0 until WorldGenerator.MAX_CACHED_CHUNKS) {
            val chunk = WorldGenerator.chunkGrid[cIdx]
            if (chunk.builtSeed == Long.MIN_VALUE) continue
            for (gIdx in 0 until chunk.crystalCount) {
                val cr = chunk.crystals[gIdx]
                val dx = cr.x - state.playerX
                val dz = cr.z - state.playerZ
                if (dx * dx + dz * dz > 42.0f * 42.0f) continue
                if (cr.variant == 0) {
                    GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 0.72f, 0.92f, 1.0f)
                } else {
                    GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 0.86f, 0.68f, 1.0f)
                }
                drawPart(vp, bladeIndexCount, cr.x, cr.y, cr.z, 18f, -90f, cr.radiusX, cr.radiusX, cr.heightY)
            }
        }
        for (l in 0 until GameState.MAX_LOOT) {
            if (state.lootActive[l]) {
                setPartColor(state.lootMetal[l], false)
                drawPart(vp, bladeIndexCount, state.lootX[l], state.lootY[l] + 0.05f, state.lootZ[l], state.timeSec * 65f, -90f, 0.35f, 0.35f, 0.65f)
            }
        }

        // 2. Sculpted Anatomical 3D Humanoid Player Adventurer (`Senje`)
        val spd = sqrt(state.velX * state.velX + state.velZ * state.velZ)
        drawConnected3DHumanoid(
            vp, state.playerX, state.playerY, state.playerZ, state.bodyYaw,
            state.gaitPhase, min(1.1f, spd / 4.2f), state.slashTimer / 0.28f,
            state.dodgeTimer > 0.0f, state.playerY > state.groundY + 0.05f,
            state.slotMetal, state.mounted, state.hurtFlash > 0.0f, true
        )

        // 3. Sculpted Anatomical 3D Humanoid Enemies
        for (i in 0 until GameState.NUM_ENEMIES) {
            val dx = state.enemyX[i] - state.playerX
            val dz = state.enemyZ[i] - state.playerZ
            if (dx * dx + dz * dz > 36.0f * 36.0f) continue
            val eMove = if (state.enemyAggro[i] && state.enemyWindup[i] <= 0.0f) 0.85f else 0.0f
            val eMet = state.enemyMetal[i]
            val eSlots = intArrayOf(eMet, eMet, eMet, eMet, eMet, eMet, eMet)
            drawConnected3DHumanoid(
                vp, state.enemyX[i], state.enemyY[i], state.enemyZ[i], state.enemyYaw[i],
                state.enemyGait[i], eMove, state.enemyWindup[i] / 0.42f,
                false, false, eSlots, false, state.enemyHurt[i] > 0.0f, false
            )
        }

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, 0)
    }

    /**
     * Renders a continuous, sculpted 3D human knight using anatomical lofted meshes
     * (`torsoVbo`, `helmVbo`, `pauldronVbo`, `armVbo`, `legVbo`, `bootVbo`, `cloakVbo`, `shieldVbo`, `bladeVbo`)
     * that pivot directly from the hip and shoulder sockets with fine 4.2px micro-ASCII density.
     */
    private fun drawConnected3DHumanoid(
        vp: FloatArray,
        wx: Float,
        wy: Float,
        wz: Float,
        yawRad: Float,
        gait: Float,
        moveAmt: Float,
        slashProg: Float,
        dodging: Boolean,
        jumping: Boolean,
        slotMetals: IntArray,
        mounted: Boolean,
        hurtFlash: Boolean,
        isPlayer: Boolean
    ) {
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uMaterialMode"), 3)
        // Fine 4.2px ASCII cell scale on the player so the human silhouette, visor, pauldrons, cloak & limbs are crystal clear
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progMeshAscii, "uCellScale"), if (isPlayer) 4.2f else 4.8f)

        val s = if (isPlayer) 1.38f else 1.24f
        val yawDeg = Math.toDegrees(yawRad.toDouble()).toFloat()
        val sinY = sin(yawRad)
        val cosY = cos(yawRad)
        val rightX = cosY
        val rightZ = -sinY

        val breathe = sin(state.timeSec * 2.5f) * 0.012f
        val bounce = abs(sin(gait)) * 0.055f * moveAmt
        val crouch = if (dodging) 0.18f else 0.0f
        val mountH = if (mounted) 0.72f else 0.0f
        val hipY = wy + mountH - crouch + (0.82f + bounce) * s

        // Ground contact shadow
        bindIndexedVbo(sphereVbo, sphereIbo)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 0.012f, 0.018f, 0.016f)
        drawPart(vp, sphereIndexCount, wx + 0.14f * s, wy + 0.015f, wz + 0.10f * s, yawDeg, 0f, 0.68f * s, 0.03f, 0.52f * s)

        if (mounted) {
            // Sculpted Steed body & legs using lofted torso/leg meshes
            bindIndexedVbo(torsoVbo, torsoIbo)
            GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 0.84f, 0.88f, 0.94f)
            drawPart(vp, torsoIndexCount, wx - sinY * 0.45f, wy + 0.66f + bounce, wz - cosY * 0.45f, yawDeg, 90f, 1.35f, 1.85f, 1.35f)
            bindIndexedVbo(legVbo, legIbo)
            for (leg in 0..3) {
                val lx = if (leg % 2 == 0) -0.20f else 0.20f
                val lz = if (leg < 2) 0.42f else -0.42f
                val swDeg = sin(gait + leg * 1.57f) * 24.0f * moveAmt
                drawPart(vp, legIndexCount, wx + rightX * lx + sinY * lz, wy + 0.68f, wz + rightZ * lx + cosY * lz, yawDeg, swDeg, 0.85f, 0.85f, 0.85f)
            }
        }

        // 1. Sculpted Human Legs & Armored Sabaton Boots (Pivoting directly from the Hip Socket `hipY`!)
        for (leg in 0..1) {
            val side = (if (leg == 0) -0.112f else 0.112f) * s
            val ph = gait + (if (leg == 1) PI.toFloat() else 0.0f)
            val swingDeg = if (jumping) (if (leg == 0) 24f else -20f) else (sin(ph) * 28.0f * moveAmt)
            val hipX = wx + rightX * side
            val hipZ = wz + rightZ * side

            // Thigh + Knee Poleyn + Calf Greave (Slot 5 = Legs)
            bindIndexedVbo(legVbo, legIbo)
            setPartColor(slotMetals[5], hurtFlash)
            drawPart(vp, legIndexCount, hipX, hipY, hipZ, yawDeg, swingDeg, s, s, s)

            // Armored Sabaton Boot (Slot 6 = Boots, sharing exact same hip pivot & swingDeg!)
            bindIndexedVbo(bootVbo, bootIbo)
            setPartColor(slotMetals[6], hurtFlash)
            drawPart(vp, bootIndexCount, hipX, hipY, hipZ, yawDeg, swingDeg, s, s, s)
        }

        // 2. Continuous Sculpted Human Pelvis, Waist, Cuirass Chest & Neck (Slot 3 = Chest)
        val forwardLean = moveAmt * 5.5f + (if (dodging) 16.0f else 0.0f)
        bindIndexedVbo(torsoVbo, torsoIbo)
        setPartColor(slotMetals[3], hurtFlash)
        drawPart(vp, torsoIndexCount, wx, hipY + breathe * s, wz, yawDeg, forwardLean, s, s, s)

        // 3. Visored Sallet Helmet + Pointed Knight Crest (Slot 1 = Helm)
        bindIndexedVbo(helmVbo, helmIbo)
        setPartColor(slotMetals[1], hurtFlash)
        drawPart(vp, helmIndexCount, wx, hipY + breathe * s, wz, yawDeg, forwardLean, s, s, s)

        // 4. Draped, Pleated 3D Traveler Cloak (`1000461483.jpg` & `1000461463.jpg`)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uMaterialMode"), 4)
        if (isPlayer) {
            GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 0.82f, 0.17f, 0.20f)
        } else {
            GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 0.32f, 0.37f, 0.43f)
        }
        val capeFlutterDeg = forwardLean + moveAmt * 12.0f + sin(state.capeWavePhase) * 5.0f
        bindIndexedVbo(cloakVbo, cloakIbo)
        drawPart(vp, cloakIndexCount, wx, hipY + breathe * s, wz, yawDeg, capeFlutterDeg, s, s, s)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uMaterialMode"), 3)

        // 5. Curved Shoulder Pauldrons (Slot 2 = Shoulders)
        val shY = hipY + (0.44f + breathe) * s
        val shSpan = 0.228f * s
        bindIndexedVbo(pauldronVbo, pauldronIbo)
        setPartColor(slotMetals[2], hurtFlash)
        for (side in intArrayOf(-1, 1)) {
            drawPart(vp, pauldronIndexCount, wx + rightX * (side * shSpan), shY, wz + rightZ * (side * shSpan), yawDeg, forwardLean, s, s, s)
        }

        // 6. Left Arm (pivoting at Left Shoulder Socket) + Curved Medieval Kite Shield (`1000461482.jpg`)
        val lShX = wx - rightX * shSpan
        val lShZ = wz - rightZ * shSpan
        val lArmSwingDeg = -sin(gait) * 22.0f * moveAmt
        bindIndexedVbo(armVbo, armIbo)
        setPartColor(slotMetals[4], hurtFlash)
        drawPart(vp, armIndexCount, lShX, shY, lShZ, yawDeg, lArmSwingDeg, s, s, s)

        // Curved Kite Shield mounted on Left Forearm
        bindIndexedVbo(shieldVbo, shieldIbo)
        setPartColor(slotMetals[2], hurtFlash)
        drawPart(
            vp, shieldIndexCount,
            lShX - rightX * 0.08f * s + sinY * 0.06f * s,
            shY - 0.34f * s,
            lShZ - rightZ * 0.08f * s + cosY * 0.06f * s,
            yawDeg - 68f, lArmSwingDeg * 0.5f, s, s, s
        )

        // 7. Right Sword Arm (pivoting at Right Shoulder Socket) + Greatsword Blade (Slot 0 = Weapon)
        val rShX = wx + rightX * shSpan
        val rShZ = wz + rightZ * shSpan
        val rArmPitchDeg = if (slashProg > 0.0f) (-55.0f + (1.0f - slashProg) * 115.0f) else (22.0f + sin(gait) * 18.0f * moveAmt)
        bindIndexedVbo(armVbo, armIbo)
        setPartColor(slotMetals[4], hurtFlash)
        drawPart(vp, armIndexCount, rShX, shY, rShZ, yawDeg, rArmPitchDeg, s, s, s)

        // Gleaming Diamond-Profile Greatsword extending from Right Gauntlet Fist
        val slashAng = if (slashProg > 0.0f) (-1.25f + (1.0f - slashProg) * 2.5f) else 0.22f
        val swordYawDeg = Math.toDegrees((yawRad + slashAng).toDouble()).toFloat()
        val sDirX = sin(yawRad + slashAng)
        val sDirZ = cos(yawRad + slashAng)
        val handX = rShX + sDirX * 0.14f * s
        val handY = shY - 0.48f * s
        val handZ = rShZ + sDirZ * 0.14f * s

        bindIndexedVbo(bladeVbo, bladeIbo)
        setPartColor(slotMetals[0], false)
        // Crossguard
        drawPart(vp, bladeIndexCount, handX - rightX * 0.14f * s, handY, handZ - rightZ * 0.14f * s, swordYawDeg + 90f, 0f, 0.05f * s, 0.05f * s, 0.28f * s)
        // Main Greatsword Blade
        drawPart(vp, bladeIndexCount, handX, handY, handZ, swordYawDeg, 12f, 0.075f * s, 0.055f * s, 0.94f * s)

        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uMaterialMode"), 0)
    }

    private fun setPartColor(metalIdx: Int, hurtFlash: Boolean) {
        if (hurtFlash) {
            GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 1.0f, 0.28f, 0.28f)
        } else {
            val rgb = GameState.METAL_RGB[metalIdx.coerceIn(0, 9)]
            GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), rgb[0], rgb[1], rgb[2])
        }
    }

    private fun drawPart(
        vp: FloatArray,
        indexCount: Int,
        x: Float,
        y: Float,
        z: Float,
        yawDeg: Float,
        pitchDeg: Float,
        sx: Float,
        sy: Float,
        sz: Float
    ) {
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, x, y, z)
        if (yawDeg != 0.0f) {
            Matrix.rotateM(modelMatrix, 0, yawDeg, 0f, 1f, 0f)
        }
        if (pitchDeg != 0.0f) {
            Matrix.rotateM(modelMatrix, 0, pitchDeg, 1f, 0f, 0f)
        }
        Matrix.scaleM(modelMatrix, 0, sx, sy, sz)
        Matrix.multiplyMM(mvpMatrix, 0, vp, 0, modelMatrix, 0)

        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(progMeshAscii, "uMVP"), 1, false, mvpMatrix, 0)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(progMeshAscii, "uModel"), 1, false, modelMatrix, 0)
        GLES30.glDrawElements(GLES30.GL_TRIANGLES, indexCount, GLES30.GL_UNSIGNED_SHORT, 0)
    }

    private fun drawInstanced3DGrass(vp: FloatArray) {
        GLES30.glUseProgram(progGrassInstanced)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, glyphAtlasTex)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progGrassInstanced, "uAtlas"), 0)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(progGrassInstanced, "uVP"), 1, false, vp, 0)
        GLES30.glUniform3f(
            GLES30.glGetUniformLocation(progGrassInstanced, "uPlayerPos"),
            state.playerX, state.groundY, state.playerZ
        )
        GLES30.glUniform3f(
            GLES30.glGetUniformLocation(progGrassInstanced, "uCamRight"),
            cos(state.camYaw), 0.0f, -sin(state.camYaw)
        )
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progGrassInstanced, "uTime"), state.timeSec)

        val phase = ((state.worldSeed and 0xFFFFL).toFloat() / 65535.0f) * 6.28318f
        val amp = if (state.worldType == 3) 3.4f else 2.2f
        val halfW = WorldGenerator.riverHalfWidth(state.worldType, state.genRivers)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progGrassInstanced, "uRiverPhase"), phase)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progGrassInstanced, "uRiverAmp"), amp)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progGrassInstanced, "uRiverHalfW"), halfW)

        GLES30.glDisableVertexAttribArray(2)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, grassRibbonVbo)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 4, GLES30.GL_FLOAT, false, 16, 0)
        GLES30.glVertexAttribDivisor(0, 0)

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, grassInstanceVbo)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 4, GLES30.GL_FLOAT, false, 16, 0)
        GLES30.glVertexAttribDivisor(1, 1)

        val count = when (state.qualityPreset) {
            0 -> 10000
            1 -> 20000
            else -> MAX_GRASS_INSTANCES
        }
        GLES30.glDrawArraysInstanced(GLES30.GL_TRIANGLES, 0, 6, count)

        GLES30.glVertexAttribDivisor(1, 0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
    }

    private fun render3DChainmailEquipmentScene() {
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        GLES30.glViewport(0, 0, width, height)
        GLES30.glClearColor(0.0f, 0.0f, 0.0f, 1.0f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

        val aspect = width / height.toFloat()
        Matrix.perspectiveM(projMatrix, 0, 38.0f / state.previewZoom, aspect, 0.5f, 30.0f)
        Matrix.setLookAtM(viewMatrix, 0, 0.65f, 0.35f, 4.2f, 0.45f, -0.15f, 0.0f, 0f, 1f, 0f)
        Matrix.multiplyMM(vpMatrix, 0, projMatrix, 0, viewMatrix, 0)

        GLES30.glUseProgram(progMeshAscii)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, glyphAtlasTex)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uAtlas"), 0)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uCamPos"), 0.65f, 0.35f, 4.2f)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progMeshAscii, "uCellScale"), 8.2f)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uDebugSolid"), if (state.debugSolidMode) 1 else 0)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progMeshAscii, "uTime"), state.timeSec)

        if (state.previewFullHero) {
            drawConnected3DHumanoid(
                vpMatrix, -0.35f, -1.05f, 0.0f, state.previewYaw,
                state.timeSec * 2.0f, 0.35f, 0.0f,
                false, false, state.slotMetal, false, false, true
            )
        } else {
            bindIndexedVbo(sphereVbo, sphereIbo)
            GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uMaterialMode"), 1)
            setPartColor(state.activeMetal, false)
            val yawDeg = Math.toDegrees(state.previewYaw.toDouble()).toFloat()

            drawPart(vpMatrix, sphereIndexCount, -0.35f, 0.30f, 0.0f, yawDeg, 0f, 0.96f, 1.08f, 0.96f)
            drawPart(vpMatrix, sphereIndexCount, -0.35f, -0.36f, 0.0f, yawDeg, 0f, 1.56f, 0.86f, 1.36f)
            drawPart(vpMatrix, sphereIndexCount, -0.35f, -0.68f, 0.0f, yawDeg, 0f, 1.98f, 0.46f, 1.68f)
        }

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, 0)
    }

    companion object {
        private const val REFLECT_W = 512
        private const val REFLECT_H = 512
        private const val MAX_GRASS_INSTANCES = 32000
    }
}
