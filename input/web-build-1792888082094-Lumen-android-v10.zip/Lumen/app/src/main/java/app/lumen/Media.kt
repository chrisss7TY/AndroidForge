package app.lumen

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import kotlin.math.roundToInt

/** Full-quality frame (10% into the video), scaled down to maxW. */
fun frameOf(ctx: Context, uri: Uri, maxW: Int = 720): Bitmap? {
    val r = MediaMetadataRetriever()
    return try {
        r.setDataSource(ctx, uri)
        val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        val t = d * 100
        fun i(k: Int) = r.extractMetadata(k)?.toIntOrNull() ?: 0
        val vw = i(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH); val vh = i(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
        // 4K: let the decoder output the thumbnail size directly instead of a 33 MB bitmap that is scaled down afterwards (less CPU, no GC spikes)
        val scaled = if (Build.VERSION.SDK_INT >= 27 && i(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION) == 0 && vw > maxW && vh > 0)
            runCatching { r.getScaledFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, maxW, (vh * maxW.toFloat() / vw).roundToInt()) }.getOrNull()
        else null
        val raw = scaled ?: r.getFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: r.getFrameAtTime(0)
        if (raw != null && raw.width > maxW) {
            val s = Bitmap.createScaledBitmap(raw, maxW, (raw.height * maxW.toFloat() / raw.width).roundToInt(), true)
            if (s !== raw) raw.recycle()
            s
        } else raw
    } catch (e: Exception) {
        null
    } finally {
        runCatching { r.release() }
    }
}

/** (duration ms, displayed height px) */
fun probe(ctx: Context, uri: Uri): Pair<Long, Int> {
    val r = MediaMetadataRetriever()
    return try {
        r.setDataSource(ctx, uri)
        fun i(k: Int) = r.extractMetadata(k)?.toIntOrNull() ?: 0
        val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        val rot = i(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
        val h = if (rot == 90 || rot == 270) i(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH) else i(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
        d to h
    } catch (e: Exception) {
        0L to 0
    } finally {
        runCatching { r.release() }
    }
}

fun nameOf(ctx: Context, u: Uri): String =
    runCatching {
        ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
    }.getOrNull() ?: "video_${System.currentTimeMillis()}.mp4"
