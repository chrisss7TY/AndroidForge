package com.ashveil.abyss;

import android.graphics.Canvas;
import android.graphics.Paint;

/**
 * A plume of many soft hair strands (horse mane / tail).
 *
 * Each strand is a Verlet chain with its own length, root position along the root line, and gust phase.
 * Forces: gravity, a turbulent wind, a "streaming" pull toward a rest direction (so the plume fans out and
 * arcs instead of hanging like string) and a bending stiffness that keeps each strand a smooth curve.
 * Simulated in fixed 1/120 s sub-steps so it is stable at any frame rate.
 *
 * Drawn as smooth white translucent strokes (a wide faint pass for volume, a crisp pass for fibres) - NOT as
 * ASCII glyphs - which is what gives the soft, fluffy, flowing look.
 */
final class HairFx {
    private static final float STEP = 1.0f / 120.0f;

    private final int strands;
    private final int nodes;
    private final float[] x, y, px, py;
    private final float[] rootU;     // 0..1 position of the strand's root along the root line
    private final float[] lenScale;  // per-strand length multiplier
    private final float[] phase;     // per-strand gust phase
    private final float[] shade;     // 0..1 brightness
    private final float[] fanAng;    // -1..1 fan-out of the strand's rest direction
    private final float segLen;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float lastAx, lastAy, lastBx, lastBy;
    private boolean primed = false;
    private float acc = 0.0f;

    HairFx(int strands, int nodes, float segLen, long seed) {
        this.strands = strands;
        this.nodes = nodes;
        this.segLen = segLen;
        x = new float[strands * nodes];
        y = new float[strands * nodes];
        px = new float[strands * nodes];
        py = new float[strands * nodes];
        rootU = new float[strands];
        lenScale = new float[strands];
        phase = new float[strands];
        shade = new float[strands];
        fanAng = new float[strands];
        java.util.Random r = new java.util.Random(seed);
        for (int s = 0; s < strands; s++) {
            rootU[s] = (s + r.nextFloat() * 0.8f) / strands;
            lenScale[s] = 0.62f + r.nextFloat() * 0.52f;
            phase[s] = s * 0.16f + r.nextFloat() * 0.5f;   // neighbours move together -> a flowing sheet
            fanAng[s] = (rootU[s] - 0.5f) * 2.0f + (r.nextFloat() - 0.5f) * 0.5f;
            shade[s] = r.nextFloat();
        }
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
    }

    void reset() {
        primed = false;
    }

    /**
     * @param ax,ay  root line start (world)     @param bx,by  root line end (world)
     * @param restX,restY unit-ish direction the strands like to stream toward
     * @param stream how strongly they stream toward it (units/s^2)
     */
    void step(float dt, float ax, float ay, float bx, float by,
              float restX, float restY, float stream, float gravity,
              float windX, float windY, float gust, float fan, float time) {
        if (!primed) {
            lastAx = ax; lastAy = ay; lastBx = bx; lastBy = by;
            for (int s = 0; s < strands; s++) {
                float rx = ax + (bx - ax) * rootU[s];
                float ry = ay + (by - ay) * rootU[s];
                for (int n = 0; n < nodes; n++) {
                    int i = s * nodes + n;
                    x[i] = px[i] = rx + restX * segLen * lenScale[s] * n;
                    y[i] = py[i] = ry + restY * segLen * lenScale[s] * n + 0.02f * n;
                }
            }
            primed = true;
        }
        acc += Math.min(dt, 0.05f);
        int steps = 0;
        float total = acc;
        while (acc >= STEP && steps < 8) {
            acc -= STEP;
            steps++;
        }
        if (steps == 0) return;
        float rlen = (float) Math.sqrt(restX * restX + restY * restY) + 1e-5f;
        final float bdx = restX / rlen;
        final float bdy = restY / rlen;
        float h2 = STEP * STEP;

        for (int k = 1; k <= steps; k++) {
            float f = k / (float) steps;
            float curAx = lastAx + (ax - lastAx) * f;
            float curAy = lastAy + (ay - lastAy) * f;
            float curBx = lastBx + (bx - lastBx) * f;
            float curBy = lastBy + (by - lastBy) * f;
            float tt = time - (steps - k) * STEP;

            for (int s = 0; s < strands; s++) {
                int base = s * nodes;
                float L = segLen * lenScale[s];
                float fc = (float) Math.cos(fanAng[s] * fan);
                float fs = (float) Math.sin(fanAng[s] * fan);
                float rdx = bdx * fc - bdy * fs;
                float rdy = bdx * fs + bdy * fc;
                x[base] = curAx + (curBx - curAx) * rootU[s];
                y[base] = curAy + (curBy - curAy) * rootU[s];
                px[base] = x[base];
                py[base] = y[base];

                for (int n = 1; n < nodes; n++) {
                    int i = base + n;
                    float u = n / (float) (nodes - 1);
                    float vx = (x[i] - px[i]) * 0.986f;
                    float vy = (y[i] - py[i]) * 0.986f;
                    px[i] = x[i];
                    py[i] = y[i];

                    float g1 = (float) Math.sin(tt * 3.3f + phase[s] + n * 0.62f);
                    float g2 = (float) Math.sin(tt * 5.9f + phase[s] * 1.7f - n * 0.9f);
                    float gx = (g1 * 0.7f + g2 * 0.3f) * gust * (0.4f + u);
                    float gy = (g2 * 0.7f - g1 * 0.3f) * gust * 0.7f * (0.4f + u);

                    float ax2 = windX + gx + rdx * stream * (1.0f - 0.35f * u);
                    float ay2 = windY + gy + rdy * stream * (1.0f - 0.35f * u) + gravity * (0.35f + 0.65f * u);
                    x[i] += vx + ax2 * h2;
                    y[i] += vy + ay2 * h2;
                }

                // keep segment lengths (root pinned), a few relaxation passes
                for (int it = 0; it < 4; it++) {
                    for (int n = 0; n < nodes - 1; n++) {
                        int a = base + n;
                        int b = a + 1;
                        float dx = x[b] - x[a];
                        float dy = y[b] - y[a];
                        float d = (float) Math.sqrt(dx * dx + dy * dy) + 1e-6f;
                        float diff = (d - L) / d;
                        if (n == 0) {
                            x[b] -= dx * diff;
                            y[b] -= dy * diff;
                        } else {
                            x[a] += dx * diff * 0.5f;
                            y[a] += dy * diff * 0.5f;
                            x[b] -= dx * diff * 0.5f;
                            y[b] -= dy * diff * 0.5f;
                        }
                    }
                }

                // bending stiffness: nudge each node toward the straight continuation of the two before it
                for (int n = 2; n < nodes; n++) {
                    int i = base + n;
                    float ex = x[i - 1] - x[i - 2];
                    float ey = y[i - 1] - y[i - 2];
                    float el = (float) Math.sqrt(ex * ex + ey * ey) + 1e-6f;
                    float tx = x[i - 1] + ex / el * L;
                    float ty = y[i - 1] + ey / el * L;
                    x[i] += (tx - x[i]) * 0.22f;
                    y[i] += (ty - y[i]) * 0.22f;
                }
            }
        }
        lastAx = ax; lastAy = ay; lastBx = bx; lastBy = by;
    }

    /**
     * @param ox,oy screen position of the world point (refX, refY); unit = pixels per world unit
     */
    void draw(Canvas canvas, float refX, float refY, float ox, float oy, float unit, float widthPx,
              int baseGrey, float alphaMul) {
        // pass 1: wide faint pass = soft volume
        for (int pass = 0; pass < 2; pass++) {
            for (int s = 0; s < strands; s++) {
                int base = s * nodes;
                for (int n = 0; n < nodes - 1; n++) {
                    float u = n / (float) (nodes - 1);
                    float taper = 1.0f - 0.72f * u;
                    float w = widthPx * taper * (0.7f + 0.6f * shade[s]);
                    int grey = Math.min(255, baseGrey + (int) (shade[s] * 22.0f) - (int) (u * 26.0f));
                    int a;
                    if (pass == 0) {
                        w *= 3.2f;
                        a = (int) ((30 + 26 * (1.0f - u)) * alphaMul);
                    } else {
                        a = (int) ((150 + 80 * shade[s]) * (1.0f - 0.55f * u) * alphaMul);
                    }
                    paint.setStrokeWidth(w);
                    paint.setColor(0);
                    paint.setARGB(Math.max(0, Math.min(255, a)), grey, grey, Math.min(255, grey + 4));
                    int i = base + n;
                    canvas.drawLine(ox + (x[i] - refX) * unit, oy + (y[i] - refY) * unit,
                            ox + (x[i + 1] - refX) * unit, oy + (y[i + 1] - refY) * unit, paint);
                }
            }
        }
    }
}
