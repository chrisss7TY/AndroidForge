package com.ashveil.abyss;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;

import java.util.Random;

/**
 * Pre-baked art for the world view. Everything here is drawn once and cached by the caller,
 * so none of it runs per frame.
 */
final class Gfx {
    static final String ROCK_CHARS = "@WM#B8&%$N0QOZmwqpdbkhao*+=-:;,.";
    static final int SPRITE_PPU = 96;     // sprite pixels per world unit
    private static final int GLYPH_W = 10;
    private static final int GLYPH_H = 14;

    private Gfx() {
    }

    private static float smooth(float a, float b, float v) {
        float t = Math.max(0.0f, Math.min(1.0f, (v - a) / (b - a)));
        return t * t * (3.0f - 2.0f * t);
    }

    private static float cellNoise(int x, int y, long id) {
        long h = WorldGen.mix64(id + x * 0x632BE59BD9B4E019L + y * 0x9E3779B97F4A7C15L);
        return ((h >>> 40) & 0xFFFF) / 65536.0f;
    }

    /**
     * A standing stone or boulder drawn the way the reference clips show it: a near-black
     * silhouette packed with dense luminance-ramp glyphs, lit from the upper left.
     *
     * @param baseOut receives the pixel position of the object's footprint centre inside the bitmap
     */
    static Bitmap rockSprite(WorldGen.Obj o, float[] baseOut) {
        boolean pillar = o.kind == WorldGen.PILLAR;
        float wUnits = o.w * (pillar ? 1.30f : 1.12f);
        int w = Math.max(32, (int) (wUnits * SPRITE_PPU));
        float depthU = o.w * 0.34f;
        int footPx = (int) (depthU * SPRITE_PPU);
        int h = Math.max(32, (int) ((o.h + depthU) * SPRITE_PPU));

        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Random rnd = new Random(o.id);
        float ph1 = rnd.nextFloat() * 6.2832f;
        float ph2 = rnd.nextFloat() * 6.2832f;
        float lean = rnd.nextFloat() * 2.0f - 1.0f;

        // --- silhouette: per-row left/right edge
        float[] left = new float[h];
        float[] right = new float[h];
        for (int r = 0; r < h; r++) {
            float v = r / (float) (h - 1);
            float half;
            if (pillar) {
                float base = 0.5f * o.w * SPRITE_PPU;
                half = base * (0.70f + 0.42f * smooth(0.66f, 1.0f, v));
                if (v < 0.06f) half *= (float) Math.sqrt(v / 0.06f);
                if (v > 0.95f) half *= (float) Math.sqrt(Math.max(0.0f, (1.0f - v) / 0.05f));
            } else {
                float e = 2.0f * v - 1.0f;
                half = 0.5f * w * (float) Math.sqrt(Math.max(0.0f, 1.0f - e * e));
            }
            half *= 1.0f + 0.07f * (float) Math.sin(v * 19.0f + ph1) + 0.04f * (float) Math.sin(v * 47.0f + ph2);
            float cx = w * 0.5f + (pillar ? lean * (1.0f - v) * o.w * SPRITE_PPU * 0.10f : 0.0f);
            left[r] = cx - half;
            right[r] = cx + half;
        }

        Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Color.rgb(4, 6, 8));
        Path path = new Path();
        int first = -1;
        int last = -1;
        for (int r = 0; r < h; r++) {
            if (right[r] - left[r] > 1.0f) {
                if (first < 0) first = r;
                last = r;
            }
        }
        if (first >= 0) {
            path.moveTo(left[first], first);
            for (int r = first; r <= last; r++) path.lineTo(left[r], r);
            for (int r = last; r >= first; r--) path.lineTo(right[r], r);
            path.close();
            c.drawPath(path, fill);
        }

        // --- glyph skin
        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setTypeface(Typeface.MONOSPACE);
        tp.setFakeBoldText(true);
        tp.setTextSize(15.0f);
        char[] one = new char[1];
        int nChars = ROCK_CHARS.length();
        for (int gy = 4; gy < h - 2; gy += GLYPH_H) {
            int rr = Math.min(h - 1, gy);
            float l = left[rr];
            float rg = right[rr];
            if (rg - l < GLYPH_W) continue;
            float cx = (l + rg) * 0.5f;
            float half = (rg - l) * 0.5f;
            float v = gy / (float) h;
            for (float gx = l + 2.0f; gx < rg - GLYPH_W + 2.0f; gx += GLYPH_W) {
                float nx = ((gx + GLYPH_W * 0.5f) - cx) / half;
                float ny = pillar ? 0.0f : (v - 0.5f) * 2.0f;
                float lit = 0.55f - 0.42f * nx - 0.28f * ny;
                float n = cellNoise((int) gx, gy, o.id);
                float lum = 0.34f + 0.46f * lit + 0.20f * n;
                if (pillar && v < 0.10f) lum += 0.12f;
                if (nx > 0.78f || ny > 0.80f) lum -= 0.18f;
                lum = Math.max(0.15f, Math.min(1.0f, lum));
                int idx = (int) ((1.0f - lum) * (nChars - 1) + (n - 0.5f) * 3.0f);
                idx = Math.max(0, Math.min(nChars - 1, idx));
                int vv = Math.max(70, Math.min(248, (int) (70.0f + lum * 175.0f)));
                tp.setColor(Color.rgb(Math.max(0, vv - 6), vv, Math.min(255, vv + 9)));
                one[0] = ROCK_CHARS.charAt(idx);
                c.drawText(one, 0, 1, gx, gy + GLYPH_H * 0.8f, tp);
            }
        }

        baseOut[0] = w * 0.5f;
        baseOut[1] = h - footPx * 0.5f;
        return bmp;
    }

    /** 256px tileable wispy fog: grainy white-blue patches with soft, uneven density. */
    static Bitmap fogTile(long seed) {
        final int n = 256;
        int[] px = new int[n * n];
        Random rnd = new Random(seed ^ 0xF06F06L);
        int[] sizes = {4, 8, 16, 32};
        float[] amps = {0.50f, 0.28f, 0.14f, 0.08f};
        float[][] lat = new float[4][];
        for (int o = 0; o < 4; o++) {
            lat[o] = new float[sizes[o] * sizes[o]];
            for (int i = 0; i < lat[o].length; i++) lat[o][i] = rnd.nextFloat();
        }
        for (int y = 0; y < n; y++) {
            for (int x = 0; x < n; x++) {
                float sum = 0.0f;
                for (int o = 0; o < 4; o++) {
                    int s = sizes[o];
                    float fx = x * s / (float) n;
                    float fy = y * s / (float) n;
                    int x0 = (int) fx;
                    int y0 = (int) fy;
                    float tx = fx - x0;
                    float ty = fy - y0;
                    tx = tx * tx * (3.0f - 2.0f * tx);
                    ty = ty * ty * (3.0f - 2.0f * ty);
                    int x1 = (x0 + 1) % s;
                    int y1 = (y0 + 1) % s;
                    x0 %= s;
                    y0 %= s;
                    float a = lat[o][y0 * s + x0];
                    float b = lat[o][y0 * s + x1];
                    float cc = lat[o][y1 * s + x0];
                    float d = lat[o][y1 * s + x1];
                    float top = a + (b - a) * tx;
                    float bot = cc + (d - cc) * tx;
                    sum += amps[o] * (top + (bot - top) * ty);
                }
                float a = Math.max(0.0f, Math.min(1.0f, (sum - 0.46f) * 3.4f));
                float grain = 0.55f + 0.45f * rnd.nextFloat();
                px[y * n + x] = Color.argb((int) (a * grain * 118.0f), 206, 224, 232);
            }
        }
        Bitmap bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888);
        bmp.setPixels(px, 0, n, 0, 0, n, n);
        return bmp;
    }

    private static final class FloatList {
        float[] a = new float[4096];
        int n = 0;

        void add4(float x0, float y0, float x1, float y1) {
            if (n + 4 > a.length) a = java.util.Arrays.copyOf(a, a.length * 2);
            a[n++] = x0;
            a[n++] = y0;
            a[n++] = x1;
            a[n++] = y1;
        }
    }

    /**
     * Seamless tile of fine wind-swept blades: dark undergrowth to bright tips. Blades near an
     * edge are duplicated across it, so neighbouring tiles join without a visible seam.
     */
    static Bitmap grassTile(int t) {
        Bitmap bmp = Bitmap.createBitmap(t, t, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        c.drawColor(Color.rgb(6, 12, 11));
        Random rnd = new Random(0x5EEDBEEFL);

        int[] colors = {
                Color.rgb(7, 17, 14), Color.rgb(11, 28, 22), Color.rgb(17, 42, 32),
                Color.rgb(27, 62, 46), Color.rgb(40, 86, 62), Color.rgb(74, 122, 92)
        };
        int[] counts = {30000, 30000, 28000, 20000, 9000, 2600};
        float k = t / 1536.0f;
        Paint pb = new Paint(Paint.ANTI_ALIAS_FLAG);
        pb.setStyle(Paint.Style.STROKE);
        pb.setStrokeCap(Paint.Cap.ROUND);
        pb.setStrokeWidth(1.35f * Math.max(0.8f, k));

        float margin = 26.0f * k;
        for (int ci = 0; ci < colors.length; ci++) {
            FloatList fl = new FloatList();
            for (int i = 0; i < counts[ci]; i += 3) {
                float tx = rnd.nextFloat() * t;
                float ty = rnd.nextFloat() * t;
                for (int b = 0; b < 3; b++) {
                    float bx = tx + (b - 1) * 2.2f * k;
                    float by = ty + (b == 1 ? -1.0f : 0.5f) * k;
                    float len = (8.0f + rnd.nextFloat() * 8.0f) * k * (0.75f + 0.1f * ci);
                    float lean = ((b - 1) * 1.5f + (rnd.nextFloat() - 0.5f) * 3.0f + 1.4f) * k;
                    for (int ox = -1; ox <= 1; ox++) {
                        if (ox == -1 && bx < t - margin) continue;
                        if (ox == 1 && bx > margin) continue;
                        for (int oy = -1; oy <= 1; oy++) {
                            if (oy == -1 && by < t - margin) continue;
                            if (oy == 1 && by > margin) continue;
                            float ax = bx + ox * t;
                            float ay = by + oy * t;
                            fl.add4(ax, ay, ax + lean, ay - len);
                        }
                    }
                }
            }
            pb.setColor(colors[ci]);
            c.drawLines(fl.a, 0, fl.n, pb);
        }
        return bmp;
    }
}
