# Hero animation + human body (added)

All in `MainActivity.java` (search `HERO RIG BEGIN`).

- Body: ~7.7 heads tall. Head + neck, hair cap, tapered torso (pelvis / abdomen / chest / shoulders / belt),
  upper arm + forearm + hand, thigh + shin + calf + boot + foot. Depth-sorted (near limbs in front, far limbs behind).
- Idle: breathing (chest + shoulders, lagged), slow weight shift, occasional head glance, sword arm sways.
- Walk -> run: gait clock is distance-driven (`heroCycleDist`), so planted feet match ground speed (no sliding).
  Heel strike -> toe-off foot roll, hip bob lowest at double support, arms counter-swing, run adds forward lean,
  bent elbows, longer lift and a flight phase.
- Dodge: crouch -> tucked ball roll with a hop -> unfold -> short recovery crouch. Vertical dodges squash into a low dive.
- Slash: wind-up overhead, sweep, recovery, with a lunge step.
- Mounted rider uses the same human proportions (seated, reins hand, sword arm).
- The hero glyph grid is now 64x58 cells with 1.3 aspect (same as the horse grid) and is drawn by `drawHeroGlyphs`,
  so the body is no longer squeezed. Use [DISMOUNT] to see the foot hero; the horse rider is the default.

Not compiled against the Android SDK (none available). The rig + rider code were compiled and rendered on desktop.
