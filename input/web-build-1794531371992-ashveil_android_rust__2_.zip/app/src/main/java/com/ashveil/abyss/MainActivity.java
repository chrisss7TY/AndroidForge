package com.ashveil.abyss;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
    private static boolean sRustLoaded = false;
    static {
        try {
            System.loadLibrary("ashveil_ascii_3d");
            sRustLoaded = true;
        } catch (Throwable ignored) {
            sRustLoaded = false;
        }
    }

    public static native long nativeInit(long seed);
    public static native int nativeStep(long handle, float dt);
    public static native void nativeTouch(long handle, int action, long pointerId, float normX, float normY);
    public static native void nativeDestroy(long handle);

    private AshveilMicroAsciiView mView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );
        mView = new AshveilMicroAsciiView(this);
        setContentView(mView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mView != null) mView.resumeGame();
    }

    @Override
    protected void onPause() {
        if (mView != null) mView.pauseGame();
        super.onPause();
    }

    private static final class AshveilMicroAsciiView extends SurfaceView implements Runnable, SurfaceHolder.Callback {
        // Luminance-ordered ASCII ramps matching the reference video
        private static final String DENSE_RAMP = " .,:;-=+*oahkbdpqwmZOQ0N$%&8B#MW@";
        private static final String[] MONOLITH_ROWS = new String[]{
                "      @WM@@       ",
                "   ##B@@BNBMWNW@@ ",
                "  &MMBW#MW#MH@@WWW",
                " p$&&#M#B#N@M@@WMW",
                "&#N#NB//bw0($#M#HB",
                "wna$&W000qq0Obd|$W",
                "epb$x%(pO0080q*z!|",
                "%%e%%.00@@QQO8r+==",
                " %ebddON@M$8Q~iii+",
                "  %wmW#M8%rxll;;  ",
                "   @MWO08qac:+..  ",
                "  #BWHMM#%r=-:;   ",
                "  &pOM@Mr+=~:;,.  ",
                "  0&m#0=+-:;..    ",
                "  $Nw%=~-:,.      ",
                "  d&^!r-l:;       ",
                "  B*d^r+*;:.      ",
                "  %pwroz:==++*    "
        };
        private static final String[] GROUND_CLUSTERS = new String[]{
                "0000 080000  0QQO 08",
                "0Q08 00Q08 B0Q08  00",
                "d08 00Q000 8 0Q08 00",
                "080 8 0Q0800 000Q 08",
                "qq0Obd Q008B 00Q0 d8",
                "00Q00 80Q08 00O0 0Q8"
        };

        private Thread mThread;
        private volatile boolean mRunning = false;
        private long mRustHandle = 0;

        private final Paint mAsciiPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mGrassPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mShadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mUiPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mPanelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        // Screen Modes: 0 = Start Menu (on launch!), 1 = Playing, 2 = Character/Loot/Forge Modal
        private int mScreenMode = 0;
        private int mZoomPreset = 1; // 0 = Close-Up (Hair Physics), 1 = Medium, 2 = Wide Landscape
        private float mCameraZoom = 1.35f;
        private float mTargetZoom = 1.35f;
        private int mWindPreset = 1; // 0 = Gentle, 1 = Meadow Gale, 2 = Storm

        // World & Horse/Rider State
        private float mTimeSec = 0.0f;
        private float mHorseX = 0.0f;
        private float mHorseY = 0.0f;
        private float mHorseVelX = 0.0f;
        private float mHorseVelY = 0.0f;
        private float mFacingX = 1.0f;
        private float mFacingY = 0.0f;
        private float mGaitPhase = 0.0f;
        private float mGallopBoostTimer = 0.0f;
        private float mSlashTimer = 0.0f;
        private float mLevelUpTimer = 0.0f;

        //Camera position in world units
        private float mCamX = 0.0f;
        private float mCamY = 0.0f;

        // Multi-Strand Verlet Hair, Mane, and Tail Physics
        private static final int TAIL_STRANDS = 14;
        private static final int TAIL_NODES = 9;
        private final float[][] mTailX = new float[TAIL_STRANDS][TAIL_NODES];
        private final float[][] mTailY = new float[TAIL_STRANDS][TAIL_NODES];
        private final float[][] mTailPrevX = new float[TAIL_STRANDS][TAIL_NODES];
        private final float[][] mTailPrevY = new float[TAIL_STRANDS][TAIL_NODES];

        private static final int MANE_STRANDS = 12;
        private static final int MANE_NODES = 6;
        private final float[][] mManeX = new float[MANE_STRANDS][MANE_NODES];
        private final float[][] mManeY = new float[MANE_STRANDS][MANE_NODES];
        private final float[][] mManePrevX = new float[MANE_STRANDS][MANE_NODES];
        private final float[][] mManePrevY = new float[MANE_STRANDS][MANE_NODES];

        private static final int HAIR_STRANDS = 8;
        private static final int HAIR_NODES = 7;
        private final float[][] mHairX = new float[HAIR_STRANDS][HAIR_NODES];
        private final float[][] mHairY = new float[HAIR_STRANDS][HAIR_NODES];
        private final float[][] mHairPrevX = new float[HAIR_STRANDS][HAIR_NODES];
        private final float[][] mHairPrevY = new float[HAIR_STRANDS][HAIR_NODES];

        // Local Micro-ASCII Raster Buffer for the Horse, Rider & Hair (64x52 micro-glyphs)
        private static final int HORSE_BUF_W = 64;
        private static final int HORSE_BUF_H = 52;
        private final char[] mHorseGlyphBuf = new char[HORSE_BUF_W * HORSE_BUF_H];
        private final int[] mHorseColorBuf = new int[HORSE_BUF_W * HORSE_BUF_H];
        private final float[] mHorseLumBuf = new float[HORSE_BUF_W * HORSE_BUF_H];

        // 3D Stone Monoliths in World Space
        private static final int NUM_MONOLITHS = 14;
        private final float[] mMonoX = new float[NUM_MONOLITHS];
        private final float[] mMonoY = new float[NUM_MONOLITHS];

        // Multi-Character ASCII Humanoid Enemies
        private static final int NUM_ENEMIES = 10;
        private final float[] mEnemyX = new float[NUM_ENEMIES];
        private final float[] mEnemyY = new float[NUM_ENEMIES];
        private final int[] mEnemyHp = new int[NUM_ENEMIES];
        private final int[] mEnemyMaxHp = new int[NUM_ENEMIES];
        private final int[] mEnemyLvl = new int[NUM_ENEMIES];
        private final float[] mEnemyPhase = new float[NUM_ENEMIES];
        private final float[] mEnemyHurt = new float[NUM_ENEMIES];

        // Loot Drops on Ground
        private static final int MAX_LOOT = 10;
        private final boolean[] mLootActive = new boolean[MAX_LOOT];
        private final float[] mLootX = new float[MAX_LOOT];
        private final float[] mLootY = new float[MAX_LOOT];
        private final int[] mLootRarity = new int[MAX_LOOT];
        private final String[] mLootName = new String[MAX_LOOT];

        // RPG Progression & Inventory
        private int mLevel = 1, mXp = 0, mXpNext = 100, mStatPts = 0;
        private int mVit = 12, mStr = 14, mDex = 12, mInt = 10;
        private int mHp = 180, mMaxHp = 180, mAsh = 60, mForgeRank = 0;
        private String mWeaponName = "[R] Pale-Moon Greatsword";
        private String mArmorName = "[U] Silver-Weave Rider Mail";
        private String mHelmName = "[C] Ashen Hood";
        private String mRingName = "[R] Wind-Step Signet";
        private int mBagCount = 0;
        private String mToast = "";
        private float mToastTimer = 0.0f;

        // Touch Controls
        private int mMovePointerId = -1;
        private float mMoveOrigX, mMoveOrigY, mMoveCurX, mMoveCurY;
        private int mActPointerId = -1;
        private float mActOrigX, mActOrigY, mActCurX, mActCurY;

        public AshveilMicroAsciiView(Context ctx) {
            super(ctx);
            getHolder().addCallback(this);
            setFocusable(true);
            mAsciiPaint.setTypeface(Typeface.MONOSPACE);
            mAsciiPaint.setFakeBoldText(true);
            mUiPaint.setTypeface(Typeface.SERIF);
            mGrassPaint.setStrokeCap(Paint.Cap.ROUND);
            if (sRustLoaded) {
                mRustHandle = nativeInit(0xA547E110L);
            }
            initWorldAndPhysics();
        }

        private void initWorldAndPhysics() {
            for (int s = 0; s < TAIL_STRANDS; s++) {
                for (int n = 0; n < TAIL_NODES; n++) {
                    mTailX[s][n] = mTailPrevX[s][n] = mHorseX - 1.1f - n * 0.14f;
                    mTailY[s][n] = mTailPrevY[s][n] = mHorseY + n * 0.12f;
                }
            }
            for (int s = 0; s < MANE_STRANDS; s++) {
                for (int n = 0; n < MANE_NODES; n++) {
                    mManeX[s][n] = mManePrevX[s][n] = mHorseX + 0.4f;
                    mManeY[s][n] = mManePrevY[s][n] = mHorseY - 0.6f + n * 0.08f;
                }
            }
            for (int s = 0; s < HAIR_STRANDS; s++) {
                for (int n = 0; n < HAIR_NODES; n++) {
                    mHairX[s][n] = mHairPrevX[s][n] = mHorseX - 0.1f - n * 0.10f;
                    mHairY[s][n] = mHairPrevY[s][n] = mHorseY - 1.25f + n * 0.08f;
                }
            }

            float[][] monoCoords = {
                    {-4.2f, 3.8f}, {5.2f, 4.4f}, {-6.5f, -4.8f}, {6.8f, -3.5f},
                    {-11.0f, 8.5f}, {10.5f, 9.2f}, {-2.5f, 11.5f}, {3.5f, -11.0f},
                    {-14.0f, -2.0f}, {14.5f, 2.5f}, {-8.5f, 15.0f}, {9.0f, 16.5f},
                    {-12.5f, -13.0f}, {12.0f, -14.0f}
            };
            for (int i = 0; i < NUM_MONOLITHS; i++) {
                mMonoX[i] = monoCoords[i][0];
                mMonoY[i] = monoCoords[i][1];
            }

            for (int i = 0; i < NUM_ENEMIES; i++) {
                spawnEnemy(i, i < 3);
            }
        }

        private void spawnEnemy(int i, boolean close) {
            float ang = i * 0.95f + 0.6f;
            float dist = close ? (4.8f + i * 1.8f) : (9.0f + (i % 5) * 3.2f);
            mEnemyX[i] = mHorseX + (float) Math.cos(ang) * dist;
            mEnemyY[i] = mHorseY + (float) Math.sin(ang) * dist;
            mEnemyLvl[i] = Math.max(1, mLevel + (i % 4));
            mEnemyMaxHp[i] = 70 + mEnemyLvl[i] * 30;
            mEnemyHp[i] = mEnemyMaxHp[i];
            mEnemyPhase[i] = i * 1.3f;
            mEnemyHurt[i] = 0.0f;
        }

        private float riverCenterY(float wx) {
            return -6.5f + (float) Math.sin(wx * 0.16f) * 3.2f;
        }

        public void resumeGame() {
            if (mRunning) return;
            mRunning = true;
            mThread = new Thread(this, "AshveilMicroAsciiLoop");
            mThread.start();
        }

        public void pauseGame() {
            mRunning = false;
            if (mThread != null) {
                try {
                    mThread.join(400);
                } catch (InterruptedException ignored) {
                }
                mThread = null;
            }
        }

        @Override
        public void surfaceCreated(SurfaceHolder holder) {
            resumeGame();
        }

        @Override
        public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {}

        @Override
        public void surfaceDestroyed(SurfaceHolder holder) {
            pauseGame();
            if (sRustLoaded && mRustHandle != 0) {
                nativeDestroy(mRustHandle);
                mRustHandle = 0;
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            int action = event.getActionMasked();
            int idx = event.getActionIndex();
            int pid = event.getPointerId(idx);
            float w = Math.max(1.0f, getWidth());
            float h = Math.max(1.0f, getHeight());
            float nx = event.getX(idx) / w;
            float ny = event.getY(idx) / h;

            if (sRustLoaded && mRustHandle != 0) {
                int rAct = (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) ? 0
                        : (action == MotionEvent.ACTION_MOVE ? 1 : 2);
                nativeTouch(mRustHandle, rAct, pid, nx, ny);
            }

            // Handle Start Menu screen taps
            if (mScreenMode == 0) {
                if (action == MotionEvent.ACTION_DOWN) {
                    if (ny >= 0.44f && ny <= 0.54f) {
                        // [ ENTER THE WORLD ]
                        mScreenMode = 1;
                        cycleZoomPreset(0); // Start in close-up/medium showcase view
                        showToast("RIDE WITH LEFT THUMB | TAP/SWIPE RIGHT TO SLASH & GALLOP");
                    } else if (ny > 0.54f && ny <= 0.63f) {
                        // [ CAMERA ZOOM PRESET ]
                        cycleZoomPreset((mZoomPreset + 1) % 3);
                    } else if (ny > 0.63f && ny <= 0.72f) {
                        // [ HAIR & WIND PHYSICS ]
                        mWindPreset = (mWindPreset + 1) % 3;
                    } else if (ny > 0.72f && ny <= 0.82f) {
                        // [ CHARACTER, LOOT & FORGE ]
                        mScreenMode = 2;
                    } else {
                        mScreenMode = 1;
                        showToast("RIDE WITH LEFT THUMB | TAP/SWIPE RIGHT TO SLASH & GALLOP");
                    }
                }
                return true;
            }

            // Handle Character / Loot / Forge Modal taps
            if (mScreenMode == 2) {
                if (action == MotionEvent.ACTION_DOWN) {
                    if (ny >= 0.30f && ny <= 0.48f && mStatPts > 0) {
                        mVit++;
                        mStr += 2;
                        mDex++;
                        mStatPts--;
                        mMaxHp += 20;
                        mHp = mMaxHp;
                        showToast("ATTRIBUTES UPGRADED! (" + mStatPts + " PTS LEFT)");
                    } else if (ny > 0.48f && ny <= 0.66f) {
                        int cost = 40 * (mForgeRank + 1);
                        if (mAsh >= cost) {
                            mAsh -= cost;
                            mForgeRank++;
                            mStr += 3;
                            mMaxHp += 15;
                            mHp = mMaxHp;
                            showToast("BLADE TEMPERED TO +" + mForgeRank + "!");
                        } else {
                            showToast("NEED " + cost + " CINDER ASH TO TEMPER");
                        }
                    } else {
                        mScreenMode = 1;
                    }
                }
                return true;
            }

            // Active Gameplay Touch Handling
            switch (action) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_POINTER_DOWN:
                    // Top-left [MENU] button
                    if (nx < 0.22f && ny < 0.09f) {
                        mScreenMode = 0;
                        mMovePointerId = -1;
                        mActPointerId = -1;
                        return true;
                    }
                    // Top-center [ZOOM] button
                    if (nx >= 0.35f && nx <= 0.65f && ny < 0.09f) {
                        cycleZoomPreset((mZoomPreset + 1) % 3);
                        return true;
                    }
                    // Top-right [HERO/LOOT] button
                    if (nx > 0.76f && ny < 0.09f) {
                        mScreenMode = 2;
                        mMovePointerId = -1;
                        mActPointerId = -1;
                        return true;
                    }

                    // Bottom-half or Left-side movement thumbstick vs Right-side combat/gallop
                    boolean isPortrait = (h > w);
                    boolean isMoveZone = isPortrait ? (nx < 0.58f) : (nx < 0.50f);
                    if (isMoveZone && mMovePointerId == -1) {
                        mMovePointerId = pid;
                        mMoveOrigX = mMoveCurX = nx;
                        mMoveOrigY = mMoveCurY = ny;
                    } else if (!isMoveZone && mActPointerId == -1) {
                        mActPointerId = pid;
                        mActOrigX = mActCurX = nx;
                        mActOrigY = mActCurY = ny;
                    }
                    break;

                case MotionEvent.ACTION_MOVE:
                    for (int i = 0; i < event.getPointerCount(); i++) {
                        int id = event.getPointerId(i);
                        float px = event.getX(i) / w;
                        float py = event.getY(i) / h;
                        if (id == mMovePointerId) {
                            mMoveCurX = px;
                            mMoveCurY = py;
                        } else if (id == mActPointerId) {
                            mActCurX = px;
                            mActCurY = py;
                        }
                    }
                    break;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_POINTER_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (pid == mMovePointerId) {
                        mMovePointerId = -1;
                    } else if (pid == mActPointerId) {
                        float dx = mActCurX - mActOrigX;
                        float dy = mActCurY - mActOrigY;
                        float d = (float) Math.sqrt(dx * dx + dy * dy);
                        if (d > 0.045f) {
                            // Swipe -> Gallop Burst with billowing hair physics!
                            mGallopBoostTimer = 0.45f;
                            mFacingX = dx / d;
                            mFacingY = dy / d;
                        } else {
                            // Tap -> Mounted Greatsword Cleave!
                            performMountedSlash();
                        }
                        mActPointerId = -1;
                    }
                    break;
            }
            return true;
        }

        private void cycleZoomPreset(int preset) {
            mZoomPreset = preset;
            if (preset == 0) {
                mTargetZoom = 1.65f; // Close-up hair & ASCII detail view (like 00:05-00:15)
                showToast("CAMERA: CLOSE-UP HAIR PHYSICS VIEW");
            } else if (preset == 1) {
                mTargetZoom = 1.18f; // Medium riding view (like 00:25-00:38)
                showToast("CAMERA: MEDIUM RIDING VIEW");
            } else {
                mTargetZoom = 0.72f; // Wide sweeping landscape view (like 00:00-00:03 & 00:20)
                showToast("CAMERA: WIDE LANDSCAPE VIEW");
            }
        }

        private void performMountedSlash() {
            mSlashTimer = 0.26f;
            int dmg = 26 + mStr * 3 + mLevel * 5 + mForgeRank * 10;
            for (int i = 0; i < NUM_ENEMIES; i++) {
                float dx = mEnemyX[i] - mHorseX;
                float dy = mEnemyY[i] - mHorseY;
                float dist = (float) Math.sqrt(dx * dx + dy * dy);
                if (dist <= 3.6f) {
                    mEnemyHp[i] -= dmg;
                    mEnemyHurt[i] = 0.22f;
                    if (dist > 0.1f) {
                        mEnemyX[i] += (dx / dist) * 0.9f;
                        mEnemyY[i] += (dy / dist) * 0.9f;
                    }
                    if (mEnemyHp[i] <= 0) {
                        int xpGain = 45 + mEnemyLvl[i] * 25;
                        mXp += xpGain;
                        dropLootAt(mEnemyX[i], mEnemyY[i], mEnemyLvl[i]);
                        if (mXp >= mXpNext) {
                            mXp -= mXpNext;
                            mLevel++;
                            mXpNext = 100 + mLevel * 85;
                            mStatPts += 3;
                            mMaxHp += 24;
                            mHp = mMaxHp;
                            mLevelUpTimer = 2.4f;
                            showToast("ASCENDED TO LEVEL " + mLevel + "! (+3 STAT PTS)");
                        } else {
                            showToast("FELLED WANDERER (+" + xpGain + " XP | LOOT DROPPED)");
                        }
                        spawnEnemy(i, false);
                    }
                }
            }
        }

        private void dropLootAt(float x, float y, int lvl) {
            String[] names = {
                    "[R] Pale-Moon Greatsword",
                    "[E] Wraith-Weave Cloak",
                    "[L] Crown of the First Kiln",
                    "[E] Obsidian Courser Barding",
                    "[R] Starlight Signet Ring"
            };
            for (int i = 0; i < MAX_LOOT; i++) {
                if (!mLootActive[i]) {
                    mLootActive[i] = true;
                    mLootX[i] = x;
                    mLootY[i] = y;
                    int r = (int) (Math.abs(x * 17 + y * 13 + mTimeSec * 7) % names.length);
                    mLootRarity[i] = (r == 2) ? 4 : (r == 1 || r == 3) ? 3 : 2;
                    mLootName[i] = names[r] + " +" + Math.max(1, lvl / 2);
                    return;
                }
            }
        }

        private void showToast(String msg) {
            mToast = msg;
            mToastTimer = 3.2f;
        }

        @Override
        public void run() {
            long lastNs = System.nanoTime();
            while (mRunning) {
                long nowNs = System.nanoTime();
                float dt = (nowNs - lastNs) / 1_000_000_000.0f;
                lastNs = nowNs;
                if (dt > 0.05f) dt = 0.05f;

                updatePhysicsAndWorld(dt);
                rasterizeHorseAndRiderAscii();
                drawFrame();

                long frameNs = System.nanoTime() - nowNs;
                long sleepMs = (16_666_666L - frameNs) / 1_000_000L;
                if (sleepMs > 1) {
                    try {
                        Thread.sleep(sleepMs);
                    } catch (InterruptedException ignored) {
                    }
                }
            }
        }

        private void updatePhysicsAndWorld(float dt) {
            mTimeSec += dt;
            if (sRustLoaded && mRustHandle != 0) {
                nativeStep(mRustHandle, dt);
            }
            if (mToastTimer > 0.0f) mToastTimer -= dt;
            if (mSlashTimer > 0.0f) mSlashTimer -= dt;
            if (mLevelUpTimer > 0.0f) mLevelUpTimer -= dt;
            if (mGallopBoostTimer > 0.0f) mGallopBoostTimer -= dt;

            // Smooth camera zoom interpolation
            float targetZ = (mScreenMode == 0) ? 1.42f : mTargetZoom;
            mCameraZoom += (targetZ - mCameraZoom) * Math.min(1.0f, 5.5f * dt);

            // Horse movement from floating left thumbstick
            if (mScreenMode == 1) {
                if (mGallopBoostTimer > 0.0f) {
                    mHorseVelX = mFacingX * 8.2f;
                    mHorseVelY = mFacingY * 8.2f;
                } else if (mMovePointerId != -1) {
                    float dx = mMoveCurX - mMoveOrigX;
                    float dy = mMoveCurY - mMoveOrigY;
                    float len = (float) Math.sqrt(dx * dx + dy * dy);
                    if (len > 0.008f) {
                        float strength = Math.min(1.0f, len / 0.10f);
                        float spd = strength * (4.6f + mDex * 0.06f);
                        float dirX = dx / len;
                        float dirY = dy / len;
                        mFacingX += (dirX - mFacingX) * Math.min(1.0f, 11.0f * dt);
                        mFacingY += (dirY - mFacingY) * Math.min(1.0f, 11.0f * dt);
                        float fl = (float) Math.sqrt(mFacingX * mFacingX + mFacingY * mFacingY);
                        if (fl > 1e-4f) {
                            mFacingX /= fl;
                            mFacingY /= fl;
                        }
                        mHorseVelX = dirX * spd;
                        mHorseVelY = dirY * spd;
                    } else {
                        mHorseVelX *= 0.80f;
                        mHorseVelY *= 0.80f;
                    }
                } else {
                    mHorseVelX *= 0.82f;
                    mHorseVelY *= 0.82f;
                }

                float nx = mHorseX + mHorseVelX * dt;
                float ny = mHorseY + mHorseVelY * dt;
                if (!collidesWithMonolith(nx, ny)) {
                    mHorseX = nx;
                    mHorseY = ny;
                }

                float vLen = (float) Math.sqrt(mHorseVelX * mHorseVelX + mHorseVelY * mHorseVelY);
                if (vLen > 0.15f) {
                    mGaitPhase = (float) ((mGaitPhase + vLen * dt * 2.9f) % (Math.PI * 2.0));
                }
            } else {
                mHorseVelX = 0.0f;
                mHorseVelY = 0.0f;
            }

            mCamX += (mHorseX - mCamX) * Math.min(1.0f, 8.0f * dt);
            mCamY += (mHorseY - mCamY) * Math.min(1.0f, 8.0f * dt);

            // Multi-Strand Verlet Physics for Horse Tail, Neck Mane & Rider Hair
            float windScale = (mWindPreset == 0) ? 0.55f : (mWindPreset == 1 ? 1.15f : 2.10f);
            float gustX = ((float) Math.sin(mTimeSec * 2.3f) * 3.2f + 2.4f) * windScale - mHorseVelX * 2.1f;
            float gustY = ((float) Math.cos(mTimeSec * 1.7f) * 1.6f + 0.8f) * windScale - mHorseVelY * 1.8f + 3.4f;

            // 1. Update 14 Tail Strands
            float tailRootX = mHorseX - mFacingX * 0.92f;
            float tailRootY = mHorseY - mFacingY * 0.35f - 0.12f;
            for (int s = 0; s < TAIL_STRANDS; s++) {
                float fan = (s - (TAIL_STRANDS - 1) * 0.5f) * 0.032f;
                mTailX[s][0] = tailRootX - mFacingY * fan;
                mTailY[s][0] = tailRootY + mFacingX * fan;
                float sWindX = gustX + (float) Math.sin(mTimeSec * 4.1f + s * 0.6f) * 1.4f;
                float sWindY = gustY + Math.abs(fan) * 1.8f;
                stepVerletChain(mTailX[s], mTailY[s], mTailPrevX[s], mTailPrevY[s], TAIL_NODES, 0.135f, sWindX, sWindY, dt);
            }

            // 2. Update 12 Neck Mane Strands
            for (int s = 0; s < MANE_STRANDS; s++) {
                float t = s / (float) (MANE_STRANDS - 1);
                float neckX = mHorseX + mFacingX * (0.22f + t * 0.62f);
                float neckY = mHorseY + mFacingY * (0.10f + t * 0.25f) - (0.38f + t * 0.42f);
                mManeX[s][0] = neckX;
                mManeY[s][0] = neckY;
                float mWindX = gustX * 0.85f - mFacingX * 1.8f + (float) Math.sin(mTimeSec * 5.0f + s) * 1.1f;
                float mWindY = gustY * 0.70f + 1.2f;
                stepVerletChain(mManeX[s], mManeY[s], mManePrevX[s], mManePrevY[s], MANE_NODES, 0.095f, mWindX, mWindY, dt);
            }

            // 3. Update 8 Rider Flowing Hair Strands
            float headX = mHorseX - mFacingX * 0.06f;
            float headY = mHorseY - 1.08f;
            for (int s = 0; s < HAIR_STRANDS; s++) {
                float fan = (s - 3.5f) * 0.025f;
                mHairX[s][0] = headX + fan;
                mHairY[s][0] = headY + Math.abs(fan) * 0.4f;
                float hWindX = gustX * 1.05f + (float) Math.cos(mTimeSec * 4.5f + s) * 1.2f;
                float hWindY = gustY * 0.80f + 1.0f;
                stepVerletChain(mHairX[s], mHairY[s], mHairPrevX[s], mHairPrevY[s], HAIR_NODES, 0.105f, hWindX, hWindY, dt);
            }

            if (mScreenMode != 1) return;

            // Collect nearby loot drops
            for (int i = 0; i < MAX_LOOT; i++) {
                if (mLootActive[i]) {
                    float dx = mLootX[i] - mHorseX;
                    float dy = mLootY[i] - mHorseY;
                    if (dx * dx + dy * dy <= 2.2f) {
                        mLootActive[i] = false;
                        mAsh += 35 * mLootRarity[i];
                        mBagCount = Math.min(16, mBagCount + 1);
                        mWeaponName = mLootName[i];
                        mStr += 2;
                        showToast("EQUIPPED: " + mLootName[i]);
                    }
                }
            }

            // Update roaming ASCII humanoid enemies
            for (int i = 0; i < NUM_ENEMIES; i++) {
                if (mEnemyHurt[i] > 0.0f) mEnemyHurt[i] -= dt;
                float dx = mHorseX - mEnemyX[i];
                float dy = mHorseY - mEnemyY[i];
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                if (d > 1.35f && d < 14.0f) {
                    float spd = 1.65f * dt;
                    mEnemyX[i] += (dx / d) * spd;
                    mEnemyY[i] += (dy / d) * spd;
                    mEnemyPhase[i] += dt * 5.0f;
                }
            }
        }

        private boolean collidesWithMonolith(float x, float y) {
            for (int i = 0; i < NUM_MONOLITHS; i++) {
                if (Math.abs(x - mMonoX[i]) < 0.95f && Math.abs(y - mMonoY[i]) < 0.65f) {
                    return true;
                }
            }
            return false;
        }

        private void stepVerletChain(
                float[] x, float[] y, float[] px, float[] py,
                int count, float segLen, float ax, float ay, float dt
        ) {
            float damping = 0.88f;
            float dt2 = dt * dt;
            for (int i = 1; i < count; i++) {
                float cx = x[i];
                float cy = y[i];
                float vx = (cx - px[i]) * damping + ax * dt2;
                float vy = (cy - py[i]) * damping + ay * dt2;
                px[i] = cx;
                py[i] = cy;
                x[i] = cx + vx;
                y[i] = cy + vy;
            }
            for (int iter = 0; iter < 4; iter++) {
                for (int i = 1; i < count; i++) {
                    float dx = x[i] - x[i - 1];
                    float dy = y[i] - y[i - 1];
                    float d = (float) Math.sqrt(dx * dx + dy * dy);
                    if (d > 1e-4f) {
                        float diff = (d - segLen) / d;
                        if (i == 1) {
                            x[i] -= dx * diff;
                            y[i] -= dy * diff;
                        } else {
                            x[i - 1] += dx * diff * 0.30f;
                            y[i - 1] += dy * diff * 0.30f;
                            x[i] -= dx * diff * 0.70f;
                            y[i] -= dy * diff * 0.70f;
                        }
                    }
                }
            }
        }

        /**
         * Rasterizes the 3D-shaded Horse, 4 articulated animated legs, Mounted Knight Rider,
         * and all 34 multi-node Verlet Hair/Mane/Tail strands into the 64x52 micro-ASCII buffer.
         */
        private void rasterizeHorseAndRiderAscii() {
            for (int i = 0; i < HORSE_BUF_W * HORSE_BUF_H; i++) {
                mHorseGlyphBuf[i] = ' ';
                mHorseLumBuf[i] = -1.0f;
            }

            // World-to-local buffer scale (64x52 covers 3.6 x 2.9 world units around the horse)
            float scaleX = 17.5f;
            float scaleY = 17.5f;
            float cx = HORSE_BUF_W * 0.5f;
            float cy = HORSE_BUF_H * 0.56f;

            float fx = mFacingX;
            float fy = mFacingY;
            float bob = (float) Math.abs(Math.sin(mGaitPhase)) * 0.045f;

            // 1. 4 Articulated Animated Horse Legs (Back-Left, Front-Left, Back-Right, Front-Right)
            float[] legHipOff = {-0.58f, 0.52f, -0.46f, 0.62f};
            float[] legPhaseOff = {0.0f, (float) Math.PI, (float) (Math.PI * 0.5), (float) (Math.PI * 1.5)};
            float[] legBrightness = {0.42f, 0.45f, 0.72f, 0.76f};
            float speedFactor = Math.min(1.0f, (float) Math.sqrt(mHorseVelX * mHorseVelX + mHorseVelY * mHorseVelY) / 3.5f);

            for (int leg = 0; leg < 4; leg++) {
                float ph = mGaitPhase + legPhaseOff[leg];
                float swing = (float) Math.sin(ph) * 0.28f * speedFactor;
                float lift = Math.max(0.0f, (float) Math.cos(ph)) * 0.18f * speedFactor;

                float hipX = fx * legHipOff[leg];
                float hipY = fy * legHipOff[leg] * 0.35f + 0.08f - bob;
                float kneeX = hipX + fx * (swing * 0.5f + 0.04f);
                float kneeY = hipY + 0.36f - lift * 0.5f;
                float hoofX = kneeX + fx * swing;
                float hoofY = hipY + 0.74f - lift;

                plotCapsuleAscii(cx, cy, scaleX, scaleY, hipX, hipY, kneeX, kneeY, 0.11f, legBrightness[leg]);
                plotCapsuleAscii(cx, cy, scaleX, scaleY, kneeX, kneeY, hoofX, hoofY, 0.085f, legBrightness[leg] * 0.9f);
            }

            // 2. Horse Barrel Torso, Hindquarters & Chest (3D shaded capsules)
            float rearX = -fx * 0.56f;
            float rearY = -fy * 0.22f - 0.05f - bob;
            float frontX = fx * 0.52f;
            float frontY = fy * 0.22f - 0.08f - bob;
            plotCapsuleAscii(cx, cy, scaleX, scaleY, rearX, rearY, frontX, frontY, 0.34f, 0.88f);
            // Hindquarter highlight
            plotCapsuleAscii(cx, cy, scaleX, scaleY, rearX, rearY - 0.06f, rearX * 0.5f, rearY - 0.08f, 0.26f, 0.96f);

            // 3. Horse Arched Neck, Head, Muzzle & Ears
            float neckTopX = frontX + fx * 0.42f;
            float neckTopY = frontY - 0.52f;
            plotCapsuleAscii(cx, cy, scaleX, scaleY, frontX, frontY - 0.05f, neckTopX, neckTopY, 0.22f, 0.92f);

            float muzzleX = neckTopX + fx * 0.38f;
            float muzzleY = neckTopY + 0.14f;
            plotCapsuleAscii(cx, cy, scaleX, scaleY, neckTopX, neckTopY, muzzleX, muzzleY, 0.14f, 0.95f);
            // Ears
            plotCapsuleAscii(cx, cy, scaleX, scaleY, neckTopX - fx * 0.05f, neckTopY - 0.08f, neckTopX - fx * 0.02f, neckTopY - 0.24f, 0.06f, 0.98f);

            // 4. Mounted Knight Rider (Boots/Legs, Armored Torso, Shoulders, Head)
            float saddleX = -fx * 0.06f;
            float saddleY = -0.32f - bob;
            // Rider leg in stirrup
            plotCapsuleAscii(cx, cy, scaleX, scaleY, saddleX, saddleY + 0.18f, saddleX + fx * 0.12f, saddleY + 0.58f, 0.10f, 0.38f);
            // Rider armored torso & cloak
            plotCapsuleAscii(cx, cy, scaleX, scaleY, saddleX, saddleY, saddleX - fx * 0.04f, saddleY - 0.52f, 0.21f, 0.62f);
            // Rider head / helm
            plotCapsuleAscii(cx, cy, scaleX, scaleY, saddleX - fx * 0.04f, saddleY - 0.66f, saddleX - fx * 0.02f, saddleY - 0.80f, 0.13f, 0.84f);
            // Rider arm holding reins
            plotCapsuleAscii(cx, cy, scaleX, scaleY, saddleX + fx * 0.05f, saddleY - 0.36f, frontX + fx * 0.20f, frontY - 0.25f, 0.08f, 0.70f);

            // 5. Rasterize Multi-Strand Verlet Physics: Tail, Neck Mane & Rider Hair
            for (int s = 0; s < TAIL_STRANDS; s++) {
                float lum = 0.80f + (s % 4) * 0.05f;
                for (int n = 0; n < TAIL_NODES - 1; n++) {
                    float lx0 = mTailX[s][n] - mHorseX;
                    float ly0 = mTailY[s][n] - mHorseY;
                    float lx1 = mTailX[s][n + 1] - mHorseX;
                    float ly1 = mTailY[s][n + 1] - mHorseY;
                    float r = (0.095f - n * 0.007f);
                    plotHairSegmentAscii(cx, cy, scaleX, scaleY, lx0, ly0, lx1, ly1, r, lum - n * 0.04f);
                }
            }

            for (int s = 0; s < MANE_STRANDS; s++) {
                float lum = 0.88f + (s % 3) * 0.04f;
                for (int n = 0; n < MANE_NODES - 1; n++) {
                    float lx0 = mManeX[s][n] - mHorseX;
                    float ly0 = mManeY[s][n] - mHorseY;
                    float lx1 = mManeX[s][n + 1] - mHorseX;
                    float ly1 = mManeY[s][n + 1] - mHorseY;
                    plotHairSegmentAscii(cx, cy, scaleX, scaleY, lx0, ly0, lx1, ly1, 0.075f, lum - n * 0.03f);
                }
            }

            for (int s = 0; s < HAIR_STRANDS; s++) {
                for (int n = 0; n < HAIR_NODES - 1; n++) {
                    float lx0 = mHairX[s][n] - mHorseX;
                    float ly0 = mHairY[s][n] - mHorseY;
                    float lx1 = mHairX[s][n + 1] - mHorseX;
                    float ly1 = mHairY[s][n + 1] - mHorseY;
                    plotHairSegmentAscii(cx, cy, scaleX, scaleY, lx0, ly0, lx1, ly1, 0.070f, 0.96f - n * 0.04f);
                }
            }
        }

        private void plotCapsuleAscii(
                float cx, float cy, float sx, float sy,
                float ax, float ay, float bx, float by,
                float radius, float baseLum
        ) {
            int minC = Math.max(0, (int) (cx + (Math.min(ax, bx) - radius) * sx) - 1);
            int maxC = Math.min(HORSE_BUF_W - 1, (int) (cx + (Math.max(ax, bx) + radius) * sx) + 1);
            int minR = Math.max(0, (int) (cy + (Math.min(ay, by) - radius) * sy) - 1);
            int maxR = Math.min(HORSE_BUF_H - 1, (int) (cy + (Math.max(ay, by) + radius) * sy) + 1);

            float abx = bx - ax;
            float aby = by - ay;
            float ab2 = abx * abx + aby * aby + 1e-6f;

            for (int r = minR; r <= maxR; r++) {
                float py = (r - cy) / sy;
                for (int c = minC; c <= maxC; c++) {
                    float px = (c - cx) / sx;
                    float t = ((px - ax) * abx + (py - ay) * aby) / ab2;
                    if (t < 0.0f) t = 0.0f;
                    else if (t > 1.0f) t = 1.0f;
                    float qx = ax + t * abx;
                    float qy = ay + t * aby;
                    float dx = px - qx;
                    float dy = py - qy;
                    float d2 = dx * dx + dy * dy;
                    float r2 = radius * radius;
                    if (d2 <= r2) {
                        float distNorm = (float) Math.sqrt(d2) / radius;
                        float nz = (float) Math.sqrt(Math.max(0.0f, 1.0f - distNorm * distNorm));
                        float ny = dy / radius;
                        // Top-left 3D directional lighting + dark silhouette rim
                        float light = (nz * 0.72f - ny * 0.38f + 0.15f) * baseLum;
                        if (distNorm > 0.80f) {
                            light *= 0.25f; // Crisp dark ASCII outline like reference video
                        }
                        int idx = r * HORSE_BUF_W + c;
                        if (light > mHorseLumBuf[idx]) {
                            mHorseLumBuf[idx] = light;
                            int rampIdx = Math.max(1, Math.min(DENSE_RAMP.length() - 1, (int) (light * (DENSE_RAMP.length() - 1))));
                            mHorseGlyphBuf[idx] = DENSE_RAMP.charAt(rampIdx);
                            int v = Math.max(18, Math.min(250, (int) (light * 255.0f)));
                            mHorseColorBuf[idx] = Color.rgb(v, v, Math.min(255, v + 6));
                        }
                    }
                }
            }
        }

        private void plotHairSegmentAscii(
                float cx, float cy, float sx, float sy,
                float ax, float ay, float bx, float by,
                float radius, float lum
        ) {
            int steps = 5;
            for (int i = 0; i <= steps; i++) {
                float t = i / (float) steps;
                float px = ax + (bx - ax) * t;
                float py = ay + (by - ay) * t;
                int c0 = Math.round(cx + px * sx);
                int r0 = Math.round(cy + py * sy);
                int radCells = Math.max(1, Math.round(radius * sx));
                for (int dr = -radCells; dr <= radCells; dr++) {
                    for (int dc = -radCells; dc <= radCells; dc++) {
                        int c = c0 + dc;
                        int r = r0 + dr;
                        if (c >= 0 && c < HORSE_BUF_W && r >= 0 && r < HORSE_BUF_H) {
                            float falloff = 1.0f - ((float) Math.sqrt(dc * dc + dr * dr) / (radCells + 0.6f));
                            if (falloff > 0.0f) {
                                float l = lum * (0.65f + 0.35f * falloff);
                                int idx = r * HORSE_BUF_W + c;
                                if (l >= mHorseLumBuf[idx]) {
                                    mHorseLumBuf[idx] = l;
                                    int rIdx = Math.max(4, Math.min(DENSE_RAMP.length() - 1, (int) (l * (DENSE_RAMP.length() - 1))));
                                    mHorseGlyphBuf[idx] = DENSE_RAMP.charAt(rIdx);
                                    int v = Math.max(95, Math.min(252, (int) (l * 255.0f)));
                                    mHorseColorBuf[idx] = Color.rgb(v, v, Math.min(255, v + 5));
                                }
                            }
                        }
                    }
                }
            }
        }

        private void drawFrame() {
            SurfaceHolder holder = getHolder();
            Canvas canvas = null;
            try {
                canvas = holder.lockCanvas();
                if (canvas == null) return;

                int w = canvas.getWidth();
                int h = canvas.getHeight();
                // Deep dark forest-obsidian base background
                canvas.drawColor(Color.rgb(8, 14, 11));

                float pixelsPerUnit = Math.min(w, h) * 0.095f * mCameraZoom;
                float centerX = w * 0.5f;
                float centerY = h * 0.48f;

                float halfUnitsW = (w * 0.5f) / pixelsPerUnit + 2.5f;
                float halfUnitsH = (h * 0.5f) / pixelsPerUnit + 2.5f;

                int minWx = (int) Math.floor(mCamX - halfUnitsW);
                int maxWx = (int) Math.ceil(mCamX + halfUnitsW);
                int minWy = (int) Math.floor(mCamY - halfUnitsH);
                int maxWy = (int) Math.ceil(mCamY + halfUnitsH);

                // ----------------------------------------------------------------
                // 1. RENDER WINDING DARK RIVER & FLOWING WHITE ASCII FOAM STREAKS
                // ----------------------------------------------------------------
                mAsciiPaint.setTextSize(Math.max(8.0f, pixelsPerUnit * 0.22f));
                for (int wy = minWy; wy <= maxWy; wy++) {
                    for (int wx = minWx; wx <= maxWx; wx++) {
                        float ry = riverCenterY(wx);
                        float distRiver = Math.abs(wy - ry);
                        float sx = centerX + (wx - mCamX) * pixelsPerUnit;
                        float sy = centerY + (wy - mCamY) * pixelsPerUnit;

                        if (distRiver < 2.3f) {
                            mPanelPaint.setColor(Color.rgb(7, 11, 20));
                            canvas.drawRect(
                                    sx - pixelsPerUnit * 0.55f,
                                    sy - pixelsPerUnit * 0.55f,
                                    sx + pixelsPerUnit * 0.55f,
                                    sy + pixelsPerUnit * 0.55f,
                                    mPanelPaint
                            );
                            // Flowing diagonal white/silver ASCII foam streaks
                            float foamWave = (float) Math.sin((wx * 0.55f + wy * 0.85f) - mTimeSec * 2.6f);
                            if (foamWave > 0.42f || distRiver > 1.85f) {
                                mAsciiPaint.setColor(foamWave > 0.78f ? Color.rgb(218, 226, 236) : Color.rgb(92, 112, 138));
                                canvas.drawText("00Q8B@#*=~-:.", (Math.abs(wx + wy) % 6), (Math.abs(wx + wy) % 6) + 6, sx, sy, mAsciiPaint);
                            }
                        } else {
                            // ------------------------------------------------------------
                            // 2. RENDER `0Q8B` GROUND ASCII MATRIX PATCHES & SHADOWS
                            // ------------------------------------------------------------
                            int hash = Math.abs((wx * 73856093) ^ (wy * 19349663));
                            if ((hash % 10) < 6) {
                                String rowStr = GROUND_CLUSTERS[hash % GROUND_CLUSTERS.length];
                                mAsciiPaint.setColor((hash % 3 == 0) ? Color.rgb(72, 88, 100) : Color.rgb(42, 62, 50));
                                canvas.drawText(rowStr, 0, Math.min(10, rowStr.length()), sx - pixelsPerUnit * 0.4f, sy, mAsciiPaint);
                            }
                        }
                    }
                }

                // ----------------------------------------------------------------
                // 3. RENDER WIND-SWEPT DARK-EMERALD GRASS BLADES & WILDFLOWERS
                // ----------------------------------------------------------------
                float windScale = (mWindPreset == 0) ? 0.6f : (mWindPreset == 1 ? 1.0f : 1.75f);
                mGrassPaint.setStrokeWidth(Math.max(1.5f, pixelsPerUnit * 0.042f));

                for (int wy = minWy; wy <= maxWy; wy++) {
                    for (int wx = minWx; wx <= maxWx; wx++) {
                        if (Math.abs(wy - riverCenterY(wx)) < 2.0f) continue;

                        float sx = centerX + (wx - mCamX) * pixelsPerUnit;
                        float sy = centerY + (wy - mCamY) * pixelsPerUnit;

                        // Check if under horse or monolith shadow
                        float dxH = wx - (mHorseX + 0.45f);
                        float dyH = wy - (mHorseY + 0.35f);
                        boolean inShadow = (dxH * dxH + dyH * dyH < 1.6f);

                        float windAng = -0.55f + (float) Math.sin(wx * 0.28f + wy * 0.19f - mTimeSec * 3.1f * windScale) * 0.42f * windScale;
                        float bladeLen = pixelsPerUnit * 0.42f;
                        float tipDx = (float) Math.cos(windAng) * bladeLen;
                        float tipDy = (float) Math.sin(windAng) * bladeLen - bladeLen * 0.55f;

                        int h = Math.abs((wx * 19349663) ^ (wy * 83492791));
                        for (int b = 0; b < 5; b++) {
                            float ox = ((h >> (b * 3)) & 7) / 7.0f * pixelsPerUnit - pixelsPerUnit * 0.5f;
                            float oy = ((h >> (b * 3 + 2)) & 7) / 7.0f * pixelsPerUnit - pixelsPerUnit * 0.5f;
                            if (inShadow) {
                                mGrassPaint.setColor(Color.rgb(9, 15, 12));
                            } else if (b == 0) {
                                mGrassPaint.setColor(Color.rgb(20, 38, 28));
                            } else if (b < 3) {
                                mGrassPaint.setColor(Color.rgb(36, 62, 46));
                            } else {
                                mGrassPaint.setColor(Color.rgb(62, 94, 72));
                            }
                            canvas.drawLine(sx + ox, sy + oy, sx + ox + tipDx, sy + oy + tipDy, mGrassPaint);
                        }

                        // Wildflowers (`*` and `.`) scattered in the grass like the reference video
                        if (!inShadow && (h % 19) == 0) {
                            mAsciiPaint.setColor(Color.rgb(226, 232, 220));
                            canvas.drawText((h % 2 == 0) ? "*" : "o.", sx, sy, mAsciiPaint);
                        }
                    }
                }

                // ----------------------------------------------------------------
                // 4. WATER REFLECTION WHEN RIDING NEAR/IN THE RIVER
                // ----------------------------------------------------------------
                if (Math.abs(mHorseY - riverCenterY(mHorseX)) < 3.2f) {
                    drawHorseAsciiBuffer(canvas, centerX, centerY, pixelsPerUnit, true);
                }

                // ----------------------------------------------------------------
                // 5. RENDER GLOWING ASCII LOOT DROPS ON THE GROUND
                // ----------------------------------------------------------------
                for (int i = 0; i < MAX_LOOT; i++) {
                    if (mLootActive[i]) {
                        float lx = centerX + (mLootX[i] - mCamX) * pixelsPerUnit;
                        float ly = centerY + (mLootY[i] - mCamY) * pixelsPerUnit;
                        mAsciiPaint.setColor(Color.rgb(245, 212, 98));
                        canvas.drawText("@WM#*+", lx - pixelsPerUnit * 0.3f, ly, mAsciiPaint);
                        canvas.drawText(" | * |", lx - pixelsPerUnit * 0.3f, ly - pixelsPerUnit * 0.35f, mAsciiPaint);
                    }
                }

                // ----------------------------------------------------------------
                // 6. RENDER MULTI-CHARACTER ASCII HUMANOID ENEMIES
                // ----------------------------------------------------------------
                String[] enemyRows = {
                        "  @M#  ",
                        " #W8W# ",
                        "&M#B#M&",
                        "q#8@8#p",
                        " #B#B# ",
                        " d# #b ",
                        " |: :| ",
                        " :. .: "
                };
                float enemyFontPx = Math.max(7.0f, pixelsPerUnit * 0.16f);
                mAsciiPaint.setTextSize(enemyFontPx);
                for (int i = 0; i < NUM_ENEMIES; i++) {
                    float ex = centerX + (mEnemyX[i] - mCamX) * pixelsPerUnit;
                    float ey = centerY + (mEnemyY[i] - mCamY) * pixelsPerUnit;
                    if (ex < -120 || ex > w + 120 || ey < -120 || ey > h + 120) continue;

                    // Cast shadow on grass
                    mShadowPaint.setColor(Color.argb(150, 5, 8, 7));
                    canvas.drawOval(new RectF(ex - pixelsPerUnit * 0.4f, ey - pixelsPerUnit * 0.1f, ex + pixelsPerUnit * 0.6f, ey + pixelsPerUnit * 0.35f), mShadowPaint);

                    mAsciiPaint.setColor(mEnemyHurt[i] > 0.0f ? Color.rgb(235, 75, 75) : Color.rgb(172, 168, 158));
                    for (int r = 0; r < enemyRows.length; r++) {
                        canvas.drawText(enemyRows[r], ex - enemyFontPx * 2.1f, ey - (enemyRows.length - r) * enemyFontPx * 0.88f, mAsciiPaint);
                    }
                }

                // ----------------------------------------------------------------
                // 7. RENDER MICRO-ASCII HORSE, RIDER & VERLET HAIR/MANE/TAIL
                // ----------------------------------------------------------------
                drawHorseAsciiBuffer(canvas, centerX, centerY, pixelsPerUnit, false);

                // Render Greatsword / Cinder Slash Arc when attacking
                if (mSlashTimer > 0.0f) {
                    mAsciiPaint.setTextSize(Math.max(10.0f, pixelsPerUnit * 0.24f));
                    mAsciiPaint.setColor(Color.rgb(245, 245, 240));
                    float hx = centerX + (mHorseX - mCamX) * pixelsPerUnit;
                    float hy = centerY + (mHorseY - mCamY) * pixelsPerUnit;
                    for (int a = -5; a <= 5; a++) {
                        float ang = (float) Math.atan2(mFacingY, mFacingX) + a * 0.22f;
                        float rx = hx + (float) Math.cos(ang) * pixelsPerUnit * 1.45f;
                        float ry = hy + (float) Math.sin(ang) * pixelsPerUnit * 1.15f;
                        canvas.drawText("@W#*+", (a + 5) % 4, ((a + 5) % 4) + 1, rx, ry, mAsciiPaint);
                    }
                }

                // ----------------------------------------------------------------
                // 8. RENDER 3D STONE MONOLITHS (`@WM@@` / `#B@@BNBMWNW@@`)
                // ----------------------------------------------------------------
                float monoFontPx = Math.max(7.5f, pixelsPerUnit * 0.165f);
                mAsciiPaint.setTextSize(monoFontPx);
                for (int i = 0; i < NUM_MONOLITHS; i++) {
                    float mx = centerX + (mMonoX[i] - mCamX) * pixelsPerUnit;
                    float my = centerY + (mMonoY[i] - mCamY) * pixelsPerUnit;
                    if (mx < -200 || mx > w + 200 || my < -200 || my > h + 200) continue;

                    // Cast dark diagonal shadow behind monolith
                    mShadowPaint.setColor(Color.argb(175, 4, 7, 6));
                    canvas.drawOval(new RectF(mx - pixelsPerUnit * 0.6f, my - pixelsPerUnit * 0.2f, mx + pixelsPerUnit * 1.6f, my + pixelsPerUnit * 0.55f), mShadowPaint);

                    for (int r = 0; r < MONOLITH_ROWS.length; r++) {
                        String row = MONOLITH_ROWS[r];
                        float ry = my - (MONOLITH_ROWS.length - 1 - r) * monoFontPx * 0.88f;
                        int shade = Math.max(95, 225 - r * 6);
                        mAsciiPaint.setColor(Color.rgb(shade - 6, shade, Math.min(255, shade + 8)));
                        canvas.drawText(row, mx - monoFontPx * 4.5f, ry, mAsciiPaint);
                    }
                }

                // ----------------------------------------------------------------
                // 9. RENDER START MENU OR MINIMALIST IN-GAME HUD
                // ----------------------------------------------------------------
                if (mScreenMode == 0) {
                    drawStartMenuOverlay(canvas, w, h);
                } else if (mScreenMode == 1) {
                    drawMinimalistGameplayHud(canvas, w, h);
                } else if (mScreenMode == 2) {
                    drawCharacterAndLootModal(canvas, w, h);
                }
            } finally {
                if (canvas != null) {
                    holder.unlockCanvasAndPost(canvas);
                }
            }
        }

        private void drawHorseAsciiBuffer(Canvas canvas, float centerX, float centerY, float pixelsPerUnit, boolean reflection) {
            float hx = centerX + (mHorseX - mCamX) * pixelsPerUnit;
            float hy = centerY + (mHorseY - mCamY) * pixelsPerUnit;

            if (!reflection) {
                // Soft dark shadow directly under the horse's hooves
                mShadowPaint.setColor(Color.argb(185, 4, 7, 6));
                canvas.drawOval(
                        new RectF(
                                hx - pixelsPerUnit * 0.95f,
                                hy + pixelsPerUnit * 0.15f,
                                hx + pixelsPerUnit * 1.05f,
                                hy + pixelsPerUnit * 0.82f
                        ),
                        mShadowPaint
                );
            }

            float cellPx = (pixelsPerUnit * 3.2f) / HORSE_BUF_W;
            mAsciiPaint.setTextSize(Math.max(5.5f, cellPx * 1.18f));

            float startX = hx - (HORSE_BUF_W * 0.5f) * cellPx;
            float startY = hy - (HORSE_BUF_H * 0.56f) * cellPx;
            char[] single = new char[1];

            for (int r = 0; r < HORSE_BUF_H; r++) {
                float drawY = reflection
                        ? (hy + pixelsPerUnit * 0.75f + (HORSE_BUF_H - r) * cellPx * 0.55f)
                        : (startY + r * cellPx);
                for (int c = 0; c < HORSE_BUF_W; c++) {
                    int idx = r * HORSE_BUF_W + c;
                    char ch = mHorseGlyphBuf[idx];
                    if (ch != ' ') {
                        if (reflection) {
                            mAsciiPaint.setColor(Color.argb(95, 165, 185, 210));
                        } else {
                            mAsciiPaint.setColor(mHorseColorBuf[idx]);
                        }
                        single[0] = ch;
                        canvas.drawText(single, 0, 1, startX + c * cellPx, drawY, mAsciiPaint);
                    }
                }
            }
        }

        private void drawStartMenuOverlay(Canvas canvas, int w, int h) {
            // Subtle vignette scrim so the live mounted knight & flowing hair physics shine in the background
            mPanelPaint.setColor(Color.argb(95, 6, 10, 8));
            canvas.drawRect(0, 0, w, h, mPanelPaint);

            mUiPaint.setTextAlign(Paint.Align.CENTER);
            float titleSize = Math.min(w, h) * 0.082f;
            mUiPaint.setTextSize(titleSize);
            mUiPaint.setColor(Color.rgb(244, 246, 242));
            canvas.drawText("A S H V E I L", w * 0.5f, h * 0.28f, mUiPaint);

            mUiPaint.setTextSize(titleSize * 0.42f);
            mUiPaint.setColor(Color.rgb(198, 208, 202));
            canvas.drawText("Pure-ASCII 3D Open-World RPG & Hair Physics", w * 0.5f, h * 0.34f, mUiPaint);

            mAsciiPaint.setTextAlign(Paint.Align.CENTER);
            float btnTextSize = Math.min(w, h) * 0.036f;
            mAsciiPaint.setTextSize(btnTextSize);

            String zoomLabel = (mZoomPreset == 0) ? "CLOSE-UP" : (mZoomPreset == 1 ? "MEDIUM" : "WIDE");
            String windLabel = (mWindPreset == 0) ? "CALM" : (mWindPreset == 1 ? "GALE" : "STORM");

            String[] buttons = {
                    "[ ENTER THE WORLD ]",
                    "[ CAMERA ZOOM: " + zoomLabel + " ]",
                    "[ HAIR & WIND PHYSICS: " + windLabel + " ]",
                    "[ CHARACTER, LOOT & FORGE (LV." + mLevel + ") ]"
            };
            float[] btnY = {0.49f, 0.58f, 0.67f, 0.76f};

            for (int i = 0; i < buttons.length; i++) {
                float by = h * btnY[i];
                float bw = Math.min(w * 0.82f, btnTextSize * 22.0f);
                float bh = btnTextSize * 2.1f;
                mPanelPaint.setColor(i == 0 ? Color.argb(190, 22, 38, 28) : Color.argb(165, 12, 18, 15));
                canvas.drawRoundRect(new RectF(w * 0.5f - bw * 0.5f, by - bh * 0.68f, w * 0.5f + bw * 0.5f, by + bh * 0.32f), 12.0f, 12.0f, mPanelPaint);

                mAsciiPaint.setColor(i == 0 ? Color.rgb(245, 248, 242) : Color.rgb(185, 202, 192));
                canvas.drawText(buttons[i], w * 0.5f, by, mAsciiPaint);
            }

            mAsciiPaint.setTextAlign(Paint.Align.LEFT);
            mUiPaint.setTextAlign(Paint.Align.LEFT);
        }

        private void drawMinimalistGameplayHud(Canvas canvas, int w, int h) {
            float hudFont = Math.max(22.0f, Math.min(w, h) * 0.028f);
            mAsciiPaint.setTextSize(hudFont);

            // Top-left [MENU] pill, Top-center [ZOOM] pill, Top-right [LV/BAG] pill
            mPanelPaint.setColor(Color.argb(155, 8, 14, 11));
            canvas.drawRoundRect(new RectF(16, 18, 16 + hudFont * 5.5f, 18 + hudFont * 1.8f), 10, 10, mPanelPaint);
            mAsciiPaint.setColor(Color.rgb(220, 228, 222));
            canvas.drawText("[MENU]", 28, 18 + hudFont * 1.25f, mAsciiPaint);

            String zTxt = "[ZOOM:" + (mZoomPreset == 0 ? "CLOSE" : (mZoomPreset == 1 ? "MED" : "WIDE")) + "]";
            float zw = hudFont * 7.8f;
            canvas.drawRoundRect(new RectF(w * 0.5f - zw * 0.5f, 18, w * 0.5f + zw * 0.5f, 18 + hudFont * 1.8f), 10, 10, mPanelPaint);
            canvas.drawText(zTxt, w * 0.5f - zw * 0.42f, 18 + hudFont * 1.25f, mAsciiPaint);

            String rTxt = "[LV." + mLevel + " BAG:" + mBagCount + "]";
            float rw = hudFont * 8.2f;
            canvas.drawRoundRect(new RectF(w - rw - 16, 18, w - 16, 18 + hudFont * 1.8f), 10, 10, mPanelPaint);
            mAsciiPaint.setColor(Color.rgb(245, 212, 98));
            canvas.drawText(rTxt, w - rw - 4, 18 + hudFont * 1.25f, mAsciiPaint);

            // Floating minimalist ASCII thumbstick indicator when touching left zone
            if (mMovePointerId != -1) {
                float ox = mMoveOrigX * w;
                float oy = mMoveOrigY * h;
                float cx = mMoveCurX * w;
                float cy = mMoveCurY * h;
                mAsciiPaint.setColor(Color.argb(160, 190, 205, 195));
                canvas.drawText("( + )", ox - hudFont * 1.2f, oy, mAsciiPaint);
                mAsciiPaint.setColor(Color.rgb(245, 248, 242));
                canvas.drawText("@", cx - hudFont * 0.3f, cy, mAsciiPaint);
            }

            if (mToastTimer > 0.0f && mToast != null && !mToast.isEmpty()) {
                mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                mAsciiPaint.setColor(Color.rgb(240, 244, 238));
                canvas.drawText(mToast, w * 0.5f, h - hudFont * 1.6f, mAsciiPaint);
                mAsciiPaint.setTextAlign(Paint.Align.LEFT);
            }
        }

        private void drawCharacterAndLootModal(Canvas canvas, int w, int h) {
            mPanelPaint.setColor(Color.argb(215, 8, 13, 10));
            canvas.drawRect(w * 0.08f, h * 0.14f, w * 0.92f, h * 0.86f, mPanelPaint);

            float f = Math.min(w, h) * 0.033f;
            mAsciiPaint.setTextSize(f);
            float x0 = w * 0.14f;

            mAsciiPaint.setColor(Color.rgb(245, 212, 98));
            canvas.drawText("[ PILGRIM LEVELING, LOOT & CINDER FORGE ]", x0, h * 0.22f, mAsciiPaint);

            mAsciiPaint.setColor(Color.rgb(210, 224, 216));
            canvas.drawText("LEVEL: " + mLevel + "   XP: " + mXp + "/" + mXpNext + "   STAT PTS: " + mStatPts, x0, h * 0.29f, mAsciiPaint);
            canvas.drawText("HP: " + mHp + "/" + mMaxHp + "   VIT:" + mVit + "  STR:" + mStr + "  DEX:" + mDex + "   ASH:" + mAsh, x0, h * 0.35f, mAsciiPaint);

            mAsciiPaint.setColor(Color.rgb(130, 215, 170));
            canvas.drawText("> [TAP HERE TO SPEND STAT PT (+VIT/+STR/+DEX)]", x0, h * 0.42f, mAsciiPaint);

            int cost = 40 * (mForgeRank + 1);
            mAsciiPaint.setColor(Color.rgb(255, 165, 82));
            canvas.drawText("> [TAP HERE TO TEMPER WEAPON +" + (mForgeRank + 1) + " (COST: " + cost + " ASH)]", x0, h * 0.54f, mAsciiPaint);

            mAsciiPaint.setColor(Color.rgb(225, 232, 228));
            canvas.drawText("WPN: " + mWeaponName + " (+" + mForgeRank + ")", x0, h * 0.64f, mAsciiPaint);
            canvas.drawText("ARM: " + mArmorName, x0, h * 0.69f, mAsciiPaint);
            canvas.drawText("HLM: " + mHelmName + "   RNG: " + mRingName, x0, h * 0.74f, mAsciiPaint);

            mAsciiPaint.setColor(Color.rgb(175, 190, 182));
            canvas.drawText("[ TAP BOTTOM TO RETURN TO WORLD ]", x0, h * 0.82f, mAsciiPaint);
        }
    }
}
