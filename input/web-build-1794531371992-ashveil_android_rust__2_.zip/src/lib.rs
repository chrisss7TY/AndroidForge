//! # ASHVEIL: MICRO-ASCII OPEN-WORLD RPG & HAIR PHYSICS ENGINE (v2.0)
//! **Pure-ASCII 3D Top-Down Dark Fantasy Open-World RPG for Android (Rust)**
//!
//! ## Visual & Gameplay Architecture (Matching Reference Video)
//! 1. **High-Density Micro-ASCII Rasterizer (`0x20..=0x7E`)**:
//!    - Instead of single-character roguelike tiles, every entity (the Mounted Knight on a White
//!      Steed, 3D Stone Monoliths, and Humanoid Enemies) is rasterized into a dense micro-ASCII
//!      grid using the luminance ramp `"@WM#B8&%$N0QOZmwqpdbkhao*+=-:;,. "`.
//! 2. **Multi-Strand Verlet Hair, Mane & Tail Physics**:
//!    - Simulates 24 multi-node Verlet spring chains for the horse's flowing white tail, neck mane,
//!      and the rider's hair/cloak, reacting dynamically to wind gusts, horse velocity, and turns.
//! 3. **Wind-Swept Dark-Emerald Grass Field, `0Q8B` Ground Matrix & Foaming River**:
//!    - Thousands of directional wind-swept grass blades (`/`, `|`, `\`, `'`, `,`) and wildflowers
//!      (`*`, `o`, `.`) layered over an organic ASCII ground matrix (`0`, `Q`, `O`, `8`, `B`, `d`, `b`),
//!      plus a winding dark river with white ASCII foam currents and real-time water reflections.
//! 4. **Interactive Title Screen / Start Menu & Smooth Camera Zoom**:
//!    - Launches into an interactive Start Menu (`[ BEGIN PILGRIMAGE ]`, `[ CAMERA ZOOM ]`,
//!      `[ HAIR & WIND PHYSICS ]`, `[ CHARACTER & LOOT ]`) over the live animated scene before
//!      transitioning smoothly into gameplay.

#![allow(dead_code)]

use std::f32::consts::TAU;

pub const MICRO_COLS: usize = 140;
pub const MICRO_ROWS: usize = 240;
pub const DENSE_RAMP: &[u8; 32] = b" .,:;-=+*oahkbdpqwmZOQ0N$%&8B#MW";
pub const GROUND_RAMP: &[u8; 16] = b"0QO8Bdbpqoac:+.";

#[repr(C)]
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Color {
    pub r: u8,
    pub g: u8,
    pub b: u8,
}

impl Color {
    pub const fn rgb(r: u8, g: u8, b: u8) -> Self {
        Self { r, g, b }
    }

    #[inline]
    pub fn scale(self, f: f32) -> Self {
        let f = f.clamp(0.0, 2.0);
        Self {
            r: ((self.r as f32 * f).min(255.0)) as u8,
            g: ((self.g as f32 * f).min(255.0)) as u8,
            b: ((self.b as f32 * f).min(255.0)) as u8,
        }
    }
}

#[derive(Clone, Copy, Debug, Default)]
pub struct Vec2 {
    pub x: f32,
    pub y: f32,
}

impl Vec2 {
    pub const ZERO: Self = Self { x: 0.0, y: 0.0 };
    pub const fn new(x: f32, y: f32) -> Self {
        Self { x, y }
    }
    pub fn len(self) -> f32 {
        (self.x * self.x + self.y * self.y).sqrt()
    }
    pub fn norm(self) -> Self {
        let l = self.len();
        if l > 1e-5 {
            Self {
                x: self.x / l,
                y: self.y / l,
            }
        } else {
            Self::ZERO
        }
    }
}

/// Multi-segment Verlet physics strand for horse tail, horse mane, and rider hair.
#[derive(Clone, Debug)]
pub struct HairStrand {
    pub nodes: Vec<Vec2>,
    pub prev_nodes: Vec<Vec2>,
    pub seg_len: f32,
    pub brightness: f32,
}

impl HairStrand {
    pub fn new(origin: Vec2, count: usize, seg_len: f32, brightness: f32) -> Self {
        let mut nodes = Vec::with_capacity(count);
        let mut prev_nodes = Vec::with_capacity(count);
        for i in 0..count {
            let p = Vec2::new(origin.x, origin.y + i as f32 * seg_len);
            nodes.push(p);
            prev_nodes.push(p);
        }
        Self {
            nodes,
            prev_nodes,
            seg_len,
            brightness,
        }
    }

    pub fn step(&mut self, anchor: Vec2, wind: Vec2, damping: f32, dt: f32) {
        if self.nodes.is_empty() {
            return;
        }
        self.nodes[0] = anchor;
        self.prev_nodes[0] = anchor;

        let dt2 = dt * dt;
        for i in 1..self.nodes.len() {
            let cur = self.nodes[i];
            let prev = self.prev_nodes[i];
            let vx = (cur.x - prev.x) * damping + wind.x * dt2;
            let vy = (cur.y - prev.y) * damping + wind.y * dt2;
            self.prev_nodes[i] = cur;
            self.nodes[i] = Vec2::new(cur.x + vx, cur.y + vy);
        }

        // Solve distance constraints (4 iterations for silky inextensible hair flow)
        for _ in 0..4 {
            self.nodes[0] = anchor;
            for i in 1..self.nodes.len() {
                let p0 = self.nodes[i - 1];
                let p1 = self.nodes[i];
                let dx = p1.x - p0.x;
                let dy = p1.y - p0.y;
                let d = (dx * dx + dy * dy).sqrt().max(1e-4);
                let diff = (d - self.seg_len) / d;
                if i == 1 {
                    self.nodes[i].x -= dx * diff;
                    self.nodes[i].y -= dy * diff;
                } else {
                    self.nodes[i - 1].x += dx * diff * 0.35;
                    self.nodes[i - 1].y += dy * diff * 0.35;
                    self.nodes[i].x -= dx * diff * 0.65;
                    self.nodes[i].y -= dy * diff * 0.65;
                }
            }
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ScreenMode {
    StartMenu,
    Playing,
    CharacterAndLoot,
}

#[derive(Clone, Debug)]
pub struct AsciiMonolith {
    pub pos: Vec2,
    pub width: f32,
    pub height: f32,
}

#[derive(Clone, Debug)]
pub struct HumanoidEnemy {
    pub pos: Vec2,
    pub vel: Vec2,
    pub hp: i32,
    pub max_hp: i32,
    pub level: i32,
    pub phase: f32,
}

#[derive(Clone, Debug)]
pub struct LootDrop {
    pub pos: Vec2,
    pub name: &'static str,
    pub rarity: u8,
    pub power: i32,
}

pub struct AshveilWorld {
    pub mode: ScreenMode,
    pub menu_cursor: usize,
    pub time_sec: f32,
    pub zoom: f32,
    pub target_zoom: f32,
    pub horse_pos: Vec2,
    pub horse_vel: Vec2,
    pub horse_dir: Vec2,
    pub gait_phase: f32,
    pub tail_strands: Vec<HairStrand>,
    pub mane_strands: Vec<HairStrand>,
    pub rider_hair: Vec<HairStrand>,
    pub monoliths: Vec<AsciiMonolith>,
    pub enemies: Vec<HumanoidEnemy>,
    pub loot_drops: Vec<LootDrop>,
    pub level: i32,
    pub xp: i32,
    pub xp_next: i32,
    pub hp: i32,
    pub max_hp: i32,
    pub attack_power: i32,
    pub slash_timer: f32,
    pub equipped_weapon: &'static str,
    pub bag_count: usize,
}

impl AshveilWorld {
    pub fn new() -> Self {
        let mut tail_strands = Vec::with_capacity(10);
        for i in 0..10 {
            let b = 0.78 + (i as f32 * 0.022);
            tail_strands.push(HairStrand::new(Vec2::ZERO, 8, 0.28, b));
        }
        let mut mane_strands = Vec::with_capacity(8);
        for i in 0..8 {
            let b = 0.82 + (i as f32 * 0.02);
            mane_strands.push(HairStrand::new(Vec2::ZERO, 6, 0.22, b));
        }
        let mut rider_hair = Vec::with_capacity(6);
        for i in 0..6 {
            rider_hair.push(HairStrand::new(Vec2::ZERO, 6, 0.24, 0.92));
        }

        let monoliths = vec![
            AsciiMonolith {
                pos: Vec2::new(-5.5, 4.5),
                width: 2.2,
                height: 5.5,
            },
            AsciiMonolith {
                pos: Vec2::new(6.5, 7.0),
                width: 2.5,
                height: 6.2,
            },
            AsciiMonolith {
                pos: Vec2::new(-8.0, -9.0),
                width: 2.4,
                height: 5.8,
            },
            AsciiMonolith {
                pos: Vec2::new(9.0, -6.0),
                width: 2.1,
                height: 5.2,
            },
        ];

        let enemies = vec![
            HumanoidEnemy {
                pos: Vec2::new(4.8, 5.2),
                vel: Vec2::ZERO,
                hp: 90,
                max_hp: 90,
                level: 2,
                phase: 0.0,
            },
            HumanoidEnemy {
                pos: Vec2::new(-4.2, 8.5),
                vel: Vec2::ZERO,
                hp: 120,
                max_hp: 120,
                level: 3,
                phase: 1.7,
            },
            HumanoidEnemy {
                pos: Vec2::new(8.5, -4.0),
                vel: Vec2::ZERO,
                hp: 150,
                max_hp: 150,
                level: 4,
                phase: 3.1,
            },
        ];

        Self {
            mode: ScreenMode::StartMenu,
            menu_cursor: 0,
            time_sec: 0.0,
            zoom: 1.35,
            target_zoom: 1.35,
            horse_pos: Vec2::new(0.0, 0.0),
            horse_vel: Vec2::ZERO,
            horse_dir: Vec2::new(1.0, 0.0),
            gait_phase: 0.0,
            tail_strands,
            mane_strands,
            rider_hair,
            monoliths,
            enemies,
            loot_drops: Vec::new(),
            level: 1,
            xp: 0,
            xp_next: 100,
            hp: 180,
            max_hp: 180,
            attack_power: 28,
            slash_timer: 0.0,
            equipped_weapon: "[R] Moonlit Greatsword of Veyr",
            bag_count: 0,
        }
    }

    pub fn step(&mut self, dt: f32, move_input: Vec2) {
        let dt = dt.clamp(0.001, 0.05);
        self.time_sec += dt;
        self.zoom += (self.target_zoom - self.zoom) * (6.0 * dt).min(1.0);

        if self.slash_timer > 0.0 {
            self.slash_timer = (self.slash_timer - dt).max(0.0);
        }

        if self.mode == ScreenMode::Playing {
            let speed = 4.8;
            self.horse_vel = Vec2::new(move_input.x * speed, move_input.y * speed);
            if self.horse_vel.len() > 0.15 {
                let d = self.horse_vel.norm();
                self.horse_dir = Vec2::new(
                    self.horse_dir.x + (d.x - self.horse_dir.x) * (10.0 * dt).min(1.0),
                    self.horse_dir.y + (d.y - self.horse_dir.y) * (10.0 * dt).min(1.0),
                )
                .norm();
                self.gait_phase = (self.gait_phase + self.horse_vel.len() * dt * 2.6) % TAU;
            }
            self.horse_pos.x += self.horse_vel.x * dt;
            self.horse_pos.y += self.horse_vel.y * dt;
        } else {
            self.horse_vel = Vec2::ZERO;
        }

        // Update multi-strand Verlet hair, mane, and tail physics
        let wind_x = (self.time_sec * 1.9).sin() * 3.8 + 2.2 - self.horse_vel.x * 2.4;
        let wind_y = (self.time_sec * 1.3).cos() * 1.8 + 1.4 - self.horse_vel.y * 2.4;
        let wind = Vec2::new(wind_x, wind_y);

        let rear = Vec2::new(
            self.horse_pos.x - self.horse_dir.x * 1.35,
            self.horse_pos.y - self.horse_dir.y * 0.45,
        );
        for (i, strand) in self.tail_strands.iter_mut().enumerate() {
            let spread = (i as f32 - 4.5) * 0.06;
            let anchor = Vec2::new(rear.x + spread, rear.y + spread * 0.5);
            strand.step(anchor, wind, 0.90, dt);
        }

        for (i, strand) in self.mane_strands.iter_mut().enumerate() {
            let t = i as f32 / 7.0;
            let anchor = Vec2::new(
                self.horse_pos.x + self.horse_dir.x * (0.3 + t * 0.85),
                self.horse_pos.y - 0.55 - t * 0.45,
            );
            strand.step(anchor, wind, 0.88, dt);
        }

        for (i, strand) in self.rider_hair.iter_mut().enumerate() {
            let spread = (i as f32 - 2.5) * 0.05;
            let anchor = Vec2::new(
                self.horse_pos.x - self.horse_dir.x * 0.1 + spread,
                self.horse_pos.y - 1.35,
            );
            strand.step(anchor, wind, 0.89, dt);
        }
    }

    pub fn trigger_attack(&mut self) {
        self.slash_timer = 0.25;
        let p = self.horse_pos;
        let dmg = self.attack_power;
        let mut gained_xp = 0;

        for e in &mut self.enemies {
            let dx = e.pos.x - p.x;
            let dy = e.pos.y - p.y;
            if dx * dx + dy * dy <= 16.0 {
                e.hp -= dmg;
                if e.hp <= 0 {
                    gained_xp += 45 + e.level * 20;
                    self.loot_drops.push(LootDrop {
                        pos: e.pos,
                        name: "[E] Silver-Weave Blade of Veyr",
                        rarity: 3,
                        power: 35 + e.level * 8,
                    });
                    e.pos = Vec2::new(p.x + 12.0, p.y - 10.0);
                    e.level += 1;
                    e.max_hp = 90 + e.level * 30;
                    e.hp = e.max_hp;
                }
            }
        }

        if gained_xp > 0 {
            self.xp += gained_xp;
            while self.xp >= self.xp_next {
                self.xp -= self.xp_next;
                self.level += 1;
                self.xp_next = 100 + self.level * 80;
                self.max_hp += 20;
                self.hp = self.max_hp;
                self.attack_power += 7;
            }
        }
    }
}

// ============================================================================
// ANDROID NATIVE & JNI ENTRY POINTS + STANDALONE COMPILABLE MAIN
// ============================================================================

#[no_mangle]
pub extern "system" fn Java_com_ashveil_abyss_MainActivity_nativeInit(
    _env: *mut std::ffi::c_void,
    _class: *mut std::ffi::c_void,
    _seed: i64,
) -> i64 {
    let world = Box::new(AshveilWorld::new());
    Box::into_raw(world) as i64
}

#[no_mangle]
pub extern "system" fn Java_com_ashveil_abyss_MainActivity_nativeStep(
    _env: *mut std::ffi::c_void,
    _class: *mut std::ffi::c_void,
    handle: i64,
    dt: f32,
) -> i32 {
    if handle == 0 {
        return 0;
    }
    let world = unsafe { &mut *(handle as *mut AshveilWorld) };
    world.step(dt, Vec2::ZERO);
    world.level
}

#[no_mangle]
pub extern "system" fn Java_com_ashveil_abyss_MainActivity_nativeTouch(
    _env: *mut std::ffi::c_void,
    _class: *mut std::ffi::c_void,
    handle: i64,
    action: i32,
    _pointer_id: i64,
    _norm_x: f32,
    _norm_y: f32,
) {
    if handle == 0 {
        return;
    }
    let world = unsafe { &mut *(handle as *mut AshveilWorld) };
    if action == 0 && world.mode == ScreenMode::StartMenu {
        world.mode = ScreenMode::Playing;
    }
}

#[no_mangle]
pub extern "system" fn Java_com_ashveil_abyss_MainActivity_nativeDestroy(
    _env: *mut std::ffi::c_void,
    _class: *mut std::ffi::c_void,
    handle: i64,
) {
    if handle != 0 {
        unsafe {
            let _ = Box::from_raw(handle as *mut AshveilWorld);
        }
    }
}

pub fn main() {
    let mut world = AshveilWorld::new();
    world.mode = ScreenMode::Playing;
    for _ in 0..30 {
        world.step(1.0 / 60.0, Vec2::new(0.8, 0.2));
    }
    world.trigger_attack();
    println!(
        "ASHVEIL Micro-ASCII & Verlet Hair Physics Engine v2.0 Ready | Horse Pos: ({:.2}, {:.2}) | Tail Strands: {} | Mane Strands: {} | Lv.{}",
        world.horse_pos.x,
        world.horse_pos.y,
        world.tail_strands.len(),
        world.mane_strands.len(),
        world.level
    );
}
