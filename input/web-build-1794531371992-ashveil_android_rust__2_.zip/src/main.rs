fn main() {
    ashveil_ascii_3d::main();
}
