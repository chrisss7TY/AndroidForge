package com.ashveil.cinders;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
    private static boolean sRustLoaded = false;
    static {
        try {
            System.loadLibrary("ashveil_ascii_3d");
            sRustLoaded = true;
        } catch (Throwable ignored) {
            sRustLoaded = false;
        }
    }

    public static native long nativeInit(long seed);
    public static native int nativeStep(long handle, float dt);
    public static native void nativeTouch(long handle, int action, long pointerId, float normX, float normY);
    public static native void nativeDestroy(long handle);

    private AshveilSurfaceView mView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );
        mView = new AshveilSurfaceView(this);
        setContentView(mView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mView != null) mView.resumeGame();
    }

    @Override
    protected void onPause() {
        if (mView != null) mView.pauseGame();
        super.onPause();
    }

    private static final class AshveilSurfaceView extends SurfaceView implements Runnable, SurfaceHolder.Callback {
        private static final int COLS = 88;
        private static final int ROWS = 46;
        private static final float PERSP_XY = 0.085f;
        private static final float PERSP_Y_TILT = 0.22f;

        private Thread mThread;
        private volatile boolean mRunning = false;
        private long mRustHandle = 0;

        private final char[] mGlyphs = new char[COLS * ROWS];
        private final int[] mFgColors = new int[COLS * ROWS];
        private final float[] mZOrder = new float[COLS * ROWS];
        private final Paint mTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mBgPaint = new Paint();

        // Player & MMORPG State
        private float mPlayerX = 0.0f, mPlayerY = 2.0f, mPlayerZ = 1.0f;
        private float mFacingX = 0.0f, mFacingY = -1.0f;
        private float mCamX = 0.0f, mCamY = 2.0f;
        private int mLevel = 1, mXp = 0, mXpNext = 100, mStatPts = 0;
        private int mVit = 12, mStr = 12, mDex = 10, mInt = 10, mFai = 10;
        private int mHp = 160, mMaxHp = 160;
        private float mStamina = 100.0f, mMaxStamina = 100.0f;
        private int mFlasks = 4, mAsh = 50, mClassIdx = 0;
        private float mDodgeTimer = 0.0f, mDodgeDirX = 0.0f, mDodgeDirY = -1.0f;
        private float mAttackCooldown = 0.0f, mSlashTimer = 0.0f, mLevelUpTimer = 0.0f;
        private boolean mSlashIsPyro = false;
        private float mTimeSec = 0.0f;

        // Touch & Menu State
        private int mMovePointerId = -1;
        private float mMoveOrigX, mMoveOrigY, mMoveCurX, mMoveCurY;
        private int mActPointerId = -1;
        private float mActOrigX, mActOrigY, mActCurX, mActCurY, mActHoldTime;
        private int mMenuState = 0; // 0=Hidden, 1=Main, 2=Stats, 3=Bag, 4=Party, 5=Map
        private int mMenuCursor = 0;
        private String mToast = "SHARD VEYR-01 ONLINE | TOUCH LEFT: MOVE | RIGHT: STRIKE/DODGE";
        private float mToastTimer = 5.0f;
        private String mMmoFeed = "[SHARD] Welcome to ASHVEIL ONLINE (Shard Veyr-01)";

        // Equipment & Bag
        private final String[] mEquippedNames = new String[]{
                "[C] Ashen Broadsword", "[Empty]", "[Empty]", "[Empty]", "[Empty]", "[Empty]"
        };
        private final int[] mEquippedPower = new int[]{18, 0, 0, 0, 0, 0};
        private final String[] mBagNames = new String[16];
        private final int[] mBagSlots = new int[16];
        private final int[] mBagPower = new int[16];
        private int mBagCount = 0;

        // Enemies (x, y, hp, maxHp, level, kind, windup)
        private static final int MAX_ENEMIES = 18;
        private final float[] mEnemyX = new float[MAX_ENEMIES];
        private final float[] mEnemyY = new float[MAX_ENEMIES];
        private final int[] mEnemyHp = new int[MAX_ENEMIES];
        private final int[] mEnemyMaxHp = new int[MAX_ENEMIES];
        private final int[] mEnemyLvl = new int[MAX_ENEMIES];
        private final int[] mEnemyKind = new int[MAX_ENEMIES];

        // Ground Loot Drops (x, y, rarity, slot, active)
        private static final int MAX_LOOT = 16;
        private final float[] mLootX = new float[MAX_LOOT];
        private final float[] mLootY = new float[MAX_LOOT];
        private final int[] mLootRarity = new int[MAX_LOOT];
        private final int[] mLootSlot = new int[MAX_LOOT];
        private final boolean[] mLootActive = new boolean[MAX_LOOT];

        // Online Shard Party Peers
        private final float[] mPeerX = new float[]{-4.0f, 5.0f, 11.0f, -3.0f};
        private final float[] mPeerY = new float[]{3.0f, -4.0f, 9.0f, -5.0f};
        private final int[] mPeerLvl = new int[]{4, 6, 5, 7};
        private final String[] mPeerTag = new String[]{"L4KNT", "L6HEX", "L5PYR", "L7CLR"};
        private final boolean[] mPeerParty = new boolean[]{true, true, false, true};

        public AshveilSurfaceView(Context ctx) {
            super(ctx);
            getHolder().addCallback(this);
            setFocusable(true);
            mTextPaint.setTypeface(Typeface.MONOSPACE);
            mBgPaint.setColor(Color.rgb(7, 8, 11));
            if (sRustLoaded) {
                mRustHandle = nativeInit(0xA547E110L);
            }
            spawnInitialEnemies();
        }

        private void spawnInitialEnemies() {
            for (int i = 0; i < MAX_ENEMIES; i++) {
                respawnEnemy(i, i == 0);
            }
        }

        private void respawnEnemy(int i, boolean nearStart) {
            float angle = (i * 1.37f) + mTimeSec * 0.5f;
            float dist = nearStart ? 9.0f : (14.0f + (i % 7) * 3.5f);
            mEnemyX[i] = mPlayerX + (float) Math.cos(angle) * dist;
            mEnemyY[i] = mPlayerY + (float) Math.sin(angle) * dist;
            mEnemyKind[i] = (i == MAX_ENEMIES - 1) ? 5 : (i % 5);
            mEnemyLvl[i] = Math.max(1, mLevel + (i % 4) - 1);
            mEnemyMaxHp[i] = (mEnemyKind[i] == 5) ? (450 + mEnemyLvl[i] * 80) : (45 + mEnemyLvl[i] * 25);
            mEnemyHp[i] = mEnemyMaxHp[i];
        }

        public void resumeGame() {
            if (mRunning) return;
            mRunning = true;
            mThread = new Thread(this, "AshveilRenderLoop");
            mThread.start();
        }

        public void pauseGame() {
            mRunning = false;
            if (mThread != null) {
                try {
                    mThread.join(400);
                } catch (InterruptedException ignored) {
                }
                mThread = null;
            }
        }

        @Override
        public void surfaceCreated(SurfaceHolder holder) {
            resumeGame();
        }

        @Override
        public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {}

        @Override
        public void surfaceDestroyed(SurfaceHolder holder) {
            pauseGame();
            if (sRustLoaded && mRustHandle != 0) {
                nativeDestroy(mRustHandle);
                mRustHandle = 0;
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            int action = event.getActionMasked();
            int idx = event.getActionIndex();
            int pid = event.getPointerId(idx);
            float w = Math.max(1.0f, getWidth());
            float h = Math.max(1.0f, getHeight());
            float nx = event.getX(idx) / w;
            float ny = event.getY(idx) / h;

            if (sRustLoaded && mRustHandle != 0) {
                int rAct = (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) ? 0
                        : (action == MotionEvent.ACTION_MOVE ? 1 : 2);
                nativeTouch(mRustHandle, rAct, pid, nx, ny);
            }

            switch (action) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_POINTER_DOWN:
                    if (nx > 0.86f && ny < 0.14f) {
                        mMenuState = (mMenuState == 0) ? 1 : 0;
                        mMenuCursor = 0;
                        return true;
                    }
                    if (nx < 0.22f && ny < 0.14f) {
                        if (mFlasks > 0 && mHp < mMaxHp) {
                            mFlasks--;
                            int heal = 65 + mVit * 4;
                            mHp = Math.min(mMaxHp, mHp + heal);
                            showToast("ASHEN FLASK CONSUMED (+" + heal + " HP)");
                        }
                        return true;
                    }
                    if (nx < 0.5f && mMovePointerId == -1) {
                        mMovePointerId = pid;
                        mMoveOrigX = mMoveCurX = nx;
                        mMoveOrigY = mMoveCurY = ny;
                    } else if (nx >= 0.5f && mActPointerId == -1) {
                        mActPointerId = pid;
                        mActOrigX = mActCurX = nx;
                        mActOrigY = mActCurY = ny;
                        mActHoldTime = 0.0f;
                    }
                    break;

                case MotionEvent.ACTION_MOVE:
                    for (int i = 0; i < event.getPointerCount(); i++) {
                        int id = event.getPointerId(i);
                        float px = event.getX(i) / w;
                        float py = event.getY(i) / h;
                        if (id == mMovePointerId) {
                            mMoveCurX = px;
                            mMoveCurY = py;
                        } else if (id == mActPointerId) {
                            mActCurX = px;
                            mActCurY = py;
                        }
                    }
                    break;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_POINTER_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (pid == mMovePointerId) {
                        float dy = mMoveCurY - mMoveOrigY;
                        if (mMenuState != 0 && Math.abs(dy) > 0.035f) {
                            mMenuCursor = (mMenuCursor + (dy > 0 ? 1 : 4)) % 5;
                        }
                        mMovePointerId = -1;
                    } else if (pid == mActPointerId) {
                        float dx = mActCurX - mActOrigX;
                        float dy = mActCurY - mActOrigY;
                        float dist = (float) Math.sqrt(dx * dx + dy * dy);
                        if (mMenuState != 0) {
                            handleMenuSelect();
                        } else if (dist > 0.045f && mStamina >= 18.0f) {
                            mStamina -= 18.0f;
                            mDodgeTimer = 0.28f;
                            mDodgeDirX = dx / dist;
                            mDodgeDirY = dy / dist;
                            mFacingX = mDodgeDirX;
                            mFacingY = mDodgeDirY;
                        } else {
                            triggerAttack(mActHoldTime >= 0.35f);
                        }
                        mActPointerId = -1;
                    }
                    break;
            }
            return true;
        }

        private void handleMenuSelect() {
            if (mMenuState == 1) {
                if (mMenuCursor == 0) mMenuState = 0;
                else if (mMenuCursor == 1) { mMenuState = 2; mMenuCursor = 0; }
                else if (mMenuCursor == 2) { mMenuState = 3; mMenuCursor = 0; }
                else if (mMenuCursor == 3) { mMenuState = 4; mMenuCursor = 0; }
                else mMenuState = 0;
            } else if (mMenuState == 2) {
                if (mMenuCursor < 4 && mStatPts > 0) {
                    if (mMenuCursor == 0) { mVit++; mMaxHp += 12; mHp = mMaxHp; }
                    else if (mMenuCursor == 1) mStr++;
                    else if (mMenuCursor == 2) mDex++;
                    else mInt++;
                    mStatPts--;
                    showToast("STAT POINT ALLOCATED (" + mStatPts + " LEFT)");
                } else if (mMenuCursor == 4) {
                    mClassIdx = (mClassIdx + 1) % 4;
                    showToast("CLASS SWITCHED");
                    mMenuState = 0;
                } else {
                    mMenuState = 0;
                }
            } else {
                mMenuState = 0;
            }
        }

        private void triggerAttack(boolean heavyPyro) {
            if (mAttackCooldown > 0.0f || mStamina < 14.0f) return;
            mStamina -= heavyPyro ? 24.0f : 14.0f;
            mAttackCooldown = heavyPyro ? 0.40f : 0.22f;
            mSlashTimer = 0.20f;
            mSlashIsPyro = heavyPyro;
            float range = heavyPyro ? 4.4f : 2.6f;
            int dmg = (18 + mStr * 2 + mLevel * 3 + mEquippedPower[0]) * (heavyPyro ? 2 : 1);

            for (int i = 0; i < MAX_ENEMIES; i++) {
                float dx = mEnemyX[i] - mPlayerX;
                float dy = mEnemyY[i] - mPlayerY;
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                if (d <= range) {
                    mEnemyHp[i] -= dmg;
                    if (d > 0.1f) {
                        mEnemyX[i] += (dx / d) * 0.75f;
                        mEnemyY[i] += (dy / d) * 0.75f;
                    }
                    if (mEnemyHp[i] <= 0) {
                        onEnemyKilled(i);
                    }
                }
            }
        }

        private void onEnemyKilled(int i) {
            int xpGain = 35 + mEnemyLvl[i] * 20 + (mEnemyKind[i] == 5 ? 400 : 0);
            mXp += xpGain;
            spawnLoot(mEnemyX[i], mEnemyY[i], mEnemyLvl[i], mEnemyKind[i] == 5);
            if (mXp >= mXpNext) {
                mXp -= mXpNext;
                mLevel++;
                mXpNext = 100 + mLevel * 75;
                mStatPts += 3;
                mMaxHp += 18;
                mHp = mMaxHp;
                mLevelUpTimer = 2.5f;
                mMmoFeed = "[SHARD] AshPilgrim ascended to Level " + mLevel + "!";
                showToast("LEVEL UP! LV." + mLevel + " (+3 STAT PTS IN [=] MENU)");
            } else {
                showToast("SLAIN FOE (+" + xpGain + " XP | LOOT DROPPED)");
            }
            respawnEnemy(i, false);
        }

        private void spawnLoot(float x, float y, int lvl, boolean boss) {
            for (int i = 0; i < MAX_LOOT; i++) {
                if (!mLootActive[i]) {
                    mLootActive[i] = true;
                    mLootX[i] = x;
                    mLootY[i] = y;
                    int r = boss ? 4 : ((int) (Math.abs(x * 13 + y * 7 + mTimeSec * 11) % 100));
                    mLootRarity[i] = boss ? 4 : (r > 92 ? 4 : r > 78 ? 3 : r > 55 ? 2 : r > 28 ? 1 : 0);
                    mLootSlot[i] = (int) (Math.abs(lvl + i) % 6);
                    return;
                }
            }
        }

        private void showToast(String msg) {
            mToast = msg;
            mToastTimer = 3.0f;
        }

        @Override
        public void run() {
            long lastNs = System.nanoTime();
            while (mRunning) {
                long nowNs = System.nanoTime();
                float dt = (nowNs - lastNs) / 1_000_000_000.0f;
                lastNs = nowNs;
                if (dt > 0.05f) dt = 0.05f;

                updateSimulation(dt);
                renderAscii3D();
                drawToSurface();

                long frameNs = System.nanoTime() - nowNs;
                long sleepMs = (16_666_666L - frameNs) / 1_000_000L;
                if (sleepMs > 1) {
                    try {
                        Thread.sleep(sleepMs);
                    } catch (InterruptedException ignored) {
                    }
                }
            }
        }

        private void updateSimulation(float dt) {
            mTimeSec += dt;
            if (sRustLoaded && mRustHandle != 0) {
                nativeStep(mRustHandle, dt);
            }
            if (mActPointerId != -1) mActHoldTime += dt;
            if (mToastTimer > 0.0f) mToastTimer -= dt;
            if (mMenuState != 0) return;

            if (mDodgeTimer > 0.0f) mDodgeTimer -= dt;
            if (mAttackCooldown > 0.0f) mAttackCooldown -= dt;
            if (mSlashTimer > 0.0f) mSlashTimer -= dt;
            if (mLevelUpTimer > 0.0f) mLevelUpTimer -= dt;
            if (mDodgeTimer <= 0.0f && mAttackCooldown <= 0.0f) {
                mStamina = Math.min(mMaxStamina, mStamina + 28.0f * dt);
            }

            float vx = 0.0f, vy = 0.0f;
            if (mDodgeTimer > 0.0f) {
                vx = mDodgeDirX * 13.5f;
                vy = mDodgeDirY * 13.5f;
            } else if (mMovePointerId != -1) {
                float dx = mMoveCurX - mMoveOrigX;
                float dy = mMoveCurY - mMoveOrigY;
                float len = (float) Math.sqrt(dx * dx + dy * dy);
                if (len > 0.008f) {
                    float s = Math.min(1.0f, len / 0.09f) * (6.2f + mDex * 0.05f);
                    mFacingX = dx / len;
                    mFacingY = dy / len;
                    vx = mFacingX * s;
                    vy = mFacingY * s;
                }
            }

            float nx = mPlayerX + vx * dt;
            float ny = mPlayerY + vy * dt;
            if (columnHeight(Math.round(nx), Math.round(mPlayerY)) == 0) mPlayerX = nx;
            if (columnHeight(Math.round(mPlayerX), Math.round(ny)) == 0) mPlayerY = ny;

            mCamX += ((mPlayerX + mFacingX * 1.2f) - mCamX) * Math.min(1.0f, 10.0f * dt);
            mCamY += ((mPlayerY + mFacingY * 1.2f) - mCamY) * Math.min(1.0f, 10.0f * dt);

            // Collect nearby 3D loot drops
            for (int i = 0; i < MAX_LOOT; i++) {
                if (mLootActive[i]) {
                    float dx = mLootX[i] - mPlayerX;
                    float dy = mLootY[i] - mPlayerY;
                    if (dx * dx + dy * dy <= 2.4f) {
                        mLootActive[i] = false;
                        int rar = mLootRarity[i];
                        int slot = mLootSlot[i];
                        int pwr = (rar + 1) * 12 + mLevel * 4;
                        String[] rTags = {"[C]", "[U]", "[R]", "[E]", "[L]"};
                        String[] sNames = {"Greatsword", "Scale Mail", "Greathelm", "Signet Ring", "Eclipse Amulet", "Kiln Relic"};
                        String itemName = rTags[rar] + " Cinder " + sNames[slot];
                        mAsh += 15 * (rar + 1);
                        if (pwr > mEquippedPower[slot]) {
                            mEquippedPower[slot] = pwr;
                            mEquippedNames[slot] = itemName;
                            showToast("EQUIPPED UPGRADE: " + itemName);
                        } else if (mBagCount < 16) {
                            mBagNames[mBagCount] = itemName;
                            mBagSlots[mBagCount] = slot;
                            mBagPower[mBagCount] = pwr;
                            mBagCount++;
                            showToast("LOOTED TO BAG: " + itemName);
                        }
                        mMmoFeed = "[LOOT] AshPilgrim looted " + itemName;
                    }
                }
            }

            // Update online shard party peers
            for (int p = 0; p < 4; p++) {
                float angle = p * 1.6f + mTimeSec * 0.4f;
                float tx = mPlayerX + (float) Math.cos(angle) * 4.2f;
                float ty = mPlayerY + (float) Math.sin(angle) * 4.2f;
                mPeerX[p] += (tx - mPeerX[p]) * Math.min(1.0f, 2.5f * dt);
                mPeerY[p] += (ty - mPeerY[p]) * Math.min(1.0f, 2.5f * dt);
            }

            // Update enemies
            for (int i = 0; i < MAX_ENEMIES; i++) {
                float dx = mPlayerX - mEnemyX[i];
                float dy = mPlayerY - mEnemyY[i];
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                if (d > 1.2f && d < 22.0f) {
                    float spd = 2.8f * dt;
                    mEnemyX[i] += (dx / d) * spd;
                    mEnemyY[i] += (dy / d) * spd;
                } else if (d <= 1.25f && mDodgeTimer <= 0.0f) {
                    mHp -= Math.max(1, (8 + mEnemyLvl[i] * 2) * dt);
                    if (mHp <= 0) {
                        mHp = mMaxHp;
                        mFlasks = 4;
                        mPlayerX = 0.0f;
                        mPlayerY = 2.0f;
                        showToast("RESPAWNED AT SANCTUARY BONFIRE");
                    }
                }
            }
        }

        private int columnHeight(int wx, int wy) {
            int d2 = wx * wx + wy * wy;
            if (d2 <= 49) {
                if ((Math.abs(wx) == 6 && Math.abs(wy) == 6) || (Math.abs(wx) == 6 && wy == 0)) return 5;
                return 0;
            }
            int h = Math.abs((wx * 73856093) ^ (wy * 19349663)) % 100;
            if (wx % 8 == 0 && wy % 8 == 0 && h < 65) return 6;
            if (h > 91) return 4 + (h % 3);
            return 0;
        }

        private void putCell(int c, int r, float z, char ch, int fg) {
            if (c < 0 || r < 0 || c >= COLS || r >= ROWS) return;
            int idx = r * COLS + c;
            if (z >= mZOrder[idx]) {
                mGlyphs[idx] = ch;
                mFgColors[idx] = fg;
                mZOrder[idx] = z;
            }
        }

        private void drawUiText(int c, int r, String s, int fg) {
            for (int i = 0; i < s.length(); i++) {
                putCell(c + i, r, 1000.0f, s.charAt(i), fg);
            }
        }

        private int projectX(float wx, float wz) {
            float relX = wx - mCamX;
            float persp = 1.0f + Math.max(0.0f, wz - 1.0f) * PERSP_XY;
            return Math.round(COLS * 0.5f + relX * persp);
        }

        private int projectY(float wy, float wz) {
            float relY = wy - mCamY;
            float zd = Math.max(0.0f, wz - 1.0f);
            float persp = 1.0f + zd * PERSP_XY;
            return Math.round(ROWS * 0.5f + relY * persp - zd * PERSP_Y_TILT);
        }

        private void renderAscii3D() {
            for (int i = 0; i < COLS * ROWS; i++) {
                mGlyphs[i] = ' ';
                mFgColors[i] = 0xFF525660;
                mZOrder[i] = -100.0f;
            }

            int camXi = Math.round(mCamX);
            int camYi = Math.round(mCamY);
            int halfW = COLS / 2 + 5;
            int halfH = ROWS / 2 + 5;

            // Pass 1: 3D Extruded World Columns & Torch Lighting
            for (int wy = camYi - halfH; wy <= camYi + halfH; wy++) {
                for (int wx = camXi - halfW; wx <= camXi + halfW; wx++) {
                    float dx = wx - mPlayerX;
                    float dy = wy - mPlayerY;
                    float dist = (float) Math.sqrt(dx * dx + dy * dy);
                    if (dist > 30.0f) continue;

                    float falloff = Math.max(0.18f, Math.min(1.2f, 1.0f - (dist / 20.0f)));
                    int gx = projectX(wx, 1.0f);
                    int gy = projectY(wy, 1.0f);

                    if (wx == 0 && wy == -2) {
                        putCell(gx, gy, 2.0f, '&', 0xFFFF9438);
                        putCell(projectX(wx, 2.5f), projectY(wy, 2.5f), 3.5f, '^', 0xFFF5CA4E);
                        continue;
                    }

                    char floorCh = ((wx + wy) & 1) == 0 ? '.' : ',';
                    int shade = (int) (135 * falloff);
                    int floorCol = Color.rgb(shade, shade + 4, shade + 12);
                    putCell(gx, gy, 1.0f, floorCh, floorCol);

                    int h = columnHeight(wx, wy);
                    if (h > 0) {
                        char wallCh = Math.abs(dx) > Math.abs(dy) ? '|' : '=';
                        for (int layer = 1; layer <= h; layer++) {
                            float wz = 1.0f + layer;
                            int sx = projectX(wx, wz);
                            int sy = projectY(wy, wz);
                            boolean roof = (layer == h);
                            int lShade = Math.min(245, (int) ((120 + layer * 18) * falloff));
                            putCell(sx, sy, wz + 0.1f, roof ? '+' : wallCh, Color.rgb(lShade, lShade, lShade + 8));
                        }
                    }
                }
            }

            // Pass 2: 3D Ground Loot Drops & Rarity Light Beams
            int[] rarCols = {0xFF9EA2AC, 0xFF4A945C, 0xFF56CCE8, 0xFFA860E0, 0xFFF5CA4E};
            for (int i = 0; i < MAX_LOOT; i++) {
                if (mLootActive[i]) {
                    int col = rarCols[mLootRarity[i]];
                    putCell(projectX(mLootX[i], 1.4f), projectY(mLootY[i], 1.4f), 2.5f, '*', col);
                    int beamH = mLootRarity[i] + 1;
                    for (int b = 1; b <= beamH; b++) {
                        float bz = 1.4f + b * 0.85f;
                        putCell(projectX(mLootX[i], bz), projectY(mLootY[i], bz), bz + 1.0f, b == beamH ? '*' : '|', col);
                    }
                }
            }

            // Pass 3: Online Shard Party Peers
            for (int p = 0; p < 4; p++) {
                int pCol = mPeerParty[p] ? 0xFF56CCE8 : 0xFFF5CA4E;
                putCell(projectX(mPeerX[p], 1.5f), projectY(mPeerY[p], 1.5f), 3.0f, '@', pCol);
                int tx = projectX(mPeerX[p], 3.2f);
                int ty = projectY(mPeerY[p], 3.2f);
                putCell(tx, ty, 4.8f, '^', 0xFFE4E0D4);
                String tag = mPeerTag[p];
                for (int k = 0; k < tag.length(); k++) {
                    putCell(tx - 2 + k, ty - 1, 6.0f, tag.charAt(k), pCol);
                }
            }

            // Pass 4: 3D Extruded Enemies & Raid Boss
            char[] eGlyphs = {'s', 'W', 'K', 'G', 'A', 'S'};
            for (int i = 0; i < MAX_ENEMIES; i++) {
                int k = mEnemyKind[i];
                int col = (k == 5) ? 0xFFF5CA4E : 0xFFD64E22;
                putCell(projectX(mEnemyX[i], 1.5f), projectY(mEnemyY[i], 1.5f), 2.8f, eGlyphs[k], col);
                putCell(projectX(mEnemyX[i], 3.2f), projectY(mEnemyY[i], 3.2f), 4.5f, k == 5 ? '@' : '^', 0xFFE4E0D4);
            }

            // Pass 5: Slash / Pyromancy Arcs
            if (mSlashTimer > 0.0f) {
                float perpX = -mFacingY;
                float perpY = mFacingX;
                for (int s = -6; s <= 6; s++) {
                    float t = s / 6.0f;
                    float ax = mPlayerX + mFacingX * 1.8f + perpX * t * 1.6f;
                    float ay = mPlayerY + mFacingY * 1.8f + perpY * t * 1.6f;
                    putCell(projectX(ax, 2.5f), projectY(ay, 2.5f), 5.0f, mSlashIsPyro ? '*' : '/',
                            mSlashIsPyro ? 0xFFFF9438 : 0xFFE4E0D4);
                }
            }

            // Pass 6: Local Player (`@` + Class Crown)
            putCell(projectX(mPlayerX, 1.5f), projectY(mPlayerY, 1.5f), 3.5f, '@',
                    mDodgeTimer > 0.0f ? 0xFF56CCE8 : 0xFFE4E0D4);
            putCell(projectX(mPlayerX, 3.4f), projectY(mPlayerY, 3.4f), 5.5f, '^', 0xFFFF9438);

            if (mLevelUpTimer > 0.0f) {
                for (int z = 1; z <= 5; z++) {
                    int lx = projectX(mPlayerX, 1.0f + z);
                    int ly = projectY(mPlayerY, 1.0f + z);
                    putCell(lx - 1, ly, 7.0f, '|', 0xFFF5CA4E);
                    putCell(lx + 1, ly, 7.0f, '|', 0xFFF5CA4E);
                }
            }

            // Pass 7: Minimalist Pure-ASCII HUD & Menus
            String[] clsTags = {"KNT", "HEX", "PYR", "CLR"};
            drawUiText(2, 1, "HP[" + barString(mHp, mMaxHp, 8, '#') + "]", 0xFFC4262E);
            drawUiText(15, 1, "LV." + mLevel + "[" + barString(mXp, mXpNext, 6, '=') + "]", 0xFF56CCE8);
            drawUiText(29, 1, clsTags[mClassIdx] + " [+" + mFlasks + "] ASH:" + mAsh + (mStatPts > 0 ? " *+STAT*" : ""), 0xFFF5CA4E);
            drawUiText(COLS - 18, 1, "VEYR-01 P:4/4 [=]", 0xFF9EA2AC);

            drawUiText(2, ROWS - 2, mMmoFeed, 0xFF9EA2AC);
            drawUiText(COLS - 35, ROWS - 2, "[TAP:STRIKE SWIPE:DODGE HOLD:PYRO]", 0xFF525660);

            if (mMovePointerId != -1) {
                int ox = Math.round(mMoveOrigX * COLS);
                int oy = Math.round(mMoveOrigY * ROWS);
                int cx = Math.round(mMoveCurX * COLS);
                int cy = Math.round(mMoveCurY * ROWS);
                drawUiText(ox - 1, oy, "(+)", 0xFF9EA2AC);
                putCell(cx, cy, 1000.0f, 'o', 0xFFFF9438);
            }

            if (mToastTimer > 0.0f && mToast != null) {
                int tx = Math.max(1, (COLS - mToast.length()) / 2);
                drawUiText(tx, ROWS - 4, mToast, 0xFFF5CA4E);
            }

            if (mMenuState != 0) {
                renderMenuOverlay();
            }
        }

        private String barString(int cur, int max, int width, char fill) {
            int filled = Math.max(0, Math.min(width, (cur * width) / Math.max(1, max)));
            StringBuilder sb = new StringBuilder(width);
            for (int i = 0; i < width; i++) sb.append(i < filled ? fill : '.');
            return sb.toString();
        }

        private void renderMenuOverlay() {
            int bw = 48, bh = 14;
            int x0 = (COLS - bw) / 2;
            int y0 = (ROWS - bh) / 2;
            for (int r = y0; r < y0 + bh; r++) {
                for (int c = x0; c < x0 + bw; c++) {
                    boolean tb = (r == y0 || r == y0 + bh - 1);
                    boolean lr = (c == x0 || c == x0 + bw - 1);
                    char ch = (tb && lr) ? '+' : (tb ? '-' : (lr ? '|' : ' '));
                    putCell(c, r, 1000.0f, ch, 0xFF9EA2AC);
                }
            }
            if (mMenuState == 1) {
                drawUiText(x0 + 10, y0, "[ ASHVEIL MMORPG SANCTUARY ]", 0xFFE4E0D4);
                String[] items = {
                        "RESUME PILGRIMAGE",
                        "CHARACTER STATS, LEVELING & CLASS",
                        "EQUIPPED GEAR & LOOT BAG (" + mBagCount + "/16)",
                        "SHARD VEYR-01 PARTY ROSTER",
                        "CLOSE OVERLAY"
                };
                for (int i = 0; i < items.length; i++) {
                    boolean sel = (i == mMenuCursor);
                    drawUiText(x0 + 3, y0 + 2 + i * 2, (sel ? "> " : "  ") + items[i], sel ? 0xFFFF9438 : 0xFFE4E0D4);
                }
            } else if (mMenuState == 2) {
                drawUiText(x0 + 11, y0, "[ LEVELING & ATTRIBUTES ]", 0xFFF5CA4E);
                drawUiText(x0 + 3, y0 + 2, "LV." + mLevel + "  XP:" + mXp + "/" + mXpNext + "  STAT PTS:" + mStatPts, 0xFF56CCE8);
                String[] stats = {
                        "VIT: " + mVit + " (+Max HP & Flask Heal)",
                        "STR: " + mStr + " (+Melee Damage)",
                        "DEX: " + mDex + " (+Crit & Move Speed)",
                        "INT: " + mInt + " (+Pyromancy Power)",
                        "SWITCH CLASS"
                };
                for (int i = 0; i < stats.length; i++) {
                    boolean sel = (i == mMenuCursor);
                    drawUiText(x0 + 3, y0 + 4 + i * 2, (sel ? "> " : "  ") + stats[i], sel ? 0xFFFF9438 : 0xFFE4E0D4);
                }
            } else if (mMenuState == 3) {
                drawUiText(x0 + 10, y0, "[ EQUIPPED GEAR & LOOT ]", 0xFFF5CA4E);
                String[] slots = {"WPN", "ARM", "HLM", "RNG", "AML", "RLC"};
                for (int i = 0; i < 6; i++) {
                    drawUiText(x0 + 3, y0 + 2 + i, slots[i] + ": " + mEquippedNames[i] + " (Pwr:" + mEquippedPower[i] + ")", 0xFFE4E0D4);
                }
                drawUiText(x0 + 3, y0 + 9, "Bag Items: " + mBagCount + "/16 (Auto-equips upgrades!)", 0xFF56CCE8);
                drawUiText(x0 + 3, y0 + 11, "[TAP RIGHT TO RETURN]", 0xFFFF9438);
            } else {
                drawUiText(x0 + 10, y0, "[ SHARD VEYR-01 PARTY ]", 0xFF56CCE8);
                drawUiText(x0 + 3, y0 + 3, "> Veyr_Paladin [Lv.4 KNT] [PARTY]", 0xFFF5CA4E);
                drawUiText(x0 + 3, y0 + 5, "  Nyx_Hexblade [Lv.6 HEX] [PARTY]", 0xFFF5CA4E);
                drawUiText(x0 + 3, y0 + 7, "  Kael_Pyro    [Lv.5 PYR] [SOLO]", 0xFF9EA2AC);
                drawUiText(x0 + 3, y0 + 9, "  Mire_Cleric  [Lv.7 CLR] [PARTY]", 0xFFF5CA4E);
                drawUiText(x0 + 3, y0 + 11, "[TAP RIGHT TO RETURN]", 0xFFFF9438);
            }
        }

        private void drawToSurface() {
            SurfaceHolder holder = getHolder();
            Canvas canvas = null;
            try {
                canvas = holder.lockCanvas();
                if (canvas == null) return;

                int w = canvas.getWidth();
                int h = canvas.getHeight();
                canvas.drawRect(0, 0, w, h, mBgPaint);

                float cellW = (float) w / COLS;
                float cellH = (float) h / ROWS;
                mTextPaint.setTextSize(cellH * 0.92f);

                char[] single = new char[1];
                for (int r = 0; r < ROWS; r++) {
                    float by = (r + 0.82f) * cellH;
                    for (int c = 0; c < COLS; c++) {
                        int idx = r * COLS + c;
                        char ch = mGlyphs[idx];
                        if (ch != ' ') {
                            mTextPaint.setColor(mFgColors[idx]);
                            single[0] = ch;
                            canvas.drawText(single, 0, 1, c * cellW, by, mTextPaint);
                        }
                    }
                }
            } finally {
                if (canvas != null) {
                    holder.unlockCanvasAndPost(canvas);
                }
            }
        }
    }
}
