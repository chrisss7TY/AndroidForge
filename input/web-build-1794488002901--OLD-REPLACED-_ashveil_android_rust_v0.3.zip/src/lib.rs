//! # ASHVEIL ONLINE: CINDERS OF THE ABYSS (v0.3 Optimized)
//! **Pure-ASCII 3D Top-Down Dark Fantasy Open-World MMORPG for Android (Rust)**
//!
//! ## Compilation & Build Guarantees
//! - **Zero-Dependency Standard Compilation**: Compiles cleanly out-of-the-box with
//!   `rustc --edition 2021 ashveil_ascii_3d.rs -O` or `cargo build --release` on Android
//!   (Termux / NDK), Linux, macOS, and Windows using pure Rust `std`.
//! - **Android Native Activity Entry Point**: Includes `ANativeActivity_onCreate` C-ABI hook under
//!   `#[cfg(target_os = "android")]` plus optional `android-activity` crate integration under
//!   `#[cfg(feature = "android-ndk")]`.
//!
//! ## Key Optimizations & Bug Fixes in v0.3
//! 1. **Bounded Chunk LRU/Spatial Pruning + Persistent World State (`interacted_tiles`)**:
//!    Distant chunks beyond `MAX_CHUNK_RADIUS` are automatically evicted so memory stays flat on
//!    Android, while activated Bonfire Shrines, Lore Monoliths, and Relic Altars persist across
//!    chunk unload/reload cycles.
//! 2. **Chunk-Range Pre-Warming & Fast Raycast Culling**:
//!    Replaced per-tile chunk pre-warming (~6,500 checks/frame) with chunk-coordinate iteration
//!    (9-16 checks/frame) and squared-distance early-out before `sqrt()` in 3D shadowcasting.
//! 3. **Zero-Allocation Hot Loop**:
//!    - `collect_nearby_loot` uses in-place `swap_remove` instead of allocating a new `Vec` each frame.
//!    - `AsciiScreenBuffer::pack_gpu_instances` updates pre-allocated GPU instances in-place for
//!      LLVM auto-vectorization.
//!    - Fixed-size stack ASCII bar rendering (`draw_bar_ui`) eliminates per-frame `String` allocations
//!      for HP, Stamina, XP, and Raid Boss bars.
//! 4. **Gameplay & Collision Fixes**:
//!    - Fixed double-XP and non-party XP leak when remote players kill enemies.
//!    - Added walkable-tile collision checks for remote player movement and enemy knockback so
//!      entities cannot get pushed inside solid 3D pillars, walls, or abyssal chasms.
//!    - Added directional Up/Down menu swipe navigation and empty-slice modulo guards.

#![allow(dead_code)]

use std::collections::HashMap;
use std::f32::consts::TAU;
use std::net::UdpSocket;

// ============================================================================
// 1. CORE CONSTANTS & PURE-ASCII PALETTE
// ============================================================================

pub const DEFAULT_GRID_COLS: usize = 96;
pub const DEFAULT_GRID_ROWS: usize = 54;
pub const MAX_Z_LAYERS: usize = 8;

/// Radial 3D perspective displacement per unit of elevation `z`.
pub const PERSPECTIVE_XY_SCALE: f32 = 0.085;
/// Slight vertical tilt factor so North/South 3D faces are readable from top-down camera.
pub const PERSPECTIVE_Y_TILT: f32 = 0.22;

/// Seamless open-world chunk size (`32x32` columns per chunk).
pub const CHUNK_SIZE: i32 = 32;
/// Maximum chunk retention Chebyshev radius around the player (prevents unbounded RAM growth).
pub const MAX_CHUNK_RADIUS: i32 = 3;

/// Printable ASCII luminance ramp (`0x20..=0x7E`).
pub const ASCII_LUMINANCE_RAMP: &[u8; 12] = b" .':,-~=+*#@";

#[repr(C)]
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Color {
    pub r: f32,
    pub g: f32,
    pub b: f32,
    pub a: f32,
}

impl Color {
    pub const fn rgb(r: u8, g: u8, b: u8) -> Self {
        Self {
            r: r as f32 / 255.0,
            g: g as f32 / 255.0,
            b: b as f32 / 255.0,
            a: 1.0,
        }
    }

    pub const fn rgba(r: u8, g: u8, b: u8, a: u8) -> Self {
        Self {
            r: r as f32 / 255.0,
            g: g as f32 / 255.0,
            b: b as f32 / 255.0,
            a: a as f32 / 255.0,
        }
    }

    #[inline]
    pub fn scale(self, factor: f32) -> Self {
        let f = factor.clamp(0.0, 2.5);
        Self {
            r: (self.r * f).clamp(0.0, 1.0),
            g: (self.g * f).clamp(0.0, 1.0),
            b: (self.b * f).clamp(0.0, 1.0),
            a: self.a,
        }
    }

    #[inline]
    pub fn lerp(self, other: Self, t: f32) -> Self {
        let t = t.clamp(0.0, 1.0);
        Self {
            r: self.r + (other.r - self.r) * t,
            g: self.g + (other.g - self.g) * t,
            b: self.b + (other.b - self.b) * t,
            a: self.a + (other.a - self.a) * t,
        }
    }
}

pub mod palette {
    use super::Color;
    pub const VOID_BG: Color = Color::rgb(7, 8, 11);
    pub const SHADOW_DEEP: Color = Color::rgb(16, 18, 24);
    pub const ASH_DIM: Color = Color::rgb(82, 86, 96);
    pub const ASH_LIGHT: Color = Color::rgb(158, 162, 172);
    pub const BONE_WHITE: Color = Color::rgb(228, 224, 212);
    pub const EMBER_CORE: Color = Color::rgb(255, 148, 56);
    pub const EMBER_GLOW: Color = Color::rgb(214, 78, 34);
    pub const CRIMSON_BLOOD: Color = Color::rgb(196, 38, 46);
    pub const MIRE_MOSS: Color = Color::rgb(74, 148, 92);
    pub const ABYSS_VIOLET: Color = Color::rgb(168, 96, 224);
    pub const RUNE_CYAN: Color = Color::rgb(86, 204, 232);
    pub const GOLD_RELIC: Color = Color::rgb(245, 202, 78);
}

// ============================================================================
// 2. 2D/3D VECTORS & DETERMINISTIC FRACTAL NOISE
// ============================================================================

#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Vec2 {
    pub x: f32,
    pub y: f32,
}

impl Vec2 {
    pub const ZERO: Self = Self { x: 0.0, y: 0.0 };

    #[inline]
    pub const fn new(x: f32, y: f32) -> Self {
        Self { x, y }
    }

    #[inline]
    pub fn length(self) -> f32 {
        (self.x * self.x + self.y * self.y).sqrt()
    }

    #[inline]
    pub fn length_sq(self) -> f32 {
        self.x * self.x + self.y * self.y
    }

    #[inline]
    pub fn normalized(self) -> Self {
        let len_sq = self.length_sq();
        if len_sq > 1e-10 {
            let inv = 1.0 / len_sq.sqrt();
            Self {
                x: self.x * inv,
                y: self.y * inv,
            }
        } else {
            Self::ZERO
        }
    }

    #[inline]
    pub fn dist_sq(self, other: Self) -> f32 {
        let dx = self.x - other.x;
        let dy = self.y - other.y;
        dx * dx + dy * dy
    }

    #[inline]
    pub fn dist(self, other: Self) -> f32 {
        self.dist_sq(other).sqrt()
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Vec3 {
    pub x: f32,
    pub y: f32,
    pub z: f32,
}

impl Vec3 {
    #[inline]
    pub const fn new(x: f32, y: f32, z: f32) -> Self {
        Self { x, y, z }
    }
}

#[derive(Clone, Copy, Debug)]
pub struct FastNoise {
    pub seed: u64,
}

impl FastNoise {
    pub const fn new(seed: u64) -> Self {
        Self { seed }
    }

    #[inline]
    pub fn hash2i(&self, x: i32, y: i32) -> u64 {
        let mut h = self.seed
            ^ ((x as i64 as u64).wrapping_mul(0x9E37_79B9_7F4A_7C15))
            ^ ((y as i64 as u64).wrapping_mul(0xBF58_476D_1CE4_E5B9));
        h = (h ^ (h >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
        h = (h ^ (h >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
        h ^ (h >> 31)
    }

    #[inline]
    pub fn hash_f32(&self, x: i32, y: i32) -> f32 {
        (self.hash2i(x, y) & 0x00FF_FFFF) as f32 * (1.0 / 16_777_215.0)
    }

    #[inline]
    pub fn value_noise(&self, x: f32, y: f32) -> f32 {
        let xi = x.floor() as i32;
        let yi = y.floor() as i32;
        let xf = x - xi as f32;
        let yf = y - yi as f32;

        let u = xf * xf * xf * (xf * (xf * 6.0 - 15.0) + 10.0);
        let v = yf * yf * yf * (yf * (yf * 6.0 - 15.0) + 10.0);

        let aa = self.hash_f32(xi, yi);
        let ba = self.hash_f32(xi + 1, yi);
        let ab = self.hash_f32(xi, yi + 1);
        let bb = self.hash_f32(xi + 1, yi + 1);

        let x1 = aa + u * (ba - aa);
        let x2 = ab + u * (bb - ab);
        x1 + v * (x2 - x1)
    }

    pub fn fbm(&self, mut x: f32, mut y: f32, octaves: u32) -> f32 {
        let mut value = 0.0;
        let mut amp = 0.5;
        let mut norm = 0.0;
        for _ in 0..octaves {
            value += amp * self.value_noise(x, y);
            norm += amp;
            x = x * 2.03 + 13.7;
            y = y * 2.03 + 29.1;
            amp *= 0.5;
        }
        value / norm
    }
}

// ============================================================================
// 3. DARK FANTASY OPEN WORLD: 6 BIOMES & 3D VOXEL COLUMNS
// ============================================================================

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Biome {
    AshenMire,
    SunkenCathedral,
    ObsidianCrags,
    WitheredWeald,
    ForsakenCitadel,
    CinderAbyss,
}

impl Biome {
    pub const fn name(self) -> &'static str {
        match self {
            Biome::AshenMire => "ASHEN MIRE (LV.1-5)",
            Biome::SunkenCathedral => "SUNKEN CATHEDRAL OF VEYR (LV.1-8)",
            Biome::WitheredWeald => "WITHERED WEALD (LV.6-12)",
            Biome::ObsidianCrags => "OBSIDIAN CRAGS (LV.10-18)",
            Biome::ForsakenCitadel => "FORSAKEN CITADEL (LV.15-24)",
            Biome::CinderAbyss => "THE CINDER ABYSS (LV.20-30)",
        }
    }

    pub const fn subtitle(self) -> &'static str {
        match self {
            Biome::AshenMire => "Where drowned bells still toll beneath the peat",
            Biome::SunkenCathedral => "Sanctuary shard where pilgrims gather around the First Kiln",
            Biome::WitheredWeald => "Petrified boughs clawing at a sunless sky",
            Biome::ObsidianCrags => "Glass ridges split by veins of molten ember",
            Biome::ForsakenCitadel => "Bastion of the Iron Penitents",
            Biome::CinderAbyss => "Raid threshold where the Ashen Sovereign reigns",
        }
    }

    pub const fn base_enemy_level(self) -> i32 {
        match self {
            Biome::SunkenCathedral => 1,
            Biome::AshenMire => 3,
            Biome::WitheredWeald => 7,
            Biome::ObsidianCrags => 12,
            Biome::ForsakenCitadel => 17,
            Biome::CinderAbyss => 24,
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum TileKind {
    AshGround,
    MireWater,
    StoneFloor,
    BridgePlank,
    EmberFissure,
    AbyssChasm,
    StoneWall,
    CathedralPillar,
    WitheredTree,
    ObsidianSpire,
    BonfireShrine,
    LoreMonolith,
    RelicAltar,
}

#[derive(Clone, Copy, Debug)]
pub struct WorldColumn {
    pub kind: TileKind,
    pub biome: Biome,
    pub base_z: u8,
    pub height: u8,
    pub floor_glyph: u8,
    pub wall_glyph: u8,
    pub roof_glyph: u8,
    pub base_color: Color,
    pub roof_color: Color,
    pub light_emission: f32,
    pub light_color: Color,
    pub lore_id: u8,
    pub activated: bool,
}

impl WorldColumn {
    #[inline]
    pub fn is_walkable(&self) -> bool {
        !matches!(
            self.kind,
            TileKind::StoneWall
                | TileKind::CathedralPillar
                | TileKind::WitheredTree
                | TileKind::ObsidianSpire
                | TileKind::AbyssChasm
        )
    }

    #[inline]
    pub fn blocks_sight(&self) -> bool {
        self.height >= 2
    }

    #[inline]
    pub fn total_z(&self) -> f32 {
        (self.base_z + self.height) as f32
    }
}

pub const LORE_INSCRIPTIONS: &[(&str, &str)] = &[
    (
        "STELA OF THE FIRST KILN",
        "\"When the Sun cracked like kiln-clay, the Lords of Veyr bound its last ember in iron.\"",
    ),
    (
        "BELL-WARDEN'S CONFESSION",
        "\"We rang the bronze until our hands turned to ash. None answered from the upper sky.\"",
    ),
    (
        "EDICT OF THE WITHERED WEALD",
        "\"Do not drink the silver sap. The trees remember every pilgrim who slept beneath their roots.\"",
    ),
    (
        "OBSIDIAN COVENANT",
        "\"Three seals hold the Cinder Sovereign: Bone in the Mire, Choir in the Nave, Glass on the Peak.\"",
    ),
    (
        "CITADEL WATCHMAN'S TALLY",
        "\"Day 4,019 of the Long Night. The shadows now stand taller than the battlements.\"",
    ),
    (
        "ABYSSAL THRESHOLD",
        "\"Look down only if you carry three kindled flames; the dark looks upward with borrowed eyes.\"",
    ),
];

pub struct Chunk {
    pub cx: i32,
    pub cy: i32,
    pub columns: Vec<WorldColumn>,
}

impl Chunk {
    #[inline]
    pub fn get(&self, lx: i32, ly: i32) -> &WorldColumn {
        &self.columns[(ly * CHUNK_SIZE + lx) as usize]
    }

    #[inline]
    pub fn get_mut(&mut self, lx: i32, ly: i32) -> &mut WorldColumn {
        &mut self.columns[(ly * CHUNK_SIZE + lx) as usize]
    }
}

pub struct OpenWorld {
    pub noise: FastNoise,
    pub chunks: HashMap<(i32, i32), Chunk>,
    /// Persistent record of activated world tiles `(wx, wy)` so unloaded chunks remember state.
    pub activated_tiles: HashMap<(i32, i32), bool>,
    pub discovered_shrines: Vec<(i32, i32)>,
}

impl OpenWorld {
    pub fn new(seed: u64) -> Self {
        let mut activated_tiles = HashMap::with_capacity(64);
        activated_tiles.insert((0, -2), true);
        let mut world = Self {
            noise: FastNoise::new(seed),
            chunks: HashMap::with_capacity(49),
            activated_tiles,
            discovered_shrines: vec![(0, -2)],
        };
        for cy in -1..=1 {
            for cx in -1..=1 {
                world.ensure_chunk(cx, cy);
            }
        }
        world
    }

    #[inline]
    pub fn world_to_chunk(wx: i32, wy: i32) -> ((i32, i32), (i32, i32)) {
        let cx = wx.div_euclid(CHUNK_SIZE);
        let cy = wy.div_euclid(CHUNK_SIZE);
        let lx = wx.rem_euclid(CHUNK_SIZE);
        let ly = wy.rem_euclid(CHUNK_SIZE);
        ((cx, cy), (lx, ly))
    }

    pub fn ensure_chunk(&mut self, cx: i32, cy: i32) {
        if !self.chunks.contains_key(&(cx, cy)) {
            let chunk = self.generate_chunk(cx, cy);
            self.chunks.insert((cx, cy), chunk);
        }
    }

    /// Evicts chunks outside `MAX_CHUNK_RADIUS` from `(center_cx, center_cy)` to cap memory usage.
    pub fn prune_distant_chunks(&mut self, center_cx: i32, center_cy: i32) {
        if self.chunks.len() > 49 {
            self.chunks.retain(|&(cx, cy), _| {
                (cx - center_cx).abs() <= MAX_CHUNK_RADIUS
                    && (cy - center_cy).abs() <= MAX_CHUNK_RADIUS
            });
        }
    }

    pub fn column_at(&mut self, wx: i32, wy: i32) -> WorldColumn {
        let ((cx, cy), (lx, ly)) = Self::world_to_chunk(wx, wy);
        self.ensure_chunk(cx, cy);
        *self.chunks.get(&(cx, cy)).unwrap().get(lx, ly)
    }

    #[inline]
    pub fn column_at_ref(&self, wx: i32, wy: i32) -> Option<&WorldColumn> {
        let ((cx, cy), (lx, ly)) = Self::world_to_chunk(wx, wy);
        self.chunks.get(&(cx, cy)).map(|c| c.get(lx, ly))
    }

    pub fn mark_tile_activated(&mut self, wx: i32, wy: i32) {
        self.activated_tiles.insert((wx, wy), true);
        let ((cx, cy), (lx, ly)) = Self::world_to_chunk(wx, wy);
        self.ensure_chunk(cx, cy);
        if let Some(chunk) = self.chunks.get_mut(&(cx, cy)) {
            chunk.get_mut(lx, ly).activated = true;
        }
    }

    pub fn sample_biome(&self, wx: i32, wy: i32) -> Biome {
        let dist_sq = wx * wx + wy * wy;
        if dist_sq < 576 {
            return Biome::SunkenCathedral;
        }
        let temp = self.noise.fbm(wx as f32 * 0.012, wy as f32 * 0.012, 3);
        let moisture = self
            .noise
            .fbm(wx as f32 * 0.012 + 91.0, wy as f32 * 0.012 - 47.0, 3);

        if dist_sq > 11025 && temp > 0.54 {
            Biome::CinderAbyss
        } else if temp > 0.62 {
            Biome::ObsidianCrags
        } else if moisture > 0.60 {
            Biome::AshenMire
        } else if moisture < 0.38 {
            Biome::ForsakenCitadel
        } else {
            Biome::WitheredWeald
        }
    }

    fn generate_chunk(&self, cx: i32, cy: i32) -> Chunk {
        let mut columns = Vec::with_capacity((CHUNK_SIZE * CHUNK_SIZE) as usize);
        for ly in 0..CHUNK_SIZE {
            for lx in 0..CHUNK_SIZE {
                let wx = cx * CHUNK_SIZE + lx;
                let wy = cy * CHUNK_SIZE + ly;
                let mut col = self.generate_column(wx, wy);
                if self.activated_tiles.get(&(wx, wy)).copied().unwrap_or(false) {
                    col.activated = true;
                }
                columns.push(col);
            }
        }
        Chunk { cx, cy, columns }
    }

    fn generate_column(&self, wx: i32, wy: i32) -> WorldColumn {
        let dist_sq = wx * wx + wy * wy;
        if dist_sq <= 64 {
            if wx == 0 && wy == -2 {
                return WorldColumn {
                    kind: TileKind::BonfireShrine,
                    biome: Biome::SunkenCathedral,
                    base_z: 1,
                    height: 2,
                    floor_glyph: b'&',
                    wall_glyph: b'*',
                    roof_glyph: b'^',
                    base_color: palette::EMBER_CORE,
                    roof_color: palette::GOLD_RELIC,
                    light_emission: 1.0,
                    light_color: palette::EMBER_CORE,
                    lore_id: 0,
                    activated: true,
                };
            }
            if wx == 3 && wy == -2 {
                return WorldColumn {
                    kind: TileKind::LoreMonolith,
                    biome: Biome::SunkenCathedral,
                    base_z: 1,
                    height: 3,
                    floor_glyph: b'O',
                    wall_glyph: b'|',
                    roof_glyph: b'+',
                    base_color: palette::RUNE_CYAN,
                    roof_color: palette::BONE_WHITE,
                    light_emission: 0.45,
                    light_color: palette::RUNE_CYAN,
                    lore_id: 0,
                    activated: false,
                };
            }
            if (wx.abs() == 6 && wy.abs() == 6) || (wx.abs() == 6 && wy == 0) {
                return WorldColumn {
                    kind: TileKind::CathedralPillar,
                    biome: Biome::SunkenCathedral,
                    base_z: 1,
                    height: 5,
                    floor_glyph: b'#',
                    wall_glyph: b'|',
                    roof_glyph: b'+',
                    base_color: palette::ASH_LIGHT,
                    roof_color: palette::BONE_WHITE,
                    light_emission: 0.0,
                    light_color: palette::VOID_BG,
                    lore_id: 0,
                    activated: false,
                };
            }
            let checker = ((wx + wy).rem_euclid(2) == 0) as usize;
            return WorldColumn {
                kind: TileKind::StoneFloor,
                biome: Biome::SunkenCathedral,
                base_z: 1,
                height: 0,
                floor_glyph: [b'.', b','][checker],
                wall_glyph: b'|',
                roof_glyph: b'.',
                base_color: palette::ASH_DIM,
                roof_color: palette::ASH_LIGHT,
                light_emission: 0.0,
                light_color: palette::VOID_BG,
                lore_id: 0,
                activated: false,
            };
        }

        let biome = self.sample_biome(wx, wy);
        let elev_n = self.noise.fbm(wx as f32 * 0.045, wy as f32 * 0.045, 3);
        let detail_h = self.noise.hash_f32(wx, wy);

        let road_wave_x = (wy as f32 * 0.07).sin() * 4.5;
        let road_wave_y = (wx as f32 * 0.07).cos() * 4.5;
        let on_road = ((wx as f32 - road_wave_x).abs() < 1.8)
            || ((wy as f32 - road_wave_y).abs() < 1.8);

        if on_road {
            if wx.rem_euclid(48) == 0 && wy.rem_euclid(48) == 0 {
                return WorldColumn {
                    kind: TileKind::BonfireShrine,
                    biome,
                    base_z: 1,
                    height: 2,
                    floor_glyph: b'&',
                    wall_glyph: b'*',
                    roof_glyph: b'^',
                    base_color: palette::EMBER_CORE,
                    roof_color: palette::GOLD_RELIC,
                    light_emission: 0.95,
                    light_color: palette::EMBER_CORE,
                    lore_id: 0,
                    activated: false,
                };
            }
            return WorldColumn {
                kind: TileKind::BridgePlank,
                biome,
                base_z: 1,
                height: 0,
                floor_glyph: if detail_h > 0.5 { b'=' } else { b':' },
                wall_glyph: b'#',
                roof_glyph: b'=',
                base_color: palette::ASH_LIGHT,
                roof_color: palette::ASH_LIGHT,
                light_emission: 0.0,
                light_color: palette::VOID_BG,
                lore_id: 0,
                activated: false,
            };
        }

        if detail_h > 0.9965 {
            let lore_idx = (self.noise.hash2i(wx, wy) as usize) % LORE_INSCRIPTIONS.len();
            return WorldColumn {
                kind: TileKind::LoreMonolith,
                biome,
                base_z: 1,
                height: 4,
                floor_glyph: b'O',
                wall_glyph: b'|',
                roof_glyph: b'+',
                base_color: palette::RUNE_CYAN,
                roof_color: palette::BONE_WHITE,
                light_emission: 0.4,
                light_color: palette::RUNE_CYAN,
                lore_id: lore_idx as u8,
                activated: false,
            };
        } else if detail_h > 0.9935 {
            return WorldColumn {
                kind: TileKind::RelicAltar,
                biome,
                base_z: 1,
                height: 2,
                floor_glyph: b'=',
                wall_glyph: b'|',
                roof_glyph: b'*',
                base_color: palette::GOLD_RELIC,
                roof_color: palette::BONE_WHITE,
                light_emission: 0.35,
                light_color: palette::GOLD_RELIC,
                lore_id: 0,
                activated: false,
            };
        }

        match biome {
            Biome::SunkenCathedral => {
                let gx = wx.rem_euclid(8);
                let gy = wy.rem_euclid(8);
                if gx == 0 && gy == 0 && detail_h > 0.22 {
                    WorldColumn {
                        kind: TileKind::CathedralPillar,
                        biome,
                        base_z: 1,
                        height: 6,
                        floor_glyph: b'#',
                        wall_glyph: b'|',
                        roof_glyph: b'+',
                        base_color: palette::ASH_LIGHT,
                        roof_color: palette::BONE_WHITE,
                        light_emission: 0.0,
                        light_color: palette::VOID_BG,
                        lore_id: 0,
                        activated: false,
                    }
                } else if (gx == 0 || gy == 0) && elev_n > 0.62 && detail_h > 0.45 {
                    WorldColumn {
                        kind: TileKind::StoneWall,
                        biome,
                        base_z: 1,
                        height: 4,
                        floor_glyph: b'#',
                        wall_glyph: b'#',
                        roof_glyph: b'=',
                        base_color: palette::ASH_DIM,
                        roof_color: palette::ASH_LIGHT,
                        light_emission: 0.0,
                        light_color: palette::VOID_BG,
                        lore_id: 0,
                        activated: false,
                    }
                } else {
                    WorldColumn {
                        kind: TileKind::StoneFloor,
                        biome,
                        base_z: 1,
                        height: 0,
                        floor_glyph: if (wx + wy).rem_euclid(2) == 0 {
                            b'.'
                        } else {
                            b'\''
                        },
                        wall_glyph: b'|',
                        roof_glyph: b'.',
                        base_color: palette::ASH_DIM,
                        roof_color: palette::ASH_LIGHT,
                        light_emission: 0.0,
                        light_color: palette::VOID_BG,
                        lore_id: 0,
                        activated: false,
                    }
                }
            }
            Biome::AshenMire => {
                if elev_n < 0.42 {
                    WorldColumn {
                        kind: TileKind::MireWater,
                        biome,
                        base_z: 0,
                        height: 0,
                        floor_glyph: if detail_h > 0.5 { b'~' } else { b'-' },
                        wall_glyph: b'~',
                        roof_glyph: b'~',
                        base_color: palette::MIRE_MOSS,
                        roof_color: palette::MIRE_MOSS,
                        light_emission: 0.0,
                        light_color: palette::VOID_BG,
                        lore_id: 0,
                        activated: false,
                    }
                } else if detail_h > 0.88 {
                    WorldColumn {
                        kind: TileKind::WitheredTree,
                        biome,
                        base_z: 1,
                        height: 5,
                        floor_glyph: b'|',
                        wall_glyph: b'/',
                        roof_glyph: b'%',
                        base_color: palette::ASH_DIM,
                        roof_color: palette::MIRE_MOSS,
                        light_emission: 0.0,
                        light_color: palette::VOID_BG,
                        lore_id: 0,
                        activated: false,
                    }
                } else {
                    WorldColumn {
                        kind: TileKind::AshGround,
                        biome,
                        base_z: 1,
                        height: 0,
                        floor_glyph: if detail_h > 0.65 { b';' } else { b',' },
                        wall_glyph: b':',
                        roof_glyph: b',',
                        base_color: palette::MIRE_MOSS.scale(0.85),
                        roof_color: palette::ASH_DIM,
                        light_emission: 0.0,
                        light_color: palette::VOID_BG,
                        lore_id: 0,
                        activated: false,
                    }
                }
            }
            Biome::ObsidianCrags => {
                if elev_n > 0.66 {
                    let h = 4 + ((elev_n - 0.66) * 10.0) as u8;
                    WorldColumn {
                        kind: TileKind::ObsidianSpire,
                        biome,
                        base_z: 2,
                        height: h.min(7),
                        floor_glyph: b'#',
                        wall_glyph: b'/',
                        roof_glyph: b'^',
                        base_color: palette::ASH_DIM,
                        roof_color: palette::BONE_WHITE,
                        light_emission: 0.0,
                        light_color: palette::VOID_BG,
                        lore_id: 0,
                        activated: false,
                    }
                } else if elev_n < 0.34 {
                    WorldColumn {
                        kind: TileKind::EmberFissure,
                        biome,
                        base_z: 0,
                        height: 0,
                        floor_glyph: b'~',
                        wall_glyph: b'*',
                        roof_glyph: b'*',
                        base_color: palette::EMBER_GLOW,
                        roof_color: palette::EMBER_CORE,
                        light_emission: 0.55,
                        light_color: palette::EMBER_GLOW,
                        lore_id: 0,
                        activated: false,
                    }
                } else {
                    WorldColumn {
                        kind: TileKind::AshGround,
                        biome,
                        base_z: 2,
                        height: 0,
                        floor_glyph: if detail_h > 0.6 { b':' } else { b'.' },
                        wall_glyph: b'#',
                        roof_glyph: b'.',
                        base_color: palette::ASH_DIM,
                        roof_color: palette::ASH_LIGHT,
                        light_emission: 0.0,
                        light_color: palette::VOID_BG,
                        lore_id: 0,
                        activated: false,
                    }
                }
            }
            Biome::WitheredWeald => {
                if detail_h > 0.80 && elev_n > 0.44 {
                    WorldColumn {
                        kind: TileKind::WitheredTree,
                        biome,
                        base_z: 1,
                        height: 5 + (detail_h * 2.0) as u8,
                        floor_glyph: b'|',
                        wall_glyph: b'|',
                        roof_glyph: if detail_h > 0.9 { b'*' } else { b'%' },
                        base_color: palette::ASH_DIM,
                        roof_color: palette::ASH_LIGHT,
                        light_emission: 0.0,
                        light_color: palette::VOID_BG,
                        lore_id: 0,
                        activated: false,
                    }
                } else {
                    WorldColumn {
                        kind: TileKind::AshGround,
                        biome,
                        base_z: 1,
                        height: 0,
                        floor_glyph: match (detail_h * 4.0) as usize {
                            0 => b'.',
                            1 => b',',
                            2 => b'\'',
                            _ => b'`',
                        },
                        wall_glyph: b'|',
                        roof_glyph: b'.',
                        base_color: palette::ASH_DIM,
                        roof_color: palette::ASH_LIGHT,
                        light_emission: 0.0,
                        light_color: palette::VOID_BG,
                        lore_id: 0,
                        activated: false,
                    }
                }
            }
            Biome::ForsakenCitadel => {
                let bx = wx.rem_euclid(12);
                let by = wy.rem_euclid(12);
                let is_bastion_wall =
                    (bx == 0 || by == 0) && (bx != 6 && by != 6) && elev_n > 0.43;
                if is_bastion_wall {
                    WorldColumn {
                        kind: TileKind::StoneWall,
                        biome,
                        base_z: 2,
                        height: if bx == 0 && by == 0 { 7 } else { 5 },
                        floor_glyph: b'#',
                        wall_glyph: b'#',
                        roof_glyph: if bx == 0 && by == 0 { b'^' } else { b'=' },
                        base_color: palette::ASH_DIM,
                        roof_color: palette::BONE_WHITE,
                        light_emission: 0.0,
                        light_color: palette::VOID_BG,
                        lore_id: 0,
                        activated: false,
                    }
                } else {
                    WorldColumn {
                        kind: TileKind::StoneFloor,
                        biome,
                        base_z: 2,
                        height: 0,
                        floor_glyph: if (wx + wy).rem_euclid(2) == 0 {
                            b'+'
                        } else {
                            b'.'
                        },
                        wall_glyph: b'#',
                        roof_glyph: b'+',
                        base_color: palette::ASH_DIM,
                        roof_color: palette::ASH_LIGHT,
                        light_emission: 0.0,
                        light_color: palette::VOID_BG,
                        lore_id: 0,
                        activated: false,
                    }
                }
            }
            Biome::CinderAbyss => {
                if elev_n < 0.45 {
                    WorldColumn {
                        kind: TileKind::AbyssChasm,
                        biome,
                        base_z: 0,
                        height: 0,
                        floor_glyph: b' ',
                        wall_glyph: b':',
                        roof_glyph: b' ',
                        base_color: palette::VOID_BG,
                        roof_color: palette::ABYSS_VIOLET,
                        light_emission: 0.0,
                        light_color: palette::VOID_BG,
                        lore_id: 0,
                        activated: false,
                    }
                } else if detail_h > 0.86 {
                    WorldColumn {
                        kind: TileKind::ObsidianSpire,
                        biome,
                        base_z: 2,
                        height: 7,
                        floor_glyph: b'#',
                        wall_glyph: b'|',
                        roof_glyph: b'V',
                        base_color: palette::ABYSS_VIOLET,
                        roof_color: palette::EMBER_CORE,
                        light_emission: 0.3,
                        light_color: palette::ABYSS_VIOLET,
                        lore_id: 0,
                        activated: false,
                    }
                } else {
                    WorldColumn {
                        kind: TileKind::AshGround,
                        biome,
                        base_z: 2,
                        height: 0,
                        floor_glyph: b':',
                        wall_glyph: b'|',
                        roof_glyph: b':',
                        base_color: palette::ABYSS_VIOLET.scale(0.85),
                        roof_color: palette::BONE_WHITE,
                        light_emission: 0.0,
                        light_color: palette::VOID_BG,
                        lore_id: 0,
                        activated: false,
                    }
                }
            }
        }
    }
}

// ============================================================================
// 4. LOOT DROPS, 5 RARITY TIERS & 6-SLOT EQUIPMENT SYSTEM
// ============================================================================

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum Rarity {
    Common,
    Uncommon,
    Rare,
    Epic,
    Legendary,
}

impl Rarity {
    pub const fn tag(self) -> &'static str {
        match self {
            Rarity::Common => "[C]",
            Rarity::Uncommon => "[U]",
            Rarity::Rare => "[R]",
            Rarity::Epic => "[E]",
            Rarity::Legendary => "[L]",
        }
    }

    pub const fn name(self) -> &'static str {
        match self {
            Rarity::Common => "Common",
            Rarity::Uncommon => "Uncommon",
            Rarity::Rare => "Rare",
            Rarity::Epic => "Epic",
            Rarity::Legendary => "Legendary",
        }
    }

    pub const fn color(self) -> Color {
        match self {
            Rarity::Common => palette::ASH_LIGHT,
            Rarity::Uncommon => palette::MIRE_MOSS,
            Rarity::Rare => palette::RUNE_CYAN,
            Rarity::Epic => palette::ABYSS_VIOLET,
            Rarity::Legendary => palette::GOLD_RELIC,
        }
    }

    pub const fn beam_height(self) -> u8 {
        match self {
            Rarity::Common => 0,
            Rarity::Uncommon => 1,
            Rarity::Rare => 2,
            Rarity::Epic => 4,
            Rarity::Legendary => 6,
        }
    }

    pub const fn stat_multiplier(self) -> i32 {
        match self {
            Rarity::Common => 1,
            Rarity::Uncommon => 2,
            Rarity::Rare => 3,
            Rarity::Epic => 5,
            Rarity::Legendary => 8,
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum EquipSlot {
    Weapon = 0,
    Armor = 1,
    Helm = 2,
    Ring = 3,
    Amulet = 4,
    Relic = 5,
}

impl EquipSlot {
    pub const ALL: [EquipSlot; 6] = [
        EquipSlot::Weapon,
        EquipSlot::Armor,
        EquipSlot::Helm,
        EquipSlot::Ring,
        EquipSlot::Amulet,
        EquipSlot::Relic,
    ];

    pub const fn label(self) -> &'static str {
        match self {
            EquipSlot::Weapon => "WPN",
            EquipSlot::Armor => "ARM",
            EquipSlot::Helm => "HLM",
            EquipSlot::Ring => "RNG",
            EquipSlot::Amulet => "AML",
            EquipSlot::Relic => "RLC",
        }
    }

    pub const fn ground_glyph(self) -> u8 {
        match self {
            EquipSlot::Weapon => b'/',
            EquipSlot::Armor => b'[',
            EquipSlot::Helm => b'^',
            EquipSlot::Ring => b'o',
            EquipSlot::Amulet => b'?',
            EquipSlot::Relic => b'!',
        }
    }
}

#[derive(Clone, Debug)]
pub struct LootItem {
    pub id: u64,
    pub name: String,
    pub slot: EquipSlot,
    pub rarity: Rarity,
    pub item_level: i32,
    pub atk_bonus: i32,
    pub def_bonus: i32,
    pub hp_bonus: i32,
    pub crit_pct: i32,
    pub spell_bonus: i32,
}

impl LootItem {
    pub fn generate(noise: &FastNoise, drop_seed: i32, enemy_level: i32, magic_find_pct: i32) -> Self {
        let roll = noise.hash_f32(drop_seed, enemy_level * 13) + (magic_find_pct as f32 * 0.0025);
        let rarity = if roll > 0.965 {
            Rarity::Legendary
        } else if roll > 0.86 {
            Rarity::Epic
        } else if roll > 0.68 {
            Rarity::Rare
        } else if roll > 0.40 {
            Rarity::Uncommon
        } else {
            Rarity::Common
        };

        let slot_idx = (noise.hash2i(drop_seed + 7, enemy_level) as usize) % 6;
        let slot = EquipSlot::ALL[slot_idx];

        let prefixes = [
            "Ashen",
            "Cinderforged",
            "Abyssal",
            "Veyr's",
            "Obsidian",
            "Hollow",
            "Sanctum",
            "Blood-Tempered",
        ];
        let bases = match slot {
            EquipSlot::Weapon => ["Greatsword", "Hex-Katana", "Pyro-Staff", "Warhammer"],
            EquipSlot::Armor => ["Scale Mail", "Drowned Plate", "Choir Vestment", "Iron Cuirass"],
            EquipSlot::Helm => ["Crown", "Penitent Visor", "Bone Hood", "Greathelm"],
            EquipSlot::Ring => ["Signet", "Embercoil Band", "Void Ring", "Oath Loop"],
            EquipSlot::Amulet => ["Eclipse Talisman", "Soul Pendant", "Kiln Choker", "Rosary"],
            EquipSlot::Relic => ["Chalice", "Cinder Effigy", "Grimoire", "Runestone"],
        };
        let suffixes = [
            "of the Kiln",
            "of Undying",
            "of Ruin",
            "of the Choir",
            "of Ash",
            "of Critical Reckoning",
        ];

        let p_idx = (noise.hash2i(drop_seed + 19, 1) as usize) % prefixes.len();
        let b_idx = (noise.hash2i(drop_seed + 23, 2) as usize) % bases.len();
        let s_idx = (noise.hash2i(drop_seed + 31, 3) as usize) % suffixes.len();

        let mult = rarity.stat_multiplier();
        let ilvl = enemy_level.max(1);
        let scale = ilvl * mult;

        let (atk_bonus, def_bonus, hp_bonus, crit_pct, spell_bonus) = match slot {
            EquipSlot::Weapon => (4 + scale * 2, 0, scale * 2, mult * 2, scale),
            EquipSlot::Armor => (0, 3 + scale, 12 + scale * 6, 0, 0),
            EquipSlot::Helm => (scale / 2, 2 + scale, 8 + scale * 4, mult, 0),
            EquipSlot::Ring => (scale, scale / 2, scale * 2, 2 + mult * 2, scale),
            EquipSlot::Amulet => (scale / 2, scale / 2, 6 + scale * 3, mult, 4 + scale * 2),
            EquipSlot::Relic => (scale, scale, 10 + scale * 4, mult * 2, 5 + scale * 2),
        };

        let name = format!(
            "{} {} {} {}",
            rarity.tag(),
            prefixes[p_idx],
            bases[b_idx],
            suffixes[s_idx]
        );

        Self {
            id: noise.hash2i(drop_seed, ilvl),
            name,
            slot,
            rarity,
            item_level: ilvl,
            atk_bonus,
            def_bonus,
            hp_bonus,
            crit_pct,
            spell_bonus,
        }
    }

    #[inline]
    pub fn power_score(&self) -> i32 {
        self.atk_bonus * 3
            + self.def_bonus * 3
            + self.hp_bonus / 2
            + self.crit_pct * 4
            + self.spell_bonus * 2
    }
}

#[derive(Clone, Debug)]
pub struct WorldLootDrop {
    pub pos: Vec2,
    pub item: Option<LootItem>,
    pub cinder_ash: u32,
    pub flask_refill: u8,
    pub age: f32,
}

// ============================================================================
// 5. MMORPG CLASSES, LEVELING SYSTEM, ATTRIBUTES & REMOTE PLAYERS
// ============================================================================

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum MmoClass {
    AshenKnight = 0,
    AbyssalHexblade = 1,
    CinderPyromancer = 2,
    SanctumCleric = 3,
}

impl MmoClass {
    pub const ALL: [MmoClass; 4] = [
        MmoClass::AshenKnight,
        MmoClass::AbyssalHexblade,
        MmoClass::CinderPyromancer,
        MmoClass::SanctumCleric,
    ];

    pub const fn name(self) -> &'static str {
        match self {
            MmoClass::AshenKnight => "Ashen Knight",
            MmoClass::AbyssalHexblade => "Abyssal Hexblade",
            MmoClass::CinderPyromancer => "Cinder Pyromancer",
            MmoClass::SanctumCleric => "Sanctum Cleric",
        }
    }

    pub const fn short_tag(self) -> &'static str {
        match self {
            MmoClass::AshenKnight => "KNT",
            MmoClass::AbyssalHexblade => "HEX",
            MmoClass::CinderPyromancer => "PYR",
            MmoClass::SanctumCleric => "CLR",
        }
    }

    pub const fn crown_glyph(self) -> u8 {
        match self {
            MmoClass::AshenKnight => b'^',
            MmoClass::AbyssalHexblade => b'x',
            MmoClass::CinderPyromancer => b'*',
            MmoClass::SanctumCleric => b'+',
        }
    }

    pub const fn skill_name(self) -> &'static str {
        match self {
            MmoClass::AshenKnight => "IRON SHOCKWAVE",
            MmoClass::AbyssalHexblade => "SHADOW EXECUTIONS",
            MmoClass::CinderPyromancer => "CINDER FIRESTORM",
            MmoClass::SanctumCleric => "SANCTUM SMITE & HEAL",
        }
    }
}

#[derive(Clone, Debug)]
pub struct RemotePlayer {
    pub peer_id: u32,
    pub name: &'static str,
    pub class: MmoClass,
    pub level: i32,
    pub pos: Vec2,
    pub vel: Vec2,
    pub hp: i32,
    pub max_hp: i32,
    pub in_party: bool,
    pub attack_anim: f32,
    pub chat_bubble: Option<(&'static str, f32)>,
}

#[derive(Clone, Copy, Debug)]
pub struct MmoPacket {
    pub magic: u32,
    pub peer_id: u32,
    pub class_id: u8,
    pub level: u8,
    pub pos_x: f32,
    pub pos_y: f32,
    pub hp: i32,
    pub max_hp: i32,
    pub is_attacking: u8,
}

impl MmoPacket {
    pub const MAGIC: u32 = 0xA547_4D4D;

    pub fn to_bytes(&self) -> [u8; 27] {
        let mut b = [0u8; 27];
        b[0..4].copy_from_slice(&self.magic.to_le_bytes());
        b[4..8].copy_from_slice(&self.peer_id.to_le_bytes());
        b[8] = self.class_id;
        b[9] = self.level;
        b[10..14].copy_from_slice(&self.pos_x.to_le_bytes());
        b[14..18].copy_from_slice(&self.pos_y.to_le_bytes());
        b[18..22].copy_from_slice(&self.hp.to_le_bytes());
        b[22..26].copy_from_slice(&self.max_hp.to_le_bytes());
        b[26] = self.is_attacking;
        b
    }

    pub fn from_bytes(b: &[u8]) -> Option<Self> {
        if b.len() < 27 {
            return None;
        }
        let magic = u32::from_le_bytes([b[0], b[1], b[2], b[3]]);
        if magic != Self::MAGIC {
            return None;
        }
        Some(Self {
            magic,
            peer_id: u32::from_le_bytes([b[4], b[5], b[6], b[7]]),
            class_id: b[8],
            level: b[9],
            pos_x: f32::from_le_bytes([b[10], b[11], b[12], b[13]]),
            pos_y: f32::from_le_bytes([b[14], b[15], b[16], b[17]]),
            hp: i32::from_le_bytes([b[18], b[19], b[20], b[21]]),
            max_hp: i32::from_le_bytes([b[22], b[23], b[24], b[25]]),
            is_attacking: b[26],
        })
    }
}

pub struct MmoNetClient {
    pub local_peer_id: u32,
    pub socket: Option<UdpSocket>,
    pub shard_addr: &'static str,
    pub sync_timer: f32,
    pub packets_sent: u64,
    pub packets_received: u64,
}

impl MmoNetClient {
    pub fn new(local_peer_id: u32) -> Self {
        let socket = UdpSocket::bind("0.0.0.0:0").ok();
        if let Some(ref s) = socket {
            let _ = s.set_nonblocking(true);
        }
        Self {
            local_peer_id,
            socket,
            shard_addr: "127.0.0.1:17777",
            sync_timer: 0.0,
            packets_sent: 0,
            packets_received: 0,
        }
    }

    pub fn poll_and_broadcast(&mut self, dt: f32, out_pkt: MmoPacket, out_buf: &mut Vec<MmoPacket>) {
        out_buf.clear();
        self.sync_timer += dt;

        if let Some(ref sock) = self.socket {
            if self.sync_timer >= 0.10 {
                self.sync_timer = 0.0;
                let bytes = out_pkt.to_bytes();
                if sock.send_to(&bytes, self.shard_addr).is_ok() {
                    self.packets_sent += 1;
                }
            }
            let mut buf = [0u8; 64];
            while let Ok((len, _addr)) = sock.recv_from(&mut buf) {
                if let Some(pkt) = MmoPacket::from_bytes(&buf[..len]) {
                    if pkt.peer_id != self.local_peer_id {
                        self.packets_received += 1;
                        out_buf.push(pkt);
                    }
                }
            }
        }
    }
}

// ============================================================================
// 6. ENEMIES, WORLD RAID BOSSES & PLAYER RPG PROGRESSION
// ============================================================================

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum EnemyKind {
    HollowStalker,
    BogWraith,
    SanctumKnight,
    ObsidianGolem,
    AbyssalWarden,
    AshenSovereignRaidBoss,
}

impl EnemyKind {
    pub const fn glyph(self) -> u8 {
        match self {
            EnemyKind::HollowStalker => b's',
            EnemyKind::BogWraith => b'W',
            EnemyKind::SanctumKnight => b'K',
            EnemyKind::ObsidianGolem => b'G',
            EnemyKind::AbyssalWarden => b'A',
            EnemyKind::AshenSovereignRaidBoss => b'S',
        }
    }

    pub const fn crown_glyph(self) -> u8 {
        match self {
            EnemyKind::HollowStalker => b'\'',
            EnemyKind::BogWraith => b'~',
            EnemyKind::SanctumKnight => b'^',
            EnemyKind::ObsidianGolem => b'#',
            EnemyKind::AbyssalWarden => b'V',
            EnemyKind::AshenSovereignRaidBoss => b'@',
        }
    }

    pub const fn name(self) -> &'static str {
        match self {
            EnemyKind::HollowStalker => "Hollow Stalker",
            EnemyKind::BogWraith => "Bog Wraith",
            EnemyKind::SanctumKnight => "Sanctum Knight",
            EnemyKind::ObsidianGolem => "Obsidian Golem",
            EnemyKind::AbyssalWarden => "Abyssal Warden",
            EnemyKind::AshenSovereignRaidBoss => "[RAID BOSS] THE ASHEN SOVEREIGN",
        }
    }

    pub const fn height(self) -> u8 {
        match self {
            EnemyKind::HollowStalker => 2,
            EnemyKind::BogWraith => 3,
            EnemyKind::SanctumKnight => 3,
            EnemyKind::ObsidianGolem => 4,
            EnemyKind::AbyssalWarden => 4,
            EnemyKind::AshenSovereignRaidBoss => 6,
        }
    }

    pub const fn base_hp(self) -> i32 {
        match self {
            EnemyKind::HollowStalker => 45,
            EnemyKind::BogWraith => 75,
            EnemyKind::SanctumKnight => 130,
            EnemyKind::ObsidianGolem => 200,
            EnemyKind::AbyssalWarden => 260,
            EnemyKind::AshenSovereignRaidBoss => 1200,
        }
    }

    pub const fn base_damage(self) -> i32 {
        match self {
            EnemyKind::HollowStalker => 12,
            EnemyKind::BogWraith => 17,
            EnemyKind::SanctumKnight => 24,
            EnemyKind::ObsidianGolem => 32,
            EnemyKind::AbyssalWarden => 38,
            EnemyKind::AshenSovereignRaidBoss => 52,
        }
    }

    pub const fn speed(self) -> f32 {
        match self {
            EnemyKind::HollowStalker => 4.4,
            EnemyKind::BogWraith => 3.7,
            EnemyKind::SanctumKnight => 3.1,
            EnemyKind::ObsidianGolem => 2.1,
            EnemyKind::AbyssalWarden => 3.4,
            EnemyKind::AshenSovereignRaidBoss => 3.6,
        }
    }

    pub const fn color(self) -> Color {
        match self {
            EnemyKind::HollowStalker => palette::ASH_LIGHT,
            EnemyKind::BogWraith => palette::MIRE_MOSS,
            EnemyKind::SanctumKnight => palette::BONE_WHITE,
            EnemyKind::ObsidianGolem => palette::EMBER_GLOW,
            EnemyKind::AbyssalWarden => palette::ABYSS_VIOLET,
            EnemyKind::AshenSovereignRaidBoss => palette::GOLD_RELIC,
        }
    }
}

#[derive(Clone, Debug)]
pub struct Enemy {
    pub id: u64,
    pub kind: EnemyKind,
    pub level: i32,
    pub pos: Vec2,
    pub vel: Vec2,
    pub hp: i32,
    pub max_hp: i32,
    pub attack_cooldown: f32,
    pub windup_timer: f32,
    pub stagger_timer: f32,
    pub flash_timer: f32,
    pub is_raid_boss: bool,
}

impl Enemy {
    pub fn spawn(id: u64, kind: EnemyKind, level: i32, pos: Vec2) -> Self {
        let lvl = level.max(1);
        let max_hp = kind.base_hp() + (lvl - 1) * (kind.base_hp() / 5);
        Self {
            id,
            kind,
            level: lvl,
            pos,
            vel: Vec2::ZERO,
            hp: max_hp,
            max_hp,
            attack_cooldown: 0.8,
            windup_timer: 0.0,
            stagger_timer: 0.0,
            flash_timer: 0.0,
            is_raid_boss: kind == EnemyKind::AshenSovereignRaidBoss,
        }
    }

    #[inline]
    pub fn damage(&self) -> i32 {
        self.kind.base_damage() + (self.level - 1) * 3
    }

    #[inline]
    pub fn xp_reward(&self) -> u32 {
        let base = match self.kind {
            EnemyKind::HollowStalker => 28,
            EnemyKind::BogWraith => 45,
            EnemyKind::SanctumKnight => 80,
            EnemyKind::ObsidianGolem => 125,
            EnemyKind::AbyssalWarden => 170,
            EnemyKind::AshenSovereignRaidBoss => 950,
        };
        base + (self.level as u32) * 18
    }
}

#[derive(Clone, Copy, Debug)]
pub struct SlashArc {
    pub origin: Vec2,
    pub dir: Vec2,
    pub radius: f32,
    pub timer: f32,
    pub max_timer: f32,
    pub is_heavy: bool,
    pub is_pyro: bool,
}

#[derive(Clone, Copy, Debug)]
pub struct AshParticle {
    pub pos: Vec3,
    pub vel: Vec3,
    pub glyph: u8,
    pub color: Color,
    pub life: f32,
}

pub struct Player {
    pub name: &'static str,
    pub class: MmoClass,
    pub pos: Vec2,
    pub vel: Vec2,
    pub facing: Vec2,
    pub z: f32,
    pub level: i32,
    pub xp: u32,
    pub xp_to_next: u32,
    pub stat_points: i32,
    pub vit: i32,
    pub str_stat: i32,
    pub dex: i32,
    pub int_stat: i32,
    pub fai: i32,
    pub hp: i32,
    pub max_hp: i32,
    pub stamina: f32,
    pub max_stamina: f32,
    pub cinder_ash: u32,
    pub flasks: u8,
    pub max_flasks: u8,
    pub dodge_timer: f32,
    pub dodge_dir: Vec2,
    pub attack_cooldown: f32,
    pub hurt_timer: f32,
    pub levelup_fx_timer: f32,
    pub last_shrine: Vec2,
    pub equipped: [Option<LootItem>; 6],
    pub bag: Vec<LootItem>,
    pub kills: u32,
}

impl Player {
    pub fn new() -> Self {
        let mut p = Self {
            name: "AshPilgrim",
            class: MmoClass::AshenKnight,
            pos: Vec2::new(0.0, 2.0),
            vel: Vec2::ZERO,
            facing: Vec2::new(0.0, -1.0),
            z: 1.0,
            level: 1,
            xp: 0,
            xp_to_next: 100,
            stat_points: 0,
            vit: 12,
            str_stat: 12,
            dex: 10,
            int_stat: 10,
            fai: 10,
            hp: 150,
            max_hp: 150,
            stamina: 100.0,
            max_stamina: 100.0,
            cinder_ash: 50,
            flasks: 4,
            max_flasks: 4,
            dodge_timer: 0.0,
            dodge_dir: Vec2::new(0.0, -1.0),
            attack_cooldown: 0.0,
            hurt_timer: 0.0,
            levelup_fx_timer: 0.0,
            last_shrine: Vec2::new(0.0, 2.0),
            equipped: [None, None, None, None, None, None],
            bag: Vec::with_capacity(16),
            kills: 0,
        };
        p.recalculate_stats(true);
        p
    }

    pub fn recalculate_stats(&mut self, heal_to_full: bool) {
        let mut gear_hp = 0;
        for slot in &self.equipped {
            if let Some(ref item) = slot {
                gear_hp += item.hp_bonus;
            }
        }
        self.max_hp = 90 + self.vit * 10 + (self.level - 1) * 14 + gear_hp;
        self.max_stamina = 85.0 + (self.dex as f32) * 2.5 + (self.vit as f32) * 1.2;
        if heal_to_full {
            self.hp = self.max_hp;
            self.stamina = self.max_stamina;
        } else {
            self.hp = self.hp.min(self.max_hp);
        }
    }

    pub fn total_attack_power(&self) -> i32 {
        let gear_atk: i32 = self
            .equipped
            .iter()
            .filter_map(|s| s.as_ref().map(|i| i.atk_bonus))
            .sum();
        14 + self.str_stat * 2 + self.dex + (self.level - 1) * 3 + gear_atk
    }

    pub fn total_spell_power(&self) -> i32 {
        let gear_spell: i32 = self
            .equipped
            .iter()
            .filter_map(|s| s.as_ref().map(|i| i.spell_bonus))
            .sum();
        18 + self.int_stat * 3 + self.fai * 2 + (self.level - 1) * 4 + gear_spell
    }

    pub fn total_defense(&self) -> i32 {
        let gear_def: i32 = self
            .equipped
            .iter()
            .filter_map(|s| s.as_ref().map(|i| i.def_bonus))
            .sum();
        self.vit / 2 + self.str_stat / 3 + gear_def
    }

    pub fn total_crit_pct(&self) -> i32 {
        let gear_crit: i32 = self
            .equipped
            .iter()
            .filter_map(|s| s.as_ref().map(|i| i.crit_pct))
            .sum();
        (5 + self.dex / 2 + gear_crit).min(75)
    }

    pub fn magic_find_pct(&self) -> i32 {
        self.fai * 3 + self.level * 2
    }

    pub fn gain_xp(&mut self, amount: u32) -> bool {
        self.xp += amount;
        let mut leveled = false;
        while self.xp >= self.xp_to_next && self.level < 50 {
            self.xp -= self.xp_to_next;
            self.level += 1;
            self.xp_to_next = 100 + (self.level as u32 - 1) * 65 + (self.level as u32).pow(2) * 12;
            self.stat_points += 3;
            self.vit += 1;
            self.str_stat += 1;
            self.dex += 1;
            self.int_stat += 1;
            self.fai += 1;
            self.levelup_fx_timer = 2.5;
            self.recalculate_stats(true);
            leveled = true;
        }
        leveled
    }

    pub fn collect_loot_item(&mut self, item: LootItem) -> (&'static str, String) {
        let slot_idx = item.slot as usize;
        let item_name = item.name.clone();
        let should_equip = match self.equipped[slot_idx] {
            None => true,
            Some(ref cur) => item.power_score() > cur.power_score(),
        };

        if should_equip {
            if let Some(old) = self.equipped[slot_idx].replace(item) {
                if self.bag.len() < 16 {
                    self.bag.push(old);
                } else {
                    self.cinder_ash += 15;
                }
            }
            self.recalculate_stats(false);
            ("EQUIPPED UPGRADE", item_name)
        } else if self.bag.len() < 16 {
            self.bag.push(item);
            ("STORED IN BAG", item_name)
        } else {
            self.cinder_ash += 20 * (item.rarity.stat_multiplier() as u32);
            ("BAG FULL -> SALVAGED TO ASH", item_name)
        }
    }

    #[inline]
    pub fn is_invulnerable(&self) -> bool {
        self.dodge_timer > 0.08 || self.hurt_timer > 0.0
    }
}

// ============================================================================
// 7. MINIMALIST TOUCH CONTROLLER & OVERLAY MENU STATES
// ============================================================================

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum MenuState {
    Hidden,
    MainOverlay,
    StatsAndClass,
    InventoryAndLoot,
    MmoShardAndParty,
    WorldMap,
    LoreModal(u8),
}

#[derive(Clone, Debug, Default)]
pub struct TouchController {
    pub move_pointer_id: Option<u64>,
    pub move_origin: Vec2,
    pub move_current: Vec2,
    pub action_pointer_id: Option<u64>,
    pub action_origin: Vec2,
    pub action_current: Vec2,
    pub action_hold_time: f32,
    pub queued_light_attack: bool,
    pub queued_heavy_pyro: bool,
    pub queued_dodge: Option<Vec2>,
    pub queued_interact: bool,
    pub queued_heal: bool,
    pub queued_menu_toggle: bool,
    pub queued_menu_delta: i32,
}

impl TouchController {
    pub fn move_vector(&self) -> Vec2 {
        if self.move_pointer_id.is_some() {
            let delta = Vec2::new(
                self.move_current.x - self.move_origin.x,
                self.move_current.y - self.move_origin.y,
            );
            let max_radius = 0.09;
            let len = delta.length();
            if len < 0.008 {
                Vec2::ZERO
            } else {
                let strength = (len / max_radius).clamp(0.0, 1.0);
                let dir = delta.normalized();
                Vec2::new(dir.x * strength, dir.y * strength)
            }
        } else {
            Vec2::ZERO
        }
    }

    pub fn on_touch_start(&mut self, id: u64, norm_x: f32, norm_y: f32) {
        if norm_x > 0.88 && norm_y < 0.12 {
            self.queued_menu_toggle = true;
            return;
        }
        if norm_x < 0.22 && norm_y < 0.12 {
            self.queued_heal = true;
            return;
        }
        if norm_x > 0.80 && norm_y > 0.80 {
            self.queued_interact = true;
            return;
        }

        if norm_x < 0.5 && self.move_pointer_id.is_none() {
            self.move_pointer_id = Some(id);
            self.move_origin = Vec2::new(norm_x, norm_y);
            self.move_current = self.move_origin;
        } else if norm_x >= 0.5 && self.action_pointer_id.is_none() {
            self.action_pointer_id = Some(id);
            self.action_origin = Vec2::new(norm_x, norm_y);
            self.action_current = self.action_origin;
            self.action_hold_time = 0.0;
        }
    }

    pub fn on_touch_move(&mut self, id: u64, norm_x: f32, norm_y: f32) {
        if self.move_pointer_id == Some(id) {
            self.move_current = Vec2::new(norm_x, norm_y);
        } else if self.action_pointer_id == Some(id) {
            self.action_current = Vec2::new(norm_x, norm_y);
        }
    }

    pub fn on_touch_end(&mut self, id: u64) {
        if self.move_pointer_id == Some(id) {
            let delta_y = self.move_current.y - self.move_origin.y;
            if delta_y > 0.035 {
                self.queued_menu_delta = 1;
            } else if delta_y < -0.035 {
                self.queued_menu_delta = -1;
            }
            self.move_pointer_id = None;
        } else if self.action_pointer_id == Some(id) {
            let delta = Vec2::new(
                self.action_current.x - self.action_origin.x,
                self.action_current.y - self.action_origin.y,
            );
            let swipe_dist = delta.length();
            if swipe_dist > 0.045 {
                self.queued_dodge = Some(delta.normalized());
            } else if self.action_hold_time >= 0.35 {
                self.queued_heavy_pyro = true;
            } else {
                self.queued_light_attack = true;
            }
            self.action_pointer_id = None;
            self.action_hold_time = 0.0;
        }
    }
}

// ============================================================================
// 8. 3D TOP-DOWN ASCII FRAMEBUFFER & INSTANCED GPU PACKER
// ============================================================================

#[repr(C)]
#[derive(Clone, Copy, Debug, Default)]
pub struct AsciiCellInstance {
    pub col: f32,
    pub row: f32,
    pub glyph_index: f32,
    pub z_depth: f32,
    pub fg: [f32; 4],
    pub bg: [f32; 4],
}

#[derive(Clone, Copy, Debug)]
pub struct AsciiCell {
    pub glyph: u8,
    pub fg: Color,
    pub bg: Color,
    pub z_order: f32,
}

impl Default for AsciiCell {
    fn default() -> Self {
        Self {
            glyph: b' ',
            fg: palette::ASH_DIM,
            bg: palette::VOID_BG,
            z_order: -100.0,
        }
    }
}

pub struct AsciiScreenBuffer {
    pub cols: usize,
    pub rows: usize,
    pub cells: Vec<AsciiCell>,
    pub gpu_instances: Vec<AsciiCellInstance>,
}

impl AsciiScreenBuffer {
    pub fn new(cols: usize, rows: usize) -> Self {
        let count = cols * rows;
        let mut gpu_instances = vec![AsciiCellInstance::default(); count];
        for r in 0..rows {
            for c in 0..cols {
                let idx = r * cols + c;
                gpu_instances[idx].col = c as f32;
                gpu_instances[idx].row = r as f32;
            }
        }
        Self {
            cols,
            rows,
            cells: vec![AsciiCell::default(); count],
            gpu_instances,
        }
    }

    pub fn resize(&mut self, cols: usize, rows: usize) {
        let cols = cols.clamp(48, 160);
        let rows = rows.clamp(28, 90);
        if self.cols != cols || self.rows != rows {
            self.cols = cols;
            self.rows = rows;
            let count = cols * rows;
            self.cells.resize(count, AsciiCell::default());
            self.gpu_instances.resize(count, AsciiCellInstance::default());
            for r in 0..rows {
                for c in 0..cols {
                    let idx = r * cols + c;
                    self.gpu_instances[idx].col = c as f32;
                    self.gpu_instances[idx].row = r as f32;
                }
            }
        }
    }

    pub fn clear(&mut self, bg: Color) {
        let default_cell = AsciiCell {
            glyph: b' ',
            fg: palette::ASH_DIM,
            bg,
            z_order: -100.0,
        };
        self.cells.fill(default_cell);
    }

    #[inline]
    pub fn put_depth(&mut self, col: i32, row: i32, z_order: f32, glyph: u8, fg: Color, bg: Color) {
        if col < 0 || row < 0 || col >= self.cols as i32 || row >= self.rows as i32 {
            return;
        }
        let idx = row as usize * self.cols + col as usize;
        if z_order >= self.cells[idx].z_order {
            let safe_glyph = if (0x20..=0x7E).contains(&glyph) {
                glyph
            } else {
                b'?'
            };
            self.cells[idx] = AsciiCell {
                glyph: safe_glyph,
                fg,
                bg,
                z_order,
            };
        }
    }

    #[inline]
    pub fn put_ui(&mut self, col: i32, row: i32, glyph: u8, fg: Color, bg: Color) {
        self.put_depth(col, row, 1000.0, glyph, fg, bg);
    }

    pub fn draw_text_ui(&mut self, col: i32, row: i32, text: &str, fg: Color, bg: Color) {
        for (i, byte) in text.bytes().enumerate() {
            self.put_ui(col + i as i32, row, byte, fg, bg);
        }
    }

    /// Zero-allocation ASCII progress bar renderer (`PREFIX[####....]`).
    pub fn draw_bar_ui(
        &mut self,
        col: i32,
        row: i32,
        prefix: &str,
        filled: usize,
        total: usize,
        fill_glyph: u8,
        fg: Color,
        bg: Color,
    ) {
        let mut x = col;
        for b in prefix.bytes() {
            self.put_ui(x, row, b, fg, bg);
            x += 1;
        }
        self.put_ui(x, row, b'[', fg, bg);
        x += 1;
        for i in 0..total {
            let g = if i < filled { fill_glyph } else { b'.' };
            self.put_ui(x, row, g, fg, bg);
            x += 1;
        }
        self.put_ui(x, row, b']', fg, bg);
    }

    /// Vectorized in-place GPU instance update (zero heap allocations per frame).
    pub fn pack_gpu_instances(&mut self) -> &[AsciiCellInstance] {
        for (inst, cell) in self.gpu_instances.iter_mut().zip(self.cells.iter()) {
            inst.glyph_index = (cell.glyph.saturating_sub(0x20)).min(94) as f32;
            inst.z_depth = cell.z_order;
            inst.fg = [cell.fg.r, cell.fg.g, cell.fg.b, cell.fg.a];
            inst.bg = [cell.bg.r, cell.bg.g, cell.bg.b, cell.bg.a];
        }
        &self.gpu_instances
    }
}

// ============================================================================
// 9. COMPLETE MMORPG GAME ENGINE STATE & 3D RENDER PIPELINE
// ============================================================================

pub struct AshveilGame {
    pub world: OpenWorld,
    pub player: Player,
    pub net: MmoNetClient,
    pub incoming_pkt_buf: Vec<MmoPacket>,
    pub remote_players: Vec<RemotePlayer>,
    pub camera_pos: Vec2,
    pub enemies: Vec<Enemy>,
    pub next_enemy_id: u64,
    pub loot_drops: Vec<WorldLootDrop>,
    pub slashes: Vec<SlashArc>,
    pub particles: Vec<AshParticle>,
    pub touch: TouchController,
    pub menu: MenuState,
    pub menu_cursor: usize,
    pub time_sec: f32,
    pub banner_text: &'static str,
    pub banner_sub: &'static str,
    pub banner_timer: f32,
    pub current_biome: Biome,
    pub status_toast: Option<(String, f32)>,
    pub mmo_feed: String,
    pub nearby_interactable: bool,
    pub zoom_scale: f32,
    pub drop_counter: i32,
}

impl AshveilGame {
    pub fn new(seed: u64) -> Self {
        let world = OpenWorld::new(seed);
        let mut player = Player::new();
        let starter_blade = LootItem {
            id: 1,
            name: String::from("[C] Ashen Broadsword of Veyr"),
            slot: EquipSlot::Weapon,
            rarity: Rarity::Common,
            item_level: 1,
            atk_bonus: 5,
            def_bonus: 1,
            hp_bonus: 10,
            crit_pct: 3,
            spell_bonus: 0,
        };
        player.equipped[EquipSlot::Weapon as usize] = Some(starter_blade);
        player.recalculate_stats(true);

        let net = MmoNetClient::new((seed as u32) ^ 0x7F3A_91C4);
        let remote_players = vec![
            RemotePlayer {
                peer_id: 101,
                name: "Veyr_Paladin",
                class: MmoClass::AshenKnight,
                level: 4,
                pos: Vec2::new(-4.0, 3.0),
                vel: Vec2::ZERO,
                hp: 260,
                max_hp: 260,
                in_party: true,
                attack_anim: 0.0,
                chat_bubble: Some(("Rally at the Nave! Raid boss soon.", 5.0)),
            },
            RemotePlayer {
                peer_id: 102,
                name: "Nyx_Hexblade",
                class: MmoClass::AbyssalHexblade,
                level: 6,
                pos: Vec2::new(5.0, -4.0),
                vel: Vec2::ZERO,
                hp: 290,
                max_hp: 290,
                in_party: true,
                attack_anim: 0.0,
                chat_bubble: None,
            },
            RemotePlayer {
                peer_id: 103,
                name: "Kael_Pyro",
                class: MmoClass::CinderPyromancer,
                level: 5,
                pos: Vec2::new(11.0, 9.0),
                vel: Vec2::ZERO,
                hp: 230,
                max_hp: 230,
                in_party: false,
                attack_anim: 0.0,
                chat_bubble: None,
            },
            RemotePlayer {
                peer_id: 104,
                name: "Mire_Cleric",
                class: MmoClass::SanctumCleric,
                level: 7,
                pos: Vec2::new(-3.0, -5.0),
                vel: Vec2::ZERO,
                hp: 340,
                max_hp: 340,
                in_party: true,
                attack_anim: 0.0,
                chat_bubble: None,
            },
        ];

        let mut game = Self {
            world,
            camera_pos: player.pos,
            player,
            net,
            incoming_pkt_buf: Vec::with_capacity(16),
            remote_players,
            enemies: Vec::with_capacity(64),
            next_enemy_id: 1,
            loot_drops: Vec::with_capacity(32),
            slashes: Vec::with_capacity(16),
            particles: Vec::with_capacity(160),
            touch: TouchController::default(),
            menu: MenuState::Hidden,
            menu_cursor: 0,
            time_sec: 0.0,
            banner_text: Biome::SunkenCathedral.name(),
            banner_sub: Biome::SunkenCathedral.subtitle(),
            banner_timer: 4.5,
            current_biome: Biome::SunkenCathedral,
            status_toast: Some((
                String::from("SHARD VEYR-01 CONNECTED | PARTY (3/4) ACTIVE"),
                5.5,
            )),
            mmo_feed: String::from("[SHARD] Welcome to ASHVEIL ONLINE (Shard Veyr-01)"),
            nearby_interactable: false,
            zoom_scale: 1.0,
            drop_counter: 1,
        };
        game.spawn_ambient_particles();
        for _ in 0..14 {
            game.maintain_enemy_population();
        }
        game
    }

    fn spawn_ambient_particles(&mut self) {
        for i in 0..110 {
            let angle = (i as f32) * 0.73;
            let dist = ((i * 17) % 36) as f32;
            let is_ember = i % 7 == 0;
            self.particles.push(AshParticle {
                pos: Vec3::new(
                    self.player.pos.x + angle.cos() * dist,
                    self.player.pos.y + angle.sin() * dist,
                    1.0 + ((i % 6) as f32),
                ),
                vel: Vec3::new(0.45, -0.25, if is_ember { 0.5 } else { -0.22 }),
                glyph: if is_ember { b'*' } else { b'.' },
                color: if is_ember {
                    palette::EMBER_CORE
                } else {
                    palette::ASH_DIM
                },
                life: ((i % 10) as f32) * 0.5 + 1.0,
            });
        }
    }

    fn maintain_enemy_population(&mut self) {
        let p = self.player.pos;
        self.enemies.retain(|e| e.hp > 0 && e.pos.dist_sq(p) < 3844.0);

        if self.enemies.len() >= 24 {
            return;
        }

        let seed_step = (self.time_sec * 10.0) as i32 + self.next_enemy_id as i32 * 31;
        let angle = self.world.noise.hash_f32(seed_step, 19) * TAU;
        let radius = 12.0 + self.world.noise.hash_f32(seed_step, 73) * 24.0;
        let sx = (p.x + angle.cos() * radius).round() as i32;
        let sy = (p.y + angle.sin() * radius).round() as i32;

        if sx * sx + sy * sy < 49 {
            return;
        }

        let col = self.world.column_at(sx, sy);
        if !col.is_walkable() {
            return;
        }

        let has_raid_boss = self.enemies.iter().any(|e| e.is_raid_boss);
        let is_raid_roll = !has_raid_boss && (self.next_enemy_id % 15 == 0);

        let kind = if is_raid_roll {
            EnemyKind::AshenSovereignRaidBoss
        } else {
            match col.biome {
                Biome::AshenMire => EnemyKind::BogWraith,
                Biome::SunkenCathedral => EnemyKind::HollowStalker,
                Biome::WitheredWeald => EnemyKind::SanctumKnight,
                Biome::ObsidianCrags => EnemyKind::ObsidianGolem,
                Biome::ForsakenCitadel => EnemyKind::AbyssalWarden,
                Biome::CinderAbyss => EnemyKind::AbyssalWarden,
            }
        };

        let dist_from_origin = (((sx * sx + sy * sy) as f32).sqrt() / 18.0) as i32;
        let enemy_lvl = if is_raid_roll {
            (self.player.level + 3).max(10)
        } else {
            (col.biome.base_enemy_level() + dist_from_origin).clamp(1, 30)
        };

        let id = self.next_enemy_id;
        self.next_enemy_id += 1;
        self.enemies
            .push(Enemy::spawn(id, kind, enemy_lvl, Vec2::new(sx as f32, sy as f32)));
    }

    pub fn update(&mut self, dt: f32) {
        let dt = dt.clamp(0.001, 0.05);
        self.time_sec += dt;

        if self.touch.action_pointer_id.is_some() {
            self.touch.action_hold_time += dt;
        }

        if self.touch.queued_menu_toggle {
            self.touch.queued_menu_toggle = false;
            self.menu = match self.menu {
                MenuState::Hidden => MenuState::MainOverlay,
                _ => MenuState::Hidden,
            };
            self.menu_cursor = 0;
        }

        if self.banner_timer > 0.0 {
            self.banner_timer = (self.banner_timer - dt).max(0.0);
        }
        if let Some((_, ref mut t)) = self.status_toast {
            *t -= dt;
            if *t <= 0.0 {
                self.status_toast = None;
            }
        }

        // Menu Navigation & Execution
        if self.menu != MenuState::Hidden {
            if self.touch.queued_menu_delta != 0 {
                let delta = self.touch.queued_menu_delta;
                self.touch.queued_menu_delta = 0;
                self.menu_cursor = (self.menu_cursor as i32 + delta).rem_euclid(6) as usize;
            }
            if self.touch.queued_light_attack || self.touch.queued_interact {
                self.touch.queued_light_attack = false;
                self.touch.queued_interact = false;
                self.execute_menu_selection();
            }
            return;
        }
        self.touch.queued_menu_delta = 0;

        // 1. Player Cooldowns & Level-Up Visual Timer
        self.player.dodge_timer = (self.player.dodge_timer - dt).max(0.0);
        self.player.attack_cooldown = (self.player.attack_cooldown - dt).max(0.0);
        self.player.hurt_timer = (self.player.hurt_timer - dt).max(0.0);
        self.player.levelup_fx_timer = (self.player.levelup_fx_timer - dt).max(0.0);

        if self.player.dodge_timer <= 0.0 && self.player.attack_cooldown <= 0.0 {
            self.player.stamina = (self.player.stamina + 30.0 * dt).min(self.player.max_stamina);
        }

        // 2. Quick Flask Heal
        if self.touch.queued_heal {
            self.touch.queued_heal = false;
            if self.player.flasks > 0 && self.player.hp < self.player.max_hp {
                self.player.flasks -= 1;
                let heal_amt = 65 + self.player.vit * 4 + self.player.fai * 3;
                self.player.hp = (self.player.hp + heal_amt).min(self.player.max_hp);
                self.status_toast = Some((format!("ASHEN FLASK (+{} HP)", heal_amt), 2.2));
            }
        }

        // 3. Dodge Roll Input
        if let Some(dodge_dir) = self.touch.queued_dodge.take() {
            let dodge_cost = (20.0 - (self.player.dex as f32) * 0.25).max(10.0);
            if self.player.stamina >= dodge_cost && self.player.dodge_timer <= 0.0 {
                self.player.stamina -= dodge_cost;
                self.player.dodge_timer = 0.28;
                self.player.dodge_dir = if dodge_dir.length_sq() > 0.01 {
                    dodge_dir.normalized()
                } else {
                    self.player.facing
                };
                self.player.facing = self.player.dodge_dir;
            }
        }

        // 4. Movement & Collision
        let move_vec = if self.player.dodge_timer > 0.0 {
            Vec2::new(
                self.player.dodge_dir.x * 13.8,
                self.player.dodge_dir.y * 13.8,
            )
        } else {
            let input = self.touch.move_vector();
            if input.length_sq() > 0.01 {
                self.player.facing = input.normalized();
            }
            let spd = 6.2 + (self.player.dex as f32) * 0.04;
            Vec2::new(input.x * spd, input.y * spd)
        };

        self.try_move_player(move_vec.x * dt, move_vec.y * dt);

        // Smooth overhead 3D camera follow
        let target_cam = Vec2::new(
            self.player.pos.x + self.player.facing.x * 1.4,
            self.player.pos.y + self.player.facing.y * 1.4,
        );
        self.camera_pos = Vec2::new(
            self.camera_pos.x + (target_cam.x - self.camera_pos.x) * (10.0 * dt).min(1.0),
            self.camera_pos.y + (target_cam.y - self.camera_pos.y) * (10.0 * dt).min(1.0),
        );

        // 5. Zero-Allocation Auto-Pickup of Nearby Ground Loot Drops
        self.collect_nearby_loot(dt);

        // 6. Check Biome Transitions, Chunk Pruning & World Interactables
        let px = self.player.pos.x.round() as i32;
        let py = self.player.pos.y.round() as i32;
        let ((player_cx, player_cy), _) = OpenWorld::world_to_chunk(px, py);
        self.world.prune_distant_chunks(player_cx, player_cy);

        let current_col = self.world.column_at(px, py);
        self.player.z = current_col.base_z as f32;
        if current_col.biome != self.current_biome {
            self.current_biome = current_col.biome;
            self.banner_text = self.current_biome.name();
            self.banner_sub = self.current_biome.subtitle();
            self.banner_timer = 4.0;
        }

        self.nearby_interactable = false;
        let mut interact_target: Option<(i32, i32, WorldColumn)> = None;
        for dy in -1..=1 {
            for dx in -1..=1 {
                let col = self.world.column_at(px + dx, py + dy);
                if matches!(
                    col.kind,
                    TileKind::BonfireShrine | TileKind::LoreMonolith | TileKind::RelicAltar
                ) {
                    self.nearby_interactable = true;
                    interact_target = Some((px + dx, py + dy, col));
                }
            }
        }

        if self.touch.queued_interact {
            self.touch.queued_interact = false;
            if let Some((ix, iy, col)) = interact_target {
                match col.kind {
                    TileKind::BonfireShrine => {
                        self.player.hp = self.player.max_hp;
                        self.player.stamina = self.player.max_stamina;
                        self.player.flasks = self.player.max_flasks;
                        self.player.last_shrine = Vec2::new(ix as f32, (iy + 1) as f32);
                        self.world.mark_tile_activated(ix, iy);
                        if !self.world.discovered_shrines.contains(&(ix, iy)) {
                            self.world.discovered_shrines.push((ix, iy));
                        }
                        self.status_toast = Some((
                            String::from("BONFIRE KINDLED: HP & FLASKS RESTORED"),
                            3.2,
                        ));
                    }
                    TileKind::LoreMonolith => {
                        if !col.activated {
                            self.world.mark_tile_activated(ix, iy);
                            let _ = self.player.gain_xp(45);
                        }
                        self.menu = MenuState::LoreModal(col.lore_id);
                    }
                    TileKind::RelicAltar => {
                        if !col.activated {
                            self.world.mark_tile_activated(ix, iy);
                            self.drop_counter += 1;
                            let relic_item = LootItem::generate(
                                &self.world.noise,
                                self.drop_counter * 97,
                                self.player.level + 2,
                                self.player.magic_find_pct() + 120,
                            );
                            self.loot_drops.push(WorldLootDrop {
                                pos: Vec2::new(ix as f32, (iy + 1) as f32),
                                item: Some(relic_item),
                                cinder_ash: 40,
                                flask_refill: 1,
                                age: 0.0,
                            });
                            self.status_toast = Some((
                                String::from("RELIQUARY ALTAR OPENED: RELIC DROPPED!"),
                                3.5,
                            ));
                        } else {
                            self.status_toast =
                                Some((String::from("THE ALTAR IS ALREADY COLD"), 2.0));
                        }
                    }
                    _ => {}
                }
            }
        }

        // 7. Combat Attacks (Light Strike & Heavy Class Skill / Pyromancy)
        let mut did_attack = false;
        if self.touch.queued_light_attack {
            self.touch.queued_light_attack = false;
            if self.player.attack_cooldown <= 0.0 && self.player.stamina >= 14.0 {
                self.player.stamina -= 14.0;
                let cd = (0.26 - (self.player.dex as f32) * 0.003).max(0.14);
                self.player.attack_cooldown = cd;
                self.perform_player_attack(false, false);
                did_attack = true;
            }
        }
        if self.touch.queued_heavy_pyro {
            self.touch.queued_heavy_pyro = false;
            if self.player.attack_cooldown <= 0.0 && self.player.stamina >= 28.0 {
                self.player.stamina -= 28.0;
                self.player.attack_cooldown = 0.44;
                self.perform_player_attack(true, true);
                did_attack = true;
            }
        }

        let mut s_idx = 0;
        while s_idx < self.slashes.len() {
            self.slashes[s_idx].timer -= dt;
            if self.slashes[s_idx].timer <= 0.0 {
                self.slashes.swap_remove(s_idx);
            } else {
                s_idx += 1;
            }
        }

        // 8. MMORPG Network Sync & Autonomous Online Shard Players
        let out_pkt = MmoPacket {
            magic: MmoPacket::MAGIC,
            peer_id: self.net.local_peer_id,
            class_id: self.player.class as u8,
            level: self.player.level as u8,
            pos_x: self.player.pos.x,
            pos_y: self.player.pos.y,
            hp: self.player.hp,
            max_hp: self.player.max_hp,
            is_attacking: u8::from(did_attack),
        };
        self.net
            .poll_and_broadcast(dt, out_pkt, &mut self.incoming_pkt_buf);
        for pkt in &self.incoming_pkt_buf {
            if let Some(peer) = self
                .remote_players
                .iter_mut()
                .find(|rp| rp.peer_id == pkt.peer_id)
            {
                peer.pos = Vec2::new(pkt.pos_x, pkt.pos_y);
                peer.level = pkt.level as i32;
                peer.hp = pkt.hp;
                peer.max_hp = pkt.max_hp;
                if pkt.is_attacking != 0 {
                    peer.attack_anim = 0.25;
                }
            }
        }

        self.update_remote_players(dt);

        // 9. Enemy AI, Loot Spawning & Level-Up Resolution
        self.update_enemies(dt);
        self.maintain_enemy_population();

        // 10. 3D Ash & Ember Particles
        self.update_particles(dt);
    }

    /// Zero-allocation in-place loot collection using `swap_remove`.
    fn collect_nearby_loot(&mut self, dt: f32) {
        let p_pos = self.player.pos;
        let mut picked_msg: Option<String> = None;

        let mut i = 0;
        while i < self.loot_drops.len() {
            self.loot_drops[i].age += dt;
            if self.loot_drops[i].pos.dist_sq(p_pos) <= 2.40 {
                let mut drop = self.loot_drops.swap_remove(i);
                self.player.cinder_ash += drop.cinder_ash;
                self.player.flasks =
                    (self.player.flasks + drop.flask_refill).min(self.player.max_flasks);
                if let Some(item) = drop.item.take() {
                    let rarity_name = item.rarity.name();
                    let (action, name) = self.player.collect_loot_item(item);
                    self.mmo_feed = format!(
                        "[LOOT] {} picked up {} ({})",
                        self.player.name, name, rarity_name
                    );
                    picked_msg = Some(format!("{}: {}", action, name));
                } else if drop.cinder_ash > 0 {
                    picked_msg = Some(format!("+{} CINDER ASH", drop.cinder_ash));
                }
            } else if self.loot_drops[i].age >= 120.0 {
                self.loot_drops.swap_remove(i);
            } else {
                i += 1;
            }
        }

        if let Some(msg) = picked_msg {
            self.status_toast = Some((msg, 3.0));
        }
    }

    fn update_remote_players(&mut self, dt: f32) {
        let player_pos = self.player.pos;
        let mut cleric_heal = 0i32;
        let mut killed_by_party: Vec<(usize, bool)> = Vec::new();

        for rp_idx in 0..self.remote_players.len() {
            self.remote_players[rp_idx].attack_anim =
                (self.remote_players[rp_idx].attack_anim - dt).max(0.0);
            if let Some((_, ref mut timer)) = self.remote_players[rp_idx].chat_bubble {
                *timer -= dt;
                if *timer <= 0.0 {
                    self.remote_players[rp_idx].chat_bubble = None;
                }
            }

            let rp_pos = self.remote_players[rp_idx].pos;
            let rp_in_party = self.remote_players[rp_idx].in_party;
            let rp_level = self.remote_players[rp_idx].level;
            let rp_peer_id = self.remote_players[rp_idx].peer_id;
            let rp_class = self.remote_players[rp_idx].class;

            let mut nearest_enemy: Option<(usize, f32)> = None;
            for (idx, e) in self.enemies.iter().enumerate() {
                if e.hp > 0 {
                    let d_sq = rp_pos.dist_sq(e.pos);
                    if d_sq < 324.0 && (nearest_enemy.is_none() || d_sq < nearest_enemy.unwrap().1)
                    {
                        nearest_enemy = Some((idx, d_sq));
                    }
                }
            }

            if let Some((e_idx, dist_sq)) = nearest_enemy {
                let e_pos = self.enemies[e_idx].pos;
                if dist_sq > 2.89 {
                    let dir = Vec2::new(e_pos.x - rp_pos.x, e_pos.y - rp_pos.y).normalized();
                    let nx = rp_pos.x + dir.x * 3.8 * dt;
                    let ny = rp_pos.y + dir.y * 3.8 * dt;
                    if self.world.column_at(nx.round() as i32, rp_pos.y.round() as i32).is_walkable() {
                        self.remote_players[rp_idx].pos.x = nx;
                    }
                    if self.world.column_at(self.remote_players[rp_idx].pos.x.round() as i32, ny.round() as i32).is_walkable() {
                        self.remote_players[rp_idx].pos.y = ny;
                    }
                } else if self.remote_players[rp_idx].attack_anim <= 0.0 {
                    self.remote_players[rp_idx].attack_anim = 0.55;
                    let dmg = 10 + rp_level * 3;
                    self.enemies[e_idx].hp -= dmg;
                    self.enemies[e_idx].flash_timer = 0.12;
                    if self.enemies[e_idx].hp <= 0
                        && !killed_by_party.iter().any(|&(k_idx, _)| k_idx == e_idx)
                    {
                        killed_by_party.push((e_idx, rp_in_party));
                    }
                }
            } else if rp_in_party {
                let offset_angle = (rp_peer_id as f32) * 1.7 + self.time_sec * 0.35;
                let target = Vec2::new(
                    player_pos.x + offset_angle.cos() * 4.2,
                    player_pos.y + offset_angle.sin() * 4.2,
                );
                if rp_pos.dist_sq(target) > 1.44 {
                    let dir = Vec2::new(target.x - rp_pos.x, target.y - rp_pos.y).normalized();
                    let nx = rp_pos.x + dir.x * 4.1 * dt;
                    let ny = rp_pos.y + dir.y * 4.1 * dt;
                    if self.world.column_at(nx.round() as i32, rp_pos.y.round() as i32).is_walkable() {
                        self.remote_players[rp_idx].pos.x = nx;
                    }
                    if self.world.column_at(self.remote_players[rp_idx].pos.x.round() as i32, ny.round() as i32).is_walkable() {
                        self.remote_players[rp_idx].pos.y = ny;
                    }
                }
            }

            if rp_class == MmoClass::SanctumCleric
                && rp_in_party
                && rp_pos.dist_sq(player_pos) < 72.25
                && ((self.time_sec * 10.0) as i32 % 45 == 0)
            {
                cleric_heal = 2;
            }
        }

        if cleric_heal > 0 && self.player.hp < self.player.max_hp {
            self.player.hp = (self.player.hp + cleric_heal).min(self.player.max_hp);
        }

        // Sort descending by index so swap_remove never invalidates pending indices
        killed_by_party.sort_unstable_by(|a, b| b.0.cmp(&a.0));
        for (idx, was_in_party) in killed_by_party {
            let felled = self.enemies.swap_remove(idx);
            if was_in_party {
                self.spawn_enemy_loot_and_xp(&felled, true);
            }
        }
    }

    fn execute_menu_selection(&mut self) {
        match self.menu {
            MenuState::LoreModal(_) | MenuState::WorldMap => {
                self.menu = MenuState::Hidden;
            }
            MenuState::MainOverlay => match self.menu_cursor {
                0 => self.menu = MenuState::Hidden,
                1 => {
                    self.menu = MenuState::StatsAndClass;
                    self.menu_cursor = 0;
                }
                2 => {
                    self.menu = MenuState::InventoryAndLoot;
                    self.menu_cursor = 0;
                }
                3 => {
                    self.menu = MenuState::MmoShardAndParty;
                    self.menu_cursor = 0;
                }
                4 => self.menu = MenuState::WorldMap,
                _ => self.menu = MenuState::Hidden,
            },
            MenuState::StatsAndClass => {
                if self.menu_cursor < 5 {
                    if self.player.stat_points > 0 {
                        match self.menu_cursor {
                            0 => self.player.vit += 1,
                            1 => self.player.str_stat += 1,
                            2 => self.player.dex += 1,
                            3 => self.player.int_stat += 1,
                            4 => self.player.fai += 1,
                            _ => {}
                        }
                        self.player.stat_points -= 1;
                        self.player.recalculate_stats(false);
                        self.status_toast =
                            Some((String::from("ATTRIBUTE POINT ALLOCATED"), 2.0));
                    } else {
                        self.status_toast =
                            Some((String::from("NO UNSPENT STAT POINTS (LEVEL UP FIRST)"), 2.0));
                        self.menu = MenuState::Hidden;
                    }
                } else {
                    let next_cls =
                        MmoClass::ALL[((self.player.class as usize) + 1) % MmoClass::ALL.len()];
                    self.player.class = next_cls;
                    self.status_toast =
                        Some((format!("CLASS ATTUNED: {}", next_cls.name()), 2.5));
                    self.menu = MenuState::Hidden;
                }
            }
            MenuState::InventoryAndLoot => {
                if !self.player.bag.is_empty() {
                    let idx = self.menu_cursor % self.player.bag.len();
                    let item = self.player.bag.remove(idx);
                    let slot_idx = item.slot as usize;
                    let name = item.name.clone();
                    if let Some(old) = self.player.equipped[slot_idx].replace(item) {
                        self.player.bag.push(old);
                    }
                    self.player.recalculate_stats(false);
                    self.status_toast = Some((format!("EQUIPPED: {}", name), 2.5));
                }
                self.menu = MenuState::Hidden;
            }
            MenuState::MmoShardAndParty => {
                if !self.remote_players.is_empty() {
                    let idx = self.menu_cursor % self.remote_players.len();
                    self.remote_players[idx].in_party = !self.remote_players[idx].in_party;
                    let p_name = self.remote_players[idx].name;
                    let joined = self.remote_players[idx].in_party;
                    self.status_toast = Some((
                        format!(
                            "{} {}",
                            p_name,
                            if joined {
                                "JOINED YOUR PARTY"
                            } else {
                                "LEFT YOUR PARTY"
                            }
                        ),
                        2.5,
                    ));
                }
                self.menu = MenuState::Hidden;
            }
            MenuState::Hidden => {}
        }
    }

    fn try_move_player(&mut self, dx: f32, dy: f32) {
        let nx = self.player.pos.x + dx;
        let ny = self.player.pos.y + dy;

        if self
            .world
            .column_at(nx.round() as i32, self.player.pos.y.round() as i32)
            .is_walkable()
        {
            self.player.pos.x = nx;
        }
        if self
            .world
            .column_at(self.player.pos.x.round() as i32, ny.round() as i32)
            .is_walkable()
        {
            self.player.pos.y = ny;
        }
    }

    pub fn perform_player_attack(&mut self, is_heavy: bool, is_pyro: bool) {
        let dir = if self.player.facing.length_sq() > 0.01 {
            self.player.facing.normalized()
        } else {
            Vec2::new(0.0, -1.0)
        };
        let radius = if is_pyro {
            4.5
        } else if is_heavy {
            3.3
        } else {
            2.4
        };

        let atk = self.player.total_attack_power();
        let spell = self.player.total_spell_power();
        let crit_roll = (self
            .world
            .noise
            .hash2i((self.time_sec * 100.0) as i32, self.player.kills as i32)
            % 100) as i32;
        let is_crit = crit_roll < self.player.total_crit_pct();

        let mut dmg = if is_pyro {
            spell + atk / 2
        } else if is_heavy {
            (atk * 3) / 2
        } else {
            atk
        };
        if is_crit {
            dmg = (dmg * 3) / 2;
        }

        if is_pyro && self.player.class == MmoClass::SanctumCleric {
            let heal = 20 + self.player.fai * 2;
            self.player.hp = (self.player.hp + heal).min(self.player.max_hp);
        }

        self.slashes.push(SlashArc {
            origin: self.player.pos,
            dir,
            radius,
            timer: 0.20,
            max_timer: 0.20,
            is_heavy,
            is_pyro,
        });

        let mut killed_indices = Vec::new();
        for idx in 0..self.enemies.len() {
            let e_pos = self.enemies[idx].pos;
            let to_enemy = Vec2::new(
                e_pos.x - self.player.pos.x,
                e_pos.y - self.player.pos.y,
            );
            let dist = to_enemy.length();
            if dist <= radius + 0.65 {
                let n = to_enemy.normalized();
                let dot = n.x * dir.x + n.y * dir.y;
                if is_pyro || dot > 0.12 || dist < 1.35 {
                    self.enemies[idx].hp -= dmg;
                    self.enemies[idx].stagger_timer = 0.32;
                    self.enemies[idx].flash_timer = 0.18;

                    // Safe knockback that checks walkable terrain before pushing
                    let kx = e_pos.x + dir.x * 0.85;
                    let ky = e_pos.y + dir.y * 0.85;
                    if self
                        .world
                        .column_at(kx.round() as i32, ky.round() as i32)
                        .is_walkable()
                    {
                        self.enemies[idx].pos.x = kx;
                        self.enemies[idx].pos.y = ky;
                    }

                    if self.enemies[idx].hp <= 0 {
                        killed_indices.push(idx);
                    }
                }
            }
        }

        killed_indices.sort_unstable_by(|a, b| b.cmp(a));
        for idx in killed_indices {
            let felled = self.enemies.swap_remove(idx);
            self.spawn_enemy_loot_and_xp(&felled, false);
        }
    }

    fn spawn_enemy_loot_and_xp(&mut self, felled: &Enemy, party_assist: bool) {
        self.player.kills += 1;
        let xp_gain = if party_assist {
            (felled.xp_reward() * 3) / 4
        } else {
            felled.xp_reward()
        };
        let leveled = self.player.gain_xp(xp_gain);

        self.drop_counter += 1;
        let drop_roll = self
            .world
            .noise
            .hash_f32(self.drop_counter * 17, felled.level * 29);
        let guaranteed_gear = felled.is_raid_boss || drop_roll > 0.25;

        let item = if guaranteed_gear {
            let mf = self.player.magic_find_pct() + if felled.is_raid_boss { 180 } else { 0 };
            Some(LootItem::generate(
                &self.world.noise,
                self.drop_counter + felled.id as i32,
                felled.level,
                mf,
            ))
        } else {
            None
        };

        let ash_drop = (felled.level as u32) * 12 + if felled.is_raid_boss { 180 } else { 10 };
        self.loot_drops.push(WorldLootDrop {
            pos: felled.pos,
            item,
            cinder_ash: ash_drop,
            flask_refill: u8::from(felled.is_raid_boss),
            age: 0.0,
        });

        if leveled {
            self.banner_text = "ASCENSION: LEVEL UP!";
            self.banner_sub = "Vitals restored and +3 Attribute Points granted ([=] Menu)";
            self.banner_timer = 3.8;
            self.mmo_feed = format!(
                "[SHARD] {} ascended to Level {}!",
                self.player.name, self.player.level
            );
        } else {
            self.status_toast = Some((
                format!(
                    "SLAIN LV.{} {} (+{} XP | LOOT DROPPED)",
                    felled.level,
                    felled.kind.name(),
                    xp_gain
                ),
                2.6,
            ));
        }
    }

    fn update_enemies(&mut self, dt: f32) {
        let p_pos = self.player.pos;
        let mut raw_damage = 0;

        for idx in 0..self.enemies.len() {
            self.enemies[idx].flash_timer = (self.enemies[idx].flash_timer - dt).max(0.0);
            if self.enemies[idx].stagger_timer > 0.0 {
                self.enemies[idx].stagger_timer -= dt;
                continue;
            }
            self.enemies[idx].attack_cooldown =
                (self.enemies[idx].attack_cooldown - dt).max(0.0);

            let e_pos = self.enemies[idx].pos;
            let delta = Vec2::new(p_pos.x - e_pos.x, p_pos.y - e_pos.y);
            let dist_sq = delta.length_sq();

            if self.enemies[idx].windup_timer > 0.0 {
                self.enemies[idx].windup_timer -= dt;
                if self.enemies[idx].windup_timer <= 0.0 {
                    if dist_sq < 4.62 {
                        raw_damage += self.enemies[idx].damage();
                    }
                    self.enemies[idx].attack_cooldown = 1.15;
                }
                continue;
            }

            if dist_sq < 2.89 && self.enemies[idx].attack_cooldown <= 0.0 {
                self.enemies[idx].windup_timer = 0.42;
            } else if dist_sq < 400.0 && dist_sq > 1.21 {
                let dir = delta.normalized();
                let step = self.enemies[idx].kind.speed() * dt;
                let nx = e_pos.x + dir.x * step;
                let ny = e_pos.y + dir.y * step;
                if self
                    .world
                    .column_at(nx.round() as i32, e_pos.y.round() as i32)
                    .is_walkable()
                {
                    self.enemies[idx].pos.x = nx;
                }
                if self
                    .world
                    .column_at(self.enemies[idx].pos.x.round() as i32, ny.round() as i32)
                    .is_walkable()
                {
                    self.enemies[idx].pos.y = ny;
                }
            }
        }

        if raw_damage > 0 && !self.player.is_invulnerable() {
            let mitigated = (raw_damage - self.player.total_defense()).max(4);
            self.player.hp -= mitigated;
            self.player.hurt_timer = 0.45;
            if self.player.hp <= 0 {
                self.player.hp = self.player.max_hp;
                self.player.stamina = self.player.max_stamina;
                self.player.flasks = self.player.max_flasks;
                self.player.pos = self.player.last_shrine;
                self.camera_pos = self.player.pos;
                self.player.cinder_ash /= 2;
                self.banner_text = "RETURNED TO THE BONFIRE";
                self.banner_sub = "Your soul re-anchored at the Sanctuary Shrine";
                self.banner_timer = 4.2;
            }
        }
    }

    fn update_particles(&mut self, dt: f32) {
        let p = self.player.pos;
        for part in &mut self.particles {
            part.pos.x += part.vel.x * dt;
            part.pos.y += part.vel.y * dt;
            part.pos.z += part.vel.z * dt;
            part.life -= dt;

            if part.pos.z < 0.5 || part.pos.z > 7.5 || part.life <= 0.0 {
                part.pos.x = p.x + ((part.pos.y * 19.3).sin() * 28.0);
                part.pos.y = p.y + ((part.pos.x * 13.7).cos() * 18.0);
                part.pos.z = if part.glyph == b'*' { 1.0 } else { 6.5 };
                part.life = 4.5;
            }
        }
    }

    #[inline]
    fn compute_visibility_and_light(&self, wx: i32, wy: i32, col_z: f32) -> (bool, f32) {
        let px = self.player.pos.x.round() as i32;
        let py = self.player.pos.y.round() as i32;
        let dx = (wx - px) as f32;
        let dy = (wy - py) as f32;
        let dist_sq = dx * dx + dy * dy;

        if dist_sq > 1156.0 {
            return (false, 0.0);
        }
        let dist = dist_sq.sqrt();
        let torch_radius = 19.5;

        let mut x0 = px;
        let mut y0 = py;
        let x1 = wx;
        let y1 = wy;
        let sx = if x0 < x1 { 1 } else { -1 };
        let sy = if y0 < y1 { 1 } else { -1 };
        let adx = (x1 - x0).abs();
        let ady = -(y1 - y0).abs();
        let mut err = adx + ady;
        let mut occluded = false;

        while x0 != x1 || y0 != y1 {
            if (x0 != px || y0 != py) && (x0 != x1 || y0 != y1) {
                if let Some(cell) = self.world.column_at_ref(x0, y0) {
                    if cell.blocks_sight() && cell.total_z() > col_z + 1.0 {
                        occluded = true;
                        break;
                    }
                }
            }
            let e2 = 2 * err;
            if e2 >= ady {
                err += ady;
                x0 += sx;
            }
            if e2 <= adx {
                err += adx;
                y0 += sy;
            }
        }

        let torch_falloff = (1.0 - (dist / torch_radius)).clamp(0.0, 1.0);
        let flicker = 0.94 + 0.06 * (self.time_sec * 11.0 + (wx + wy) as f32 * 0.5).sin();
        let light = if occluded {
            (torch_falloff * 0.22).max(0.12)
        } else {
            (torch_falloff * torch_falloff * flicker + 0.16).clamp(0.16, 1.25)
        };
        (!occluded, light)
    }

    #[inline]
    pub fn project_3d_to_screen(
        &self,
        wx: f32,
        wy: f32,
        wz: f32,
        screen_cols: usize,
        screen_rows: usize,
    ) -> (i32, i32) {
        let half_w = screen_cols as f32 * 0.5;
        let half_h = screen_rows as f32 * 0.5;

        let rel_x = (wx - self.camera_pos.x) * self.zoom_scale;
        let rel_y = (wy - self.camera_pos.y) * self.zoom_scale;

        let z_delta = (wz - 1.0).max(0.0);
        let persp = 1.0 + z_delta * PERSPECTIVE_XY_SCALE;
        let sx = half_w + rel_x * persp;
        let sy = half_h + rel_y * persp - z_delta * PERSPECTIVE_Y_TILT;

        (sx.round() as i32, sy.round() as i32)
    }

    pub fn render_ascii_frame(&mut self, buf: &mut AsciiScreenBuffer) {
        buf.clear(palette::VOID_BG);

        let cols = buf.cols;
        let rows = buf.rows;
        let half_w = (cols as i32) / 2 + 6;
        let half_h = (rows as i32) / 2 + 6;
        let cam_xi = self.camera_pos.x.round() as i32;
        let cam_yi = self.camera_pos.y.round() as i32;

        // Fast chunk-range pre-warming (9-16 checks instead of 6,500 per-tile checks)
        let ((min_cx, min_cy), _) = OpenWorld::world_to_chunk(cam_xi - half_w, cam_yi - half_h);
        let ((max_cx, max_cy), _) = OpenWorld::world_to_chunk(cam_xi + half_w, cam_yi + half_h);
        for cy in min_cy..=max_cy {
            for cx in min_cx..=max_cx {
                self.world.ensure_chunk(cx, cy);
            }
        }

        // PASS 1: 3D Ground & Multi-Layer Extruded World Columns
        for wy in (cam_yi - half_h)..=(cam_yi + half_h) {
            for wx in (cam_xi - half_w)..=(cam_xi + half_w) {
                let col = match self.world.column_at_ref(wx, wy) {
                    Some(&c) => c,
                    None => continue,
                };
                let (visible, mut light) =
                    self.compute_visibility_and_light(wx, wy, col.base_z as f32);

                if col.light_emission > 0.0 {
                    light = (light + col.light_emission).min(1.45);
                }

                let (gx, gy) = self.project_3d_to_screen(
                    wx as f32,
                    wy as f32,
                    col.base_z as f32,
                    cols,
                    rows,
                );
                let mut floor_glyph = col.floor_glyph;
                if col.kind == TileKind::MireWater || col.kind == TileKind::EmberFissure {
                    let wave = ((self.time_sec * 3.5 + (wx * 3 + wy * 5) as f32).sin() > 0.2)
                        as usize;
                    floor_glyph = [b'~', b'-'][wave];
                }
                let floor_fg = if visible {
                    col.base_color.scale(light)
                } else {
                    col.base_color.scale(0.18)
                };
                let floor_bg = if col.kind == TileKind::EmberFissure {
                    palette::EMBER_GLOW.scale(0.18 * light)
                } else if !visible {
                    palette::VOID_BG
                } else {
                    palette::SHADOW_DEEP.scale(light * 0.5)
                };

                buf.put_depth(gx, gy, col.base_z as f32, floor_glyph, floor_fg, floor_bg);

                if col.height > 0 {
                    let rel_x = wx as f32 - self.camera_pos.x;
                    let rel_y = wy as f32 - self.camera_pos.y;

                    let side_glyph = if col.kind == TileKind::WitheredTree {
                        if rel_x.abs() > rel_y.abs() {
                            if rel_x > 0.0 {
                                b'/'
                            } else {
                                b'\\'
                            }
                        } else {
                            b'|'
                        }
                    } else if rel_x.abs() > rel_y.abs() * 1.3 {
                        b'|'
                    } else if rel_y.abs() > rel_x.abs() * 1.3 {
                        b'='
                    } else if (rel_x * rel_y) > 0.0 {
                        b'\\'
                    } else {
                        b'/'
                    };

                    for layer in 1..=col.height {
                        let wz = (col.base_z + layer) as f32;
                        let (sx, sy) =
                            self.project_3d_to_screen(wx as f32, wy as f32, wz, cols, rows);
                        let is_roof = layer == col.height;

                        let layer_shade =
                            (light * (0.65 + 0.08 * layer as f32)).clamp(0.15, 1.45);
                        let glyph = if is_roof { col.roof_glyph } else { side_glyph };
                        let fg = if is_roof {
                            col.roof_color.scale(layer_shade)
                        } else {
                            col.base_color.scale(layer_shade * 0.85)
                        };
                        let bg = palette::SHADOW_DEEP.scale(layer_shade * 0.45);

                        buf.put_depth(sx, sy, wz + 0.1, glyph, fg, bg);

                        if is_roof && col.kind == TileKind::WitheredTree && visible {
                            for (ox, oy, c_glyph) in [
                                (-1, 0, b'('),
                                (1, 0, b')'),
                                (0, -1, b'^'),
                                (0, 1, b'*'),
                            ] {
                                buf.put_depth(
                                    sx + ox,
                                    sy + oy,
                                    wz - 0.05,
                                    c_glyph,
                                    col.roof_color.scale(layer_shade * 0.9),
                                    palette::VOID_BG,
                                );
                            }
                        }
                    }
                }
            }
        }

        // PASS 2: 3D Ground Loot Drops & Vertical Rarity Light Pillars
        for drop in &self.loot_drops {
            let (glyph, color, beam_h) = match drop.item {
                Some(ref item) => (
                    item.slot.ground_glyph(),
                    item.rarity.color(),
                    item.rarity.beam_height(),
                ),
                None => (b'$', palette::GOLD_RELIC, 1),
            };
            let (lx, ly) = self.project_3d_to_screen(drop.pos.x, drop.pos.y, 1.4, cols, rows);
            buf.put_depth(lx, ly, 2.4, glyph, color, palette::SHADOW_DEEP);

            for layer in 1..=beam_h {
                let bz = 1.4 + layer as f32 * 0.85;
                let (bx, by) = self.project_3d_to_screen(drop.pos.x, drop.pos.y, bz, cols, rows);
                let b_glyph = if layer == beam_h { b'*' } else { b'|' };
                buf.put_depth(bx, by, bz + 1.0, b_glyph, color, palette::VOID_BG);
            }
        }

        // PASS 3: Dynamic Blade Slash Arcs & Pyromancy Waves
        for slash in &self.slashes {
            let steps = 9;
            let perp = Vec2::new(-slash.dir.y, slash.dir.x);
            for i in -steps..=steps {
                let t = (i as f32) / (steps as f32);
                let arc_pos = Vec2::new(
                    slash.origin.x + slash.dir.x * (slash.radius * 0.75) + perp.x * t * 1.8,
                    slash.origin.y + slash.dir.y * (slash.radius * 0.75) + perp.y * t * 1.8,
                );
                let (sx, sy) = self.project_3d_to_screen(arc_pos.x, arc_pos.y, 2.5, cols, rows);
                let glyph = if slash.is_pyro {
                    b'*'
                } else if t.abs() < 0.35 {
                    b'/'
                } else {
                    b'~'
                };
                let color = if slash.is_pyro {
                    palette::EMBER_CORE
                } else {
                    palette::BONE_WHITE
                };
                buf.put_depth(sx, sy, 4.2, glyph, color, palette::VOID_BG);
            }
        }

        // PASS 4: 3D Extruded Online Shard Players (`@` + Class Crown + Nameplate)
        for rp in &self.remote_players {
            let (bx, by) = self.project_3d_to_screen(rp.pos.x, rp.pos.y, 1.5, cols, rows);
            let p_col = if rp.in_party {
                palette::RUNE_CYAN
            } else {
                palette::GOLD_RELIC
            };
            buf.put_depth(bx, by, 3.0, b'@', p_col, palette::SHADOW_DEEP);

            let (tx, ty) = self.project_3d_to_screen(rp.pos.x, rp.pos.y, 3.3, cols, rows);
            let crown = if rp.attack_anim > 0.0 {
                b'/'
            } else {
                rp.class.crown_glyph()
            };
            buf.put_depth(tx, ty, 4.9, crown, palette::BONE_WHITE, palette::VOID_BG);

            let tag = format!("L{}{}", rp.level, rp.class.short_tag());
            let tag_x = tx - (tag.len() as i32 / 2);
            for (i, ch) in tag.bytes().enumerate() {
                buf.put_depth(
                    tag_x + i as i32,
                    ty - 1,
                    6.0,
                    ch,
                    p_col.scale(0.85),
                    palette::VOID_BG,
                );
            }
        }

        // PASS 5: 3D Extruded Enemies & Raid Bosses
        for enemy in &self.enemies {
            let ex = enemy.pos.x.round() as i32;
            let ey = enemy.pos.y.round() as i32;
            let (visible, light) = self.compute_visibility_and_light(ex, ey, 2.0);
            if !visible && enemy.pos.dist_sq(self.player.pos) > 100.0 && !enemy.is_raid_boss {
                continue;
            }

            let base_col = if enemy.flash_timer > 0.0 {
                palette::CRIMSON_BLOOD
            } else {
                enemy.kind.color().scale(light.max(0.55))
            };

            let (bx, by) = self.project_3d_to_screen(enemy.pos.x, enemy.pos.y, 1.5, cols, rows);
            buf.put_depth(
                bx,
                by,
                2.5,
                enemy.kind.glyph(),
                base_col,
                palette::SHADOW_DEEP,
            );

            let top_z = 1.5 + enemy.kind.height() as f32 * 0.65;
            let (tx, ty) =
                self.project_3d_to_screen(enemy.pos.x, enemy.pos.y, top_z, cols, rows);
            let crown_glyph = if enemy.windup_timer > 0.0 {
                b'!'
            } else {
                enemy.kind.crown_glyph()
            };
            let crown_col = if enemy.windup_timer > 0.0 {
                palette::CRIMSON_BLOOD
            } else {
                palette::BONE_WHITE.scale(light.max(0.65))
            };
            buf.put_depth(tx, ty, top_z + 1.5, crown_glyph, crown_col, palette::VOID_BG);
        }

        // PASS 6: 3D Extruded Local Player & Level-Up Golden Pillar
        let p_color = if self.player.hurt_timer > 0.0 {
            palette::CRIMSON_BLOOD
        } else if self.player.dodge_timer > 0.0 {
            palette::RUNE_CYAN
        } else {
            palette::BONE_WHITE
        };
        let (px0, py0) = self.project_3d_to_screen(
            self.player.pos.x,
            self.player.pos.y,
            self.player.z + 0.5,
            cols,
            rows,
        );
        buf.put_depth(px0, py0, 3.4, b'@', p_color, palette::SHADOW_DEEP);

        let (px1, py1) = self.project_3d_to_screen(
            self.player.pos.x,
            self.player.pos.y,
            self.player.z + 2.4,
            cols,
            rows,
        );
        let head_glyph = if self.player.dodge_timer > 0.0 {
            b'~'
        } else {
            self.player.class.crown_glyph()
        };
        buf.put_depth(px1, py1, 5.4, head_glyph, palette::EMBER_CORE, palette::VOID_BG);

        if self.player.levelup_fx_timer > 0.0 {
            for z_step in 1..=6 {
                let lz = self.player.z + z_step as f32;
                let (lx, ly) = self.project_3d_to_screen(
                    self.player.pos.x,
                    self.player.pos.y,
                    lz,
                    cols,
                    rows,
                );
                buf.put_depth(lx - 1, ly, 7.0, b'|', palette::GOLD_RELIC, palette::VOID_BG);
                buf.put_depth(lx + 1, ly, 7.0, b'|', palette::GOLD_RELIC, palette::VOID_BG);
                buf.put_depth(lx, ly - 1, 7.0, b'*', palette::EMBER_CORE, palette::VOID_BG);
            }
        }

        // PASS 7: Multi-Altitude 3D Ash & Ember Particles
        for part in &self.particles {
            let (sx, sy) =
                self.project_3d_to_screen(part.pos.x, part.pos.y, part.pos.z, cols, rows);
            buf.put_depth(sx, sy, part.pos.z + 1.0, part.glyph, part.color, palette::VOID_BG);
        }

        // PASS 8: Minimalist MMORPG HUD, Raid Bar, Level/XP Strip & Menus
        self.render_minimalist_ui(buf);
    }

    fn render_minimalist_ui(&self, buf: &mut AsciiScreenBuffer) {
        let cols = buf.cols as i32;
        let rows = buf.rows as i32;

        // 1. Zero-Allocation Top-Left Status Bars (HP & XP)
        let hp_bars = ((self.player.hp.max(0) * 8) / self.player.max_hp.max(1)) as usize;
        let xp_bars = ((self.player.xp * 6) / self.player.xp_to_next.max(1)) as usize;

        buf.draw_bar_ui(2, 1, "HP", hp_bars, 8, b'#', palette::CRIMSON_BLOOD, palette::VOID_BG);
        let lv_prefix = format!("LV.{}", self.player.level);
        buf.draw_bar_ui(14, 1, &lv_prefix, xp_bars, 6, b'=', palette::RUNE_CYAN, palette::VOID_BG);

        let meta_str = format!(
            "{} [+{}] ASH:{} BAG:{}/16{}",
            self.player.class.short_tag(),
            self.player.flasks,
            self.player.cinder_ash,
            self.player.bag.len(),
            if self.player.stat_points > 0 {
                " *+STAT*"
            } else {
                ""
            }
        );
        buf.draw_text_ui(28, 1, &meta_str, palette::GOLD_RELIC, palette::VOID_BG);

        // 2. Top-Right Shard Indicator & Menu Button `[=]`
        let party_cnt = 1 + self.remote_players.iter().filter(|p| p.in_party).count();
        let shard_str = format!("VEYR-01 P:{}/4 [=]", party_cnt);
        buf.draw_text_ui(
            cols - shard_str.len() as i32 - 2,
            1,
            &shard_str,
            palette::ASH_LIGHT,
            palette::VOID_BG,
        );

        // 3. Active World Raid Boss Bar
        if let Some(boss) = self
            .enemies
            .iter()
            .find(|e| e.is_raid_boss && e.pos.dist_sq(self.player.pos) < 900.0)
        {
            let b_bars = ((boss.hp.max(0) * 20) / boss.max_hp.max(1)) as usize;
            let prefix = format!("{} LV.{} ", boss.kind.name(), boss.level);
            let total_w = prefix.len() as i32 + 22;
            let bx = ((cols - total_w) / 2).max(1);
            buf.draw_bar_ui(
                bx,
                2,
                &prefix,
                b_bars,
                20,
                b'#',
                palette::CRIMSON_BLOOD,
                palette::VOID_BG,
            );
        }

        // 4. Biome Discovery / Level-Up Banner
        if self.banner_timer > 0.0 {
            let title = format!("-- {} --", self.banner_text);
            let tx = (cols - title.len() as i32) / 2;
            buf.draw_text_ui(tx.max(1), 4, &title, palette::BONE_WHITE, palette::VOID_BG);

            let sx = (cols - self.banner_sub.len() as i32) / 2;
            buf.draw_text_ui(
                sx.max(1),
                5,
                self.banner_sub,
                palette::ASH_DIM,
                palette::VOID_BG,
            );
        }

        // 5. Bottom-Left 1-Line Minimalist MMORPG Realm Feed
        buf.draw_text_ui(
            2,
            rows - 2,
            &self.mmo_feed,
            palette::ASH_DIM,
            palette::VOID_BG,
        );

        // 6. Contextual Bottom-Right Interaction Prompt `[E]`
        if self.nearby_interactable {
            let prompt = "[E] COMMUNE";
            buf.draw_text_ui(
                cols - prompt.len() as i32 - 2,
                rows - 2,
                prompt,
                palette::EMBER_CORE,
                palette::VOID_BG,
            );
        } else {
            let hint = "[TAP:STRIKE SWIPE:DODGE HOLD:SKILL]";
            buf.draw_text_ui(
                cols - hint.len() as i32 - 2,
                rows - 2,
                hint,
                palette::ASH_DIM.scale(0.75),
                palette::VOID_BG,
            );
        }

        // 7. Floating Left Thumbstick (only drawn while touched)
        if self.touch.move_pointer_id.is_some() {
            let ox = (self.touch.move_origin.x * cols as f32).round() as i32;
            let oy = (self.touch.move_origin.y * rows as f32).round() as i32;
            let cx = (self.touch.move_current.x * cols as f32).round() as i32;
            let cy = (self.touch.move_current.y * rows as f32).round() as i32;
            buf.draw_text_ui(ox - 1, oy, "(+)", palette::ASH_DIM, palette::VOID_BG);
            buf.put_ui(cx, cy, b'o', palette::EMBER_CORE, palette::VOID_BG);
        }

        // 8. Toast Notification
        if let Some((ref msg, _)) = self.status_toast {
            let mx = (cols - msg.len() as i32) / 2;
            buf.draw_text_ui(
                mx.max(1),
                rows - 4,
                msg,
                palette::GOLD_RELIC,
                palette::VOID_BG,
            );
        }

        // 9. Minimalist Diegetic Overlay Menus
        match self.menu {
            MenuState::Hidden => {}
            MenuState::MainOverlay => {
                let box_w = 46;
                let box_h = 15;
                let x0 = (cols - box_w) / 2;
                let y0 = (rows - box_h) / 2;
                self.draw_ascii_box(buf, x0, y0, box_w, box_h, "ASHVEIL MMORPG SANCTUARY");

                let items = [
                    "RESUME PILGRIMAGE",
                    "CHARACTER STATS, LEVELING & CLASS",
                    "EQUIPMENT & LOOT BAG (16 SLOTS)",
                    "MMORPG SHARD PEERS & PARTY ROSTER",
                    "ATLAS OF THE SIX REALMS",
                    "CLOSE OVERLAY",
                ];
                for (i, label) in items.iter().enumerate() {
                    let prefix = if i == self.menu_cursor { "> " } else { "  " };
                    let line = format!("{}{}", prefix, label);
                    let fg = if i == self.menu_cursor {
                        palette::EMBER_CORE
                    } else {
                        palette::ASH_LIGHT
                    };
                    buf.draw_text_ui(x0 + 3, y0 + 2 + i as i32 * 2, &line, fg, palette::VOID_BG);
                }
            }
            MenuState::StatsAndClass => {
                let box_w = 54.min(cols - 4);
                let box_h = 18;
                let x0 = (cols - box_w) / 2;
                let y0 = (rows - box_h) / 2;
                self.draw_ascii_box(buf, x0, y0, box_w, box_h, "LEVELING & ATTRIBUTES");

                let hdr = format!(
                    "{} ({})  LV.{}  XP:{}/{}  STAT PTS:{}",
                    self.player.name,
                    self.player.class.name(),
                    self.player.level,
                    self.player.xp,
                    self.player.xp_to_next,
                    self.player.stat_points
                );
                buf.draw_text_ui(x0 + 3, y0 + 2, &hdr, palette::GOLD_RELIC, palette::VOID_BG);

                let derived = format!(
                    "ATK:{}  SPL:{}  DEF:{}  CRIT:{}%  MF:+{}%",
                    self.player.total_attack_power(),
                    self.player.total_spell_power(),
                    self.player.total_defense(),
                    self.player.total_crit_pct(),
                    self.player.magic_find_pct()
                );
                buf.draw_text_ui(x0 + 3, y0 + 4, &derived, palette::RUNE_CYAN, palette::VOID_BG);

                let rows_data = [
                    format!("VIT: {:2} (Max HP & Flask Recovery)", self.player.vit),
                    format!("STR: {:2} (Melee Attack & Armor Pen)", self.player.str_stat),
                    format!("DEX: {:2} (Crit Chance % & Attack Speed)", self.player.dex),
                    format!("INT: {:2} (Pyromancy & Hex Damage)", self.player.int_stat),
                    format!("FAI: {:2} (Sanctum Heal & Loot Luck %)", self.player.fai),
                    format!("SWITCH CLASS [Current: {}]", self.player.class.name()),
                ];
                for (i, line) in rows_data.iter().enumerate() {
                    let prefix = if i == self.menu_cursor { "> " } else { "  " };
                    let fg = if i == self.menu_cursor {
                        palette::EMBER_CORE
                    } else {
                        palette::BONE_WHITE
                    };
                    buf.draw_text_ui(
                        x0 + 3,
                        y0 + 6 + i as i32 * 2,
                        &format!("{}{}", prefix, line),
                        fg,
                        palette::VOID_BG,
                    );
                }
            }
            MenuState::InventoryAndLoot => {
                let box_w = 58.min(cols - 4);
                let box_h = 20.min(rows - 4);
                let x0 = (cols - box_w) / 2;
                let y0 = (rows - box_h) / 2;
                self.draw_ascii_box(buf, x0, y0, box_w, box_h, "EQUIPPED GEAR & LOOT BAG");

                for (i, slot) in EquipSlot::ALL.iter().enumerate() {
                    let item_txt = match self.player.equipped[i] {
                        Some(ref it) => format!(
                            "{}: {} (ATK+{} DEF+{} HP+{})",
                            slot.label(),
                            it.name,
                            it.atk_bonus,
                            it.def_bonus,
                            it.hp_bonus
                        ),
                        None => format!("{}: [Empty]", slot.label()),
                    };
                    buf.draw_text_ui(
                        x0 + 3,
                        y0 + 2 + i as i32,
                        &item_txt,
                        palette::GOLD_RELIC,
                        palette::VOID_BG,
                    );
                }

                buf.draw_text_ui(
                    x0 + 3,
                    y0 + 9,
                    "-- LOOT BAG (TAP RIGHT TO EQUIP SELECTED) --",
                    palette::RUNE_CYAN,
                    palette::VOID_BG,
                );
                if self.player.bag.is_empty() {
                    buf.draw_text_ui(
                        x0 + 3,
                        y0 + 11,
                        "Bag is empty. Slay enemies to collect loot drops!",
                        palette::ASH_DIM,
                        palette::VOID_BG,
                    );
                } else {
                    for (i, item) in self.player.bag.iter().take(7).enumerate() {
                        let sel = i == (self.menu_cursor % self.player.bag.len());
                        let line = format!(
                            "{}{} (Lv.{} Pwr:{})",
                            if sel { "> " } else { "  " },
                            item.name,
                            item.item_level,
                            item.power_score()
                        );
                        buf.draw_text_ui(
                            x0 + 3,
                            y0 + 11 + i as i32,
                            &line,
                            item.rarity.color(),
                            palette::VOID_BG,
                        );
                    }
                }
            }
            MenuState::MmoShardAndParty => {
                let box_w = 54.min(cols - 4);
                let box_h = 16;
                let x0 = (cols - box_w) / 2;
                let y0 = (rows - box_h) / 2;
                self.draw_ascii_box(buf, x0, y0, box_w, box_h, "SHARD VEYR-01 ONLINE PEERS");

                let net_line = format!(
                    "UDP SYNC: {}  TX:{} RX:{}",
                    self.net.shard_addr, self.net.packets_sent, self.net.packets_received
                );
                buf.draw_text_ui(x0 + 3, y0 + 2, &net_line, palette::RUNE_CYAN, palette::VOID_BG);

                if !self.remote_players.is_empty() {
                    for (i, rp) in self.remote_players.iter().enumerate() {
                        let sel = i == (self.menu_cursor % self.remote_players.len());
                        let line = format!(
                            "{}{} [Lv.{} {}] HP:{}/{} {}",
                            if sel { "> " } else { "  " },
                            rp.name,
                            rp.level,
                            rp.class.short_tag(),
                            rp.hp,
                            rp.max_hp,
                            if rp.in_party { "[PARTY]" } else { "[SOLO]" }
                        );
                        buf.draw_text_ui(
                            x0 + 3,
                            y0 + 5 + i as i32 * 2,
                            &line,
                            if rp.in_party {
                                palette::GOLD_RELIC
                            } else {
                                palette::ASH_LIGHT
                            },
                            palette::VOID_BG,
                        );
                    }
                }
            }
            MenuState::WorldMap => {
                let box_w = 52.min(cols - 4);
                let box_h = 22.min(rows - 4);
                let x0 = (cols - box_w) / 2;
                let y0 = (rows - box_h) / 2;
                self.draw_ascii_box(buf, x0, y0, box_w, box_h, "ATLAS OF THE SIX REALMS");

                let px = self.player.pos.x.round() as i32;
                let py = self.player.pos.y.round() as i32;
                for my in 2..(box_h - 2) {
                    for mx in 2..(box_w - 2) {
                        let wx = px + (mx - box_w / 2) * 4;
                        let wy = py + (my - box_h / 2) * 4;
                        let (glyph, col) = if (wx - px).abs() <= 2 && (wy - py).abs() <= 2 {
                            (b'@', palette::BONE_WHITE)
                        } else if self
                            .world
                            .discovered_shrines
                            .iter()
                            .any(|&(sx, sy)| (sx - wx).abs() <= 3 && (sy - wy).abs() <= 3)
                        {
                            (b'&', palette::EMBER_CORE)
                        } else {
                            match self.world.sample_biome(wx, wy) {
                                Biome::AshenMire => (b'~', palette::MIRE_MOSS),
                                Biome::SunkenCathedral => (b'+', palette::ASH_LIGHT),
                                Biome::ObsidianCrags => (b'^', palette::EMBER_GLOW),
                                Biome::WitheredWeald => (b'*', palette::ASH_DIM),
                                Biome::ForsakenCitadel => (b'#', palette::BONE_WHITE),
                                Biome::CinderAbyss => (b':', palette::ABYSS_VIOLET),
                            }
                        };
                        buf.put_ui(x0 + mx, y0 + my, glyph, col, palette::VOID_BG);
                    }
                }
                buf.draw_text_ui(
                    x0 + 3,
                    y0 + box_h - 2,
                    "[@] YOU  [&] SHRINE  (TAP RIGHT TO CLOSE)",
                    palette::GOLD_RELIC,
                    palette::VOID_BG,
                );
            }
            MenuState::LoreModal(lore_id) => {
                let (title, body) =
                    LORE_INSCRIPTIONS[(lore_id as usize) % LORE_INSCRIPTIONS.len()];
                let box_w = 56.min(cols - 4);
                let box_h = 10;
                let x0 = (cols - box_w) / 2;
                let y0 = (rows - box_h) / 2;
                self.draw_ascii_box(buf, x0, y0, box_w, box_h, title);

                let max_line = (box_w - 6) as usize;
                let mut row_cursor = y0 + 3;
                let mut current_line = String::new();
                for word in body.split_whitespace() {
                    if current_line.len() + word.len() + 1 > max_line {
                        buf.draw_text_ui(
                            x0 + 3,
                            row_cursor,
                            &current_line,
                            palette::BONE_WHITE,
                            palette::VOID_BG,
                        );
                        row_cursor += 1;
                        current_line.clear();
                    }
                    if !current_line.is_empty() {
                        current_line.push(' ');
                    }
                    current_line.push_str(word);
                }
                if !current_line.is_empty() {
                    buf.draw_text_ui(
                        x0 + 3,
                        row_cursor,
                        &current_line,
                        palette::BONE_WHITE,
                        palette::VOID_BG,
                    );
                }
                buf.draw_text_ui(
                    x0 + 3,
                    y0 + box_h - 2,
                    "[TAP RIGHT TO STEP BACK]",
                    palette::RUNE_CYAN,
                    palette::VOID_BG,
                );
            }
        }
    }

    fn draw_ascii_box(
        &self,
        buf: &mut AsciiScreenBuffer,
        x0: i32,
        y0: i32,
        w: i32,
        h: i32,
        title: &str,
    ) {
        for r in y0..(y0 + h) {
            for c in x0..(x0 + w) {
                let is_top_or_bot = r == y0 || r == y0 + h - 1;
                let is_left_or_right = c == x0 || c == x0 + w - 1;
                let glyph = if is_top_or_bot && is_left_or_right {
                    b'+'
                } else if is_top_or_bot {
                    b'-'
                } else if is_left_or_right {
                    b'|'
                } else {
                    b' '
                };
                buf.put_ui(c, r, glyph, palette::ASH_DIM, palette::VOID_BG);
            }
        }
        let header = format!("[ {} ]", title);
        let hx = x0 + (w - header.len() as i32) / 2;
        buf.draw_text_ui(hx.max(x0 + 1), y0, &header, palette::BONE_WHITE, palette::VOID_BG);
    }
}

// ============================================================================
// 10. EMBEDDED 95-GLYPH 8x12 BITMAP ASCII FONT ATLAS & OPENGL ES 3.0 SHADERS
// ============================================================================

pub fn build_procedural_ascii_atlas() -> (usize, usize, Vec<u8>) {
    let glyph_w = 8usize;
    let glyph_h = 12usize;
    let num_glyphs = 95usize;
    let tex_w = glyph_w * num_glyphs;
    let tex_h = glyph_h;
    let mut pixels = vec![0u8; tex_w * tex_h];

    for idx in 0..num_glyphs {
        let ch = (0x20 + idx as u8) as char;
        let rows = glyph_8x12_pattern(ch);
        for (ry, row_bits) in rows.iter().enumerate() {
            for rx in 0..8 {
                if (row_bits >> (7 - rx)) & 1 == 1 {
                    let px = idx * glyph_w + rx;
                    pixels[ry * tex_w + px] = 255;
                }
            }
        }
    }

    (tex_w, tex_h, pixels)
}

pub const fn glyph_8x12_pattern(ch: char) -> [u8; 12] {
    match ch {
        ' ' => [0; 12],
        '.' => [0, 0, 0, 0, 0, 0, 0, 0, 0x18, 0x18, 0, 0],
        ',' => [0, 0, 0, 0, 0, 0, 0, 0, 0x18, 0x18, 0x30, 0],
        '\'' => [0, 0x18, 0x18, 0x30, 0, 0, 0, 0, 0, 0, 0, 0],
        ':' => [0, 0, 0, 0x18, 0x18, 0, 0, 0x18, 0x18, 0, 0, 0],
        ';' => [0, 0, 0, 0x18, 0x18, 0, 0, 0x18, 0x18, 0x30, 0, 0],
        '-' => [0, 0, 0, 0, 0, 0x7E, 0x7E, 0, 0, 0, 0, 0],
        '=' => [0, 0, 0, 0, 0x7E, 0, 0, 0x7E, 0, 0, 0, 0],
        '+' => [0, 0, 0, 0x18, 0x18, 0x7E, 0x7E, 0x18, 0x18, 0, 0, 0],
        '|' => [0, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0],
        '/' => [0, 0x02, 0x06, 0x0C, 0x18, 0x18, 0x30, 0x60, 0xC0, 0x80, 0, 0],
        '\\' => [0, 0x80, 0xC0, 0x60, 0x30, 0x18, 0x18, 0x0C, 0x06, 0x02, 0, 0],
        '^' => [0, 0x18, 0x3C, 0x66, 0xC3, 0, 0, 0, 0, 0, 0, 0],
        '~' => [0, 0, 0, 0, 0x76, 0xDC, 0, 0, 0, 0, 0, 0],
        '*' => [0, 0, 0x18, 0x99, 0x5A, 0x3C, 0x5A, 0x99, 0x18, 0, 0, 0],
        '#' => [0, 0, 0x36, 0x36, 0xFF, 0x36, 0x36, 0xFF, 0x36, 0x36, 0, 0],
        '%' => [0, 0x62, 0x64, 0x08, 0x10, 0x26, 0x46, 0, 0, 0, 0, 0],
        '&' => [0, 0x38, 0x6C, 0x38, 0x76, 0xDC, 0xCC, 0x76, 0, 0, 0, 0],
        '@' => [0, 0x3C, 0x66, 0x99, 0xA5, 0xA5, 0x9F, 0x60, 0x3E, 0, 0, 0],
        '$' => [0, 0x18, 0x7E, 0x98, 0x7E, 0x1A, 0x7E, 0x18, 0, 0, 0, 0],
        '[' => [0, 0x3C, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x3C, 0, 0],
        ']' => [0, 0x3C, 0x0C, 0x0C, 0x0C, 0x0C, 0x0C, 0x0C, 0x0C, 0x3C, 0, 0],
        '(' => [0, 0x0C, 0x18, 0x30, 0x30, 0x30, 0x30, 0x18, 0x0C, 0, 0, 0],
        ')' => [0, 0x30, 0x18, 0x0C, 0x0C, 0x0C, 0x0C, 0x18, 0x30, 0, 0, 0],
        '!' => [0, 0x18, 0x3C, 0x3C, 0x18, 0x18, 0, 0x18, 0x18, 0, 0, 0],
        '>' => [0, 0, 0x60, 0x30, 0x18, 0x0C, 0x18, 0x30, 0x60, 0, 0, 0],
        '<' => [0, 0, 0x0C, 0x18, 0x30, 0x60, 0x30, 0x18, 0x0C, 0, 0, 0],
        _ => {
            let b = ch as u8;
            [
                0,
                0x3C,
                0x66 ^ (b & 0x18),
                0x66,
                0x7E ^ ((b >> 1) & 0x3C),
                0x66,
                0x66 ^ ((b >> 2) & 0x18),
                0x66,
                0x3C,
                0,
                0,
                0,
            ]
        }
    }
}

pub const GLES3_VERTEX_SHADER: &str = r#"#version 300 es
precision highp float;

layout(location = 0) in vec2 a_quad_uv;
layout(location = 1) in vec2 i_grid_pos;
layout(location = 2) in float i_glyph_index;
layout(location = 3) in float i_z_depth;
layout(location = 4) in vec4 i_fg_color;
layout(location = 5) in vec4 i_bg_color;

uniform vec2 u_grid_dims;

out vec2 v_atlas_uv;
out vec4 v_fg_color;
out vec4 v_bg_color;

void main() {
    vec2 cell_pos = (i_grid_pos + a_quad_uv) / u_grid_dims;
    vec2 ndc = vec2(cell_pos.x * 2.0 - 1.0, 1.0 - cell_pos.y * 2.0);
    gl_Position = vec4(ndc, 0.0, 1.0);

    float num_glyphs = 95.0;
    v_atlas_uv = vec2((i_glyph_index + a_quad_uv.x) / num_glyphs, a_quad_uv.y);
    v_fg_color = i_fg_color;
    v_bg_color = i_bg_color;
}
"#;

pub const GLES3_FRAGMENT_SHADER: &str = r#"#version 300 es
precision mediump float;

in vec2 v_atlas_uv;
in vec4 v_fg_color;
in vec4 v_bg_color;

uniform sampler2D u_font_atlas;

out vec4 frag_color;

void main() {
    float mask = texture(u_font_atlas, v_atlas_uv).r;
    frag_color = mix(v_bg_color, v_fg_color, mask);
}
"#;

// ============================================================================
// 11. ANDROID NATIVE ENTRY POINTS & STANDALONE COMPILABLE MAIN
// ============================================================================

/// Zero-dependency Android NDK `ANativeActivity_onCreate` hook (compiles with pure `std`).
#[cfg(target_os = "android")]
#[no_mangle]
pub extern "C" fn ANativeActivity_onCreate(
    _activity: *mut std::ffi::c_void,
    _saved_state: *const std::ffi::c_void,
    _saved_state_size: usize,
) {
    let mut game = AshveilGame::new(0xA547_E110_C1D3_2026);
    let mut screen = AsciiScreenBuffer::new(DEFAULT_GRID_COLS, DEFAULT_GRID_ROWS);
    let _atlas = build_procedural_ascii_atlas();
    game.update(1.0 / 60.0);
    game.render_ascii_frame(&mut screen);
    let _ = screen.pack_gpu_instances();
}

/// Optional `android-activity` crate hook when built with `--features android-ndk`.
#[cfg(all(target_os = "android", feature = "android-ndk"))]
#[no_mangle]
pub fn android_main(_app: android_activity::AndroidApp) {
    let mut game = AshveilGame::new(0xA547_E110_C1D3_2026);
    let mut screen = AsciiScreenBuffer::new(DEFAULT_GRID_COLS, DEFAULT_GRID_ROWS);
    game.update(1.0 / 60.0);
    game.render_ascii_frame(&mut screen);
    let _ = screen.pack_gpu_instances();
}


/// Zero-dependency JNI Bridge for Android Gradle (`com.ashveil.cinders.MainActivity`).
/// Allows the compiled `libashveil_ascii_3d.so` to be driven directly by `MainActivity.java`.
#[no_mangle]
pub extern "system" fn Java_com_ashveil_cinders_MainActivity_nativeInit(
    _env: *mut std::ffi::c_void,
    _class: *mut std::ffi::c_void,
    seed: i64,
) -> i64 {
    let game = Box::new(AshveilGame::new(seed as u64));
    Box::into_raw(game) as i64
}

#[no_mangle]
pub extern "system" fn Java_com_ashveil_cinders_MainActivity_nativeStep(
    _env: *mut std::ffi::c_void,
    _class: *mut std::ffi::c_void,
    handle: i64,
    dt: f32,
) -> i32 {
    if handle == 0 {
        return 0;
    }
    let game = unsafe { &mut *(handle as *mut AshveilGame) };
    game.update(dt);
    ((game.player.level & 0xFFFF) << 16) | (game.player.hp.max(0) & 0xFFFF)
}

#[no_mangle]
pub extern "system" fn Java_com_ashveil_cinders_MainActivity_nativeTouch(
    _env: *mut std::ffi::c_void,
    _class: *mut std::ffi::c_void,
    handle: i64,
    action: i32,
    pointer_id: i64,
    norm_x: f32,
    norm_y: f32,
) {
    if handle == 0 {
        return;
    }
    let game = unsafe { &mut *(handle as *mut AshveilGame) };
    match action {
        0 => game.touch.on_touch_start(pointer_id as u64, norm_x, norm_y),
        1 => game.touch.on_touch_move(pointer_id as u64, norm_x, norm_y),
        _ => game.touch.on_touch_end(pointer_id as u64),
    }
}

#[no_mangle]
pub extern "system" fn Java_com_ashveil_cinders_MainActivity_nativeDestroy(
    _env: *mut std::ffi::c_void,
    _class: *mut std::ffi::c_void,
    handle: i64,
) {
    if handle != 0 {
        unsafe {
            let _ = Box::from_raw(handle as *mut AshveilGame);
        }
    }
}

/// Compilable standalone entry point (`rustc --edition 2021 ashveil_ascii_3d.rs -O` or `cargo run`).
pub fn main() {
    let mut game = AshveilGame::new(0xA547_E110_C1D3_2026);
    let mut screen = AsciiScreenBuffer::new(DEFAULT_GRID_COLS, DEFAULT_GRID_ROWS);

    // Spawn an enemy in front of the player to verify combat, loot drops, and XP leveling
    game.enemies.push(Enemy::spawn(
        999,
        EnemyKind::SanctumKnight,
        3,
        Vec2::new(0.0, 1.0),
    ));

    for _ in 0..6 {
        game.player.attack_cooldown = 0.0;
        game.player.stamina = 100.0;
        game.perform_player_attack(true, true);
        game.update(1.0 / 60.0);
    }

    game.player.pos = Vec2::new(0.0, 1.0);
    game.update(1.0 / 60.0);
    game.render_ascii_frame(&mut screen);

    let instances = screen.pack_gpu_instances();
    println!(
        "ASHVEIL ONLINE v0.3 Ready | Grid: {}x{} ({} instances) | Player Lv.{} {} (XP:{}/{}) | Kills:{} | Chunks:{} | Feed: {}",
        screen.cols,
        screen.rows,
        instances.len(),
        game.player.level,
        game.player.class.name(),
        game.player.xp,
        game.player.xp_to_next,
        game.player.kills,
        game.world.chunks.len(),
        game.mmo_feed
    );
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_mmorpg_combat_loot_leveling_and_chunk_pruning() {
        let mut game = AshveilGame::new(42);
        let initial_lvl = game.player.level;
        let leveled = game.player.gain_xp(500);
        assert!(leveled);
        assert!(game.player.level > initial_lvl);
        assert!(game.player.stat_points >= 3);

        let item = LootItem::generate(&game.world.noise, 77, 10, 50);
        let (_status, name) = game.player.collect_loot_item(item);
        assert!(!name.is_empty());

        // Verify persistent tile activation across chunk pruning
        game.world.mark_tile_activated(128, 128);
        game.world.prune_distant_chunks(0, 0);
        assert!(game.world.column_at(128, 128).activated);

        let mut buf = AsciiScreenBuffer::new(DEFAULT_GRID_COLS, DEFAULT_GRID_ROWS);
        game.render_ascii_frame(&mut buf);
        assert_eq!(
            buf.pack_gpu_instances().len(),
            DEFAULT_GRID_COLS * DEFAULT_GRID_ROWS
        );
    }
}
