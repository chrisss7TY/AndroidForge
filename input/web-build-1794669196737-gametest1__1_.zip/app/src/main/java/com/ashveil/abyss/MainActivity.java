package com.ashveil.abyss;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class MainActivity extends Activity {
    private static boolean sRustLoaded = false;
    static {
        try {
            System.loadLibrary("ashveil_ascii_3d");
            sRustLoaded = true;
        } catch (Throwable ignored) {
            sRustLoaded = false;
        }
    }

    public static native long nativeInit(long seed);
    public static native int nativeStep(long handle, float dt);
    public static native void nativeTouch(long handle, int action, long pointerId, float normX, float normY);
    public static native void nativeDestroy(long handle);

    private AshveilView mView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );
        mView = new AshveilView(this);
        setContentView(mView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mView != null) mView.resumeGame();
    }

    @Override
    protected void onPause() {
        if (mView != null) mView.pauseGame();
        super.onPause();
    }

    private static final class AshveilView extends SurfaceView implements Runnable, SurfaceHolder.Callback {
        private static final String DENSE_RAMP = " .,:;-=+*oahkbdpqwmZOQ0N$%&8B#MW@";
        private static final String CLIFF_CHARS = "@WM#B8&%$N0QOZmwqpdbkhao*+=-:;,.";
        private static final String[] GROUND_ASCII = new String[]{
                "0Q8B", "QQ0O", "80aa", "qQ80", "b0Q8", "O08Q"
        };

        // Handcrafted ASCII House / Cottage (warm hearth + shingled roof)
        private static final String[] HOUSE_ART = new String[]{
                "      .::::::::::.      ",
                "    .:////////////:.    ",
                "  .:////////////////:.  ",
                " .====================. ",
                " |  [##]        [##]  | ",
                " |  |..|  .--.  |..|  | ",
                " |______| |**| |______| ",
                " |######| |**| |######| "
        };

        private Thread mThread;
        private volatile boolean mRunning = false;
        private long mRustHandle = 0;

        // Reusable Paints (zero per-frame allocations)
        private final Paint mAsciiPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mGrassPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mShadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mUiPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mUiSubPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mPanelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mBitmapPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
        private final Paint mGlowPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
        private final Paint mChunkBgPaint = new Paint();
        private final Paint mChunkTxtPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final char[] mSingleChar = new char[1];
        private final RectF mTmpRect = new RectF();
        private final Rect mSrcRect = new Rect();

        // Pre-baked World & Glow Caches (64 chunks = zero thrashing in landscape!)
        private static final int MEADOW_TILE_PX = 1536;
        private static final float CHUNK_WORLD_UNITS = 4.0f;
        private static final int CHUNK_PX = 384;
        private static final int CHUNK_CELLS = 24;
        private static final int CHUNK_CACHE_CAP = 100;

        private Bitmap mMeadowTileBitmap = null;
        private Bitmap mFogBitmap = null;
        private Bitmap mAmberGlowBitmap = null;
        private Bitmap mCyanGlowBitmap = null;
        private Bitmap mVignetteBitmap = null;

        private final int[] mChunkKeys = new int[CHUNK_CACHE_CAP];
        private final Bitmap[] mChunkBitmaps = new Bitmap[CHUNK_CACHE_CAP];
        private final Canvas[] mChunkCanvases = new Canvas[CHUNK_CACHE_CAP];
        private final int[] mChunkAge = new int[CHUNK_CACHE_CAP];
        private int mChunkTick = 1;


        // Procedural world (Minecraft-style): everything is a pure function of the seed.
        private volatile WorldGen mGen;
        private long mWorldSeed = 0L;
        private volatile boolean mWorldDirty = false;
        private volatile long mPendingSeed = 0L;
        private SharedPreferences mPrefs;
        private final ArrayList<WorldGen.Obj> mObjs = new ArrayList<WorldGen.Obj>();
        private final ArrayList<WorldGen.Obj> mChunkObjs = new ArrayList<WorldGen.Obj>();
        private final Random mRng = new Random();
        private final float[] mSample = new float[3];

        // Stone sprites (pillars / boulders), baked once per object and cached
        private static final int SPRITE_CACHE_CAP = 28;
        private final HashMap<Long, Bitmap> mSpriteCache = new HashMap<Long, Bitmap>();
        private final HashMap<Long, float[]> mSpriteBase = new HashMap<Long, float[]>();
        private final ArrayList<Long> mSpriteOrder = new ArrayList<Long>();
        private int mSpriteBudget = 1;
        private long mFrameStartNs = 0L;

        // Wispy world-anchored fog: two scrolling layers of tileable noise
        private Bitmap mFogTile = null;
        private final BitmapShader[] mFogShader = new BitmapShader[2];
        private final Paint[] mFogPaint = new Paint[]{new Paint(Paint.FILTER_BITMAP_FLAG), new Paint(Paint.FILTER_BITMAP_FLAG)};
        private final Matrix[] mFogMatrix = new Matrix[]{new Matrix(), new Matrix()};
        // 2.5D Perspective Ground Mesh & Billboard Projection Scratch
        private final Matrix mChunkMatrix = new Matrix();
        private final float[] mPolySrc = new float[8];
        private final float[] mPolyDst = new float[8];
        private final float[] mProjTmp = new float[3];
        private final float[] mProjTmp2 = new float[3];
        private Bitmap mHorizonBitmap = null;

        // Chunk painter scratch (no per-chunk allocation)
        private Bitmap mTintBitmap = null;
        private final int[] mTintPx = new int[CHUNK_CELLS * CHUNK_CELLS];
        private final float[] mLatCliff = new float[(CHUNK_CELLS + 1) * (CHUNK_CELLS + 1)];
        private final float[] mLatWater = new float[(CHUNK_CELLS + 1) * (CHUNK_CELLS + 1)];
        private final float[] mLatMoist = new float[(CHUNK_CELLS + 1) * (CHUNK_CELLS + 1)];
        private final boolean[] mSolid = new boolean[CHUNK_CELLS * CHUNK_CELLS];
        private final boolean[] mWet = new boolean[CHUNK_CELLS * CHUNK_CELLS];
        private final Paint mTintPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
        private static final int MASK_PX = CHUNK_CELLS * 4;
        private Bitmap mWaterMask = null;
        private Bitmap mCliffMask = null;
        private final int[] mMaskPx = new int[MASK_PX * MASK_PX];
        private final float[] mFoamBright = new float[900 * 4];
        private final float[] mFoamDim = new float[900 * 4];
        private final float[] mTickPts = new float[400 * 4];

        // Screen mode: 0 = Start Menu, 1 = Gameplay, 2 = Character / Inventory / Forge Modal
        private int mScreenMode = 0;
        private boolean mMounted = true;
        private boolean mAttackButtonOnly = true;
        private int mZoomPreset = 1;
        private float mCameraZoom = 1.15f;
        private int mWindPreset = 1;

        // World & Camera State
        private float mPlayerX = 0.0f;
        private float mPlayerY = 0.0f;
        private float mCamX = 0.0f;
        private float mCamY = 0.0f;
        private float mVelX = 0.0f;
        private float mVelY = 0.0f;
        private float mFacingX = 0.85f;
        private float mFacingY = 0.52f;
        private float mGaitPhase = 0.0f;
        private float mTimeSec = 0.0f;
        private float mSlashTimer = 0.0f;
        private float mSlashCooldown = 0.0f;
        private float mDodgeTimer = 0.0f;
        private float mDodgeCooldown = 0.0f;
        private float mDodgeDirX = 1.0f;
        private float mDodgeDirY = 0.0f;
        private float mPlayerHurtFlash = 0.0f;

        private static final int MAX_AFTERIMAGES = 5;
        private final float[] mGhostX = new float[MAX_AFTERIMAGES];
        private final float[] mGhostY = new float[MAX_AFTERIMAGES];
        private final float[] mGhostLife = new float[MAX_AFTERIMAGES];
        private float mGhostSpawnAccum = 0.0f;

        private float mCursorX = 0.54f;
        private float mCursorY = 0.52f;

        // Touch Controls
        private int mMovePointerId = -1;
        private float mJoyBaseX = 0.0f;
        private float mJoyBaseY = 0.0f;
        private float mJoyCurrX = 0.0f;
        private float mJoyCurrY = 0.0f;
        private float mInputX = 0.0f;
        private float mInputY = 0.0f;

        // Offline Single-Player RPG State
        private int mLevel = 13;
        private int mXp = 420;
        private int mXpNext = 900;
        private int mHp = 1612;
        private int mMaxHp = 1612;
        private int mMp = 134;
        private int mMaxMp = 134;
        private int mGold = 5194;
        private int mStatPoints = 3;
        private int mVit = 18;
        private int mStr = 21;
        private int mDex = 16;
        private int mForgeLevel = 2;
        private int mForgeSlot = 0; // 0=Helm, 1=Shoulders, 2=Chest, 3=Gloves, 4=Legs, 5=Boots
        private int mForgeMetal = 0; // 0=Iron..9=Emberstone
        private int mRuneSlot1 = -1;
        private int mRuneSlot2 = -1;
        private float mCoifRot = 0.0f;
        private String mEquippedWeapon = "Pale-Moon Greatsword";
        private String mEquippedArmor = "Silver-Weave Mail";
        private final String[] mInventory = new String[16];
        private int mInvCount = 2;

        // Toast Banner
        private String mStatusBanner = "Move with left thumb • [ATK] Slash • [DODGE] Dash";
        private float mBannerTimer = 4.0f;

        // Verlet Hair / Mane / Tail / Cloak Physics
        private static final int TAIL_STRANDS = 12;
        private static final int TAIL_NODES = 10;
        private final float[][] mTailX = new float[TAIL_STRANDS][TAIL_NODES];
        private final float[][] mTailY = new float[TAIL_STRANDS][TAIL_NODES];
        private final float[][] mTailPrevX = new float[TAIL_STRANDS][TAIL_NODES];
        private final float[][] mTailPrevY = new float[TAIL_STRANDS][TAIL_NODES];

        private static final int MANE_STRANDS = 14;
        private static final int MANE_NODES = 7;
        private final float[][] mManeX = new float[MANE_STRANDS][MANE_NODES];
        private final float[][] mManeY = new float[MANE_STRANDS][MANE_NODES];
        private final float[][] mManePrevX = new float[MANE_STRANDS][MANE_NODES];
        private final float[][] mManePrevY = new float[MANE_STRANDS][MANE_NODES];

        private static final int HAIR_STRANDS = 10;
        private static final int HAIR_NODES = 9;
        private final float[][] mHairX = new float[HAIR_STRANDS][HAIR_NODES];
        private final float[][] mHairY = new float[HAIR_STRANDS][HAIR_NODES];
        private final float[][] mHairPrevX = new float[HAIR_STRANDS][HAIR_NODES];
        private final float[][] mHairPrevY = new float[HAIR_STRANDS][HAIR_NODES];

        // Reference-video look: dense living grass, pollen sparkles, fluffy strand mane + tail
        private final GrassFx mGrassFx = new GrassFx();
        private final HairFx mTailFx = new HairFx(34, 11, 0.105f, 7L);
        private final HairFx mManeFx = new HairFx(24, 8, 0.085f, 9L);
        private float mNeckBaseLocX = 0.4f, mNeckBaseLocY = -0.1f, mNeckTopLocX = 0.8f, mNeckTopLocY = -0.6f;
        private float mAsciiAdv = 0.0f;

        // High-Resolution ASCII Entity Buffers (fine glyph grid: tall glyph cells like a real terminal)
        private static final float HORSE_SPAN_PPU = 3.15f;   // buffer width in world units
        private static final float HORSE_ROW_ASPECT = 1.3f;  // glyph cell height / width
        private static final int HORSE_BUF_W = 96;
        private static final int HORSE_BUF_H = 58;
        private final char[] mHorseGlyphBuf = new char[HORSE_BUF_W * HORSE_BUF_H];
        private final float[] mHorseLumBuf = new float[HORSE_BUF_W * HORSE_BUF_H];
        private final int[] mHorseColorBuf = new int[HORSE_BUF_W * HORSE_BUF_H];

        private static final int FOOT_BUF_W = 64;
        private static final int FOOT_BUF_H = 58;
        private final char[] mFootGlyphBuf = new char[FOOT_BUF_W * FOOT_BUF_H];
        private final float[] mFootLumBuf = new float[FOOT_BUF_W * FOOT_BUF_H];
        private final int[] mFootColorBuf = new int[FOOT_BUF_W * FOOT_BUF_H];
        private final float[] mFootZBuf = new float[FOOT_BUF_W * FOOT_BUF_H];
        // Hero glyph grid: square-ish world units, glyph cell height = 1.3 x width (like the horse grid)
        private static final float HERO_COLS_PER_UNIT = 24.0f;
        private static final float HERO_ROWS_PER_UNIT = 24.0f / 1.3f;
        private static final float HERO_UNIT_PPU = 0.942f;   // rig unit -> world unit (same as before)
        // hero animation state (smoothed so poses blend instead of popping)
        private float mHLastT = 0.0f, mHWalk = 0.0f, mHRun = 0.0f, mHRec = 0.0f;
        private float mHSfx = 0.85f, mHSfy = 0.4f;

        private static final int ENEMY_BUF_W = 38;
        private static final int ENEMY_BUF_H = 44;
        private final char[] mEnemyGlyphBuf = new char[ENEMY_BUF_W * ENEMY_BUF_H];
        private final float[] mEnemyLumBuf = new float[ENEMY_BUF_W * ENEMY_BUF_H];
        private final int[] mEnemyColorBuf = new int[ENEMY_BUF_W * ENEMY_BUF_H];

        // Humanoid Enemies (stay at guard post until player approaches!)
        private static final int NUM_ENEMIES = 6;
        private final float[] mEnemyX = new float[NUM_ENEMIES];
        private final float[] mEnemyY = new float[NUM_ENEMIES];
        private final float[] mEnemyHomeX = new float[NUM_ENEMIES];
        private final float[] mEnemyHomeY = new float[NUM_ENEMIES];
        private final float[] mEnemyFacingX = new float[NUM_ENEMIES];
        private final float[] mEnemyFacingY = new float[NUM_ENEMIES];
        private final float[] mEnemyGait = new float[NUM_ENEMIES];
        private final float[] mEnemyAtkWindup = new float[NUM_ENEMIES];
        private final float[] mEnemyAtkCooldown = new float[NUM_ENEMIES];
        private final boolean[] mEnemyAggro = new boolean[NUM_ENEMIES];
        private final int[] mEnemyHp = new int[NUM_ENEMIES];
        private final int[] mEnemyMaxHp = new int[NUM_ENEMIES];
        private final float[] mEnemyHurt = new float[NUM_ENEMIES];
        private final int[] mEnemyKind = new int[NUM_ENEMIES];

        private static final int MAX_LOOT = 16;
        private final float[] mLootX = new float[MAX_LOOT];
        private final float[] mLootY = new float[MAX_LOOT];
        private final boolean[] mLootActive = new boolean[MAX_LOOT];
        private final int[] mLootRarity = new int[MAX_LOOT];

        // Ash / Spark / Firefly Particles
        private static final int MAX_PARTICLES = 64;
        private final float[] mPartX = new float[MAX_PARTICLES];
        private final float[] mPartY = new float[MAX_PARTICLES];
        private final float[] mPartVx = new float[MAX_PARTICLES];
        private final float[] mPartVy = new float[MAX_PARTICLES];
        private final float[] mPartLife = new float[MAX_PARTICLES];
        private final int[] mPartColor = new int[MAX_PARTICLES];
        private int mPartCursor = 0;

        // Crafting Materials & Potions
        private int mHerbMoon = 3;
        private int mHerbCinder = 2;
        private int mHerbMoss = 2;
        private int mCinderShards = 2;
        private int mPotions = 2;

        // Harvestable Flora Nodes
        private static final int NUM_FLORA = 14;
        private final float[] mFloraX = new float[NUM_FLORA];
        private final float[] mFloraY = new float[NUM_FLORA];
        private final int[] mFloraKind = new int[NUM_FLORA]; // 0=Moonpetal, 1=Cinderbloom, 2=Ashmoss
        private final float[] mFloraRegrow = new float[NUM_FLORA];

        // Ambient Fauna (Deer, Rabbits, Birds, River Koi)
        private static final int NUM_FAUNA = 12;
        private final float[] mFaunaX = new float[NUM_FAUNA];
        private final float[] mFaunaY = new float[NUM_FAUNA];
        private final float[] mFaunaVx = new float[NUM_FAUNA];
        private final float[] mFaunaVy = new float[NUM_FAUNA];
        private final int[] mFaunaKind = new int[NUM_FAUNA]; // 0=Deer, 1=Rabbit, 2=Bird, 3=RiverKoi
        private final float[] mFaunaPhase = new float[NUM_FAUNA];

        // Floating Damage Popups
        private static final int MAX_POPUPS = 12;
        private final float[] mPopX = new float[MAX_POPUPS];
        private final float[] mPopY = new float[MAX_POPUPS];
        private final float[] mPopLife = new float[MAX_POPUPS];
        private final String[] mPopText = new String[MAX_POPUPS];
        private final int[] mPopColor = new int[MAX_POPUPS];
        private int mPopCursor = 0;

        public AshveilView(Context context) {
            super(context);
            getHolder().addCallback(this);
            setFocusable(true);
            setKeepScreenOn(true);

            mAsciiPaint.setTypeface(Typeface.MONOSPACE);
            mAsciiPaint.setFakeBoldText(true);
            mGrassPaint.setStyle(Paint.Style.STROKE);
            mGrassPaint.setStrokeCap(Paint.Cap.ROUND);
            mShadowPaint.setStyle(Paint.Style.FILL);
            mUiPaint.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
            mUiSubPaint.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL));
            mPanelPaint.setStyle(Paint.Style.FILL);
            mBorderPaint.setStyle(Paint.Style.STROKE);
            mBorderPaint.setStrokeWidth(2.2f);
            mGlowPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));
            mChunkBgPaint.setStyle(Paint.Style.FILL);
            mChunkTxtPaint.setTypeface(Typeface.MONOSPACE);
            mChunkTxtPaint.setFakeBoldText(true);

            mInventory[0] = mEquippedWeapon;
            mInventory[1] = mEquippedArmor;

            for (int i = 0; i < CHUNK_CACHE_CAP; i++) {
                mChunkKeys[i] = Integer.MIN_VALUE;
            }
            mPrefs = context.getSharedPreferences("ashveil_world", Context.MODE_PRIVATE);
            long seed;
            if (mPrefs.contains("seed")) {
                seed = mPrefs.getLong("seed", 0L);
            } else {
                seed = WorldGen.randomSeed();
                mPrefs.edit().putLong("seed", seed).apply();
            }
            buildWorld(seed, true);
        }

        /** (Re)generate the whole world from a seed and drop the player on its spawn meadow. */
        private void buildWorld(long seed, boolean restorePos) {
            WorldGen g = new WorldGen(seed);
            mGen = g;
            mWorldSeed = seed;
            mRng.setSeed(seed ^ 0xA5A5A5L);
            mSpriteCache.clear();
            mSpriteBase.clear();
            mSpriteOrder.clear();
            for (int i = 0; i < CHUNK_CACHE_CAP; i++) {
                mChunkKeys[i] = Integer.MIN_VALUE;
            }
            float px = g.spawnX;
            float py = g.spawnY;
            if (restorePos && mPrefs != null && mPrefs.getLong("pos_seed", Long.MIN_VALUE) == seed) {
                float sx = mPrefs.getFloat("pos_x", px);
                float sy = mPrefs.getFloat("pos_y", py);
                if (!g.blocked(sx, sy)) {
                    px = sx;
                    py = sy;
                }
            }
            mPlayerX = px;
            mPlayerY = py;
            mCamX = px;
            mCamY = py;
            mVelX = 0.0f;
            mVelY = 0.0f;
            initWorld();
        }

        private void requestWorld(long seed) {
            mPendingSeed = seed;
            mWorldDirty = true;
        }

        private void promptForSeed() {
            final Context ctx = getContext();
            if (!(ctx instanceof Activity)) return;
            ((Activity) ctx).runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    final EditText input = new EditText(ctx);
                    input.setInputType(InputType.TYPE_CLASS_TEXT);
                    input.setSingleLine(true);
                    input.setHint("Blank = random world");
                    new AlertDialog.Builder(ctx)
                            .setTitle("World seed")
                            .setMessage("Same seed, same world. Numbers or any text.")
                            .setView(input)
                            .setPositiveButton("Create", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface d, int which) {
                                    requestWorld(WorldGen.seedFromText(input.getText().toString()));
                                }
                            })
                            .setNegativeButton("Cancel", null)
                            .show();
                }
            });
        }

        private void saveProgress() {
            if (mPrefs == null) return;
            mPrefs.edit().putLong("seed", mWorldSeed)
                    .putLong("pos_seed", mWorldSeed)
                    .putFloat("pos_x", mPlayerX)
                    .putFloat("pos_y", mPlayerY)
                    .apply();
        }

        private Bitmap spriteFor(WorldGen.Obj o, float[] baseOut) {
            Long key = Long.valueOf(o.id);
            Bitmap b = mSpriteCache.get(key);
            if (b == null) {
                if (mSpriteBudget <= 0) return null;
                mSpriteBudget--;
                float[] base = new float[2];
                b = Gfx.rockSprite(o, base);
                if (mSpriteOrder.size() >= SPRITE_CACHE_CAP) {
                    Long old = mSpriteOrder.remove(0);
                    mSpriteCache.remove(old);
                    mSpriteBase.remove(old);
                }
                mSpriteCache.put(key, b);
                mSpriteBase.put(key, base);
                mSpriteOrder.add(key);
            }
            float[] bs = mSpriteBase.get(key);
            baseOut[0] = bs[0];
            baseOut[1] = bs[1];
            return b;
        }

        private void initWorld() {
            mTailFx.reset();
            mManeFx.reset();
            for (int s = 0; s < TAIL_STRANDS; s++) {
                for (int n = 0; n < TAIL_NODES; n++) {
                    mTailX[s][n] = mTailPrevX[s][n] = mPlayerX - 1.1f - n * 0.14f;
                    mTailY[s][n] = mTailPrevY[s][n] = mPlayerY + n * 0.12f;
                }
            }
            for (int s = 0; s < MANE_STRANDS; s++) {
                for (int n = 0; n < MANE_NODES; n++) {
                    mManeX[s][n] = mManePrevX[s][n] = mPlayerX + 0.4f;
                    mManeY[s][n] = mManePrevY[s][n] = mPlayerY - 0.6f + n * 0.08f;
                }
            }
            for (int s = 0; s < HAIR_STRANDS; s++) {
                for (int n = 0; n < HAIR_NODES; n++) {
                    mHairX[s][n] = mHairPrevX[s][n] = mPlayerX - 0.1f - n * 0.10f;
                    mHairY[s][n] = mHairPrevY[s][n] = mPlayerY - 1.25f + n * 0.08f;
                }
            }
            for (int i = 0; i < NUM_ENEMIES; i++) {
                spawnEnemy(i, i < 3);
            }
            for (int i = 0; i < NUM_FLORA; i++) {
                float[] p = mGen.randomOpenPoint(mRng, mPlayerX, mPlayerY, 2.8f, 14.0f);
                mFloraX[i] = (p != null) ? p[0] : mPlayerX + 3.0f + i * 0.5f;
                mFloraY[i] = (p != null) ? p[1] : mPlayerY + 1.0f;
                mFloraKind[i] = i % 3;
                mFloraRegrow[i] = 0.0f;
            }
            for (int i = 0; i < NUM_FAUNA; i++) {
                mFaunaKind[i] = i % 4;
                float[] p = null;
                if (mFaunaKind[i] == 3) {
                    p = mGen.randomWaterPoint(mRng, mPlayerX, mPlayerY, 4.0f, 22.0f);
                    if (p == null) mFaunaKind[i] = 1; // no water nearby: rabbit instead of koi
                }
                if (p == null) p = mGen.randomOpenPoint(mRng, mPlayerX, mPlayerY, 3.2f, 14.0f);
                mFaunaX[i] = (p != null) ? p[0] : mPlayerX + 4.0f;
                mFaunaY[i] = (p != null) ? p[1] : mPlayerY + 2.0f;
                mFaunaVx[i] = (i % 2 == 0) ? 0.6f : -0.6f;
                mFaunaVy[i] = 0.2f;
                mFaunaPhase[i] = i * 1.1f;
            }
        }

        private void ensureStaticCaches() {
            if (mMeadowTileBitmap == null) {
                mMeadowTileBitmap = Gfx.grassTile(MEADOW_TILE_PX);
            }

            if (mFogTile == null) {
                mFogTile = Gfx.fogTile(0xF06L);
                for (int i = 0; i < 2; i++) {
                    mFogShader[i] = new BitmapShader(mFogTile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
                    mFogPaint[i].setShader(mFogShader[i]);
                }
            }

            if (mFogBitmap == null) {
                mFogBitmap = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888);
                Canvas fc = new Canvas(mFogBitmap);
                Paint fp = new Paint(Paint.ANTI_ALIAS_FLAG);
                fp.setShader(new RadialGradient(
                        128f, 128f, 128f,
                        Color.argb(62, 205, 222, 228),
                        Color.argb(0, 205, 222, 228),
                        Shader.TileMode.CLAMP
                ));
                fc.drawCircle(128f, 128f, 128f, fp);
            }

            if (mAmberGlowBitmap == null) {
                mAmberGlowBitmap = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888);
                Canvas ac = new Canvas(mAmberGlowBitmap);
                Paint ap = new Paint(Paint.ANTI_ALIAS_FLAG);
                ap.setShader(new RadialGradient(
                        128f, 128f, 128f,
                        new int[]{Color.argb(150, 255, 195, 90), Color.argb(60, 235, 130, 45), Color.argb(0, 0, 0, 0)},
                        new float[]{0.0f, 0.45f, 1.0f},
                        Shader.TileMode.CLAMP
                ));
                ac.drawCircle(128f, 128f, 128f, ap);
            }

            if (mCyanGlowBitmap == null) {
                mCyanGlowBitmap = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888);
                Canvas cc = new Canvas(mCyanGlowBitmap);
                Paint cp = new Paint(Paint.ANTI_ALIAS_FLAG);
                cp.setShader(new RadialGradient(
                        128f, 128f, 128f,
                        new int[]{Color.argb(140, 120, 245, 220), Color.argb(55, 60, 190, 175), Color.argb(0, 0, 0, 0)},
                        new float[]{0.0f, 0.45f, 1.0f},
                        Shader.TileMode.CLAMP
                ));
                cc.drawCircle(128f, 128f, 128f, cp);
            }

            if (mHorizonBitmap == null) {
                mHorizonBitmap = Bitmap.createBitmap(16, 256, Bitmap.Config.ARGB_8888);
                Canvas hc = new Canvas(mHorizonBitmap);
                Paint hp = new Paint(Paint.ANTI_ALIAS_FLAG);
                hp.setShader(new LinearGradient(
                        0f, 0f, 0f, 256f,
                        new int[]{Color.argb(225, 3, 7, 8), Color.argb(120, 6, 13, 14), Color.argb(0, 7, 14, 13)},
                        new float[]{0.0f, 0.42f, 1.0f},
                        Shader.TileMode.CLAMP
                ));
                hc.drawRect(0, 0, 16, 256, hp);
            }

            if (mVignetteBitmap == null) {
                mVignetteBitmap = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888);
                Canvas vc = new Canvas(mVignetteBitmap);
                Paint vp = new Paint(Paint.ANTI_ALIAS_FLAG);
                vp.setShader(new RadialGradient(
                        128f, 128f, 168f,
                        new int[]{Color.argb(0, 0, 0, 0), Color.argb(30, 3, 6, 6), Color.argb(135, 2, 5, 5)},
                        new float[]{0.50f, 0.80f, 1.0f},
                        Shader.TileMode.CLAMP
                ));
                vc.drawRect(0, 0, 256, 256, vp);
            }
        }

        /** True if the spot is not walkable (rock, deep water, stones, houses). */
        private boolean isCliff(float wx, float wy) {
            WorldGen g = mGen;
            return g != null && g.blocked(wx, wy);
        }

        private void spawnEnemy(int i, boolean close) {
            float[] p = mGen.randomOpenPoint(mRng, mPlayerX, mPlayerY, close ? 4.8f : 8.0f, close ? 12.0f : 20.0f);
            float ex = (p != null) ? p[0] : mPlayerX + 4.2f;
            float ey = (p != null) ? p[1] : mPlayerY + 3.2f;
            mEnemyX[i] = ex;
            mEnemyY[i] = ey;
            mEnemyHomeX[i] = ex;
            mEnemyHomeY[i] = ey;
            mEnemyFacingX[i] = -1.0f;
            mEnemyFacingY[i] = 0.0f;
            mEnemyGait[i] = i * 0.7f;
            mEnemyAtkWindup[i] = 0.0f;
            mEnemyAtkCooldown[i] = 0.6f;
            mEnemyAggro[i] = false;
            mEnemyKind[i] = i % 4;
            mEnemyMaxHp[i] = 95 + mLevel * 14 + (i % 3) * 35;
            mEnemyHp[i] = mEnemyMaxHp[i];
            mEnemyHurt[i] = 0.0f;
        }

        private void spawnParticles(float wx, float wy, int count, int color) {
            for (int k = 0; k < count; k++) {
                int idx = mPartCursor;
                mPartCursor = (mPartCursor + 1) % MAX_PARTICLES;
                float ang = (float) ((k * 2.399f) + mTimeSec * 3.7f);
                float spd = 1.4f + (k % 4) * 0.85f;
                mPartX[idx] = wx;
                mPartY[idx] = wy;
                mPartVx[idx] = (float) Math.cos(ang) * spd;
                mPartVy[idx] = (float) Math.sin(ang) * spd - 0.6f;
                mPartLife[idx] = 0.42f + (k % 3) * 0.10f;
                mPartColor[idx] = color;
            }
        }

        private void spawnPopup(float wx, float wy, String text, int color) {
            int idx = mPopCursor;
            mPopCursor = (mPopCursor + 1) % MAX_POPUPS;
            mPopX[idx] = wx;
            mPopY[idx] = wy;
            mPopLife[idx] = 0.85f;
            mPopText[idx] = text;
            mPopColor[idx] = color;
        }

        @Override
        public void surfaceCreated(SurfaceHolder holder) {
            if (sRustLoaded && mRustHandle == 0) {
                try {
                    mRustHandle = nativeInit(mWorldSeed);
                } catch (Throwable ignored) {
                    mRustHandle = 0;
                }
            }
            resumeGame();
        }

        @Override
        public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        }

        @Override
        public void surfaceDestroyed(SurfaceHolder holder) {
            pauseGame();
            if (sRustLoaded && mRustHandle != 0) {
                try {
                    nativeDestroy(mRustHandle);
                } catch (Throwable ignored) {
                }
                mRustHandle = 0;
            }
        }

        public void resumeGame() {
            if (mRunning) return;
            if (mThread != null && mThread.isAlive()) {
                try {
                    mThread.join(400);
                } catch (InterruptedException ignored) {
                }
            }
            mRunning = true;
            mThread = new Thread(this, "AshveilRenderLoop");
            mThread.setPriority(Thread.MAX_PRIORITY);
            mThread.start();
        }

        public void pauseGame() {
            saveProgress();
            mRunning = false;
            if (mThread != null) {
                try {
                    mThread.join(400);
                } catch (InterruptedException ignored) {
                }
                if (!mThread.isAlive()) mThread = null;   // keep the handle if it is still winding down
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            int action = event.getActionMasked();
            int idx = event.getActionIndex();
            int pointerId = event.getPointerId(idx);
            float x = event.getX(idx);
            float y = event.getY(idx);
            float w = Math.max(1.0f, getWidth());
            float h = Math.max(1.0f, getHeight());

            if (sRustLoaded && mRustHandle != 0) {
                try {
                    nativeTouch(mRustHandle, action, pointerId, x / w, y / h);
                } catch (Throwable ignored) {
                }
            }

            if (mScreenMode == 0) {
                if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                    handleStartMenuTap(x, y, w, h);
                }
                return true;
            }

            if (mScreenMode == 2) {
                if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                    handleModalTap(x, y, w, h);
                }
                return true;
            }

            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                float boxH = Math.min(h * 0.14f, 156.0f);
                float pillW = Math.min(w * 0.18f, 172.0f);
                float pillH = Math.max(36.0f, boxH * 0.34f);
                float px = w - pillW - 18.0f;
                float y0 = 18.0f;

                if (x >= px && x <= px + pillW) {
                    if (y >= y0 && y <= y0 + pillH) {
                        mMovePointerId = -1;
                        mInputX = 0.0f;
                        mInputY = 0.0f;
                        mScreenMode = 0;
                        return true;
                    }
                    float py2 = y0 + pillH + 8.0f;
                    if (y >= py2 && y <= py2 + pillH) {
                        mZoomPreset = (mZoomPreset + 1) % 3;
                        mCameraZoom = (mZoomPreset == 0) ? 1.55f : (mZoomPreset == 1 ? 1.15f : 0.78f);
                        showBanner(mZoomPreset == 0 ? "Camera: Close-up" : (mZoomPreset == 1 ? "Camera: Meadow" : "Camera: Wide"));
                        return true;
                    }
                    float py3 = py2 + pillH + 8.0f;
                    if (y >= py3 && y <= py3 + pillH) {
                        mMounted = !mMounted; mTailFx.reset(); mManeFx.reset();
                        spawnParticles(mPlayerX, mPlayerY, 14, Color.rgb(220, 235, 228));
                        showBanner(mMounted ? "Mounted White Steed" : "Dismounted (Foot Knight)");
                        return true;
                    }
                }

                if (x < w * 0.34f && y < h * 0.18f) {
                    mMovePointerId = -1;
                    mInputX = 0.0f;
                    mInputY = 0.0f;
                    mScreenMode = 2;
                    return true;
                }

                // Bottom Hotbar Slot 1 tap -> drink Healing Draught
                float hbW = hbWidth(w, h);
                float hbX = (w - hbW) * 0.5f;
                float hbY = h - hbSlotH(hbW);
                if (y >= hbY && y <= h && x >= hbX && x <= hbX + hbW) {
                    float slotW = hbW / 10.0f;
                    int slotIdx = (int) ((x - hbX) / slotW);
                    if (slotIdx == 0) {
                        if (mPotions > 0 && mHp < mMaxHp) {
                            mPotions--;
                            mHp = Math.min(mMaxHp, mHp + 450);
                            mMp = Math.min(mMaxMp, mMp + 60);
                            spawnParticles(mPlayerX, mPlayerY - 0.2f, 12, Color.rgb(145, 245, 200));
                            spawnPopup(mPlayerX, mPlayerY - 0.9f, "+450 HP", Color.rgb(145, 245, 200));
                        } else if (mPotions <= 0) {
                            showBanner("No Healing Draughts left (craft in Forge)");
                        }
                    }
                    return true;
                }

                float atkR = Math.min(w, h) * 0.088f;
                float atkCx = w - atkR - 26.0f;
                float atkCy = h - atkR - 26.0f - btnLift(w, h);
                float dxA = x - atkCx;
                float dyA = y - atkCy;
                if (dxA * dxA + dyA * dyA <= (atkR * 1.25f) * (atkR * 1.25f)) {
                    triggerSlash();
                    return true;
                }

                float dodgeR = Math.min(w, h) * 0.070f;
                float dodgeCx = atkCx - atkR - dodgeR - 22.0f;
                float dodgeCy = h - dodgeR - 26.0f - btnLift(w, h);
                float dxD = x - dodgeCx;
                float dyD = y - dodgeCy;
                if (dxD * dxD + dyD * dyD <= (dodgeR * 1.25f) * (dodgeR * 1.25f)) {
                    triggerDodge();
                    return true;
                }

                if (x < w * 0.50f) {
                    mMovePointerId = pointerId;
                    mJoyBaseX = x;
                    mJoyBaseY = y;
                    mJoyCurrX = x;
                    mJoyCurrY = y;
                    mInputX = 0.0f;
                    mInputY = 0.0f;
                } else {
                    mCursorX = x / w;
                    mCursorY = y / h;
                    if (!mAttackButtonOnly) {
                        triggerSlash();
                    }
                }
            } else if (action == MotionEvent.ACTION_MOVE) {
                int count = event.getPointerCount();
                for (int i = 0; i < count; i++) {
                    int pId = event.getPointerId(i);
                    float px = event.getX(i);
                    float py = event.getY(i);
                    if (pId == mMovePointerId) {
                        mJoyCurrX = px;
                        mJoyCurrY = py;
                        float dx = px - mJoyBaseX;
                        float dy = py - mJoyBaseY;
                        float maxR = Math.min(w, h) * 0.14f;
                        float len = (float) Math.sqrt(dx * dx + dy * dy);
                        if (len > 4.0f) {
                            float mag = Math.min(1.0f, len / maxR);
                            mInputX = (dx / len) * mag;
                            mInputY = (dy / len) * mag;
                        } else {
                            mInputX = 0.0f;
                            mInputY = 0.0f;
                        }
                    } else {
                        mCursorX = px / w;
                        mCursorY = py / h;
                    }
                }
            } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP || action == MotionEvent.ACTION_CANCEL) {
                if (pointerId == mMovePointerId) {
                    mMovePointerId = -1;
                    mInputX = 0.0f;
                    mInputY = 0.0f;
                }
            }
            return true;
        }

        private float hbWidth(float w, float h) {
            return Math.min(w, Math.max(w * 0.46f, h * 0.9f));
        }

        /** Lift the round buttons above the hotbar when the hotbar spans most of the screen width. */
        private float btnLift(float w, float h) {
            float hw = hbWidth(w, h);
            return (hw > w * 0.7f) ? hbSlotH(hw) + 30.0f : 0.0f;
        }

        private float hbSlotH(float hbW) {
            return Math.min(hbW / 10.0f * 0.8f, 92.0f);
        }

        private static final float[] MENU_TOPS = {0.33f, 0.425f, 0.52f, 0.615f, 0.71f, 0.805f};
        private static final float MENU_H = 0.078f;

        private void handleStartMenuTap(float x, float y, float w, float h) {
            if (x < w * 0.18f || x > w * 0.82f) return;
            int row = -1;
            for (int r = 0; r < MENU_TOPS.length; r++) {
                if (y >= h * MENU_TOPS[r] && y <= h * (MENU_TOPS[r] + MENU_H)) row = r;
            }
            if (row == 0) {
                mScreenMode = 1;
                showBanner(mAttackButtonOnly ? "Left Thumb: Move  |  ATK: Slash  |  DODGE: Dash" : "Left Thumb: Move  |  Tap Right: Slash");
            } else if (row == 1) {
                if (x < w * 0.5f) {
                    requestWorld(WorldGen.randomSeed());       // brand-new random world
                } else {
                    promptForSeed();                           // type your own seed
                }
            } else if (row == 2) {
                mZoomPreset = (mZoomPreset + 1) % 3;
                mCameraZoom = (mZoomPreset == 0) ? 1.55f : (mZoomPreset == 1 ? 1.15f : 0.78f);
            } else if (row == 3) {
                mMounted = !mMounted; mTailFx.reset(); mManeFx.reset();
            } else if (row == 4) {
                mAttackButtonOnly = !mAttackButtonOnly;
            } else if (row == 5) {
                mScreenMode = 2;
            }
        }

        private void handleModalTap(float x, float y, float w, float h) {
            if (y > h * 0.88f && x > w * 0.72f) {
                mScreenMode = 1;
                return;
            }
            // Top slot tabs: Helm, Shoulders, Chest, Gloves, Legs, Boots
            if (y >= h * 0.05f && y <= h * 0.12f) {
                int s = (int) ((x - w * 0.06f) / ((w * 0.88f) / 6.0f));
                if (s >= 0 && s < 6) mForgeSlot = s;
                return;
            }
            // Rune selector row (^ * z ~ > / x v o § +)
            if (y >= h * 0.13f && y <= h * 0.21f) {
                int r = (int) ((x - w * 0.06f) / ((w * 0.88f) / 11.0f));
                if (r >= 0 && r < 11) {
                    if (mRuneSlot1 == -1) mRuneSlot1 = r;
                    else if (mRuneSlot2 == -1) mRuneSlot2 = r;
                    else { mRuneSlot1 = r; mRuneSlot2 = -1; }
                    mStr += 1;
                    showBanner("Inscribed Rune onto Armor (+1 STR)");
                }
                return;
            }
            // Metal selector row
            if (y >= h * 0.22f && y <= h * 0.30f) {
                int m = (int) ((x - w * 0.06f) / ((w * 0.88f) / 5.0f));
                int row = (y > h * 0.26f) ? 1 : 0;
                int idx = row * 5 + Math.max(0, Math.min(4, m));
                mForgeMetal = idx;
                mForgeLevel = Math.max(mForgeLevel, idx + 1);
                showBanner("Forged Metal Tier " + (idx + 1));
                return;
            }
            // Bottom-left action buttons: Upgrade Stats / Craft Potion / Return
            if (y >= h * 0.88f && x <= w * 0.36f && mStatPoints > 0) {
                mStatPoints--;
                mVit += 2; mStr += 2; mDex += 1;
                mMaxHp += 48; mHp = mMaxHp;
                showBanner("Upgraded Stats (" + mStatPoints + " pts left)");
            } else if (y >= h * 0.88f && x > w * 0.36f && x <= w * 0.72f) {
                if (mHerbMoon >= 2 && mHerbMoss >= 1) {
                    mHerbMoon -= 2; mHerbMoss -= 1;
                    mPotions++; mHp = Math.min(mMaxHp, mHp + 450);
                    showBanner("Crafted Healing Draught (+450 HP)");
                } else {
                    showBanner("Need 2 Moonpetal + 1 Ashmoss");
                }
            }
        }

        private void showBanner(String msg) {
            mStatusBanner = msg;
            mBannerTimer = 2.6f;
        }

        private void triggerDodge() {
            if (mDodgeCooldown > 0.0f) return;
            mDodgeTimer = 0.28f;
            mDodgeCooldown = 0.85f;
            float len = (float) Math.sqrt(mInputX * mInputX + mInputY * mInputY);
            if (len > 0.15f) {
                mDodgeDirX = mInputX / len;
                mDodgeDirY = mInputY / len;
            } else {
                mDodgeDirX = mFacingX;
                mDodgeDirY = mFacingY;
            }
            mFacingX = mDodgeDirX;
            mFacingY = mDodgeDirY;
            mGhostSpawnAccum = 0.06f;
            spawnParticles(mPlayerX, mPlayerY + 0.15f, 12, Color.rgb(165, 240, 230));
        }

        private void triggerSlash() {
            if (mSlashCooldown > 0.0f) return;
            mSlashTimer = 0.26f;
            mSlashCooldown = 0.32f;

            float dmg = 34 + mStr * 3 + mForgeLevel * 14;
            for (int i = 0; i < NUM_ENEMIES; i++) {
                float dx = mEnemyX[i] - mPlayerX;
                float dy = mEnemyY[i] - mPlayerY;
                float d2 = dx * dx + dy * dy;
                if (d2 < 3.4f * 3.4f) {
                    int dealt = (int) dmg;
                    mEnemyHp[i] -= dealt;
                    mEnemyHurt[i] = 0.24f;
                    mEnemyAggro[i] = true;
                    float len = (float) Math.sqrt(d2 + 0.001f);
                    mEnemyX[i] += (dx / len) * 0.55f;
                    mEnemyY[i] += (dy / len) * 0.55f;
                    spawnParticles(mEnemyX[i], mEnemyY[i] - 0.3f, 8, Color.rgb(245, 210, 120));
                    spawnPopup(mEnemyX[i], mEnemyY[i] - 0.8f, "-" + dealt, Color.rgb(255, 224, 125));
                    if (mEnemyHp[i] <= 0) {
                        onEnemyDefeated(i);
                    }
                }
            }
        }

        private void onEnemyDefeated(int i) {
            spawnParticles(mEnemyX[i], mEnemyY[i] - 0.2f, 18, Color.rgb(220, 235, 240));
            int gainedXp = 140 + mLevel * 28;
            int gainedGold = 45 + (i * 17) % 60;
            mXp += gainedXp;
            mGold += gainedGold;
            mCinderShards += 1;
            if (mXp >= mXpNext) {
                mXp -= mXpNext;
                mLevel++;
                mXpNext = (int) (mXpNext * 1.28f);
                mStatPoints += 3;
                mMaxHp += 95;
                mHp = mMaxHp;
                mMaxMp += 16;
                mMp = mMaxMp;
                showBanner("Level Up! LV." + mLevel + " (+3 Stat Points)");
            } else {
                showBanner("Defeated Wanderer (+" + gainedXp + " XP, +" + gainedGold + "g)");
            }

            for (int l = 0; l < MAX_LOOT; l++) {
                if (!mLootActive[l]) {
                    mLootActive[l] = true;
                    mLootX[l] = mEnemyX[i];
                    mLootY[l] = mEnemyY[i];
                    mLootRarity[l] = (i + mLevel) % 4;
                    break;
                }
            }
            spawnEnemy(i, false);
        }

        @Override
        public void run() {
            long lastNs = System.nanoTime();
            while (mRunning) {
                long nowNs = System.nanoTime();
                float dt = (nowNs - lastNs) / 1_000_000_000.0f;
                lastNs = nowNs;
                if (dt > 0.05f) dt = 0.05f;
                if (dt < 0.001f) dt = 0.001f;

                if (sRustLoaded && mRustHandle != 0) {
                    try {
                        nativeStep(mRustHandle, dt);
                    } catch (Throwable ignored) {
                    }
                }

                try {
                    updateSimulation(dt);
                    drawFrame();
                } catch (RuntimeException e) {
                    // Surface not ready / torn down mid-frame: skip this frame instead of killing the render thread.
                    android.util.Log.w("Ashveil", "frame skipped: " + e);
                }

                // Cap at ~60 fps (saves battery / heat); sleep only the time left in the frame budget.
                long spentMs = (System.nanoTime() - nowNs) / 1_000_000L;
                long waitMs = 16L - spentMs;
                try {
                    Thread.sleep(waitMs > 1L ? waitMs : 1L);
                } catch (InterruptedException ignored) {
                }
            }
        }

        private void updateSimulation(float dt) {
            if (mWorldDirty) {
                mWorldDirty = false;
                buildWorld(mPendingSeed, false);
                saveProgress();
                showBanner("New world \u2022 seed " + mWorldSeed);
            }
            mTimeSec += dt;
            if (mBannerTimer > 0.0f) mBannerTimer -= dt;
            if (mSlashTimer > 0.0f) mSlashTimer -= dt;
            if (mSlashCooldown > 0.0f) mSlashCooldown -= dt;
            if (mDodgeTimer > 0.0f) mDodgeTimer -= dt;
            if (mDodgeCooldown > 0.0f) mDodgeCooldown -= dt;
            if (mPlayerHurtFlash > 0.0f) mPlayerHurtFlash -= dt;

            for (int g = 0; g < MAX_AFTERIMAGES; g++) {
                if (mGhostLife[g] > 0.0f) mGhostLife[g] -= dt;
            }

            if (mScreenMode == 0) {
                mCamX = mPlayerX + (float) Math.sin(mTimeSec * 0.25f) * 1.8f;
                mCamY = mPlayerY + (float) Math.cos(mTimeSec * 0.18f) * 1.1f;
                mFacingX = 0.88f;
                mFacingY = 0.42f;
                mGaitPhase += dt * 4.0f;
            } else if (mScreenMode == 1) {
                if (mDodgeTimer > 0.0f) {
                    float dashSpeed = mMounted ? 13.5f : 11.2f;
                    mVelX = mDodgeDirX * dashSpeed;
                    mVelY = mDodgeDirY * dashSpeed;
                    mGhostSpawnAccum += dt;
                    if (mGhostSpawnAccum >= 0.045f) {
                        mGhostSpawnAccum = 0.0f;
                        for (int g = 0; g < MAX_AFTERIMAGES; g++) {
                            if (mGhostLife[g] <= 0.0f) {
                                mGhostX[g] = mPlayerX;
                                mGhostY[g] = mPlayerY;
                                mGhostLife[g] = 0.24f;
                                break;
                            }
                        }
                    }
                } else {
                    float topSpeed = mMounted ? 5.6f : 3.9f;
                    float targetVx = mInputX * topSpeed;
                    float targetVy = mInputY * topSpeed;
                    float accel = Math.min(1.0f, dt * 11.0f);
                    mVelX += (targetVx - mVelX) * accel;
                    mVelY += (targetVy - mVelY) * accel;
                }

                float nx = mPlayerX + mVelX * dt;
                float ny = mPlayerY + mVelY * dt;
                if (!isCliff(nx, mPlayerY)) mPlayerX = nx;
                if (!isCliff(mPlayerX, ny)) mPlayerY = ny;

                float spd = (float) Math.sqrt(mVelX * mVelX + mVelY * mVelY);
                if (spd > 0.25f) {
                    mFacingX = mVelX / spd;
                    mFacingY = mVelY / spd;
                    if (mMounted) {
                        mGaitPhase += dt * (5.2f + spd * 2.1f);
                    } else {
                        mGaitPhase += Math.min(spd, 5.0f) * dt * 6.2831853f / heroCycleDist(spd);
                    }
                } else {
                    mGaitPhase += dt * 1.6f;
                }

                mCamX += (mPlayerX - mCamX) * Math.min(1.0f, dt * 8.0f);
                mCamY += (mPlayerY - mCamY) * Math.min(1.0f, dt * 8.0f);

                // Harvest nearby Flora automatically when walking over
                for (int f = 0; f < NUM_FLORA; f++) {
                    float fdx0 = mFloraX[f] - mPlayerX;
                    float fdy0 = mFloraY[f] - mPlayerY;
                    if (fdx0 * fdx0 + fdy0 * fdy0 > 38.0f * 38.0f) {
                        float[] np = mGen.randomOpenPoint(mRng, mPlayerX + mVelX * 2.0f, mPlayerY + mVelY * 2.0f, 10.0f, 24.0f);
                        if (np != null) {
                            mFloraX[f] = np[0];
                            mFloraY[f] = np[1];
                            mFloraRegrow[f] = 0.0f;
                        }
                    }
                    if (mFloraRegrow[f] > 0.0f) {
                        mFloraRegrow[f] -= dt;
                    } else {
                        float dx = mFloraX[f] - mPlayerX;
                        float dy = mFloraY[f] - mPlayerY;
                        if (dx * dx + dy * dy < 1.05f * 1.05f) {
                            mFloraRegrow[f] = 18.0f;
                            if (mFloraKind[f] == 0) {
                                mHerbMoon++;
                                spawnPopup(mFloraX[f], mFloraY[f] - 0.5f, "+1 Moonpetal", Color.rgb(175, 225, 255));
                            } else if (mFloraKind[f] == 1) {
                                mHerbCinder++;
                                spawnPopup(mFloraX[f], mFloraY[f] - 0.5f, "+1 Cinderbloom", Color.rgb(255, 185, 105));
                            } else {
                                mHerbMoss++;
                                spawnPopup(mFloraX[f], mFloraY[f] - 0.5f, "+1 Ashmoss", Color.rgb(145, 240, 170));
                            }
                            spawnParticles(mFloraX[f], mFloraY[f], 8, Color.rgb(210, 248, 220));
                        }
                    }
                }

                // Update Ambient Fauna (Deer, Rabbits, Birds, River Koi)
                for (int a = 0; a < NUM_FAUNA; a++) {
                    mFaunaPhase[a] += dt * (mFaunaKind[a] == 1 ? 7.5f : 4.2f);
                    float fdx = mFaunaX[a] - mPlayerX;
                    float fdy = mFaunaY[a] - mPlayerY;
                    if (fdx * fdx + fdy * fdy > 34.0f * 34.0f) {
                        float[] np = (mFaunaKind[a] == 3)
                                ? mGen.randomWaterPoint(mRng, mPlayerX, mPlayerY, 6.0f, 24.0f)
                                : mGen.randomOpenPoint(mRng, mPlayerX + mVelX * 2.0f, mPlayerY + mVelY * 2.0f, 10.0f, 22.0f);
                        if (np != null) {
                            mFaunaX[a] = np[0];
                            mFaunaY[a] = np[1];
                        }
                    }
                    if (mFaunaKind[a] == 3) {
                        float nxK = mFaunaX[a] + mFaunaVx[a] * dt;
                        float nyK = mFaunaY[a] + mFaunaVy[a] * dt;
                        if (mGen.waterDepth(nxK, nyK) > 0.06f) {
                            mFaunaX[a] = nxK;
                            mFaunaY[a] = nyK;
                        } else {
                            mFaunaVx[a] = -mFaunaVx[a] + (float) Math.sin(mFaunaPhase[a]) * 0.3f;
                            mFaunaVy[a] = -mFaunaVy[a] + (float) Math.cos(mFaunaPhase[a]) * 0.3f;
                        }
                    } else {
                        float dx = mFaunaX[a] - mPlayerX;
                        float dy = mFaunaY[a] - mPlayerY;
                        float d2 = dx * dx + dy * dy;
                        if (d2 < 3.5f * 3.5f) {
                            float d = (float) Math.sqrt(d2 + 0.001f);
                            float fleeSpd = (mFaunaKind[a] == 2) ? 4.4f : 3.4f;
                            mFaunaVx[a] = (dx / d) * fleeSpd;
                            mFaunaVy[a] = (dy / d) * fleeSpd;
                        } else if (((int) (mTimeSec * 2.0f + a)) % 7 == 0) {
                            mFaunaVx[a] = (float) Math.cos(mTimeSec * 0.8f + a) * 0.65f;
                            mFaunaVy[a] = (float) Math.sin(mTimeSec * 0.7f + a) * 0.65f;
                        }
                        float nxF = mFaunaX[a] + mFaunaVx[a] * dt;
                        float nyF = mFaunaY[a] + mFaunaVy[a] * dt;
                        if (mFaunaKind[a] == 2 || !isCliff(nxF, nyF)) {
                            mFaunaX[a] = nxF;
                            mFaunaY[a] = nyF;
                        } else {
                            mFaunaVx[a] = -mFaunaVx[a];
                            mFaunaVy[a] = -mFaunaVy[a];
                        }
                    }
                }

                // Pick up loot drops
                for (int l = 0; l < MAX_LOOT; l++) {
                    if (mLootActive[l]) {
                        float dx = mLootX[l] - mPlayerX;
                        float dy = mLootY[l] - mPlayerY;
                        if (dx * dx + dy * dy < 1.15f * 1.15f) {
                            mLootActive[l] = false;
                            String[] pool = {
                                    "Pale-Moon Greatsword",
                                    "Wraith-Weave Cloak",
                                    "Crown of the First Kiln",
                                    "Obsidian Courser Barding",
                                    "Starlight Signet Ring"
                            };
                            String item = pool[mLootRarity[l] % pool.length] + " +" + (1 + mLevel / 4);
                            if (mInvCount < mInventory.length) {
                                mInventory[mInvCount++] = item;
                            }
                            mEquippedWeapon = item;
                            showBanner("Equipped: " + item);
                        }
                    }
                }

                // Enemies stay in their spot until player gets close (< 6.2 units)!
                for (int i = 0; i < NUM_ENEMIES; i++) {
                    if (mEnemyHurt[i] > 0.0f) mEnemyHurt[i] -= dt;
                    if (mEnemyAtkCooldown[i] > 0.0f) mEnemyAtkCooldown[i] -= dt;

                    float dx = mPlayerX - mEnemyX[i];
                    float dy = mPlayerY - mEnemyY[i];
                    float dist = (float) Math.sqrt(dx * dx + dy * dy + 0.001f);

                    if (!mEnemyAggro[i] && dist < 6.2f) {
                        mEnemyAggro[i] = true;
                    } else if (mEnemyAggro[i] && dist > 11.5f) {
                        mEnemyAggro[i] = false;
                    }

                    if (!mEnemyAggro[i]) {
                        float hx = mEnemyHomeX[i] - mEnemyX[i];
                        float hy = mEnemyHomeY[i] - mEnemyY[i];
                        float hd = (float) Math.sqrt(hx * hx + hy * hy);
                        if (hd > 0.35f) {
                            mEnemyFacingX[i] = hx / hd;
                            mEnemyFacingY[i] = hy / hd;
                            mEnemyGait[i] += dt * 5.0f;
                            mEnemyX[i] += mEnemyFacingX[i] * 1.15f * dt;
                            mEnemyY[i] += mEnemyFacingY[i] * 1.15f * dt;
                        } else {
                            mEnemyGait[i] += dt * 1.2f;
                        }
                        continue;
                    }

                    mEnemyFacingX[i] = dx / dist;
                    mEnemyFacingY[i] = dy / dist;

                    if (mEnemyAtkWindup[i] > 0.0f) {
                        mEnemyAtkWindup[i] -= dt;
                        if (mEnemyAtkWindup[i] <= 0.0f) {
                            // Execute enemy strike!
                            if (dist < 2.15f && mDodgeTimer <= 0.0f) {
                                int enemyDmg = 18 + mLevel * 2 + (mEnemyKind[i] * 5);
                                mHp -= enemyDmg;
                                mPlayerHurtFlash = 0.22f;
                                spawnParticles(mPlayerX, mPlayerY - 0.2f, 10, Color.rgb(245, 78, 78));
                                spawnPopup(mPlayerX, mPlayerY - 0.9f, "-" + enemyDmg, Color.rgb(255, 88, 88));
                                if (mHp <= 0) {
                                    mHp = mMaxHp;
                                    mPlayerX = mGen.spawnX;
                                    mPlayerY = mGen.spawnY;
                                    showBanner("Revived at Ashveil Meadow");
                                }
                            } else if (dist < 2.15f && mDodgeTimer > 0.0f) {
                                spawnPopup(mPlayerX, mPlayerY - 0.9f, "DODGED!", Color.rgb(150, 245, 230));
                            }
                            mEnemyAtkCooldown[i] = 1.25f;
                        }
                    } else if (dist > 1.45f) {
                        mEnemyGait[i] += dt * 8.5f;
                        float ex = mEnemyX[i] + mEnemyFacingX[i] * 1.95f * dt;
                        float ey = mEnemyY[i] + mEnemyFacingY[i] * 1.95f * dt;
                        if (!isCliff(ex, ey)) {
                            mEnemyX[i] = ex;
                            mEnemyY[i] = ey;
                        }
                    } else if (mEnemyAtkCooldown[i] <= 0.0f) {
                        // Start visible weapon-raise telegraph!
                        mEnemyAtkWindup[i] = 0.42f;
                    }
                }
            }

            // Ambient firefly motes & drifting flower petals
            if (((int) (mTimeSec * 60.0f)) % 8 == 0) {
                float fx = mCamX + ((float) Math.sin(mTimeSec * 3.1f) * 6.5f);
                float fy = mCamY + ((float) Math.cos(mTimeSec * 2.3f) * 4.5f);
                boolean petal = (((int) (mTimeSec * 12.0f)) % 2 == 0);
                spawnParticles(fx, fy, 1, petal ? Color.rgb(245, 240, 215) : Color.rgb(165, 245, 175));
            }

            for (int pIdx = 0; pIdx < MAX_PARTICLES; pIdx++) {
                if (mPartLife[pIdx] > 0.0f) {
                    mPartLife[pIdx] -= dt;
                    mPartX[pIdx] += mPartVx[pIdx] * dt;
                    mPartY[pIdx] += mPartVy[pIdx] * dt;
                }
            }
            for (int k = 0; k < MAX_POPUPS; k++) {
                if (mPopLife[k] > 0.0f) {
                    mPopLife[k] -= dt;
                    mPopY[k] -= 0.9f * dt;
                }
            }

            mCoifRot += dt * 1.15f;
            updateVerletHairAndCloak(dt);
            if (mMounted) {
                rasterizeHorseAndRiderAscii();
            } else {
                rasterizeFootKnightAscii();
            }
        }

        private void updateVerletHairAndCloak(float dt) {
            float windMult = (mWindPreset == 0) ? 0.55f : (mWindPreset == 1 ? 1.0f : 1.75f);
            float windX = (float) Math.sin(mTimeSec * 2.1f) * 4.2f * windMult - mVelX * 0.50f;
            float windY = (float) Math.cos(mTimeSec * 1.6f) * 1.8f * windMult + 1.2f;

            float tailAnchorX = mPlayerX + mTailLocX;
            float tailAnchorY = mPlayerY + mTailLocY;
            stepVerletChain(mTailX, mTailY, mTailPrevX, mTailPrevY, TAIL_STRANDS, TAIL_NODES,
                    tailAnchorX, tailAnchorY, 0.14f, windX, windY, dt, 0.06f);

            float neckX = mPlayerX + mManeLocX;
            float neckY = mPlayerY + mManeLocY;
            stepVerletChain(mManeX, mManeY, mManePrevX, mManePrevY, MANE_STRANDS, MANE_NODES,
                    neckX, neckY, 0.085f, windX * 0.7f, windY * 0.8f, dt, 0.045f);

            // anchors come from the animated rig (set by the rasterizers); foot rig draws hair at +0.52 local offset
            if (mMounted) {
                float spd2 = (float) Math.sqrt(mVelX * mVelX + mVelY * mVelY);
                float fl = (float) Math.sqrt(mFacingX * mFacingX + mFacingY * mFacingY) + 1e-5f;
                float fdx = mFacingX / fl;
                float fdy = mFacingY / fl;
                float airX = -mVelX * 0.55f + windMult * 1.1f + (float) Math.sin(mTimeSec * 0.8f) * 0.8f;
                float airY = -mVelY * 0.35f + (float) Math.cos(mTimeSec * 0.7f) * 0.5f;
                float gallop = Math.min(1.0f, spd2 / 4.6f);
                mTailFx.step(dt, mPlayerX + mTailLocX, mPlayerY + mTailLocY - 0.04f,
                        mPlayerX + mTailLocX - fdx * 0.08f, mPlayerY + mTailLocY + 0.06f,
                        -fdx, -fdy * 0.4f + 0.25f, 8.5f + gallop * 6.0f, 3.2f, airX, airY,
                        2.2f + gallop * 1.6f, 0.48f, mTimeSec);
                mManeFx.step(dt, mPlayerX + mNeckTopLocX, mPlayerY + mNeckTopLocY,
                        mPlayerX + mNeckBaseLocX, mPlayerY + mNeckBaseLocY,
                        -fdx, 0.35f, 7.0f + gallop * 5.0f, 2.8f, airX * 0.85f, airY * 0.85f,
                        1.9f + gallop * 1.4f, 0.36f, mTimeSec);
            }

            float headX = mPlayerX + mHeadLocX;
            float headY = mMounted ? (mPlayerY + mHeadLocY) : (mPlayerY + mHeadLocY - 0.52f);
            stepVerletChain(mHairX, mHairY, mHairPrevX, mHairPrevY, HAIR_STRANDS, HAIR_NODES,
                    headX, headY, mMounted ? 0.10f : 0.13f, windX * 1.2f, windY, dt, 0.032f);
        }

        private void stepVerletChain(
                float[][] x, float[][] y, float[][] px, float[][] py,
                int strands, int nodes, float ax, float ay, float segLen,
                float windX, float windY, float dt, float spread
        ) {
            float dt2 = dt * dt;
            for (int s = 0; s < strands; s++) {
                float sOff = (s - strands * 0.5f) * spread;
                x[s][0] = ax + sOff * 0.35f;
                y[s][0] = ay + Math.abs(sOff) * 0.25f;
                for (int n = 1; n < nodes; n++) {
                    float vx = (x[s][n] - px[s][n]) * 0.91f;
                    float vy = (y[s][n] - py[s][n]) * 0.91f;
                    px[s][n] = x[s][n];
                    py[s][n] = y[s][n];
                    float gust = (float) Math.sin(mTimeSec * 4.2f + s * 0.9f + n * 0.5f) * 0.9f;
                    x[s][n] += vx + (windX + gust) * dt2;
                    y[s][n] += vy + windY * dt2;
                }
                for (int iter = 0; iter < 3; iter++) {
                    x[s][0] = ax + sOff * 0.35f;
                    y[s][0] = ay + Math.abs(sOff) * 0.25f;
                    for (int n = 0; n < nodes - 1; n++) {
                        int j = n + 1;
                        float dx = x[s][j] - x[s][n];
                        float dy = y[s][j] - y[s][n];
                        float dist = (float) Math.sqrt(dx * dx + dy * dy + 1e-6f);
                        float diff = (dist - segLen) / dist;
                        if (n == 0) {
                            x[s][j] -= dx * diff;
                            y[s][j] -= dy * diff;
                        } else {
                            x[s][n] += dx * diff * 0.30f;
                            y[s][n] += dy * diff * 0.30f;
                            x[s][j] -= dx * diff * 0.70f;
                            y[s][j] -= dy * diff * 0.70f;
                        }
                    }
                }
            }
        }

        // =========================================================================
        // ANIMATION HELPERS (shared by hero + horse rigs)
        // =========================================================================
        private static final float DODGE_DUR = 0.28f;
        private float mRotC = 1.0f, mRotS = 0.0f, mRotPx = 0.0f, mRotPy = 0.0f;
        private float mRtx, mRty;          // scratch output of rotPt / legKnee
        private float mFootOff, mFootLift; // scratch output of footCycle
        // Where the rig's head / mane / tail attach, in rig-local coords (verlet chains anchor here)
        private float mHeadLocX = 0.0f, mHeadLocY = -0.65f;
        private float mManeLocX = 0.45f, mManeLocY = -0.65f;
        private float mTailLocX = -0.65f, mTailLocY = -0.10f;

        private static float smooth01(float a, float b, float x) {
            float t = Math.max(0.0f, Math.min(1.0f, (x - a) / (b - a)));
            return t * t * (3.0f - 2.0f * t);
        }

        private static float mixF(float a, float b, float t) {
            return a + (b - a) * t;
        }

        private void rotPt(float x, float y) {
            float dx = x - mRotPx;
            float dy = y - mRotPy;
            float rx = mRotPx + dx * mRotC - dy * mRotS;
            float ry = mRotPy + dx * mRotS + dy * mRotC;
            mRtx = rx;
            mRty = mRotPy + (ry - mRotPy) * mRotSy + mRotDy;
        }

        /** Capsule in hero rig space, rotated by the current roll transform. */
        private void rcapFoot(float ax, float ay, float bx, float by, float r, float lum) {
            rotPt(ax, ay);
            float tax = mRtx;
            float tay = mRty;
            rotPt(bx, by);
            plotCapsuleToBuf(mFootGlyphBuf, mFootLumBuf, mFootColorBuf, FOOT_BUF_W, FOOT_BUF_H,
                    FOOT_BUF_W * 0.5f, FOOT_BUF_H * 0.55f, 20.0f, 20.0f, tax, tay, mRtx, mRty, r, lum);
        }

        private void hcap(float ax, float ay, float bx, float by, float r, float lum) {
            plotCapsuleToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                    HORSE_BUF_W * 0.5f, HORSE_BUF_H * 0.56f,
                    HORSE_BUF_W / HORSE_SPAN_PPU, HORSE_BUF_W / HORSE_SPAN_PPU / HORSE_ROW_ASPECT,
                    ax, ay, bx, by, r, lum);
        }

        /**
         * One leg's foot trajectory over a gait cycle. theta = phase in radians.
         * Stance (foot on ground, sliding back) for 'duty' of the cycle, then a lifted swing forward.
         * Result: mFootOff (-S..S along travel) and mFootLift (height above ground).
         */
        private void footCycle(float theta, float duty, float stride, float liftMax) {
            float u = theta / 6.2831853f;
            u -= (float) Math.floor(u);
            if (u < duty) {
                mFootOff = stride * (1.0f - 2.0f * u / duty);
                mFootLift = 0.0f;
            } else {
                float s = (u - duty) / (1.0f - duty);
                float e = s * s * (3.0f - 2.0f * s);
                mFootOff = -stride + 2.0f * stride * e;
                mFootLift = (float) Math.sin(Math.PI * s) * liftMax;
            }
        }

        /** Two-bone IK. Knee lands in mRtx/mRty. bendSign picks which way (+x / -x) the knee points. */
        private void legKnee(float hx, float hy, float fx, float fy, float l1, float l2,
                             float bendSign, float bendScale) {
            float dx = fx - hx;
            float dy = fy - hy;
            float d = (float) Math.sqrt(dx * dx + dy * dy + 1e-6f);
            float dc = Math.min(d, l1 + l2 - 0.01f);
            float a = (l1 * l1 - l2 * l2 + dc * dc) / (2.0f * dc);
            float h = (float) Math.sqrt(Math.max(0.0f, l1 * l1 - a * a)) * bendScale;
            float ux = dx / d;
            float uy = dy / d;
            float nx = -uy;
            float ny = ux;
            if (nx * bendSign < 0.0f) {
                nx = -nx;
                ny = -ny;
            }
            mRtx = hx + ux * a + nx * h;
            mRty = hy + uy * a + ny * h;
        }

        // =========================================================================
        // HERO: idle breathing / weight shift, planted-foot walk cycle, tuck-and-roll dodge, slash lunge
        // =========================================================================
        // ===== HERO RIG BEGIN =====
        // Human-proportioned foot hero: ~7.7 heads tall, tapered limbs, planted-foot gait (no sliding),
        // layered idle (breathing / weight shift / glances), walk -> run blend, tuck-and-roll dodge, slash.
        private float mFootHeel = 0.0f, mFootPitch = 0.0f;   // scratch output of heroFoot
        private final float[] mHKneeX = new float[2], mHKneeY = new float[2], mHAnkX = new float[2], mHAnkY = new float[2];
        private final float[] mHToeX = new float[2], mHToeY = new float[2], mHHipX = new float[2], mHHipY = new float[2];
        private float mDirX = 0.0f, mDirY = 0.0f;            // scratch output of heroDir
        private float mRotSy = 1.0f, mRotDy = 0.0f;          // dodge squash / hop (applied after the roll)

        private static final int TONE_STEEL = 0, TONE_SKIN = 1, TONE_CLOTH = 2, TONE_LEATHER = 3, TONE_HAIR = 4, TONE_FIRE = 5;
        private static final String HERO_HAIR_GLYPHS = "S8(3)~5s&${}";

        /** Distance covered per full gait cycle (two steps). Used by both the gait clock and the stride. */
        private static float heroCycleDist(float spd) {
            return Math.max(0.55f, Math.min(1.65f, 0.5f + 0.55f * spd));
        }

        /** Direction on screen for an angle measured from body-forward (0) toward down (+PI/2). */
        private void heroDir(float a, float gx, float gy) {
            float c = (float) Math.cos(a);
            mDirX = c * gx;
            mDirY = c * gy + (float) Math.sin(a);
        }

        /** Foot trajectory for one leg: stance slides back at ground speed, swing lifts and rolls through. */
        private void heroFoot(float theta, float duty, float stride, float lift) {
            float u = theta / 6.2831853f;
            u -= (float) Math.floor(u);
            if (u < duty) {
                float q = u / duty;
                mFootOff = stride * (1.0f - 2.0f * q);
                mFootLift = 0.0f;
                mFootHeel = 0.075f * smooth01(0.72f, 1.0f, q);
                mFootPitch = 0.30f * (1.0f - smooth01(0.0f, 0.30f, q)) - 0.55f * smooth01(0.72f, 1.0f, q);
            } else {
                float s = (u - duty) / (1.0f - duty);
                float e = s * s * (3.0f - 2.0f * s);
                mFootOff = -stride + 2.0f * stride * e;
                mFootLift = (float) Math.sin(Math.PI * Math.pow(s, 0.8)) * lift;
                mFootHeel = 0.0f;
                mFootPitch = -0.55f * (1.0f - smooth01(0.0f, 0.35f, s)) + 0.30f * smooth01(0.6f, 1.0f, s);
            }
        }

        /** Two-bone IK where c in [-1,1] scales / mirrors the bend (0 = straight, e.g. walking toward the camera). */
        private void heroKnee(float hx, float hy, float fx, float fy, float l1, float l2, float c) {
            float dx = fx - hx;
            float dy = fy - hy;
            float d = (float) Math.sqrt(dx * dx + dy * dy + 1e-6f);
            float dc = Math.min(d, l1 + l2 - 0.01f);
            float a = (l1 * l1 - l2 * l2 + dc * dc) / (2.0f * dc);
            float h = (float) Math.sqrt(Math.max(0.0f, l1 * l1 - a * a));
            float ux = dx / d;
            float uy = dy / d;
            float nx = -uy;
            float ny = ux;
            if (nx < 0.0f) {
                nx = -nx;
                ny = -ny;
            }
            mRtx = hx + ux * a + nx * h * c;
            mRty = hy + uy * a + ny * h * c;
        }

        /** Capsule in hero rig space, passed through the roll / squash transform, depth-sorted by z. */
        private void hcapH(float ax, float ay, float bx, float by, float r, float lum, float z, float edge, int tone) {
            rotPt(ax, ay);
            float tax = mRtx;
            float tay = mRty;
            rotPt(bx, by);
            plotHeroCap(tax, tay, mRtx, mRty, r, lum, z, edge, tone);
        }

        private void plotHeroCap(float ax, float ay, float bx, float by, float radius, float baseLum,
                                 float z, float edge, int tone) {
            final int bufW = FOOT_BUF_W;
            final int bufH = FOOT_BUF_H;
            final float cx = bufW * 0.5f;
            final float cy = bufH * 0.55f;
            final float sx = HERO_COLS_PER_UNIT;
            final float sy = HERO_ROWS_PER_UNIT;
            int minC = Math.max(0, (int) (cx + (Math.min(ax, bx) - radius) * sx) - 1);
            int maxC = Math.min(bufW - 1, (int) (cx + (Math.max(ax, bx) + radius) * sx) + 1);
            int minR = Math.max(0, (int) (cy + (Math.min(ay, by) - radius) * sy) - 1);
            int maxR = Math.min(bufH - 1, (int) (cy + (Math.max(ay, by) + radius) * sy) + 1);
            float abx = bx - ax;
            float aby = by - ay;
            float ab2 = abx * abx + aby * aby + 1e-6f;
            float r2 = radius * radius;
            for (int r = minR; r <= maxR; r++) {
                float py = (r - cy) / sy;
                for (int c = minC; c <= maxC; c++) {
                    float px = (c - cx) / sx;
                    float t = ((px - ax) * abx + (py - ay) * aby) / ab2;
                    if (t < 0.0f) t = 0.0f;
                    else if (t > 1.0f) t = 1.0f;
                    float dx = px - (ax + t * abx);
                    float dy = py - (ay + t * aby);
                    float d2 = dx * dx + dy * dy;
                    if (d2 > r2) continue;
                    float distNorm = (float) Math.sqrt(d2) / radius;
                    float nz = (float) Math.sqrt(Math.max(0.0f, 1.0f - distNorm * distNorm));
                    float ny = dy / radius;
                    float light = (nz * 0.72f - ny * 0.38f + 0.15f) * baseLum;
                    if (distNorm > 0.80f) light *= edge;
                    int idx = r * bufW + c;
                    if (z > mFootZBuf[idx] || (z == mFootZBuf[idx] && light > mFootLumBuf[idx])) {
                        mFootZBuf[idx] = z;
                        mFootLumBuf[idx] = light;
                        int v = Math.max(52, Math.min(252, (int) (44.0f + light * 235.0f)));
                        if (tone == TONE_HAIR) {
                            // curly / wavy strand glyphs like the reference hair
                            mFootGlyphBuf[idx] = HERO_HAIR_GLYPHS.charAt(((r * 7 + c * 13) & 0x7fffffff) % HERO_HAIR_GLYPHS.length());
                        } else {
                            int rampIdx = Math.max(1, Math.min(DENSE_RAMP.length() - 1, (int) (light * (DENSE_RAMP.length() - 1))));
                            mFootGlyphBuf[idx] = DENSE_RAMP.charAt(rampIdx);
                        }
                        int rr = v, gg = v, bb = v + 6;
                        if (tone == TONE_STEEL) { rr = v + 10; gg = v + 10; bb = v + 16; }                    // bright silver-white
                        else if (tone == TONE_SKIN) { rr = v + 24; gg = v + 8; bb = v - 14; }
                        else if (tone == TONE_CLOTH) { rr = v + 40; gg = v / 4; bb = v / 4; }                // deep crimson coat
                        else if (tone == TONE_LEATHER) { rr = v + 8; gg = v - 4; bb = v - 24; }
                        else if (tone == TONE_HAIR) { rr = v + 12; gg = v + 12; bb = v + 18; }              // white-silver
                        else if (tone == TONE_FIRE) { rr = 255; gg = 150 + v / 3; bb = 40 + v / 8; }        // glowing ember blade
                        mFootColorBuf[idx] = Color.rgb(Math.max(0, Math.min(255, rr)),
                                Math.max(0, Math.min(255, gg)), Math.max(0, Math.min(255, bb)));
                    }
                }
            }
        }

        /** Hair strand segment on the (non-square) hero glyph grid; always sits behind the body. */
        private void plotHeroHair(float ax, float ay, float bx, float by, float radius, float lum) {
            final int bufW = FOOT_BUF_W;
            final int bufH = FOOT_BUF_H;
            final float cx = bufW * 0.5f;
            final float cy = bufH * 0.55f;
            final int radC = Math.max(1, Math.round(radius * HERO_COLS_PER_UNIT));
            final int radR = Math.max(1, Math.round(radius * HERO_ROWS_PER_UNIT));
            for (int i = 0; i <= 4; i++) {
                float tt = i / 4.0f;
                int c0 = Math.round(cx + (ax + (bx - ax) * tt) * HERO_COLS_PER_UNIT);
                int r0 = Math.round(cy + (ay + (by - ay) * tt) * HERO_ROWS_PER_UNIT);
                for (int dr = -radR; dr <= radR; dr++) {
                    for (int dc = -radC; dc <= radC; dc++) {
                        int c = c0 + dc;
                        int r = r0 + dr;
                        if (c < 0 || c >= bufW || r < 0 || r >= bufH) continue;
                        float e = (float) Math.sqrt((dc * dc) / (float) (radC * radC + 0.6f)
                                + (dr * dr) / (float) (radR * radR + 0.6f));
                        float falloff = 1.0f - e;
                        if (falloff <= 0.0f) continue;
                        float l = lum * (0.65f + 0.35f * falloff);
                        int idx = r * bufW + c;
                        if (mFootZBuf[idx] <= -1.0f && l >= mFootLumBuf[idx]) {
                            mFootZBuf[idx] = -1.0f;
                            mFootLumBuf[idx] = l;
                            int rIdx = Math.max(4, Math.min(DENSE_RAMP.length() - 1, (int) (l * (DENSE_RAMP.length() - 1))));
                            mFootGlyphBuf[idx] = DENSE_RAMP.charAt(rIdx);
                            int v = Math.max(95, Math.min(252, (int) (l * 255.0f)));
                            mFootColorBuf[idx] = Color.rgb(v, v, Math.min(255, v + 12));
                        }
                    }
                }
            }
        }

        private void rasterizeFootKnightAscii() {
            final int total = FOOT_BUF_W * FOOT_BUF_H;
            for (int i = 0; i < total; i++) {
                mFootGlyphBuf[i] = ' ';
                mFootLumBuf[i] = -1.0f;
                mFootZBuf[i] = -9.0f;
            }
            final float PI = (float) Math.PI;
            final float t = mTimeSec;
            float dtH = Math.max(0.0f, Math.min(0.05f, t - mHLastT));
            mHLastT = t;

            // ---------- inputs, smoothed so poses blend instead of popping ----------
            float spd = (float) Math.sqrt(mVelX * mVelX + mVelY * mVelY);
            boolean dodging = mDodgeTimer > 0.0f;
            float p = dodging ? Math.max(0.0f, 1.0f - mDodgeTimer / DODGE_DUR) : 0.0f;
            mHWalk += (smooth01(0.15f, 1.5f, spd) - mHWalk) * Math.min(1.0f, dtH * 10.0f);
            mHRun += (smooth01(2.3f, 3.9f, spd) - mHRun) * Math.min(1.0f, dtH * 7.0f);
            final float walk = mHWalk;
            final float idle = 1.0f - walk;
            final float run = mHRun;

            final float fx = mFacingX;
            final float fy = mFacingY;
            float rate = Math.min(1.0f, dtH * 14.0f);
            mHSfx += (fx - mHSfx) * rate;
            mHSfy += (fy - mHSfy) * rate;
            final float sfx = mHSfx;
            final float sfy = mHSfy;
            final float sgn = fx >= 0.0f ? 1.0f : -1.0f;
            final float sgnS = Math.max(-1.0f, Math.min(1.0f, sfx * 4.0f));   // smooth left/right
            final float ay = Math.min(1.0f, Math.abs(sfy));                   // 0 = side view, 1 = front/back
            final float gx = sfx;                                             // body-forward on screen
            final float gy = 0.35f * sfy;
            final float nearOff = mixF(0.45f * sgnS, 1.0f, ay);               // near side of the body (sword side)
            final float farOff = mixF(-0.45f * sgnS, -1.0f, ay);

            final float ph = mGaitPhase;
            final float breath = (float) Math.sin(t * 2.0f);
            final float breathLag = (float) Math.sin(t * 2.0f - 0.7f);
            final float shift = (float) Math.sin(t * 0.62f);                  // slow weight shift
            final float gl = (float) Math.sin(t * 0.41f);
            final float glance = gl > 0.0f ? (float) Math.pow(gl, 6.0) : 0.0f;
            final float look = (float) Math.sin(t * 0.5f);

            // slash
            float slashProg = (mSlashTimer > 0.0f) ? (1.0f - mSlashTimer / 0.26f) : -1.0f;
            float slashE = slashProg >= 0.0f ? slashProg * slashProg * (3.0f - 2.0f * slashProg) : 0.0f;
            float lunge = slashProg >= 0.0f ? (float) Math.sin(Math.PI * slashProg) : 0.0f;
            float wS = slashProg >= 0.0f
                    ? smooth01(0.0f, 0.12f, slashProg) * (1.0f - smooth01(0.82f, 1.0f, slashProg)) : 0.0f;

            // dodge: crouch -> tucked roll -> unfold -> short recovery crouch
            final float k = dodging ? smooth01(0.0f, 0.17f, p) * (1.0f - smooth01(0.78f, 0.97f, p)) : 0.0f;
            if (dodging) mHRec = 1.0f;
            else mHRec = Math.max(0.0f, mHRec - dtH / 0.22f);
            final float rec = dodging ? smooth01(0.80f, 1.0f, p) : smooth01(0.0f, 1.0f, mHRec);
            final float rollAmt = Math.abs(fx) > 0.30f ? 1.0f : 0.0f;         // sideways roll, or a low dive toward/away
            float ang = dodging ? sgn * 2.0f * PI * smooth01(0.10f, 0.92f, p) * rollAmt : 0.0f;
            float hop = dodging ? 0.15f * (float) Math.sin(PI * smooth01(0.06f, 0.94f, p)) : 0.0f;
            mRotC = (float) Math.cos(ang);
            mRotS = (float) Math.sin(ang);
            mRotPx = 0.05f * sgn;
            mRotPy = 0.47f;
            mRotSy = 1.0f - 0.28f * k * (1.0f - rollAmt);
            mRotDy = -hop;

            // ---------- gait ----------
            final float ground = 0.82f;
            float cycle = heroCycleDist(spd);
            float duty = 0.60f - 0.14f * run;                                  // runs get a flight phase
            float stride = 0.5f * duty * cycle * 1.06f;                        // stance travel == ground travel
            float liftMax = 0.07f + 0.09f * run;
            float bobAmp = 0.018f + 0.034f * run;
            float stepBob = bobAmp * walk * (float) Math.cos(2.0f * ph);       // lowest at double support

            float bodyY = stepBob + 0.020f * walk + 0.040f * run
                    + 0.008f * breath * idle + 0.010f * shift * shift * idle
                    + 0.07f * lunge + 0.10f * rec;
            float swayAmp = 0.035f * (0.35f + 0.65f * ay);
            float hipX = 0.022f * shift * idle + swayAmp * (float) Math.cos(ph - 1.9f) * walk;
            float hipY = -0.005f + bodyY;

            // ---------- spine: pelvis -> waist -> chest -> shoulders -> neck -> head ----------
            float lean = sfx * (0.015f + 0.04f * walk + 0.075f * run + 0.11f * lunge + 0.08f * rec);
            float twist = slashProg >= 0.0f ? (slashE - 0.5f) * 0.12f * sgnS : 0.0f;
            float Px = hipX, Py = hipY;
            float Wx = Px + 0.30f * lean + 0.4f * twist, Wy = Py - 0.17f;
            float Cx = Px + 0.65f * lean + 0.8f * twist, Cy = Py - 0.36f - 0.012f * breath * idle;
            float Sx = Px + lean + twist, Sy = Py - 0.50f - 0.012f * breathLag * idle;
            float Nx = Sx + 0.20f * lean, Ny = Sy - 0.06f;
            float Hx = Nx + sfx * 0.035f + 0.012f * look * idle + 0.03f * glance * idle;
            float Hy = Ny - 0.115f - 0.5f * stepBob - 0.004f * breath * idle + 0.02f * rec;
            float Snx = Sx + nearOff * 0.19f, Sny = Sy + 0.02f;
            float Sfx = Sx + farOff * 0.19f, Sfy = Sy + 0.02f;

            // ---------- legs (planted-foot IK) ----------
            final float[] kneeXs = mHKneeX, kneeYs = mHKneeY, ankXs = mHAnkX, ankYs = mHAnkY;
            final float[] toeXs = mHToeX, toeYs = mHToeY, hipXs = mHHipX, hipYs = mHHipY;
            for (int leg = 0; leg < 2; leg++) {
                boolean nl = leg == 0;
                float side = nl ? nearOff : farOff;
                float theta = ph + (nl ? 0.0f : PI);
                heroFoot(theta, duty, stride, liftMax);
                float stance = nl ? (0.10f + 0.20f * lunge) : (-0.08f - 0.12f * lunge);
                float off = mixF(stance, mFootOff + (nl ? 0.10f * lunge : 0.0f), walk);
                float lift = mFootLift * walk;
                float heel = mFootHeel * walk;
                float pitch = mFootPitch * walk;
                float hjx = hipX + side * 0.075f;
                float hjy = hipY + 0.01f;
                float ankX = hipX * 0.4f + side * 0.085f + fx * off;
                float ankY = ground - 0.05f - lift * (1.0f + 0.9f * ay) - heel + fy * off * 0.55f;
                heroKnee(hjx, hjy, ankX, ankY, 0.40f, 0.40f, sgnS);
                float knX = mRtx;
                float knY = mRty - 0.9f * lift * (1.0f - Math.abs(sgnS));
                float toeX = ankX + fx * 0.12f * (float) Math.cos(pitch);
                float toeY = ankY + 0.035f + fy * 0.035f - 0.10f * (float) Math.sin(pitch);
                hipXs[leg] = hjx; hipYs[leg] = hjy;
                kneeXs[leg] = knX; kneeYs[leg] = knY;
                ankXs[leg] = ankX; ankYs[leg] = ankY;
                toeXs[leg] = toeX; toeYs[leg] = toeY;
            }

            // ---------- arms (forward kinematics: upper arm angle a_u, elbow flex beta) ----------
            final float UL = 0.29f, FL = 0.26f;
            float cw = (float) Math.cos(ph - 0.35f);
            // off-hand (far arm): swings with the near leg, elbow folds as speed rises
            float aF = PI * 0.5f - 0.05f + 0.02f * breathLag * idle - (0.28f * walk + 0.50f * run) * cw - 0.5f * rec;
            float bF = 0.12f + 0.02f * breath * idle + 0.15f * walk + (0.90f + 0.25f * cw) * run;
            // sword arm (near): guard that bobs with the stride, raised when running
            float aNidle = 1.22f + 0.02f * breathLag;
            float bNidle = 0.95f + 0.03f * breath;
            float aNmove = 1.05f - 0.08f * cw * walk;
            float bNmove = 1.00f + 0.15f * run;
            float aN = mixF(aNidle, aNmove, walk);
            float bN = mixF(bNidle, bNmove, walk);
            float sRelIdle = 0.45f + 0.04f * (float) Math.sin(t * 1.1f);
            float sRelMove = 0.15f - 0.50f * run;
            float aNf = aN - bN;
            float aS = aNf + mixF(sRelIdle, sRelMove, walk);
            if (wS > 0.0f) {
                float aSs = -1.7f + 3.5f * slashE;
                float aFs = aSs - 0.10f;
                float bs = 0.10f + 0.45f * (1.0f - (float) Math.sin(PI * slashProg));
                aN = mixF(aN, aFs + bs, wS);
                bN = mixF(bN, bs, wS);
                aS = mixF(aS, aSs, wS);
            }
            // far arm joints
            heroDir(aF, gx, gy);
            float fEx = Sfx + UL * mDirX, fEy = Sfy + UL * mDirY;
            heroDir(aF - bF, gx, gy);
            float fWx = fEx + FL * mDirX, fWy = fEy + FL * mDirY;
            float fHx = fWx + 0.05f * mDirX, fHy = fWy + 0.05f * mDirY;
            // near (sword) arm joints
            heroDir(aN, gx, gy);
            float nEx = Snx + UL * mDirX, nEy = Sny + UL * mDirY;
            heroDir(aN - bN, gx, gy);
            float nWx = nEx + FL * mDirX, nWy = nEy + FL * mDirY;
            float nHx = nWx + 0.05f * mDirX, nHy = nWy + 0.05f * mDirY;
            heroDir(aS, gx, gy);
            float bdx = mDirX, bdy = mDirY;
            float bladeLen = 0.52f;
            float tipX = nHx + bdx * bladeLen, tipY = nHy + bdy * bladeLen;

            // ---------- dodge tuck: blend every joint toward a curled ball ----------
            if (k > 0.0f) {
                Px = mixF(Px, -0.16f * sgn, k);  Py = mixF(Py, 0.62f, k);
                Wx = mixF(Wx, -0.24f * sgn, k);  Wy = mixF(Wy, 0.46f, k);
                Cx = mixF(Cx, -0.14f * sgn, k);  Cy = mixF(Cy, 0.26f, k);
                Sx = mixF(Sx, 0.04f * sgn, k);   Sy = mixF(Sy, 0.20f, k);
                Nx = mixF(Nx, 0.16f * sgn, k);   Ny = mixF(Ny, 0.27f, k);
                Hx = mixF(Hx, 0.26f * sgn, k);   Hy = mixF(Hy, 0.42f, k);
                Snx = mixF(Snx, 0.06f * sgn, k); Sny = mixF(Sny, 0.24f, k);
                Sfx = mixF(Sfx, 0.00f * sgn, k); Sfy = mixF(Sfy, 0.24f, k);
                float[] tkx = {0.24f, 0.20f}, tky = {0.50f, 0.44f};
                float[] tax = {-0.02f, 0.02f}, tay = {0.70f, 0.66f};
                for (int leg = 0; leg < 2; leg++) {
                    hipXs[leg] = mixF(hipXs[leg], Px + 0.04f * sgn * (leg == 0 ? 1 : -1), k);
                    hipYs[leg] = mixF(hipYs[leg], Py, k);
                    kneeXs[leg] = mixF(kneeXs[leg], tkx[leg] * sgn, k);
                    kneeYs[leg] = mixF(kneeYs[leg], tky[leg], k);
                    ankXs[leg] = mixF(ankXs[leg], tax[leg] * sgn, k);
                    ankYs[leg] = mixF(ankYs[leg], tay[leg], k);
                    toeXs[leg] = mixF(toeXs[leg], (tax[leg] + 0.10f) * sgn, k);
                    toeYs[leg] = mixF(toeYs[leg], tay[leg] + 0.02f, k);
                }
                nEx = mixF(nEx, 0.18f * sgn, k); nEy = mixF(nEy, 0.40f, k);
                nWx = mixF(nWx, 0.26f * sgn, k); nWy = mixF(nWy, 0.54f, k);
                nHx = mixF(nHx, 0.24f * sgn, k); nHy = mixF(nHy, 0.58f, k);
                fEx = mixF(fEx, 0.10f * sgn, k); fEy = mixF(fEy, 0.38f, k);
                fWx = mixF(fWx, 0.22f * sgn, k); fWy = mixF(fWy, 0.56f, k);
                fHx = mixF(fHx, 0.22f * sgn, k); fHy = mixF(fHy, 0.62f, k);
                tipX = mixF(tipX, nHx - 0.50f * sgn, k);
                tipY = mixF(tipY, nHy - 0.26f, k);
            }

            // ---------- 1. silver hair / cape (world space strands, always behind the body) ----------
            for (int hs = 0; hs < HAIR_STRANDS; hs++) {
                float lumBase = 0.76f + (hs % 3) * 0.07f;
                for (int hn = 0; hn < HAIR_NODES - 1; hn++) {
                    plotHeroHair(mHairX[hs][hn] - mPlayerX, mHairY[hs][hn] - mPlayerY + 0.52f,
                            mHairX[hs][hn + 1] - mPlayerX, mHairY[hs][hn + 1] - mPlayerY + 0.52f,
                            0.060f, lumBase - hn * 0.05f);
                }
            }

            // ---------- 2. legs ----------
            for (int leg = 0; leg < 2; leg++) {
                boolean nl = leg == 0;
                float z = nl ? 0.70f : 0.12f;
                float lm = nl ? 1.0f : 0.78f;
                hcapH(hipXs[leg], hipYs[leg], kneeXs[leg], kneeYs[leg], 0.085f, 0.66f * lm, z, 0.35f, TONE_CLOTH);          // thigh
                float cmx = mixF(kneeXs[leg], ankXs[leg], 0.28f), cmy = mixF(kneeYs[leg], ankYs[leg], 0.28f);
                hcapH(kneeXs[leg], kneeYs[leg], ankXs[leg], ankYs[leg], 0.058f, 0.62f * lm, z, 0.35f, TONE_CLOTH);        // shin
                hcapH(kneeXs[leg], kneeYs[leg], cmx, cmy, 0.068f, 0.66f * lm, z, 0.45f, TONE_CLOTH);                        // calf
                float bkx = mixF(ankXs[leg], kneeXs[leg], 0.30f), bky = mixF(ankYs[leg], kneeYs[leg], 0.30f);
                hcapH(bkx, bky, ankXs[leg], ankYs[leg], 0.062f, 0.60f * lm, z + 0.01f, 0.45f, TONE_STEEL);               // boot shaft
                hcapH(ankXs[leg] - fx * 0.02f, ankYs[leg] + 0.01f, toeXs[leg], toeYs[leg], 0.052f, 0.58f * lm, z + 0.02f, 0.45f, TONE_STEEL);  // foot
            }

            // ---------- 3. torso ----------
            float tw = mixF(0.122f, 0.160f, ay);
            float hw = 0.03f + 0.035f * ay;
            hcapH(Px - hw, Py + 0.005f, Px + hw, Py + 0.005f, 0.105f + 0.02f * ay, 0.72f, 0.50f, 0.55f, TONE_CLOTH);   // pelvis / tunic hem
            hcapH(Px, Py - 0.02f, Wx, Wy, 0.112f + 0.018f * ay, 0.80f, 0.51f, 0.55f, TONE_CLOTH);                      // abdomen
            hcapH(Wx, Wy, Cx, Cy, 0.118f + 0.022f * ay, 0.86f, 0.52f, 0.55f, TONE_CLOTH);                              // lower chest
            hcapH(Cx, Cy, Sx, Sy + 0.03f, tw, 0.90f, 0.53f, 0.55f, TONE_CLOTH);                                         // chest
            hcapH(Wx - 0.05f - 0.04f * ay, Wy + 0.015f, Wx + 0.05f + 0.04f * ay, Wy + 0.015f, 0.036f, 0.95f, 0.56f, 0.6f, TONE_LEATHER); // belt
            hcapH(Snx, Sny, Sfx, Sfy, 0.074f, 0.92f, 0.55f, 0.55f, TONE_STEEL);                                        // shoulders (white pauldrons)
            hcapH(Nx, Ny + 0.02f, Hx, Hy + 0.085f, 0.042f, 0.78f, 0.60f, 0.55f, TONE_SKIN);                             // neck

            // ---------- 4. head ----------
            hcapH(Hx, Hy - 0.005f, Hx + gx * 0.012f, Hy + 0.04f, 0.092f, 0.88f, 0.85f, 0.55f, TONE_SKIN);              // face
            hcapH(Hx - sgnS * 0.035f, Hy - 0.080f, Hx - sgnS * 0.05f, Hy - 0.020f, 0.095f, 1.0f, 0.90f, 0.7f, TONE_HAIR); // hair
            hcapH(Hx - sgnS * 0.06f, Hy, Hx - sgnS * 0.08f, Hy + 0.15f, 0.072f, 0.95f, 0.75f, 0.7f, TONE_HAIR);        // back hair
            if (sfy < -0.30f) {
                hcapH(Hx, Hy - 0.005f, Hx, Hy + 0.03f, 0.096f, 1.0f, 0.95f, 0.7f, TONE_HAIR);                          // seen from behind
            } else {
                hcapH(Hx + sgnS * 0.090f, Hy + 0.012f, Hx + sgnS * 0.096f, Hy + 0.028f, 0.036f, 0.90f, 0.88f, 0.8f, TONE_SKIN); // nose
            }

            // ---------- 5. arms + sword ----------
            hcapH(Sfx, Sfy, fEx, fEy, 0.052f, 0.70f, 0.15f, 0.35f, TONE_CLOTH);
            hcapH(fEx, fEy, fWx, fWy, 0.044f, 0.70f, 0.16f, 0.35f, TONE_SKIN);
            hcapH(fWx, fWy, fHx, fHy, 0.042f, 0.72f, 0.17f, 0.45f, TONE_SKIN);
            hcapH(Snx, Sny, nEx, nEy, 0.056f, 0.90f, 0.80f, 0.35f, TONE_CLOTH);
            hcapH(nEx, nEy, nWx, nWy, 0.046f, 0.90f, 0.81f, 0.35f, TONE_SKIN);
            hcapH(nWx, nWy, nHx, nHy, 0.044f, 0.92f, 0.82f, 0.45f, TONE_SKIN);
            float gdx = nHx + bdx * 0.07f, gdy = nHy + bdy * 0.07f;
            heroDir(aS + PI * 0.5f, gx, gy);
            hcapH(gdx - mDirX * 0.07f, gdy - mDirY * 0.07f, gdx + mDirX * 0.07f, gdy + mDirY * 0.07f, 0.036f, 0.95f, 0.96f, 0.6f, TONE_STEEL);
            hcapH(nHx - bdx * 0.05f, nHy - bdy * 0.05f, nHx, nHy, 0.038f, 0.95f, 0.95f, 0.6f, TONE_STEEL);              // pommel
            hcapH(nHx + bdx * 0.08f, nHy + bdy * 0.08f, tipX, tipY, 0.040f, 1.0f, 0.97f, 0.7f, TONE_FIRE);            // blade (ember glow)

            // hair / cape anchor follows the (possibly rolling) back of the head
            rotPt(Hx - sgnS * 0.08f, Hy - 0.01f);
            mHeadLocX = mRtx;
            mHeadLocY = mRty;
        }
        // ===== HERO RIG END =====

        private void rasterizeEnemyHumanoidAscii(int eIdx) {
            int total = ENEMY_BUF_W * ENEMY_BUF_H;
            for (int i = 0; i < total; i++) {
                mEnemyGlyphBuf[i] = ' ';
                mEnemyLumBuf[i] = -1.0f;
            }

            float sx = 18.0f;
            float sy = 18.0f;
            float cx = ENEMY_BUF_W * 0.5f;
            float cy = ENEMY_BUF_H * 0.55f;

            float g = mEnemyGait[eIdx];
            boolean moving = mEnemyAggro[eIdx] && (mEnemyAtkWindup[eIdx] <= 0.0f);
            float bob = moving ? (float) Math.abs(Math.sin(g)) * 0.07f : (float) Math.sin(g) * 0.025f;
            float fx = mEnemyFacingX[eIdx];
            float fy = mEnemyFacingY[eIdx];

            for (int leg = 0; leg < 2; leg++) {
                float ph = g + (leg == 1 ? (float) Math.PI : 0.0f);
                float side = (leg == 0 ? -0.14f : 0.14f);
                float st = moving ? (float) Math.sin(ph) * 0.28f : 0.0f;
                float lift = moving ? Math.max(0.0f, (float) Math.cos(ph)) * 0.15f : 0.0f;
                plotCapsuleToBuf(mEnemyGlyphBuf, mEnemyLumBuf, mEnemyColorBuf, ENEMY_BUF_W, ENEMY_BUF_H,
                        cx, cy, sx, sy, side, 0.14f - bob, side + st, 0.70f - lift, 0.085f, 0.70f);
            }

            plotCapsuleToBuf(mEnemyGlyphBuf, mEnemyLumBuf, mEnemyColorBuf, ENEMY_BUF_W, ENEMY_BUF_H,
                    cx, cy, sx, sy, 0.0f, 0.12f - bob, fx * 0.08f, -0.32f - bob, 0.18f, 0.82f);
            plotCapsuleToBuf(mEnemyGlyphBuf, mEnemyLumBuf, mEnemyColorBuf, ENEMY_BUF_W, ENEMY_BUF_H,
                    cx, cy, sx, sy, -0.20f, -0.28f - bob, 0.20f, -0.28f - bob, 0.10f, 0.88f);
            plotCapsuleToBuf(mEnemyGlyphBuf, mEnemyLumBuf, mEnemyColorBuf, ENEMY_BUF_W, ENEMY_BUF_H,
                    cx, cy, sx, sy, fx * 0.08f, -0.50f - bob, fx * 0.08f, -0.64f - bob, 0.12f, 0.94f);

            // Weapon arm raises high during windup telegraph!
            float windupRaise = (mEnemyAtkWindup[eIdx] > 0.0f) ? -1.45f * (mEnemyAtkWindup[eIdx] / 0.42f) : 0.25f;
            float wAng = (float) Math.atan2(fy, fx) + windupRaise;
            float hx = 0.20f + (float) Math.cos(wAng) * 0.24f;
            float hy = -0.26f - bob + (float) Math.sin(wAng) * 0.24f;
            float tx = hx + (float) Math.cos(wAng) * 0.58f;
            float ty = hy + (float) Math.sin(wAng) * 0.58f;
            plotCapsuleToBuf(mEnemyGlyphBuf, mEnemyLumBuf, mEnemyColorBuf, ENEMY_BUF_W, ENEMY_BUF_H,
                    cx, cy, sx, sy, 0.20f, -0.26f - bob, hx, hy, 0.075f, 0.78f);
            plotCapsuleToBuf(mEnemyGlyphBuf, mEnemyLumBuf, mEnemyColorBuf, ENEMY_BUF_W, ENEMY_BUF_H,
                    cx, cy, sx, sy, hx, hy, tx, ty, 0.048f, 0.98f);
        }

        // =========================================================================
        // HORSE + RIDER: 4-beat walk -> gallop blend, idle breathing / grazing / pawing / ear flicks,
        // leaping dodge with stretched legs and a flattened rider
        // =========================================================================
        private void rasterizeHorseAndRiderAscii() {
            for (int i = 0; i < HORSE_BUF_W * HORSE_BUF_H; i++) {
                mHorseGlyphBuf[i] = ' ';
                mHorseLumBuf[i] = -1.0f;
            }

            final float cx = HORSE_BUF_W * 0.5f;
            final float cy = HORSE_BUF_H * 0.56f;
            final float scaleX = HORSE_BUF_W / HORSE_SPAN_PPU;
            final float scaleY = scaleX / HORSE_ROW_ASPECT;
            final float t = mTimeSec;

            float fx = mFacingX;
            float fy = mFacingY;
            float sgn = fx >= 0.0f ? 1.0f : -1.0f;
            float spd = (float) Math.sqrt(mVelX * mVelX + mVelY * mVelY);
            float sf = Math.min(1.0f, spd / 4.6f);
            float g = smooth01(0.40f, 0.82f, sf);        // 0 = walk, 1 = gallop
            float mv = Math.min(1.0f, spd / 1.4f);       // 0 = standing
            float ph = mGaitPhase;

            boolean dodging = mDodgeTimer > 0.0f;
            float p = dodging ? Math.max(0.0f, 1.0f - mDodgeTimer / DODGE_DUR) : 0.0f;
            float k = dodging ? smooth01(0.05f, 0.20f, p) * (1.0f - smooth01(0.82f, 0.97f, p)) : 0.0f;
            float leap = dodging ? (float) Math.sin(Math.PI * p) * 0.30f : 0.0f;

            // ---- body motion ----
            float bob = 0.035f * mv * (1.0f - g) * (float) Math.cos(2.0f * ph)
                    + 0.070f * mv * g * (float) Math.cos(ph + 0.6f);
            float pitch = (float) Math.sin(ph) * 0.07f * g * mv;
            float breathe = (float) Math.sin(t * 1.8f) * 0.012f * (1.0f - mv);
            float bodyOff = bob + breathe - leap;

            float rearX = -fx * 0.56f;
            float rearY = -fy * 0.22f - 0.05f + bodyOff + pitch;
            float frontX = fx * (0.52f + 0.08f * k);
            float frontY = fy * 0.22f - 0.08f + bodyOff - pitch - 0.05f * k;

            // ---- legs ----
            final float ground = 0.98f;
            float[] legHipOff = {-0.58f, 0.52f, -0.46f, 0.62f};   // 0 hind far, 1 front far, 2 hind near, 3 front near
            float[] legBright = {0.42f, 0.45f, 0.72f, 0.76f};
            float[] walkFrac = {0.50f, 0.75f, 0.00f, 0.25f};      // 4-beat lateral walk
            float[] gallopFrac = {0.00f, 0.50f, 0.12f, 0.62f};    // hinds together, then fronts together
            float strideS = (0.18f + 0.22f * g) * mv;
            float liftL = (0.13f + 0.13f * g) * mv;
            float duty = mixF(0.62f, 0.38f, g);
            float bendScale = 0.5f + 0.5f * Math.min(1.0f, Math.abs(fx) * 1.4f);

            float pawT = t % 8.0f;
            float paw = 0.0f;
            if (mv < 0.15f && pawT < 1.6f) {
                paw = Math.max(0.0f, (float) Math.sin(pawT * 10.0f)) * 0.18f * (float) Math.sin(Math.PI * pawT / 1.6f);
            }

            for (int leg = 0; leg < 4; leg++) {
                boolean front = (leg & 1) == 1;
                float frac = mixF(walkFrac[leg], gallopFrac[leg], g);
                footCycle(ph + frac * 6.2831853f, duty, strideS, liftL);
                float off = mFootOff;
                float lift = mFootLift;

                float hipX = fx * legHipOff[leg];
                float hipY = fy * legHipOff[leg] * 0.35f + 0.08f + bodyOff + (front ? -pitch : pitch);
                float footX = hipX + fx * off;
                float footY = ground + fy * off * 0.35f - lift;
                if (leg == 3) footY -= paw;
                if (k > 0.0f) {
                    float sx = front ? 0.52f * sgn : -0.50f * sgn;
                    footX = mixF(footX, hipX + sx, k);
                    footY = mixF(footY, hipY + (front ? 0.50f : 0.46f), k);
                }
                legKnee(hipX, hipY, footX, footY, 0.47f, 0.49f, front ? sgn : -sgn, bendScale);
                float kneeX = mRtx;
                float kneeY = mRty;

                hcap(hipX, hipY, kneeX, kneeY, 0.085f, legBright[leg]);
                hcap(kneeX, kneeY, footX, footY, 0.060f, legBright[leg] * 0.9f);
                hcap(footX, footY, footX + sgn * 0.04f, footY + 0.03f, 0.060f, legBright[leg] * 0.6f); // hoof
            }

            // ---- barrel + haunch ----
            hcap(rearX, rearY, frontX, frontY, 0.31f, 0.88f);
            hcap(rearX, rearY - 0.06f, rearX * 0.5f, rearY - 0.08f, 0.24f, 0.96f);

            // ---- neck + head: nods with the gait, grazes when idle, stretches out in the dodge ----
            float nod = (float) Math.sin(ph - 0.8f) * 0.07f * (0.3f + 0.7f * mv) * mv;
            float dipEnv = Math.max(0.0f, (float) Math.sin(t * 0.45f));
            float dip = dipEnv * dipEnv * 0.30f * (1.0f - mv);
            float neckTopX = frontX + fx * (0.42f + 0.10f * g + 0.12f * k - dip * 0.4f);
            float neckTopY = frontY - 0.52f + 0.16f * g + nod + dip + 0.20f * k;
            hcap(frontX, frontY - 0.05f, neckTopX, neckTopY, 0.22f, 0.92f);

            float muzzleX = neckTopX + fx * 0.38f;
            float muzzleY = neckTopY + 0.14f + 0.10f * g + dip * 0.35f;
            hcap(neckTopX, neckTopY, muzzleX, muzzleY, 0.14f, 0.95f);

            float earPhase = t % 3.7f;
            float flick = earPhase < 0.25f ? (float) Math.sin(earPhase * 25.0f) * 0.05f : 0.0f;
            hcap(neckTopX - fx * 0.05f, neckTopY - 0.08f, neckTopX - fx * 0.02f + flick, neckTopY - 0.24f, 0.06f, 0.98f);

            // ---- rider: human proportions, seated; bounces with a lag, leans into speed, flattens in the dodge ----
            float saddleX = -fx * 0.06f;
            float saddleY = -0.30f + bodyOff * 0.9f;
            float lean = sgn * (0.04f * sf + 0.26f * k);
            float spring = bob * 0.5f;                                  // spine absorbs the gait
            float rPx = saddleX, rPy = saddleY + 0.02f;
            float rWx = rPx + lean * 0.30f, rWy = rPy - 0.17f + spring * 0.3f;
            float rCx = rPx + lean * 0.65f, rCy = rPy - 0.36f + spring * 0.6f - 0.010f * breathe * 20.0f;
            float rSx = rPx + lean, rSy = rPy - 0.50f + spring + 0.10f * k;
            float rNx = rSx + lean * 0.2f + fx * 0.01f, rNy = rSy - 0.06f;
            float rHx = rNx + fx * 0.035f + (float) Math.sin(t * 0.5f) * 0.012f * (1.0f - mv);
            float rHy = rNy - 0.115f - spring * 0.5f + 0.02f * k;

            // thighs + shins (near leg bright over the flank, far leg hidden behind the barrel)
            float kneeRx = rPx + fx * 0.26f, kneeRy = rPy + 0.20f + 0.02f * (float) Math.sin(ph) * mv;
            float stirX = kneeRx - fx * 0.02f, stirY = kneeRy + 0.34f + 0.015f * (float) Math.sin(ph + 1.0f) * mv;
            hcap(rPx, rPy + 0.02f, kneeRx, kneeRy, 0.090f, 1.0f);
            hcap(kneeRx, kneeRy, stirX, stirY, 0.062f, 0.98f);
            hcap(stirX - fx * 0.02f, stirY, stirX + fx * 0.09f, stirY + 0.03f, 0.052f, 0.95f);   // boot in the stirrup

            // torso
            hcap(rPx - sgn * 0.02f, rPy, rWx, rWy, 0.108f, 0.72f);                                  // pelvis / tunic
            hcap(rWx, rWy, rCx, rCy, 0.118f, 0.78f);                                                 // abdomen
            hcap(rCx, rCy, rSx, rSy + 0.03f, 0.128f, 0.84f);                                         // chest
            hcap(rWx - 0.05f, rWy + 0.015f, rWx + 0.05f, rWy + 0.015f, 0.036f, 0.98f);               // belt
            hcap(rSx - 0.07f, rSy + 0.02f, rSx + 0.07f, rSy + 0.02f, 0.060f, 0.86f);                 // shoulders
            hcap(rNx, rNy + 0.02f, rHx, rHy + 0.085f, 0.042f, 0.76f);                                // neck
            hcap(rHx, rHy - 0.005f, rHx + fx * 0.012f, rHy + 0.04f, 0.092f, 0.88f);                  // face
            hcap(rHx - sgn * 0.035f, rHy - 0.080f, rHx - sgn * 0.05f, rHy - 0.020f, 0.095f, 1.0f);   // silver hair
            hcap(rHx - sgn * 0.06f, rHy, rHx - sgn * 0.07f, rHy + 0.06f, 0.060f, 0.95f);             // back hair
            hcap(rHx + sgn * 0.090f, rHy + 0.012f, rHx + sgn * 0.096f, rHy + 0.028f, 0.036f, 0.90f); // nose

            // reins hand (far arm) follows the horse's head nod
            float rSnx = rSx + sgn * 0.06f, rSny = rSy + 0.02f;
            float rSfx = rSx - sgn * 0.06f, rSfy = rSy + 0.02f;
            float rnHx = rSfx + fx * 0.36f, rnHy = rSfy + 0.30f + nod * 0.6f;
            legKnee(rSfx, rSfy, rnHx, rnHy, 0.29f, 0.26f, -sgn, 1.0f);
            float rnEx = mRtx, rnEy = mRty;
            hcap(rSfx, rSfy, rnEx, rnEy, 0.050f, 0.78f);
            hcap(rnEx, rnEy, rnHx, rnHy, 0.042f, 0.80f);
            // sword arm: ready guard, sweeps through the slash
            float slashProgR = (mSlashTimer > 0.0f) ? (1.0f - mSlashTimer / 0.26f) : -1.0f;
            float slashER = slashProgR >= 0.0f ? slashProgR * slashProgR * (3.0f - 2.0f * slashProgR) : 0.0f;
            float wSR = slashProgR >= 0.0f
                    ? smooth01(0.0f, 0.12f, slashProgR) * (1.0f - smooth01(0.82f, 1.0f, slashProgR)) : 0.0f;
            float aBlade = mixF(-1.05f + 0.05f * (float) Math.sin(t * 1.1f), -1.7f + 3.5f * slashER, wSR);
            float gdx = fx, gdy = 0.35f * fy;
            float bx0 = (float) Math.cos(aBlade) * gdx, by0 = (float) Math.cos(aBlade) * gdy + (float) Math.sin(aBlade);
            float rhx = mixF(rSnx + fx * 0.30f, rSnx + bx0 * 0.45f, wSR);
            float rhy = mixF(rSny + 0.16f + nod * 0.3f, rSny + by0 * 0.45f, wSR);
            legKnee(rSnx, rSny, rhx, rhy, 0.29f, 0.26f, -sgn, 1.0f);
            hcap(rSnx, rSny, mRtx, mRty, 0.054f, 0.92f);
            hcap(mRtx, mRty, rhx, rhy, 0.044f, 0.94f);
            hcap(rhx, rhy, rhx + bx0 * 0.50f, rhy + by0 * 0.50f, 0.040f, 1.0f);                     // blade

            // ---- mane / tail / hair anchors follow the animated body ----
            mTailLocX = rearX * 1.1f;
            mTailLocY = rearY - 0.05f;
            mManeLocX = (frontX + neckTopX) * 0.5f;
            mManeLocY = (frontY + neckTopY) * 0.5f - 0.05f;
            mHeadLocX = rHx - sgn * 0.08f;
            mHeadLocY = rHy - 0.01f;
            mNeckBaseLocX = frontX - fx * 0.02f;
            mNeckBaseLocY = frontY - 0.12f;
            mNeckTopLocX = neckTopX - fx * 0.06f;
            mNeckTopLocY = neckTopY - 0.04f;

            // tail + mane are no longer plotted as glyphs: HairFx draws them as soft strands over the body
            for (int hs = 0; hs < HAIR_STRANDS; hs++) {
                for (int hn = 0; hn < HAIR_NODES - 1; hn++) {
                    plotHairToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                            cx, cy, scaleX, scaleY,
                            mHairX[hs][hn] - mPlayerX, mHairY[hs][hn] - mPlayerY,
                            mHairX[hs][hn + 1] - mPlayerX, mHairY[hs][hn + 1] - mPlayerY,
                            0.070f, 0.96f - hn * 0.04f);
                }
            }
        }

        private void plotCapsuleToBuf(
                char[] gBuf, float[] lBuf, int[] cBuf, int bufW, int bufH,
                float cx, float cy, float sx, float sy,
                float ax, float ay, float bx, float by,
                float radius, float baseLum
        ) {
            int minC = Math.max(0, (int) (cx + (Math.min(ax, bx) - radius) * sx) - 1);
            int maxC = Math.min(bufW - 1, (int) (cx + (Math.max(ax, bx) + radius) * sx) + 1);
            int minR = Math.max(0, (int) (cy + (Math.min(ay, by) - radius) * sy) - 1);
            int maxR = Math.min(bufH - 1, (int) (cy + (Math.max(ay, by) + radius) * sy) + 1);

            float abx = bx - ax;
            float aby = by - ay;
            float ab2 = abx * abx + aby * aby + 1e-6f;
            float r2 = radius * radius;

            for (int r = minR; r <= maxR; r++) {
                float py = (r - cy) / sy;
                for (int c = minC; c <= maxC; c++) {
                    float px = (c - cx) / sx;
                    float t = ((px - ax) * abx + (py - ay) * aby) / ab2;
                    if (t < 0.0f) t = 0.0f;
                    else if (t > 1.0f) t = 1.0f;
                    float qx = ax + t * abx;
                    float qy = ay + t * aby;
                    float dx = px - qx;
                    float dy = py - qy;
                    float d2 = dx * dx + dy * dy;
                    if (d2 <= r2) {
                        float distNorm = (float) Math.sqrt(d2) / radius;
                        float nz = (float) Math.sqrt(Math.max(0.0f, 1.0f - distNorm * distNorm));
                        float ny = dy / radius;
                        float light = (nz * 0.72f - ny * 0.38f + 0.15f) * baseLum;
                        if (distNorm > 0.80f) light *= 0.25f;
                        int idx = r * bufW + c;
                        if (light > lBuf[idx]) {
                            lBuf[idx] = light;
                            int rampIdx = Math.max(1, Math.min(DENSE_RAMP.length() - 1, (int) (light * (DENSE_RAMP.length() - 1))));
                            gBuf[idx] = DENSE_RAMP.charAt(rampIdx);
                            int v = Math.max(52, Math.min(252, (int) (44.0f + light * 235.0f)));
                            cBuf[idx] = Color.rgb(v, v, Math.min(255, v + 6));
                        }
                    }
                }
            }
        }

        private void plotHairToBuf(
                char[] gBuf, float[] lBuf, int[] cBuf, int bufW, int bufH,
                float cx, float cy, float sx, float sy,
                float ax, float ay, float bx, float by,
                float radius, float lum
        ) {
            int steps = 4;
            for (int i = 0; i <= steps; i++) {
                float t = i / (float) steps;
                float px = ax + (bx - ax) * t;
                float py = ay + (by - ay) * t;
                int c0 = Math.round(cx + px * sx);
                int r0 = Math.round(cy + py * sy);
                int radCells = Math.max(1, Math.round(radius * sx));
                for (int dr = -radCells; dr <= radCells; dr++) {
                    for (int dc = -radCells; dc <= radCells; dc++) {
                        int c = c0 + dc;
                        int r = r0 + dr;
                        if (c >= 0 && c < bufW && r >= 0 && r < bufH) {
                            float falloff = 1.0f - ((float) Math.sqrt(dc * dc + dr * dr) / (radCells + 0.6f));
                            if (falloff > 0.0f) {
                                float l = lum * (0.65f + 0.35f * falloff);
                                int idx = r * bufW + c;
                                if (l >= lBuf[idx]) {
                                    lBuf[idx] = l;
                                    int rIdx = Math.max(4, Math.min(DENSE_RAMP.length() - 1, (int) (l * (DENSE_RAMP.length() - 1))));
                                    gBuf[idx] = DENSE_RAMP.charAt(rIdx);
                                    int v = Math.max(95, Math.min(252, (int) (l * 255.0f)));
                                    cBuf[idx] = Color.rgb(v, v, Math.min(255, v + 5));
                                }
                            }
                        }
                    }
                }
            }
        }

        private Bitmap getOrBuildChunk(int cxIdx, int cyIdx, int[] builtThisFrame) {
            int key = ((cxIdx & 0xFFFF) << 16) | (cyIdx & 0xFFFF);
            int lruIdx = 0;
            int minAge = Integer.MAX_VALUE;
            for (int i = 0; i < CHUNK_CACHE_CAP; i++) {
                if (mChunkKeys[i] == key && mChunkBitmaps[i] != null) {
                    mChunkAge[i] = ++mChunkTick;
                    return mChunkBitmaps[i];
                }
                if (mChunkBitmaps[i] == null) {
                    lruIdx = i;
                    minAge = -1;
                } else if (minAge != -1 && mChunkAge[i] < minAge) {
                    minAge = mChunkAge[i];
                    lruIdx = i;
                }
            }

            // Always build one chunk per frame; build more only while the frame is still cheap.
            if (builtThisFrame[0] >= 1 && System.nanoTime() > mFrameStartNs + 9_000_000L) {
                return null;
            }
            if (builtThisFrame[0] >= 4) {
                return null;
            }
            builtThisFrame[0]++;

            if (mChunkBitmaps[lruIdx] == null) {
                mChunkBitmaps[lruIdx] = Bitmap.createBitmap(CHUNK_PX, CHUNK_PX, Bitmap.Config.ARGB_8888);
                mChunkCanvases[lruIdx] = new Canvas(mChunkBitmaps[lruIdx]);
            }
            mChunkKeys[lruIdx] = key;
            mChunkAge[lruIdx] = ++mChunkTick;

            paintChunk(mChunkCanvases[lruIdx], cxIdx, cyIdx);
            return mChunkBitmaps[lruIdx];
        }


        private static int waterColor(float d, int jitter) {
            float t = Math.max(0.0f, Math.min(1.0f, d / 0.45f));
            int r = (int) (12 + (3 - 12) * t) + jitter;
            int g = (int) (24 + (7 - 24) * t) + jitter;
            int b = (int) (42 + (16 - 42) * t) + jitter + 1;
            return Color.rgb(Math.max(0, r), Math.max(0, g), Math.max(0, b));
        }

        private static float bilerp(float a, float b, float c, float d, float fx, float fy) {
            float top = a + (b - a) * fx;
            float bot = c + (d - c) * fx;
            return top + (bot - top) * fy;
        }

        private boolean solidCell(WorldGen g, int i, int j, float baseWx, float baseWy, float upc) {
            int n = CHUNK_CELLS;
            if (i >= 0 && j >= 0 && i < n && j < n) return mSolid[j * n + i];
            return g.cliff(baseWx + (i + 0.5f) * upc, baseWy + (j + 0.5f) * upc) > WorldGen.CLIFF_LEVEL;
        }

        /**
         * Paints one 4x4-unit chunk of ground: fine-blade grass, moisture tint, water, rock faces,
         * shore reeds, flower clusters. Everything comes from the seeded generator, so a chunk can
         * be thrown away and rebuilt identically at any time.
         */
        private void paintChunk(Canvas cc, int cxIdx, int cyIdx) {
            final WorldGen g = mGen;
            final int n = CHUNK_CELLS;
            final int lat = n + 1;
            final float cellPx = CHUNK_PX / (float) n;
            final float baseWx = cxIdx * CHUNK_WORLD_UNITS;
            final float baseWy = cyIdx * CHUNK_WORLD_UNITS;
            final float upc = CHUNK_WORLD_UNITS / n;
            final float cliffLvl = WorldGen.CLIFF_LEVEL;
            final float wetEps = 0.012f;

            // 0) lattice of terrain samples at cell corners
            for (int j = 0; j <= n; j++) {
                for (int i = 0; i <= n; i++) {
                    g.sample(baseWx + i * upc, baseWy + j * upc, mSample);
                    int k = j * lat + i;
                    mLatCliff[k] = mSample[0];
                    mLatWater[k] = mSample[1];
                    mLatMoist[k] = mSample[2];
                }
            }

            // 1) grass: world-aligned window of the seamless blade tile (so chunks join without seams),
            //    plus a few unique accent blades per chunk to break up the tile's repetition
            long hb = g.hashBits(cxIdx, cyIdx, 900);
            int tilesPerSide = MEADOW_TILE_PX / CHUNK_PX;
            int qx = Math.floorMod(cxIdx, tilesPerSide);
            int qy = Math.floorMod(cyIdx, tilesPerSide);
            mSrcRect.set(qx * CHUNK_PX, qy * CHUNK_PX, (qx + 1) * CHUNK_PX, (qy + 1) * CHUNK_PX);
            mTmpRect.set(0, 0, CHUNK_PX, CHUNK_PX);
            cc.drawBitmap(mMeadowTileBitmap, mSrcRect, mTmpRect, null);
            mRng.setSeed(hb ^ 0xB1ADEL);
            for (int pass = 0; pass < 2; pass++) {
                int cntB = 0;
                for (int q = 0; q < 380; q++) {
                    float bx = mRng.nextFloat() * CHUNK_PX;
                    float by = 8.0f + mRng.nextFloat() * (CHUNK_PX - 8.0f);
                    float len = 9.0f + mRng.nextFloat() * 9.0f;
                    float lean = 1.0f + (mRng.nextFloat() - 0.5f) * 4.0f;
                    mFoamDim[cntB++] = bx;
                    mFoamDim[cntB++] = by;
                    mFoamDim[cntB++] = bx + lean;
                    mFoamDim[cntB++] = by - len;
                }
                mGrassPaint.setStrokeWidth(1.4f);
                mGrassPaint.setColor(pass == 0 ? Color.rgb(22, 52, 40) : Color.rgb(52, 98, 74));
                cc.drawLines(mFoamDim, 0, cntB, mGrassPaint);
            }

            // 2) smooth tint: lush groves, dry moor, darker highlands (bilinear-scaled, so no seams)
            for (int j = 0; j < n; j++) {
                for (int i = 0; i < n; i++) {
                    int k = j * lat + i;
                    float m = (mLatMoist[k] + mLatMoist[k + 1] + mLatMoist[k + lat] + mLatMoist[k + lat + 1]) * 0.25f;
                    float cl = (mLatCliff[k] + mLatCliff[k + 1] + mLatCliff[k + lat] + mLatCliff[k + lat + 1]) * 0.25f;
                    float wet = Math.max(-1.0f, Math.min(1.0f, (m - 0.5f) * 2.6f));
                    int r;
                    int gg;
                    int b;
                    int a;
                    if (wet > 0.0f) {
                        r = 22;
                        gg = 84;
                        b = 40;
                        a = (int) (74.0f * wet);
                    } else {
                        r = 52;
                        gg = 50;
                        b = 34;
                        a = (int) (96.0f * -wet);
                    }
                    float hi = Math.max(0.0f, Math.min(1.0f, (cl - 0.50f) / 0.15f));
                    int a2 = (int) (135.0f * hi);
                    if (a2 > 0) {
                        float w = a2 / (float) (a + a2 + 1);
                        r = (int) (r + (6 - r) * w);
                        gg = (int) (gg + (10 - gg) * w);
                        b = (int) (b + (12 - b) * w);
                        a = Math.max(a, a2);
                    }
                    mTintPx[j * n + i] = Color.argb(a, r, gg, b);
                }
            }
            if (mTintBitmap == null) {
                mTintBitmap = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888);
            }
            mTintBitmap.setPixels(mTintPx, 0, n, 0, 0, n, n);
            mTmpRect.set(0, 0, CHUNK_PX, CHUNK_PX);
            cc.drawBitmap(mTintBitmap, null, mTmpRect, mTintPaint);

            // 3) classify cells
            for (int j = 0; j < n; j++) {
                for (int i = 0; i < n; i++) {
                    int k = j * lat + i;
                    float cl = (mLatCliff[k] + mLatCliff[k + 1] + mLatCliff[k + lat] + mLatCliff[k + lat + 1]) * 0.25f;
                    float wd = (mLatWater[k] + mLatWater[k + 1] + mLatWater[k + lat] + mLatWater[k + lat + 1]) * 0.25f;
                    mSolid[j * n + i] = cl > cliffLvl;
                    mWet[j * n + i] = wd > 0.008f;
                }
            }

            // 3b) water and rock as smooth masks: interpolate the corner samples at 4x resolution and let
            //     bilinear scaling soften the edge, so shorelines and cliff faces are not blocky
            float minW = 9.0f, maxW = -9.0f, maxC = -9.0f;
            for (int q = 0; q < lat * lat; q++) {
                if (mLatWater[q] > maxW) maxW = mLatWater[q];
                if (mLatWater[q] < minW) minW = mLatWater[q];
                if (mLatCliff[q] > maxC) maxC = mLatCliff[q];
            }
            mTmpRect.set(0, 0, CHUNK_PX, CHUNK_PX);
            if (maxW > wetEps) {
                if (mWaterMask == null) mWaterMask = Bitmap.createBitmap(MASK_PX, MASK_PX, Bitmap.Config.ARGB_8888);
                for (int my = 0; my < MASK_PX; my++) {
                    int j = my >> 2;
                    float fy = ((my & 3) + 0.5f) / 4.0f;
                    for (int mx = 0; mx < MASK_PX; mx++) {
                        int i = mx >> 2;
                        float fx = ((mx & 3) + 0.5f) / 4.0f;
                        int k = j * lat + i;
                        float d = bilerp(mLatWater[k], mLatWater[k + 1], mLatWater[k + lat], mLatWater[k + lat + 1], fx, fy);
                        float a = (d - 0.004f) / 0.018f;
                        if (a <= 0.0f) {
                            mMaskPx[my * MASK_PX + mx] = 0;
                        } else {
                            int jit = (((cxIdx * n + i) * 7 + (cyIdx * n + j) * 13) & 7) - 3;
                            int col = waterColor(d, jit);
                            mMaskPx[my * MASK_PX + mx] = (col & 0x00FFFFFF) | ((int) (Math.min(1.0f, a) * 255.0f) << 24);
                        }
                    }
                }
                mWaterMask.setPixels(mMaskPx, 0, MASK_PX, 0, 0, MASK_PX, MASK_PX);
                cc.drawBitmap(mWaterMask, null, mTmpRect, mTintPaint);
            }
            if (maxC > cliffLvl - 0.006f) {
                if (mCliffMask == null) mCliffMask = Bitmap.createBitmap(MASK_PX, MASK_PX, Bitmap.Config.ARGB_8888);
                for (int my = 0; my < MASK_PX; my++) {
                    int j = my >> 2;
                    float fy = ((my & 3) + 0.5f) / 4.0f;
                    for (int mx = 0; mx < MASK_PX; mx++) {
                        int i = mx >> 2;
                        float fx = ((mx & 3) + 0.5f) / 4.0f;
                        int k = j * lat + i;
                        float v = bilerp(mLatCliff[k], mLatCliff[k + 1], mLatCliff[k + lat], mLatCliff[k + lat + 1], fx, fy);
                        float a = (v - (cliffLvl - 0.006f)) / 0.012f;
                        mMaskPx[my * MASK_PX + mx] = (a <= 0.0f) ? 0 : 0x00040608 | ((int) (Math.min(1.0f, a) * 255.0f) << 24);
                    }
                }
                mCliffMask.setPixels(mMaskPx, 0, MASK_PX, 0, 0, MASK_PX, MASK_PX);
                cc.drawBitmap(mCliffMask, null, mTmpRect, mTintPaint);
            }

            mChunkObjs.clear();
            g.objectsIn(baseWx, baseWy, baseWx + CHUNK_WORLD_UNITS, baseWy + CHUNK_WORLD_UNITS, mChunkObjs);
            boolean haveHouse = false;
            for (int q = 0; q < mChunkObjs.size(); q++) {
                if (mChunkObjs.get(q).kind == WorldGen.HOUSE) haveHouse = true;
            }

            Paint bg = mChunkBgPaint;
            Paint tx = mChunkTxtPaint;
            tx.setTextAlign(Paint.Align.LEFT);
            tx.setTextSize(cellPx * 1.0f);
            final float sub = cellPx / 4.0f;
            final int nChars = Gfx.ROCK_CHARS.length();

            for (int j = 0; j < n; j++) {
                for (int i = 0; i < n; i++) {
                    int k = j * lat + i;
                    float px = i * cellPx;
                    float py = j * cellPx;
                    float w00 = mLatWater[k];
                    float w10 = mLatWater[k + 1];
                    float w01 = mLatWater[k + lat];
                    float w11 = mLatWater[k + lat + 1];
                    float c00 = mLatCliff[k];
                    float c10 = mLatCliff[k + 1];
                    float c01 = mLatCliff[k + lat];
                    float c11 = mLatCliff[k + lat + 1];
                    int gi = cxIdx * n + i;
                    int gj = cyIdx * n + j;
                    int ch = Math.abs((gi * 73856093) ^ (gj * 19349663));
                    boolean anyW = w00 > wetEps || w10 > wetEps || w01 > wetEps || w11 > wetEps;
                    boolean allW = w00 > wetEps && w10 > wetEps && w01 > wetEps && w11 > wetEps;
                    boolean anyC = c00 > cliffLvl || c10 > cliffLvl || c01 > cliffLvl || c11 > cliffLvl;
                    boolean allC = c00 > cliffLvl && c10 > cliffLvl && c01 > cliffLvl && c11 > cliffLvl;
                    boolean solid = mSolid[j * n + i];

                    // ---- water glyph texture (the water itself is the mask drawn above)
                    if (allW && ch % 5 == 0) {
                        tx.setColor(Color.argb(150, 56, 80, 116));
                        cc.drawText(GROUND_ASCII[ch % GROUND_ASCII.length], 0, 3, px, py + cellPx * 0.85f, tx);
                    }

                    // ---- rock face
                    if (anyC) {
                        if (solid) {
                            float gx = (c10 + c11 - c00 - c01) * 0.5f;
                            float gy = (c01 + c11 - c00 - c10) * 0.5f;
                            float sun = 0.5f - (gx + gy) * 38.0f;
                            float nz = (ch & 255) / 255.0f;
                            float lum = 0.42f + (sun - 0.5f) * 0.9f + (nz - 0.5f) * 0.28f;
                            if (!solidCell(g, i, j - 1, baseWx, baseWy, upc)) lum += 0.22f;
                            if (!solidCell(g, i, j + 1, baseWx, baseWy, upc) || !solidCell(g, i + 1, j, baseWx, baseWy, upc)) lum -= 0.16f;
                            lum = Math.max(0.16f, Math.min(1.0f, lum));
                            int idx = (int) ((1.0f - lum) * (nChars - 1) + (nz - 0.5f) * 3.0f);
                            idx = Math.max(0, Math.min(nChars - 1, idx));
                            int v = Math.max(70, Math.min(248, (int) (70.0f + lum * 175.0f)));
                            tx.setColor(Color.rgb(Math.max(0, v - 6), v, Math.min(255, v + 9)));
                            mSingleChar[0] = Gfx.ROCK_CHARS.charAt(idx);
                            cc.drawText(mSingleChar, 0, 1, px, py + cellPx * 0.86f, tx);
                        }
                    } else if (!anyW) {
                        float cl = (c00 + c10 + c01 + c11) * 0.25f;
                        if (cl > cliffLvl - 0.05f) {
                            // rocky slope at the foot of a cliff
                            bg.setColor(Color.argb((int) (((cl - (cliffLvl - 0.05f)) / 0.05f) * 150.0f), 3, 6, 5));
                            cc.drawRect(px, py, px + cellPx + 0.5f, py + cellPx + 0.5f, bg);
                            if (ch % 100 < 40) {
                                tx.setColor(Color.argb(110, 74, 86, 98));
                                mSingleChar[0] = Gfx.ROCK_CHARS.charAt(14 + ch % 14);
                                cc.drawText(mSingleChar, 0, 1, px, py + cellPx * 0.86f, tx);
                            }
                        } else {
                            // soft shadow cast to the lower right of a cliff
                            if (solidCell(g, i - 1, j - 1, baseWx, baseWy, upc) || solidCell(g, i - 1, j, baseWx, baseWy, upc)
                                    || solidCell(g, i, j - 1, baseWx, baseWy, upc)) {
                                bg.setColor(Color.argb(80, 2, 5, 4));
                                cc.drawRect(px, py, px + cellPx + 0.5f, py + cellPx + 0.5f, bg);
                            }
                            // reeds / pebbles on the bank
                            boolean bank = (i > 0 && mWet[j * n + i - 1]) || (i < n - 1 && mWet[j * n + i + 1])
                                    || (j > 0 && mWet[(j - 1) * n + i]) || (j < n - 1 && mWet[(j + 1) * n + i]);
                            if (bank) {
                                if (ch % 3 == 0) {
                                    tx.setColor(Color.rgb(92, 138, 86));
                                    cc.drawText((ch % 2 == 0) ? "|" : "i", px, py + cellPx * 0.85f, tx);
                                } else if (ch % 5 == 0) {
                                    tx.setColor(Color.rgb(108, 118, 126));
                                    cc.drawText("o", px, py + cellPx * 0.85f, tx);
                                }
                            } else if (g.hash01(Math.floorDiv(gi, 3), Math.floorDiv(gj, 3), 910) > 0.87f && ch % 100 < 55) {
                                // sparse, dim ground-glyph patches (like the reference, not a carpet)
                                tx.setColor(Color.argb(105, 58, 78, 108));
                                cc.drawText(GROUND_ASCII[ch % GROUND_ASCII.length], px, py + cellPx * 0.85f, tx);
                            }
                            // worn path in front of cottage doors
                            if (haveHouse) {
                                float wx = baseWx + (i + 0.5f) * upc;
                                float wy = baseWy + (j + 0.5f) * upc;
                                for (int q = 0; q < mChunkObjs.size(); q++) {
                                    WorldGen.Obj o = mChunkObjs.get(q);
                                    if (o.kind == WorldGen.HOUSE && Math.abs(wx - o.x) < 0.72f && wy > o.y + 0.5f && wy < o.y + 2.8f) {
                                        bg.setColor(Color.argb(150, 26, 22, 18));
                                        cc.drawRect(px, py, px + cellPx + 0.5f, py + cellPx + 0.5f, bg);
                                        tx.setColor((ch % 2 == 0) ? Color.rgb(112, 102, 88) : Color.rgb(86, 78, 68));
                                        cc.drawText((ch % 3 == 0) ? ":" : ".", px, py + cellPx * 0.85f, tx);
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 4) flowers: white star/ring sprinkles everywhere, lavender & pale-blue clusters in damp ground
            mRng.setSeed(hb ^ 0x51F0E5L);
            float moistAvg = mLatMoist[(n / 2) * lat + n / 2];
            int sprinkles = 22 + (int) (moistAvg * 34.0f);
            for (int f = 0; f < sprinkles; f++) {
                float fx = mRng.nextFloat() * CHUNK_PX;
                float fy = mRng.nextFloat() * CHUNK_PX;
                if (!landAt(fx, fy, cellPx)) continue;
                float kind = mRng.nextFloat();
                tx.setTextSize(kind < 0.58f ? 10.0f : 9.0f);
                tx.setColor(Color.rgb(8, 16, 10));
                cc.drawText(".", fx + 0.8f, fy + 1.6f, tx);
                if (kind < 0.58f) {
                    tx.setColor((f % 3 == 0) ? Color.rgb(246, 248, 235) : Color.rgb(232, 240, 250));
                    cc.drawText("*", fx, fy, tx);
                } else if (kind < 0.84f) {
                    tx.setColor(Color.rgb(206, 222, 236));
                    cc.drawText("o", fx, fy, tx);
                } else {
                    tx.setColor(Color.rgb(230, 236, 240));
                    cc.drawText(".", fx, fy, tx);
                }
            }
            int clusters = (moistAvg > 0.56f ? 2 : 0) + (mRng.nextFloat() < 0.5f ? 1 : 0);
            for (int c = 0; c < clusters; c++) {
                float ccx = 24.0f + mRng.nextFloat() * (CHUNK_PX - 48.0f);
                float ccy = 24.0f + mRng.nextFloat() * (CHUNK_PX - 48.0f);
                int kind = mRng.nextInt(3);
                int cnt = 16 + mRng.nextInt(20);
                float rad = 30.0f + mRng.nextFloat() * 50.0f;
                int col = (kind == 0) ? Color.rgb(186, 152, 232) : (kind == 1 ? Color.rgb(164, 132, 214) : Color.rgb(214, 232, 255));
                for (int q = 0; q < cnt; q++) {
                    float a = mRng.nextFloat() * 6.2832f;
                    float r = (float) Math.sqrt(mRng.nextFloat()) * rad;
                    float fx = ccx + (float) Math.cos(a) * r;
                    float fy = ccy + (float) Math.sin(a) * r * 0.8f;
                    if (!landAt(fx, fy, cellPx)) continue;
                    tx.setTextSize(12.0f);
                    tx.setColor(Color.rgb(8, 16, 10));
                    cc.drawText(".", fx + 1.0f, fy + 2.0f, tx);
                    tx.setColor(col);
                    cc.drawText("*", fx, fy, tx);
                }
            }
        }

        private boolean landAt(float px, float py, float cellPx) {
            int i = (int) (px / cellPx);
            int j = (int) (py / cellPx);
            if (i < 0 || j < 0 || i >= CHUNK_CELLS || j >= CHUNK_CELLS) return false;
            return !mSolid[j * CHUNK_CELLS + i] && !mWet[j * CHUNK_CELLS + i];
        }

        private void drawAsciiBufferSpanBatched(
                Canvas canvas, char[] gBuf, int[] cBuf, int bufW, int bufH,
                float originX, float originY, float cellPx,
                boolean darkBacking, int overrideColor
        ) {
            mAsciiPaint.setTextSize(Math.max(5.5f, cellPx * 1.18f));
            mAsciiPaint.setTextAlign(Paint.Align.LEFT);
            for (int r = 0; r < bufH; r++) {
                float drawY = originY + r * cellPx;
                int rowOff = r * bufW;
                int c = 0;
                while (c < bufW) {
                    if (gBuf[rowOff + c] == ' ') {
                        c++;
                        continue;
                    }
                    int startC = c;
                    int firstColor = (overrideColor != 0) ? overrideColor : cBuf[rowOff + c];
                    while (c < bufW && gBuf[rowOff + c] != ' ') {
                        if (overrideColor == 0 && Math.abs(Color.red(cBuf[rowOff + c]) - Color.red(firstColor)) > 36) {
                            break;
                        }
                        c++;
                    }
                    int spanLen = c - startC;
                    float sx = originX + startC * cellPx;
                    if (darkBacking) {
                        mPanelPaint.setColor(Color.argb(230, 5, 7, 9));
                        canvas.drawRect(sx - 1.0f, drawY - cellPx * 0.88f, sx + spanLen * cellPx + 1.0f, drawY + cellPx * 0.16f, mPanelPaint);
                    }
                    mAsciiPaint.setColor(firstColor);
                    canvas.drawText(gBuf, rowOff + startC, spanLen, sx, drawY, mAsciiPaint);
                }
            }
        }

        /** Hero glyph grid: glyph advance == cell width and cell height = 1.3 x width, so the body keeps its proportions. */
        private void drawHeroGlyphs(Canvas canvas, float hx, float hy, float ppu, boolean backing, int overrideColor) {
            final float unit = ppu * HERO_UNIT_PPU;
            final float cellW = unit / HERO_COLS_PER_UNIT;
            final float cellH = unit / HERO_ROWS_PER_UNIT;
            drawHeroGlyphsAt(canvas, hx - (FOOT_BUF_W * 0.5f) * cellW,
                    hy - 0.19f * ppu - (FOOT_BUF_H * 0.55f) * cellH, cellW, cellH, backing, overrideColor);
        }

        private void drawHeroGlyphsAt(Canvas canvas, float originX, float originY, float cellW, float cellH,
                                      boolean backing, int overrideColor) {
            if (mAsciiAdv <= 0.0f) {
                mAsciiPaint.setTextSize(100.0f);
                mAsciiAdv = Math.max(0.3f, mAsciiPaint.measureText("M") / 100.0f);
            }
            mAsciiPaint.setTextSize(cellW / mAsciiAdv);
            mAsciiPaint.setTextAlign(Paint.Align.LEFT);
            for (int r = 0; r < FOOT_BUF_H; r++) {
                final float drawY = originY + r * cellH;
                final int rowOff = r * FOOT_BUF_W;
                int c = 0;
                while (c < FOOT_BUF_W) {
                    if (mFootGlyphBuf[rowOff + c] == ' ') {
                        c++;
                        continue;
                    }
                    final int startC = c;
                    final int firstColor = (overrideColor != 0) ? overrideColor : mFootColorBuf[rowOff + c];
                    while (c < FOOT_BUF_W && mFootGlyphBuf[rowOff + c] != ' ') {
                        if (overrideColor == 0 && Math.abs(Color.red(mFootColorBuf[rowOff + c]) - Color.red(firstColor)) > 22) {
                            break;
                        }
                        c++;
                    }
                    final int spanLen = c - startC;
                    final float sx = originX + startC * cellW;
                    if (backing) {
                        mPanelPaint.setColor(Color.argb(150, 5, 7, 9));
                        canvas.drawRect(sx, drawY - cellH * 0.86f, sx + spanLen * cellW, drawY + cellH * 0.14f, mPanelPaint);
                    }
                    mAsciiPaint.setColor(firstColor);
                    canvas.drawText(mFootGlyphBuf, rowOff + startC, spanLen, sx, drawY, mAsciiPaint);
                }
            }
        }

        /** Fine glyph grid for the horse: glyph advance == cell width, cell height = ROW_ASPECT x width. */
        private void drawHorseGlyphs(Canvas canvas, float hx, float hy, float ppu, boolean backing, int overrideColor) {
            final float cellW = (ppu * HORSE_SPAN_PPU) / HORSE_BUF_W;
            final float cellH = cellW * HORSE_ROW_ASPECT;
            if (mAsciiAdv <= 0.0f) {
                mAsciiPaint.setTextSize(100.0f);
                mAsciiAdv = Math.max(0.3f, mAsciiPaint.measureText("M") / 100.0f);
            }
            mAsciiPaint.setTextSize(cellW / mAsciiAdv);
            mAsciiPaint.setTextAlign(Paint.Align.LEFT);
            final float originX = hx - (HORSE_BUF_W * 0.5f) * cellW;
            final float originY = hy - (HORSE_BUF_H * 0.56f) * cellH;
            for (int r = 0; r < HORSE_BUF_H; r++) {
                final float drawY = originY + r * cellH;
                final int rowOff = r * HORSE_BUF_W;
                int c = 0;
                while (c < HORSE_BUF_W) {
                    if (mHorseGlyphBuf[rowOff + c] == ' ') {
                        c++;
                        continue;
                    }
                    final int startC = c;
                    final int firstColor = (overrideColor != 0) ? overrideColor : mHorseColorBuf[rowOff + c];
                    while (c < HORSE_BUF_W && mHorseGlyphBuf[rowOff + c] != ' ') {
                        if (overrideColor == 0 && Math.abs(Color.red(mHorseColorBuf[rowOff + c]) - Color.red(firstColor)) > 22) {
                            break;
                        }
                        c++;
                    }
                    final int spanLen = c - startC;
                    final float sx = originX + startC * cellW;
                    if (backing) {
                        mPanelPaint.setColor(Color.argb(150, 5, 7, 9));
                        canvas.drawRect(sx, drawY - cellH * 0.86f, sx + spanLen * cellW, drawY + cellH * 0.14f, mPanelPaint);
                    }
                    mAsciiPaint.setColor(firstColor);
                    canvas.drawText(mHorseGlyphBuf, rowOff + startC, spanLen, sx, drawY, mAsciiPaint);
                }
            }
        }

        private void drawFrame() {
            SurfaceHolder holder = getHolder();
            Canvas canvas = null;
            try {
                if (Build.VERSION.SDK_INT >= 26) {
                    canvas = holder.lockHardwareCanvas();
                } else {
                    canvas = holder.lockCanvas();
                }
                if (canvas == null) return;

                ensureStaticCaches();

                int screenW = canvas.getWidth();
                int screenH = canvas.getHeight();
                canvas.drawColor(Color.rgb(7, 11, 10));

                float pixelsPerUnit = Math.min(screenW, screenH) * 0.095f * mCameraZoom;
                float centerX = screenW * 0.5f;
                float centerY = screenH * 0.50f;

                final WorldGen gen = mGen;
                final float camZ = gen.terrainHeight(mCamX, mCamY);

                // Expand view bounds to cover the tilted 2.5D perspective horizon and foreground
                float halfUnitsW = ((screenW * 0.5f) / pixelsPerUnit) * 1.38f + 2.0f;
                float halfUnitsH = ((screenH * 0.5f) / (pixelsPerUnit * WorldGen.PITCH_Y)) * 1.28f + 2.2f;

                // 1. 2.5D Perspective & 3D Elevation-Warped Ground Chunks (via Matrix.setPolyToPoly)
                int minCx = (int) Math.floor((mCamX - halfUnitsW) / CHUNK_WORLD_UNITS);
                int maxCx = (int) Math.floor((mCamX + halfUnitsW) / CHUNK_WORLD_UNITS);
                int minCy = (int) Math.floor((mCamY - halfUnitsH) / CHUNK_WORLD_UNITS);
                int maxCy = (int) Math.floor((mCamY + halfUnitsH) / CHUNK_WORLD_UNITS);
                int[] builtThisFrame = new int[]{0};
                mFrameStartNs = System.nanoTime();

                mPolySrc[0] = 0.0f;       mPolySrc[1] = 0.0f;
                mPolySrc[2] = CHUNK_PX;   mPolySrc[3] = 0.0f;
                mPolySrc[4] = CHUNK_PX;   mPolySrc[5] = CHUNK_PX;
                mPolySrc[6] = 0.0f;       mPolySrc[7] = CHUNK_PX;

                for (int cy = minCy; cy <= maxCy; cy++) {
                    for (int cx = minCx; cx <= maxCx; cx++) {
                        float wx0 = cx * CHUNK_WORLD_UNITS - 0.03f;
                        float wy0 = cy * CHUNK_WORLD_UNITS - 0.03f;
                        float wx1 = (cx + 1) * CHUNK_WORLD_UNITS + 0.03f;
                        float wy1 = (cy + 1) * CHUNK_WORLD_UNITS + 0.03f;

                        gen.project25D(wx0, wy0, 0.0f, mCamX, mCamY, camZ, centerX, centerY, pixelsPerUnit, halfUnitsH, mProjTmp);
                        mPolyDst[0] = mProjTmp[0]; mPolyDst[1] = mProjTmp[1];
                        gen.project25D(wx1, wy0, 0.0f, mCamX, mCamY, camZ, centerX, centerY, pixelsPerUnit, halfUnitsH, mProjTmp);
                        mPolyDst[2] = mProjTmp[0]; mPolyDst[3] = mProjTmp[1];
                        gen.project25D(wx1, wy1, 0.0f, mCamX, mCamY, camZ, centerX, centerY, pixelsPerUnit, halfUnitsH, mProjTmp);
                        mPolyDst[4] = mProjTmp[0]; mPolyDst[5] = mProjTmp[1];
                        gen.project25D(wx0, wy1, 0.0f, mCamX, mCamY, camZ, centerX, centerY, pixelsPerUnit, halfUnitsH, mProjTmp);
                        mPolyDst[6] = mProjTmp[0]; mPolyDst[7] = mProjTmp[1];

                        Bitmap chunk = getOrBuildChunk(cx, cy, builtThisFrame);
                        Bitmap toDraw = (chunk != null) ? chunk : mMeadowTileBitmap;
                        if (mChunkMatrix.setPolyToPoly(mPolySrc, 0, mPolyDst, 0, 4)) {
                            canvas.drawBitmap(toDraw, mChunkMatrix, mBitmapPaint);
                        }
                    }
                }

                boolean ringFits = (maxCx - minCx + 3) * (maxCy - minCy + 3) <= CHUNK_CACHE_CAP;
                for (int cy = minCy - 1; ringFits && cy <= maxCy + 1 && builtThisFrame[0] < 2; cy++) {
                    for (int cx = minCx - 1; cx <= maxCx + 1 && builtThisFrame[0] < 2; cx++) {
                        if (cx >= minCx && cx <= maxCx && cy >= minCy && cy <= maxCy) continue;
                        getOrBuildChunk(cx, cy, builtThisFrame);
                    }
                }

                // 2. Dense living grass (projected onto the 2.5D tilted & height-mapped terrain)
                float windScale = (mWindPreset == 0) ? 0.6f : (mWindPreset == 1 ? 1.0f : 1.75f);
                mObjs.clear();
                gen.objectsIn(mCamX - halfUnitsW, mCamY - halfUnitsH, mCamX + halfUnitsW, mCamY + halfUnitsH, mObjs);
                mSpriteBudget = 1;

                mGrassFx.clearPushers();
                mGrassFx.addPusher(mPlayerX, mPlayerY + 0.25f, mVelX, mVelY, mMounted ? 1.7f : 1.1f);
                for (int eg = 0; eg < NUM_ENEMIES; eg++) {
                    mGrassFx.addPusher(mEnemyX[eg], mEnemyY[eg] + 0.2f, 0.0f, 0.0f, 0.9f);
                }
                mGrassFx.drawField(canvas, gen, mCamX, mCamY, centerX, centerY, pixelsPerUnit,
                        halfUnitsW, halfUnitsH, mTimeSec, windScale);
                mGrassFx.drawSparkles(canvas, gen, mCamX, mCamY, centerX, centerY, pixelsPerUnit,
                        halfUnitsW, halfUnitsH, mTimeSec);

                // Moonlit cave mouths cut into the 2.5D rock faces
                for (int oi = 0; oi < mObjs.size(); oi++) {
                    WorldGen.Obj o = mObjs.get(oi);
                    if (o.kind != WorldGen.CAVE) continue;
                    gen.project25D(o.x, o.y, 0.0f, mCamX, mCamY, camZ, centerX, centerY, pixelsPerUnit, halfUnitsH, mProjTmp);
                    float cvx = mProjTmp[0];
                    float cvy = mProjTmp[1];
                    float effPpu = pixelsPerUnit * mProjTmp[2];
                    if (cvx < -320 || cvx > screenW + 320 || cvy < -320 || cvy > screenH + 320) continue;
                    drawCaveMouth(canvas, o, cvx, cvy, effPpu);
                }

                // Moving 2.5D foam, plus the hero's upside-down reflection
                drawWaterEffects(canvas, centerX, centerY, pixelsPerUnit, halfUnitsW, halfUnitsH, camZ);

                // Handcrafted 2.5D upright ASCII cottages (with braziers) and glowing runestones
                mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                for (int oi = 0; oi < mObjs.size(); oi++) {
                    WorldGen.Obj o = mObjs.get(oi);
                    if (o.kind != WorldGen.SHRINE && o.kind != WorldGen.HOUSE) continue;
                    gen.project25D(o.x, o.y, 0.0f, mCamX, mCamY, camZ, centerX, centerY, pixelsPerUnit, halfUnitsH, mProjTmp);
                    float hx = mProjTmp[0];
                    float hy = mProjTmp[1];
                    float effPpu = pixelsPerUnit * mProjTmp[2];
                    float houseFontPx = Math.max(8.0f, effPpu * 0.19f);
                    mAsciiPaint.setTextSize(houseFontPx);
                    if (o.kind == WorldGen.SHRINE) {
                        if (hx < -80 || hx > screenW + 80 || hy < -80 || hy > screenH + 80) continue;
                        mAsciiPaint.setColor(Color.rgb(125, 245, 220));
                        canvas.drawText("[*]", hx, hy, mAsciiPaint);
                        continue;
                    }
                    if (hx < -320 || hx > screenW + 320 || hy < -260 || hy > screenH + 260) continue;

                    float hW = houseFontPx * 13.8f;
                    float hH = HOUSE_ART.length * houseFontPx * 0.90f;
                    mShadowPaint.setColor(Color.argb(180, 4, 7, 6));
                    mTmpRect.set(hx - hW * 0.48f, hy + hH * 0.22f, hx + hW * 0.56f, hy + hH * 0.44f);
                    canvas.drawOval(mTmpRect, mShadowPaint);

                    for (int hr = 0; hr < HOUSE_ART.length; hr++) {
                        float ry = hy - hH * 0.55f + hr * houseFontPx * 0.90f;
                        mPanelPaint.setColor(Color.rgb(7, 9, 11));
                        canvas.drawRect(hx - hW * 0.5f, ry - houseFontPx * 0.82f, hx + hW * 0.5f, ry + houseFontPx * 0.14f, mPanelPaint);
                        mAsciiPaint.setColor(hr < 4 ? Color.rgb(165, 178, 192) : (hr >= 6 ? Color.rgb(248, 200, 110) : Color.rgb(210, 214, 218)));
                        canvas.drawText(HOUSE_ART[hr], hx, ry, mAsciiPaint);
                    }
                    boolean flick = ((int) (mTimeSec * 8.0f + oi)) % 2 == 0;
                    mAsciiPaint.setColor(flick ? Color.rgb(255, 198, 92) : Color.rgb(242, 146, 68));
                    canvas.drawText(flick ? "(^)" : "(*)", hx + effPpu * 1.45f, hy + effPpu * 0.48f, mAsciiPaint);
                    mAsciiPaint.setColor(Color.rgb(138, 114, 86));
                    canvas.drawText("|--|--|", hx - effPpu * 1.55f, hy + effPpu * 0.68f, mAsciiPaint);
                }

                // Harvestable Flora Nodes (2.5D projected)
                mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                for (int f = 0; f < NUM_FLORA; f++) {
                    if (mFloraRegrow[f] > 0.0f) continue;
                    gen.project25D(mFloraX[f], mFloraY[f], 0.0f, mCamX, mCamY, camZ, centerX, centerY, pixelsPerUnit, halfUnitsH, mProjTmp);
                    float fx = mProjTmp[0];
                    float fy = mProjTmp[1];
                    if (fx < -80 || fx > screenW + 80 || fy < -80 || fy > screenH + 80) continue;
                    mAsciiPaint.setTextSize(Math.max(9.5f, pixelsPerUnit * mProjTmp[2] * 0.20f));
                    if (mFloraKind[f] == 0) {
                        mAsciiPaint.setColor(Color.rgb(175, 225, 255));
                        canvas.drawText("(*)", fx, fy, mAsciiPaint);
                    } else if (mFloraKind[f] == 1) {
                        mAsciiPaint.setColor(Color.rgb(255, 175, 95));
                        canvas.drawText("{@}", fx, fy, mAsciiPaint);
                    } else {
                        mAsciiPaint.setColor(Color.rgb(135, 238, 165));
                        canvas.drawText("[#]", fx, fy, mAsciiPaint);
                    }
                }

                // Ambient Fauna (2.5D projected)
                for (int a = 0; a < NUM_FAUNA; a++) {
                    gen.project25D(mFaunaX[a], mFaunaY[a], 0.0f, mCamX, mCamY, camZ, centerX, centerY, pixelsPerUnit, halfUnitsH, mProjTmp);
                    float ax = mProjTmp[0];
                    float ay = mProjTmp[1];
                    float effPpu = pixelsPerUnit * mProjTmp[2];
                    if (ax < -100 || ax > screenW + 100 || ay < -100 || ay > screenH + 100) continue;
                    mAsciiPaint.setTextSize(Math.max(9.0f, effPpu * 0.19f));
                    float hop = Math.abs((float) Math.sin(mFaunaPhase[a])) * effPpu * 0.14f;
                    if (mFaunaKind[a] == 0) {
                        mAsciiPaint.setColor(Color.rgb(212, 178, 134));
                        canvas.drawText(mFaunaVx[a] >= 0 ? "^..^>" : "<^..^", ax, ay - hop * 0.6f, mAsciiPaint);
                    } else if (mFaunaKind[a] == 1) {
                        mAsciiPaint.setColor(Color.rgb(238, 240, 235));
                        canvas.drawText("()o", ax, ay - hop, mAsciiPaint);
                    } else if (mFaunaKind[a] == 2) {
                        boolean flap = ((int) (mFaunaPhase[a] * 1.8f)) % 2 == 0;
                        mAsciiPaint.setColor(Color.rgb(185, 198, 215));
                        canvas.drawText(flap ? "\\v/" : "-v-", ax, ay - effPpu * 0.35f - hop, mAsciiPaint);
                    } else {
                        mAsciiPaint.setColor(Color.rgb(245, 165, 115));
                        canvas.drawText(mFaunaVx[a] >= 0 ? "<><" : "><>", ax, ay, mAsciiPaint);
                    }
                }

                // Standing stones and boulders behind the hero (2.5D upright depth-scaled billboards)
                drawStones(canvas, centerX, centerY, pixelsPerUnit, halfUnitsH, camZ, screenW, screenH, true);

                // 4. Loot + Animated Humanoid Enemies + Hero + Afterimages (2.5D upright billboards)
                mAsciiPaint.setTextAlign(Paint.Align.LEFT);
                for (int lIdx = 0; lIdx < MAX_LOOT; lIdx++) {
                    if (mLootActive[lIdx]) {
                        gen.project25D(mLootX[lIdx], mLootY[lIdx], 0.0f, mCamX, mCamY, camZ, centerX, centerY, pixelsPerUnit, halfUnitsH, mProjTmp);
                        float lx = mProjTmp[0];
                        float ly = mProjTmp[1];
                        float effPpu = pixelsPerUnit * mProjTmp[2];
                        mAsciiPaint.setTextSize(Math.max(10.0f, effPpu * 0.19f));
                        mAsciiPaint.setColor(Color.rgb(245, 212, 98));
                        canvas.drawText("@WM#*+", lx - effPpu * 0.3f, ly, mAsciiPaint);
                    }
                }

                for (int eIdx = 0; eIdx < NUM_ENEMIES; eIdx++) {
                    gen.project25D(mEnemyX[eIdx], mEnemyY[eIdx], 0.0f, mCamX, mCamY, camZ, centerX, centerY, pixelsPerUnit, halfUnitsH, mProjTmp);
                    float ex = mProjTmp[0];
                    float ey = mProjTmp[1];
                    float effPpu = pixelsPerUnit * mProjTmp[2];
                    float enemyCellPx = (effPpu * 2.25f) / ENEMY_BUF_W;
                    if (ex < -140 || ex > screenW + 140 || ey < -140 || ey > screenH + 140) continue;

                    mShadowPaint.setColor(Color.argb(175, 5, 8, 7));
                    mTmpRect.set(ex - effPpu * 0.36f, ey + effPpu * 0.10f, ex + effPpu * 0.56f, ey + effPpu * 0.34f);
                    canvas.drawOval(mTmpRect, mShadowPaint);

                    rasterizeEnemyHumanoidAscii(eIdx);
                    int tint = 0;
                    if (mEnemyHurt[eIdx] > 0.0f) tint = Color.rgb(242, 82, 82);
                    else if (mEnemyAtkWindup[eIdx] > 0.0f) tint = Color.rgb(255, 175, 95);
                    drawAsciiBufferSpanBatched(
                            canvas, mEnemyGlyphBuf, mEnemyColorBuf, ENEMY_BUF_W, ENEMY_BUF_H,
                            ex - (ENEMY_BUF_W * 0.5f) * enemyCellPx,
                            ey - (ENEMY_BUF_H * 0.65f) * enemyCellPx,
                            enemyCellPx, true, tint
                    );
                }

                // Dodge Afterimage Ghosts
                for (int g = 0; g < MAX_AFTERIMAGES; g++) {
                    if (mGhostLife[g] > 0.0f) {
                        gen.project25D(mGhostX[g], mGhostY[g], 0.0f, mCamX, mCamY, camZ, centerX, centerY, pixelsPerUnit, halfUnitsH, mProjTmp);
                        float gx = mProjTmp[0];
                        float gy = mProjTmp[1];
                        float effPpu = pixelsPerUnit * mProjTmp[2];
                        int alpha = Math.max(30, Math.min(180, (int) ((mGhostLife[g] / 0.24f) * 165.0f)));
                        int gCol = Color.argb(alpha, 150, 240, 225);
                        if (mMounted) {
                            drawHorseGlyphs(canvas, gx, gy, effPpu, false, gCol);
                        } else {
                            drawHeroGlyphs(canvas, gx, gy, effPpu, false, gCol);
                        }
                    }
                }

                gen.project25D(mPlayerX, mPlayerY, 0.0f, mCamX, mCamY, camZ, centerX, centerY, pixelsPerUnit, halfUnitsH, mProjTmp);
                float hx = mProjTmp[0];
                float hy = mProjTmp[1];
                float heroPpu = pixelsPerUnit * mProjTmp[2];

                if (mMounted) {
                    mShadowPaint.setColor(Color.argb(185, 4, 7, 6));
                    mTmpRect.set(hx - heroPpu * 0.9f, hy + heroPpu * 0.12f, hx + heroPpu * 1.0f, hy + heroPpu * 0.58f);
                    canvas.drawOval(mTmpRect, mShadowPaint);
                    drawHorseGlyphs(canvas, hx, hy, heroPpu, true,
                            mPlayerHurtFlash > 0.0f ? Color.rgb(255, 95, 95) : 0);
                    // soft strand tail + mane flow over the body
                    mTailFx.draw(canvas, mPlayerX, mPlayerY, hx, hy, heroPpu, Math.max(1.2f, heroPpu * 0.018f), 228, 0.95f);
                    mManeFx.draw(canvas, mPlayerX, mPlayerY, hx, hy, heroPpu, Math.max(1.1f, heroPpu * 0.016f), 232, 0.92f);
                } else {
                    mShadowPaint.setColor(Color.argb(185, 4, 7, 6));
                    mTmpRect.set(hx - heroPpu * 0.35f, hy + heroPpu * 0.14f, hx + heroPpu * 0.75f, hy + heroPpu * 0.42f);
                    canvas.drawOval(mTmpRect, mShadowPaint);

                    mAsciiPaint.setTextSize(Math.max(11.0f, heroPpu * 0.18f));
                    mAsciiPaint.setColor(Color.rgb(232, 236, 234));
                    mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                    canvas.drawText("Ashveil", hx, hy - 1.858f * heroPpu, mAsciiPaint);

                    drawHeroGlyphs(canvas, hx, hy, heroPpu, true,
                            mPlayerHurtFlash > 0.0f ? Color.rgb(255, 95, 95) : 0);
                }

                // short grass blades in front of the hooves
                mGrassFx.drawForeground(canvas, gen, mPlayerX, mPlayerY, mCamX, mCamY, centerX, centerY,
                        pixelsPerUnit, mTimeSec, windScale);

                // Standing stones and boulders in front of the hero
                drawStones(canvas, centerX, centerY, pixelsPerUnit, halfUnitsH, camZ, screenW, screenH, false);

                // Ash / Spark / Firefly Particles
                mAsciiPaint.setTextAlign(Paint.Align.LEFT);
                for (int pIdx = 0; pIdx < MAX_PARTICLES; pIdx++) {
                    if (mPartLife[pIdx] > 0.0f) {
                        gen.project25D(mPartX[pIdx], mPartY[pIdx], 0.15f, mCamX, mCamY, camZ, centerX, centerY, pixelsPerUnit, halfUnitsH, mProjTmp);
                        float px = mProjTmp[0];
                        float py = mProjTmp[1];
                        mAsciiPaint.setTextSize(Math.max(9.0f, pixelsPerUnit * mProjTmp[2] * 0.17f));
                        mAsciiPaint.setColor(mPartColor[pIdx]);
                        canvas.drawText("*", px, py, mAsciiPaint);
                    }
                }

                // Multi-layered Greatsword Slash Crescent
                if (mSlashTimer > 0.0f) {
                    mAsciiPaint.setTextSize(Math.max(13.0f, heroPpu * 0.26f));
                    float baseAng = (float) Math.atan2(mFacingY, mFacingX);
                    for (int a = -6; a <= 6; a++) {
                        float ang = baseAng + a * 0.21f;
                        float rx = hx + (float) Math.cos(ang) * heroPpu * 1.50f;
                        float ry = hy + (float) Math.sin(ang) * heroPpu * 1.20f * WorldGen.PITCH_Y;
                        mAsciiPaint.setColor(Math.abs(a) <= 2 ? Color.rgb(245, 252, 248) : Color.rgb(145, 235, 220));
                        int sIdx = (a + 6) % 4;
                        canvas.drawText("@W#*+", sIdx, sIdx + 1, rx, ry, mAsciiPaint);
                    }
                }

                // Floating Damage Popups
                mUiPaint.setTextAlign(Paint.Align.CENTER);
                for (int k = 0; k < MAX_POPUPS; k++) {
                    if (mPopLife[k] > 0.0f && mPopText[k] != null) {
                        gen.project25D(mPopX[k], mPopY[k], 0.25f, mCamX, mCamY, camZ, centerX, centerY, pixelsPerUnit, halfUnitsH, mProjTmp);
                        mUiPaint.setTextSize(Math.max(13.0f, pixelsPerUnit * mProjTmp[2] * 0.22f));
                        mUiPaint.setColor(mPopColor[k]);
                        canvas.drawText(mPopText[k], mProjTmp[0], mProjTmp[1], mUiPaint);
                    }
                }

                // 5. Additive Glowing Lanterns & Runestones + 2.5D Horizon Mist + Vignette
                for (int oi = 0; oi < mObjs.size(); oi++) {
                    WorldGen.Obj o = mObjs.get(oi);
                    if (o.kind == WorldGen.PILLAR || o.kind == WorldGen.BOULDER) continue;
                    boolean cyan = (o.kind != WorldGen.HOUSE);
                    mGlowPaint.setAlpha(o.kind == WorldGen.CAVE ? 85 : 255);
                    gen.project25D(o.x, o.y + (o.kind == WorldGen.HOUSE ? 0.8f : 0.0f),
                            o.kind == WorldGen.CAVE ? o.h * 0.4f : 0.0f,
                            mCamX, mCamY, camZ, centerX, centerY, pixelsPerUnit, halfUnitsH, mProjTmp);
                    float gx = mProjTmp[0];
                    float gy = mProjTmp[1];
                    float effPpu = pixelsPerUnit * mProjTmp[2];
                    float gRad = effPpu * ((o.kind == WorldGen.CAVE ? 2.0f : 2.6f) + 0.25f * (float) Math.sin(mTimeSec * 3.5f + oi));
                    if (gx < -gRad || gx > screenW + gRad || gy < -gRad || gy > screenH + gRad) continue;
                    mTmpRect.set(gx - gRad, gy - gRad, gx + gRad, gy + gRad);
                    canvas.drawBitmap(cyan ? mCyanGlowBitmap : mAmberGlowBitmap, null, mTmpRect, mGlowPaint);
                }
                mGlowPaint.setAlpha(255);

                // Wispy drifting fog
                float moistHere = gen.moisture(mCamX, mCamY);
                int fogA = (int) (255.0f * Math.max(0.35f, Math.min(1.0f, 0.45f + moistHere * 0.9f)));
                for (int layer = 0; layer < 1; layer++) {
                    float tileUnits = (layer == 0) ? 9.0f : 14.0f;
                    float sc = tileUnits * pixelsPerUnit / 256.0f;
                    float ddx = ((layer == 0) ? 0.55f : -0.32f) * mTimeSec;
                    float ddy = ((layer == 0) ? 0.18f : 0.26f) * mTimeSec;
                    mFogMatrix[layer].setScale(sc, sc * WorldGen.PITCH_Y);
                    mFogMatrix[layer].postTranslate(centerX + (ddx - mCamX) * pixelsPerUnit + layer * 77.0f,
                            centerY + (ddy - mCamY) * pixelsPerUnit * WorldGen.PITCH_Y - layer * 53.0f);
                    mFogShader[layer].setLocalMatrix(mFogMatrix[layer]);
                    mFogPaint[layer].setAlpha(layer == 0 ? fogA : (fogA * 3) / 4);
                    canvas.drawRect(0, 0, screenW, screenH, mFogPaint[layer]);
                }

                // 2.5D Horizon atmospheric depth haze at the top of the viewport
                if (mHorizonBitmap != null) {
                    mTmpRect.set(0, 0, screenW, screenH * 0.24f);
                    canvas.drawBitmap(mHorizonBitmap, null, mTmpRect, mBitmapPaint);
                }

                mTmpRect.set(0, 0, screenW, screenH);
                canvas.drawBitmap(mVignetteBitmap, null, mTmpRect, mBitmapPaint);

                if (mScreenMode == 1) {
                    float curX = mCursorX * screenW;
                    float curY = mCursorY * screenH;
                    float arm = Math.min(screenW, screenH) * 0.017f;
                    mBorderPaint.setColor(Color.argb(215, 236, 241, 238));
                    mBorderPaint.setStrokeWidth(2.2f);
                    canvas.drawLine(curX - arm, curY, curX + arm, curY, mBorderPaint);
                    canvas.drawLine(curX, curY - arm, curX, curY + arm, mBorderPaint);
                }

                // 6. Clean Modern Non-ASCII GUI Overlays
                if (mScreenMode == 0) {
                    drawStartMenuOverlay(canvas, screenW, screenH);
                } else if (mScreenMode == 1) {
                    drawModernHud(canvas, screenW, screenH);
                } else if (mScreenMode == 2) {
                    drawCharacterAndInventoryModal(canvas, screenW, screenH);
                }
            } finally {
                if (canvas != null) {
                    holder.unlockCanvasAndPost(canvas);
                }
            }
        }


        private final float[] mSpriteBaseTmp = new float[2];

        /** Standing stones and boulders as cached 2.5D upright glyph billboards, y-sorted against the hero. */
        private void drawStones(Canvas canvas, float centerX, float centerY, float ppu, float halfH, float camZ,
                                int screenW, int screenH, boolean behind) {
            final WorldGen gen = mGen;
            for (int oi = 0; oi < mObjs.size(); oi++) {
                WorldGen.Obj o = mObjs.get(oi);
                if (o.kind != WorldGen.PILLAR && o.kind != WorldGen.BOULDER) continue;
                if ((o.y <= mPlayerY) != behind) continue;
                gen.project25D(o.x, o.y, 0.0f, mCamX, mCamY, camZ, centerX, centerY, ppu, halfH, mProjTmp);
                float sx = mProjTmp[0];
                float sy = mProjTmp[1];
                float effPpu = ppu * mProjTmp[2];
                float scale = effPpu / Gfx.SPRITE_PPU;
                float reachX = o.w * effPpu;
                float top0 = sy - (o.h + o.w * 0.2f) * effPpu;
                float bot0 = sy + o.w * 0.2f * effPpu;
                if (bot0 < 0 || top0 > screenH || sx < -reachX || sx > screenW + reachX) continue;
                Bitmap b = spriteFor(o, mSpriteBaseTmp);
                mShadowPaint.setColor(Color.argb(165, 2, 5, 4));
                mTmpRect.set(sx - o.w * 0.55f * effPpu, sy - o.w * 0.10f * effPpu, sx + o.w * 1.0f * effPpu, sy + o.w * 0.24f * effPpu);
                canvas.drawOval(mTmpRect, mShadowPaint);
                if (b == null) continue;
                float left = sx - mSpriteBaseTmp[0] * scale;
                float top = sy - mSpriteBaseTmp[1] * scale;
                mTmpRect.set(left, top, left + b.getWidth() * scale, top + b.getHeight() * scale);
                canvas.drawBitmap(b, null, mTmpRect, mBitmapPaint);
            }
        }

        private static float h01(int a) {
            int x = a * 0x9E3779B1;
            x ^= (x >>> 15);
            x *= 0x85EBCA6B;
            x ^= (x >>> 13);
            return (x & 0xFFFF) / 65535.0f;
        }

        /** A dark cavity with twinkling cyan-white motes, like the "Moonlit Cave" clip. */
        private void drawCaveMouth(Canvas canvas, WorldGen.Obj o, float cx, float cy, float ppu) {
            float rw = o.w * 0.5f * ppu;
            float rh = o.h * 0.5f * ppu;
            mShadowPaint.setColor(Color.argb(150, 2, 4, 6));
            mTmpRect.set(cx - rw * 1.25f, cy - rh * 1.95f, cx + rw * 1.25f, cy + rh * 0.55f);
            canvas.drawOval(mTmpRect, mShadowPaint);
            mShadowPaint.setColor(Color.rgb(2, 4, 7));
            mTmpRect.set(cx - rw, cy - rh * 1.6f, cx + rw, cy + rh * 0.35f);
            canvas.drawOval(mTmpRect, mShadowPaint);
            mAsciiPaint.setTextAlign(Paint.Align.CENTER);
            mAsciiPaint.setTextSize(Math.max(8.0f, ppu * 0.12f));
            mAsciiPaint.setColor(Color.argb(120, 70, 92, 118));
            for (int r = 0; r < 4; r++) {
                canvas.drawText(". : . : . : .", cx, cy - rh * 1.2f + r * ppu * 0.24f, mAsciiPaint);
            }
            for (int k = 0; k < 26; k++) {
                float ax = h01(o.variant + k * 31 + 1);
                float ay = h01(o.variant + k * 57 + 7);
                float tw = 0.5f + 0.5f * (float) Math.sin(mTimeSec * 2.4f + k * 1.7f);
                float mx = cx + (ax - 0.5f) * 1.7f * rw;
                float my = cy - rh * 1.5f + ay * rh * 1.7f;
                mPanelPaint.setColor(Color.argb((int) (80 + 160 * tw), 190, 250, 240));
                canvas.drawCircle(mx, my, Math.max(1.4f, ppu * (0.010f + 0.012f * tw)), mPanelPaint);
            }
        }

        /** Animated 2.5D foam streaks hugging the shoreline, plus the hero reflected in the water. */
        private void drawWaterEffects(Canvas canvas, float centerX, float centerY, float ppu, float halfW, float halfH, float camZ) {
            final WorldGen gen = mGen;
            int nb = 0;
            int nd = 0;
            final float step = 0.9f;
            float x0 = (float) Math.floor((mCamX - halfW) / step) * step;
            float y0 = (float) Math.floor((mCamY - halfH) / step) * step;
            for (float wy = y0; wy <= mCamY + halfH; wy += step) {
                for (float wx = x0; wx <= mCamX + halfW; wx += step) {
                    int hx = (int) Math.floor(wx / step);
                    int hy = (int) Math.floor(wy / step);
                    float jx = wx + (gen.hash01(hx, hy, 1) - 0.5f) * step;
                    float jy = wy + (gen.hash01(hx, hy, 2) - 0.5f) * step;
                    float d = gen.waterDepth(jx, jy);
                    if (d <= 0.0f || d > 0.13f) continue;
                    float e = 0.25f;
                    float gx = gen.waterDepth(jx + e, jy) - gen.waterDepth(jx - e, jy);
                    float gy = gen.waterDepth(jx, jy + e) - gen.waterDepth(jx, jy - e);
                    float gl = (float) Math.sqrt(gx * gx + gy * gy);
                    if (gl < 1e-4f) continue;
                    float nxs = gx / gl;
                    float nys = gy / gl;
                    float tx = -nys;
                    float ty = nxs;
                    float ph = mTimeSec * 0.9f + gen.hash01(hx, hy, 3) * 6.2832f;
                    float k = 0.5f + 0.5f * (float) Math.sin(ph);
                    if (k < 0.22f) continue;
                    float drift = (float) Math.sin(ph * 0.7f) * 0.14f;
                    float len = 0.55f + gen.hash01(hx, hy, 4) * 0.6f;
                    float cxw = jx + nxs * drift;
                    float cyw = jy + nys * drift;
                    float bend = 0.10f * (float) Math.sin(ph * 1.3f);
                    gen.project25D(cxw - tx * len * 0.5f, cyw - ty * len * 0.5f, 0.0f, mCamX, mCamY, camZ, centerX, centerY, ppu, halfH, mProjTmp);
                    float p0x = mProjTmp[0], p0y = mProjTmp[1];
                    gen.project25D(cxw + nxs * bend, cyw + nys * bend, 0.0f, mCamX, mCamY, camZ, centerX, centerY, ppu, halfH, mProjTmp);
                    float p1x = mProjTmp[0], p1y = mProjTmp[1];
                    gen.project25D(cxw + tx * len * 0.5f, cyw + ty * len * 0.5f, 0.0f, mCamX, mCamY, camZ, centerX, centerY, ppu, halfH, mProjTmp);
                    float p2x = mProjTmp[0], p2y = mProjTmp[1];
                    float[] arr = (k > 0.7f) ? mFoamBright : mFoamDim;
                    int cnt = (k > 0.7f) ? nb : nd;
                    if (cnt + 8 > arr.length) continue;
                    arr[cnt++] = p0x; arr[cnt++] = p0y; arr[cnt++] = p1x; arr[cnt++] = p1y;
                    arr[cnt++] = p1x; arr[cnt++] = p1y; arr[cnt++] = p2x; arr[cnt++] = p2y;
                    if (k > 0.7f) nb = cnt; else nd = cnt;
                }
            }
            mGrassPaint.setStrokeWidth(Math.max(1.8f, ppu * 0.022f));
            if (nd > 0) {
                mGrassPaint.setColor(Color.argb(150, 120, 150, 188));
                canvas.drawLines(mFoamDim, 0, nd, mGrassPaint);
            }
            if (nb > 0) {
                mGrassPaint.setStrokeWidth(Math.max(2.2f, ppu * 0.03f));
                mGrassPaint.setColor(Color.argb(235, 226, 238, 250));
                canvas.drawLines(mFoamBright, 0, nb, mGrassPaint);
            }

            if (gen.waterDepth(mPlayerX, mPlayerY + 0.45f) > 0.0f) {
                gen.project25D(mPlayerX, mPlayerY, 0.0f, mCamX, mCamY, camZ, centerX, centerY, ppu, halfH, mProjTmp);
                float hx = mProjTmp[0];
                float hy = mProjTmp[1];
                float effPpu = ppu * mProjTmp[2];
                int reflCol = Color.argb(88, 140, 175, 205);
                canvas.save();
                canvas.scale(1.0f, -WorldGen.PITCH_Y, hx, hy + effPpu * 0.18f);
                if (mMounted) {
                    drawHorseGlyphs(canvas, hx, hy, effPpu, false, reflCol);
                } else {
                    drawHeroGlyphs(canvas, hx, hy, effPpu, false, reflCol);
                }
                canvas.restore();
            }
        }

        private void drawStartMenuOverlay(Canvas canvas, int w, int h) {
            mPanelPaint.setColor(Color.argb(120, 5, 9, 8));
            canvas.drawRect(0, 0, w, h, mPanelPaint);

            mUiPaint.setTextAlign(Paint.Align.CENTER);
            float titleSize = Math.min(w, h) * 0.085f;
            mUiPaint.setTextSize(titleSize);
            mUiPaint.setColor(Color.rgb(244, 248, 245));
            canvas.drawText("A S H V E I L", w * 0.5f, h * 0.20f, mUiPaint);

            mUiSubPaint.setTextAlign(Paint.Align.CENTER);
            mUiSubPaint.setTextSize(titleSize * 0.36f);
            mUiSubPaint.setColor(Color.rgb(185, 204, 194));
            canvas.drawText("Offline Dark-Fantasy ASCII RPG", w * 0.5f, h * 0.26f, mUiSubPaint);

            float btnTextSize = Math.min(w, h) * 0.031f;
            mUiPaint.setTextSize(btnTextSize);

            String zoomLabel = (mZoomPreset == 0) ? "Close-up" : (mZoomPreset == 1 ? "Medium" : "Wide");
            String modeLabel = mMounted ? "Mounted Steed" : "Foot Knight";
            String atkLabel = mAttackButtonOnly ? "Action Button" : "Tap Anywhere";

            String[] buttons = {
                    "[ Enter the World ]",
                    null,
                    "Camera Zoom: " + zoomLabel,
                    "Style: " + modeLabel,
                    "Attack Mode: " + atkLabel,
                    "Character, Inventory & Forge (Lv." + mLevel + ")"
            };
            for (int b = 0; b < buttons.length; b++) {
                float top = h * MENU_TOPS[b];
                float bot = top + h * MENU_H;
                if (buttons[b] == null) {
                    // world row: two half-width buttons, [ New World ] and [ Seed ]
                    String[] half = {"[ New World ]", "Seed: " + mWorldSeed};
                    for (int k = 0; k < 2; k++) {
                        float l = (k == 0) ? w * 0.22f : w * 0.505f;
                        float r = (k == 0) ? w * 0.495f : w * 0.78f;
                        mTmpRect.set(l, top, r, bot);
                        mPanelPaint.setColor(Color.argb(225, 4, 6, 8));
                        canvas.drawRect(mTmpRect, mPanelPaint);
                        mBorderPaint.setColor(Color.rgb(150, 160, 165));
                        canvas.drawRect(mTmpRect, mBorderPaint);
                        mUiPaint.setTextSize(btnTextSize * (k == 1 ? 0.92f : 1.0f));
                        mUiPaint.setColor(Color.rgb(242, 246, 244));
                        canvas.drawText(half[k], (l + r) * 0.5f, (top + bot) * 0.5f + btnTextSize * 0.35f, mUiPaint);
                    }
                    mUiPaint.setTextSize(btnTextSize);
                    continue;
                }
                mTmpRect.set(w * 0.22f, top, w * 0.78f, bot);
                mPanelPaint.setColor(b == 0 ? Color.argb(235, 10, 26, 20) : Color.argb(225, 4, 6, 8));
                canvas.drawRect(mTmpRect, mPanelPaint);
                mBorderPaint.setColor(b == 0 ? Color.rgb(155, 232, 185) : Color.rgb(150, 160, 165));
                canvas.drawRect(mTmpRect, mBorderPaint);
                mUiPaint.setColor(Color.rgb(242, 246, 244));
                canvas.drawText(buttons[b], w * 0.5f, (top + bot) * 0.5f + btnTextSize * 0.35f, mUiPaint);
            }
        }

        /** Tick-mark bar like the reference: a light outline filled with vertical strokes. */
        private void drawTickBar(Canvas canvas, float x, float y, float bw, float bh, float ratio, int tickColor) {
            mTmpRect.set(x, y, x + bw, y + bh);
            mBorderPaint.setColor(Color.rgb(205, 208, 212));
            mBorderPaint.setStrokeWidth(1.6f);
            canvas.drawRect(mTmpRect, mBorderPaint);
            float pitch = Math.max(3.0f, bh * 0.26f);
            int ticks = (int) ((bw - 6.0f) / pitch);
            int lit = (int) (ticks * Math.max(0.0f, Math.min(1.0f, ratio)) + 0.5f);
            lit = Math.min(lit, mTickPts.length / 4);
            for (int i = 0; i < lit; i++) {
                float tx = x + 4.0f + i * pitch;
                mTickPts[i * 4] = tx;
                mTickPts[i * 4 + 1] = y + 3.0f;
                mTickPts[i * 4 + 2] = tx;
                mTickPts[i * 4 + 3] = y + bh - 3.0f;
            }
            mGrassPaint.setStrokeWidth(1.5f);
            mGrassPaint.setColor(tickColor);
            if (lit > 0) canvas.drawLines(mTickPts, 0, lit * 4, mGrassPaint);
            mBorderPaint.setStrokeWidth(2.2f);
        }

        private void drawModernHud(Canvas canvas, int w, int h) {
            // Top-left status plate: black, light-grey frame, ASCII portrait, tick-mark HP / MP bars
            float cardW = Math.min(w * 0.46f, 520.0f);
            float cardH = cardW * 0.345f;
            float x0 = 8.0f;
            float y0 = 10.0f;
            mTmpRect.set(x0, y0, x0 + cardW, y0 + cardH);
            mPanelPaint.setColor(Color.rgb(0, 0, 0));
            canvas.drawRect(mTmpRect, mPanelPaint);
            mBorderPaint.setColor(Color.rgb(176, 178, 180));
            mBorderPaint.setStrokeWidth(3.0f);
            canvas.drawRect(mTmpRect, mBorderPaint);
            mBorderPaint.setStrokeWidth(2.2f);

            float pcellH = (cardH * 0.80f) / FOOT_BUF_H;
            drawHeroGlyphsAt(canvas, x0 + cardW * 0.045f, y0 + cardH * 0.10f, pcellH / 1.3f, pcellH, false, 0);

            float colX = x0 + cardW * 0.235f;
            mUiPaint.setTextAlign(Paint.Align.LEFT);
            mUiPaint.setTextSize(cardH * 0.17f);
            mUiPaint.setColor(Color.rgb(232, 236, 238));
            canvas.drawText("Ashveil", colX, y0 + cardH * 0.27f, mUiPaint);

            float barX = colX + cardW * 0.075f;
            float barW = cardW * 0.375f;
            float barH = cardH * 0.135f;
            float numX = barX + barW + cardW * 0.02f;
            mUiSubPaint.setTextAlign(Paint.Align.LEFT);
            mUiSubPaint.setTextSize(cardH * 0.125f);

            float hpY = y0 + cardH * 0.345f;
            mUiSubPaint.setColor(Color.rgb(205, 208, 212));
            canvas.drawText("HP", colX, hpY + barH * 0.95f, mUiSubPaint);
            drawTickBar(canvas, barX, hpY, barW, barH, mHp / (float) Math.max(1, mMaxHp), Color.rgb(214, 218, 222));
            mUiSubPaint.setColor(Color.rgb(226, 230, 232));
            canvas.drawText(mHp + "/" + mMaxHp, numX, hpY + barH * 0.95f, mUiSubPaint);

            float mpY = y0 + cardH * 0.54f;
            mUiSubPaint.setColor(Color.rgb(205, 208, 212));
            canvas.drawText("MP", colX, mpY + barH * 0.95f, mUiSubPaint);
            drawTickBar(canvas, barX, mpY, barW, barH, mMp / (float) Math.max(1, mMaxMp), Color.rgb(214, 218, 222));
            mUiSubPaint.setColor(Color.rgb(226, 230, 232));
            canvas.drawText(mMp + "/" + mMaxMp, numX, mpY + barH * 0.95f, mUiSubPaint);

            mUiSubPaint.setColor(Color.rgb(226, 230, 232));
            canvas.drawText("LV " + mLevel + " \u00B7 " + mGold + "g" + (mStatPoints > 0 ? "  *+STAT*" : ""), colX, y0 + cardH * 0.86f, mUiSubPaint);

            // Top-right bracket buttons: [MENU] [ZOOM] [STEED]
            float pillW = Math.min(w * 0.18f, 172.0f);
            float pillH = Math.max(36.0f, cardH * 0.34f);
            float px = w - pillW - 18.0f;
            String[] pills = {"[MENU]", "[ZOOM]", mMounted ? "[DISMOUNT]" : "[STEED]"};
            for (int i = 0; i < 3; i++) {
                float py = y0 + i * (pillH + 8.0f);
                mTmpRect.set(px, py, px + pillW, py + pillH);
                mPanelPaint.setColor(Color.rgb(0, 0, 0));
                canvas.drawRect(mTmpRect, mPanelPaint);
                mBorderPaint.setColor((i == 2 && mMounted) ? Color.rgb(155, 232, 185) : Color.rgb(200, 203, 206));
                canvas.drawRect(mTmpRect, mBorderPaint);
                mUiPaint.setTextAlign(Paint.Align.CENTER);
                mUiPaint.setTextSize(pillH * 0.40f);
                mUiPaint.setColor(Color.rgb(240, 245, 242));
                canvas.drawText(pills[i], px + pillW * 0.5f, py + pillH * 0.64f, mUiPaint);
            }

            // Bottom-right round buttons: [ATK] and [DODGE]
            float atkR = Math.min(w, h) * 0.088f;
            float atkCx = w - atkR - 26.0f;
            float atkCy = h - atkR - 26.0f - btnLift(w, h);
            mPanelPaint.setColor(mSlashTimer > 0.0f ? Color.argb(235, 70, 74, 76) : Color.argb(190, 4, 6, 8));
            mBorderPaint.setColor(mSlashCooldown > 0.0f ? Color.rgb(110, 118, 120) : Color.rgb(236, 240, 242));
            canvas.drawCircle(atkCx, atkCy, atkR, mPanelPaint);
            canvas.drawCircle(atkCx, atkCy, atkR, mBorderPaint);
            mUiPaint.setTextSize(atkR * 0.40f);
            mUiPaint.setColor(Color.rgb(245, 248, 246));
            canvas.drawText("[ATK]", atkCx, atkCy + atkR * 0.15f, mUiPaint);

            float dodgeR = Math.min(w, h) * 0.070f;
            float dodgeCx = atkCx - atkR - dodgeR - 22.0f;
            float dodgeCy = h - dodgeR - 26.0f - btnLift(w, h);
            mPanelPaint.setColor(mDodgeTimer > 0.0f ? Color.argb(235, 42, 98, 106) : Color.argb(190, 4, 8, 10));
            mBorderPaint.setColor(mDodgeCooldown > 0.0f ? Color.rgb(95, 112, 118) : Color.rgb(145, 228, 220));
            canvas.drawCircle(dodgeCx, dodgeCy, dodgeR, mPanelPaint);
            canvas.drawCircle(dodgeCx, dodgeCy, dodgeR, mBorderPaint);
            mUiPaint.setTextSize(dodgeR * 0.32f);
            mUiPaint.setColor(mDodgeCooldown > 0.0f ? Color.rgb(145, 162, 166) : Color.rgb(226, 238, 240));
            canvas.drawText(mDodgeCooldown > 0.0f ? (((int) (mDodgeCooldown * 10.0f + 0.9f) / 10.0f) + "s") : "[DODGE]", dodgeCx, dodgeCy + dodgeR * 0.12f, mUiPaint);

            // Virtual joystick ring
            if (mMovePointerId != -1) {
                mBorderPaint.setColor(Color.argb(130, 195, 228, 210));
                canvas.drawCircle(mJoyBaseX, mJoyBaseY, Math.min(w, h) * 0.11f, mBorderPaint);
                mPanelPaint.setColor(Color.argb(150, 215, 240, 225));
                canvas.drawCircle(mJoyCurrX, mJoyCurrY, Math.min(w, h) * 0.036f, mPanelPaint);
            }

            // Bottom: gold XP bar with centred label, then a numbered 1..0 hotbar grid (like the reference)
            float hbW = hbWidth(w, h);
            float hbX = (w - hbW) * 0.5f;
            float slotH = hbSlotH(hbW);
            float hbY = h - slotH;
            float xpH = 20.0f;
            float xpY = hbY - xpH - 2.0f;
            float xpRatio = Math.max(0.0f, Math.min(1.0f, mXp / (float) Math.max(1, mXpNext)));
            mTmpRect.set(hbX, xpY, hbX + hbW, xpY + xpH);
            mPanelPaint.setColor(Color.rgb(8, 9, 9));
            canvas.drawRect(mTmpRect, mPanelPaint);
            mTmpRect.set(hbX + 2.0f, xpY + 2.0f, hbX + 2.0f + (hbW - 4.0f) * xpRatio, xpY + xpH - 2.0f);
            mPanelPaint.setColor(Color.rgb(214, 176, 86));
            canvas.drawRect(mTmpRect, mPanelPaint);
            int xpTicks = Math.min(mTickPts.length / 4, (int) ((hbW - 4.0f) * xpRatio / 4.0f));
            for (int i = 0; i < xpTicks; i++) {
                float tx = hbX + 4.0f + i * 4.0f;
                mTickPts[i * 4] = tx;
                mTickPts[i * 4 + 1] = xpY + 2.0f;
                mTickPts[i * 4 + 2] = tx;
                mTickPts[i * 4 + 3] = xpY + xpH - 2.0f;
            }
            mGrassPaint.setStrokeWidth(1.0f);
            mGrassPaint.setColor(Color.argb(110, 90, 66, 20));
            if (xpTicks > 0) canvas.drawLines(mTickPts, 0, xpTicks * 4, mGrassPaint);
            mTmpRect.set(hbX, xpY, hbX + hbW, xpY + xpH);
            mBorderPaint.setColor(Color.rgb(150, 154, 158));
            mBorderPaint.setStrokeWidth(1.6f);
            canvas.drawRect(mTmpRect, mBorderPaint);
            mBorderPaint.setStrokeWidth(2.2f);
            mUiSubPaint.setTextAlign(Paint.Align.CENTER);
            mUiSubPaint.setTextSize(xpH * 0.62f);
            mUiSubPaint.setColor(Color.rgb(14, 12, 6));
            canvas.drawText("LV " + mLevel + " \u00B7 " + mXp + " / " + mXpNext + " XP", w * 0.5f + 1.0f, xpY + xpH * 0.74f + 1.0f, mUiSubPaint);
            mUiSubPaint.setColor(Color.rgb(246, 244, 232));
            canvas.drawText("LV " + mLevel + " \u00B7 " + mXp + " / " + mXpNext + " XP", w * 0.5f, xpY + xpH * 0.74f, mUiSubPaint);

            float slotW = hbW / 10.0f;
            mTmpRect.set(hbX, hbY, hbX + hbW, h);
            mPanelPaint.setColor(Color.rgb(0, 0, 0));
            canvas.drawRect(mTmpRect, mPanelPaint);
            for (int sIdx = 0; sIdx < 10; sIdx++) {
                float sx0 = hbX + sIdx * slotW;
                mTmpRect.set(sx0, hbY, sx0 + slotW, h + 2.0f);
                mBorderPaint.setColor(sIdx == 0 ? Color.rgb(145, 225, 195) : Color.rgb(120, 124, 128));
                mBorderPaint.setStrokeWidth(1.4f);
                canvas.drawRect(mTmpRect, mBorderPaint);
                mUiSubPaint.setTextSize(slotH * 0.22f);
                mUiSubPaint.setColor(Color.rgb(196, 200, 204));
                canvas.drawText(String.valueOf((sIdx + 1) % 10), sx0 + slotW * 0.5f, hbY + slotH * 0.28f, mUiSubPaint);
                if (sIdx == 0 && mPotions > 0) {
                    mUiSubPaint.setColor(Color.rgb(155, 245, 215));
                    canvas.drawText("x" + mPotions, sx0 + slotW * 0.5f, hbY + slotH * 0.62f, mUiSubPaint);
                }
            }
            mBorderPaint.setStrokeWidth(2.2f);

            if (mBannerTimer > 0.0f) {
                mUiSubPaint.setTextAlign(Paint.Align.CENTER);
                mUiSubPaint.setTextSize(Math.min(w, h) * 0.026f);
                mUiSubPaint.setColor(Color.rgb(245, 238, 195));
                canvas.drawText(mStatusBanner, w * 0.5f, xpY - 14.0f, mUiSubPaint);
            }
        }

        private static final int[] RUNE_COLS = {
                0xFFE8504A, 0xFF6CC8F0, 0xFFE8D060, 0xFFE86088, 0xFF58D890, 0xFF78E0A8,
                0xFF9060E8, 0xFF60D868, 0xFFE8E8E8, 0xFF78F0A0, 0xFFE05050
        };

        private void drawDashedRect(Canvas canvas, float l, float t, float r, float b, int col) {
            mGrassPaint.setStrokeWidth(1.4f);
            mGrassPaint.setColor(col);
            int n = 0;
            float d = 7.0f;
            for (float x = l; x < r - d; x += d * 2.0f) {
                mTickPts[n++] = x; mTickPts[n++] = t; mTickPts[n++] = x + d; mTickPts[n++] = t;
                mTickPts[n++] = x; mTickPts[n++] = b; mTickPts[n++] = x + d; mTickPts[n++] = b;
            }
            for (float y = t; y < b - d; y += d * 2.0f) {
                mTickPts[n++] = l; mTickPts[n++] = y; mTickPts[n++] = l; mTickPts[n++] = y + d;
                mTickPts[n++] = r; mTickPts[n++] = y; mTickPts[n++] = r; mTickPts[n++] = y + d;
            }
            canvas.drawLines(mTickPts, 0, n, mGrassPaint);
        }

        private void drawCharacterAndInventoryModal(Canvas canvas, int w, int h) {
            // Pure Black Forge Canvas matching `1000461485.jpg` (Chainmail test)!
            mPanelPaint.setColor(Color.rgb(4, 5, 6));
            canvas.drawRect(0, 0, w, h, mPanelPaint);

            String[] slots = {"Helm", "Shoulders", "Chest", "Gloves", "Legs", "Boots"};
            String[] runes = {"^", "*", "z", "~", ">", "/", "x", "v", "o", "\u00a7", "+"};
            String[] metals = {"Iron", "Steel", "Bronze", "Silver", "Gold", "Moonsteel", "Nightglass", "Bloodiron", "Ossite", "Emberstone"};
            int[] metalCols = {
                    Color.rgb(185, 192, 198), Color.rgb(218, 226, 234), Color.rgb(208, 152, 96),
                    Color.rgb(238, 242, 248), Color.rgb(246, 212, 92), Color.rgb(156, 208, 250),
                    Color.rgb(142, 128, 196), Color.rgb(220, 78, 86), Color.rgb(225, 218, 196),
                    Color.rgb(248, 146, 72)
            };

            String[] metalTag = {"#%:", "@%.", "&o,", "$s.", "0o.", "0\u00B0\u00B7", "", "88:", "=-.", "*+."};
            String[] itemNames = {"Coif", "Pauldrons", "Hauberk", "Gauntlets", "Greaves", "Sabatons"};

            float ts = Math.min(w, h) * 0.025f;
            mUiPaint.setTextSize(ts);
            mUiSubPaint.setTextSize(ts * 0.88f);

            // header: "<Metal> Mail <Piece>" in spaced monospace, like the reference
            mAsciiPaint.setTextAlign(Paint.Align.CENTER);
            mAsciiPaint.setTextSize(ts * 1.05f);
            mAsciiPaint.setColor(Color.rgb(214, 218, 222));
            canvas.drawText((metals[mForgeMetal] + " Mail " + itemNames[mForgeSlot]).replace("", " ").trim(), w * 0.5f, h * 0.033f, mAsciiPaint);

            // 1. Slot Tabs
            float slotW = (w * 0.88f) / 6.0f;
            for (int i = 0; i < 6; i++) {
                float sx = w * 0.06f + i * slotW;
                mTmpRect.set(sx + 2f, h * 0.05f, sx + slotW - 2f, h * 0.11f);
                mPanelPaint.setColor(i == mForgeSlot ? Color.rgb(34, 42, 32) : Color.rgb(12, 14, 16));
                canvas.drawRect(mTmpRect, mPanelPaint);
                mBorderPaint.setColor(i == mForgeSlot ? Color.rgb(218, 212, 145) : Color.rgb(68, 74, 78));
                canvas.drawRect(mTmpRect, mBorderPaint);
                mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                mAsciiPaint.setTextSize(ts * 0.95f);
                mAsciiPaint.setColor(Color.rgb(235, 238, 236));
                canvas.drawText(slots[i], sx + slotW * 0.5f, h * 0.088f, mAsciiPaint);
            }

            // 2. Rune Palette Row
            float rW = (w * 0.88f) / 11.0f;
            for (int i = 0; i < 11; i++) {
                float rx = w * 0.06f + i * rW;
                mTmpRect.set(rx + 2f, h * 0.13f, rx + rW - 2f, h * 0.20f);
                mPanelPaint.setColor(Color.rgb(10, 12, 14));
                canvas.drawRect(mTmpRect, mPanelPaint);
                mBorderPaint.setColor(Color.rgb(65, 72, 76));
                canvas.drawRect(mTmpRect, mBorderPaint);
                mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                mAsciiPaint.setTextSize(ts * 1.1f);
                mAsciiPaint.setColor(RUNE_COLS[i]);
                canvas.drawText(runes[i], rx + rW * 0.5f, h * 0.178f, mAsciiPaint);
            }

            // 3. Metal Material Grid (2 rows x 5)
            float mW = (w * 0.88f) / 5.0f;
            for (int i = 0; i < 10; i++) {
                int row = i / 5;
                int col = i % 5;
                float mx = w * 0.06f + col * mW;
                float my = h * (0.22f + row * 0.042f);
                mTmpRect.set(mx + 2f, my, mx + mW - 2f, my + h * 0.038f);
                mPanelPaint.setColor(i == mForgeMetal ? Color.rgb(28, 34, 28) : Color.rgb(10, 12, 13));
                canvas.drawRect(mTmpRect, mPanelPaint);
                mBorderPaint.setColor(i == mForgeMetal ? metalCols[i] : Color.rgb(55, 60, 64));
                canvas.drawRect(mTmpRect, mBorderPaint);
                mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                mAsciiPaint.setTextSize(ts * 0.8f);
                mAsciiPaint.setColor(metalCols[i]);
                canvas.drawText((metalTag[i].isEmpty() ? "" : metalTag[i] + " ") + metals[i], mx + mW * 0.5f, my + h * 0.026f, mAsciiPaint);
            }

            // 4. Live Rotating 3D ASCII Chainmail Coif / Armor Preview (Center-Left, matching 1000461485.jpg!)
            float coifCx = w * 0.40f;
            float coifCy = h * 0.58f;
            float coifR = Math.min(w, h) * 0.20f;
            String chainChars = "S8$#c()35";
            mAsciiPaint.setTextAlign(Paint.Align.CENTER);
            mAsciiPaint.setTextSize(Math.max(8.0f, coifR * 0.062f));
            int rings = 34;
            for (int yr = -rings; yr <= rings; yr++) {
                float ny = yr / (float) rings;
                float profile = (ny < -0.15f) ? (float) Math.sqrt(Math.max(0.0f, 1.0f - ((ny + 0.35f) * (ny + 0.35f)) * 1.4f)) * 0.58f
                        : (0.56f + (ny + 0.15f) * 0.48f);
                int cols = Math.max(6, (int) (profile * 46));
                for (int xc = -cols; xc <= cols; xc++) {
                    // each ring is offset a little from the last, so the links read as a spiral weave
                    float angle = ((xc + (yr & 1) * 0.5f) / (float) Math.max(1, cols)) * (float) Math.PI + mCoifRot;
                    float nz = (float) Math.cos(angle);
                    if (nz < -0.10f) continue;
                    if (ny > -0.45f && ny < -0.12f && Math.abs((float) Math.sin(angle)) < 0.32f && nz > 0.4f) continue;
                    float sx = coifCx + (float) Math.sin(angle) * profile * coifR;
                    float sy = coifCy + ny * coifR * 1.05f;
                    int lum = Math.max(110, Math.min(255, (int) (nz * 150 + 105)));
                    int baseC = metalCols[mForgeMetal];
                    mAsciiPaint.setColor(Color.rgb(
                            Math.min(255, (Color.red(baseC) * lum) / 200),
                            Math.min(255, (Color.green(baseC) * lum) / 200),
                            Math.min(255, (Color.blue(baseC) * lum) / 200)
                    ));
                    mSingleChar[0] = chainChars.charAt(Math.abs(yr * 7 + xc * 3) % chainChars.length());
                    canvas.drawText(mSingleChar, 0, 1, sx, sy, mAsciiPaint);
                }
            }

            // 5. Right Panel: Enchant Slots & Stats
            float rpX = w * 0.72f;
            mUiSubPaint.setTextAlign(Paint.Align.LEFT);
            mUiSubPaint.setColor(Color.rgb(185, 195, 192));
            canvas.drawText("Enchant slots", rpX, h * 0.36f, mUiSubPaint);
            for (int e = 0; e < 2; e++) {
                float ex = rpX + e * (w * 0.11f);
                mTmpRect.set(ex, h * 0.38f, ex + w * 0.09f, h * 0.47f);
                mPanelPaint.setColor(Color.rgb(8, 9, 10));
                canvas.drawRect(mTmpRect, mPanelPaint);
                drawDashedRect(canvas, mTmpRect.left, mTmpRect.top, mTmpRect.right, mTmpRect.bottom, Color.rgb(120, 126, 130));
                int rIdx = (e == 0) ? mRuneSlot1 : mRuneSlot2;
                mAsciiPaint.setTextSize(ts * 1.3f);
                mAsciiPaint.setColor(rIdx >= 0 ? Color.rgb(165, 245, 220) : Color.rgb(110, 120, 122));
                canvas.drawText(rIdx >= 0 ? runes[rIdx] : "+", ex + w * 0.045f, h * 0.435f, mAsciiPaint);
            }
            canvas.drawText("Metal: " + metals[mForgeMetal], rpX, h * 0.53f, mUiSubPaint);
            int rCount = (mRuneSlot1 >= 0 ? 1 : 0) + (mRuneSlot2 >= 0 ? 1 : 0);
            canvas.drawText("Runes: " + rCount + " / 2", rpX, h * 0.58f, mUiSubPaint);
            canvas.drawText("LV " + mLevel + " · " + mGold + "g", rpX, h * 0.65f, mUiSubPaint);
            canvas.drawText("HP " + mHp + "/" + mMaxHp, rpX, h * 0.70f, mUiSubPaint);
            canvas.drawText("Moonpetal: " + mHerbMoon, rpX, h * 0.76f, mUiSubPaint);
            canvas.drawText("Ashmoss: " + mHerbMoss, rpX, h * 0.81f, mUiSubPaint);

            // Bottom Action Bar
            String[] botLabels = {"+Stat (" + mStatPoints + ")", "Craft Potion", "Return to World"};
            float[] botX0 = {w * 0.06f, w * 0.38f, w * 0.72f};
            float[] botX1 = {w * 0.36f, w * 0.70f, w * 0.94f};
            for (int b = 0; b < 3; b++) {
                mTmpRect.set(botX0[b], h * 0.88f, botX1[b], h * 0.95f);
                mPanelPaint.setColor(b == 2 ? Color.rgb(26, 48, 38) : Color.rgb(16, 22, 20));
                canvas.drawRect(mTmpRect, mPanelPaint);
                mBorderPaint.setColor(Color.rgb(95, 118, 108));
                canvas.drawRect(mTmpRect, mBorderPaint);
                mUiPaint.setTextAlign(Paint.Align.CENTER);
                mUiPaint.setColor(Color.rgb(238, 244, 240));
                canvas.drawText(botLabels[b], (botX0[b] + botX1[b]) * 0.5f, h * 0.925f, mUiPaint);
            }
        }
    }
}
