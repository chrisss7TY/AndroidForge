package com.ashveil.abyss

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Minimalist Monospace HUD, Minecraft-Style World Selector & Custom Seed Creator,
 * 1..0 Skill Hotbar, and 3D Chainmail & Rune Equipment Forge Overlay (`1000461485.jpg`).
 */
class HudOverlayView(
    context: Context,
    private val state: GameState,
    private val prefs: SharedPreferences?
) : View(context) {

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    }
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.0f
    }

    private var movePointerId: Int = -1
    private var camPointerId: Int = -1
    private var joyBaseX: Float = 0f
    private var joyBaseY: Float = 0f
    private var joyCurrX: Float = 0f
    private var joyCurrY: Float = 0f
    private var lastCamX: Float = 0f

    private val keypadLabels = arrayOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "BKSP", "CLR")

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width
        val h = height

        when (state.screenMode) {
            0 -> drawMinimalistMainMenu(canvas, w, h)
            2 -> drawEquipmentMenuOverlay(canvas, w, h)
            3 -> drawCreateWorldMenu(canvas, w, h)
            else -> drawWorldHudOverlay(canvas, w, h)
        }
        postInvalidateOnAnimation()
    }

    // =========================================================================
    // 1. MINIMALIST MONOSPACE MAIN & WORLD SELECTOR MENU (Screen Mode 0)
    // =========================================================================
    private fun drawMinimalistMainMenu(canvas: Canvas, w: Int, h: Int) {
        boxPaint.color = Color.argb(178, 4, 6, 8)
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), boxPaint)

        val panelW = min(w * 0.84f, 780f)
        val panelH = min(h * 0.88f, 450f)
        val px = (w - panelW) * 0.5f
        val py = (h - panelH) * 0.5f

        boxPaint.color = Color.argb(244, 8, 11, 13)
        canvas.drawRect(px, py, px + panelW, py + panelH, boxPaint)
        borderPaint.color = Color.rgb(160, 174, 170)
        canvas.drawRect(px, py, px + panelW, py + panelH, borderPaint)

        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 19.5f
        textPaint.color = Color.rgb(238, 245, 242)
        canvas.drawText("ASHVEIL // 3D ASCII MMORPG & PROCEDURAL WORLD ENGINE", px + 22f, py + 32f, textPaint)

        textPaint.textSize = 12f
        textPaint.color = Color.rgb(148, 166, 160)
        canvas.drawText(
            "Active Realm: ${state.worldName}  \u00b7  Seed: ${state.worldSeed}  \u00b7  ${WorldGenerator.WORLD_TYPE_NAMES[state.worldType]}",
            px + 22f, py + 52f, textPaint
        )

        val btnY = py + 66f
        val btnH = 40f
        val halfW = (panelW - 56f) * 0.5f

        // Resume Active World Button
        boxPaint.color = Color.rgb(20, 44, 32)
        canvas.drawRect(px + 22f, btnY, px + 22f + halfW, btnY + btnH, boxPaint)
        borderPaint.color = Color.rgb(145, 225, 175)
        canvas.drawRect(px + 22f, btnY, px + 22f + halfW, btnY + btnH, borderPaint)
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = 13.5f
        textPaint.color = Color.rgb(235, 248, 240)
        canvas.drawText("[ RESUME ACTIVE WORLD ]", px + 22f + halfW * 0.5f, btnY + 25f, textPaint)

        // Create New World Button
        val createX = px + 34f + halfW
        boxPaint.color = Color.rgb(28, 34, 48)
        canvas.drawRect(createX, btnY, createX + halfW, btnY + btnH, boxPaint)
        borderPaint.color = Color.rgb(165, 195, 245)
        canvas.drawRect(createX, btnY, createX + halfW, btnY + btnH, borderPaint)
        textPaint.color = Color.rgb(235, 242, 255)
        canvas.drawText("[ + CREATE NEW WORLD ]", createX + halfW * 0.5f, btnY + 25f, textPaint)

        // Saved Worlds List Header
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 12.5f
        textPaint.color = Color.rgb(175, 185, 182)
        canvas.drawText("SAVED PROCEDURAL WORLDS (Tap any world slot to load its seed & chunks):", px + 22f, btnY + 62f, textPaint)

        val rowStartY = btnY + 72f
        val rowH = 42f
        for (i in 0 until state.savedWorldCount) {
            val wSlot = state.savedWorlds[i]
            val ry = rowStartY + i * (rowH + 6f)
            val isAct = (i == state.activeWorldIndex)

            boxPaint.color = if (isAct) Color.rgb(18, 30, 26) else Color.rgb(12, 16, 18)
            canvas.drawRect(px + 22f, ry, px + panelW - 108f, ry + rowH, boxPaint)
            borderPaint.color = if (isAct) Color.rgb(135, 218, 165) else Color.rgb(75, 86, 84)
            canvas.drawRect(px + 22f, ry, px + panelW - 108f, ry + rowH, borderPaint)

            textPaint.textAlign = Paint.Align.LEFT
            textPaint.textSize = 13.5f
            textPaint.color = if (isAct) Color.rgb(165, 245, 190) else Color.rgb(225, 232, 230)
            val activeTag = if (isAct) " [ACTIVE]" else " [LOAD]"
            canvas.drawText(
                "${i + 1}. ${wSlot.name}$activeTag  \u00b7  LV ${wSlot.savedLevel} (${wSlot.savedGold}g)",
                px + 34f, ry + 17f, textPaint
            )

            textPaint.textSize = 11.5f
            textPaint.color = Color.rgb(148, 160, 158)
            val tName = WorldGenerator.WORLD_TYPE_NAMES[wSlot.worldType.coerceIn(0, 4)]
            val mName = WorldGenerator.GAME_MODE_NAMES[wSlot.gameMode.coerceIn(0, 2)]
            canvas.drawText("Seed: ${wSlot.seed}  |  Type: $tName  |  Mode: $mName", px + 34f, ry + 34f, textPaint)

            // Delete World Button
            val delX = px + panelW - 98f
            boxPaint.color = Color.rgb(34, 16, 18)
            canvas.drawRect(delX, ry, px + panelW - 22f, ry + rowH, boxPaint)
            borderPaint.color = Color.rgb(145, 75, 78)
            canvas.drawRect(delX, ry, px + panelW - 22f, ry + rowH, borderPaint)
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.textSize = 11.5f
            textPaint.color = Color.rgb(235, 165, 165)
            canvas.drawText("DELETE", delX + 38f, ry + 25f, textPaint)
        }

        // Bottom Settings Row
        val botY = py + panelH - 46f
        val thirdW = (panelW - 64f) / 3.0f
        for (b in 0..2) {
            val bx = px + 22f + b * (thirdW + 10f)
            boxPaint.color = Color.rgb(15, 20, 24)
            canvas.drawRect(bx, botY, bx + thirdW, botY + 34f, boxPaint)
            borderPaint.color = Color.rgb(98, 110, 108)
            canvas.drawRect(bx, botY, bx + thirdW, botY + 34f, borderPaint)

            textPaint.textAlign = Paint.Align.CENTER
            textPaint.textSize = 12f
            textPaint.color = Color.rgb(218, 228, 225)
            val label = when (b) {
                0 -> {
                    val qStr = when (state.qualityPreset) {
                        0 -> "LOW (12k)"
                        1 -> "MED (24k)"
                        else -> "ULTRA (36k)"
                    }
                    "GRASS QUALITY: $qStr"
                }
                1 -> if (state.debugSolidMode) "RENDER: SOLID 3D" else "RENDER: 3D ASCII"
                else -> "OPEN EQUIPMENT FORGE"
            }
            canvas.drawText(label, bx + thirdW * 0.5f, botY + 22f, textPaint)
        }
    }

    // =========================================================================
    // 2. MINECRAFT-STYLE CREATE NEW WORLD & CUSTOM SEED SCREEN (Screen Mode 3)
    // =========================================================================
    private fun drawCreateWorldMenu(canvas: Canvas, w: Int, h: Int) {
        boxPaint.color = Color.argb(192, 4, 6, 8)
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), boxPaint)

        val panelW = min(w * 0.88f, 800f)
        val panelH = min(h * 0.90f, 460f)
        val px = (w - panelW) * 0.5f
        val py = (h - panelH) * 0.5f

        boxPaint.color = Color.argb(246, 8, 11, 14)
        canvas.drawRect(px, py, px + panelW, py + panelH, boxPaint)
        borderPaint.color = Color.rgb(165, 185, 210)
        canvas.drawRect(px, py, px + panelW, py + panelH, borderPaint)

        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 19.5f
        textPaint.color = Color.rgb(238, 245, 255)
        canvas.drawText("CREATE NEW WORLD // MINECRAFT-STYLE SEEDED 3D GENERATOR", px + 22f, py + 32f, textPaint)

        val rowY1 = py + 52f
        val rowH = 40f
        val colW = (panelW - 56f) * 0.5f

        // Option 1: World Name Selector
        boxPaint.color = Color.rgb(14, 18, 22)
        canvas.drawRect(px + 22f, rowY1, px + 22f + colW, rowY1 + rowH, boxPaint)
        borderPaint.color = Color.rgb(110, 125, 135)
        canvas.drawRect(px + 22f, rowY1, px + 22f + colW, rowY1 + rowH, borderPaint)
        textPaint.textSize = 13f
        textPaint.color = Color.rgb(225, 235, 240)
        val wName = WorldGenerator.PRESET_WORLD_NAMES[state.newWorldNameIdx % WorldGenerator.PRESET_WORLD_NAMES.size]
        canvas.drawText("World Name: $wName  [TAP]", px + 32f, rowY1 + 25f, textPaint)

        // Option 2: Game Mode Selector
        val col2X = px + 34f + colW
        canvas.drawRect(col2X, rowY1, col2X + colW, rowY1 + rowH, boxPaint)
        canvas.drawRect(col2X, rowY1, col2X + colW, rowY1 + rowH, borderPaint)
        val gMode = WorldGenerator.GAME_MODE_NAMES[state.newGameMode % WorldGenerator.GAME_MODE_NAMES.size]
        canvas.drawText("Game Mode: $gMode  [TAP]", col2X + 12f, rowY1 + 25f, textPaint)

        // Option 3: World Type Selector
        val rowY2 = rowY1 + 50f
        canvas.drawRect(px + 22f, rowY2, px + 22f + colW, rowY2 + rowH, boxPaint)
        canvas.drawRect(px + 22f, rowY2, px + 22f + colW, rowY2 + rowH, borderPaint)
        val wType = WorldGenerator.WORLD_TYPE_NAMES[state.newWorldType % WorldGenerator.WORLD_TYPE_NAMES.size]
        canvas.drawText("World Type: $wType  [TAP]", px + 32f, rowY2 + 25f, textPaint)

        // Option 4: Randomize Seed Button
        boxPaint.color = Color.rgb(22, 34, 48)
        canvas.drawRect(col2X, rowY2, col2X + colW, rowY2 + rowH, boxPaint)
        borderPaint.color = Color.rgb(145, 195, 248)
        canvas.drawRect(col2X, rowY2, col2X + colW, rowY2 + rowH, borderPaint)
        textPaint.color = Color.rgb(195, 230, 255)
        canvas.drawText("Seed: ${state.newWorldSeedInput.ifEmpty { "0" }}  [TAP RANDOM SEED]", col2X + 12f, rowY2 + 25f, textPaint)

        // Direct Custom Seed Keypad Row (Type any custom numeric seed!)
        val keyY = rowY2 + 50f
        val keyH = 34f
        val keyCount = keypadLabels.size
        val keyW = (panelW - 44f - (keyCount - 1) * 5f) / keyCount.toFloat()
        for (k in 0 until keyCount) {
            val kx = px + 22f + k * (keyW + 5f)
            boxPaint.color = Color.rgb(16, 22, 28)
            canvas.drawRect(kx, keyY, kx + keyW, keyY + keyH, boxPaint)
            borderPaint.color = Color.rgb(92, 112, 128)
            canvas.drawRect(kx, keyY, kx + keyW, keyY + keyH, borderPaint)
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.textSize = 11.5f
            textPaint.color = Color.rgb(225, 238, 248)
            canvas.drawText(keypadLabels[k], kx + keyW * 0.5f, keyY + 22f, textPaint)
        }

        // Structure Generation Toggles Row
        val rowY3 = keyY + 46f
        val thirdW = (panelW - 64f) / 3.0f
        val toggles = arrayOf(
            "Moonlit Caves: ${if (state.newGenCaves) "ON" else "OFF"}",
            "Rivers & Water: ${if (state.newGenRivers) "ON" else "OFF"}",
            "Runic Shrines: ${if (state.newGenShrines) "ON" else "OFF"}"
        )
        val toggleOn = booleanArrayOf(state.newGenCaves, state.newGenRivers, state.newGenShrines)
        for (t in 0..2) {
            val tx = px + 22f + t * (thirdW + 10f)
            boxPaint.color = if (toggleOn[t]) Color.rgb(16, 32, 24) else Color.rgb(22, 16, 18)
            canvas.drawRect(tx, rowY3, tx + thirdW, rowY3 + 38f, boxPaint)
            borderPaint.color = if (toggleOn[t]) Color.rgb(125, 205, 155) else Color.rgb(125, 85, 85)
            canvas.drawRect(tx, rowY3, tx + thirdW, rowY3 + 38f, borderPaint)
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.textSize = 12f
            textPaint.color = Color.rgb(230, 240, 235)
            canvas.drawText(toggles[t], tx + thirdW * 0.5f, rowY3 + 24f, textPaint)
        }

        // Generator Info Box
        val infoY = rowY3 + 50f
        boxPaint.color = Color.rgb(10, 14, 16)
        canvas.drawRect(px + 22f, infoY, px + panelW - 22f, infoY + 56f, boxPaint)
        borderPaint.color = Color.rgb(65, 78, 82)
        canvas.drawRect(px + 22f, infoY, px + panelW - 22f, infoY + 56f, borderPaint)
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 11.5f
        textPaint.color = Color.rgb(165, 182, 178)
        canvas.drawText(
            "\u2022 100% Seeded 16x16 Chunks: Every seed generates a unique 3D heightfield, river curve & cave coordinates.",
            px + 32f, infoY + 22f, textPaint
        )
        canvas.drawText(
            "\u2022 GPU-Synced 3D Grass & Meshes: 36,000 instanced ASCII blades + faceted rocks sit flush on 3D slopes.",
            px + 32f, infoY + 42f, textPaint
        )

        // Bottom Create & Cancel Buttons
        val botY = py + panelH - 52f
        boxPaint.color = Color.rgb(22, 52, 36)
        canvas.drawRect(px + 22f, botY, px + 22f + colW * 1.25f, botY + 42f, boxPaint)
        borderPaint.color = Color.rgb(155, 240, 185)
        canvas.drawRect(px + 22f, botY, px + 22f + colW * 1.25f, botY + 42f, borderPaint)
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = 14f
        textPaint.color = Color.rgb(240, 255, 245)
        canvas.drawText("[ CREATE & ENTER PROCEDURAL WORLD ]", px + 22f + colW * 0.625f, botY + 26f, textPaint)

        val cancelX = px + 34f + colW * 1.25f
        val cancelW = panelW - 56f - colW * 1.25f
        boxPaint.color = Color.rgb(28, 20, 22)
        canvas.drawRect(cancelX, botY, cancelX + cancelW, botY + 42f, boxPaint)
        borderPaint.color = Color.rgb(145, 95, 98)
        canvas.drawRect(cancelX, botY, cancelX + cancelW, botY + 42f, borderPaint)
        textPaint.color = Color.rgb(235, 195, 195)
        canvas.drawText("[ BACK TO WORLDS ]", cancelX + cancelW * 0.5f, botY + 26f, textPaint)
    }

    // =========================================================================
    // 3. IN-GAME 3D WORLD HUD OVERLAY (Screen Mode 1)
    // =========================================================================
    private fun drawWorldHudOverlay(canvas: Canvas, w: Int, h: Int) {
        // Top-Left ASCII Portrait & HP/MP/World Box (`Senje`)
        val hudX = 18f
        val hudY = 14f
        val pBox = 68f

        boxPaint.color = Color.argb(215, 6, 8, 10)
        canvas.drawRect(hudX, hudY, hudX + pBox, hudY + pBox, boxPaint)
        borderPaint.color = Color.rgb(175, 185, 180)
        canvas.drawRect(hudX, hudY, hudX + pBox, hudY + pBox, borderPaint)

        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = 11.5f
        textPaint.color = Color.rgb(225, 235, 232)
        val cx = hudX + pBox * 0.5f
        canvas.drawText(" .o88o. ", cx, hudY + 18f, textPaint)
        canvas.drawText("d8'..'8b", cx, hudY + 32f, textPaint)
        canvas.drawText("88.||.88", cx, hudY + 46f, textPaint)
        canvas.drawText(" 'Y88Y' ", cx, hudY + 60f, textPaint)

        val barX = hudX + pBox + 12f
        val barW = 195f
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 15.5f
        textPaint.color = Color.WHITE
        canvas.drawText("${state.playerName}  [${state.worldName}]", barX, hudY + 16f, textPaint)

        // HP Bar
        val hpY = hudY + 24f
        boxPaint.color = Color.argb(210, 14, 16, 18)
        canvas.drawRect(barX, hpY, barX + barW, hpY + 16f, boxPaint)
        val hpRatio = (state.hp.toFloat() / max(1, state.maxHp)).coerceIn(0f, 1f)
        boxPaint.color = Color.rgb(42, 168, 72)
        canvas.drawRect(barX + 2f, hpY + 2f, barX + 2f + (barW - 4f) * hpRatio, hpY + 14f, boxPaint)
        borderPaint.color = Color.rgb(140, 152, 148)
        canvas.drawRect(barX, hpY, barX + barW, hpY + 16f, borderPaint)
        textPaint.textSize = 11f
        textPaint.color = Color.WHITE
        canvas.drawText("HP ${state.hp}/${state.maxHp}", barX + 6f, hpY + 12f, textPaint)

        // MP Bar
        val mpY = hpY + 22f
        boxPaint.color = Color.argb(210, 14, 16, 18)
        canvas.drawRect(barX, mpY, barX + barW, mpY + 15f, boxPaint)
        val mpRatio = (state.mp.toFloat() / max(1, state.maxMp)).coerceIn(0f, 1f)
        boxPaint.color = Color.rgb(48, 128, 215)
        canvas.drawRect(barX + 2f, mpY + 2f, barX + 2f + (barW - 4f) * mpRatio, mpY + 13f, boxPaint)
        canvas.drawRect(barX, mpY, barX + barW, mpY + 15f, borderPaint)
        canvas.drawText("MP ${state.mp}/${state.maxMp}", barX + 6f, mpY + 11.5f, textPaint)

        // Biome & Coordinates Readout
        textPaint.textSize = 11.5f
        textPaint.color = Color.rgb(185, 205, 198)
        val questStr = if (state.questCompleted) "Quest: Complete" else "Quest: Sentinels ${state.questKills}/${state.questTarget}"
        canvas.drawText(
            "${state.currentBiomeName} (${state.playerX.toInt()}, ${state.playerZ.toInt()}) \u00b7 $questStr",
            hudX, hudY + pBox + 18f, textPaint
        )

        // Top-Right Action Bar: [WORLDS / MENU], [EQUIP], [CURSOR], [ZOOM], [STEED]
        val topBtnW = 92f
        val topBtnH = 34f
        val gap = 7f
        val startRightX = w - 16f - (topBtnW * 5f + gap * 4f)
        val labels = arrayOf(
            "WORLDS",
            "EQUIP",
            if (state.cursorViewMode) "CURSOR:ON" else "CURSOR:OFF",
            "ZOOM",
            if (state.mounted) "STEED:ON" else "STEED:OFF"
        )
        for (i in 0..4) {
            val bx = startRightX + i * (topBtnW + gap)
            boxPaint.color = if (i == 0) Color.argb(225, 18, 36, 28) else Color.argb(215, 8, 11, 13)
            canvas.drawRect(bx, hudY, bx + topBtnW, hudY + topBtnH, boxPaint)
            borderPaint.color = if (i == 0) Color.rgb(145, 225, 175) else Color.rgb(160, 172, 168)
            canvas.drawRect(bx, hudY, bx + topBtnW, hudY + topBtnH, borderPaint)
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.textSize = 11.5f
            textPaint.color = Color.rgb(232, 240, 238)
            canvas.drawText(labels[i], bx + topBtnW * 0.5f, hudY + 21f, textPaint)
        }

        // Cursor View Crosshair (`1000461482.jpg` "Fog testing + Cursor view")
        if (state.cursorViewMode) {
            val crX = state.cursorX * w
            val crY = state.cursorY * h
            borderPaint.color = Color.argb(190, 230, 245, 238)
            canvas.drawLine(crX - 10f, crY, crX + 10f, crY, borderPaint)
            canvas.drawLine(crX, crY - 10f, crX, crY + 10f, borderPaint)
        }

        // Status Banner
        if (state.bannerTimer > 0.0f) {
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.textSize = 13.5f
            textPaint.color = Color.rgb(235, 245, 240)
            canvas.drawText(state.statusBanner, w * 0.5f, hudY + 62f, textPaint)
        }

        // Bottom-Left Virtual Movement Joystick
        val jCx = if (movePointerId != -1) joyBaseX else 112f
        val jCy = if (movePointerId != -1) joyBaseY else (h - 122f)
        val jRad = 54f
        boxPaint.color = Color.argb(120, 8, 12, 14)
        canvas.drawCircle(jCx, jCy, jRad, boxPaint)
        borderPaint.color = Color.argb(185, 165, 180, 175)
        canvas.drawCircle(jCx, jCy, jRad, borderPaint)

        val knobX = if (movePointerId != -1) joyCurrX else jCx
        val knobY = if (movePointerId != -1) joyCurrY else jCy
        boxPaint.color = Color.argb(210, 195, 215, 208)
        canvas.drawCircle(knobX, knobY, 21f, boxPaint)

        // Bottom-Right Combat Buttons: [ATTACK], [DODGE], [JUMP]
        val atkX = w - 118f
        val atkY = h - 126f
        boxPaint.color = Color.argb(215, 26, 14, 16)
        canvas.drawCircle(atkX, atkY, 44f, boxPaint)
        borderPaint.color = Color.rgb(228, 185, 185)
        canvas.drawCircle(atkX, atkY, 44f, borderPaint)
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = 13f
        textPaint.color = Color.WHITE
        canvas.drawText("ATTACK", atkX, atkY + 5f, textPaint)

        val ddgX = w - 216f
        val ddgY = h - 98f
        boxPaint.color = Color.argb(215, 12, 18, 24)
        canvas.drawCircle(ddgX, ddgY, 34f, boxPaint)
        borderPaint.color = Color.rgb(175, 205, 228)
        canvas.drawCircle(ddgX, ddgY, 34f, borderPaint)
        textPaint.textSize = 11.5f
        canvas.drawText("DODGE", ddgX, ddgY + 4f, textPaint)

        val jmpX = w - 196f
        val jmpY = h - 182f
        boxPaint.color = Color.argb(215, 14, 22, 18)
        canvas.drawCircle(jmpX, jmpY, 32f, boxPaint)
        borderPaint.color = Color.rgb(175, 225, 195)
        canvas.drawCircle(jmpX, jmpY, 32f, borderPaint)
        canvas.drawText("JUMP", jmpX, jmpY + 4f, textPaint)

        // Bottom Center `LV · XP` Bar & 10-Slot Hotbar (`1..0`)
        val slotSize = 44f
        val slotGap = 4f
        val totalHotbarW = 10 * slotSize + 9 * slotGap
        val hbStartX = (w - totalHotbarW) * 0.5f
        val hbY = h - slotSize - 10f

        val xpBarY = hbY - 22f
        boxPaint.color = Color.argb(225, 6, 8, 10)
        canvas.drawRect(hbStartX, xpBarY, hbStartX + totalHotbarW, xpBarY + 17f, boxPaint)
        val xpRatio = (state.xp.toFloat() / max(1, state.xpNext)).coerceIn(0f, 1f)
        boxPaint.color = Color.rgb(58, 72, 66)
        canvas.drawRect(hbStartX + 2f, xpBarY + 2f, hbStartX + 2f + (totalHotbarW - 4f) * xpRatio, xpBarY + 15f, boxPaint)
        borderPaint.color = Color.rgb(145, 156, 152)
        canvas.drawRect(hbStartX, xpBarY, hbStartX + totalHotbarW, xpBarY + 17f, borderPaint)

        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 11f
        textPaint.color = Color.rgb(232, 240, 236)
        canvas.drawText("LV ${state.level}", hbStartX + 8f, xpBarY + 12.5f, textPaint)
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("XP ${state.xp}/${state.xpNext}", hbStartX + totalHotbarW * 0.5f, xpBarY + 12.5f, textPaint)
        textPaint.textAlign = Paint.Align.RIGHT
        textPaint.color = Color.rgb(245, 215, 120)
        canvas.drawText("${state.gold} G", hbStartX + totalHotbarW - 8f, xpBarY + 12.5f, textPaint)

        for (s in 0..9) {
            val sx = hbStartX + s * (slotSize + slotGap)
            boxPaint.color = Color.argb(225, 8, 10, 12)
            canvas.drawRect(sx, hbY, sx + slotSize, hbY + slotSize, boxPaint)

            val cd = state.hotbarCooldowns[s]
            if (cd > 0.0f) {
                val cdRatio = (cd / max(0.1f, state.hotbarMaxCooldowns[s])).coerceIn(0f, 1f)
                boxPaint.color = Color.argb(165, 40, 65, 95)
                canvas.drawRect(sx, hbY + slotSize * (1f - cdRatio), sx + slotSize, hbY + slotSize, boxPaint)
            }

            borderPaint.color = if (s == 2 && state.vortexActiveTimer > 0f) {
                Color.rgb(195, 165, 255)
            } else {
                Color.rgb(155, 165, 162)
            }
            canvas.drawRect(sx, hbY, sx + slotSize, hbY + slotSize, borderPaint)

            val keyLabel = if (s == 9) "0" else (s + 1).toString()
            textPaint.textAlign = Paint.Align.LEFT
            textPaint.textSize = 10f
            textPaint.color = Color.rgb(172, 182, 178)
            canvas.drawText(keyLabel, sx + 4f, hbY + 12f, textPaint)

            textPaint.textAlign = Paint.Align.CENTER
            textPaint.textSize = 9.5f
            textPaint.color = Color.rgb(232, 240, 236)
            canvas.drawText(GameState.HOTBAR_LABELS[s], sx + slotSize * 0.5f, hbY + 29f, textPaint)

            if (s == 5) {
                textPaint.textSize = 9f
                textPaint.color = Color.rgb(140, 235, 165)
                canvas.drawText("x${state.potions}", sx + slotSize * 0.5f, hbY + 40f, textPaint)
            } else if (s == 6) {
                textPaint.textSize = 9f
                textPaint.color = Color.rgb(145, 205, 250)
                canvas.drawText("x${state.cinderShards}", sx + slotSize * 0.5f, hbY + 40f, textPaint)
            }
        }
    }

    // =========================================================================
    // 4. 3D CHAINMAIL & RUNE EQUIPMENT FORGE OVERLAY (`1000461485.jpg`)
    // =========================================================================
    private fun drawEquipmentMenuOverlay(canvas: Canvas, w: Int, h: Int) {
        val leftX = 24f
        val topY = 20f

        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 24f
        textPaint.color = Color.WHITE
        canvas.drawText("${state.playerName} //LV ${state.level}", leftX, topY + 24f, textPaint)

        // 7 Equipment Slot Tabs (`Weapon`, `Helm`, `Shoulders`, `Chest`, `Gloves`, `Legs`, `Boots`)
        val tabY = topY + 40f
        var curX = leftX
        textPaint.textSize = 14f
        for (s in 0..6) {
            val name = GameState.SLOT_NAMES[s]
            val tw = textPaint.measureText(name) + 22f
            val sel = (s == state.selectedSlot)
            boxPaint.color = if (sel) Color.rgb(238, 242, 240) else Color.rgb(10, 12, 14)
            canvas.drawRect(curX, tabY, curX + tw, tabY + 32f, boxPaint)
            borderPaint.color = Color.rgb(195, 205, 202)
            canvas.drawRect(curX, tabY, curX + tw, tabY + 32f, borderPaint)

            textPaint.color = if (sel) Color.BLACK else Color.WHITE
            canvas.drawText(name, curX + 11f, tabY + 21f, textPaint)
            curX += tw + 6f
        }

        // Top-Right Close & View Mode Toggle (`[COIF / HERO]`, `[CLOSE]`)
        val toggleW = 148f
        val closeW = 104f
        val closeX = w - closeW - 20f
        val toggleX = closeX - toggleW - 10f

        boxPaint.color = Color.rgb(16, 22, 28)
        canvas.drawRect(toggleX, topY, toggleX + toggleW, topY + 36f, boxPaint)
        borderPaint.color = Color.rgb(165, 195, 230)
        canvas.drawRect(toggleX, topY, toggleX + toggleW, topY + 36f, borderPaint)
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = 12f
        textPaint.color = Color.WHITE
        canvas.drawText(
            if (state.previewFullHero) "VIEW: FULL HERO" else "VIEW: 3D COIF",
            toggleX + toggleW * 0.5f, topY + 23f, textPaint
        )

        boxPaint.color = Color.rgb(28, 16, 18)
        canvas.drawRect(closeX, topY, closeX + closeW, topY + 36f, boxPaint)
        borderPaint.color = Color.rgb(220, 175, 175)
        canvas.drawRect(closeX, topY, closeX + closeW, topY + 36f, borderPaint)
        canvas.drawText("CLOSE [X]", closeX + closeW * 0.5f, topY + 23f, textPaint)

        // Left Column: 10 Armor Materials (`Iron` .. `Emberstone`)
        val matStartX = leftX
        val matStartY = tabY + 50f
        val matW = 152f
        val matH = 29f
        for (m in 0..9) {
            val my = matStartY + m * (matH + 5f)
            val sel = (m == state.activeMetal)
            boxPaint.color = if (sel) Color.rgb(238, 242, 240) else Color.rgb(8, 10, 12)
            canvas.drawRect(matStartX, my, matStartX + matW, my + matH, boxPaint)
            borderPaint.color = Color.rgb(185, 195, 192)
            canvas.drawRect(matStartX, my, matStartX + matW, my + matH, borderPaint)

            textPaint.textAlign = Paint.Align.LEFT
            textPaint.textSize = 13.5f
            textPaint.color = if (sel) Color.BLACK else Color.WHITE
            canvas.drawText(GameState.METAL_NAMES[m], matStartX + 12f, my + 20f, textPaint)
        }

        // Enchanting & Rune Slots Box
        val runeX = matStartX + matW + 18f
        val runeY = matStartY
        val runeBoxW = 195f
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 14f
        textPaint.color = Color.WHITE
        canvas.drawText("Enchanting:", runeX, runeY + 16f, textPaint)

        for (r in 0..1) {
            val ry = runeY + 26f + r * 46f
            val rVal = if (r == 0) state.runeSlot1 else state.runeSlot2
            boxPaint.color = Color.rgb(10, 12, 14)
            canvas.drawRect(runeX, ry, runeX + runeBoxW, ry + 36f, boxPaint)
            borderPaint.color = Color.rgb(175, 185, 182)
            canvas.drawRect(runeX, ry, runeX + runeBoxW, ry + 36f, borderPaint)
            textPaint.textSize = 12.5f
            textPaint.color = Color.rgb(220, 232, 228)
            val rLabel = if (rVal < 0) {
                "Rune Slot ${r + 1}: Empty"
            } else {
                "Rune ${r + 1}: ${GameState.METAL_NAMES[rVal]} (+Stats)"
            }
            canvas.drawText(rLabel, runeX + 10f, ry + 23f, textPaint)
        }

        // Item Stats Summary Card
        val cardY = runeY + 132f
        boxPaint.color = Color.argb(215, 8, 10, 12)
        canvas.drawRect(runeX, cardY, runeX + runeBoxW + 30f, cardY + 135f, boxPaint)
        borderPaint.color = Color.rgb(145, 155, 152)
        canvas.drawRect(runeX, cardY, runeX + runeBoxW + 30f, cardY + 135f, borderPaint)

        val eqMat = GameState.METAL_NAMES[state.slotMetal[state.selectedSlot]]
        val eqSlot = GameState.SLOT_NAMES[state.selectedSlot]
        textPaint.textSize = 13f
        textPaint.color = Color.rgb(235, 245, 240)
        canvas.drawText("$eqMat $eqSlot", runeX + 10f, cardY + 24f, textPaint)
        textPaint.textSize = 11.5f
        textPaint.color = Color.rgb(170, 185, 180)
        canvas.drawText("Defense Rating: +${35 + state.activeMetal * 18}", runeX + 10f, cardY + 48f, textPaint)
        canvas.drawText("Attack Bonus: +${14 + state.activeMetal * 9}", runeX + 10f, cardY + 68f, textPaint)
        canvas.drawText("HP ${state.hp}/${state.maxHp}  MP ${state.mp}/${state.maxMp}", runeX + 10f, cardY + 92f, textPaint)
        canvas.drawText("Drag right side to rotate 3D ASCII model", runeX + 10f, cardY + 116f, textPaint)
    }

    // =========================================================================
    // TOUCH INPUT & GESTURE ROUTING
    // =========================================================================
    override fun onTouchEvent(event: MotionEvent): Boolean {
        val w = max(1, width)
        val h = max(1, height)
        val action = event.actionMasked
        val idx = event.actionIndex
        val pid = event.getPointerId(idx)
        val tx = event.getX(idx)
        val ty = event.getY(idx)

        if (state.screenMode == 0) {
            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                handleMainMenuTouch(tx, ty, w, h)
            }
            return true
        }

        if (state.screenMode == 3) {
            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                handleCreateWorldTouch(tx, ty, w, h)
            }
            return true
        }

        if (state.screenMode == 2) {
            when (action) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                    if (!handleEquipmentTouch(tx, ty, w)) {
                        camPointerId = pid
                        lastCamX = tx
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    for (i in 0 until event.pointerCount) {
                        if (event.getPointerId(i) == camPointerId) {
                            val cx = event.getX(i)
                            state.previewYaw += (cx - lastCamX) * 0.01f
                            lastCamX = cx
                        }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                    if (pid == camPointerId) camPointerId = -1
                }
            }
            return true
        }

        // Screen Mode 1: Active 3D World Controls
        when (action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                if (handleHudButtonsTouch(tx, ty, w, h)) {
                    return true
                }
                if (tx < w * 0.44f && ty > h * 0.36f && movePointerId == -1) {
                    movePointerId = pid
                    joyBaseX = tx
                    joyBaseY = ty
                    joyCurrX = tx
                    joyCurrY = ty
                    state.inputX = 0f
                    state.inputZ = 0f
                } else if (camPointerId == -1) {
                    camPointerId = pid
                    lastCamX = tx
                    state.cursorX = (tx / w.toFloat()).coerceIn(0.15f, 0.85f)
                    state.cursorY = (ty / h.toFloat()).coerceIn(0.15f, 0.85f)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.pointerCount) {
                    val cPid = event.getPointerId(i)
                    val cx = event.getX(i)
                    val cy = event.getY(i)
                    if (cPid == movePointerId) {
                        val dx = cx - joyBaseX
                        val dy = cy - joyBaseY
                        val dist = sqrt(dx * dx + dy * dy)
                        val maxR = 54f
                        if (dist > maxR) {
                            joyCurrX = joyBaseX + (dx / dist) * maxR
                            joyCurrY = joyBaseY + (dy / dist) * maxR
                            state.inputX = dx / dist
                            state.inputZ = dy / dist
                        } else {
                            joyCurrX = cx
                            joyCurrY = cy
                            state.inputX = dx / maxR
                            state.inputZ = dy / maxR
                        }
                    } else if (cPid == camPointerId) {
                        val dx = cx - lastCamX
                        state.camYaw -= dx * 0.0065f
                        lastCamX = cx
                        state.cursorX = (cx / w.toFloat()).coerceIn(0.15f, 0.85f)
                        state.cursorY = (cy / h.toFloat()).coerceIn(0.15f, 0.85f)
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                if (pid == movePointerId || action == MotionEvent.ACTION_CANCEL) {
                    movePointerId = -1
                    state.inputX = 0f
                    state.inputZ = 0f
                }
                if (pid == camPointerId || action == MotionEvent.ACTION_CANCEL) {
                    camPointerId = -1
                }
            }
        }
        return true
    }

    private fun handleMainMenuTouch(tx: Float, ty: Float, w: Int, h: Int) {
        val panelW = min(w * 0.84f, 780f)
        val panelH = min(h * 0.88f, 450f)
        val px = (w - panelW) * 0.5f
        val py = (h - panelH) * 0.5f

        val btnY = py + 66f
        val btnH = 40f
        val halfW = (panelW - 56f) * 0.5f

        if (ty in btnY..(btnY + btnH)) {
            if (tx in (px + 22f)..(px + 22f + halfW)) {
                state.screenMode = 1
                return
            }
            val createX = px + 34f + halfW
            if (tx in createX..(createX + halfW)) {
                state.randomizeNewWorldSeed()
                state.screenMode = 3
                return
            }
        }

        val rowStartY = btnY + 72f
        val rowH = 42f
        for (i in 0 until state.savedWorldCount) {
            val ry = rowStartY + i * (rowH + 6f)
            if (ty in ry..(ry + rowH)) {
                if (tx in (px + 22f)..(px + panelW - 108f)) {
                    state.loadWorldSlot(i)
                    state.persistWorlds(prefs)
                    return
                }
                val delX = px + panelW - 98f
                if (tx in delX..(px + panelW - 22f)) {
                    state.deleteWorldSlot(i, prefs)
                    return
                }
            }
        }

        val botY = py + panelH - 46f
        val thirdW = (panelW - 64f) / 3.0f
        if (ty in botY..(botY + 34f)) {
            for (b in 0..2) {
                val bx = px + 22f + b * (thirdW + 10f)
                if (tx in bx..(bx + thirdW)) {
                    when (b) {
                        0 -> state.qualityPreset = (state.qualityPreset + 1) % 3
                        1 -> state.debugSolidMode = !state.debugSolidMode
                        2 -> state.screenMode = 2
                    }
                    return
                }
            }
        }
    }

    private fun handleCreateWorldTouch(tx: Float, ty: Float, w: Int, h: Int) {
        val panelW = min(w * 0.88f, 800f)
        val panelH = min(h * 0.90f, 460f)
        val px = (w - panelW) * 0.5f
        val py = (h - panelH) * 0.5f

        val rowY1 = py + 52f
        val rowH = 40f
        val colW = (panelW - 56f) * 0.5f
        val col2X = px + 34f + colW

        if (ty in rowY1..(rowY1 + rowH)) {
            if (tx in (px + 22f)..(px + 22f + colW)) {
                state.newWorldNameIdx = (state.newWorldNameIdx + 1) % WorldGenerator.PRESET_WORLD_NAMES.size
                return
            }
            if (tx in col2X..(col2X + colW)) {
                state.newGameMode = (state.newGameMode + 1) % WorldGenerator.GAME_MODE_NAMES.size
                return
            }
        }

        val rowY2 = rowY1 + 50f
        if (ty in rowY2..(rowY2 + rowH)) {
            if (tx in (px + 22f)..(px + 22f + colW)) {
                state.newWorldType = (state.newWorldType + 1) % WorldGenerator.WORLD_TYPE_NAMES.size
                return
            }
            if (tx in col2X..(col2X + colW)) {
                state.randomizeNewWorldSeed()
                return
            }
        }

        // Custom Seed Keypad Row
        val keyY = rowY2 + 50f
        val keyH = 34f
        val keyCount = keypadLabels.size
        val keyW = (panelW - 44f - (keyCount - 1) * 5f) / keyCount.toFloat()
        if (ty in keyY..(keyY + keyH)) {
            for (k in 0 until keyCount) {
                val kx = px + 22f + k * (keyW + 5f)
                if (tx in kx..(kx + keyW)) {
                    when (val lbl = keypadLabels[k]) {
                        "BKSP" -> state.backspaceSeedInput()
                        "CLR" -> state.clearSeedInput()
                        "-" -> state.appendSeedDigit('-')
                        else -> state.appendSeedDigit(lbl[0])
                    }
                    return
                }
            }
        }

        val rowY3 = keyY + 46f
        val thirdW = (panelW - 64f) / 3.0f
        if (ty in rowY3..(rowY3 + 38f)) {
            for (t in 0..2) {
                val bx = px + 22f + t * (thirdW + 10f)
                if (tx in bx..(bx + thirdW)) {
                    when (t) {
                        0 -> state.newGenCaves = !state.newGenCaves
                        1 -> state.newGenRivers = !state.newGenRivers
                        2 -> state.newGenShrines = !state.newGenShrines
                    }
                    return
                }
            }
        }

        val botY = py + panelH - 52f
        if (ty in botY..(botY + 42f)) {
            if (tx in (px + 22f)..(px + 22f + colW * 1.25f)) {
                state.createAndLaunchNewWorld(prefs)
                return
            }
            val cancelX = px + 34f + colW * 1.25f
            if (tx >= cancelX) {
                state.screenMode = 0
                return
            }
        }
    }

    private fun handleHudButtonsTouch(tx: Float, ty: Float, w: Int, h: Int): Boolean {
        val hudY = 14f
        val topBtnW = 92f
        val topBtnH = 34f
        val gap = 7f
        val startRightX = w - 16f - (topBtnW * 5f + gap * 4f)

        if (ty in hudY..(hudY + topBtnH + 10f) && tx >= startRightX) {
            val idx = ((tx - startRightX) / (topBtnW + gap)).toInt().coerceIn(0, 4)
            when (idx) {
                0 -> {
                    movePointerId = -1
                    state.inputX = 0f
                    state.inputZ = 0f
                    state.screenMode = 0
                }
                1 -> {
                    movePointerId = -1
                    state.inputX = 0f
                    state.inputZ = 0f
                    state.screenMode = 2
                }
                2 -> state.cursorViewMode = !state.cursorViewMode
                3 -> {
                    state.zoomPreset = (state.zoomPreset + 1) % 3
                    state.cameraZoom = when (state.zoomPreset) {
                        0 -> 0.82f
                        1 -> 1.0f
                        else -> 1.28f
                    }
                }
                4 -> state.mounted = !state.mounted
            }
            return true
        }

        val atkDx = tx - (w - 118f)
        val atkDy = ty - (h - 126f)
        if (atkDx * atkDx + atkDy * atkDy <= 50f * 50f) {
            state.triggerAttack()
            return true
        }

        val ddgDx = tx - (w - 216f)
        val ddgDy = ty - (h - 98f)
        if (ddgDx * ddgDx + ddgDy * ddgDy <= 40f * 40f) {
            state.triggerDodge()
            return true
        }

        val jmpDx = tx - (w - 196f)
        val jmpDy = ty - (h - 182f)
        if (jmpDx * jmpDx + jmpDy * jmpDy <= 38f * 38f) {
            state.triggerJump()
            return true
        }

        val slotSize = 44f
        val slotGap = 4f
        val totalHotbarW = 10 * slotSize + 9 * slotGap
        val hbStartX = (w - totalHotbarW) * 0.5f
        val hbY = h - slotSize - 10f
        if (ty >= hbY - 6f && tx in hbStartX..(hbStartX + totalHotbarW)) {
            val s = ((tx - hbStartX) / (slotSize + slotGap)).toInt().coerceIn(0, 9)
            state.triggerHotbarSlot(s)
            return true
        }

        return false
    }

    private fun handleEquipmentTouch(tx: Float, ty: Float, w: Int): Boolean {
        val leftX = 24f
        val topY = 20f
        val toggleW = 148f
        val closeW = 104f
        val closeX = w - closeW - 20f
        val toggleX = closeX - toggleW - 10f

        if (ty in topY..(topY + 42f)) {
            if (tx in closeX..(closeX + closeW)) {
                state.screenMode = 1
                return true
            }
            if (tx in toggleX..(toggleX + toggleW)) {
                state.previewFullHero = !state.previewFullHero
                return true
            }
        }

        val tabY = topY + 40f
        if (ty in tabY..(tabY + 36f)) {
            var curX = leftX
            textPaint.textSize = 14f
            for (s in 0..6) {
                val tw = textPaint.measureText(GameState.SLOT_NAMES[s]) + 22f
                if (tx in curX..(curX + tw)) {
                    state.selectedSlot = s
                    state.activeMetal = state.slotMetal[s]
                    return true
                }
                curX += tw + 6f
            }
        }

        val matStartX = leftX
        val matStartY = tabY + 50f
        val matW = 152f
        val matH = 29f
        if (tx in matStartX..(matStartX + matW) && ty >= matStartY) {
            val m = ((ty - matStartY) / (matH + 5f)).toInt()
            if (m in 0..9) {
                state.activeMetal = m
                state.slotMetal[state.selectedSlot] = m
                state.recalcStats()
                return true
            }
        }

        val runeX = matStartX + matW + 18f
        val runeY = matStartY
        val runeBoxW = 195f
        if (tx in runeX..(runeX + runeBoxW)) {
            if (ty in (runeY + 26f)..(runeY + 62f)) {
                state.runeSlot1 = (state.runeSlot1 + 2) % 11 - 1
                state.recalcStats()
                return true
            }
            if (ty in (runeY + 72f)..(runeY + 108f)) {
                state.runeSlot2 = (state.runeSlot2 + 2) % 11 - 1
                state.recalcStats()
                return true
            }
        }

        return false
    }
}
