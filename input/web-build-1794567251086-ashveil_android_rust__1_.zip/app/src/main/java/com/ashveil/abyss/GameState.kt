package com.ashveil.abyss

import android.content.SharedPreferences
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Core Real-Time 3D RPG, Equipment, Skill, Minecraft-Style World Management & Multiplayer State.
 */
class GameState {

    // Screen Modes:
    // 0 = Minimalist Monospace World & Main Menu (over live 3D ASCII world)
    // 1 = Active Playable 3D ASCII World
    // 2 = 3D Chainmail & Rune Equipment Forge (`1000461485.jpg`)
    // 3 = Minecraft-Style Create New World & Seed Editor Screen
    @Volatile var screenMode: Int = 1

    class SavedWorldSlot(
        var name: String = "Ashveil Wilds",
        var seed: Long = -4918273645L,
        var worldType: Int = 0,
        var gameMode: Int = 0,
        var genCaves: Boolean = true,
        var genRivers: Boolean = true,
        var genShrines: Boolean = true,
        var savedX: Float = 0.0f,
        var savedZ: Float = 4.0f,
        var savedLevel: Int = 13,
        var savedXp: Int = 1943,
        var savedGold: Int = 5194
    )

    val savedWorlds = Array(6) { idx ->
        when (idx) {
            0 -> SavedWorldSlot("Senje's Sanctuary", -4918273645L, 0, 0, true, true, true, 0f, 4f, 13, 1943, 5194)
            1 -> SavedWorldSlot("Obsidian Crags", -9012847561L, 1, 0, true, true, true, 0f, 4f, 15, 3420, 7840)
            2 -> SavedWorldSlot("Elderwood Vale", 77283910421L, 2, 2, true, true, true, 0f, 4f, 19, 4120, 12450)
            else -> SavedWorldSlot("New Realm", 0L, 0, 0, true, true, true, 0f, 4f, 1, 0, 250)
        }
    }
    @Volatile var savedWorldCount: Int = 3
    @Volatile var activeWorldIndex: Int = 0

    // Active World Parameters
    @Volatile var worldName: String = "Senje's Sanctuary"
    @Volatile var worldSeed: Long = -4918273645L
    @Volatile var worldType: Int = 0
    @Volatile var gameMode: Int = 0
    @Volatile var genCaves: Boolean = true
    @Volatile var genRivers: Boolean = true
    @Volatile var genShrines: Boolean = true
    @Volatile var currentBiomeName: String = "Emerald Meadow"

    // New World Creation Builder State (Screen Mode 3)
    @Volatile var newWorldNameIdx: Int = 0
    @Volatile var newWorldSeedInput: String = "8492017492"
    @Volatile var newWorldSeed: Long = 8492017492L
    @Volatile var newWorldType: Int = 0
    @Volatile var newGameMode: Int = 0
    @Volatile var newGenCaves: Boolean = true
    @Volatile var newGenRivers: Boolean = true
    @Volatile var newGenShrines: Boolean = true

    // Visual & Camera Controls
    @Volatile var mounted: Boolean = false
    @Volatile var cursorViewMode: Boolean = true
    @Volatile var debugSolidMode: Boolean = false
    @Volatile var qualityPreset: Int = 2 // 0=Low (12k), 1=Med (24k), 2=Ultra (36k instanced grass)
    @Volatile var zoomPreset: Int = 1
    @Volatile var cameraZoom: Float = 1.0f
    @Volatile var camYaw: Float = 0.0f

    // Player 3D Transform & Physics
    @Volatile var playerX: Float = 0.0f
    @Volatile var playerY: Float = 0.0f
    @Volatile var playerZ: Float = 4.0f
    @Volatile var groundY: Float = 0.0f
    @Volatile var velX: Float = 0.0f
    @Volatile var velY: Float = 0.0f
    @Volatile var velZ: Float = 0.0f
    @Volatile var facingX: Float = 0.0f
    @Volatile var facingZ: Float = -1.0f
    @Volatile var bodyYaw: Float = PI.toFloat()
    @Volatile var turnVel: Float = 0.0f
    @Volatile var gaitPhase: Float = 0.0f
    @Volatile var capeWavePhase: Float = 0.0f
    @Volatile var timeSec: Float = 0.0f
    @Volatile var slashTimer: Float = 0.0f
    @Volatile var slashCooldown: Float = 0.0f
    @Volatile var dodgeTimer: Float = 0.0f
    @Volatile var dodgeCooldown: Float = 0.0f
    @Volatile var dodgeDirX: Float = 0.0f
    @Volatile var dodgeDirZ: Float = -1.0f
    @Volatile var hurtFlash: Float = 0.0f

    // Active 3D Astral Vortex Skill Ring on the Ground (`1000461463.jpg` "New skills")
    @Volatile var vortexActiveTimer: Float = 3.5f
    @Volatile var vortexX: Float = -1.35f
    @Volatile var vortexY: Float = 0.02f
    @Volatile var vortexZ: Float = 3.65f
    @Volatile var vortexTickTimer: Float = 0.0f
    @Volatile var wardBuffTimer: Float = 0.0f

    // Hotbar Cooldowns (10 slots)
    val hotbarCooldowns = FloatArray(10)
    val hotbarMaxCooldowns = floatArrayOf(1.5f, 2.8f, 5.0f, 8.0f, 4.5f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f)

    // Cursor View offset (normalized screen coords)
    @Volatile var cursorX: Float = 0.56f
    @Volatile var cursorY: Float = 0.46f
    @Volatile var inputX: Float = 0.0f
    @Volatile var inputZ: Float = 0.0f

    // RPG Progression & Stats (Matches `Senje` screenshot: HP 1612/1612, MP 134/134, LV 13, 5194g)
    @Volatile var playerName: String = "Senje"
    @Volatile var level: Int = 13
    @Volatile var xp: Int = 1943
    @Volatile var xpNext: Int = 6995
    @Volatile var hp: Int = 1612
    @Volatile var maxHp: Int = 1612
    @Volatile var mp: Int = 134
    @Volatile var maxMp: Int = 134
    @Volatile var gold: Int = 5194
    @Volatile var statPoints: Int = 3
    @Volatile var vit: Int = 18
    @Volatile var str: Int = 22
    @Volatile var dex: Int = 16
    @Volatile var potions: Int = 5
    @Volatile var cinderShards: Int = 4

    // Quest System
    @Volatile var questKills: Int = 0
    @Volatile var questTarget: Int = 5
    @Volatile var questCompleted: Boolean = false

    // 7-Slot Equipment & 10-Material System (Weapon, Helm, Shoulders, Chest, Gloves, Legs, Boots)
    @Volatile var selectedSlot: Int = 1 // Default highlighted tab: Helm (`1000461485.jpg`)
    val slotMetal = intArrayOf(1, 0, 1, 1, 0, 1, 0)
    @Volatile var activeMetal: Int = 0
    @Volatile var runeSlot1: Int = -1
    @Volatile var runeSlot2: Int = -1
    @Volatile var previewYaw: Float = 0.4f
    @Volatile var previewZoom: Float = 1.0f
    @Volatile var previewFullHero: Boolean = false

    // 3D Enemies (Seeded around active world chunks)
    val enemyX = FloatArray(NUM_ENEMIES)
    val enemyY = FloatArray(NUM_ENEMIES)
    val enemyZ = FloatArray(NUM_ENEMIES)
    val enemyHomeX = FloatArray(NUM_ENEMIES)
    val enemyHomeZ = FloatArray(NUM_ENEMIES)
    val enemyYaw = FloatArray(NUM_ENEMIES)
    val enemyGait = FloatArray(NUM_ENEMIES)
    val enemyWindup = FloatArray(NUM_ENEMIES)
    val enemyCooldown = FloatArray(NUM_ENEMIES)
    val enemyHurt = FloatArray(NUM_ENEMIES)
    val enemyHp = IntArray(NUM_ENEMIES)
    val enemyMaxHp = IntArray(NUM_ENEMIES)
    val enemyMetal = IntArray(NUM_ENEMIES)
    val enemyAggro = BooleanArray(NUM_ENEMIES)

    // 3D Loot Drops
    val lootX = FloatArray(MAX_LOOT)
    val lootY = FloatArray(MAX_LOOT)
    val lootZ = FloatArray(MAX_LOOT)
    val lootMetal = IntArray(MAX_LOOT)
    val lootActive = BooleanArray(MAX_LOOT)

    // Status Banner
    @Volatile var statusBanner: String = "World: Senje's Sanctuary • Seed: -4918273645 • Tap [WORLDS] to Create Worlds"
    @Volatile var bannerTimer: Float = 4.5f

    // Server-Authoritative Multiplayer Sync Queue
    class NetEntityPacket {
        var entityId: Long = 0L
        var x: Float = 0f
        var y: Float = 0f
        var z: Float = 0f
        var yaw: Float = 0f
        var animState: Int = 0
        var hp: Int = 100
        var maxHp: Int = 100
    }
    val netPeers = Array(8) { NetEntityPacket() }
    @Volatile var connectedPeers: Int = 0

    init {
        WorldGenerator.ensureChunksAroundPlayer(
            playerX, playerZ, worldSeed, worldType, genCaves, genRivers, genShrines
        )
        groundY = WorldGenerator.getTerrainHeight(playerX, playerZ, worldSeed, worldType, genRivers)
        playerY = groundY
        vortexY = groundY + 0.02f
        for (i in 0 until NUM_ENEMIES) {
            spawnEnemy(i, i < 3)
        }
    }

    fun randomizeNewWorldSeed() {
        val next = WorldGenerator.splitMix64(System.nanoTime() xor (newWorldSeed * 6364136223846793005L + 1442695040888963407L))
        // Keep within readable 10-digit signed range
        val modSeed = (next % 9999999999L)
        newWorldSeed = if (modSeed == 0L) 421987361L else modSeed
        newWorldSeedInput = newWorldSeed.toString()
    }

    fun appendSeedDigit(digitChar: Char) {
        if (digitChar == '-') {
            newWorldSeedInput = if (newWorldSeedInput.startsWith("-")) {
                newWorldSeedInput.substring(1)
            } else {
                "-$newWorldSeedInput"
            }
        } else if (newWorldSeedInput.length < 13) {
            newWorldSeedInput = if (newWorldSeedInput == "0") digitChar.toString() else (newWorldSeedInput + digitChar)
        }
        newWorldSeed = newWorldSeedInput.toLongOrNull() ?: 0L
    }

    fun clearSeedInput() {
        newWorldSeedInput = ""
        newWorldSeed = 0L
    }

    fun backspaceSeedInput() {
        if (newWorldSeedInput.isNotEmpty()) {
            newWorldSeedInput = newWorldSeedInput.dropLast(1)
        }
        newWorldSeed = newWorldSeedInput.toLongOrNull() ?: 0L
    }

    fun loadWorldSlot(slotIdx: Int) {
        if (slotIdx < 0 || slotIdx >= savedWorldCount) return
        saveCurrentWorldToActiveSlot()

        activeWorldIndex = slotIdx
        val w = savedWorlds[slotIdx]
        worldName = w.name
        worldSeed = w.seed
        worldType = w.worldType
        gameMode = w.gameMode
        genCaves = w.genCaves
        genRivers = w.genRivers
        genShrines = w.genShrines
        playerX = w.savedX
        playerZ = w.savedZ
        level = w.savedLevel
        xp = w.savedXp
        gold = w.savedGold
        if (gameMode == 2) {
            gold = max(gold, 99999)
            potions = 99
        }

        WorldGenerator.forceRebuildAllChunks()
        WorldGenerator.ensureChunksAroundPlayer(
            playerX, playerZ, worldSeed, worldType, genCaves, genRivers, genShrines
        )
        groundY = WorldGenerator.getTerrainHeight(playerX, playerZ, worldSeed, worldType, genRivers)
        playerY = groundY
        velX = 0f
        velY = 0f
        velZ = 0f
        for (l in 0 until MAX_LOOT) lootActive[l] = false
        for (i in 0 until NUM_ENEMIES) spawnEnemy(i, i < 3)

        vortexX = playerX - 1.35f
        vortexZ = playerZ - 0.35f
        vortexY = WorldGenerator.getTerrainHeight(vortexX, vortexZ, worldSeed, worldType, genRivers) + 0.02f
        vortexActiveTimer = 3.0f

        statusBanner = "Entered '$worldName' (Seed: $worldSeed • ${WorldGenerator.WORLD_TYPE_NAMES[worldType]})"
        bannerTimer = 4.0f
        screenMode = 1
    }

    fun createAndLaunchNewWorld(prefs: SharedPreferences?) {
        saveCurrentWorldToActiveSlot()

        val parsedSeed = newWorldSeedInput.toLongOrNull()
        val finalSeed = if (parsedSeed != null && parsedSeed != 0L) parsedSeed else {
            randomizeNewWorldSeed()
            newWorldSeed
        }

        val name = WorldGenerator.PRESET_WORLD_NAMES[newWorldNameIdx % WorldGenerator.PRESET_WORLD_NAMES.size]
        val targetSlot = if (savedWorldCount < savedWorlds.size) {
            savedWorldCount++
            savedWorldCount - 1
        } else {
            savedWorlds.size - 1
        }

        val w = savedWorlds[targetSlot]
        w.name = name
        w.seed = finalSeed
        w.worldType = newWorldType
        w.gameMode = newGameMode
        w.genCaves = newGenCaves
        w.genRivers = newGenRivers
        w.genShrines = newGenShrines
        w.savedX = 0.0f
        w.savedZ = 4.0f
        w.savedLevel = level
        w.savedXp = xp
        w.savedGold = if (newGameMode == 2) 99999 else gold

        loadWorldSlot(targetSlot)
        persistWorlds(prefs)
    }

    fun deleteWorldSlot(slotIdx: Int, prefs: SharedPreferences?) {
        if (savedWorldCount <= 1 || slotIdx < 0 || slotIdx >= savedWorldCount) return
        for (i in slotIdx until savedWorldCount - 1) {
            val dst = savedWorlds[i]
            val src = savedWorlds[i + 1]
            dst.name = src.name
            dst.seed = src.seed
            dst.worldType = src.worldType
            dst.gameMode = src.gameMode
            dst.genCaves = src.genCaves
            dst.genRivers = src.genRivers
            dst.genShrines = src.genShrines
            dst.savedX = src.savedX
            dst.savedZ = src.savedZ
            dst.savedLevel = src.savedLevel
            dst.savedXp = src.savedXp
            dst.savedGold = src.savedGold
        }
        savedWorldCount--
        if (activeWorldIndex >= savedWorldCount) {
            activeWorldIndex = savedWorldCount - 1
        }
        loadWorldSlot(activeWorldIndex)
        screenMode = 0
        persistWorlds(prefs)
    }

    fun saveCurrentWorldToActiveSlot() {
        if (activeWorldIndex in 0 until savedWorldCount) {
            val w = savedWorlds[activeWorldIndex]
            w.name = worldName
            w.seed = worldSeed
            w.worldType = worldType
            w.gameMode = gameMode
            w.genCaves = genCaves
            w.genRivers = genRivers
            w.genShrines = genShrines
            w.savedX = playerX
            w.savedZ = playerZ
            w.savedLevel = level
            w.savedXp = xp
            w.savedGold = gold
        }
    }

    fun persistWorlds(prefs: SharedPreferences?) {
        if (prefs == null) return
        saveCurrentWorldToActiveSlot()
        val ed = prefs.edit()
        ed.putInt("world_count", savedWorldCount)
        ed.putInt("active_idx", activeWorldIndex)
        for (i in 0 until savedWorldCount) {
            val w = savedWorlds[i]
            ed.putString("w_${i}_name", w.name)
            ed.putLong("w_${i}_seed", w.seed)
            ed.putInt("w_${i}_type", w.worldType)
            ed.putInt("w_${i}_mode", w.gameMode)
            ed.putBoolean("w_${i}_caves", w.genCaves)
            ed.putBoolean("w_${i}_rivers", w.genRivers)
            ed.putBoolean("w_${i}_shrines", w.genShrines)
            ed.putFloat("w_${i}_x", w.savedX)
            ed.putFloat("w_${i}_z", w.savedZ)
            ed.putInt("w_${i}_lv", w.savedLevel)
            ed.putInt("w_${i}_xp", w.savedXp)
            ed.putInt("w_${i}_gold", w.savedGold)
        }
        ed.apply()
    }

    fun loadPersistedWorlds(prefs: SharedPreferences?) {
        if (prefs == null || !prefs.contains("world_count")) return
        val cnt = prefs.getInt("world_count", 3).coerceIn(1, savedWorlds.size)
        savedWorldCount = cnt
        activeWorldIndex = prefs.getInt("active_idx", 0).coerceIn(0, cnt - 1)
        for (i in 0 until cnt) {
            val w = savedWorlds[i]
            w.name = prefs.getString("w_${i}_name", w.name) ?: w.name
            w.seed = prefs.getLong("w_${i}_seed", w.seed)
            w.worldType = prefs.getInt("w_${i}_type", w.worldType).coerceIn(0, 4)
            w.gameMode = prefs.getInt("w_${i}_mode", w.gameMode).coerceIn(0, 2)
            w.genCaves = prefs.getBoolean("w_${i}_caves", true)
            w.genRivers = prefs.getBoolean("w_${i}_rivers", true)
            w.genShrines = prefs.getBoolean("w_${i}_shrines", true)
            w.savedX = prefs.getFloat("w_${i}_x", 0f)
            w.savedZ = prefs.getFloat("w_${i}_z", 4f)
            w.savedLevel = prefs.getInt("w_${i}_lv", 13)
            w.savedXp = prefs.getInt("w_${i}_xp", 1943)
            w.savedGold = prefs.getInt("w_${i}_gold", 5194)
        }
        loadWorldSlot(activeWorldIndex)
    }

    fun spawnEnemy(i: Int, initialNear: Boolean) {
        val h = WorldGenerator.hashCoords(i, (timeSec * 10f).toInt(), worldSeed, 0xE4E3L + i * 73L)
        val angle = (i * 1.047f) + WorldGenerator.randFloat01(h) * 0.55f
        val dist = if (initialNear) (8.5f + (i % 3) * 3.8f) else (13.0f + (i % 4) * 4.5f)
        val ex = playerX + cos(angle) * dist
        var ez = playerZ - sin(angle) * dist
        if (WorldGenerator.isInsideRiver(ex, ez, worldSeed, worldType, genRivers)) {
            ez -= 5.8f
        }
        enemyX[i] = ex
        enemyZ[i] = ez
        enemyHomeX[i] = ex
        enemyHomeZ[i] = ez
        enemyY[i] = WorldGenerator.getTerrainHeight(ex, ez, worldSeed, worldType, genRivers)
        enemyYaw[i] = angle + PI.toFloat()
        enemyGait[i] = i * 1.1f
        enemyWindup[i] = 0.0f
        enemyCooldown[i] = 0.0f
        enemyHurt[i] = 0.0f
        val lvScale = max(1, level + (i % 3) - 1)
        enemyMaxHp[i] = 240 + lvScale * 28
        enemyHp[i] = enemyMaxHp[i]
        enemyMetal[i] = (i + 1) % 10
        enemyAggro[i] = false
    }

    fun triggerJump() {
        if (playerY <= groundY + 0.04f) {
            velY = 6.2f
        }
    }

    fun triggerDodge() {
        if (dodgeCooldown <= 0.0f && mp >= 10) {
            mp -= 10
            dodgeTimer = 0.30f
            dodgeCooldown = 1.05f
            hotbarCooldowns[4] = 1.05f
            val len = sqrt(inputX * inputX + inputZ * inputZ)
            if (len > 0.1f) {
                dodgeDirX = inputX / len
                dodgeDirZ = inputZ / len
            } else {
                dodgeDirX = facingX
                dodgeDirZ = facingZ
            }
        }
    }

    fun triggerAttack() {
        if (slashCooldown <= 0.0f) {
            slashTimer = 0.28f
            slashCooldown = 0.42f
            hotbarCooldowns[0] = 0.42f
            performMeleeHitCheck(1.0f, 3.3f)
        }
    }

    private fun performMeleeHitCheck(dmgMult: Float, reach: Float) {
        val weaponTier = slotMetal[0]
        val baseDmg = ((46 + str * 2 + weaponTier * 14 + (if (runeSlot1 >= 0) 20 else 0)) * dmgMult).toInt()

        for (i in 0 until NUM_ENEMIES) {
            val dx = enemyX[i] - playerX
            val dz = enemyZ[i] - playerZ
            val dist = sqrt(dx * dx + dz * dz)
            if (dist < reach) {
                val dot = (dx * facingX + dz * facingZ) / max(0.001f, dist)
                if (dot > -0.25f || dist < 1.85f) {
                    damageEnemy(i, baseDmg, dx, dz, dist)
                }
            }
        }
    }

    private fun damageEnemy(i: Int, dmg: Int, dx: Float, dz: Float, dist: Float) {
        enemyHp[i] -= dmg
        enemyHurt[i] = 0.25f
        enemyAggro[i] = true
        if (dist > 0.01f) {
            enemyX[i] += (dx / dist) * 0.45f
            enemyZ[i] += (dz / dist) * 0.45f
        }

        if (enemyHp[i] <= 0) {
            val droppedMetal = enemyMetal[i]
            dropLoot(enemyX[i], enemyZ[i], droppedMetal)
            val xpGain = 220 + level * 25
            val goldGain = 85 + droppedMetal * 24
            xp += xpGain
            gold += goldGain
            cinderShards++

            if (!questCompleted) {
                questKills++
                if (questKills >= questTarget) {
                    questCompleted = true
                    gold += 1000
                    xp += 1200
                    statusBanner = "Quest Complete! +1000g & +1200 XP"
                    bannerTimer = 4.0f
                }
            }

            if (xp >= xpNext) {
                xp -= xpNext
                level++
                xpNext = (xpNext * 1.25f).toInt()
                statPoints += 3
                maxHp += 120
                maxMp += 18
                hp = maxHp
                mp = maxMp
                statusBanner = "LEVEL UP! Reached LV $level (+3 Stat Pts)"
                bannerTimer = 4.0f
            } else if (bannerTimer <= 0.0f) {
                statusBanner = "Slain ${METAL_NAMES[droppedMetal]} Sentinel (+${xpGain} XP, +${goldGain}g)"
                bannerTimer = 2.6f
            }
            spawnEnemy(i, false)
        }
    }

    private fun dropLoot(x: Float, z: Float, metal: Int) {
        for (l in 0 until MAX_LOOT) {
            if (!lootActive[l]) {
                lootActive[l] = true
                lootX[l] = x
                lootZ[l] = z
                lootY[l] = WorldGenerator.getTerrainHeight(x, z, worldSeed, worldType, genRivers)
                lootMetal[l] = metal
                return
            }
        }
    }

    /**
     * Triggers Hotbar Slots 1..10 (`index 0..9`).
     */
    fun triggerHotbarSlot(slot: Int) {
        if (slot in 0..9 && hotbarCooldowns[slot] > 0.0f) return
        when (slot) {
            0 -> triggerAttack()
            1 -> {
                if (mp >= 22) {
                    mp -= 22
                    slashTimer = 0.34f
                    hotbarCooldowns[1] = hotbarMaxCooldowns[1]
                    performMeleeHitCheck(1.75f, 4.2f)
                    statusBanner = "Cast Crescent Cleave! (175% AoE Slash)"
                    bannerTimer = 2.2f
                } else {
                    statusBanner = "Not enough MP for Crescent Cleave!"
                    bannerTimer = 1.8f
                }
            }
            2 -> {
                if (mp >= 30) {
                    mp -= 30
                    vortexX = playerX + facingX * 2.2f
                    vortexZ = playerZ + facingZ * 2.2f
                    vortexY = WorldGenerator.getTerrainHeight(vortexX, vortexZ, worldSeed, worldType, genRivers)
                    vortexActiveTimer = 5.0f
                    vortexTickTimer = 0.0f
                    hotbarCooldowns[2] = hotbarMaxCooldowns[2]
                    statusBanner = "Cast Astral Vortex! (3D ASCII Ground Rune Field)"
                    bannerTimer = 2.5f
                } else {
                    statusBanner = "Not enough MP for Astral Vortex!"
                    bannerTimer = 1.8f
                }
            }
            3 -> {
                if (mp >= 25) {
                    mp -= 25
                    wardBuffTimer = 8.0f
                    hotbarCooldowns[3] = hotbarMaxCooldowns[3]
                    statusBanner = "Moonsteel Ward Active! (50% Damage Reduction + Regen)"
                    bannerTimer = 2.5f
                }
            }
            4 -> triggerDodge()
            5 -> {
                if (potions > 0 && hp < maxHp) {
                    potions--
                    hp = min(maxHp, hp + 480)
                    hotbarCooldowns[5] = 1.0f
                    statusBanner = "Drank Healing Draught (+480 HP)"
                    bannerTimer = 2.2f
                } else if (hp >= maxHp) {
                    statusBanner = "HP is already full!"
                    bannerTimer = 1.5f
                }
            }
            6 -> {
                if (cinderShards > 0 && mp < maxMp) {
                    cinderShards--
                    mp = min(maxMp, mp + 85)
                    hotbarCooldowns[6] = 1.0f
                    statusBanner = "Channelled Cinder Shard (+85 MP)"
                    bannerTimer = 2.2f
                }
            }
            7 -> {
                mounted = !mounted
                statusBanner = if (mounted) "Summoned Spectral War Steed" else "Dismounted War Steed"
                bannerTimer = 2.0f
            }
            8 -> {
                cursorViewMode = !cursorViewMode
                statusBanner = if (cursorViewMode) "Cursor View Mode: ON" else "Cursor View Mode: OFF"
                bannerTimer = 2.0f
            }
            9 -> {
                screenMode = if (screenMode == 2) 1 else 2
            }
        }
    }

    fun stepSimulation(dt: Float) {
        timeSec += dt
        if (bannerTimer > 0.0f) bannerTimer = max(0.0f, bannerTimer - dt)
        if (slashTimer > 0.0f) slashTimer = max(0.0f, slashTimer - dt)
        if (slashCooldown > 0.0f) slashCooldown = max(0.0f, slashCooldown - dt)
        if (dodgeTimer > 0.0f) dodgeTimer = max(0.0f, dodgeTimer - dt)
        if (dodgeCooldown > 0.0f) dodgeCooldown = max(0.0f, dodgeCooldown - dt)
        if (hurtFlash > 0.0f) hurtFlash = max(0.0f, hurtFlash - dt)
        if (wardBuffTimer > 0.0f) {
            wardBuffTimer = max(0.0f, wardBuffTimer - dt)
            if ((timeSec * 10f).toInt() % 5 == 0) {
                hp = min(maxHp, hp + 2)
            }
        }
        for (s in 0..9) {
            if (hotbarCooldowns[s] > 0.0f) {
                hotbarCooldowns[s] = max(0.0f, hotbarCooldowns[s] - dt)
            }
        }

        if (vortexActiveTimer > 0.0f) {
            vortexActiveTimer = max(0.0f, vortexActiveTimer - dt)
            vortexTickTimer += dt
            if (vortexTickTimer >= 0.45f) {
                vortexTickTimer = 0.0f
                val vortexDmg = 34 + str + slotMetal[0] * 8
                for (i in 0 until NUM_ENEMIES) {
                    val dx = enemyX[i] - vortexX
                    val dz = enemyZ[i] - vortexZ
                    val d = sqrt(dx * dx + dz * dz)
                    if (d < 2.6f) {
                        damageEnemy(i, vortexDmg, dx, dz, d)
                    }
                }
            }
        }

        if (screenMode == 2) {
            previewYaw += dt * 0.55f
            return
        }
        if (screenMode != 1) {
            return
        }

        val moveSpeed = (if (mounted) 7.6f else 5.0f) * (1.0f + dex * 0.005f)
        val rotX = inputX * cos(camYaw) + inputZ * sin(camYaw)
        val rotZ = -inputX * sin(camYaw) + inputZ * cos(camYaw)

        if (dodgeTimer > 0.0f) {
            velX = dodgeDirX * 11.8f
            velZ = dodgeDirZ * 11.8f
        } else {
            velX = rotX * moveSpeed
            velZ = rotZ * moveSpeed
        }

        val nextX = playerX + velX * dt
        val nextZ = playerZ + velZ * dt

        if (!collidesWithRockOrTree(nextX, nextZ)) {
            playerX = nextX
            playerZ = nextZ
        }

        // Update active 16x16 world chunks around player
        WorldGenerator.ensureChunksAroundPlayer(
            playerX, playerZ, worldSeed, worldType, genCaves, genRivers, genShrines
        )
        groundY = WorldGenerator.getTerrainHeight(playerX, playerZ, worldSeed, worldType, genRivers)
        val bId = WorldGenerator.getBiomeAt(playerX, playerZ, worldSeed, worldType, genCaves)
        currentBiomeName = WorldGenerator.getBiomeName(bId)

        // Vertical Jump & Terrain Following
        if (playerY > groundY || velY > 0.0f) {
            playerY += velY * dt
            velY -= 16.5f * dt
            if (playerY <= groundY) {
                playerY = groundY
                velY = 0.0f
            }
        } else {
            playerY = groundY
        }

        val spd = sqrt(velX * velX + velZ * velZ)
        if (spd > 0.15f) {
            facingX = velX / spd
            facingZ = velZ / spd
            val targetYaw = atan2(facingX, facingZ)
            var diff = targetYaw - bodyYaw
            while (diff > PI) diff -= (2.0 * PI).toFloat()
            while (diff < -PI) diff += (2.0 * PI).toFloat()
            turnVel = diff * 10.0f
            bodyYaw += turnVel * dt
            gaitPhase += dt * (if (mounted) 11.5f else 8.8f)
            capeWavePhase += dt * 12.5f
        } else {
            turnVel = 0.0f
            capeWavePhase += dt * 3.2f
        }

        // Collect 3D Loot Drops
        for (l in 0 until MAX_LOOT) {
            if (lootActive[l]) {
                val dx = lootX[l] - playerX
                val dz = lootZ[l] - playerZ
                if (dx * dx + dz * dz < 1.85f * 1.85f) {
                    lootActive[l] = false
                    val m = lootMetal[l]
                    activeMetal = m
                    slotMetal[selectedSlot] = m
                    recalcStats()
                    statusBanner = "Looted & Equipped ${METAL_NAMES[m]} ${SLOT_NAMES[selectedSlot]}!"
                    bannerTimer = 3.2f
                }
            }
        }

        // Update 3D Enemies (Stationary at guard post until player approaches within 7.5m)
        for (i in 0 until NUM_ENEMIES) {
            if (enemyHurt[i] > 0.0f) enemyHurt[i] = max(0.0f, enemyHurt[i] - dt)
            if (enemyCooldown[i] > 0.0f) enemyCooldown[i] = max(0.0f, enemyCooldown[i] - dt)

            val dx = playerX - enemyX[i]
            val dz = playerZ - enemyZ[i]
            val dist = sqrt(dx * dx + dz * dz)

            if (dist < 7.5f) {
                enemyAggro[i] = true
            } else if (dist > 14.5f) {
                enemyAggro[i] = false
            }

            if (enemyAggro[i]) {
                enemyYaw[i] = atan2(dx, dz)
                if (dist > 1.65f && enemyWindup[i] <= 0.0f) {
                    val es = 2.95f
                    enemyX[i] += (dx / dist) * es * dt
                    enemyZ[i] += (dz / dist) * es * dt
                    enemyY[i] = WorldGenerator.getTerrainHeight(enemyX[i], enemyZ[i], worldSeed, worldType, genRivers)
                    enemyGait[i] += dt * 7.2f
                } else if (dist <= 1.95f) {
                    if (enemyWindup[i] <= 0.0f && enemyCooldown[i] <= 0.0f) {
                        enemyWindup[i] = 0.42f
                    }
                }

                if (enemyWindup[i] > 0.0f) {
                    enemyWindup[i] -= dt
                    if (enemyWindup[i] <= 0.0f) {
                        enemyCooldown[i] = 1.45f
                        if (dist <= 2.35f && dodgeTimer <= 0.0f && gameMode != 2) {
                            var armorSum = 0
                            for (s in 0..6) armorSum += slotMetal[s]
                            var dmg = max(8, 36 - armorSum)
                            if (wardBuffTimer > 0.0f) dmg /= 2
                            hp = max(0, hp - dmg)
                            hurtFlash = 0.28f
                            if (hp <= 0) {
                                if (gameMode == 1) {
                                    level = max(1, level - 1)
                                    gold = max(0, gold / 2)
                                    statusBanner = "HARDCORE FALL! Respawned at Sanctuary (-1 LV)"
                                } else {
                                    statusBanner = "Respawned at Sanctuary"
                                }
                                hp = maxHp
                                mp = maxMp
                                playerX = 0.0f
                                playerZ = 4.0f
                                bannerTimer = 3.5f
                            }
                        }
                    }
                }
            } else {
                val hx = enemyHomeX[i] - enemyX[i]
                val hz = enemyHomeZ[i] - enemyZ[i]
                val hDist = sqrt(hx * hx + hz * hz)
                if (hDist > 0.35f) {
                    enemyYaw[i] = atan2(hx, hz)
                    enemyX[i] += (hx / hDist) * 2.0f * dt
                    enemyZ[i] += (hz / hDist) * 2.0f * dt
                    enemyY[i] = WorldGenerator.getTerrainHeight(enemyX[i], enemyZ[i], worldSeed, worldType, genRivers)
                    enemyGait[i] += dt * 5.0f
                }
            }
        }
    }

    private fun collidesWithRockOrTree(nx: Float, nz: Float): Boolean {
        for (cIdx in 0 until WorldGenerator.MAX_CACHED_CHUNKS) {
            val chunk = WorldGenerator.chunkGrid[cIdx]
            if (chunk.builtSeed == Long.MIN_VALUE) continue
            for (r in 0 until chunk.rockCount) {
                val rf = chunk.rocks[r]
                val dx = nx - rf.x
                val dz = nz - rf.z
                val minR = min(rf.radiusX, rf.radiusZ) * 0.45f + 0.30f
                if (dx * dx + dz * dz < minR * minR) return true
            }
            for (t in 0 until chunk.treeCount) {
                val tr = chunk.trees[t]
                val dx = nx - tr.x
                val dz = nz - tr.z
                if (dx * dx + dz * dz < 0.60f * 0.60f) return true
            }
        }
        return false
    }

    fun recalcStats() {
        var bonusHp = 0
        var bonusStr = 0
        for (s in 0..6) {
            bonusHp += slotMetal[s] * 35
            bonusStr += slotMetal[s] * 2
        }
        maxHp = 1200 + vit * 20 + bonusHp + (if (runeSlot2 >= 0) 150 else 0)
        maxMp = 100 + dex * 2 + (if (runeSlot1 >= 0) 30 else 0)
        if (hp > maxHp) hp = maxHp
        if (mp > maxMp) mp = maxMp
    }

    companion object {
        const val NUM_ENEMIES = 7
        const val MAX_LOOT = 6

        val SLOT_NAMES = arrayOf(
            "Weapon", "Helm", "Shoulders", "Chest", "Gloves", "Legs", "Boots"
        )

        val METAL_NAMES = arrayOf(
            "Iron", "Steel", "Bronze", "Silver", "Gold",
            "Moonsteel", "Nightglass", "Bloodiron", "Ossite", "Emberstone"
        )

        val HOTBAR_LABELS = arrayOf(
            "SLASH", "CLEAVE", "VORTEX", "WARD", "DODGE",
            "HP POT", "MP SHD", "STEED", "CURSOR", "FORGE"
        )

        val METAL_RGB = arrayOf(
            floatArrayOf(0.66f, 0.70f, 0.75f), // 0: Iron
            floatArrayOf(0.82f, 0.87f, 0.94f), // 1: Steel
            floatArrayOf(0.84f, 0.62f, 0.38f), // 2: Bronze
            floatArrayOf(0.92f, 0.96f, 1.00f), // 3: Silver
            floatArrayOf(0.98f, 0.84f, 0.34f), // 4: Gold
            floatArrayOf(0.58f, 0.84f, 1.00f), // 5: Moonsteel
            floatArrayOf(0.52f, 0.44f, 0.82f), // 6: Nightglass
            floatArrayOf(0.92f, 0.30f, 0.32f), // 7: Bloodiron
            floatArrayOf(0.88f, 0.90f, 0.80f), // 8: Ossite
            floatArrayOf(1.00f, 0.54f, 0.24f)  // 9: Emberstone
        )
    }
}
