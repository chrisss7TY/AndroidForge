package com.ashveil.abyss

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * True Minecraft-Style Seeded Procedural World Generator for ASHVEIL (v7.0.0).
 *
 * Key upgrades over legacy generator:
 * 1. EVERY chunk (including spawn chunks around (0, 0)) is 100% deterministically generated
 *    from the 64-bit World Seed + World Type + Structure Toggles. Changing the seed or creating
 *    a new world produces a genuinely different 3D landscape, river trajectory, cave sanctuary,
 *    biome layout, and object placement right from spawn!
 * 2. Analytical trigonometric FBM heightfield (`getTerrainHeight`) is shared identically between
 *    Kotlin CPU physics/placement and GLSL #version 300 es GPU vertex shaders (`vsTerrain` and
 *    `vsGrass`), guaranteeing that all 36,000 instanced 3D ASCII grass blades and all rocks/trees
 *    sit 100% flush on the 3D terrain slopes with zero floating or clipping!
 */
object WorldGenerator {

    const val CHUNK_SIZE = 16.0f
    const val ACTIVE_GRID_RADIUS = 3 // 7x7 chunks active around player (49 chunks cached)
    const val GRID_DIM = ACTIVE_GRID_RADIUS * 2 + 1
    const val MAX_CACHED_CHUNKS = GRID_DIM * GRID_DIM

    // 5 Minecraft-style World Generator Types
    val WORLD_TYPE_NAMES = arrayOf(
        "Standard Realm",
        "Amplified Crags",
        "Elderwood Forest",
        "Moonlit Caverns",
        "Shattered Basin"
    )

    val GAME_MODE_NAMES = arrayOf(
        "Survival RPG",
        "Hardcore Abyss",
        "Creative Sandbox"
    )

    val PRESET_WORLD_NAMES = arrayOf(
        "Ashveil Wilds",
        "Senje's Sanctuary",
        "Moonlit Hollow",
        "Obsidian Reach",
        "Elderwood Vale",
        "Nightglass Fen",
        "Bloodiron Crags",
        "Whispering Abyss"
    )

    class PropInstance(
        var x: Float = 0f,
        var y: Float = 0f,
        var z: Float = 0f,
        var radiusX: Float = 1f,
        var heightY: Float = 1f,
        var radiusZ: Float = 1f,
        var yawDeg: Float = 0f,
        var variant: Int = 0
    )

    class WorldChunk {
        var chunkX: Int = Int.MIN_VALUE
        var chunkZ: Int = Int.MIN_VALUE
        var builtSeed: Long = Long.MIN_VALUE
        var builtType: Int = -1
        var biomeId: Int = 0 // 0=Emerald Meadow, 1=Elderwood Forest, 2=Obsidian Crags, 3=Moonlit Cave

        var rockCount: Int = 0
        val rocks = Array(12) { PropInstance() }

        var treeCount: Int = 0
        val trees = Array(10) { PropInstance() }

        var crystalCount: Int = 0
        val crystals = Array(8) { PropInstance() }

        var hasCaveArch: Boolean = false
        var archX: Float = 0f
        var archY: Float = 0f
        var archZ: Float = 0f
        var archYaw: Float = 0f

        var hasShrine: Boolean = false
        var shrineX: Float = 0f
        var shrineY: Float = 0f
        var shrineZ: Float = 0f
    }

    val chunkGrid = Array(MAX_CACHED_CHUNKS) { WorldChunk() }
    private var lastCenterChunkX = Int.MIN_VALUE
    private var lastCenterChunkZ = Int.MIN_VALUE
    private var lastSeed = Long.MIN_VALUE
    private var lastWorldType = -1
    private var lastFlags = -1

    // Cached GPU-compatible float seed offsets (passed directly to GLSL shaders!)
    val gpuSeedParams = FloatArray(4)

    fun updateGpuSeedParams(seed: Long, worldType: Int) {
        val h1 = splitMix64(seed)
        val h2 = splitMix64(h1 + 0x9E3779B97F4A7C15L)
        // [0] = seedPhaseX, [1] = seedPhaseZ, [2] = riverPhase, [3] = heightScale
        gpuSeedParams[0] = ((h1 and 0xFFFFL).toFloat() / 65535.0f) * 62.8318f
        gpuSeedParams[1] = (((h1 ushr 16) and 0xFFFFL).toFloat() / 65535.0f) * 62.8318f
        gpuSeedParams[2] = ((h2 and 0xFFFFL).toFloat() / 65535.0f) * 6.28318f
        gpuSeedParams[3] = when (worldType) {
            1 -> 1.85f // Amplified Crags
            2 -> 0.85f // Elderwood Forest
            3 -> 1.25f // Moonlit Caverns
            4 -> 0.45f // Shattered Basin
            else -> 1.05f // Standard Realm
        }
    }

    fun splitMix64(x: Long): Long {
        var z = x + -0x61c8864680b583ebL
        z = (z xor (z ushr 30)) * -0x40a7b892e31b1a47L
        z = (z xor (z ushr 27)) * -0x6b2fb644ecceee15L
        return z xor (z ushr 31)
    }

    fun hashCoords(cx: Int, cz: Int, seed: Long, salt: Long): Long {
        val h = seed xor (cx.toLong() * 341873128712L) xor (cz.toLong() * 132897987541L) xor salt
        return splitMix64(h)
    }

    fun randFloat01(h: Long): Float {
        return ((h ushr 40) and 0xFFFFFFL).toFloat() / 16777216.0f
    }

    /**
     * River center Z coordinate at world X.
     * Uses `gpuSeedParams[2]` so every seed bends the river differently and matches the GPU shader!
     */
    fun riverCenterZ(wx: Float, seed: Long, worldType: Int): Float {
        updateGpuSeedParams(seed, worldType)
        val rPhase = gpuSeedParams[2]
        val amp = if (worldType == 4) 3.6f else 2.35f
        val baseOffset = -6.8f + sin(rPhase) * 2.2f
        return baseOffset + sin(wx * 0.12f + rPhase) * amp + cos(wx * 0.055f - rPhase * 0.6f) * 1.45f
    }

    fun riverHalfWidth(worldType: Int, genRivers: Boolean): Float {
        if (!genRivers) return 0.0f
        return if (worldType == 4) 3.4f else 2.55f
    }

    fun isInsideRiver(wx: Float, wz: Float, seed: Long, worldType: Int, genRivers: Boolean): Boolean {
        if (!genRivers) return false
        val rz = riverCenterZ(wx, seed, worldType)
        return abs(wz - rz) < riverHalfWidth(worldType, genRivers)
    }

    /**
     * Seeded Moonlit Cave Sanctuary center near the starting region + infinite regional caves.
     */
    fun getPrimaryCaveCenterX(seed: Long): Float {
        val h = splitMix64(seed xor 0xCA7E01L)
        return (randFloat01(h) - 0.5f) * 14.0f
    }

    fun getPrimaryCaveCenterZ(seed: Long): Float {
        val h = splitMix64(seed xor 0xCA7E02L)
        return -17.5f - randFloat01(h) * 5.0f
    }

    fun isInsideMoonlitCave(wx: Float, wz: Float, seed: Long, genCaves: Boolean): Boolean {
        if (!genCaves) return false
        val cx0 = getPrimaryCaveCenterX(seed)
        val cz0 = getPrimaryCaveCenterZ(seed)
        val dx0 = wx - cx0
        val dz0 = wz - cz0
        if (dx0 * dx0 + dz0 * dz0 < 9.5f * 9.5f) return true

        val regX = floor((wx + 32.0f) / 64.0f).toInt()
        val regZ = floor((wz + 32.0f) / 64.0f).toInt()
        if (regX == 0 && regZ == 0) return false
        val h = hashCoords(regX, regZ, seed, 0xCA7E5L)
        if ((h and 1L) == 0L) {
            val cx = regX * 64.0f + (randFloat01(h) - 0.5f) * 26.0f
            val cz = regZ * 64.0f + (randFloat01(splitMix64(h)) - 0.5f) * 26.0f
            val dx = wx - cx
            val dz = wz - cz
            if (dx * dx + dz * dz < 10.0f * 10.0f) return true
        }
        return false
    }

    /**
     * Analytical Continuous 3D Terrain Height Function.
     * This exact mathematical formula is also evaluated in the GLSL vertex shaders (`vsTerrain` and `vsGrass`)
     * so the 3D terrain mesh, 36,000 instanced grass blades, player physics, and rock/tree placement
     * share the exact same elevation at every `(wx, wz)` coordinate!
     */
    fun getTerrainHeight(wx: Float, wz: Float, seed: Long, worldType: Int, genRivers: Boolean): Float {
        updateGpuSeedParams(seed, worldType)
        val px = gpuSeedParams[0]
        val pz = gpuSeedParams[1]
        val hScale = gpuSeedParams[3]

        // Smooth valley flattening along the river so planar water reflections stay pristine
        var riverMask = 1.0f
        if (genRivers) {
            val distRiver = abs(wz - riverCenterZ(wx, seed, worldType))
            riverMask = ((distRiver - 3.6f) / 5.5f).coerceIn(0.0f, 1.0f)
            riverMask = riverMask * riverMask * (3.0f - 2.0f * riverMask)
        }

        // Gentle clearing right at initial spawn (0, 4)
        val dxSpawn = wx
        val dzSpawn = wz - 4.0f
        val distSpawn = sqrt(dxSpawn * dxSpawn + dzSpawn * dzSpawn)
        var spawnMask = ((distSpawn - 4.5f) / 7.5f).coerceIn(0.0f, 1.0f)
        spawnMask = spawnMask * spawnMask * (3.0f - 2.0f * spawnMask)

        // Multi-octave trigonometric FBM (100% deterministic & identical on CPU and GPU)
        val n1 = sin(wx * 0.075f + px) * cos(wz * 0.075f + pz)
        val n2 = sin((wx * 0.16f - wz * 0.11f) + px * 1.7f) * 0.5f
        val n3 = cos((wx * 0.042f + wz * 0.058f) - pz * 1.3f) * 0.75f
        val rawH = max(0.0f, (n1 + n2 + n3 + 0.65f) * 0.52f)

        return rawH * hScale * riverMask * spawnMask
    }

    /**
     * Biome classification based on seed, coordinates, and World Type.
     */
    fun getBiomeAt(wx: Float, wz: Float, seed: Long, worldType: Int, genCaves: Boolean): Int {
        if (isInsideMoonlitCave(wx, wz, seed, genCaves)) return 3
        updateGpuSeedParams(seed, worldType)
        val px = gpuSeedParams[0]
        val pz = gpuSeedParams[1]
        val moisture = sin(wx * 0.038f + px * 0.5f) * cos(wz * 0.038f - pz * 0.5f) * 0.5f + 0.5f
        return when (worldType) {
            1 -> if (moisture > 0.35f) 2 else 0 // Amplified Crags
            2 -> if (moisture > 0.22f) 1 else 0 // Elderwood Forest
            3 -> if (moisture > 0.45f) 3 else 2 // Moonlit Caverns
            else -> when {
                moisture > 0.66f -> 2 // Obsidian Crags
                moisture > 0.38f -> 1 // Elderwood Forest
                else -> 0             // Emerald Meadow
            }
        }
    }

    fun getBiomeName(biomeId: Int): String = when (biomeId) {
        1 -> "Elderwood Forest"
        2 -> "Obsidian Crags"
        3 -> "Moonlit Sanctuary"
        else -> "Emerald Meadow"
    }

    fun ensureChunksAroundPlayer(
        playerX: Float,
        playerZ: Float,
        seed: Long,
        worldType: Int,
        genCaves: Boolean,
        genRivers: Boolean,
        genShrines: Boolean
    ) {
        updateGpuSeedParams(seed, worldType)
        val pcx = floor(playerX / CHUNK_SIZE).toInt()
        val pcz = floor(playerZ / CHUNK_SIZE).toInt()
        val flags = (if (genCaves) 1 else 0) or (if (genRivers) 2 else 0) or (if (genShrines) 4 else 0)

        if (pcx == lastCenterChunkX && pcz == lastCenterChunkZ &&
            seed == lastSeed && worldType == lastWorldType && flags == lastFlags
        ) {
            return
        }
        lastCenterChunkX = pcx
        lastCenterChunkZ = pcz
        lastSeed = seed
        lastWorldType = worldType
        lastFlags = flags

        var slot = 0
        for (dz in -ACTIVE_GRID_RADIUS..ACTIVE_GRID_RADIUS) {
            for (dx in -ACTIVE_GRID_RADIUS..ACTIVE_GRID_RADIUS) {
                val cx = pcx + dx
                val cz = pcz + dz
                val chunk = chunkGrid[slot++]
                if (chunk.chunkX != cx || chunk.chunkZ != cz ||
                    chunk.builtSeed != seed || chunk.builtType != worldType
                ) {
                    populateChunk(chunk, cx, cz, seed, worldType, genCaves, genRivers, genShrines)
                }
            }
        }
    }

    fun forceRebuildAllChunks() {
        lastSeed = Long.MIN_VALUE
        for (c in chunkGrid) {
            c.builtSeed = Long.MIN_VALUE
        }
    }

    private fun populateChunk(
        chunk: WorldChunk,
        cx: Int,
        cz: Int,
        seed: Long,
        worldType: Int,
        genCaves: Boolean,
        genRivers: Boolean,
        genShrines: Boolean
    ) {
        chunk.chunkX = cx
        chunk.chunkZ = cz
        chunk.builtSeed = seed
        chunk.builtType = worldType
        chunk.rockCount = 0
        chunk.treeCount = 0
        chunk.crystalCount = 0
        chunk.hasCaveArch = false
        chunk.hasShrine = false

        val baseX = cx * CHUNK_SIZE
        val baseZ = cz * CHUNK_SIZE
        val centerX = baseX + CHUNK_SIZE * 0.5f
        val centerZ = baseZ + CHUNK_SIZE * 0.5f
        chunk.biomeId = getBiomeAt(centerX, centerZ, seed, worldType, genCaves)

        // Check if this chunk hosts the primary seeded Moonlit Cave Archway
        val caveX = getPrimaryCaveCenterX(seed)
        val caveZ = getPrimaryCaveCenterZ(seed)
        val caveEntranceZ = caveZ + 4.8f
        if (genCaves && caveX >= baseX && caveX < baseX + CHUNK_SIZE &&
            caveEntranceZ >= baseZ && caveEntranceZ < baseZ + CHUNK_SIZE
        ) {
            chunk.hasCaveArch = true
            chunk.archX = caveX
            chunk.archZ = caveEntranceZ
            chunk.archY = getTerrainHeight(caveX, caveEntranceZ, seed, worldType, genRivers)
            chunk.archYaw = 0.0f
            // Flanking cliff walls around the cave chamber
            addRock(chunk, caveX - 3.6f, caveZ + 1.5f, 2.8f, 6.4f, 2.8f, 18f, seed, worldType, genRivers)
            addRock(chunk, caveX + 3.6f, caveZ + 1.5f, 2.8f, 6.4f, 2.8f, -18f, seed, worldType, genRivers)
            addRock(chunk, caveX - 2.4f, caveZ - 3.2f, 3.2f, 7.2f, 3.0f, 32f, seed, worldType, genRivers)
            addRock(chunk, caveX + 2.4f, caveZ - 3.2f, 3.2f, 7.2f, 3.0f, -32f, seed, worldType, genRivers)
            // Bioluminescent crystals inside the cave grotto
            for (c in 0 until 5) {
                val ch = hashCoords(cx, cz, seed, 0xC915L + c * 31L)
                val ox = (randFloat01(ch) - 0.5f) * 5.2f
                val oz = (randFloat01(splitMix64(ch)) - 0.5f) * 5.2f
                addCrystal(
                    chunk, caveX + ox, caveZ + oz,
                    0.38f + randFloat01(ch xor 99L) * 0.25f,
                    1.25f + randFloat01(ch xor 199L) * 0.95f,
                    c % 2, seed, worldType, genRivers
                )
            }
        }

        // Seeded Canyon & Sanctuary Framing around the Starting Valley (cx in -1..0, cz in -1..0)
        // Uses the world seed so every new world reshapes the canyon walls, trees, and boulders!
        val isSpawnArea = (cx in -1..0 && cz in -1..0)
        val rockBudget = when {
            chunk.biomeId == 2 || worldType == 1 -> 8
            isSpawnArea -> 6
            else -> 5
        }
        val treeBudget = when {
            chunk.biomeId == 1 || worldType == 2 -> 8
            chunk.biomeId == 2 -> 2
            else -> 5
        }

        // 1. Procedural Faceted Rocks & Canyon Cliffs
        for (i in 0 until rockBudget) {
            val h = hashCoords(cx, cz, seed, 100L + i * 37L)
            val rx = baseX + 1.8f + randFloat01(h) * (CHUNK_SIZE - 3.6f)
            val rz = baseZ + 1.8f + randFloat01(splitMix64(h)) * (CHUNK_SIZE - 3.6f)

            // Keep immediate player spawn point (0, 4) clear so player never spawns inside a rock
            val dSpawn2 = rx * rx + (rz - 4.0f) * (rz - 4.0f)
            if (dSpawn2 < 3.6f * 3.6f) continue
            if (isInsideRiver(rx, rz, seed, worldType, genRivers)) continue
            if (overlapsExisting(chunk, rx, rz, 2.2f)) continue

            val isCliffPillar = (chunk.biomeId == 2 || worldType == 1 || (isSpawnArea && abs(rx) > 3.8f) || (h and 3L) == 0L)
            val radX = if (isCliffPillar) (1.9f + randFloat01(h xor 17L) * 1.3f) else (1.1f + randFloat01(h xor 17L) * 0.9f)
            val heightY = if (isCliffPillar) (4.2f + randFloat01(h xor 53L) * 3.8f) else (1.3f + randFloat01(h xor 53L) * 1.4f)
            val radZ = radX * (0.82f + randFloat01(h xor 89L) * 0.36f)
            val yaw = randFloat01(h xor 131L) * 360.0f
            addRock(chunk, rx, rz, radX, heightY, radZ, yaw, seed, worldType, genRivers)
        }

        // 2. Procedural Multi-Canopy 3D Fantasy Trees
        for (i in 0 until treeBudget) {
            val h = hashCoords(cx, cz, seed, 500L + i * 43L)
            val tx = baseX + 2.0f + randFloat01(h) * (CHUNK_SIZE - 4.0f)
            val tz = baseZ + 2.0f + randFloat01(splitMix64(h)) * (CHUNK_SIZE - 4.0f)

            val dSpawn2 = tx * tx + (tz - 4.0f) * (tz - 4.0f)
            if (dSpawn2 < 4.2f * 4.2f) continue
            if (isInsideRiver(tx, tz, seed, worldType, genRivers)) continue
            if (isInsideMoonlitCave(tx, tz, seed, genCaves)) continue
            if (overlapsExisting(chunk, tx, tz, 2.5f)) continue

            val trunkH = 3.1f + randFloat01(h xor 29L) * 1.8f
            val crownR = 1.85f + randFloat01(h xor 71L) * 0.95f
            val yaw = randFloat01(h xor 113L) * 360.0f
            addTree(chunk, tx, tz, trunkH, crownR, yaw, seed, worldType, genRivers)
        }

        // 3. Procedural Bioluminescent Crystals in Cave / Crag Chunks
        if (genCaves && (chunk.biomeId == 3 || worldType == 3 || (hashCoords(cx, cz, seed, 888L) and 3L) == 0L)) {
            val cCount = if (chunk.biomeId == 3 || worldType == 3) 4 else 2
            for (i in 0 until cCount) {
                val h = hashCoords(cx, cz, seed, 900L + i * 61L)
                val gx = baseX + 2.2f + randFloat01(h) * (CHUNK_SIZE - 4.4f)
                val gz = baseZ + 2.2f + randFloat01(splitMix64(h)) * (CHUNK_SIZE - 4.4f)
                if (isInsideRiver(gx, gz, seed, worldType, genRivers)) continue
                if (overlapsExisting(chunk, gx, gz, 1.4f)) continue
                val rad = 0.36f + randFloat01(h xor 19L) * 0.28f
                val hgt = 1.15f + randFloat01(h xor 41L) * 0.95f
                addCrystal(chunk, gx, gz, rad, hgt, (i + abs(cx)) % 2, seed, worldType, genRivers)
            }
        }

        // 4. Procedural Ancient Runic Shrine
        if (genShrines) {
            val sh = hashCoords(cx, cz, seed, 1337L)
            if ((sh and 3L) == 0L) {
                val sx = baseX + 3.5f + randFloat01(sh) * (CHUNK_SIZE - 7.0f)
                val sz = baseZ + 3.5f + randFloat01(splitMix64(sh)) * (CHUNK_SIZE - 7.0f)
                if (!isInsideRiver(sx, sz, seed, worldType, genRivers) && !overlapsExisting(chunk, sx, sz, 2.2f)) {
                    chunk.hasShrine = true
                    chunk.shrineX = sx
                    chunk.shrineZ = sz
                    chunk.shrineY = getTerrainHeight(sx, sz, seed, worldType, genRivers)
                }
            }
        }
    }

    private fun overlapsExisting(chunk: WorldChunk, x: Float, z: Float, minDist: Float): Boolean {
        val minSq = minDist * minDist
        for (i in 0 until chunk.rockCount) {
            val dx = chunk.rocks[i].x - x
            val dz = chunk.rocks[i].z - z
            if (dx * dx + dz * dz < minSq) return true
        }
        for (i in 0 until chunk.treeCount) {
            val dx = chunk.trees[i].x - x
            val dz = chunk.trees[i].z - z
            if (dx * dx + dz * dz < minSq) return true
        }
        if (chunk.hasCaveArch) {
            val dx = chunk.archX - x
            val dz = chunk.archZ - z
            if (dx * dx + dz * dz < 4.2f * 4.2f) return true
        }
        return false
    }

    private fun addRock(
        chunk: WorldChunk,
        wx: Float,
        wz: Float,
        rx: Float,
        hy: Float,
        rz: Float,
        yaw: Float,
        seed: Long,
        worldType: Int,
        genRivers: Boolean
    ) {
        if (chunk.rockCount >= chunk.rocks.size) return
        val p = chunk.rocks[chunk.rockCount++]
        p.x = wx
        p.y = getTerrainHeight(wx, wz, seed, worldType, genRivers)
        p.z = wz
        p.radiusX = rx
        p.heightY = hy
        p.radiusZ = rz
        p.yawDeg = yaw
    }

    private fun addTree(
        chunk: WorldChunk,
        wx: Float,
        wz: Float,
        trunkH: Float,
        crownR: Float,
        yaw: Float,
        seed: Long,
        worldType: Int,
        genRivers: Boolean
    ) {
        if (chunk.treeCount >= chunk.trees.size) return
        val p = chunk.trees[chunk.treeCount++]
        p.x = wx
        p.y = getTerrainHeight(wx, wz, seed, worldType, genRivers)
        p.z = wz
        p.radiusX = crownR
        p.heightY = trunkH
        p.radiusZ = crownR
        p.yawDeg = yaw
    }

    private fun addCrystal(
        chunk: WorldChunk,
        wx: Float,
        wz: Float,
        rad: Float,
        hgt: Float,
        variant: Int,
        seed: Long,
        worldType: Int,
        genRivers: Boolean
    ) {
        if (chunk.crystalCount >= chunk.crystals.size) return
        val p = chunk.crystals[chunk.crystalCount++]
        p.x = wx
        p.y = getTerrainHeight(wx, wz, seed, worldType, genRivers)
        p.z = wz
        p.radiusX = rad
        p.heightY = hgt
        p.radiusZ = rad
        p.variant = variant
    }
}
