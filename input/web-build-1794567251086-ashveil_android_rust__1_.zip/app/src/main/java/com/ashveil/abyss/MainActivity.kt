package com.ashveil.abyss

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout

/**
 * Main Android Entry Activity for ASHVEIL (v7.0.0 Kotlin).
 * Configures OpenGL ES 3.0 3D ASCII surface view, HUD & World Generator overlay,
 * and persistent SharedPreferences world save state.
 */
class MainActivity : Activity() {

    private var glView: GLSurfaceView? = null
    private var hudView: HudOverlayView? = null
    private lateinit var state: GameState
    private var prefs: SharedPreferences? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            WindowManager.LayoutParams.FLAG_FULLSCREEN or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        )

        prefs = getSharedPreferences("ashveil_worlds_v7", Context.MODE_PRIVATE)
        state = GameState()
        state.loadPersistedWorlds(prefs)

        val root = FrameLayout(this)

        val surface = GLSurfaceView(this).apply {
            setEGLContextClientVersion(3)
            setEGLConfigChooser(8, 8, 8, 8, 16, 0)
            setRenderer(AsciiGlRenderer(state))
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        }
        glView = surface

        val overlay = HudOverlayView(this, state, prefs)
        hudView = overlay

        root.addView(
            surface,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )
        root.addView(
            overlay,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        glView?.onResume()
    }

    override fun onPause() {
        if (::state.isInitialized) {
            state.persistWorlds(prefs)
        }
        glView?.onPause()
        super.onPause()
    }
}
