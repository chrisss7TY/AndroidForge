package com.ashveil.abyss

import android.opengl.GLES30
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * High-Performance OpenGL ES 3.0 VAO/VBO/IBO 3D Mesh Library.
 * Builds true 3D geometric meshes (faceted craggy boulders, tapered tree trunks,
 * multi-lobed foliage canopies, vaulted cave arches, hexagonal crystals, anatomical
 * armor components, greatsword blades, 3D heightfield terrain grid, and 36,000
 * GPU-instanced 3D grass/wildflower ribbons) using hardware VAOs for single-call binding.
 */
class MeshLibrary {

    class GlMesh(
        val vao: Int,
        val vbo: Int,
        val ibo: Int,
        val indexCount: Int
    )

    lateinit var rockMesh: GlMesh
    lateinit var trunkMesh: GlMesh
    lateinit var canopyMesh: GlMesh
    lateinit var crystalMesh: GlMesh
    lateinit var archMesh: GlMesh
    lateinit var cuirassMesh: GlMesh
    lateinit var helmMesh: GlMesh
    lateinit var limbMesh: GlMesh
    lateinit var swordMesh: GlMesh
    lateinit var cloakMesh: GlMesh
    lateinit var coifBustMesh: GlMesh
    lateinit var terrainGridMesh: GlMesh
    lateinit var flatQuadMesh: GlMesh

    var grassVao: Int = 0
    var grassRibbonVbo: Int = 0
    var grassInstanceVbo: Int = 0

    fun initAllMeshes() {
        rockMesh = buildFacetedRockMesh(12, 14)
        trunkMesh = buildTaperedTrunkMesh(10, 12)
        canopyMesh = buildFoliageCanopyMesh(12, 16)
        crystalMesh = buildHexCrystalMesh()
        archMesh = buildCaveArchMesh(16, 10)
        cuirassMesh = buildAnatomicalCuirassMesh(14, 16)
        helmMesh = buildKnightHelmMesh(14, 16)
        limbMesh = buildTaperedLimbMesh(10, 12)
        swordMesh = buildGreatswordMesh()
        cloakMesh = buildTravelerCloakMesh(10, 12)
        coifBustMesh = buildChainmailBustMesh(20, 24)
        terrainGridMesh = buildSubdividedGridMesh(44, 44)
        flatQuadMesh = buildSubdividedGridMesh(2, 2)
        buildInstancedGrassVao()
    }

    /**
     * Creates an OpenGL ES 3.0 VAO + VBO + IBO with interleaved [x, y, z, nx, ny, nz, u, v] (32 bytes/vertex).
     */
    private fun uploadIndexedMesh(verts: FloatArray, indices: ShortArray): GlMesh {
        val vaoArr = IntArray(1)
        val bufArr = IntArray(2)
        GLES30.glGenVertexArrays(1, vaoArr, 0)
        GLES30.glGenBuffers(2, bufArr, 0)

        val vao = vaoArr[0]
        val vbo = bufArr[0]
        val ibo = bufArr[1]

        val vb = ByteBuffer.allocateDirect(verts.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
        vb.put(verts).position(0)

        val ib = ByteBuffer.allocateDirect(indices.size * 2)
            .order(ByteOrder.nativeOrder()).asShortBuffer()
        ib.put(indices).position(0)

        GLES30.glBindVertexArray(vao)

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, verts.size * 4, vb, GLES30.GL_STATIC_DRAW)

        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, ibo)
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, indices.size * 2, ib, GLES30.GL_STATIC_DRAW)

        // Attribute 0: vec3 aPos (offset 0)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 32, 0)
        // Attribute 1: vec3 aNormal (offset 12)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 32, 12)
        // Attribute 2: vec2 aUv (offset 24)
        GLES30.glEnableVertexAttribArray(2)
        GLES30.glVertexAttribPointer(2, 2, GLES30.GL_FLOAT, false, 32, 24)

        GLES30.glBindVertexArray(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, 0)

        return GlMesh(vao, vbo, ibo, indices.size)
    }

    /**
     * Builds a parametrized deformed UV surface with analytical/finite-difference normals.
     */
    private fun buildParametricSurface(
        latBands: Int,
        lonBands: Int,
        evalPoint: (u: Float, v: Float, outPos: FloatArray) -> Unit
    ): GlMesh {
        val vertCount = (latBands + 1) * (lonBands + 1)
        val verts = FloatArray(vertCount * 8)
        val p0 = FloatArray(3)
        val px = FloatArray(3)
        val py = FloatArray(3)
        val eps = 0.015f

        var vPtr = 0
        for (lat in 0..latBands) {
            val v = lat / latBands.toFloat()
            for (lon in 0..lonBands) {
                val u = lon / lonBands.toFloat()
                evalPoint(u, v, p0)
                evalPoint(min(1f, u + eps), v, px)
                evalPoint(u, min(1f, v + eps), py)

                val tx = px[0] - p0[0]
                val ty = px[1] - p0[1]
                val tz = px[2] - p0[2]

                val bx = py[0] - p0[0]
                val by = py[1] - p0[1]
                val bz = py[2] - p0[2]

                var nx = by * tz - bz * ty
                var ny = bz * tx - bx * tz
                var nz = bx * ty - by * tx
                val len = sqrt(nx * nx + ny * ny + nz * nz)
                if (len > 1e-5f) {
                    nx /= len
                    ny /= len
                    nz /= len
                } else {
                    nx = 0f
                    ny = 1f
                    nz = 0f
                }

                verts[vPtr++] = p0[0]
                verts[vPtr++] = p0[1]
                verts[vPtr++] = p0[2]
                verts[vPtr++] = nx
                verts[vPtr++] = ny
                verts[vPtr++] = nz
                verts[vPtr++] = u
                verts[vPtr++] = v
            }
        }

        val indices = ShortArray(latBands * lonBands * 6)
        var iPtr = 0
        for (lat in 0 until latBands) {
            for (lon in 0 until lonBands) {
                val first = (lat * (lonBands + 1)) + lon
                val second = first + lonBands + 1
                indices[iPtr++] = first.toShort()
                indices[iPtr++] = second.toShort()
                indices[iPtr++] = (first + 1).toShort()
                indices[iPtr++] = second.toShort()
                indices[iPtr++] = (second + 1).toShort()
                indices[iPtr++] = (first + 1).toShort()
            }
        }
        return uploadIndexedMesh(verts, indices)
    }

    /**
     * 1. Faceted Craggy Cliff & Boulder Mesh:
     * Flat base anchored at y=0, angular stepped cliff strata, and faceted rock ridges.
     */
    private fun buildFacetedRockMesh(latBands: Int, lonBands: Int): GlMesh {
        return buildParametricSurface(latBands, lonBands) { u, v, out ->
            val theta = v * PI.toFloat()
            val phi = u * 2.0f * PI.toFloat()
            val sinT = sin(theta)
            val cosT = cos(theta)

            // Angular rock faceting + geological horizontal strata
            val facet = 0.84f + 0.16f * cos(phi * 5.0f + sin(theta * 4.0f) * 1.4f)
            val strata = 0.92f + 0.08f * cos(theta * 9.0f)
            val taperBottom = if (cosT < -0.65f) 1.12f else 1.0f
            val r = 0.5f * facet * strata * taperBottom

            out[0] = cos(phi) * sinT * r
            // Anchor bottom at y = 0.0 and top at y = 1.0 so rocks never float!
            out[1] = (cosT * 0.5f + 0.5f)
            out[2] = sin(phi) * sinT * r
        }
    }

    /**
     * 2. Gnarled Tree Trunk with Flared Root Buttresses (anchored at y=0..1).
     */
    private fun buildTaperedTrunkMesh(latBands: Int, lonBands: Int): GlMesh {
        return buildParametricSurface(latBands, lonBands) { u, v, out ->
            val phi = u * 2.0f * PI.toFloat()
            val y = 1.0f - v // y from 1.0 (top) down to 0.0 (roots)
            val rootFlare = max(0.0f, 1.0f - y * 2.8f)
            val rootButtress = rootFlare * rootFlare * (0.45f + 0.35f * cos(phi * 5.0f))
            val barkTwist = 0.06f * sin(phi * 6.0f + y * 5.0f)
            val radius = (0.34f * (1.0f - y * 0.38f) + rootButtress + barkTwist)
            val bendX = sin(y * PI.toFloat()) * 0.06f
            out[0] = cos(phi) * radius + bendX
            out[1] = y
            out[2] = sin(phi) * radius
        }
    }

    /**
     * 3. Multi-Lobed Foliage Canopy Mesh for Ancient Forest Trees.
     */
    private fun buildFoliageCanopyMesh(latBands: Int, lonBands: Int): GlMesh {
        return buildParametricSurface(latBands, lonBands) { u, v, out ->
            val theta = v * PI.toFloat()
            val phi = u * 2.0f * PI.toFloat()
            val sinT = sin(theta)
            val cosT = cos(theta)
            val lobes = 0.82f + 0.18f * sin(phi * 6.0f) * sin(theta * 4.0f) + 0.10f * cos(phi * 3.0f - theta * 5.0f)
            out[0] = cos(phi) * sinT * 0.52f * lobes
            out[1] = cosT * 0.44f * lobes
            out[2] = sin(phi) * sinT * 0.52f * lobes
        }
    }

    /**
     * 4. Pointed Hexagonal Bioluminescent Crystal Spire (anchored at y=0..1).
     */
    private fun buildHexCrystalMesh(): GlMesh {
        return buildParametricSurface(6, 6) { u, v, out ->
            val phi = u * 2.0f * PI.toFloat()
            val y = 1.0f - v
            val tipTaper = if (y > 0.72f) (1.0f - y) / 0.28f else 1.0f
            val r = 0.42f * tipTaper
            out[0] = cos(phi) * r
            out[1] = y
            out[2] = sin(phi) * r
        }
    }

    /**
     * 5. Vaulted Moonlit Cave Entrance Archway Mesh (true hollow stone arch anchored at y=0).
     */
    private fun buildCaveArchMesh(archSegs: Int, tubeSegs: Int): GlMesh {
        return buildParametricSurface(archSegs, tubeSegs) { u, v, out ->
            val archAngle = v * PI.toFloat() // 0 to PI across the arch
            val tubeAngle = u * 2.0f * PI.toFloat()
            val majorRx = 3.8f
            val majorRy = 3.4f
            val crag = 0.85f + 0.18f * cos(tubeAngle * 4.0f + archAngle * 5.0f)
            val minorR = (1.15f + 0.35f * sin(archAngle)) * crag

            val cx = cos(archAngle) * majorRx
            val cy = sin(archAngle) * majorRy
            val radX = cos(archAngle)
            val radY = sin(archAngle)

            out[0] = cx + radX * cos(tubeAngle) * minorR
            out[1] = max(0.0f, cy + radY * cos(tubeAngle) * minorR)
            out[2] = sin(tubeAngle) * minorR * 1.45f
        }
    }

    /**
     * 6. Sculpted Medieval Cuirass / Torso Armor Mesh with V-taper waist & chest ridge.
     */
    private fun buildAnatomicalCuirassMesh(latBands: Int, lonBands: Int): GlMesh {
        return buildParametricSurface(latBands, lonBands) { u, v, out ->
            val theta = v * PI.toFloat()
            val phi = u * 2.0f * PI.toFloat()
            val sinT = sin(theta)
            val cosT = cos(theta)
            // V-taper: broader across upper chest, narrower at waist, slight flare at tassets
            val hNorm = cosT * 0.5f + 0.5f
            val widthCurve = 0.76f + 0.34f * hNorm + (if (hNorm < 0.22f) 0.14f else 0.0f)
            val chestKeel = if (sin(phi) > 0.0f) (1.0f + 0.18f * pow3(sin(phi)) * sinT) else 0.92f
            out[0] = cos(phi) * sinT * 0.50f * widthCurve
            out[1] = cosT * 0.50f
            out[2] = sin(phi) * sinT * 0.42f * chestKeel
        }
    }

    /**
     * 7. Sculpted Medieval Knight/Adventurer Sallet & Visored Helm Mesh.
     */
    private fun buildKnightHelmMesh(latBands: Int, lonBands: Int): GlMesh {
        return buildParametricSurface(latBands, lonBands) { u, v, out ->
            val theta = v * PI.toFloat()
            val phi = u * 2.0f * PI.toFloat()
            val sinT = sin(theta)
            val cosT = cos(theta)
            val visorRidge = if (sin(phi) > 0.2f && abs(cosT) < 0.38f) 1.18f else 1.0f
            val neckFlare = if (cosT < -0.55f) 1.16f else 1.0f
            val crest = if (abs(cos(phi)) < 0.18f && cosT > 0.2f) 1.10f else 1.0f
            out[0] = cos(phi) * sinT * 0.48f * neckFlare
            out[1] = cosT * 0.52f * crest
            out[2] = sin(phi) * sinT * 0.52f * visorRidge * neckFlare
        }
    }

    /**
     * 8. Tapered Anatomical Limb / Gauntlet / Greave Mesh.
     */
    private fun buildTaperedLimbMesh(latBands: Int, lonBands: Int): GlMesh {
        return buildParametricSurface(latBands, lonBands) { u, v, out ->
            val theta = v * PI.toFloat()
            val phi = u * 2.0f * PI.toFloat()
            val sinT = sin(theta)
            val cosT = cos(theta)
            val cuff = 0.85f + 0.15f * cos(theta * 3.0f)
            out[0] = cos(phi) * sinT * 0.48f * cuff
            out[1] = cosT * 0.50f
            out[2] = sin(phi) * sinT * 0.48f * cuff
        }
    }

    /**
     * 9. Crossguard Greatsword Mesh (Pommel + Grip + Wide Crossguard + Tapered Diamond Blade).
     */
    private fun buildGreatswordMesh(): GlMesh {
        return buildParametricSurface(16, 8) { u, v, out ->
            val phi = u * 2.0f * PI.toFloat()
            val z = (v - 0.18f) * 1.25f // Blade extends forward along +Z, hilt behind 0
            val isCrossguard = (v in 0.16f..0.23f)
            val isGrip = (v < 0.16f)
            val tipTaper = if (v > 0.78f) max(0.04f, (1.0f - v) / 0.22f) else 1.0f

            val widthX = when {
                isCrossguard -> 2.35f
                isGrip -> 0.36f
                else -> 0.58f * tipTaper
            }
            val thickY = when {
                isCrossguard -> 0.48f
                isGrip -> 0.36f
                else -> 0.22f * tipTaper
            }
            out[0] = cos(phi) * widthX * 0.5f
            out[1] = sin(phi) * thickY * 0.5f
            out[2] = z
        }
    }

    /**
     * 10. Flowing Draped Traveler Cloak Mesh with Pleated Hem.
     */
    private fun buildTravelerCloakMesh(latBands: Int, lonBands: Int): GlMesh {
        return buildParametricSurface(latBands, lonBands) { u, v, out ->
            val theta = v * PI.toFloat()
            val phi = u * 2.0f * PI.toFloat()
            val sinT = sin(theta)
            val cosT = cos(theta)
            val hNorm = 0.5f - cosT * 0.5f // 0 at shoulders, 1 at bottom hem
            val flare = 0.72f + hNorm * 0.52f
            val pleats = 1.0f + 0.12f * sin(phi * 7.0f) * hNorm
            out[0] = cos(phi) * sinT * 0.52f * flare * pleats
            out[1] = cosT * 0.52f
            out[2] = sin(phi) * sinT * 0.28f * pleats - hNorm * 0.14f
        }
    }

    /**
     * 11. Single Continuous 3D Chainmail Coif, Collar & Mantle Bust Mesh (`1000461485.jpg`).
     */
    private fun buildChainmailBustMesh(latBands: Int, lonBands: Int): GlMesh {
        return buildParametricSurface(latBands, lonBands) { u, v, out ->
            val phi = u * 2.0f * PI.toFloat()
            val y = 0.95f - v * 1.95f // +0.95 (crown) down to -1.00 (mantle hem)
            val profileR = when {
                y > 0.25f -> {
                    // Cranium dome
                    val t = ((y - 0.25f) / 0.70f).coerceIn(0f, 1f)
                    sqrt(max(0.01f, 1.0f - t * t)) * 0.68f
                }
                y > -0.15f -> {
                    // Jaw & reinforced mail neck guard
                    val t = (y - (-0.15f)) / 0.40f
                    0.58f + (1.0f - t) * 0.16f
                }
                else -> {
                    // Flared chainmail mantle across shoulders & upper chest
                    val t = ((-0.15f - y) / 0.85f).coerceIn(0f, 1f)
                    0.74f + t * 0.92f
                }
            }
            val shoulderAspectX = if (y < -0.15f) 1.24f else 0.96f
            val shoulderAspectZ = if (y < -0.15f) 0.88f else 1.02f
            out[0] = cos(phi) * profileR * shoulderAspectX
            out[1] = y
            out[2] = sin(phi) * profileR * shoulderAspectZ
        }
    }

    /**
     * 12. Subdivided 3D Terrain & Water Grid VAO (-1..+1 on X and Z, displaced in vertex shader).
     */
    private fun buildSubdividedGridMesh(gridX: Int, gridZ: Int): GlMesh {
        val vertCount = (gridX + 1) * (gridZ + 1)
        val verts = FloatArray(vertCount * 8)
        var vPtr = 0
        for (iz in 0..gridZ) {
            val v = iz / gridZ.toFloat()
            val z = (v - 0.5f) * 2.0f
            for (ix in 0..gridX) {
                val u = ix / gridX.toFloat()
                val x = (u - 0.5f) * 2.0f
                verts[vPtr++] = x
                verts[vPtr++] = 0.0f
                verts[vPtr++] = z
                verts[vPtr++] = 0.0f
                verts[vPtr++] = 1.0f
                verts[vPtr++] = 0.0f
                verts[vPtr++] = u
                verts[vPtr++] = v
            }
        }

        val indices = ShortArray(gridX * gridZ * 6)
        var iPtr = 0
        for (iz in 0 until gridZ) {
            for (ix in 0 until gridX) {
                val row1 = iz * (gridX + 1) + ix
                val row2 = row1 + gridX + 1
                indices[iPtr++] = row1.toShort()
                indices[iPtr++] = row2.toShort()
                indices[iPtr++] = (row1 + 1).toShort()
                indices[iPtr++] = row2.toShort()
                indices[iPtr++] = (row2 + 1).toShort()
                indices[iPtr++] = (row1 + 1).toShort()
            }
        }
        return uploadIndexedMesh(verts, indices)
    }

    /**
     * 13. Hardware VAO for 36,000 GPU-Instanced 3D ASCII Grass Blades & Wildflowers.
     */
    private fun buildInstancedGrassVao() {
        val ribbon = floatArrayOf(
            -0.5f, 0.0f, 0.0f, 1.0f,
             0.5f, 0.0f, 1.0f, 1.0f,
            -0.5f, 1.0f, 0.0f, 0.0f,
             0.5f, 0.0f, 1.0f, 1.0f,
             0.5f, 1.0f, 1.0f, 0.0f,
            -0.5f, 1.0f, 0.0f, 0.0f
        )
        val rb = ByteBuffer.allocateDirect(ribbon.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
        rb.put(ribbon).position(0)

        val inst = FloatArray(MAX_GRASS_INSTANCES * 4)
        var seed = 0x5F3759DF
        for (i in 0 until MAX_GRASS_INSTANCES) {
            seed = seed * 1664525 + 1013904223
            val rx = (((seed ushr 15) and 0xFFFF) / 65535.0f - 0.5f) * 34.0f
            seed = seed * 1664525 + 1013904223
            val rz = (((seed ushr 15) and 0xFFFF) / 65535.0f - 0.5f) * 34.0f
            seed = seed * 1664525 + 1013904223
            val isFlower = (i % 22 == 0)
            val hScale = if (isFlower) 0.27f else (0.31f + ((seed ushr 12) and 15) * 0.018f)
            val typeSeed = if (isFlower) (100.0f + (i % 6)) else (i % 16).toFloat()

            val o = i * 4
            inst[o] = rx
            inst[o + 1] = rz
            inst[o + 2] = hScale
            inst[o + 3] = typeSeed
        }
        val ib = ByteBuffer.allocateDirect(inst.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
        ib.put(inst).position(0)

        val vaoArr = IntArray(1)
        val vbos = IntArray(2)
        GLES30.glGenVertexArrays(1, vaoArr, 0)
        GLES30.glGenBuffers(2, vbos, 0)

        grassVao = vaoArr[0]
        grassRibbonVbo = vbos[0]
        grassInstanceVbo = vbos[1]

        GLES30.glBindVertexArray(grassVao)

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, grassRibbonVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, ribbon.size * 4, rb, GLES30.GL_STATIC_DRAW)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 4, GLES30.GL_FLOAT, false, 16, 0)
        GLES30.glVertexAttribDivisor(0, 0)

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, grassInstanceVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, inst.size * 4, ib, GLES30.GL_STATIC_DRAW)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 4, GLES30.GL_FLOAT, false, 16, 0)
        GLES30.glVertexAttribDivisor(1, 1)

        GLES30.glBindVertexArray(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
    }

    private fun pow3(x: Float): Float = x * x * x

    companion object {
        const val MAX_GRASS_INSTANCES = 36000
    }
}
