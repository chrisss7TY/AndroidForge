package com.ashveil.abyss

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * High-Performance OpenGL ES 3.0 3D ASCII Rendering Engine for ASHVEIL (v7.0.0).
 *
 * Architecture & Performance Highlights:
 * - Zero per-frame `glGetUniformLocation` lookups (all uniform locations cached on link).
 * - Hardware VAOs (`MeshLibrary`) for single-call mesh binding: faceted craggy cliffs,
 *   gnarled tree trunks & multi-lobed canopies, vaulted Moonlit Cave archways, hexagonal
 *   bioluminescent crystals, anatomical cuirass/helm/limb/cloak/greatsword meshes, and
 *   continuous 3D Chainmail Coif bust (`1000461485.jpg`).
 * - True 3D Heightfield Terrain Mesh (`44x44` grid) & 36,000 GPU-instanced 3D grass/wildflower
 *   blades sharing an identical analytical FBM height function in GLSL `#version 300 es` so
 *   every blade and prop sits flush on 3D hills and valleys across any random world seed.
 * - 512x512 Planar Water Reflection FBO with wave-distorted ASCII reflections (`1000461484.jpg`).
 */
class AsciiGlRenderer(private val state: GameState) : GLSurfaceView.Renderer {

    private var lastNs: Long = System.nanoTime()
    private var width: Int = 1280
    private var height: Int = 720

    private val meshes = MeshLibrary()

    // Shader Programs
    private var progMeshAscii: Int = 0
    private var progTerrainAscii: Int = 0
    private var progGrassInstanced: Int = 0
    private var progWaterAscii: Int = 0

    // Cached Uniform Locations for progMeshAscii
    private var uMeshMvp: Int = -1
    private var uMeshModel: Int = -1
    private var uMeshAtlas: Int = -1
    private var uMeshBaseColor: Int = -1
    private var uMeshCamPos: Int = -1
    private var uMeshCellScale: Int = -1
    private var uMeshMaterialMode: Int = -1
    private var uMeshDebugSolid: Int = -1
    private var uMeshTime: Int = -1

    // Cached Uniform Locations for progTerrainAscii
    private var uTerrVp: Int = -1
    private var uTerrCenter: Int = -1
    private var uTerrScale: Int = -1
    private var uTerrSeedParams: Int = -1
    private var uTerrCaveCenter: Int = -1
    private var uTerrGenRivers: Int = -1
    private var uTerrAtlas: Int = -1
    private var uTerrCamPos: Int = -1
    private var uTerrTime: Int = -1
    private var uTerrDebugSolid: Int = -1

    // Cached Uniform Locations for progGrassInstanced
    private var uGrassVp: Int = -1
    private var uGrassPlayerPos: Int = -1
    private var uGrassCamRight: Int = -1
    private var uGrassTime: Int = -1
    private var uGrassSeedParams: Int = -1
    private var uGrassCaveCenter: Int = -1
    private var uGrassRiverHalfW: Int = -1
    private var uGrassAtlas: Int = -1

    // Cached Uniform Locations for progWaterAscii
    private var uWaterMvp: Int = -1
    private var uWaterModel: Int = -1
    private var uWaterAtlas: Int = -1
    private var uWaterReflectTex: Int = -1
    private var uWaterTime: Int = -1

    // 16x6 High-Resolution Monospace Glyph Atlas Texture
    private var glyphAtlasTex: Int = 0

    // Planar Water Reflection Framebuffer Object (FBO)
    private var reflectFbo: Int = 0
    private var reflectTex: Int = 0
    private var reflectDepthRb: Int = 0

    // Pre-allocated Transformation Matrices (Zero GC allocations in render loop)
    private val projMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val vpMatrix = FloatArray(16)
    private val reflectViewMatrix = FloatArray(16)
    private val reflectVpMatrix = FloatArray(16)
    private val modelMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0.018f, 0.028f, 0.025f, 1.0f)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glDepthFunc(GLES30.GL_LEQUAL)
        GLES30.glDisable(GLES30.GL_CULL_FACE)

        glyphAtlasTex = createAsciiGlyphAtlasTexture()
        meshes.initAllMeshes()
        initReflectionFbo()
        compileAllShaders()
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        width = max(1, w)
        height = max(1, h)
        GLES30.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        val nowNs = System.nanoTime()
        var dt = (nowNs - lastNs) / 1_000_000_000.0f
        lastNs = nowNs
        if (dt > 0.05f) dt = 0.05f
        if (dt < 0.001f) dt = 0.001f

        state.stepSimulation(dt)

        if (state.screenMode == 2) {
            render3DChainmailEquipmentScene()
        } else {
            render3DOpenWorldScene()
        }
    }

    private fun createAsciiGlyphAtlasTexture(): Int {
        val cols = 16
        val rows = 6
        val cellW = 48
        val cellH = 48
        val bmp = Bitmap.createBitmap(cols * cellW, rows * cellH, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.TRANSPARENT)

        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textSize = 37.0f
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
        }

        // 6 specialized rows of 16 ASCII characters:
        // Row 0..1: 32-step luminance ramp for 3D rocks, cliffs, trees & armor (`1000461471.jpg`)
        // Row 2: Chainmail coif concentric rings (`1000461485.jpg`)
        // Row 3: Individual 3D grass blades (`|/\,;`) & wildflowers (`*o+.`)
        // Row 4: Forest soil moss & normal-mapped cave stone glyphs (`1000461483.jpg`)
        // Row 5: Water ripples & Astral Vortex skill circle glyphs (`1000461484.jpg` & `1000461463.jpg`)
        val atlasChars =
            " .,:;~-=+*oahkbd" +
            "pqwmZOQ0N\$%&8B#W" +
            "@S8\$#c()350Qo*+=" +
            "|/\\,;'*o+.^v~:;#" +
            "0Q8B@WM#%&80aaqQ" +
            "-~=:.o0*+@\u00a7^v<>#"

        val fm = p.fontMetrics
        val baselineOff = -(fm.ascent + fm.descent) * 0.5f

        for (r in 0 until rows) {
            for (col in 0 until cols) {
                val idx = r * cols + col
                val ch = if (idx < atlasChars.length) atlasChars[idx] else '@'
                val cx = col * cellW + cellW * 0.5f
                val cy = r * cellH + cellH * 0.5f + baselineOff
                c.drawText(ch.toString(), cx, cy, p)
            }
        }

        val tex = IntArray(1)
        GLES30.glGenTextures(1, tex, 0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex[0])
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0)
        bmp.recycle()
        return tex[0]
    }

    private fun initReflectionFbo() {
        val fbo = IntArray(1)
        val tex = IntArray(1)
        val rb = IntArray(1)
        GLES30.glGenFramebuffers(1, fbo, 0)
        GLES30.glGenTextures(1, tex, 0)
        GLES30.glGenRenderbuffers(1, rb, 0)

        reflectFbo = fbo[0]
        reflectTex = tex[0]
        reflectDepthRb = rb[0]

        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, reflectTex)
        GLES30.glTexImage2D(
            GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, REFLECT_W, REFLECT_H, 0,
            GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null
        )
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)

        GLES30.glBindRenderbuffer(GLES30.GL_RENDERBUFFER, reflectDepthRb)
        GLES30.glRenderbufferStorage(GLES30.GL_RENDERBUFFER, GLES30.GL_DEPTH_COMPONENT16, REFLECT_W, REFLECT_H)

        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, reflectFbo)
        GLES30.glFramebufferTexture2D(
            GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, reflectTex, 0
        )
        GLES30.glFramebufferRenderbuffer(
            GLES30.GL_FRAMEBUFFER, GLES30.GL_DEPTH_ATTACHMENT, GLES30.GL_RENDERBUFFER, reflectDepthRb
        )
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
    }

    private fun compileAllShaders() {
        // Shared GLSL terrain height function snippet (matches WorldGenerator.getTerrainHeight!)
        val glslTerrainFunc = """
            float evalRiverZ(float wx, vec4 sp, float amp) {
                float rPhase = sp.z;
                float baseOff = -6.8 + sin(rPhase) * 2.2;
                return baseOff + sin(wx * 0.12 + rPhase) * amp + cos(wx * 0.055 - rPhase * 0.6) * 1.45;
            }
            float evalTerrainHeight(vec2 xz, vec4 sp, float genRivers, float rAmp) {
                float riverMask = 1.0;
                if (genRivers > 0.5) {
                    float dRiv = abs(xz.y - evalRiverZ(xz.x, sp, rAmp));
                    riverMask = clamp((dRiv - 3.6) / 5.5, 0.0, 1.0);
                    riverMask = riverMask * riverMask * (3.0 - 2.0 * riverMask);
                }
                float dSpawn = length(xz - vec2(0.0, 4.0));
                float spawnMask = clamp((dSpawn - 4.5) / 7.5, 0.0, 1.0);
                spawnMask = spawnMask * spawnMask * (3.0 - 2.0 * spawnMask);

                float n1 = sin(xz.x * 0.075 + sp.x) * cos(xz.y * 0.075 + sp.y);
                float n2 = sin((xz.x * 0.16 - xz.y * 0.11) + sp.x * 1.7) * 0.5;
                float n3 = cos((xz.x * 0.042 + xz.y * 0.058) - sp.y * 1.3) * 0.75;
                float rawH = max(0.0, (n1 + n2 + n3 + 0.65) * 0.52);
                return rawH * sp.w * riverMask * spawnMask;
            }
        """.trimIndent()

        // 1. 3D Mesh Surface-Contour ASCII Shader
        val vsMesh = """
            #version 300 es
            layout(location = 0) in vec3 aPos;
            layout(location = 1) in vec3 aNormal;
            layout(location = 2) in vec2 aUv;
            uniform mat4 uMVP;
            uniform mat4 uModel;
            out vec3 vWorldPos;
            out vec3 vNormal;
            out vec2 vUv;
            void main() {
                vec4 wp = uModel * vec4(aPos, 1.0);
                vWorldPos = wp.xyz;
                mat3 normalMat = transpose(inverse(mat3(uModel)));
                vNormal = normalize(normalMat * aNormal);
                vUv = aUv;
                gl_Position = uMVP * vec4(aPos, 1.0);
            }
        """.trimIndent()

        val fsMesh = """
            #version 300 es
            precision mediump float;
            in vec3 vWorldPos;
            in vec3 vNormal;
            in vec2 vUv;
            uniform sampler2D uAtlas;
            uniform vec3 uBaseColor;
            uniform vec3 uCamPos;
            uniform float uCellScale;
            uniform int uMaterialMode;
            uniform int uDebugSolid;
            uniform float uTime;
            out vec4 fragColor;

            float hash12(vec2 p) {
                return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
            }

            void main() {
                vec3 bump = vec3(
                    sin(vWorldPos.x * 4.5 + vWorldPos.z * 2.2) * cos(vWorldPos.y * 3.8),
                    cos(vWorldPos.x * 3.2 - vWorldPos.z * 4.1),
                    sin(vWorldPos.z * 4.8 - vWorldPos.x * 2.5)
                ) * (uMaterialMode == 0 ? 0.22 : 0.06);

                vec3 N = normalize(vNormal + bump);
                vec3 L = normalize(vec3(-0.52, 0.80, 0.34));
                vec3 V = normalize(uCamPos - vWorldPos);
                vec3 H = normalize(L + V);
                float diff = max(0.06, dot(N, L));
                float spec = pow(max(0.0, dot(N, H)), 18.0);
                float rim = pow(1.0 - max(0.0, dot(N, V)), 2.3);

                if (uDebugSolid == 1) {
                    vec3 solidCol = uBaseColor * (0.25 + 0.75 * diff) + vec3(spec * 0.35 + rim * 0.2);
                    fragColor = vec4(solidCol, 1.0);
                    return;
                }

                // Mode 5: Glowing 3D Astral Vortex Rune Ring (`1000461463.jpg` "New skills")
                if (uMaterialMode == 5) {
                    vec2 uvCentered = (vUv - vec2(0.5)) * 2.0;
                    float r = length(uvCentered);
                    if (r > 0.98 || r < 0.42) discard;
                    float ringBand = smoothstep(0.42, 0.56, r) * (1.0 - smoothstep(0.84, 0.98, r));
                    float ang = atan(uvCentered.y, uvCentered.x) + uTime * 1.8;
                    float seg = floor(mod(ang * 4.5, 16.0));
                    vec2 gUv = fract(vec2(ang * 3.8, (r - 0.42) * 3.2));
                    vec2 aUv = (vec2(seg, 5.0) + gUv) / vec2(16.0, 6.0);
                    float m = texture(uAtlas, aUv).a;
                    float spark = pow(max(0.0, cos(ang - uTime * 3.2)), 8.0);
                    vec3 glowCol = mix(vec3(0.68, 0.56, 0.95), vec3(1.0, 0.96, 0.82), spark + m * 0.5);
                    if (m * ringBand < 0.12 && spark < 0.4) discard;
                    fragColor = vec4(glowCol * (0.55 + 0.75 * m + spark * 0.8), 1.0);
                    return;
                }

                vec2 cellDim = vec2(max(6.0, uCellScale), max(8.0, uCellScale * 1.32));
                vec2 scGrid = gl_FragCoord.xy / cellDim;
                vec2 cellId = floor(scGrid);
                vec2 cellUv = fract(scGrid);
                cellUv.y = 1.0 - cellUv.y;

                // Mode 3 & 4: 3D Adventurer Armor & Flowing Crimson Traveler Cloak (`1000461482.jpg`)
                if (uMaterialMode == 3 || uMaterialMode == 4) {
                    float lum = clamp(diff * 0.52 + spec * 0.96 + rim * 0.58, 0.04, 0.99);
                    float idx = (spec > 0.32 || rim > 0.54) ? (22.0 + floor(lum * 9.0))
                              : (diff > 0.35 ? (8.0 + floor(lum * 13.0)) : (2.0 + floor(lum * 6.0)));
                    vec2 atlasUv = (vec2(mod(idx, 16.0), floor(idx / 16.0)) + cellUv) / vec2(16.0, 6.0);
                    float mask = texture(uAtlas, atlasUv).a;
                    vec3 obsidianBack = vec3(0.012, 0.016, 0.020);
                    vec3 glyphRgb;
                    if (uMaterialMode == 4) {
                        glyphRgb = (rim > 0.60) ? vec3(0.95, 0.58, 0.58) : (uBaseColor * (0.38 + 0.82 * lum));
                    } else {
                        glyphRgb = (spec > 0.32 || rim > 0.54) ? vec3(0.96, 0.98, 1.0) : (uBaseColor * (0.34 + 0.78 * lum));
                    }
                    fragColor = vec4(mix(obsidianBack, glyphRgb, mask), 1.0);
                    return;
                }

                // Mode 1: 3D Chainmail Coif Concentric Ring ASCII Shader (`1000461485.jpg`)
                if (uMaterialMode == 1) {
                    float lum = clamp(diff * 0.82 + spec * 0.45 + rim * 0.38, 0.05, 0.99);
                    float ringRow = floor(vUv.y * 28.0);
                    float ringCol = floor(vUv.x * 40.0 + mod(ringRow, 2.0) * 0.5);
                    float h = hash12(vec2(ringCol, ringRow) + cellId * 0.15);
                    float glyphCol = floor(clamp(lum * 11.0 + h * 5.0, 1.0, 15.0));
                    vec2 atlasUv = (vec2(glyphCol, 2.0) + cellUv) / vec2(16.0, 6.0);
                    float mask = texture(uAtlas, atlasUv).a;
                    vec3 litGlyph = uBaseColor * (0.22 + 0.92 * lum);
                    fragColor = vec4(mix(vec3(0.01, 0.012, 0.015), litGlyph, mask), 1.0);
                    return;
                }

                // Mode 0: Dark-Backed 3D ASCII Faceted Cliffs, Boulders, Cave Arches & Trees
                float lum = clamp(diff * 0.78 + rim * 0.48 + spec * 0.26, 0.05, 0.99);
                float h = hash12(cellId);
                float idx = clamp(floor((lum * 0.80 + h * 0.20) * 31.0), 2.0, 31.0);
                float glyphCol = mod(idx, 16.0);
                float glyphRow = floor(idx / 16.0);

                vec2 atlasUv = (vec2(glyphCol, glyphRow) + cellUv) / vec2(16.0, 6.0);
                float mask = texture(uAtlas, atlasUv).a;
                vec3 darkBack = vec3(0.014, 0.019, 0.025);
                vec3 litGlyph = uBaseColor * (0.26 + 0.86 * lum);
                vec3 col = mix(darkBack, litGlyph, mask);

                float dist = length(vWorldPos.xz - uCamPos.xz);
                float mistWave = sin(vWorldPos.x * 0.35 + vWorldPos.z * 0.28 - uTime * 0.55)
                               * cos(vWorldPos.x * 0.22 - vWorldPos.z * 0.41 + uTime * 0.38);
                float lowMist = clamp((1.7 - vWorldPos.y) * 0.45, 0.0, 1.0) * smoothstep(0.15, 0.75, mistWave * 0.5 + 0.5) * 0.28;
                float fog = clamp((dist - 15.0) / 24.0, 0.0, 0.50) + lowMist;
                fragColor = vec4(mix(col, vec3(0.52, 0.60, 0.63), clamp(fog, 0.0, 0.62)), 1.0);
            }
        """.trimIndent()

        // 2. True 3D Heightfield Terrain Mesh Shader
        val vsTerrain = """
            #version 300 es
            layout(location = 0) in vec3 aPos;
            uniform mat4 uVP;
            uniform vec2 uCenterXZ;
            uniform float uGridScale;
            uniform vec4 uSeedParams;
            uniform float uGenRivers;
            out vec3 vWorldPos;
            out vec3 vNormal;
            $glslTerrainFunc
            void main() {
                vec2 xz = uCenterXZ + aPos.xz * uGridScale;
                float rAmp = (uSeedParams.w < 0.6) ? 3.6 : 2.35;
                float h0 = evalTerrainHeight(xz, uSeedParams, uGenRivers, rAmp);
                float hx = evalTerrainHeight(xz + vec2(0.4, 0.0), uSeedParams, uGenRivers, rAmp);
                float hz = evalTerrainHeight(xz + vec2(0.0, 0.4), uSeedParams, uGenRivers, rAmp);
                vNormal = normalize(vec3(h0 - hx, 0.4, h0 - hz));
                vWorldPos = vec3(xz.x, h0 - 0.02, xz.y);
                gl_Position = uVP * vec4(vWorldPos, 1.0);
            }
        """.trimIndent()

        val fsTerrain = """
            #version 300 es
            precision mediump float;
            in vec3 vWorldPos;
            in vec3 vNormal;
            uniform sampler2D uAtlas;
            uniform vec3 uCamPos;
            uniform vec2 uCaveCenter;
            uniform float uTime;
            uniform int uDebugSolid;
            out vec4 fragColor;

            float hash12(vec2 p) {
                return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
            }

            void main() {
                vec3 L = normalize(vec3(-0.52, 0.80, 0.34));
                float diff = max(0.18, dot(normalize(vNormal), L));
                if (uDebugSolid == 1) {
                    fragColor = vec4(vec3(0.12, 0.24, 0.16) * diff, 1.0);
                    return;
                }

                bool inCave = (length(vWorldPos.xz - uCaveCenter) < 9.5);
                vec2 gCoord = vWorldPos.xz * (inCave ? 3.2 : 2.3);
                vec2 cId = floor(gCoord);
                vec2 cUv = fract(gCoord);
                float h = hash12(cId);
                vec3 soil = inCave ? vec3(0.014, 0.018, 0.026) : (vec3(0.018, 0.032, 0.026) * (0.65 + 0.55 * diff));
                float ridge = max(0.0, sin(vWorldPos.x * 1.3 + sin(vWorldPos.z * 0.9) * 2.0) * cos(vWorldPos.z * 1.1));

                if (!inCave && h < 0.50 && vWorldPos.y < 0.35) {
                    fragColor = vec4(soil, 1.0);
                    return;
                }
                float gCol = floor(clamp(h * 10.0 + ridge * 6.0, 0.0, 15.0));
                vec2 aUv = (vec2(gCol, 4.0) + cUv) / vec2(16.0, 6.0);
                float m = texture(uAtlas, aUv).a;
                vec3 glyphTone = inCave
                    ? mix(vec3(0.18, 0.24, 0.34), vec3(0.68, 0.78, 0.90), pow(ridge, 2.0))
                    : (vec3(0.16, 0.26, 0.28) * diff);
                vec3 col = mix(soil, glyphTone, m * (inCave ? (0.38 + 0.62 * ridge) : 0.58));

                float dist = length(vWorldPos.xz - uCamPos.xz);
                float fog = clamp((dist - 16.0) / 22.0, 0.0, 0.48);
                fragColor = vec4(mix(col, vec3(0.48, 0.56, 0.60), fog), 1.0);
            }
        """.trimIndent()

        // 3. GPU-Terrain-Synced Instanced 3D Grass & Wildflower Shader (36,000 instances)
        val vsGrass = """
            #version 300 es
            layout(location = 0) in vec4 aRibbon;
            layout(location = 1) in vec4 aInst;
            uniform mat4 uVP;
            uniform vec3 uPlayerPos;
            uniform vec3 uCamRight;
            uniform float uTime;
            uniform vec4 uSeedParams;
            uniform vec2 uCaveCenter;
            uniform float uRiverHalfW;
            out vec2 vUv;
            out vec3 vColor;
            out vec2 vAtlasCell;
            out float vFog;
            $glslTerrainFunc
            void main() {
                vec2 tile = floor((uPlayerPos.xz - aInst.xy + 17.0) / 34.0) * 34.0 + aInst.xy;
                float rAmp = (uSeedParams.w < 0.6) ? 3.6 : 2.35;
                float genRiv = (uRiverHalfW > 0.01) ? 1.0 : 0.0;
                float riverZ = evalRiverZ(tile.x, uSeedParams, rAmp);
                if (uRiverHalfW > 0.01 && abs(tile.y - riverZ) < uRiverHalfW + 0.18) {
                    gl_Position = vec4(0.0, 0.0, -2.0, 1.0);
                    return;
                }
                // Exclude grass deep inside the seeded dark Moonlit Cave chamber
                vec2 dCave = tile - uCaveCenter;
                if (dot(dCave, dCave) < 6.8 * 6.8) {
                    gl_Position = vec4(0.0, 0.0, -2.0, 1.0);
                    return;
                }

                // Exact 3D terrain elevation at this grass blade's (x, z) coordinate!
                float groundH = evalTerrainHeight(tile, uSeedParams, genRiv, rAmp);

                bool nearCaveMouth = (length(dCave) < 11.5);
                bool isFlower = (aInst.w >= 100.0) || (nearCaveMouth && mod(aInst.w, 4.0) < 1.0);

                float sway = sin(tile.x * 0.55 + tile.y * 0.45 - uTime * 2.4) * 0.11 * aRibbon.y;
                float wScale = isFlower ? 0.18 : 0.115;
                vec3 worldPos = vec3(tile.x, groundH, tile.y)
                              + uCamRight * (aRibbon.x * wScale + sway)
                              + vec3(0.0, aRibbon.y * aInst.z, 0.0);

                // Player & terrain slope shadow modulation
                float dPlayer = length(tile - (uPlayerPos.xz + vec2(0.32, 0.22)));
                float shadow = smoothstep(0.32, 1.30, dPlayer);

                if (isFlower) {
                    float fType = mod(aInst.w, 5.0);
                    vAtlasCell = vec2(6.0 + mod(fType, 4.0), 3.0);
                    vec3 fCol = (fType < 2.0) ? vec3(0.76, 0.60, 0.95)
                              : (fType < 3.5 ? vec3(0.94, 0.96, 0.92) : vec3(0.66, 0.50, 0.88));
                    vColor = fCol * (0.45 + 0.55 * shadow);
                } else {
                    vAtlasCell = vec2(mod(aInst.w, 6.0), 3.0);
                    float shade = fract(aInst.w * 0.173 + sin(tile.x * 0.25 + tile.y * 0.25) * 0.2);
                    vec3 rootCol = vec3(0.03, 0.10, 0.045);
                    vec3 tipCol = mix(vec3(0.13, 0.38, 0.16), vec3(0.38, 0.68, 0.32), shade);
                    vColor = mix(rootCol, tipCol, aRibbon.y) * (0.28 + 0.72 * shadow);
                }

                float m1 = sin(tile.x * 0.32 + tile.y * 0.24 - uTime * 0.62);
                float m2 = cos(tile.x * 0.19 - tile.y * 0.37 + uTime * 0.44);
                float mistRibbon = smoothstep(0.35, 0.88, m1 * m2 + 0.35) * 0.42;
                float distCam = length(tile - uPlayerPos.xz);
                vFog = clamp((distCam - 12.0) / 18.0, 0.0, 0.42) + mistRibbon;
                vUv = aRibbon.zw;
                gl_Position = uVP * vec4(worldPos, 1.0);
            }
        """.trimIndent()

        val fsGrass = """
            #version 300 es
            precision mediump float;
            in vec2 vUv;
            in vec3 vColor;
            in vec2 vAtlasCell;
            in float vFog;
            uniform sampler2D uAtlas;
            out vec4 fragColor;
            void main() {
                vec2 atlasUv = (vAtlasCell + vUv) / vec2(16.0, 6.0);
                float a = texture(uAtlas, atlasUv).a;
                if (a < 0.24) discard;
                vec3 col = mix(vColor, vec3(0.56, 0.64, 0.66), clamp(vFog, 0.0, 0.68));
                fragColor = vec4(col, 1.0);
            }
        """.trimIndent()

        // 4. Normal-Mapped 3D Water & Planar ASCII Reflection Shader
        val vsWater = """
            #version 300 es
            layout(location = 0) in vec3 aPos;
            uniform mat4 uMVP;
            uniform mat4 uModel;
            out vec3 vWorldPos;
            out vec4 vClipPos;
            void main() {
                vec4 wp = uModel * vec4(aPos, 1.0);
                vWorldPos = wp.xyz;
                vClipPos = uMVP * vec4(aPos, 1.0);
                gl_Position = vClipPos;
            }
        """.trimIndent()

        val fsWater = """
            #version 300 es
            precision mediump float;
            in vec3 vWorldPos;
            in vec4 vClipPos;
            uniform sampler2D uAtlas;
            uniform sampler2D uReflectTex;
            uniform float uTime;
            out vec4 fragColor;
            void main() {
                vec2 p = vWorldPos.xz;
                float w1 = sin(p.x * 1.6 + p.y * 1.1 - uTime * 2.5);
                float w2 = cos(p.x * 0.9 - p.y * 1.9 + uTime * 1.9);
                vec3 N = normalize(vec3(w1 * 0.26, 1.0, w2 * 0.26));
                vec3 L = normalize(vec3(-0.45, 0.65, 0.60));
                float spec = pow(max(0.0, dot(N, L)), 14.0);

                vec2 ndc = (vClipPos.xy / max(0.001, vClipPos.w)) * 0.5 + 0.5;
                vec2 reflUv = clamp(vec2(ndc.x, 1.0 - ndc.y) + N.xz * 0.032, 0.01, 0.99);
                vec3 reflCol = texture(uReflectTex, reflUv).rgb;

                vec2 cellUv = fract(vec2(p.x * 4.2, p.y * 5.6));
                float glyphIdx = floor(clamp((spec * 1.4 + length(reflCol) * 0.55), 0.0, 0.99) * 15.0);
                vec2 atlasUv = (vec2(glyphIdx, 5.0) + cellUv) / vec2(16.0, 6.0);
                float gMask = texture(uAtlas, atlasUv).a;

                vec3 deepWater = vec3(0.018, 0.028, 0.048);
                vec3 streakCol = vec3(0.76, 0.85, 0.95) * gMask * smoothstep(0.32, 0.86, spec + w1 * 0.24);
                vec3 asciiRefl = reflCol * (0.35 + 0.65 * gMask);
                vec3 col = deepWater + asciiRefl * 0.85 + streakCol;
                fragColor = vec4(col, 1.0);
            }
        """.trimIndent()

        progMeshAscii = linkProgram(vsMesh, fsMesh)
        progTerrainAscii = linkProgram(vsTerrain, fsTerrain)
        progGrassInstanced = linkProgram(vsGrass, fsGrass)
        progWaterAscii = linkProgram(vsWater, fsWater)

        // Cache all uniform locations once at shader link time
        uMeshMvp = GLES30.glGetUniformLocation(progMeshAscii, "uMVP")
        uMeshModel = GLES30.glGetUniformLocation(progMeshAscii, "uModel")
        uMeshAtlas = GLES30.glGetUniformLocation(progMeshAscii, "uAtlas")
        uMeshBaseColor = GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor")
        uMeshCamPos = GLES30.glGetUniformLocation(progMeshAscii, "uCamPos")
        uMeshCellScale = GLES30.glGetUniformLocation(progMeshAscii, "uCellScale")
        uMeshMaterialMode = GLES30.glGetUniformLocation(progMeshAscii, "uMaterialMode")
        uMeshDebugSolid = GLES30.glGetUniformLocation(progMeshAscii, "uDebugSolid")
        uMeshTime = GLES30.glGetUniformLocation(progMeshAscii, "uTime")

        uTerrVp = GLES30.glGetUniformLocation(progTerrainAscii, "uVP")
        uTerrCenter = GLES30.glGetUniformLocation(progTerrainAscii, "uCenterXZ")
        uTerrScale = GLES30.glGetUniformLocation(progTerrainAscii, "uGridScale")
        uTerrSeedParams = GLES30.glGetUniformLocation(progTerrainAscii, "uSeedParams")
        uTerrCaveCenter = GLES30.glGetUniformLocation(progTerrainAscii, "uCaveCenter")
        uTerrGenRivers = GLES30.glGetUniformLocation(progTerrainAscii, "uGenRivers")
        uTerrAtlas = GLES30.glGetUniformLocation(progTerrainAscii, "uAtlas")
        uTerrCamPos = GLES30.glGetUniformLocation(progTerrainAscii, "uCamPos")
        uTerrTime = GLES30.glGetUniformLocation(progTerrainAscii, "uTime")
        uTerrDebugSolid = GLES30.glGetUniformLocation(progTerrainAscii, "uDebugSolid")

        uGrassVp = GLES30.glGetUniformLocation(progGrassInstanced, "uVP")
        uGrassPlayerPos = GLES30.glGetUniformLocation(progGrassInstanced, "uPlayerPos")
        uGrassCamRight = GLES30.glGetUniformLocation(progGrassInstanced, "uCamRight")
        uGrassTime = GLES30.glGetUniformLocation(progGrassInstanced, "uTime")
        uGrassSeedParams = GLES30.glGetUniformLocation(progGrassInstanced, "uSeedParams")
        uGrassCaveCenter = GLES30.glGetUniformLocation(progGrassInstanced, "uCaveCenter")
        uGrassRiverHalfW = GLES30.glGetUniformLocation(progGrassInstanced, "uRiverHalfW")
        uGrassAtlas = GLES30.glGetUniformLocation(progGrassInstanced, "uAtlas")

        uWaterMvp = GLES30.glGetUniformLocation(progWaterAscii, "uMVP")
        uWaterModel = GLES30.glGetUniformLocation(progWaterAscii, "uModel")
        uWaterAtlas = GLES30.glGetUniformLocation(progWaterAscii, "uAtlas")
        uWaterReflectTex = GLES30.glGetUniformLocation(progWaterAscii, "uReflectTex")
        uWaterTime = GLES30.glGetUniformLocation(progWaterAscii, "uTime")
    }

    private fun linkProgram(vsSrc: String, fsSrc: String): Int {
        val vs = GLES30.glCreateShader(GLES30.GL_VERTEX_SHADER)
        GLES30.glShaderSource(vs, vsSrc)
        GLES30.glCompileShader(vs)

        val fs = GLES30.glCreateShader(GLES30.GL_FRAGMENT_SHADER)
        GLES30.glShaderSource(fs, fsSrc)
        GLES30.glCompileShader(fs)

        val prog = GLES30.glCreateProgram()
        GLES30.glAttachShader(prog, vs)
        GLES30.glAttachShader(prog, fs)
        GLES30.glLinkProgram(prog)
        return prog
    }

    private fun render3DOpenWorldScene() {
        val aspect = width / height.toFloat()
        Matrix.perspectiveM(projMatrix, 0, 40.0f / state.cameraZoom, aspect, 0.5f, 90.0f)

        val cursorOffX = if (state.cursorViewMode) (state.cursorX - 0.5f) * 2.5f else 0.0f
        val cursorOffZ = if (state.cursorViewMode) (state.cursorY - 0.5f) * 2.5f else 0.0f
        val targetX = state.playerX + cursorOffX
        val targetZ = state.playerZ + cursorOffZ

        val camDist = 9.8f / state.cameraZoom
        val camHeight = state.groundY + 9.0f / state.cameraZoom
        val eyeX = targetX + sin(state.camYaw) * camDist
        val eyeY = camHeight
        val eyeZ = targetZ + cos(state.camYaw) * camDist

        WorldGenerator.updateGpuSeedParams(state.worldSeed, state.worldType)

        // 1. Planar Water Reflection FBO Pass
        if (state.genRivers) {
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, reflectFbo)
            GLES30.glViewport(0, 0, REFLECT_W, REFLECT_H)
            GLES30.glClearColor(0.015f, 0.024f, 0.038f, 1.0f)
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

            Matrix.setLookAtM(
                reflectViewMatrix, 0,
                eyeX, -eyeY * 0.65f, eyeZ,
                targetX, 0.0f, targetZ,
                0f, 1f, 0f
            )
            Matrix.multiplyMM(reflectVpMatrix, 0, projMatrix, 0, reflectViewMatrix, 0)
            draw3DEntitiesAndLandscape(reflectVpMatrix, eyeX, -eyeY * 0.65f, eyeZ)
        }

        // 2. Main Screen Pass
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        GLES30.glViewport(0, 0, width, height)
        GLES30.glClearColor(0.018f, 0.028f, 0.025f, 1.0f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

        Matrix.setLookAtM(
            viewMatrix, 0,
            eyeX, eyeY, eyeZ,
            targetX, state.groundY + 0.45f, targetZ,
            0f, 1f, 0f
        )
        Matrix.multiplyMM(vpMatrix, 0, projMatrix, 0, viewMatrix, 0)

        draw3DTerrainMesh(vpMatrix, eyeX, eyeY, eyeZ)
        if (state.genRivers) {
            drawWaterSurface(vpMatrix)
        }
        draw3DEntitiesAndLandscape(vpMatrix, eyeX, eyeY, eyeZ)
        if (!state.debugSolidMode) {
            drawInstanced3DGrass(vpMatrix)
        }
    }

    private fun draw3DTerrainMesh(vp: FloatArray, eyeX: Float, eyeY: Float, eyeZ: Float) {
        GLES30.glUseProgram(progTerrainAscii)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, glyphAtlasTex)
        GLES30.glUniform1i(uTerrAtlas, 0)

        // Snap grid center to 1.6-unit steps so terrain vertices never swim as the player moves
        val snapX = floor(state.playerX / 1.6f) * 1.6f
        val snapZ = floor(state.playerZ / 1.6f) * 1.6f
        val sp = WorldGenerator.gpuSeedParams
        val caveX = WorldGenerator.getPrimaryCaveCenterX(state.worldSeed)
        val caveZ = WorldGenerator.getPrimaryCaveCenterZ(state.worldSeed)

        GLES30.glUniformMatrix4fv(uTerrVp, 1, false, vp, 0)
        GLES30.glUniform2f(uTerrCenter, snapX, snapZ)
        GLES30.glUniform1f(uTerrScale, 36.0f)
        GLES30.glUniform4f(uTerrSeedParams, sp[0], sp[1], sp[2], sp[3])
        GLES30.glUniform2f(uTerrCaveCenter, caveX, caveZ)
        GLES30.glUniform1f(uTerrGenRivers, if (state.genRivers) 1.0f else 0.0f)
        GLES30.glUniform3f(uTerrCamPos, eyeX, eyeY, eyeZ)
        GLES30.glUniform1f(uTerrTime, state.timeSec)
        GLES30.glUniform1i(uTerrDebugSolid, if (state.debugSolidMode) 1 else 0)

        GLES30.glBindVertexArray(meshes.terrainGridMesh.vao)
        GLES30.glDrawElements(
            GLES30.GL_TRIANGLES,
            meshes.terrainGridMesh.indexCount,
            GLES30.GL_UNSIGNED_SHORT,
            0
        )

        // Draw active 3D Astral Vortex Skill Ring on the ground (`1000461463.jpg` "New skills")
        if (state.vortexActiveTimer > 0.0f) {
            GLES30.glUseProgram(progMeshAscii)
            GLES30.glUniform1i(uMeshAtlas, 0)
            GLES30.glUniform3f(uMeshCamPos, eyeX, eyeY, eyeZ)
            GLES30.glUniform1i(uMeshMaterialMode, 5)
            GLES30.glUniform1i(uMeshDebugSolid, 0)
            GLES30.glUniform1f(uMeshTime, state.timeSec)

            GLES30.glBindVertexArray(meshes.flatQuadMesh.vao)
            Matrix.setIdentityM(modelMatrix, 0)
            Matrix.translateM(modelMatrix, 0, state.vortexX, state.vortexY + 0.04f, state.vortexZ)
            Matrix.scaleM(modelMatrix, 0, 1.48f, 1.0f, 1.48f)
            Matrix.multiplyMM(mvpMatrix, 0, vp, 0, modelMatrix, 0)
            GLES30.glUniformMatrix4fv(uMeshMvp, 1, false, mvpMatrix, 0)
            GLES30.glUniformMatrix4fv(uMeshModel, 1, false, modelMatrix, 0)
            GLES30.glDrawElements(
                GLES30.GL_TRIANGLES,
                meshes.flatQuadMesh.indexCount,
                GLES30.GL_UNSIGNED_SHORT,
                0
            )
        }
        GLES30.glBindVertexArray(0)
    }

    private fun drawWaterSurface(vp: FloatArray) {
        GLES30.glUseProgram(progWaterAscii)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, glyphAtlasTex)
        GLES30.glUniform1i(uWaterAtlas, 0)

        GLES30.glActiveTexture(GLES30.GL_TEXTURE1)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, reflectTex)
        GLES30.glUniform1i(uWaterReflectTex, 1)
        GLES30.glUniform1f(uWaterTime, state.timeSec)

        val halfW = WorldGenerator.riverHalfWidth(state.worldType, state.genRivers)
        GLES30.glBindVertexArray(meshes.flatQuadMesh.vao)
        for (seg in -6..6) {
            val wx = state.playerX + seg * 4.8f
            val wz = WorldGenerator.riverCenterZ(wx, state.worldSeed, state.worldType)
            Matrix.setIdentityM(modelMatrix, 0)
            Matrix.translateM(modelMatrix, 0, wx, 0.01f, wz)
            Matrix.scaleM(modelMatrix, 0, 2.6f, 1.0f, halfW)
            Matrix.multiplyMM(mvpMatrix, 0, vp, 0, modelMatrix, 0)

            GLES30.glUniformMatrix4fv(uWaterMvp, 1, false, mvpMatrix, 0)
            GLES30.glUniformMatrix4fv(uWaterModel, 1, false, modelMatrix, 0)
            GLES30.glDrawElements(
                GLES30.GL_TRIANGLES,
                meshes.flatQuadMesh.indexCount,
                GLES30.GL_UNSIGNED_SHORT,
                0
            )
        }
        GLES30.glBindVertexArray(0)
    }

    private fun draw3DEntitiesAndLandscape(vp: FloatArray, eyeX: Float, eyeY: Float, eyeZ: Float) {
        GLES30.glUseProgram(progMeshAscii)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, glyphAtlasTex)
        GLES30.glUniform1i(uMeshAtlas, 0)
        GLES30.glUniform3f(uMeshCamPos, eyeX, eyeY, eyeZ)
        GLES30.glUniform1i(uMeshDebugSolid, if (state.debugSolidMode) 1 else 0)
        GLES30.glUniform1f(uMeshTime, state.timeSec)
        GLES30.glUniform1i(uMeshMaterialMode, 0)
        GLES30.glUniform1f(uMeshCellScale, 8.4f)

        // Pass 1: Faceted Craggy Rocks & Cliffs (`meshes.rockMesh`, anchored at y=0)
        GLES30.glBindVertexArray(meshes.rockMesh.vao)
        GLES30.glUniform3f(uMeshBaseColor, 0.78f, 0.85f, 0.92f)
        for (cIdx in 0 until WorldGenerator.MAX_CACHED_CHUNKS) {
            val chunk = WorldGenerator.chunkGrid[cIdx]
            if (chunk.builtSeed == Long.MIN_VALUE) continue
            for (rIdx in 0 until chunk.rockCount) {
                val rf = chunk.rocks[rIdx]
                val dx = rf.x - state.playerX
                val dz = rf.z - state.playerZ
                if (dx * dx + dz * dz > 35.0f * 35.0f) continue
                drawBoundMesh(vp, meshes.rockMesh.indexCount, rf.x, rf.y, rf.z, rf.yawDeg, rf.radiusX, rf.heightY, rf.radiusZ)
            }
        }

        // Pass 2: Vaulted Moonlit Cave Archways (`meshes.archMesh`)
        GLES30.glBindVertexArray(meshes.archMesh.vao)
        GLES30.glUniform3f(uMeshBaseColor, 0.74f, 0.82f, 0.90f)
        for (cIdx in 0 until WorldGenerator.MAX_CACHED_CHUNKS) {
            val chunk = WorldGenerator.chunkGrid[cIdx]
            if (chunk.builtSeed == Long.MIN_VALUE || !chunk.hasCaveArch) continue
            val dx = chunk.archX - state.playerX
            val dz = chunk.archZ - state.playerZ
            if (dx * dx + dz * dz <= 36.0f * 36.0f) {
                drawBoundMesh(vp, meshes.archMesh.indexCount, chunk.archX, chunk.archY, chunk.archZ, chunk.archYaw, 1.0f, 1.0f, 1.0f)
            }
        }

        // Pass 3: Gnarled Tree Trunks with Flared Roots (`meshes.trunkMesh`)
        GLES30.glBindVertexArray(meshes.trunkMesh.vao)
        GLES30.glUniform3f(uMeshBaseColor, 0.44f, 0.35f, 0.26f)
        for (cIdx in 0 until WorldGenerator.MAX_CACHED_CHUNKS) {
            val chunk = WorldGenerator.chunkGrid[cIdx]
            if (chunk.builtSeed == Long.MIN_VALUE) continue
            for (tIdx in 0 until chunk.treeCount) {
                val tr = chunk.trees[tIdx]
                val dx = tr.x - state.playerX
                val dz = tr.z - state.playerZ
                if (dx * dx + dz * dz > 33.0f * 33.0f) continue
                drawBoundMesh(vp, meshes.trunkMesh.indexCount, tr.x, tr.y, tr.z, tr.yawDeg, 1.15f, tr.heightY, 1.15f)
            }
        }

        // Pass 4: Multi-Lobed Foliage Canopies (`meshes.canopyMesh`)
        GLES30.glBindVertexArray(meshes.canopyMesh.vao)
        GLES30.glUniform3f(uMeshBaseColor, 0.24f, 0.62f, 0.28f)
        for (cIdx in 0 until WorldGenerator.MAX_CACHED_CHUNKS) {
            val chunk = WorldGenerator.chunkGrid[cIdx]
            if (chunk.builtSeed == Long.MIN_VALUE) continue
            for (tIdx in 0 until chunk.treeCount) {
                val tr = chunk.trees[tIdx]
                val dx = tr.x - state.playerX
                val dz = tr.z - state.playerZ
                if (dx * dx + dz * dz > 33.0f * 33.0f) continue
                drawBoundMesh(
                    vp, meshes.canopyMesh.indexCount,
                    tr.x, tr.y + tr.heightY * 0.94f, tr.z,
                    tr.yawDeg, tr.radiusX * 2.0f, tr.radiusX * 1.65f, tr.radiusZ * 2.0f
                )
                drawBoundMesh(
                    vp, meshes.canopyMesh.indexCount,
                    tr.x - 0.42f, tr.y + tr.heightY * 1.18f, tr.z + 0.32f,
                    tr.yawDeg + 45f, tr.radiusX * 1.55f, tr.radiusX * 1.35f, tr.radiusZ * 1.55f
                )
            }
        }

        // Pass 5: Pointed Hexagonal Bioluminescent Crystals & Shrines (`meshes.crystalMesh`)
        GLES30.glBindVertexArray(meshes.crystalMesh.vao)
        for (cIdx in 0 until WorldGenerator.MAX_CACHED_CHUNKS) {
            val chunk = WorldGenerator.chunkGrid[cIdx]
            if (chunk.builtSeed == Long.MIN_VALUE) continue
            for (gIdx in 0 until chunk.crystalCount) {
                val cr = chunk.crystals[gIdx]
                val dx = cr.x - state.playerX
                val dz = cr.z - state.playerZ
                if (dx * dx + dz * dz > 30.0f * 30.0f) continue
                if (cr.variant == 0) {
                    GLES30.glUniform3f(uMeshBaseColor, 0.72f, 0.94f, 1.0f)
                } else {
                    GLES30.glUniform3f(uMeshBaseColor, 0.88f, 0.68f, 1.0f)
                }
                drawBoundMesh(vp, meshes.crystalMesh.indexCount, cr.x, cr.y, cr.z, 18f, cr.radiusX * 1.8f, cr.heightY, cr.radiusZ * 1.8f)
            }
            if (chunk.hasShrine) {
                val dx = chunk.shrineX - state.playerX
                val dz = chunk.shrineZ - state.playerZ
                if (dx * dx + dz * dz <= 30.0f * 30.0f) {
                    GLES30.glUniform3f(uMeshBaseColor, 0.95f, 0.85f, 0.55f)
                    drawBoundMesh(vp, meshes.crystalMesh.indexCount, chunk.shrineX, chunk.shrineY, chunk.shrineZ, state.timeSec * 25f, 1.1f, 2.5f, 1.1f)
                }
            }
        }

        // Pass 6: Ground Loot Drops
        for (l in 0 until GameState.MAX_LOOT) {
            if (state.lootActive[l]) {
                setPartColor(state.lootMetal[l], false)
                drawBoundMesh(vp, meshes.crystalMesh.indexCount, state.lootX[l], state.lootY[l], state.lootZ[l], state.timeSec * 70f, 0.68f, 0.62f, 0.68f)
            }
        }

        // Pass 7: Sculpted 3D Humanoid Player Adventurer (`Senje`)
        val spd = sqrt(state.velX * state.velX + state.velZ * state.velZ)
        drawSculpted3DHumanoid(
            vp, state.playerX, state.playerY, state.playerZ, state.bodyYaw,
            state.gaitPhase, min(1.1f, spd / 4.2f), state.slashTimer / 0.28f,
            state.dodgeTimer > 0.0f, state.playerY > state.groundY + 0.05f,
            state.slotMetal, state.mounted, state.hurtFlash > 0.0f, true
        )

        // Pass 8: Sculpted 3D Humanoid Enemies & NPCs
        for (i in 0 until GameState.NUM_ENEMIES) {
            val dx = state.enemyX[i] - state.playerX
            val dz = state.enemyZ[i] - state.playerZ
            if (dx * dx + dz * dz > 26.0f * 26.0f) continue
            val eMove = if (state.enemyAggro[i] && state.enemyWindup[i] <= 0.0f) 0.85f else 0.0f
            val eMet = state.enemyMetal[i]
            val eSlots = intArrayOf(eMet, eMet, eMet, eMet, eMet, eMet, eMet)
            drawSculpted3DHumanoid(
                vp, state.enemyX[i], state.enemyY[i], state.enemyZ[i], state.enemyYaw[i],
                state.enemyGait[i], eMove, state.enemyWindup[i] / 0.42f,
                false, false, eSlots, false, state.enemyHurt[i] > 0.0f, false
            )
        }

        GLES30.glBindVertexArray(0)
    }

    /**
     * Renders an articulated 3D humanoid adventurer using sculpted armor VAOs
     * (`cuirassMesh`, `helmMesh`, `limbMesh`, `cloakMesh`, and `swordMesh`).
     */
    private fun drawSculpted3DHumanoid(
        vp: FloatArray,
        wx: Float,
        wy: Float,
        wz: Float,
        yawRad: Float,
        gait: Float,
        moveAmt: Float,
        slashProg: Float,
        dodging: Boolean,
        jumping: Boolean,
        slotMetals: IntArray,
        mounted: Boolean,
        hurtFlash: Boolean,
        isPlayer: Boolean
    ) {
        GLES30.glUniform1i(uMeshMaterialMode, 3)
        GLES30.glUniform1f(uMeshCellScale, if (isPlayer) 6.5f else 7.5f)

        val s = if (isPlayer) 1.26f else 1.14f
        val yawDeg = Math.toDegrees(yawRad.toDouble()).toFloat()
        val sinY = sin(yawRad)
        val cosY = cos(yawRad)
        val rightX = cosY
        val rightZ = -sinY

        val breathe = sin(state.timeSec * 2.6f) * 0.022f
        val bounce = abs(sin(gait)) * 0.085f * moveAmt
        val crouch = if (dodging) 0.22f else 0.0f
        val mountH = if (mounted) 0.78f else 0.0f
        val baseH = wy + mountH - crouch

        // 1. Limbs, Pauldrons, Greaves & Mounted Steed (`meshes.limbMesh`)
        GLES30.glBindVertexArray(meshes.limbMesh.vao)
        val limbIdxCount = meshes.limbMesh.indexCount

        // Ground contact shadow
        GLES30.glUniform3f(uMeshBaseColor, 0.015f, 0.022f, 0.020f)
        drawBoundMesh(vp, limbIdxCount, wx + 0.16f * s, wy + 0.015f, wz + 0.12f * s, yawDeg, 0.76f * s, 0.03f, 0.60f * s)

        if (mounted) {
            GLES30.glUniform3f(uMeshBaseColor, 0.86f, 0.90f, 0.95f)
            drawBoundMesh(vp, limbIdxCount, wx, wy + 0.68f + bounce, wz, yawDeg, 0.62f, 0.54f, 1.38f)
            drawBoundMesh(vp, limbIdxCount, wx + sinY * 0.62f, wy + 1.08f + bounce, wz + cosY * 0.62f, yawDeg, 0.38f, 0.58f, 0.44f)
            for (leg in 0..3) {
                val lx = if (leg % 2 == 0) -0.24f else 0.24f
                val lz = if (leg < 2) 0.44f else -0.44f
                val sw = sin(gait + leg * 1.57f) * 0.26f * moveAmt
                drawBoundMesh(
                    vp, limbIdxCount,
                    wx + rightX * lx + sinY * (lz + sw), wy + 0.34f, wz + rightZ * lx + cosY * (lz + sw),
                    yawDeg, 0.18f, 0.68f, 0.18f
                )
            }
        }

        // Articulated Thighs, Greaves & Sabatons (Slot 5=Legs, Slot 6=Boots)
        for (leg in 0..1) {
            val side = (if (leg == 0) -0.15f else 0.15f) * s
            val ph = gait + (if (leg == 1) PI.toFloat() else 0.0f)
            val swing = if (jumping) (if (leg == 0) 0.18f else -0.14f) else (sin(ph) * 0.28f * moveAmt)
            val lift = if (jumping) 0.16f else (max(0.0f, cos(ph)) * 0.14f * moveAmt)

            setPartColor(slotMetals[5], hurtFlash)
            val tx = wx + rightX * side + sinY * (swing * 0.5f) * s
            val ty = baseH + (0.58f + lift * 0.4f) * s
            val tz = wz + rightZ * side + cosY * (swing * 0.5f) * s
            drawBoundMesh(vp, limbIdxCount, tx, ty, tz, yawDeg, 0.22f * s, 0.46f * s, 0.24f * s)

            val sx = wx + rightX * side + sinY * (swing * 0.85f) * s
            val sy = baseH + (0.28f + lift * 0.8f) * s
            val sz = wz + rightZ * side + cosY * (swing * 0.85f) * s
            drawBoundMesh(vp, limbIdxCount, sx, sy, sz, yawDeg, 0.19f * s, 0.42f * s, 0.20f * s)

            setPartColor(slotMetals[6], hurtFlash)
            drawBoundMesh(
                vp, limbIdxCount, sx + sinY * 0.06f * s, baseH + (0.09f + lift) * s, sz + cosY * 0.06f * s,
                yawDeg, 0.20f * s, 0.18f * s, 0.28f * s
            )
        }

        val pelvisY = baseH + (0.80f + bounce) * s
        val chestY = pelvisY + (0.34f + breathe) * s

        // Pauldrons & Arms (Slot 2=Shoulders, Slot 4=Gloves)
        setPartColor(slotMetals[2], hurtFlash)
        val shSpan = 0.28f * s
        for (side in intArrayOf(-1, 1)) {
            drawBoundMesh(
                vp, limbIdxCount,
                wx + rightX * (side * shSpan), chestY + 0.14f * s, wz + rightZ * (side * shSpan),
                yawDeg, 0.23f * s, 0.25f * s, 0.23f * s
            )
        }

        setPartColor(slotMetals[4], hurtFlash)
        val armSw = sin(gait) * 0.20f * moveAmt
        drawBoundMesh(
            vp, limbIdxCount,
            wx - rightX * (shSpan + 0.04f * s) - sinY * armSw * s, chestY - 0.10f * s,
            wz - rightZ * (shSpan + 0.04f * s) - cosY * armSw * s,
            yawDeg, 0.17f * s, 0.44f * s, 0.18f * s
        )

        val slashAng = if (slashProg > 0.0f) (-1.35f + (1.0f - slashProg) * 2.7f) else (0.48f + armSw * 0.4f)
        val sDirX = sin(yawRad + slashAng)
        val sDirZ = cos(yawRad + slashAng)
        val rArmX = wx + rightX * (shSpan + 0.04f * s) + sDirX * 0.14f * s
        val rArmY = chestY - 0.08f * s
        val rArmZ = wz + rightZ * (shSpan + 0.04f * s) + sDirZ * 0.14f * s
        drawBoundMesh(vp, limbIdxCount, rArmX, rArmY, rArmZ, yawDeg, 0.17f * s, 0.44f * s, 0.18f * s)

        // 2. Sculpted V-Taper Cuirass & Pelvis Tassets (`meshes.cuirassMesh`, Slot 3=Chest)
        GLES30.glBindVertexArray(meshes.cuirassMesh.vao)
        setPartColor(slotMetals[3], hurtFlash)
        drawBoundMesh(vp, meshes.cuirassMesh.indexCount, wx, pelvisY, wz, yawDeg, 0.40f * s, 0.32f * s, 0.32f * s)
        drawBoundMesh(vp, meshes.cuirassMesh.indexCount, wx, chestY, wz, yawDeg, 0.48f * s, 0.54f * s, 0.38f * s)

        // 3. Sculpted Visored Knight Helm (`meshes.helmMesh`, Slot 1=Helm)
        GLES30.glBindVertexArray(meshes.helmMesh.vao)
        setPartColor(slotMetals[1], hurtFlash)
        val headY = chestY + 0.38f * s
        drawBoundMesh(vp, meshes.helmMesh.indexCount, wx, headY, wz, yawDeg, 0.30f * s, 0.36f * s, 0.32f * s)

        // 4. Crossguard Greatsword (`meshes.swordMesh`, Slot 0=Weapon)
        GLES30.glBindVertexArray(meshes.swordMesh.vao)
        setPartColor(slotMetals[0], false)
        val swordYawDeg = Math.toDegrees((yawRad + slashAng).toDouble()).toFloat()
        drawBoundMesh(
            vp, meshes.swordMesh.indexCount,
            rArmX + sDirX * 0.22f * s, rArmY - 0.08f * s, rArmZ + sDirZ * 0.22f * s,
            swordYawDeg, 0.18f * s, 0.18f * s, 0.92f * s
        )

        // 5. Flowing Pleated Traveler Cloak (`meshes.cloakMesh`)
        GLES30.glBindVertexArray(meshes.cloakMesh.vao)
        GLES30.glUniform1i(uMeshMaterialMode, 4)
        if (isPlayer) {
            GLES30.glUniform3f(uMeshBaseColor, 0.80f, 0.18f, 0.20f)
        } else {
            GLES30.glUniform3f(uMeshBaseColor, 0.34f, 0.38f, 0.44f)
        }
        val capeFlutter = sin(state.capeWavePhase) * 0.06f * (0.4f + moveAmt)
        drawBoundMesh(
            vp, meshes.cloakMesh.indexCount,
            wx - sinY * (0.16f + moveAmt * 0.06f) * s + rightX * capeFlutter * s,
            chestY - 0.10f * s,
            wz - cosY * (0.16f + moveAmt * 0.06f) * s + rightZ * capeFlutter * s,
            yawDeg, 0.48f * s, 0.72f * s, 0.28f * s
        )

        GLES30.glUniform1i(uMeshMaterialMode, 0)
    }

    private fun setPartColor(metalIdx: Int, hurtFlash: Boolean) {
        if (hurtFlash) {
            GLES30.glUniform3f(uMeshBaseColor, 1.0f, 0.28f, 0.28f)
        } else {
            val rgb = GameState.METAL_RGB[metalIdx.coerceIn(0, 9)]
            GLES30.glUniform3f(uMeshBaseColor, rgb[0], rgb[1], rgb[2])
        }
    }

    private fun drawBoundMesh(
        vp: FloatArray,
        indexCount: Int,
        x: Float,
        y: Float,
        z: Float,
        yawDeg: Float,
        sx: Float,
        sy: Float,
        sz: Float
    ) {
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, x, y, z)
        if (yawDeg != 0.0f) {
            Matrix.rotateM(modelMatrix, 0, yawDeg, 0f, 1f, 0f)
        }
        Matrix.scaleM(modelMatrix, 0, sx, sy, sz)
        Matrix.multiplyMM(mvpMatrix, 0, vp, 0, modelMatrix, 0)

        GLES30.glUniformMatrix4fv(uMeshMvp, 1, false, mvpMatrix, 0)
        GLES30.glUniformMatrix4fv(uMeshModel, 1, false, modelMatrix, 0)
        GLES30.glDrawElements(GLES30.GL_TRIANGLES, indexCount, GLES30.GL_UNSIGNED_SHORT, 0)
    }

    private fun drawInstanced3DGrass(vp: FloatArray) {
        GLES30.glUseProgram(progGrassInstanced)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, glyphAtlasTex)
        GLES30.glUniform1i(uGrassAtlas, 0)
        GLES30.glUniformMatrix4fv(uGrassVp, 1, false, vp, 0)
        GLES30.glUniform3f(uGrassPlayerPos, state.playerX, state.groundY, state.playerZ)
        GLES30.glUniform3f(uGrassCamRight, cos(state.camYaw), 0.0f, -sin(state.camYaw))
        GLES30.glUniform1f(uGrassTime, state.timeSec)

        val sp = WorldGenerator.gpuSeedParams
        val caveX = WorldGenerator.getPrimaryCaveCenterX(state.worldSeed)
        val caveZ = WorldGenerator.getPrimaryCaveCenterZ(state.worldSeed)
        val halfW = WorldGenerator.riverHalfWidth(state.worldType, state.genRivers)

        GLES30.glUniform4f(uGrassSeedParams, sp[0], sp[1], sp[2], sp[3])
        GLES30.glUniform2f(uGrassCaveCenter, caveX, caveZ)
        GLES30.glUniform1f(uGrassRiverHalfW, halfW)

        GLES30.glBindVertexArray(meshes.grassVao)
        val count = when (state.qualityPreset) {
            0 -> 12000
            1 -> 24000
            else -> MeshLibrary.MAX_GRASS_INSTANCES
        }
        GLES30.glDrawArraysInstanced(GLES30.GL_TRIANGLES, 0, 6, count)
        GLES30.glBindVertexArray(0)
    }

    private fun render3DChainmailEquipmentScene() {
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        GLES30.glViewport(0, 0, width, height)
        GLES30.glClearColor(0.0f, 0.0f, 0.0f, 1.0f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

        val aspect = width / height.toFloat()
        Matrix.perspectiveM(projMatrix, 0, 38.0f / state.previewZoom, aspect, 0.5f, 30.0f)
        Matrix.setLookAtM(viewMatrix, 0, 0.65f, 0.35f, 4.2f, 0.45f, -0.15f, 0.0f, 0f, 1f, 0f)
        Matrix.multiplyMM(vpMatrix, 0, projMatrix, 0, viewMatrix, 0)

        GLES30.glUseProgram(progMeshAscii)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, glyphAtlasTex)
        GLES30.glUniform1i(uMeshAtlas, 0)
        GLES30.glUniform3f(uMeshCamPos, 0.65f, 0.35f, 4.2f)
        GLES30.glUniform1f(uMeshCellScale, 8.0f)
        GLES30.glUniform1i(uMeshDebugSolid, if (state.debugSolidMode) 1 else 0)
        GLES30.glUniform1f(uMeshTime, state.timeSec)

        if (state.previewFullHero) {
            drawSculpted3DHumanoid(
                vpMatrix, -0.35f, -0.95f, 0.0f, state.previewYaw,
                state.timeSec * 2.0f, 0.35f, 0.0f,
                false, false, state.slotMetal, false, false, true
            )
        } else {
            // Single Continuous Sculpted 3D Chainmail Coif, Collar & Mantle Bust (`1000461485.jpg`)
            GLES30.glUniform1i(uMeshMaterialMode, 1)
            setPartColor(state.activeMetal, false)
            val yawDeg = Math.toDegrees(state.previewYaw.toDouble()).toFloat()
            GLES30.glBindVertexArray(meshes.coifBustMesh.vao)
            drawBoundMesh(vpMatrix, meshes.coifBustMesh.indexCount, -0.35f, -0.05f, 0.0f, yawDeg, 1.0f, 1.0f, 1.0f)
            GLES30.glBindVertexArray(0)
        }
    }

    companion object {
        private const val REFLECT_W = 512
        private const val REFLECT_H = 512
    }
}
