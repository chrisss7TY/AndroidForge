# ASHVEIL ONLINE: Cinders of the Abyss (Android Rust 3D Top-Down ASCII MMORPG)

A pure-ASCII (`0x20..=0x7E`), 60/120 FPS 3D top-down dark fantasy open-world MMORPG written in Rust for Android and desktop.

## How to Compile & Run
1. **Single-File Direct Compilation (`rustc`)**:
   ```bash
   rustc --edition 2021 ashveil_ascii_3d.rs -O -o ashveil_mmorpg
   ./ashveil_mmorpg
   ```
2. **Cargo Build / Test / Run (Desktop or Termux on Android)**:
   ```bash
   cargo build --release
   cargo test
   cargo run --release
   ```
3. **Android Native APK (`cargo-apk`)**:
   ```bash
   rustup target add aarch64-linux-android
   cargo install cargo-apk
   cargo apk build --release
   ```

## Core MMORPG, Loot & Leveling Features
- **MMORPG Shard Networking & Party System**: Non-blocking `std::net::UdpSocket` state synchronization (`MmoPacket`) paired with active online shard peers (`Veyr_Paladin`, `Nyx_Hexblade`, `Kael_Pyro`, `Mire_Cleric`), 4 switchable classes (`Ashen Knight`, `Abyssal Hexblade`, `Cinder Pyromancer`, `Sanctum Cleric`), party healing auras, and **World Raid Bosses** (`[RAID BOSS] THE ASHEN SOVEREIGN`).
- **5-Tier Loot Drops & 6-Slot Equipment System**: Enemies drop physical 3D ASCII loot (`$`, `/`, `[`, `^`, `o`, `?`, `!`) with vertical 3D ASCII light beams (`|` + `*`) for `Rare`, `Epic`, and `Legendary` gear across 6 slots (`Weapon`, `Armor`, `Helm`, `Ring`, `Amulet`, `Relic`) and a 16-slot loot bag.
- **RPG Leveling & 5 Core Attributes**: Earn XP from enemies, party assists, Raid Bosses, and Lore Monoliths (`Lv.1` to `Lv.50`), triggering a 3D Golden Ascension Pillar and awarding `+3 STAT PTS` per level to allocate into `VIT`, `STR`, `DEX`, `INT`, and `FAI`.
