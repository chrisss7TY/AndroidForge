# Ashveil signed-project package

This package restores the original Ashveil signing configuration and includes the original `app/ashveil.jks` from the project you uploaded. Both `debug` and `release` build variants explicitly use that key, so the generated APK is signed and keeps the same signing identity as the original project.

The Android version has been incremented to versionCode 17 / versionName 5.2.1 so it can update an installed versionCode 16 build, provided that installed build was signed with this same keystore.

## Build
1. Open the project folder in Android Studio.
2. Allow Gradle sync to finish.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)** for a signed debug APK, or select the release variant and build the APK.
4. Android Studio will show a notification with the APK location, normally `app/build/outputs/apk/debug/app-debug.apk` or `app/build/outputs/apk/release/app-release.apk`.

## Important key security
This archive contains your original signing key and the password that was already present in your uploaded project. Keep the archive private; do not upload it to public repositories or send it to other people. Anyone with the private key and password may be able to sign apps as this project.

This package fixes APK signing configuration only. It does not mean an APK was compiled or device-tested in this environment.
