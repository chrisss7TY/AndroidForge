package com.ashveil.abyss

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Real-time OpenGL ES 3.0 3D ASCII Rendering Engine for ASHVEIL.
 * - Custom GLSL #version 300 es shaders with normal-map perturbation, volumetric mist & rim lighting
 * - GPU VBO/IBO mesh pipeline (zero client-side buffer corruption)
 * - 32,000 GPU-instanced 3D ASCII grass blades & biome-aware lavender/white wildflowers
 * - 512x512 Planar Water Reflection FBO with distorted ASCII wave reflections
 * - Articulated 3D humanoid adventurer with flowing crimson traveler cloak & equipment geometry
 * - 3D Chainmail Coif & Full Character preview for the Equipment & Rune Forge
 */
class AsciiGlRenderer(private val state: GameState) : GLSurfaceView.Renderer {

    private var lastNs: Long = System.nanoTime()
    private var width: Int = 1280
    private var height: Int = 720

    // OpenGL Shader Programs
    private var progMeshAscii: Int = 0
    private var progGrassInstanced: Int = 0
    private var progWaterAscii: Int = 0

    // 16x6 High-Resolution Monospace Glyph Atlas Texture
    private var glyphAtlasTex: Int = 0

    // Planar Water Reflection Framebuffer Object (FBO)
    private var reflectFbo: Int = 0
    private var reflectTex: Int = 0
    private var reflectDepthRb: Int = 0

    // GPU VBOs & IBOs
    private var sphereVbo: Int = 0
    private var sphereIbo: Int = 0
    private var sphereIndexCount: Int = 0
    private var quadVbo: Int = 0

    // GPU Instanced 3D Grass & Wildflower Buffers
    private var grassRibbonVbo: Int = 0
    private var grassInstanceVbo: Int = 0

    // Transformation Matrices (Pre-allocated to avoid GC in render loop)
    private val projMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val vpMatrix = FloatArray(16)
    private val reflectViewMatrix = FloatArray(16)
    private val reflectVpMatrix = FloatArray(16)
    private val modelMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0.020f, 0.032f, 0.028f, 1.0f)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glDepthFunc(GLES30.GL_LEQUAL)
        GLES30.glDisable(GLES30.GL_CULL_FACE)

        glyphAtlasTex = createAsciiGlyphAtlasTexture()
        buildUnitSphereVbo(16, 20)
        buildQuadVbo()
        buildInstancedGrassBuffers()
        initReflectionFbo()
        compileAllShaders()
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        width = max(1, w)
        height = max(1, h)
        GLES30.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        val nowNs = System.nanoTime()
        var dt = (nowNs - lastNs) / 1_000_000_000.0f
        lastNs = nowNs
        if (dt > 0.05f) dt = 0.05f
        if (dt < 0.001f) dt = 0.001f

        state.stepSimulation(dt)

        if (state.screenMode == 2) {
            render3DChainmailEquipmentScene()
        } else {
            render3DOpenWorldScene()
        }
    }

    private fun createAsciiGlyphAtlasTexture(): Int {
        val cols = 16
        val rows = 6
        val cellW = 48
        val cellH = 48
        val bmp = Bitmap.createBitmap(cols * cellW, rows * cellH, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.TRANSPARENT)

        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        p.textSize = 37.0f
        p.color = Color.WHITE
        p.textAlign = Paint.Align.CENTER

        // 6 specialized rows of 16 ASCII characters:
        // Row 0..1: 32-step luminance ramp for 3D rocks, cliffs, and armor (`1000461471.jpg`)
        // Row 2: Chainmail coif concentric rings (`1000461485.jpg`)
        // Row 3: Individual 3D grass blades (`|/\,;`) & wildflowers (`*o+.`)
        // Row 4: Forest soil moss & normal-mapped cave stone glyphs (`1000461483.jpg`)
        // Row 5: Water ripples & Astral Vortex skill circle glyphs (`1000461484.jpg` & `1000461463.jpg`)
        val atlasChars =
            " .,:;~-=+*oahkbd" +
            "pqwmZOQ0N\$%&8B#W" +
            "@S8\$#c()350Qo*+=" +
            "|/\\,;'*o+.^v~:;#" +
            "0Q8B@WM#%&80aaqQ" +
            "-~=:.o0*+@\u00a7^v<>#"

        val fm = p.fontMetrics
        val baselineOff = -(fm.ascent + fm.descent) * 0.5f

        for (r in 0 until rows) {
            for (col in 0 until cols) {
                val idx = r * cols + col
                val ch = if (idx < atlasChars.length) atlasChars[idx] else '@'
                val cx = col * cellW + cellW * 0.5f
                val cy = r * cellH + cellH * 0.5f + baselineOff
                c.drawText(ch.toString(), cx, cy, p)
            }
        }

        val tex = IntArray(1)
        GLES30.glGenTextures(1, tex, 0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex[0])
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0)
        bmp.recycle()
        return tex[0]
    }

    private fun buildUnitSphereVbo(latBands: Int, lonBands: Int) {
        val vertCount = (latBands + 1) * (lonBands + 1)
        val verts = FloatArray(vertCount * 8)
        var vPtr = 0
        for (lat in 0..latBands) {
            val theta = (lat * PI / latBands).toFloat()
            val sinT = sin(theta)
            val cosT = cos(theta)
            for (lon in 0..lonBands) {
                val phi = (lon * 2.0 * PI / lonBands).toFloat()
                val nx = cos(phi) * sinT
                val ny = cosT
                val nz = sin(phi) * sinT
                verts[vPtr++] = nx * 0.5f
                verts[vPtr++] = ny * 0.5f
                verts[vPtr++] = nz * 0.5f
                verts[vPtr++] = nx
                verts[vPtr++] = ny
                verts[vPtr++] = nz
                verts[vPtr++] = lon / lonBands.toFloat()
                verts[vPtr++] = lat / latBands.toFloat()
            }
        }

        val indices = ShortArray(latBands * lonBands * 6)
        var iPtr = 0
        for (lat in 0 until latBands) {
            for (lon in 0 until lonBands) {
                val first = (lat * (lonBands + 1)) + lon
                val second = first + lonBands + 1
                indices[iPtr++] = first.toShort()
                indices[iPtr++] = second.toShort()
                indices[iPtr++] = (first + 1).toShort()
                indices[iPtr++] = second.toShort()
                indices[iPtr++] = (second + 1).toShort()
                indices[iPtr++] = (first + 1).toShort()
            }
        }
        sphereIndexCount = indices.size

        val vb = ByteBuffer.allocateDirect(verts.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
        vb.put(verts).position(0)

        val ib = ByteBuffer.allocateDirect(indices.size * 2)
            .order(ByteOrder.nativeOrder()).asShortBuffer()
        ib.put(indices).position(0)

        val bufs = IntArray(2)
        GLES30.glGenBuffers(2, bufs, 0)
        sphereVbo = bufs[0]
        sphereIbo = bufs[1]

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, sphereVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, verts.size * 4, vb, GLES30.GL_STATIC_DRAW)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)

        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, sphereIbo)
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, indices.size * 2, ib, GLES30.GL_STATIC_DRAW)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, 0)
    }

    private fun buildQuadVbo() {
        val q = floatArrayOf(
            -1f, 0f, -1f, 0f, 1f, 0f, 0f, 0f,
             1f, 0f, -1f, 0f, 1f, 0f, 1f, 0f,
            -1f, 0f,  1f, 0f, 1f, 0f, 0f, 1f,
             1f, 0f, -1f, 0f, 1f, 0f, 1f, 0f,
             1f, 0f,  1f, 0f, 1f, 0f, 1f, 1f,
            -1f, 0f,  1f, 0f, 1f, 0f, 0f, 1f
        )
        val qb = ByteBuffer.allocateDirect(q.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
        qb.put(q).position(0)

        val bufs = IntArray(1)
        GLES30.glGenBuffers(1, bufs, 0)
        quadVbo = bufs[0]
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, quadVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, q.size * 4, qb, GLES30.GL_STATIC_DRAW)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
    }

    private fun buildInstancedGrassBuffers() {
        val ribbon = floatArrayOf(
            -0.5f, 0.0f, 0.0f, 1.0f,
             0.5f, 0.0f, 1.0f, 1.0f,
            -0.5f, 1.0f, 0.0f, 0.0f,
             0.5f, 0.0f, 1.0f, 1.0f,
             0.5f, 1.0f, 1.0f, 0.0f,
            -0.5f, 1.0f, 0.0f, 0.0f
        )
        val rb = ByteBuffer.allocateDirect(ribbon.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
        rb.put(ribbon).position(0)

        val inst = FloatArray(MAX_GRASS_INSTANCES * 4)
        var seed = 918273645
        for (i in 0 until MAX_GRASS_INSTANCES) {
            seed = seed * 1664525 + 1013904223
            val rx = (((seed ushr 16) and 0xFFFF) / 65535.0f - 0.5f) * 30.0f
            seed = seed * 1664525 + 1013904223
            val rz = (((seed ushr 16) and 0xFFFF) / 65535.0f - 0.5f) * 30.0f
            seed = seed * 1664525 + 1013904223
            val isFlower = (i % 24 == 0)
            val hScale = if (isFlower) 0.25f else (0.30f + ((seed ushr 12) and 15) * 0.017f)
            val typeSeed = if (isFlower) (100.0f + (i % 6)) else (i % 16).toFloat()

            val o = i * 4
            inst[o] = rx
            inst[o + 1] = rz
            inst[o + 2] = hScale
            inst[o + 3] = typeSeed
        }
        val ib = ByteBuffer.allocateDirect(inst.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
        ib.put(inst).position(0)

        val vbos = IntArray(2)
        GLES30.glGenBuffers(2, vbos, 0)
        grassRibbonVbo = vbos[0]
        grassInstanceVbo = vbos[1]

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, grassRibbonVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, ribbon.size * 4, rb, GLES30.GL_STATIC_DRAW)

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, grassInstanceVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, inst.size * 4, ib, GLES30.GL_STATIC_DRAW)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
    }

    private fun initReflectionFbo() {
        val fbo = IntArray(1)
        val tex = IntArray(1)
        val rb = IntArray(1)
        GLES30.glGenFramebuffers(1, fbo, 0)
        GLES30.glGenTextures(1, tex, 0)
        GLES30.glGenRenderbuffers(1, rb, 0)

        reflectFbo = fbo[0]
        reflectTex = tex[0]
        reflectDepthRb = rb[0]

        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, reflectTex)
        GLES30.glTexImage2D(
            GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, REFLECT_W, REFLECT_H, 0,
            GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null
        )
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)

        GLES30.glBindRenderbuffer(GLES30.GL_RENDERBUFFER, reflectDepthRb)
        GLES30.glRenderbufferStorage(GLES30.GL_RENDERBUFFER, GLES30.GL_DEPTH_COMPONENT16, REFLECT_W, REFLECT_H)

        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, reflectFbo)
        GLES30.glFramebufferTexture2D(
            GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, reflectTex, 0
        )
        GLES30.glFramebufferRenderbuffer(
            GLES30.GL_FRAMEBUFFER, GLES30.GL_DEPTH_ATTACHMENT, GLES30.GL_RENDERBUFFER, reflectDepthRb
        )
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
    }

    private fun compileAllShaders() {
        val vsMesh = """
            #version 300 es
            layout(location = 0) in vec3 aPos;
            layout(location = 1) in vec3 aNormal;
            layout(location = 2) in vec2 aUv;
            uniform mat4 uMVP;
            uniform mat4 uModel;
            out vec3 vWorldPos;
            out vec3 vNormal;
            out vec2 vUv;
            void main() {
                vec4 wp = uModel * vec4(aPos, 1.0);
                vWorldPos = wp.xyz;
                mat3 normalMat = transpose(inverse(mat3(uModel)));
                vNormal = normalize(normalMat * aNormal);
                vUv = aUv;
                gl_Position = uMVP * vec4(aPos, 1.0);
            }
        """.trimIndent()

        // Modes:
        // 0 = Dark-Backed ASCII Cliff / Boulder / Tree with normal-mapped ridges (`1000461482.jpg`, `1000461471.jpg`)
        // 1 = 3D Chainmail Coif Concentric Ring ASCII Shader (`1000461485.jpg`)
        // 2 = Ground Soil / Normal-Mapped Cave Floor + Volumetric Drifting Fog (`1000461483.jpg`)
        // 3 = Dark-Armored 3D Character with bright silver rim/specular highlights (`1000461482.jpg`)
        // 4 = Crimson/Obsidian Traveler Cloak (`1000461483.jpg`, `1000461463.jpg`)
        // 5 = Astral Vortex Glowing Rune Circle on ground (`1000461463.jpg` "New skills")
        val fsMesh = """
            #version 300 es
            precision mediump float;
            in vec3 vWorldPos;
            in vec3 vNormal;
            in vec2 vUv;
            uniform sampler2D uAtlas;
            uniform vec3 uBaseColor;
            uniform vec3 uCamPos;
            uniform float uCellScale;
            uniform int uMaterialMode;
            uniform int uDebugSolid;
            uniform float uTime;
            out vec4 fragColor;

            float hash12(vec2 p) {
                return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
            }

            void main() {
                // Procedural normal-map perturbation for rocks & cave floor (`1000461483.jpg`)
                vec3 bump = vec3(
                    sin(vWorldPos.x * 4.5 + vWorldPos.z * 2.2) * cos(vWorldPos.y * 3.8),
                    cos(vWorldPos.x * 3.2 - vWorldPos.z * 4.1),
                    sin(vWorldPos.z * 4.8 - vWorldPos.x * 2.5)
                ) * ((uMaterialMode == 0 || uMaterialMode == 2) ? 0.22 : 0.06);

                vec3 N = normalize(vNormal + bump);
                vec3 L = normalize(vec3(-0.52, 0.80, 0.34));
                vec3 V = normalize(uCamPos - vWorldPos);
                vec3 H = normalize(L + V);
                float diff = max(0.06, dot(N, L));
                float spec = pow(max(0.0, dot(N, H)), 18.0);
                float rim = pow(1.0 - max(0.0, dot(N, V)), 2.3);

                if (uDebugSolid == 1) {
                    vec3 solidCol = uBaseColor * (0.25 + 0.75 * diff) + vec3(spec * 0.35 + rim * 0.2);
                    fragColor = vec4(solidCol, 1.0);
                    return;
                }

                // Mode 5: Glowing 3D Astral Vortex Rune Ring (`1000461463.jpg` "New skills")
                if (uMaterialMode == 5) {
                    vec2 uvCentered = (vUv - vec2(0.5)) * 2.0;
                    float r = length(uvCentered);
                    if (r > 0.98 || r < 0.42) discard;
                    float ringBand = smoothstep(0.42, 0.56, r) * (1.0 - smoothstep(0.84, 0.98, r));
                    float ang = atan(uvCentered.y, uvCentered.x) + uTime * 1.8;
                    float seg = floor(mod(ang * 4.5, 16.0));
                    vec2 gUv = fract(vec2(ang * 3.8, (r - 0.42) * 3.2));
                    vec2 aUv = (vec2(seg, 5.0) + gUv) / vec2(16.0, 6.0);
                    float m = texture(uAtlas, aUv).a;
                    float spark = pow(max(0.0, cos(ang - uTime * 3.2)), 8.0);
                    vec3 glowCol = mix(vec3(0.68, 0.56, 0.95), vec3(1.0, 0.96, 0.82), spark + m * 0.5);
                    if (m * ringBand < 0.12 && spark < 0.4) discard;
                    fragColor = vec4(glowCol * (0.55 + 0.75 * m + spark * 0.8), 1.0);
                    return;
                }

                // Mode 2: Ground Soil & Normal-Mapped Cave Floor (`1000461483.jpg`)
                if (uMaterialMode == 2) {
                    bool inCave = (vWorldPos.z < -8.5);
                    vec2 gCoord = vWorldPos.xz * (inCave ? 3.2 : 2.3);
                    vec2 cId = floor(gCoord);
                    vec2 cUv = fract(gCoord);
                    float h = hash12(cId);
                    vec3 soil = inCave ? vec3(0.016, 0.020, 0.028) : vec3(0.020, 0.033, 0.028);
                    float ridge = max(0.0, sin(vWorldPos.x * 1.3 + sin(vWorldPos.z * 0.9) * 2.0) * cos(vWorldPos.z * 1.1));
                    if (!inCave && h < 0.52) {
                        fragColor = vec4(soil, 1.0);
                        return;
                    }
                    float gCol = floor(clamp(h * 10.0 + ridge * 6.0, 0.0, 15.0));
                    vec2 aUv = (vec2(gCol, 4.0) + cUv) / vec2(16.0, 6.0);
                    float m = texture(uAtlas, aUv).a;
                    vec3 glyphTone = inCave
                        ? mix(vec3(0.18, 0.23, 0.32), vec3(0.68, 0.76, 0.88), pow(ridge, 2.0))
                        : vec3(0.16, 0.24, 0.28);
                    vec3 col = mix(soil, glyphTone, m * (inCave ? (0.35 + 0.65 * ridge) : 0.55));
                    fragColor = vec4(col, 1.0);
                    return;
                }

                // Aspect-corrected rectangular monospace character cells (`QdBrqi*==:;~;` look!)
                vec2 cellDim = vec2(max(6.0, uCellScale), max(8.0, uCellScale * 1.32));
                vec2 scGrid = gl_FragCoord.xy / cellDim;
                vec2 cellId = floor(scGrid);
                vec2 cellUv = fract(scGrid);
                cellUv.y = 1.0 - cellUv.y;

                // Mode 3 & 4: 3D Adventurer Armor & Flowing Crimson Traveler Cloak
                if (uMaterialMode == 3 || uMaterialMode == 4) {
                    float lum = clamp(diff * 0.50 + spec * 0.95 + rim * 0.56, 0.04, 0.99);
                    float idx = (spec > 0.34 || rim > 0.56) ? (22.0 + floor(lum * 9.0))
                              : (diff > 0.36 ? (8.0 + floor(lum * 13.0)) : (2.0 + floor(lum * 6.0)));
                    vec2 atlasUv = (vec2(mod(idx, 16.0), floor(idx / 16.0)) + cellUv) / vec2(16.0, 6.0);
                    float mask = texture(uAtlas, atlasUv).a;
                    vec3 obsidianBack = vec3(0.012, 0.016, 0.020);
                    vec3 glyphRgb;
                    if (uMaterialMode == 4) {
                        // Flowing Crimson Cloak (`1000461483.jpg` & `1000461463.jpg`)
                        glyphRgb = (rim > 0.62) ? vec3(0.95, 0.58, 0.58) : (uBaseColor * (0.38 + 0.82 * lum));
                    } else {
                        glyphRgb = (spec > 0.34 || rim > 0.56) ? vec3(0.96, 0.98, 1.0) : (uBaseColor * (0.34 + 0.78 * lum));
                    }
                    fragColor = vec4(mix(obsidianBack, glyphRgb, mask), 1.0);
                    return;
                }

                // Mode 1: 3D Chainmail Coif concentric ASCII rings (`1000461485.jpg`)
                if (uMaterialMode == 1) {
                    float lum = clamp(diff * 0.82 + spec * 0.45 + rim * 0.38, 0.05, 0.99);
                    float ringRow = floor(vUv.y * 26.0);
                    float ringCol = floor(vUv.x * 38.0 + mod(ringRow, 2.0) * 0.5);
                    float h = hash12(vec2(ringCol, ringRow) + cellId * 0.15);
                    float glyphCol = floor(clamp(lum * 11.0 + h * 5.0, 1.0, 15.0));
                    vec2 atlasUv = (vec2(glyphCol, 2.0) + cellUv) / vec2(16.0, 6.0);
                    float mask = texture(uAtlas, atlasUv).a;
                    vec3 litGlyph = uBaseColor * (0.22 + 0.92 * lum);
                    fragColor = vec4(mix(vec3(0.01, 0.012, 0.015), litGlyph, mask), 1.0);
                    return;
                }

                // Mode 0: Dark-Backed 3D ASCII Cliffs, Boulders & Trees (`1000461482.jpg`, `1000461471.jpg`)
                float lum = clamp(diff * 0.76 + rim * 0.48 + spec * 0.25, 0.05, 0.99);
                float h = hash12(cellId);
                float idx = clamp(floor((lum * 0.78 + h * 0.22) * 31.0), 2.0, 31.0);
                float glyphCol = mod(idx, 16.0);
                float glyphRow = floor(idx / 16.0);

                vec2 atlasUv = (vec2(glyphCol, glyphRow) + cellUv) / vec2(16.0, 6.0);
                float mask = texture(uAtlas, atlasUv).a;
                vec3 darkBack = vec3(0.014, 0.019, 0.025);
                vec3 litGlyph = uBaseColor * (0.26 + 0.86 * lum);
                vec3 col = mix(darkBack, litGlyph, mask);

                // Volumetric ground mist + distance fog (`1000461482.jpg`)
                float dist = length(vWorldPos.xz - uCamPos.xz);
                float mistWave = sin(vWorldPos.x * 0.35 + vWorldPos.z * 0.28 - uTime * 0.55)
                               * cos(vWorldPos.x * 0.22 - vWorldPos.z * 0.41 + uTime * 0.38);
                float lowMist = clamp((1.6 - vWorldPos.y) * 0.45, 0.0, 1.0) * smoothstep(0.15, 0.75, mistWave * 0.5 + 0.5) * 0.28;
                float fog = clamp((dist - 15.0) / 24.0, 0.0, 0.50) + lowMist;
                fragColor = vec4(mix(col, vec3(0.52, 0.60, 0.63), clamp(fog, 0.0, 0.62)), 1.0);
            }
        """.trimIndent()

        // 2. GPU Instanced 3D Grass & Wildflower Shader with Volumetric Mist & Shadows
        val vsGrass = """
            #version 300 es
            layout(location = 0) in vec4 aRibbon;
            layout(location = 1) in vec4 aInst;
            uniform mat4 uVP;
            uniform vec3 uPlayerPos;
            uniform vec3 uCamRight;
            uniform float uTime;
            uniform float uRiverPhase;
            uniform float uRiverAmp;
            uniform float uRiverHalfW;
            out vec2 vUv;
            out vec3 vColor;
            out vec2 vAtlasCell;
            out float vFog;
            void main() {
                vec2 tile = floor((uPlayerPos.xz - aInst.xy + 15.0) / 30.0) * 30.0 + aInst.xy;
                float riverZ = -6.5 + sin(tile.x * 0.13 + uRiverPhase) * uRiverAmp
                             + cos(tile.x * 0.055 - uRiverPhase * 0.5) * 1.35;
                if (uRiverHalfW > 0.01 && abs(tile.y - riverZ) < uRiverHalfW + 0.15) {
                    gl_Position = vec4(0.0, 0.0, -2.0, 1.0);
                    return;
                }
                // Exclude grass deep inside the dark Moonlit Cave chamber (`1000461481.jpg`)
                vec2 dCave = tile - vec2(0.0, -19.5);
                if (dot(dCave, dCave) < 6.8 * 6.8) {
                    gl_Position = vec4(0.0, 0.0, -2.0, 1.0);
                    return;
                }

                // Extra lavender/violet wildflower density outside the Moonlit Cave entrance (`1000461481.jpg`)
                bool nearCaveMouth = (tile.y < -7.0 && tile.y > -14.5 && abs(tile.x) < 9.5);
                bool isFlower = (aInst.w >= 100.0) || (nearCaveMouth && mod(aInst.w, 4.0) < 1.0);

                float sway = sin(tile.x * 0.55 + tile.y * 0.45 - uTime * 2.4) * 0.11 * aRibbon.y;
                float wScale = isFlower ? 0.18 : 0.115;
                vec3 worldPos = vec3(tile.x, uPlayerPos.y, tile.y)
                              + uCamRight * (aRibbon.x * wScale + sway)
                              + vec3(0.0, aRibbon.y * aInst.z, 0.0);

                // Player & Canyon Cliff Cast Shadows (`1000461482.jpg`)
                float dPlayer = length(tile - (uPlayerPos.xz + vec2(0.32, 0.22)));
                float shadow = smoothstep(0.32, 1.30, dPlayer);
                float canyonShadow = smoothstep(1.6, 3.4, length(tile - vec2(-4.2, 3.5)))
                                   * smoothstep(1.6, 3.4, length(tile - vec2(5.4, 2.8)));
                shadow *= (0.45 + 0.55 * canyonShadow);

                if (isFlower) {
                    float fType = mod(aInst.w, 5.0);
                    vAtlasCell = vec2(6.0 + mod(fType, 4.0), 3.0);
                    vec3 fCol = (fType < 2.0) ? vec3(0.76, 0.60, 0.95)
                              : (fType < 3.5 ? vec3(0.94, 0.96, 0.92) : vec3(0.66, 0.50, 0.88));
                    vColor = fCol * (0.45 + 0.55 * shadow);
                } else {
                    vAtlasCell = vec2(mod(aInst.w, 6.0), 3.0);
                    float shade = fract(aInst.w * 0.173 + sin(tile.x * 0.25 + tile.y * 0.25) * 0.2);
                    vec3 rootCol = vec3(0.03, 0.10, 0.045);
                    vec3 tipCol = mix(vec3(0.13, 0.37, 0.16), vec3(0.36, 0.65, 0.31), shade);
                    vColor = mix(rootCol, tipCol, aRibbon.y) * (0.28 + 0.72 * shadow);
                }

                // Drifting Volumetric Ground Fog Ribbons (`1000461482.jpg` "Fog testing + Cursor view")
                float m1 = sin(tile.x * 0.32 + tile.y * 0.24 - uTime * 0.62);
                float m2 = cos(tile.x * 0.19 - tile.y * 0.37 + uTime * 0.44);
                float mistRibbon = smoothstep(0.35, 0.88, m1 * m2 + 0.35) * 0.44;
                float distCam = length(tile - uPlayerPos.xz);
                vFog = clamp((distCam - 11.5) / 18.0, 0.0, 0.42) + mistRibbon;
                vUv = aRibbon.zw;
                gl_Position = uVP * vec4(worldPos, 1.0);
            }
        """.trimIndent()

        val fsGrass = """
            #version 300 es
            precision mediump float;
            in vec2 vUv;
            in vec3 vColor;
            in vec2 vAtlasCell;
            in float vFog;
            uniform sampler2D uAtlas;
            out vec4 fragColor;
            void main() {
                vec2 atlasUv = (vAtlasCell + vUv) / vec2(16.0, 6.0);
                float a = texture(uAtlas, atlasUv).a;
                if (a < 0.24) discard;
                vec3 col = mix(vColor, vec3(0.56, 0.64, 0.66), clamp(vFog, 0.0, 0.68));
                fragColor = vec4(col, 1.0);
            }
        """.trimIndent()

        // 3. Normal-Mapped 3D Water & Planar ASCII Reflection Shader (`1000461484.jpg` "Water reflection test")
        val vsWater = """
            #version 300 es
            layout(location = 0) in vec3 aPos;
            uniform mat4 uMVP;
            uniform mat4 uModel;
            out vec3 vWorldPos;
            out vec4 vClipPos;
            void main() {
                vec4 wp = uModel * vec4(aPos, 1.0);
                vWorldPos = wp.xyz;
                vClipPos = uMVP * vec4(aPos, 1.0);
                gl_Position = vClipPos;
            }
        """.trimIndent()

        val fsWater = """
            #version 300 es
            precision mediump float;
            in vec3 vWorldPos;
            in vec4 vClipPos;
            uniform sampler2D uAtlas;
            uniform sampler2D uReflectTex;
            uniform float uTime;
            out vec4 fragColor;
            void main() {
                vec2 p = vWorldPos.xz;
                float w1 = sin(p.x * 1.6 + p.y * 1.1 - uTime * 2.5);
                float w2 = cos(p.x * 0.9 - p.y * 1.9 + uTime * 1.9);
                vec3 N = normalize(vec3(w1 * 0.26, 1.0, w2 * 0.26));
                vec3 L = normalize(vec3(-0.45, 0.65, 0.60));
                float spec = pow(max(0.0, dot(N, L)), 14.0);

                vec2 ndc = (vClipPos.xy / max(0.001, vClipPos.w)) * 0.5 + 0.5;
                vec2 reflUv = clamp(vec2(ndc.x, 1.0 - ndc.y) + N.xz * 0.032, 0.01, 0.99);
                vec3 reflCol = texture(uReflectTex, reflUv).rgb;

                vec2 cellUv = fract(vec2(p.x * 4.2, p.y * 5.6));
                float glyphIdx = floor(clamp((spec * 1.4 + length(reflCol) * 0.55), 0.0, 0.99) * 15.0);
                vec2 atlasUv = (vec2(glyphIdx, 5.0) + cellUv) / vec2(16.0, 6.0);
                float gMask = texture(uAtlas, atlasUv).a;

                vec3 deepWater = vec3(0.018, 0.028, 0.048);
                vec3 streakCol = vec3(0.76, 0.85, 0.95) * gMask * smoothstep(0.32, 0.86, spec + w1 * 0.24);
                vec3 asciiRefl = reflCol * (0.35 + 0.65 * gMask);
                vec3 col = deepWater + asciiRefl * 0.85 + streakCol;
                fragColor = vec4(col, 1.0);
            }
        """.trimIndent()

        progMeshAscii = linkProgram(vsMesh, fsMesh)
        progGrassInstanced = linkProgram(vsGrass, fsGrass)
        progWaterAscii = linkProgram(vsWater, fsWater)
    }

    private fun linkProgram(vsSrc: String, fsSrc: String): Int {
        val vs = GLES30.glCreateShader(GLES30.GL_VERTEX_SHADER)
        GLES30.glShaderSource(vs, vsSrc)
        GLES30.glCompileShader(vs)

        val fs = GLES30.glCreateShader(GLES30.GL_FRAGMENT_SHADER)
        GLES30.glShaderSource(fs, fsSrc)
        GLES30.glCompileShader(fs)

        val prog = GLES30.glCreateProgram()
        GLES30.glAttachShader(prog, vs)
        GLES30.glAttachShader(prog, fs)
        GLES30.glLinkProgram(prog)
        return prog
    }

    private fun render3DOpenWorldScene() {
        val aspect = width / height.toFloat()
        Matrix.perspectiveM(projMatrix, 0, 40.0f / state.cameraZoom, aspect, 0.5f, 85.0f)

        val cursorOffX = if (state.cursorViewMode) (state.cursorX - 0.5f) * 2.4f else 0.0f
        val cursorOffZ = if (state.cursorViewMode) (state.cursorY - 0.5f) * 2.4f else 0.0f
        val targetX = state.playerX + cursorOffX
        val targetZ = state.playerZ + cursorOffZ

        val camDist = 9.8f / state.cameraZoom
        val camHeight = state.groundY + 9.0f / state.cameraZoom
        val eyeX = targetX + sin(state.camYaw) * camDist
        val eyeY = camHeight
        val eyeZ = targetZ + cos(state.camYaw) * camDist

        // 1. Planar Water Reflection FBO Pass
        if (state.genRivers) {
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, reflectFbo)
            GLES30.glViewport(0, 0, REFLECT_W, REFLECT_H)
            GLES30.glClearColor(0.015f, 0.024f, 0.038f, 1.0f)
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

            Matrix.setLookAtM(
                reflectViewMatrix, 0,
                eyeX, -eyeY * 0.65f, eyeZ,
                targetX, 0.0f, targetZ,
                0f, 1f, 0f
            )
            Matrix.multiplyMM(reflectVpMatrix, 0, projMatrix, 0, reflectViewMatrix, 0)
            draw3DEntitiesAndLandscape(reflectVpMatrix, eyeX, -eyeY * 0.65f, eyeZ)
        }

        // 2. Main Screen Pass
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        GLES30.glViewport(0, 0, width, height)
        GLES30.glClearColor(0.020f, 0.032f, 0.028f, 1.0f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

        Matrix.setLookAtM(
            viewMatrix, 0,
            eyeX, eyeY, eyeZ,
            targetX, state.groundY + 0.45f, targetZ,
            0f, 1f, 0f
        )
        Matrix.multiplyMM(vpMatrix, 0, projMatrix, 0, viewMatrix, 0)

        drawGroundPlane(vpMatrix, eyeX, eyeY, eyeZ)
        if (state.genRivers) {
            drawWaterSurface(vpMatrix)
        }
        draw3DEntitiesAndLandscape(vpMatrix, eyeX, eyeY, eyeZ)
        if (!state.debugSolidMode) {
            drawInstanced3DGrass(vpMatrix)
        }
    }

    private fun bindQuadVbo() {
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, quadVbo)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 32, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 32, 12)
        GLES30.glEnableVertexAttribArray(2)
        GLES30.glVertexAttribPointer(2, 2, GLES30.GL_FLOAT, false, 32, 24)
    }

    private fun bindSphereVbo() {
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, sphereVbo)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 32, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 32, 12)
        GLES30.glEnableVertexAttribArray(2)
        GLES30.glVertexAttribPointer(2, 2, GLES30.GL_FLOAT, false, 32, 24)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, sphereIbo)
    }

    private fun drawGroundPlane(vp: FloatArray, eyeX: Float, eyeY: Float, eyeZ: Float) {
        GLES30.glUseProgram(progMeshAscii)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, glyphAtlasTex)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uAtlas"), 0)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uCamPos"), eyeX, eyeY, eyeZ)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progMeshAscii, "uCellScale"), 8.0f)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uMaterialMode"), 2)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uDebugSolid"), if (state.debugSolidMode) 1 else 0)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progMeshAscii, "uTime"), state.timeSec)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 0.08f, 0.16f, 0.10f)

        bindQuadVbo()
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, state.playerX, state.groundY - 0.02f, state.playerZ)
        Matrix.scaleM(modelMatrix, 0, 38.0f, 1.0f, 38.0f)
        Matrix.multiplyMM(mvpMatrix, 0, vp, 0, modelMatrix, 0)

        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(progMeshAscii, "uMVP"), 1, false, mvpMatrix, 0)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(progMeshAscii, "uModel"), 1, false, modelMatrix, 0)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 6)

        // Draw active 3D Astral Vortex Skill Ring on the ground (`1000461463.jpg` "New skills"!)
        if (state.vortexActiveTimer > 0.0f) {
            GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uMaterialMode"), 5)
            Matrix.setIdentityM(modelMatrix, 0)
            Matrix.translateM(modelMatrix, 0, state.vortexX, state.vortexY + 0.02f, state.vortexZ)
            Matrix.scaleM(modelMatrix, 0, 1.45f, 1.0f, 1.45f)
            Matrix.multiplyMM(mvpMatrix, 0, vp, 0, modelMatrix, 0)
            GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(progMeshAscii, "uMVP"), 1, false, mvpMatrix, 0)
            GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(progMeshAscii, "uModel"), 1, false, modelMatrix, 0)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 6)
        }

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
    }

    private fun drawWaterSurface(vp: FloatArray) {
        GLES30.glUseProgram(progWaterAscii)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, glyphAtlasTex)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progWaterAscii, "uAtlas"), 0)

        GLES30.glActiveTexture(GLES30.GL_TEXTURE1)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, reflectTex)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progWaterAscii, "uReflectTex"), 1)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progWaterAscii, "uTime"), state.timeSec)

        val halfW = WorldGenerator.riverHalfWidth(state.worldType, state.genRivers)
        bindQuadVbo()
        for (seg in -5..5) {
            val wx = state.playerX + seg * 5.2f
            val wz = WorldGenerator.riverCenterZ(wx, state.worldSeed, state.worldType)
            Matrix.setIdentityM(modelMatrix, 0)
            Matrix.translateM(modelMatrix, 0, wx, 0.01f, wz)
            Matrix.scaleM(modelMatrix, 0, 2.8f, 1.0f, halfW)
            Matrix.multiplyMM(mvpMatrix, 0, vp, 0, modelMatrix, 0)

            GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(progWaterAscii, "uMVP"), 1, false, mvpMatrix, 0)
            GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(progWaterAscii, "uModel"), 1, false, modelMatrix, 0)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 6)
        }
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
    }

    private fun draw3DEntitiesAndLandscape(vp: FloatArray, eyeX: Float, eyeY: Float, eyeZ: Float) {
        GLES30.glUseProgram(progMeshAscii)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, glyphAtlasTex)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uAtlas"), 0)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uCamPos"), eyeX, eyeY, eyeZ)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uDebugSolid"), if (state.debugSolidMode) 1 else 0)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progMeshAscii, "uTime"), state.timeSec)

        bindSphereVbo()

        // 1. Render Seeded Procedural Chunks (Rocks, Canyon Pillars, Trees, Cave Crystals, Shrines)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uMaterialMode"), 0)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progMeshAscii, "uCellScale"), 8.5f)

        for (cIdx in 0 until WorldGenerator.MAX_CACHED_CHUNKS) {
            val chunk = WorldGenerator.chunkGrid[cIdx]
            if (chunk.builtSeed == Long.MIN_VALUE) continue

            // Ground-anchored Dark-Backed ASCII Rock Formations & Canyon Walls (`1000461482.jpg`, `1000461471.jpg`)
            GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 0.78f, 0.85f, 0.92f)
            for (rIdx in 0 until chunk.rockCount) {
                val rf = chunk.rocks[rIdx]
                val dx = rf.x - state.playerX
                val dz = rf.z - state.playerZ
                if (dx * dx + dz * dz > 34.0f * 34.0f) continue
                drawSpherePart(vp, rf.x, rf.y + rf.heightY * 0.35f, rf.z, 0f, rf.radiusX, rf.heightY, rf.radiusZ)
            }

            // Ground-anchored Multi-Canopy 3D Forest Trees
            for (tIdx in 0 until chunk.treeCount) {
                val tr = chunk.trees[tIdx]
                val dx = tr.x - state.playerX
                val dz = tr.z - state.playerZ
                if (dx * dx + dz * dz > 32.0f * 32.0f) continue
                // Trunk
                GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 0.42f, 0.34f, 0.26f)
                drawSpherePart(vp, tr.x, tr.y + tr.heightY * 0.45f, tr.z, 0f, 0.54f, tr.heightY, 0.54f)
                // Layered 3D Leaf Canopies
                GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 0.24f, 0.60f, 0.28f)
                drawSpherePart(vp, tr.x, tr.y + tr.heightY * 0.92f, tr.z, 0f, tr.radiusX, tr.radiusX * 0.85f, tr.radiusX)
                drawSpherePart(
                    vp, tr.x - 0.38f, tr.y + tr.heightY * 1.15f, tr.z + 0.28f,
                    0f, tr.radiusX * 0.76f, tr.radiusX * 0.72f, tr.radiusX * 0.76f
                )
            }

            // Bioluminescent Cave Crystals (`1000461481.jpg` "Moonlit Cave")
            for (gIdx in 0 until chunk.crystalCount) {
                val cr = chunk.crystals[gIdx]
                val dx = cr.x - state.playerX
                val dz = cr.z - state.playerZ
                if (dx * dx + dz * dz > 30.0f * 30.0f) continue
                if (cr.variant == 0) {
                    GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 0.72f, 0.92f, 1.0f)
                } else {
                    GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 0.86f, 0.68f, 1.0f)
                }
                drawSpherePart(vp, cr.x, cr.y + cr.heightY * 0.42f, cr.z, 18f, cr.radiusX, cr.heightY, cr.radiusZ)
            }

            // Ancient Runic Shrine Pillar
            if (chunk.hasShrine) {
                val dx = chunk.shrineX - state.playerX
                val dz = chunk.shrineZ - state.playerZ
                if (dx * dx + dz * dz < 30.0f * 30.0f) {
                    GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 0.92f, 0.84f, 0.56f)
                    drawSpherePart(vp, chunk.shrineX, chunk.shrineY + 1.15f, chunk.shrineZ, 0f, 0.65f, 2.5f, 0.65f)
                }
            }
        }

        // 2. Loot Chests / Forge Ingots on ground
        for (l in 0 until GameState.MAX_LOOT) {
            if (state.lootActive[l]) {
                setPartColor(state.lootMetal[l], false)
                drawSpherePart(vp, state.lootX[l], state.lootY[l] + 0.24f, state.lootZ[l], state.timeSec * 65f, 0.42f, 0.34f, 0.42f)
            }
        }

        // 3. Articulated 3D Humanoid Player Adventurer (`Senje`)
        val spd = sqrt(state.velX * state.velX + state.velZ * state.velZ)
        drawConnected3DHumanoid(
            vp, state.playerX, state.playerY, state.playerZ, state.bodyYaw,
            state.gaitPhase, min(1.1f, spd / 4.2f), state.slashTimer / 0.28f,
            state.dodgeTimer > 0.0f, state.playerY > state.groundY + 0.05f,
            state.slotMetal, state.mounted, state.hurtFlash > 0.0f, true
        )

        // 4. Articulated 3D Humanoid Enemies
        for (i in 0 until GameState.NUM_ENEMIES) {
            val dx = state.enemyX[i] - state.playerX
            val dz = state.enemyZ[i] - state.playerZ
            if (dx * dx + dz * dz > 26.0f * 26.0f) continue
            val eMove = if (state.enemyAggro[i] && state.enemyWindup[i] <= 0.0f) 0.85f else 0.0f
            val eMet = state.enemyMetal[i]
            val eSlots = intArrayOf(eMet, eMet, eMet, eMet, eMet, eMet, eMet)
            drawConnected3DHumanoid(
                vp, state.enemyX[i], state.enemyY[i], state.enemyZ[i], state.enemyYaw[i],
                state.enemyGait[i], eMove, state.enemyWindup[i] / 0.42f,
                false, false, eSlots, false, state.enemyHurt[i] > 0.0f, false
            )
        }

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, 0)
    }

    private fun drawConnected3DHumanoid(
        vp: FloatArray,
        wx: Float,
        wy: Float,
        wz: Float,
        yawRad: Float,
        gait: Float,
        moveAmt: Float,
        slashProg: Float,
        dodging: Boolean,
        jumping: Boolean,
        slotMetals: IntArray,
        mounted: Boolean,
        hurtFlash: Boolean,
        isPlayer: Boolean
    ) {
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uMaterialMode"), 3)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progMeshAscii, "uCellScale"), if (isPlayer) 6.6f else 7.6f)

        val s = if (isPlayer) 1.25f else 1.12f
        val yawDeg = Math.toDegrees(yawRad.toDouble()).toFloat()
        val sinY = sin(yawRad)
        val cosY = cos(yawRad)
        val rightX = cosY
        val rightZ = -sinY

        val breathe = sin(state.timeSec * 2.5f) * 0.02f
        val bounce = abs(sin(gait)) * 0.08f * moveAmt
        val crouch = if (dodging) 0.20f else 0.0f
        val mountH = if (mounted) 0.78f else 0.0f
        val baseH = wy + mountH - crouch

        // Ground contact shadow
        GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 0.015f, 0.022f, 0.020f)
        drawSpherePart(vp, wx + 0.18f * s, wy + 0.015f, wz + 0.12f * s, yawDeg, 0.74f * s, 0.03f, 0.58f * s)

        if (mounted) {
            GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 0.86f, 0.90f, 0.95f)
            drawSpherePart(vp, wx, wy + 0.68f + bounce, wz, yawDeg, 0.62f, 0.54f, 1.38f)
            drawSpherePart(vp, wx + sinY * 0.62f, wy + 1.08f + bounce, wz + cosY * 0.62f, yawDeg, 0.38f, 0.58f, 0.44f)
            for (leg in 0..3) {
                val lx = if (leg % 2 == 0) -0.24f else 0.24f
                val lz = if (leg < 2) 0.44f else -0.44f
                val sw = sin(gait + leg * 1.57f) * 0.26f * moveAmt
                drawSpherePart(
                    vp, wx + rightX * lx + sinY * (lz + sw), wy + 0.34f, wz + rightZ * lx + cosY * (lz + sw),
                    yawDeg, 0.18f, 0.68f, 0.18f
                )
            }
        }

        // 1. Overlapping Thigh + Shin + Boot (Slots 5=Legs, 6=Boots)
        for (leg in 0..1) {
            val side = (if (leg == 0) -0.15f else 0.15f) * s
            val ph = gait + (if (leg == 1) PI.toFloat() else 0.0f)
            val swing = if (jumping) (if (leg == 0) 0.18f else -0.14f) else (sin(ph) * 0.28f * moveAmt)
            val lift = if (jumping) 0.16f else (max(0.0f, cos(ph)) * 0.14f * moveAmt)

            setPartColor(slotMetals[5], hurtFlash)
            val tx = wx + rightX * side + sinY * (swing * 0.5f) * s
            val ty = baseH + (0.58f + lift * 0.4f) * s
            val tz = wz + rightZ * side + cosY * (swing * 0.5f) * s
            drawSpherePart(vp, tx, ty, tz, yawDeg, 0.22f * s, 0.46f * s, 0.24f * s)

            val sx = wx + rightX * side + sinY * (swing * 0.85f) * s
            val sy = baseH + (0.28f + lift * 0.8f) * s
            val sz = wz + rightZ * side + cosY * (swing * 0.85f) * s
            drawSpherePart(vp, sx, sy, sz, yawDeg, 0.19f * s, 0.42f * s, 0.20f * s)

            setPartColor(slotMetals[6], hurtFlash)
            drawSpherePart(
                vp, sx + sinY * 0.06f * s, baseH + (0.09f + lift) * s, sz + cosY * 0.06f * s,
                yawDeg, 0.20f * s, 0.18f * s, 0.28f * s
            )
        }

        // 2. Pelvis, Waist & Chest Cuirass (Slot 3=Chest)
        val pelvisY = baseH + (0.80f + bounce) * s
        val chestY = pelvisY + (0.34f + breathe) * s
        setPartColor(slotMetals[3], hurtFlash)
        drawSpherePart(vp, wx, pelvisY, wz, yawDeg, 0.40f * s, 0.32f * s, 0.30f * s)
        drawSpherePart(vp, wx, chestY, wz, yawDeg, 0.46f * s, 0.52f * s, 0.34f * s)

        // 3. Flowing Crimson / Dark Traveler Cloak on Back (`1000461483.jpg` & `1000461463.jpg`)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uMaterialMode"), 4)
        if (isPlayer) {
            GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 0.78f, 0.18f, 0.20f)
        } else {
            GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 0.34f, 0.38f, 0.44f)
        }
        val capeFlutter = sin(state.capeWavePhase) * 0.06f * (0.4f + moveAmt)
        drawSpherePart(
            vp,
            wx - sinY * (0.16f + moveAmt * 0.06f) * s + rightX * capeFlutter * s,
            chestY - 0.08f * s,
            wz - cosY * (0.16f + moveAmt * 0.06f) * s + rightZ * capeFlutter * s,
            yawDeg, 0.46f * s, 0.68f * s, 0.26f * s
        )
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uMaterialMode"), 3)

        // 4. Connected Pauldrons & Arms (Slot 2=Shoulders, Slot 4=Gloves)
        setPartColor(slotMetals[2], hurtFlash)
        val shSpan = 0.28f * s
        for (side in intArrayOf(-1, 1)) {
            drawSpherePart(
                vp, wx + rightX * (side * shSpan), chestY + 0.14f * s, wz + rightZ * (side * shSpan),
                yawDeg, 0.22f * s, 0.24f * s, 0.22f * s
            )
        }

        // Left Arm connected to Left Shoulder
        setPartColor(slotMetals[4], hurtFlash)
        val armSw = sin(gait) * 0.20f * moveAmt
        drawSpherePart(
            vp, wx - rightX * (shSpan + 0.04f * s) - sinY * armSw * s, chestY - 0.10f * s,
            wz - rightZ * (shSpan + 0.04f * s) - cosY * armSw * s, yawDeg, 0.17f * s, 0.44f * s, 0.18f * s
        )

        // Right Sword Arm connected to Right Shoulder + Extended Blade (Slot 0=Weapon)
        val slashAng = if (slashProg > 0.0f) (-1.35f + (1.0f - slashProg) * 2.7f) else (0.48f + armSw * 0.4f)
        val sDirX = sin(yawRad + slashAng)
        val sDirZ = cos(yawRad + slashAng)
        val rArmX = wx + rightX * (shSpan + 0.04f * s) + sDirX * 0.14f * s
        val rArmY = chestY - 0.08f * s
        val rArmZ = wz + rightZ * (shSpan + 0.04f * s) + sDirZ * 0.14f * s
        drawSpherePart(vp, rArmX, rArmY, rArmZ, yawDeg, 0.17f * s, 0.44f * s, 0.18f * s)

        // Gleaming Sword Blade extending from right hand (colored by Weapon Slot 0 metal!)
        setPartColor(slotMetals[0], false)
        val swordYawDeg = Math.toDegrees((yawRad + slashAng).toDouble()).toFloat()
        drawSpherePart(
            vp, rArmX + sDirX * 0.54f * s, rArmY - 0.10f * s, rArmZ + sDirZ * 0.54f * s,
            swordYawDeg, 0.09f * s, 0.09f * s, 0.96f * s
        )

        // 5. Connected Neck & Helmeted Head (Slot 1=Helm)
        setPartColor(slotMetals[1], hurtFlash)
        val headY = chestY + 0.38f * s
        drawSpherePart(vp, wx, headY, wz, yawDeg, 0.28f * s, 0.34f * s, 0.30f * s)

        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uMaterialMode"), 0)
    }

    private fun setPartColor(metalIdx: Int, hurtFlash: Boolean) {
        if (hurtFlash) {
            GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), 1.0f, 0.28f, 0.28f)
        } else {
            val rgb = GameState.METAL_RGB[metalIdx.coerceIn(0, 9)]
            GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uBaseColor"), rgb[0], rgb[1], rgb[2])
        }
    }

    private fun drawSpherePart(
        vp: FloatArray,
        x: Float,
        y: Float,
        z: Float,
        yawDeg: Float,
        sx: Float,
        sy: Float,
        sz: Float
    ) {
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, x, y, z)
        if (yawDeg != 0.0f) {
            Matrix.rotateM(modelMatrix, 0, yawDeg, 0f, 1f, 0f)
        }
        Matrix.scaleM(modelMatrix, 0, sx, sy, sz)
        Matrix.multiplyMM(mvpMatrix, 0, vp, 0, modelMatrix, 0)

        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(progMeshAscii, "uMVP"), 1, false, mvpMatrix, 0)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(progMeshAscii, "uModel"), 1, false, modelMatrix, 0)
        GLES30.glDrawElements(GLES30.GL_TRIANGLES, sphereIndexCount, GLES30.GL_UNSIGNED_SHORT, 0)
    }

    private fun drawInstanced3DGrass(vp: FloatArray) {
        GLES30.glUseProgram(progGrassInstanced)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, glyphAtlasTex)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progGrassInstanced, "uAtlas"), 0)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(progGrassInstanced, "uVP"), 1, false, vp, 0)
        GLES30.glUniform3f(
            GLES30.glGetUniformLocation(progGrassInstanced, "uPlayerPos"),
            state.playerX, state.groundY, state.playerZ
        )
        GLES30.glUniform3f(
            GLES30.glGetUniformLocation(progGrassInstanced, "uCamRight"),
            cos(state.camYaw), 0.0f, -sin(state.camYaw)
        )
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progGrassInstanced, "uTime"), state.timeSec)

        val phase = ((state.worldSeed and 0xFFFFL).toFloat() / 65535.0f) * 6.28318f
        val amp = if (state.worldType == 3) 3.4f else 2.2f
        val halfW = WorldGenerator.riverHalfWidth(state.worldType, state.genRivers)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progGrassInstanced, "uRiverPhase"), phase)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progGrassInstanced, "uRiverAmp"), amp)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progGrassInstanced, "uRiverHalfW"), halfW)

        GLES30.glDisableVertexAttribArray(2)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, grassRibbonVbo)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 4, GLES30.GL_FLOAT, false, 16, 0)
        GLES30.glVertexAttribDivisor(0, 0)

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, grassInstanceVbo)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 4, GLES30.GL_FLOAT, false, 16, 0)
        GLES30.glVertexAttribDivisor(1, 1)

        val count = when (state.qualityPreset) {
            0 -> 10000
            1 -> 20000
            else -> MAX_GRASS_INSTANCES
        }
        GLES30.glDrawArraysInstanced(GLES30.GL_TRIANGLES, 0, 6, count)

        GLES30.glVertexAttribDivisor(1, 0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
    }

    private fun render3DChainmailEquipmentScene() {
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        GLES30.glViewport(0, 0, width, height)
        GLES30.glClearColor(0.0f, 0.0f, 0.0f, 1.0f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

        val aspect = width / height.toFloat()
        Matrix.perspectiveM(projMatrix, 0, 38.0f / state.previewZoom, aspect, 0.5f, 30.0f)
        Matrix.setLookAtM(viewMatrix, 0, 0.65f, 0.35f, 4.2f, 0.45f, -0.15f, 0.0f, 0f, 1f, 0f)
        Matrix.multiplyMM(vpMatrix, 0, projMatrix, 0, viewMatrix, 0)

        GLES30.glUseProgram(progMeshAscii)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, glyphAtlasTex)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uAtlas"), 0)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(progMeshAscii, "uCamPos"), 0.65f, 0.35f, 4.2f)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progMeshAscii, "uCellScale"), 8.2f)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uDebugSolid"), if (state.debugSolidMode) 1 else 0)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progMeshAscii, "uTime"), state.timeSec)

        bindSphereVbo()

        if (state.previewFullHero) {
            drawConnected3DHumanoid(
                vpMatrix, -0.35f, -0.95f, 0.0f, state.previewYaw,
                state.timeSec * 2.0f, 0.35f, 0.0f,
                false, false, state.slotMetal, false, false, true
            )
        } else {
            // Iconic 3D Chainmail Coif & Mantle Preview (`1000461485.jpg` "Chainmail test")
            GLES30.glUniform1i(GLES30.glGetUniformLocation(progMeshAscii, "uMaterialMode"), 1)
            setPartColor(state.activeMetal, false)
            val yawDeg = Math.toDegrees(state.previewYaw.toDouble()).toFloat()

            drawSpherePart(vpMatrix, -0.35f, 0.30f, 0.0f, yawDeg, 0.96f, 1.08f, 0.96f)
            drawSpherePart(vpMatrix, -0.35f, -0.36f, 0.0f, yawDeg, 1.56f, 0.86f, 1.36f)
            drawSpherePart(vpMatrix, -0.35f, -0.68f, 0.0f, yawDeg, 1.98f, 0.46f, 1.68f)
        }

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, 0)
    }

    companion object {
        private const val REFLECT_W = 512
        private const val REFLECT_H = 512
        private const val MAX_GRASS_INSTANCES = 32000
    }
}
