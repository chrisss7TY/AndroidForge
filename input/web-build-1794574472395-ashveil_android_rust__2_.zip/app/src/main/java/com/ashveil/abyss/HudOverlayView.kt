package com.ashveil.abyss

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Minimalist Monospace HUD, Minecraft-Style World Creation Menu, 1..0 Skill Hotbar,
 * and 3D Chainmail & Rune Equipment Forge Overlay.
 */
class HudOverlayView(
    context: Context,
    private val state: GameState,
    private val prefs: SharedPreferences?
) : View(context) {

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    }
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.0f
    }

    private var movePointerId: Int = -1
    private var camPointerId: Int = -1
    private var joyBaseX: Float = 0f
    private var joyBaseY: Float = 0f
    private var joyCurrX: Float = 0f
    private var joyCurrY: Float = 0f
    private var lastCamX: Float = 0f

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width
        val h = height

        when (state.screenMode) {
            0 -> drawMinimalistMainMenu(canvas, w, h)
            2 -> drawEquipmentMenuOverlay(canvas, w, h)
            3 -> drawCreateWorldMenu(canvas, w, h)
            else -> drawWorldHudOverlay(canvas, w, h)
        }
        postInvalidateOnAnimation()
    }

    // =========================================================================
    // 1. MINIMALIST MONOSPACE MAIN & WORLD SELECTOR MENU (Screen Mode 0)
    // =========================================================================
    private fun drawMinimalistMainMenu(canvas: Canvas, w: Int, h: Int) {
        boxPaint.color = Color.argb(175, 4, 6, 8)
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), boxPaint)

        val panelW = min(w * 0.82f, 760f)
        val panelH = min(h * 0.88f, 440f)
        val px = (w - panelW) * 0.5f
        val py = (h - panelH) * 0.5f

        boxPaint.color = Color.argb(242, 8, 11, 13)
        canvas.drawRect(px, py, px + panelW, py + panelH, boxPaint)
        borderPaint.color = Color.rgb(155, 168, 164)
        canvas.drawRect(px, py, px + panelW, py + panelH, borderPaint)

        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 20f
        textPaint.color = Color.rgb(238, 245, 242)
        canvas.drawText("ASHVEIL // 3D ASCII MMORPG & WORLD ENGINE", px + 22f, py + 34f, textPaint)

        textPaint.textSize = 12f
        textPaint.color = Color.rgb(150, 165, 160)
        canvas.drawText(
            "Active World: ${state.worldName}  \u00b7  Seed: ${state.worldSeed}  \u00b7  ${WorldGenerator.WORLD_TYPE_NAMES[state.worldType]}",
            px + 22f, py + 54f, textPaint
        )

        // Top Action Bar: [ RESUME ACTIVE WORLD ]  &  [ + CREATE NEW WORLD (MINECRAFT GENERATOR) ]
        val btnY = py + 68f
        val btnH = 40f
        val halfW = (panelW - 56f) * 0.5f

        // Resume Button
        boxPaint.color = Color.rgb(20, 44, 32)
        canvas.drawRect(px + 22f, btnY, px + 22f + halfW, btnY + btnH, boxPaint)
        borderPaint.color = Color.rgb(145, 225, 175)
        canvas.drawRect(px + 22f, btnY, px + 22f + halfW, btnY + btnH, borderPaint)
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = 13.5f
        textPaint.color = Color.rgb(235, 248, 240)
        canvas.drawText("[ RESUME ACTIVE WORLD ]", px + 22f + halfW * 0.5f, btnY + 25f, textPaint)

        // Create New World Button
        val createX = px + 34f + halfW
        boxPaint.color = Color.rgb(28, 34, 48)
        canvas.drawRect(createX, btnY, createX + halfW, btnY + btnH, boxPaint)
        borderPaint.color = Color.rgb(165, 195, 245)
        canvas.drawRect(createX, btnY, createX + halfW, btnY + btnH, borderPaint)
        textPaint.color = Color.rgb(235, 242, 255)
        canvas.drawText("[ + CREATE NEW WORLD ]", createX + halfW * 0.5f, btnY + 25f, textPaint)

        // Saved Worlds List Header
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 12.5f
        textPaint.color = Color.rgb(175, 185, 182)
        canvas.drawText("SAVED PROCEDURAL WORLDS (Tap a world to load seed & chunks):", px + 22f, btnY + 64f, textPaint)

        val rowStartY = btnY + 76f
        val rowH = 44f
        for (i in 0 until state.savedWorldCount) {
            val wSlot = state.savedWorlds[i]
            val ry = rowStartY + i * (rowH + 6f)
            val isAct = (i == state.activeWorldIndex)

            boxPaint.color = if (isAct) Color.rgb(22, 32, 28) else Color.rgb(12, 15, 18)
            canvas.drawRect(px + 22f, ry, px + panelW - 110f, ry + rowH, boxPaint)
            borderPaint.color = if (isAct) Color.rgb(185, 225, 165) else Color.rgb(75, 84, 88)
            canvas.drawRect(px + 22f, ry, px + panelW - 110f, ry + rowH, borderPaint)

            textPaint.textAlign = Paint.Align.LEFT
            textPaint.textSize = 13.5f
            textPaint.color = Color.rgb(238, 242, 240)
            val tag = if (isAct) " [ACTIVE]" else ""
            canvas.drawText("${i + 1}. ${wSlot.name}$tag", px + 34f, ry + 18f, textPaint)

            textPaint.textSize = 11.5f
            textPaint.color = Color.rgb(155, 170, 166)
            val tName = WorldGenerator.WORLD_TYPE_NAMES[wSlot.worldType]
            val mName = WorldGenerator.GAME_MODE_NAMES[wSlot.gameMode]
            canvas.drawText(
                "Seed: ${wSlot.seed}  \u00b7  $tName ($mName)  \u00b7  LV ${wSlot.savedLevel}  \u00b7  ${wSlot.savedGold}g",
                px + 34f, ry + 35f, textPaint
            )

            // Delete World Button (if > 1 world)
            val delX = px + panelW - 102f
            boxPaint.color = Color.rgb(36, 16, 18)
            canvas.drawRect(delX, ry, px + panelW - 22f, ry + rowH, boxPaint)
            borderPaint.color = Color.rgb(145, 78, 82)
            canvas.drawRect(delX, ry, px + panelW - 22f, ry + rowH, borderPaint)
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.textSize = 12f
            textPaint.color = Color.rgb(235, 165, 165)
            canvas.drawText("[DELETE]", (delX + px + panelW - 22f) * 0.5f, ry + 26f, textPaint)
        }

        // Bottom Quality Preset Toggle
        val qY = py + panelH - 36f
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 12f
        textPaint.color = Color.rgb(165, 178, 174)
        val qLabel = when (state.qualityPreset) {
            0 -> "LOW (10,000 Grass Glyphs)"
            1 -> "MEDIUM (20,000 Grass Glyphs)"
            else -> "ULTRA (32,000 Instanced Grass Glyphs)"
        }
        canvas.drawText("[ TAP HERE TO CYCLE GRAPHICS QUALITY: $qLabel ]", px + 22f, qY + 16f, textPaint)
    }

    // =========================================================================
    // 2. MINECRAFT-STYLE CREATE NEW WORLD GENERATOR MENU (Screen Mode 3)
    // =========================================================================
    private fun drawCreateWorldMenu(canvas: Canvas, w: Int, h: Int) {
        boxPaint.color = Color.argb(185, 4, 6, 8)
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), boxPaint)

        val panelW = min(w * 0.84f, 780f)
        val panelH = min(h * 0.90f, 450f)
        val px = (w - panelW) * 0.5f
        val py = (h - panelH) * 0.5f

        boxPaint.color = Color.argb(245, 8, 11, 14)
        canvas.drawRect(px, py, px + panelW, py + panelH, boxPaint)
        borderPaint.color = Color.rgb(165, 195, 235)
        canvas.drawRect(px, py, px + panelW, py + panelH, borderPaint)

        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 19f
        textPaint.color = Color.rgb(238, 245, 252)
        canvas.drawText("CREATE NEW PROCEDURAL 3D ASCII WORLD", px + 22f, py + 34f, textPaint)

        val colW = (panelW - 56f) * 0.5f
        val leftX = px + 22f
        val rightX = px + 34f + colW

        // Row 1: World Name & Game Mode
        val r1Y = py + 52f
        val boxH = 44f
        drawOptionButton(
            canvas, leftX, r1Y, colW, boxH,
            "WORLD NAME (Tap to Cycle):",
            WorldGenerator.PRESET_WORLD_NAMES[state.newWorldNameIdx % WorldGenerator.PRESET_WORLD_NAMES.size]
        )
        drawOptionButton(
            canvas, rightX, r1Y, colW, boxH,
            "GAME MODE (Tap to Cycle):",
            WorldGenerator.GAME_MODE_NAMES[state.newGameMode]
        )

        // Row 2: World Seed & Randomize / Preset Seed
        val r2Y = r1Y + boxH + 12f
        drawOptionButton(
            canvas, leftX, r2Y, colW, boxH,
            "WORLD SEED (Tap for Random 64-bit Seed):",
            "${state.newWorldSeed}"
        )
        drawOptionButton(
            canvas, rightX, r2Y, colW, boxH,
            "WORLD TYPE / BIOME GENERATOR:",
            WorldGenerator.WORLD_TYPE_NAMES[state.newWorldType]
        )

        // Row 3: Seed Presets Bar
        val r3Y = r2Y + boxH + 12f
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 11.5f
        textPaint.color = Color.rgb(155, 170, 180)
        canvas.drawText("FAMOUS SEEDS (Tap to apply preset seed):", leftX, r3Y + 12f, textPaint)

        val presetW = (panelW - 44f) / 4.0f
        for (p in 0 until 4) {
            val bx = leftX + p * presetW
            val by = r3Y + 18f
            val sel = (state.newWorldSeed == WorldGenerator.PRESET_SEEDS[p])
            boxPaint.color = if (sel) Color.rgb(26, 42, 52) else Color.rgb(12, 16, 20)
            canvas.drawRect(bx, by, bx + presetW - 6f, by + 32f, boxPaint)
            borderPaint.color = if (sel) Color.rgb(155, 220, 245) else Color.rgb(72, 82, 90)
            canvas.drawRect(bx, by, bx + presetW - 6f, by + 32f, borderPaint)
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.textSize = 11f
            textPaint.color = Color.rgb(225, 235, 242)
            canvas.drawText(WorldGenerator.PRESET_SEED_LABELS[p], bx + (presetW - 6f) * 0.5f, by + 20f, textPaint)
        }

        // Row 4: Structure Generation Toggles (Moonlit Caves, Rivers, Shrines)
        val r4Y = r3Y + 62f
        val togW = (panelW - 44f) / 3.0f
        val toggles = arrayOf(
            "MOONLIT CAVES: ${if (state.newGenCaves) "ON" else "OFF"}",
            "WINDING RIVERS: ${if (state.newGenRivers) "ON" else "OFF"}",
            "RUNIC SHRINES: ${if (state.newGenShrines) "ON" else "OFF"}"
        )
        val togActive = booleanArrayOf(state.newGenCaves, state.newGenRivers, state.newGenShrines)
        for (t in 0 until 3) {
            val tx = leftX + t * togW
            boxPaint.color = if (togActive[t]) Color.rgb(20, 38, 30) else Color.rgb(24, 16, 18)
            canvas.drawRect(tx, r4Y, tx + togW - 8f, r4Y + 36f, boxPaint)
            borderPaint.color = if (togActive[t]) Color.rgb(135, 215, 165) else Color.rgb(125, 80, 80)
            canvas.drawRect(tx, r4Y, tx + togW - 8f, r4Y + 36f, borderPaint)
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.textSize = 12f
            textPaint.color = Color.rgb(235, 242, 238)
            canvas.drawText(toggles[t], tx + (togW - 8f) * 0.5f, r4Y + 23f, textPaint)
        }

        // Bottom Buttons: [ BACK TO MENU ]  &  [ GENERATE & LAUNCH 3D WORLD ]
        val botY = py + panelH - 54f
        boxPaint.color = Color.rgb(24, 28, 32)
        canvas.drawRect(leftX, botY, leftX + colW * 0.65f, botY + 42f, boxPaint)
        borderPaint.color = Color.rgb(135, 145, 150)
        canvas.drawRect(leftX, botY, leftX + colW * 0.65f, botY + 42f, borderPaint)
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = 13f
        textPaint.color = Color.rgb(225, 230, 232)
        canvas.drawText("[ < BACK ]", leftX + colW * 0.325f, botY + 26f, textPaint)

        val genX = leftX + colW * 0.72f
        val genW = panelW - 44f - colW * 0.72f
        boxPaint.color = Color.rgb(22, 52, 36)
        canvas.drawRect(genX, botY, genX + genW, botY + 42f, boxPaint)
        borderPaint.color = Color.rgb(155, 245, 185)
        canvas.drawRect(genX, botY, genX + genW, botY + 42f, borderPaint)
        textPaint.textSize = 14f
        textPaint.color = Color.rgb(240, 255, 245)
        canvas.drawText("[ GENERATE & LAUNCH 3D ASCII WORLD ]", genX + genW * 0.5f, botY + 26f, textPaint)
    }

    private fun drawOptionButton(
        canvas: Canvas,
        x: Float,
        y: Float,
        w: Float,
        h: Float,
        label: String,
        value: String
    ) {
        boxPaint.color = Color.rgb(14, 18, 22)
        canvas.drawRect(x, y, x + w, y + h, boxPaint)
        borderPaint.color = Color.rgb(95, 110, 120)
        canvas.drawRect(x, y, x + w, y + h, borderPaint)

        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 11f
        textPaint.color = Color.rgb(155, 170, 178)
        canvas.drawText(label, x + 12f, y + 16f, textPaint)

        textPaint.textSize = 14f
        textPaint.color = Color.rgb(238, 245, 248)
        canvas.drawText(value, x + 12f, y + 35f, textPaint)
    }

    // =========================================================================
    // 3. IN-GAME HUD OVERLAY (Screen Mode 1 - Faithful to Reference Screenshots!)
    // =========================================================================
    private fun drawWorldHudOverlay(canvas: Canvas, w: Int, h: Int) {
        // 1. Top-Left `Senje` Portrait & Status Box (`1000461482.jpg` & `1000461471.jpg`)
        val boxW = min(w * 0.38f, 430.0f)
        val boxH = min(h * 0.24f, 148.0f)
        val x0 = 16.0f
        val y0 = 16.0f

        boxPaint.color = Color.argb(235, 6, 8, 9)
        canvas.drawRect(x0, y0, x0 + boxW, y0 + boxH, boxPaint)
        borderPaint.color = Color.rgb(175, 182, 180)
        canvas.drawRect(x0, y0, x0 + boxW, y0 + boxH, borderPaint)

        val pSize = boxH * 0.11f
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = pSize
        textPaint.color = Color.rgb(205, 212, 210)
        for (r in SENJE_PORTRAIT.indices) {
            canvas.drawText(SENJE_PORTRAIT[r], x0 + 10f, y0 + 24f + r * (pSize * 1.05f), textPaint)
        }

        val tx = x0 + boxW * 0.24f
        val titleSize = boxH * 0.16f
        textPaint.textSize = titleSize
        textPaint.color = Color.rgb(242, 245, 244)
        canvas.drawText("${state.playerName}  [${state.worldName}]", tx, y0 + titleSize * 1.30f, textPaint)

        val barSize = boxH * 0.125f
        textPaint.textSize = barSize
        textPaint.color = Color.rgb(222, 228, 226)
        canvas.drawText("HP |||||||||||||||||||| ${state.hp}/${state.maxHp}", tx, y0 + titleSize * 2.45f, textPaint)
        canvas.drawText("MP |||||||||||||||||||| ${state.mp}/${state.maxMp}", tx, y0 + titleSize * 3.50f, textPaint)
        canvas.drawText(
            "LV ${state.level} \u00b7 ${state.gold}g \u00b7 ${state.currentBiomeName}",
            tx, y0 + titleSize * 4.60f, textPaint
        )

        // 2. Cursor-View Crosshair `+` & Player Nameplate in 3D World (`1000461482.jpg`)
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = 15.0f
        textPaint.color = Color.rgb(235, 240, 238)
        canvas.drawText(state.playerName, w * 0.5f, h * 0.41f, textPaint)

        if (state.cursorViewMode) {
            textPaint.textSize = 24.0f
            textPaint.color = Color.argb(220, 235, 242, 240)
            canvas.drawText("+", state.cursorX * w, state.cursorY * h, textPaint)
        }

        // 3. Top-Right Minimalist Monospace Controls: [MENU / WORLDS], [EQUIP / FORGE], [ZOOM], [STEED], [VIEW]
        val pillW = min(w * 0.17f, 164.0f)
        val pillH = 32.0f
        val px = w - pillW - 16.0f
        val modeLabel = if (state.debugSolidMode) "SOLID 3D" else "ASCII 3D"
        val pills = arrayOf(
            "[MENU / WORLDS]",
            "[EQUIP / FORGE]",
            "[ZOOM]",
            if (state.mounted) "[DISMOUNT]" else "[STEED]",
            "[VIEW: $modeLabel]"
        )
        textPaint.textSize = 12.5f
        for (i in pills.indices) {
            val py = y0 + i * (pillH + 5.0f)
            boxPaint.color = Color.argb(220, 8, 10, 11)
            canvas.drawRect(px, py, px + pillW, py + pillH, boxPaint)
            borderPaint.color = if (i == 0) Color.rgb(165, 210, 185) else Color.rgb(135, 145, 142)
            canvas.drawRect(px, py, px + pillW, py + pillH, borderPaint)
            textPaint.color = Color.rgb(235, 240, 238)
            canvas.drawText(pills[i], px + pillW * 0.5f, py + pillH * 0.66f, textPaint)
        }

        // 4. Bottom XP Bar + 1..0 Numbered Hotbar with Colored ASCII Skill Gems (`1000461463.jpg` & `1000461485.jpg`!)
        val hbW = min(w * 0.56f, 540.0f)
        val hbX = (w - hbW) * 0.5f
        val hbY = h - 48.0f

        boxPaint.color = Color.argb(230, 8, 10, 11)
        canvas.drawRect(hbX, hbY - 18.0f, hbX + hbW, hbY - 3.0f, boxPaint)
        borderPaint.color = Color.rgb(115, 125, 122)
        canvas.drawRect(hbX, hbY - 18.0f, hbX + hbW, hbY - 3.0f, borderPaint)

        val xpRatio = (state.xp / max(1, state.xpNext).toFloat()).coerceIn(0f, 1f)
        boxPaint.color = Color.rgb(205, 165, 78)
        canvas.drawRect(hbX + 2f, hbY - 16.0f, hbX + (hbW - 4f) * xpRatio, hbY - 5.0f, boxPaint)

        textPaint.textSize = 11.0f
        textPaint.color = Color.rgb(238, 242, 240)
        canvas.drawText("LV ${state.level} \u00b7 ${state.xp} / ${state.xpNext} XP", w * 0.5f, hbY - 6.5f, textPaint)

        val slotW = hbW / 10.0f
        for (s in 0 until 10) {
            val sx = hbX + s * slotW
            boxPaint.color = Color.argb(235, 6, 8, 9)
            canvas.drawRect(sx, hbY, sx + slotW, hbY + 38.0f, boxPaint)

            // Cooldown sweep overlay
            val cd = state.hotbarCooldowns[s]
            if (cd > 0.0f) {
                val frac = (cd / state.hotbarMaxCooldowns[s]).coerceIn(0f, 1f)
                boxPaint.color = Color.argb(140, 40, 55, 70)
                canvas.drawRect(sx + 1f, hbY + 38f * (1f - frac), sx + slotW - 1f, hbY + 38f, boxPaint)
            }

            borderPaint.color = Color.rgb(105, 115, 112)
            canvas.drawRect(sx, hbY, sx + slotW, hbY + 38.0f, borderPaint)
            textPaint.color = Color.rgb(210, 218, 215)
            canvas.drawText(((s + 1) % 10).toString(), sx + slotW * 0.5f, hbY + 12.5f, textPaint)

            // Colored ASCII Skill/Item Icons matching `1000461463.jpg`!
            when (s) {
                0 -> {
                    textPaint.color = Color.rgb(225, 95, 95)
                    canvas.drawText("{+}x${state.potions}", sx + slotW * 0.5f, hbY + 30.0f, textPaint)
                }
                1 -> {
                    textPaint.color = Color.rgb(135, 195, 245)
                    canvas.drawText("/@\\", sx + slotW * 0.5f, hbY + 30.0f, textPaint)
                }
                2 -> {
                    textPaint.color = Color.rgb(195, 145, 250)
                    canvas.drawText("(O)", sx + slotW * 0.5f, hbY + 30.0f, textPaint)
                }
                3 -> {
                    textPaint.color = Color.rgb(125, 235, 185)
                    canvas.drawText("[*]", sx + slotW * 0.5f, hbY + 30.0f, textPaint)
                }
                4 -> {
                    textPaint.color = Color.rgb(235, 195, 110)
                    canvas.drawText(">><", sx + slotW * 0.5f, hbY + 30.0f, textPaint)
                }
                else -> {
                    textPaint.color = Color.rgb(120, 130, 128)
                    canvas.drawText("\u00b7", sx + slotW * 0.5f, hbY + 28.0f, textPaint)
                }
            }
        }

        // 5. Bottom-Right Mobile Action Buttons: [ATK], [DODGE], [JUMP]
        val atkR = min(w, h) * 0.085f
        val atkCx = w - atkR - 24.0f
        val atkCy = h - atkR - 24.0f
        boxPaint.color = if (state.slashTimer > 0f) Color.argb(235, 48, 82, 62) else Color.argb(220, 8, 11, 10)
        borderPaint.color = Color.rgb(195, 208, 202)
        canvas.drawCircle(atkCx, atkCy, atkR, boxPaint)
        canvas.drawCircle(atkCx, atkCy, atkR, borderPaint)
        textPaint.textSize = 15.0f
        textPaint.color = Color.rgb(242, 246, 244)
        canvas.drawText("[ATK]", atkCx, atkCy + 5.0f, textPaint)

        val dodgeR = min(w, h) * 0.068f
        val dodgeCx = atkCx - atkR - dodgeR - 18.0f
        val dodgeCy = h - dodgeR - 24.0f
        boxPaint.color = if (state.dodgeTimer > 0f) Color.argb(235, 36, 82, 88) else Color.argb(220, 8, 11, 12)
        borderPaint.color = Color.rgb(165, 215, 210)
        canvas.drawCircle(dodgeCx, dodgeCy, dodgeR, boxPaint)
        canvas.drawCircle(dodgeCx, dodgeCy, dodgeR, borderPaint)
        textPaint.textSize = 13.0f
        val dTxt = if (state.dodgeCooldown > 0f) "${((state.dodgeCooldown * 10f + 0.9f).toInt() / 10f)}s" else "[DODGE]"
        canvas.drawText(dTxt, dodgeCx, dodgeCy + 4.5f, textPaint)

        val jumpR = min(w, h) * 0.062f
        val jumpCx = atkCx - jumpR * 0.35f
        val jumpCy = atkCy - atkR - jumpR - 14.0f
        boxPaint.color = if (state.playerY > state.groundY + 0.02f) Color.argb(235, 52, 78, 96) else Color.argb(220, 8, 11, 12)
        borderPaint.color = Color.rgb(185, 215, 235)
        canvas.drawCircle(jumpCx, jumpCy, jumpR, boxPaint)
        canvas.drawCircle(jumpCx, jumpCy, jumpR, borderPaint)
        textPaint.textSize = 12.5f
        canvas.drawText("[JUMP]", jumpCx, jumpCy + 4.5f, textPaint)

        // Virtual Joystick Ring
        if (movePointerId != -1) {
            borderPaint.color = Color.argb(145, 205, 225, 215)
            canvas.drawCircle(joyBaseX, joyBaseY, min(w, h) * 0.11f, borderPaint)
            canvas.drawCircle(joyCurrX, joyCurrY, min(w, h) * 0.035f, borderPaint)
        }

        if (state.bannerTimer > 0f) {
            textPaint.textSize = 13.5f
            textPaint.color = Color.rgb(235, 232, 195)
            canvas.drawText(state.statusBanner, w * 0.5f, hbY - 26.0f, textPaint)
        }
    }

    // =========================================================================
    // 4. 3D CHAINMAIL & RUNE EQUIPMENT FORGE (Screen Mode 2 - `1000461485.jpg`)
    // =========================================================================
    private fun drawEquipmentMenuOverlay(canvas: Canvas, w: Int, h: Int) {
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 14.0f
        textPaint.color = Color.rgb(225, 230, 228)
        canvas.drawText(
            "${GameState.METAL_SHORT[state.activeMetal]} Mail ${GameState.SLOT_NAMES[state.selectedSlot]}",
            18f, 24f, textPaint
        )

        // 7 Slot Tabs: Weapon, Helm, Shoulders, Chest, Gloves, Legs, Boots
        val slotW = (w * 0.72f) / 7.0f
        for (i in 0 until 7) {
            val sx = 18f + i * slotW
            boxPaint.color = if (i == state.selectedSlot) Color.rgb(32, 38, 28) else Color.rgb(10, 12, 14)
            canvas.drawRect(sx, 34f, sx + slotW - 5f, 64f, boxPaint)
            borderPaint.color = if (i == state.selectedSlot) Color.rgb(210, 205, 138) else Color.rgb(75, 82, 86)
            canvas.drawRect(sx, 34f, sx + slotW - 5f, 64f, borderPaint)
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.textSize = 12.5f
            textPaint.color = Color.rgb(235, 238, 236)
            canvas.drawText(GameState.SLOT_NAMES[i], sx + (slotW - 5f) * 0.5f, 54f, textPaint)
        }

        // Rune Row: ^ * z ~ > / x v ° § †
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 12.5f
        textPaint.color = Color.rgb(155, 165, 162)
        canvas.drawText("- drag into a slot (or click)", 18f, 82f, textPaint)
        val rW = (w * 0.66f) / 11.0f
        for (i in 0 until 11) {
            val rx = 18f + i * rW
            boxPaint.color = Color.rgb(8, 10, 12)
            canvas.drawRect(rx, 90f, rx + rW - 4f, 124f, boxPaint)
            borderPaint.color = Color.rgb(65, 72, 76)
            canvas.drawRect(rx, 90f, rx + rW - 4f, 124f, borderPaint)
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.textSize = 14f
            textPaint.color = when (i % 3) {
                0 -> Color.rgb(110, 225, 165)
                1 -> Color.rgb(215, 145, 235)
                else -> Color.rgb(225, 115, 115)
            }
            canvas.drawText(GameState.RUNE_GLYPHS[i], rx + (rW - 4f) * 0.5f, 112f, textPaint)
        }

        // 10 Metal Selector Buttons in 2 rows
        val mW = (w * 0.72f) / 5.0f
        for (i in 0 until 10) {
            val row = i / 5
            val col = i % 5
            val mx = 18f + col * mW
            val my = 136f + row * 34f
            boxPaint.color = if (i == state.activeMetal) Color.rgb(28, 34, 26) else Color.rgb(8, 10, 12)
            canvas.drawRect(mx, my, mx + mW - 6f, my + 28f, boxPaint)
            val rgb = GameState.METAL_RGB[i]
            val mCol = Color.rgb((rgb[0] * 255).toInt(), (rgb[1] * 255).toInt(), (rgb[2] * 255).toInt())
            borderPaint.color = if (i == state.activeMetal) mCol else Color.rgb(62, 68, 72)
            canvas.drawRect(mx, my, mx + mW - 6f, my + 28f, borderPaint)
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.textSize = 12f
            textPaint.color = mCol
            canvas.drawText(GameState.METAL_NAMES[i], mx + (mW - 6f) * 0.5f, my + 19f, textPaint)
        }

        // Right Divider & Enchant Slots Panel
        val divX = w * 0.75f
        borderPaint.color = Color.rgb(75, 82, 86)
        canvas.drawLine(divX, 34f, divX, h - 50f, borderPaint)

        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 13f
        textPaint.color = Color.rgb(185, 195, 192)
        canvas.drawText("Enchant slots", divX + 18f, 60f, textPaint)
        for (e in 0..1) {
            val ex = divX + 18f + e * 64f
            canvas.drawRect(ex, 72f, ex + 52f, 124f, borderPaint)
            val rIdx = if (e == 0) state.runeSlot1 else state.runeSlot2
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.color = if (rIdx >= 0) Color.rgb(145, 245, 205) else Color.rgb(115, 125, 122)
            canvas.drawText(if (rIdx >= 0) GameState.RUNE_GLYPHS[rIdx] else "+", ex + 26f, 104f, textPaint)
        }

        textPaint.textAlign = Paint.Align.LEFT
        textPaint.color = Color.rgb(175, 185, 182)
        canvas.drawText("Metal: ${GameState.METAL_SHORT[state.activeMetal]}", divX + 18f, 152f, textPaint)
        val rCount = (if (state.runeSlot1 >= 0) 1 else 0) + (if (state.runeSlot2 >= 0) 1 else 0)
        canvas.drawText("Runes: $rCount / 2", divX + 18f, 174f, textPaint)
        canvas.drawText(
            if (rCount == 0) "no enchantments" else "+${rCount * 22} Arcane Power",
            divX + 18f, 196f, textPaint
        )

        // Toggle 3D Coif vs Full Hero Preview Button
        val prevBtnY = h - 134f
        boxPaint.color = Color.rgb(16, 24, 32)
        canvas.drawRect(divX + 18f, prevBtnY, w - 18f, prevBtnY + 44f, boxPaint)
        borderPaint.color = Color.rgb(145, 185, 225)
        canvas.drawRect(divX + 18f, prevBtnY, w - 18f, prevBtnY + 44f, borderPaint)
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = 12f
        textPaint.color = Color.rgb(225, 238, 250)
        val pMode = if (state.previewFullHero) "FULL HERO" else "CHAINMAIL COIF"
        canvas.drawText("[ PREVIEW: $pMode ]", (divX + w) * 0.5f, prevBtnY + 27f, textPaint)

        // Return to 3D World Button
        boxPaint.color = Color.rgb(22, 42, 32)
        canvas.drawRect(divX + 18f, h - 76f, w - 18f, h - 24f, boxPaint)
        borderPaint.color = Color.rgb(165, 225, 185)
        canvas.drawRect(divX + 18f, h - 76f, w - 18f, h - 24f, borderPaint)
        textPaint.textSize = 13f
        textPaint.color = Color.rgb(238, 245, 240)
        canvas.drawText("[ RETURN TO WORLD ]", (divX + w) * 0.5f, h - 44f, textPaint)

        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 12f
        textPaint.color = Color.rgb(145, 155, 152)
        canvas.drawText("drag center to turn 3D ASCII preview \u00b7 tap metal or rune to forge", 18f, h - 18f, textPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val action = event.actionMasked
        val idx = event.actionIndex
        val pId = event.getPointerId(idx)
        val x = event.getX(idx)
        val y = event.getY(idx)
        val w = max(1f, width.toFloat())
        val h = max(1f, height.toFloat())

        // 1. Minimalist Main & World Selector Menu Touch Handling
        if (state.screenMode == 0) {
            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                val panelW = min(w * 0.82f, 760f)
                val panelH = min(h * 0.88f, 440f)
                val px = (w - panelW) * 0.5f
                val py = (h - panelH) * 0.5f
                val btnY = py + 68f
                val btnH = 40f
                val halfW = (panelW - 56f) * 0.5f

                // [ RESUME ACTIVE WORLD ]
                if (x >= px + 22f && x <= px + 22f + halfW && y >= btnY && y <= btnY + btnH) {
                    state.screenMode = 1
                    return true
                }
                // [ + CREATE NEW WORLD ]
                val createX = px + 34f + halfW
                if (x >= createX && x <= createX + halfW && y >= btnY && y <= btnY + btnH) {
                    state.newWorldNameIdx = (state.newWorldNameIdx + 1) % WorldGenerator.PRESET_WORLD_NAMES.size
                    state.newWorldSeed = WorldGenerator.splitMix64(System.nanoTime() xor state.worldSeed)
                    state.screenMode = 3
                    return true
                }

                // Saved Worlds List Rows
                val rowStartY = btnY + 76f
                val rowH = 44f
                for (i in 0 until state.savedWorldCount) {
                    val ry = rowStartY + i * (rowH + 6f)
                    if (y >= ry && y <= ry + rowH) {
                        val delX = px + panelW - 102f
                        if (x >= delX && x <= px + panelW - 22f) {
                            state.deleteWorldSlot(i, prefs)
                            return true
                        } else if (x >= px + 22f && x < delX) {
                            state.loadWorldSlot(i)
                            state.persistWorlds(prefs)
                            return true
                        }
                    }
                }

                // Bottom Graphics Quality Toggle
                if (y >= py + panelH - 44f && y <= py + panelH) {
                    state.qualityPreset = (state.qualityPreset + 1) % 3
                    return true
                }
            }
            return true
        }

        // 2. Minecraft-Style Create New World Menu Touch Handling
        if (state.screenMode == 3) {
            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                val panelW = min(w * 0.84f, 780f)
                val panelH = min(h * 0.90f, 450f)
                val px = (w - panelW) * 0.5f
                val py = (h - panelH) * 0.5f
                val colW = (panelW - 56f) * 0.5f
                val leftX = px + 22f
                val rightX = px + 34f + colW
                val r1Y = py + 52f
                val boxH = 44f
                val r2Y = r1Y + boxH + 12f
                val r3Y = r2Y + boxH + 12f
                val r4Y = r3Y + 62f

                // Cycle World Name
                if (x >= leftX && x <= leftX + colW && y >= r1Y && y <= r1Y + boxH) {
                    state.newWorldNameIdx = (state.newWorldNameIdx + 1) % WorldGenerator.PRESET_WORLD_NAMES.size
                    return true
                }
                // Cycle Game Mode
                if (x >= rightX && x <= rightX + colW && y >= r1Y && y <= r1Y + boxH) {
                    state.newGameMode = (state.newGameMode + 1) % WorldGenerator.GAME_MODE_NAMES.size
                    return true
                }
                // Randomize 64-bit Seed
                if (x >= leftX && x <= leftX + colW && y >= r2Y && y <= r2Y + boxH) {
                    state.newWorldSeed = WorldGenerator.splitMix64(System.nanoTime() + state.newWorldSeed)
                    return true
                }
                // Cycle World Type / Biome Preset
                if (x >= rightX && x <= rightX + colW && y >= r2Y && y <= r2Y + boxH) {
                    state.newWorldType = (state.newWorldType + 1) % WorldGenerator.WORLD_TYPE_NAMES.size
                    return true
                }
                // Famous Seed Presets
                if (y >= r3Y + 18f && y <= r3Y + 50f && x >= leftX && x <= leftX + panelW - 44f) {
                    val presetW = (panelW - 44f) / 4.0f
                    val p = ((x - leftX) / presetW).toInt().coerceIn(0, 3)
                    state.newWorldSeed = WorldGenerator.PRESET_SEEDS[p]
                    return true
                }
                // Structure Toggles (Caves, Rivers, Shrines)
                if (y >= r4Y && y <= r4Y + 36f && x >= leftX && x <= leftX + panelW - 44f) {
                    val togW = (panelW - 44f) / 3.0f
                    when (((x - leftX) / togW).toInt().coerceIn(0, 2)) {
                        0 -> state.newGenCaves = !state.newGenCaves
                        1 -> state.newGenRivers = !state.newGenRivers
                        2 -> state.newGenShrines = !state.newGenShrines
                    }
                    return true
                }
                // Bottom Back & Generate Buttons
                val botY = py + panelH - 54f
                if (y >= botY && y <= botY + 42f) {
                    if (x >= leftX && x <= leftX + colW * 0.65f) {
                        state.screenMode = 0
                        return true
                    }
                    val genX = leftX + colW * 0.72f
                    if (x >= genX && x <= px + panelW - 22f) {
                        state.createAndLaunchNewWorld(prefs)
                        return true
                    }
                }
            }
            return true
        }

        // 3. Equipment & Chainmail Forge Touch Handling
        if (state.screenMode == 2) {
            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                val divX = w * 0.75f
                if (x > divX && y > h - 84f) {
                    state.persistWorlds(prefs)
                    state.screenMode = 1
                    return true
                }
                if (x > divX && y >= h - 140f && y <= h - 88f) {
                    state.previewFullHero = !state.previewFullHero
                    return true
                }
                if (y in 34f..64f && x < w * 0.73f) {
                    val s = ((x - 18f) / ((w * 0.72f) / 7.0f)).toInt()
                    if (s in 0..6) {
                        state.selectedSlot = s
                        state.activeMetal = state.slotMetal[s]
                    }
                    return true
                }
                if (y in 90f..124f && x < w * 0.68f) {
                    val r = ((x - 18f) / ((w * 0.66f) / 11.0f)).toInt()
                    if (r in 0..10) {
                        if (state.runeSlot1 == -1) state.runeSlot1 = r
                        else if (state.runeSlot2 == -1) state.runeSlot2 = r
                        else {
                            state.runeSlot1 = r
                            state.runeSlot2 = -1
                        }
                        state.str += 2
                    }
                    return true
                }
                if (y in 136f..204f && x < w * 0.73f) {
                    val col = ((x - 18f) / ((w * 0.72f) / 5.0f)).toInt().coerceIn(0, 4)
                    val row = if (y >= 170f) 1 else 0
                    val m = row * 5 + col
                    state.activeMetal = m
                    state.slotMetal[state.selectedSlot] = m
                    return true
                }
                lastCamX = x
            } else if (action == MotionEvent.ACTION_MOVE) {
                state.previewYaw += (x - lastCamX) * 0.01f
                lastCamX = x
            }
            return true
        }

        // 4. Active 3D World Mode Controls
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            val pillW = min(w * 0.17f, 164.0f)
            val pillH = 32.0f
            val px = w - pillW - 16.0f
            val y0 = 16.0f

            if (x in px..(px + pillW) && y <= y0 + 5 * (pillH + 5f)) {
                when (((y - y0) / (pillH + 5f)).toInt()) {
                    0 -> {
                        movePointerId = -1
                        state.inputX = 0f
                        state.inputZ = 0f
                        state.saveCurrentWorldToActiveSlot()
                        state.screenMode = 0
                    }
                    1 -> {
                        movePointerId = -1
                        state.inputX = 0f
                        state.inputZ = 0f
                        state.screenMode = 2
                    }
                    2 -> {
                        state.zoomPreset = (state.zoomPreset + 1) % 3
                        state.cameraZoom = when (state.zoomPreset) {
                            0 -> 1.35f
                            1 -> 1.0f
                            else -> 0.75f
                        }
                    }
                    3 -> state.mounted = !state.mounted
                    4 -> {
                        state.debugSolidMode = !state.debugSolidMode
                        state.statusBanner = if (state.debugSolidMode) {
                            "Visual Debug Mode: Solid 3D Geometry"
                        } else {
                            "Visual Mode: Real-Time 3D ASCII"
                        }
                        state.bannerTimer = 2.5f
                    }
                }
                return true
            }

            // Tap Senje Portrait Box -> Open 3D Equipment & Chainmail Forge
            if (x < w * 0.38f && y < h * 0.24f) {
                movePointerId = -1
                state.inputX = 0f
                state.inputZ = 0f
                state.screenMode = 2
                return true
            }

            // Bottom Hotbar Slots 1..0
            val hbW = min(w * 0.56f, 540.0f)
            val hbX = (w - hbW) * 0.5f
            val hbY = h - 48.0f
            if (y >= hbY && x in hbX..(hbX + hbW)) {
                val s = ((x - hbX) / (hbW / 10.0f)).toInt().coerceIn(0, 9)
                state.triggerHotbarSlot(s)
                return true
            }

            // Bottom-Right [ATK], [DODGE], [JUMP]
            val atkR = min(w, h) * 0.085f
            val atkCx = w - atkR - 24.0f
            val atkCy = h - atkR - 24.0f
            if ((x - atkCx) * (x - atkCx) + (y - atkCy) * (y - atkCy) <= (atkR * 1.25f) * (atkR * 1.25f)) {
                state.triggerSlash()
                return true
            }

            val dodgeR = min(w, h) * 0.068f
            val dodgeCx = atkCx - atkR - dodgeR - 18.0f
            val dodgeCy = h - dodgeR - 24.0f
            if ((x - dodgeCx) * (x - dodgeCx) + (y - dodgeCy) * (y - dodgeCy) <= (dodgeR * 1.25f) * (dodgeR * 1.25f)) {
                state.triggerDodge()
                return true
            }

            val jumpR = min(w, h) * 0.062f
            val jumpCx = atkCx - jumpR * 0.35f
            val jumpCy = atkCy - atkR - jumpR - 14.0f
            if ((x - jumpCx) * (x - jumpCx) + (y - jumpCy) * (y - jumpCy) <= (jumpR * 1.25f) * (jumpR * 1.25f)) {
                state.triggerJump()
                return true
            }

            // Left Half -> Virtual Movement Joystick; Right Half -> Cursor-View & Camera Orbit
            if (x < w * 0.48f) {
                movePointerId = pId
                joyBaseX = x
                joyCurrX = x
                joyBaseY = y
                joyCurrY = y
                state.inputX = 0f
                state.inputZ = 0f
            } else {
                camPointerId = pId
                lastCamX = x
                state.cursorX = x / w
                state.cursorY = y / h
            }
        } else if (action == MotionEvent.ACTION_MOVE) {
            val count = event.pointerCount
            for (i in 0 until count) {
                val id = event.getPointerId(i)
                val px = event.getX(i)
                val py = event.getY(i)
                if (id == movePointerId) {
                    joyCurrX = px
                    joyCurrY = py
                    val dx = px - joyBaseX
                    val dy = py - joyBaseY
                    val maxR = min(w, h) * 0.12f
                    val len = sqrt(dx * dx + dy * dy)
                    if (len > 4f) {
                        val mag = min(1f, len / maxR)
                        state.inputX = (dx / len) * mag
                        state.inputZ = (dy / len) * mag
                    } else {
                        state.inputX = 0f
                        state.inputZ = 0f
                    }
                } else if (id == camPointerId) {
                    state.camYaw -= (px - lastCamX) * 0.0045f
                    lastCamX = px
                    state.cursorX = px / w
                    state.cursorY = py / h
                }
            }
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP || action == MotionEvent.ACTION_CANCEL) {
            if (pId == movePointerId) {
                movePointerId = -1
                state.inputX = 0f
                state.inputZ = 0f
            } else if (pId == camPointerId) {
                camPointerId = -1
            }
        }
        return true
    }

    companion object {
        private val SENJE_PORTRAIT = arrayOf(
            "  .---.  ",
            "  |===|  ",
            " .|===|. ",
            " ||===|| ",
            " ||===|| ",
            "  || ||  ",
            "  || ||  "
        )
    }
}
