package com.ashveil.abyss

import android.content.SharedPreferences
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Shared real-time 3D RPG, Equipment, Skill, World Management & Multiplayer-ready State.
 */
class GameState {

    // Screen Modes:
    // 0 = Minimalist Monospace World & Main Menu (over live 3D ASCII background)
    // 1 = Active Playable 3D ASCII World
    // 2 = 3D Chainmail & Rune Equipment Forge (`1000461485.jpg`)
    // 3 = Minecraft-Style Create New World Screen
    @Volatile var screenMode: Int = 1

    // Saved Worlds Management (Up to 5 persistent worlds)
    class SavedWorldSlot(
        var name: String = "Ashveil Wilds",
        var seed: Long = -4918273645L,
        var worldType: Int = 0,
        var gameMode: Int = 0,
        var genCaves: Boolean = true,
        var genRivers: Boolean = true,
        var genShrines: Boolean = true,
        var savedX: Float = 0.0f,
        var savedZ: Float = 4.0f,
        var savedLevel: Int = 13,
        var savedXp: Int = 1943,
        var savedGold: Int = 5194
    )

    val savedWorlds = Array(5) { idx ->
        when (idx) {
            0 -> SavedWorldSlot("Senje's Realm", -4918273645L, 0, 0, true, true, true, 0f, 4f, 13, 1943, 5194)
            1 -> SavedWorldSlot("Moonlit Crags", -9012847561L, 1, 0, true, true, true, 0f, 4f, 15, 3420, 7840)
            2 -> SavedWorldSlot("Elderwood Basin", 77283910421L, 2, 2, true, true, true, 0f, 4f, 19, 4120, 12450)
            else -> SavedWorldSlot("Empty World Slot", 0L, 0, 0, true, true, true, 0f, 4f, 1, 0, 100)
        }
    }
    @Volatile var savedWorldCount: Int = 3
    @Volatile var activeWorldIndex: Int = 0

    // Active World Parameters
    @Volatile var worldName: String = "Senje's Realm"
    @Volatile var worldSeed: Long = -4918273645L
    @Volatile var worldType: Int = 0
    @Volatile var gameMode: Int = 0
    @Volatile var genCaves: Boolean = true
    @Volatile var genRivers: Boolean = true
    @Volatile var genShrines: Boolean = true
    @Volatile var currentBiomeName: String = "Emerald Meadow"

    // New World Creation Builder State (for Screen Mode 3)
    @Volatile var newWorldNameIdx: Int = 0
    @Volatile var newWorldSeed: Long = 8492017492L
    @Volatile var newWorldType: Int = 0
    @Volatile var newGameMode: Int = 0
    @Volatile var newGenCaves: Boolean = true
    @Volatile var newGenRivers: Boolean = true
    @Volatile var newGenShrines: Boolean = true

    // Visual & Camera Controls
    @Volatile var mounted: Boolean = false
    @Volatile var cursorViewMode: Boolean = true
    @Volatile var debugSolidMode: Boolean = false
    @Volatile var qualityPreset: Int = 2 // 0=Low (10k grass), 1=Med (20k), 2=Ultra (32k instanced grass)
    @Volatile var zoomPreset: Int = 1
    @Volatile var cameraZoom: Float = 1.0f
    @Volatile var camYaw: Float = 0.0f

    // Player 3D Transform & Physics
    @Volatile var playerX: Float = 0.0f
    @Volatile var playerY: Float = 0.0f
    @Volatile var playerZ: Float = 4.0f
    @Volatile var groundY: Float = 0.0f
    @Volatile var velX: Float = 0.0f
    @Volatile var velY: Float = 0.0f
    @Volatile var velZ: Float = 0.0f
    @Volatile var facingX: Float = 0.0f
    @Volatile var facingZ: Float = -1.0f
    @Volatile var bodyYaw: Float = PI.toFloat()
    @Volatile var turnVel: Float = 0.0f
    @Volatile var gaitPhase: Float = 0.0f
    @Volatile var capeWavePhase: Float = 0.0f
    @Volatile var timeSec: Float = 0.0f
    @Volatile var slashTimer: Float = 0.0f
    @Volatile var slashCooldown: Float = 0.0f
    @Volatile var dodgeTimer: Float = 0.0f
    @Volatile var dodgeCooldown: Float = 0.0f
    @Volatile var dodgeDirX: Float = 0.0f
    @Volatile var dodgeDirZ: Float = -1.0f
    @Volatile var hurtFlash: Float = 0.0f

    // Active 3D Astral Vortex Skill Ring on the Ground (matches `1000461463.jpg` "New skills"!)
    @Volatile var vortexActiveTimer: Float = 3.5f // Active near start so player sees the skill ring right away!
    @Volatile var vortexX: Float = -1.35f
    @Volatile var vortexY: Float = 0.02f
    @Volatile var vortexZ: Float = 3.65f
    @Volatile var vortexTickTimer: Float = 0.0f
    @Volatile var wardBuffTimer: Float = 0.0f

    // Hotbar Cooldowns (10 slots)
    val hotbarCooldowns = FloatArray(10)
    val hotbarMaxCooldowns = floatArrayOf(1.5f, 2.8f, 5.0f, 8.0f, 4.5f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f)

    // Cursor View offset (normalized screen coords)
    @Volatile var cursorX: Float = 0.56f
    @Volatile var cursorY: Float = 0.46f
    @Volatile var inputX: Float = 0.0f
    @Volatile var inputZ: Float = 0.0f

    // RPG Progression & Stats (Matches `Senje` screenshot: HP 1612/1612, MP 134/134, LV 13, 5194g)
    @Volatile var playerName: String = "Senje"
    @Volatile var level: Int = 13
    @Volatile var xp: Int = 1943
    @Volatile var xpNext: Int = 6995
    @Volatile var hp: Int = 1612
    @Volatile var maxHp: Int = 1612
    @Volatile var mp: Int = 134
    @Volatile var maxMp: Int = 134
    @Volatile var gold: Int = 5194
    @Volatile var statPoints: Int = 3
    @Volatile var vit: Int = 18
    @Volatile var str: Int = 22
    @Volatile var dex: Int = 16
    @Volatile var potions: Int = 5
    @Volatile var cinderShards: Int = 4

    // Quest System
    @Volatile var questKills: Int = 0
    @Volatile var questTarget: Int = 5
    @Volatile var questCompleted: Boolean = false

    // 7-Slot Equipment & 10-Material System (Weapon, Helm, Shoulders, Chest, Gloves, Legs, Boots)
    @Volatile var selectedSlot: Int = 1 // Default highlighted tab: Helm (`1000461485.jpg`)
    val slotMetal = intArrayOf(1, 0, 1, 1, 0, 1, 0) // Weapon=Steel, Helm=Iron, etc.
    @Volatile var activeMetal: Int = 0 // 0=Iron..9=Emberstone
    @Volatile var runeSlot1: Int = -1
    @Volatile var runeSlot2: Int = -1
    @Volatile var previewYaw: Float = 0.4f
    @Volatile var previewZoom: Float = 1.0f
    @Volatile var previewFullHero: Boolean = false // Toggle between 3D Chainmail Coif & Full 3D Character in Forge

    // 3D Enemies (Seeded around active world chunks; guard post until player approaches within 7.5m)
    val enemyX = FloatArray(NUM_ENEMIES)
    val enemyY = FloatArray(NUM_ENEMIES)
    val enemyZ = FloatArray(NUM_ENEMIES)
    val enemyHomeX = FloatArray(NUM_ENEMIES)
    val enemyHomeZ = FloatArray(NUM_ENEMIES)
    val enemyYaw = FloatArray(NUM_ENEMIES)
    val enemyGait = FloatArray(NUM_ENEMIES)
    val enemyWindup = FloatArray(NUM_ENEMIES)
    val enemyCooldown = FloatArray(NUM_ENEMIES)
    val enemyHurt = FloatArray(NUM_ENEMIES)
    val enemyHp = IntArray(NUM_ENEMIES)
    val enemyMaxHp = IntArray(NUM_ENEMIES)
    val enemyMetal = IntArray(NUM_ENEMIES)
    val enemyAggro = BooleanArray(NUM_ENEMIES)

    // 3D Loot Drops
    val lootX = FloatArray(MAX_LOOT)
    val lootY = FloatArray(MAX_LOOT)
    val lootZ = FloatArray(MAX_LOOT)
    val lootMetal = IntArray(MAX_LOOT)
    val lootActive = BooleanArray(MAX_LOOT)

    // Status Banner
    @Volatile var statusBanner: String = "World: Senje's Realm • Seed: -4918273645 • Tap [MENU] for Worlds"
    @Volatile var bannerTimer: Float = 4.5f

    // Server-Authoritative Multiplayer Sync Queue (Ready for WebSocket/UDP Packet Relay)
    class NetEntityPacket {
        var entityId: Long = 0L
        var x: Float = 0f
        var y: Float = 0f
        var z: Float = 0f
        var yaw: Float = 0f
        var animState: Int = 0
        var hp: Int = 100
        var maxHp: Int = 100
    }
    val netPeers = Array(8) { NetEntityPacket() }
    @Volatile var connectedPeers: Int = 0

    init {
        WorldGenerator.ensureChunksAroundPlayer(
            playerX, playerZ, worldSeed, worldType, genCaves, genRivers, genShrines
        )
        for (i in 0 until NUM_ENEMIES) {
            spawnEnemy(i, i < 3)
        }
    }

    fun loadWorldSlot(slotIdx: Int) {
        if (slotIdx < 0 || slotIdx >= savedWorldCount) return
        saveCurrentWorldToActiveSlot()

        activeWorldIndex = slotIdx
        val w = savedWorlds[slotIdx]
        worldName = w.name
        worldSeed = w.seed
        worldType = w.worldType
        gameMode = w.gameMode
        genCaves = w.genCaves
        genRivers = w.genRivers
        genShrines = w.genShrines
        playerX = w.savedX
        playerZ = w.savedZ
        level = w.savedLevel
        xp = w.savedXp
        gold = w.savedGold
        if (gameMode == 2) {
            // Creative Sandbox mode grants extra gold & potions
            gold = max(gold, 99999)
            potions = 99
        }

        WorldGenerator.forceRebuildAllChunks()
        WorldGenerator.ensureChunksAroundPlayer(
            playerX, playerZ, worldSeed, worldType, genCaves, genRivers, genShrines
        )
        groundY = WorldGenerator.getTerrainHeight(playerX, playerZ, worldSeed, worldType, genRivers)
        playerY = groundY
        velX = 0f
        velY = 0f
        velZ = 0f
        for (l in 0 until MAX_LOOT) lootActive[l] = false
        for (i in 0 until NUM_ENEMIES) spawnEnemy(i, i < 3)

        vortexX = playerX - 1.35f
        vortexZ = playerZ - 0.35f
        vortexY = groundY + 0.02f
        vortexActiveTimer = 3.0f

        statusBanner = "Loaded '$worldName' (Seed: $worldSeed • ${WorldGenerator.WORLD_TYPE_NAMES[worldType]})"
        bannerTimer = 4.0f
        screenMode = 1
    }

    fun createAndLaunchNewWorld(prefs: SharedPreferences?) {
        saveCurrentWorldToActiveSlot()

        val name = WorldGenerator.PRESET_WORLD_NAMES[newWorldNameIdx % WorldGenerator.PRESET_WORLD_NAMES.size]
        val targetSlot = if (savedWorldCount < savedWorlds.size) {
            savedWorldCount++
            savedWorldCount - 1
        } else {
            savedWorlds.size - 1
        }

        val w = savedWorlds[targetSlot]
        w.name = name
        w.seed = newWorldSeed
        w.worldType = newWorldType
        w.gameMode = newGameMode
        w.genCaves = newGenCaves
        w.genRivers = newGenRivers
        w.genShrines = newGenShrines
        w.savedX = 0.0f
        w.savedZ = 4.0f
        w.savedLevel = level
        w.savedXp = xp
        w.savedGold = if (newGameMode == 2) 99999 else gold

        loadWorldSlot(targetSlot)
        persistWorlds(prefs)
    }

    fun deleteWorldSlot(slotIdx: Int, prefs: SharedPreferences?) {
        if (savedWorldCount <= 1 || slotIdx < 0 || slotIdx >= savedWorldCount) return
        for (i in slotIdx until savedWorldCount - 1) {
            val dst = savedWorlds[i]
            val src = savedWorlds[i + 1]
            dst.name = src.name
            dst.seed = src.seed
            dst.worldType = src.worldType
            dst.gameMode = src.gameMode
            dst.genCaves = src.genCaves
            dst.genRivers = src.genRivers
            dst.genShrines = src.genShrines
            dst.savedX = src.savedX
            dst.savedZ = src.savedZ
            dst.savedLevel = src.savedLevel
            dst.savedXp = src.savedXp
            dst.savedGold = src.savedGold
        }
        savedWorldCount--
        if (activeWorldIndex >= savedWorldCount) {
            activeWorldIndex = savedWorldCount - 1
        }
        loadWorldSlot(activeWorldIndex)
        screenMode = 0
        persistWorlds(prefs)
    }

    fun saveCurrentWorldToActiveSlot() {
        if (activeWorldIndex in 0 until savedWorldCount) {
            val w = savedWorlds[activeWorldIndex]
            w.name = worldName
            w.seed = worldSeed
            w.worldType = worldType
            w.gameMode = gameMode
            w.genCaves = genCaves
            w.genRivers = genRivers
            w.genShrines = genShrines
            w.savedX = playerX
            w.savedZ = playerZ
            w.savedLevel = level
            w.savedXp = xp
            w.savedGold = gold
        }
    }

    fun persistWorlds(prefs: SharedPreferences?) {
        if (prefs == null) return
        saveCurrentWorldToActiveSlot()
        val ed = prefs.edit()
        ed.putInt("world_count", savedWorldCount)
        ed.putInt("active_idx", activeWorldIndex)
        for (i in 0 until savedWorldCount) {
            val w = savedWorlds[i]
            ed.putString("w_${i}_name", w.name)
            ed.putLong("w_${i}_seed", w.seed)
            ed.putInt("w_${i}_type", w.worldType)
            ed.putInt("w_${i}_mode", w.gameMode)
            ed.putBoolean("w_${i}_caves", w.genCaves)
            ed.putBoolean("w_${i}_rivers", w.genRivers)
            ed.putBoolean("w_${i}_shrines", w.genShrines)
            ed.putFloat("w_${i}_x", w.savedX)
            ed.putFloat("w_${i}_z", w.savedZ)
            ed.putInt("w_${i}_lv", w.savedLevel)
            ed.putInt("w_${i}_xp", w.savedXp)
            ed.putInt("w_${i}_gold", w.savedGold)
        }
        for (s in slotMetal.indices) {
            ed.putInt("slot_metal_$s", slotMetal[s])
        }
        ed.putInt("rune_1", runeSlot1)
        ed.putInt("rune_2", runeSlot2)
        ed.apply()
    }

    fun loadPersistedWorlds(prefs: SharedPreferences?) {
        if (prefs == null || !prefs.contains("world_count")) return
        val count = prefs.getInt("world_count", 3).coerceIn(1, savedWorlds.size)
        savedWorldCount = count
        for (i in 0 until count) {
            val w = savedWorlds[i]
            w.name = prefs.getString("w_${i}_name", w.name) ?: w.name
            w.seed = prefs.getLong("w_${i}_seed", w.seed)
            w.worldType = prefs.getInt("w_${i}_type", w.worldType).coerceIn(0, 3)
            w.gameMode = prefs.getInt("w_${i}_mode", w.gameMode).coerceIn(0, 2)
            w.genCaves = prefs.getBoolean("w_${i}_caves", true)
            w.genRivers = prefs.getBoolean("w_${i}_rivers", true)
            w.genShrines = prefs.getBoolean("w_${i}_shrines", true)
            w.savedX = prefs.getFloat("w_${i}_x", 0.0f)
            w.savedZ = prefs.getFloat("w_${i}_z", 4.0f)
            w.savedLevel = prefs.getInt("w_${i}_lv", 13)
            w.savedXp = prefs.getInt("w_${i}_xp", 1943)
            w.savedGold = prefs.getInt("w_${i}_gold", 5194)
        }
        for (s in slotMetal.indices) {
            slotMetal[s] = prefs.getInt("slot_metal_$s", slotMetal[s]).coerceIn(0, 9)
        }
        runeSlot1 = prefs.getInt("rune_1", -1)
        runeSlot2 = prefs.getInt("rune_2", -1)
        val act = prefs.getInt("active_idx", 0).coerceIn(0, count - 1)
        loadWorldSlot(act)
    }

    fun spawnEnemy(i: Int, near: Boolean) {
        val h = WorldGenerator.hashCoords(i, level, worldSeed, 0xE4E31L)
        val ang = i * 0.95f + 0.6f + WorldGenerator.randFloat01(h) * 0.4f
        val dist = if (near) (6.5f + i * 2.2f) else (10.5f + (i % 5) * 3.8f)
        var ex = playerX + cos(ang) * dist
        var ez = playerZ + sin(ang) * dist
        if (WorldGenerator.isBlockedByWorld(ex, ez) || WorldGenerator.isInsideRiver(ex, ez, worldSeed, worldType, genRivers)) {
            ex = playerX + 5.5f + (i % 3) * 2.2f
            ez = playerZ + 5.5f + (i / 3) * 2.2f
        }
        enemyX[i] = ex
        enemyHomeX[i] = ex
        enemyZ[i] = ez
        enemyHomeZ[i] = ez
        enemyY[i] = WorldGenerator.getTerrainHeight(ex, ez, worldSeed, worldType, genRivers)
        enemyYaw[i] = PI.toFloat()
        enemyGait[i] = i * 0.8f
        enemyWindup[i] = 0.0f
        enemyCooldown[i] = 0.5f
        enemyHurt[i] = 0.0f
        enemyMaxHp[i] = 120 + level * 16 + (i % 3) * 40
        enemyHp[i] = enemyMaxHp[i]
        enemyMetal[i] = (i + 1 + abs((h and 7L).toInt())) % METAL_RGB.size
        enemyAggro[i] = false
    }

    fun triggerSlash(aoeMultiplier: Float = 1.0f) {
        if (slashCooldown > 0.0f && aoeMultiplier <= 1.0f) return
        slashTimer = 0.28f
        slashCooldown = 0.32f

        val weaponBonus = (slotMetal[0] * 10) + (slotMetal[1] + slotMetal[2] + slotMetal[3]) * 5
        val runeBonus = (if (runeSlot1 >= 0) 22 else 0) + (if (runeSlot2 >= 0) 22 else 0)
        val dmg = ((46 + str * 3 + weaponBonus + runeBonus) * aoeMultiplier).toInt()
        val reach = if (aoeMultiplier > 1.0f) 4.8f else 3.7f

        for (i in 0 until NUM_ENEMIES) {
            val dx = enemyX[i] - playerX
            val dz = enemyZ[i] - playerZ
            val d2 = dx * dx + dz * dz
            if (d2 < reach * reach) {
                damageEnemy(i, dmg, dx, dz, d2)
            }
        }
    }

    private fun damageEnemy(i: Int, dmg: Int, dx: Float, dz: Float, d2: Float) {
        enemyHp[i] -= dmg
        enemyHurt[i] = 0.25f
        enemyAggro[i] = true
        val d = sqrt(d2 + 0.001f)
        val kx = enemyX[i] + (dx / d) * 0.65f
        val kz = enemyZ[i] + (dz / d) * 0.65f
        if (!WorldGenerator.isBlockedByWorld(kx, kz)) {
            enemyX[i] = kx
            enemyZ[i] = kz
            enemyY[i] = WorldGenerator.getTerrainHeight(kx, kz, worldSeed, worldType, genRivers)
        }
        if (enemyHp[i] <= 0) {
            val xpGain = 185 + level * 35
            val goldGain = 65 + (i * 23) % 80
            xp += xpGain
            gold += goldGain
            cinderShards++
            if (!questCompleted) {
                questKills++
                if (questKills >= questTarget) {
                    questCompleted = true
                    gold += 500
                    xp += 1000
                    statusBanner = "QUEST COMPLETE: Moonlit Wardens (+500g, +1000 XP)"
                    bannerTimer = 4.0f
                }
            }
            if (xp >= xpNext) {
                xp -= xpNext
                level++
                xpNext = (xpNext * 1.25f).toInt()
                statPoints += 3
                maxHp += 110
                hp = maxHp
                maxMp += 18
                mp = maxMp
                statusBanner = "LEVEL UP! LV $level (+3 Stat Pts)"
                bannerTimer = 3.5f
            } else if (!questCompleted) {
                statusBanner = "Slain Ash-Stalker (+$xpGain XP, +${goldGain}g)"
                bannerTimer = 2.6f
            }
            for (l in 0 until MAX_LOOT) {
                if (!lootActive[l]) {
                    lootActive[l] = true
                    lootX[l] = enemyX[i]
                    lootZ[l] = enemyZ[i]
                    lootY[l] = enemyY[i]
                    lootMetal[l] = (enemyMetal[i] + 1) % METAL_RGB.size
                    break
                }
            }
            spawnEnemy(i, false)
        }
    }

    fun triggerHotbarSlot(slot: Int) {
        if (slot !in 0..9) return
        if (hotbarCooldowns[slot] > 0.0f) return

        when (slot) {
            0 -> {
                // Slot 1: Crimson Draught
                if (potions > 0 || gameMode == 2) {
                    if (gameMode != 2) potions--
                    hp = min(maxHp, hp + 520)
                    mp = min(maxMp, mp + 65)
                    hotbarCooldowns[0] = hotbarMaxCooldowns[0]
                    statusBanner = "Crimson Draught: +520 HP, +65 MP"
                    bannerTimer = 2.2f
                }
            }
            1 -> {
                // Slot 2: Whirlwind Cleave
                if (mp >= 18 || gameMode == 2) {
                    if (gameMode != 2) mp -= 18
                    hotbarCooldowns[1] = hotbarMaxCooldowns[1]
                    triggerSlash(1.45f)
                    statusBanner = "Skill: Whirlwind Cleave!"
                    bannerTimer = 2.0f
                }
            }
            2 -> {
                // Slot 3: Astral Vortex Ring (`1000461463.jpg` "New skills"!)
                if (mp >= 28 || gameMode == 2) {
                    if (gameMode != 2) mp -= 28
                    hotbarCooldowns[2] = hotbarMaxCooldowns[2]
                    vortexX = playerX + facingX * 1.65f
                    vortexZ = playerZ + facingZ * 1.65f
                    vortexY = WorldGenerator.getTerrainHeight(vortexX, vortexZ, worldSeed, worldType, genRivers) + 0.02f
                    vortexActiveTimer = 6.0f
                    vortexTickTimer = 0.05f
                    statusBanner = "Skill: Astral Vortex Rune Summoned!"
                    bannerTimer = 2.5f
                }
            }
            3 -> {
                // Slot 4: Moonlit Ward
                if (mp >= 24 || gameMode == 2) {
                    if (gameMode != 2) mp -= 24
                    hotbarCooldowns[3] = hotbarMaxCooldowns[3]
                    wardBuffTimer = 8.0f
                    hp = min(maxHp, hp + 220)
                    statusBanner = "Skill: Moonlit Ward Active (8s)"
                    bannerTimer = 2.2f
                }
            }
            4 -> {
                // Slot 5: Shadow Step Strike
                if (mp >= 20 || gameMode == 2) {
                    if (gameMode != 2) mp -= 20
                    hotbarCooldowns[4] = hotbarMaxCooldowns[4]
                    var bestIdx = -1
                    var bestD2 = 12.0f * 12.0f
                    for (i in 0 until NUM_ENEMIES) {
                        val dx = enemyX[i] - playerX
                        val dz = enemyZ[i] - playerZ
                        val d2 = dx * dx + dz * dz
                        if (d2 < bestD2) {
                            bestD2 = d2
                            bestIdx = i
                        }
                    }
                    if (bestIdx >= 0) {
                        playerX = enemyX[bestIdx] - facingX * 1.1f
                        playerZ = enemyZ[bestIdx] - facingZ * 1.1f
                        groundY = WorldGenerator.getTerrainHeight(playerX, playerZ, worldSeed, worldType, genRivers)
                        playerY = groundY
                        triggerSlash(1.6f)
                        statusBanner = "Skill: Shadow Step Strike!"
                        bannerTimer = 2.0f
                    }
                }
            }
        }
    }

    fun triggerJump() {
        if (playerY <= groundY + 0.04f) {
            velY = 6.4f
        }
    }

    fun triggerDodge() {
        if (dodgeCooldown > 0.0f) return
        dodgeTimer = 0.28f
        dodgeCooldown = 0.80f
        val len = sqrt(inputX * inputX + inputZ * inputZ)
        if (len > 0.15f) {
            dodgeDirX = inputX / len
            dodgeDirZ = inputZ / len
        } else {
            dodgeDirX = facingX
            dodgeDirZ = facingZ
        }
        facingX = dodgeDirX
        facingZ = dodgeDirZ
    }

    fun stepSimulation(dt: Float) {
        timeSec += dt
        if (bannerTimer > 0.0f) bannerTimer -= dt
        if (slashTimer > 0.0f) slashTimer -= dt
        if (slashCooldown > 0.0f) slashCooldown -= dt
        if (dodgeTimer > 0.0f) dodgeTimer -= dt
        if (dodgeCooldown > 0.0f) dodgeCooldown -= dt
        if (hurtFlash > 0.0f) hurtFlash -= dt
        if (wardBuffTimer > 0.0f) wardBuffTimer -= dt

        for (s in hotbarCooldowns.indices) {
            if (hotbarCooldowns[s] > 0.0f) {
                hotbarCooldowns[s] = max(0.0f, hotbarCooldowns[s] - dt)
            }
        }

        // Passive MP regeneration
        if (mp < maxMp && (timeSec.toInt() != ((timeSec - dt).toInt()))) {
            mp = min(maxMp, mp + 3)
        }

        if (screenMode == 2) {
            previewYaw += dt * 0.65f
            return
        }
        if (screenMode == 0 || screenMode == 3) {
            // Smooth background camera orbit while viewing the minimalist world menu
            camYaw += dt * 0.12f
            gaitPhase += dt * 1.6f
            capeWavePhase += dt * 2.2f
            return
        }

        // Camera-relative movement vector
        val cosY = cos(camYaw)
        val sinY = sin(camYaw)
        val worldInX = inputX * cosY - inputZ * sinY
        val worldInZ = inputX * sinY + inputZ * cosY

        if (dodgeTimer > 0.0f) {
            val dashSpd = if (mounted) 14.5f else 12.0f
            velX = dodgeDirX * dashSpd
            velZ = dodgeDirZ * dashSpd
        } else {
            val topSpd = (if (mounted) 7.4f else 4.9f) * (if (wardBuffTimer > 0f) 1.2f else 1.0f)
            val accel = min(1.0f, dt * 11.5f)
            velX += (worldInX * topSpd - velX) * accel
            velZ += (worldInZ * topSpd - velZ) * accel
        }

        val nx = playerX + velX * dt
        val nz = playerZ + velZ * dt
        if (!WorldGenerator.isBlockedByWorld(nx, playerZ)) playerX = nx
        if (!WorldGenerator.isBlockedByWorld(playerX, nz)) playerZ = nz

        // Ensure procedural 16x16 chunks are populated around new player coordinates
        WorldGenerator.ensureChunksAroundPlayer(
            playerX, playerZ, worldSeed, worldType, genCaves, genRivers, genShrines
        )
        val biomeId = WorldGenerator.getBiomeAt(playerX, playerZ, worldSeed, worldType, genCaves)
        currentBiomeName = WorldGenerator.getBiomeName(biomeId)

        groundY = WorldGenerator.getTerrainHeight(playerX, playerZ, worldSeed, worldType, genRivers)

        // Vertical Jump & Terrain-Following Gravity Physics
        if (playerY > groundY || velY > 0.0f) {
            playerY += velY * dt
            velY -= 16.8f * dt
            if (playerY < groundY) {
                playerY = groundY
                velY = 0.0f
            }
        } else {
            playerY = groundY
        }

        val spd = sqrt(velX * velX + velZ * velZ)
        capeWavePhase += dt * (2.6f + spd * 1.4f)
        if (spd > 0.20f) {
            facingX = velX / spd
            facingZ = velZ / spd
            val targetYaw = atan2(facingX, facingZ)
            var diff = targetYaw - bodyYaw
            while (diff > PI) diff -= (PI * 2.0).toFloat()
            while (diff < -PI) diff += (PI * 2.0).toFloat()
            turnVel = diff
            bodyYaw += diff * min(1.0f, dt * 12.0f)
            gaitPhase += dt * (if (mounted) 5.8f + spd * 1.9f else 5.2f + spd * 2.5f)
        } else {
            turnVel *= 0.85f
            gaitPhase += dt * 1.8f
        }

        // Astral Vortex AoE Skill Pulse (`1000461463.jpg`)
        if (vortexActiveTimer > 0.0f) {
            vortexActiveTimer -= dt
            vortexTickTimer -= dt
            if (vortexTickTimer <= 0.0f) {
                vortexTickTimer = 0.55f
                for (i in 0 until NUM_ENEMIES) {
                    val dx = enemyX[i] - vortexX
                    val dz = enemyZ[i] - vortexZ
                    val d2 = dx * dx + dz * dz
                    if (d2 < 3.2f * 3.2f) {
                        damageEnemy(i, 34 + str * 2, dx, dz, d2)
                    }
                }
            }
        }

        // Loot pickup
        for (l in 0 until MAX_LOOT) {
            if (lootActive[l]) {
                val dx = lootX[l] - playerX
                val dz = lootZ[l] - playerZ
                if (dx * dx + dz * dz < 1.45f * 1.45f) {
                    lootActive[l] = false
                    val m = lootMetal[l]
                    val targetSlot = m % SLOT_NAMES.size
                    slotMetal[targetSlot] = m
                    activeMetal = m
                    statusBanner = "Looted & Equipped ${METAL_SHORT[m]} ${SLOT_NAMES[targetSlot]}!"
                    bannerTimer = 3.0f
                }
            }
        }

        // Enemy AI (Guard post until player within 7.5 units)
        for (i in 0 until NUM_ENEMIES) {
            if (enemyHurt[i] > 0.0f) enemyHurt[i] -= dt
            if (enemyCooldown[i] > 0.0f) enemyCooldown[i] -= dt

            val dx = playerX - enemyX[i]
            val dz = playerZ - enemyZ[i]
            val dist = sqrt(dx * dx + dz * dz + 0.001f)

            if (dist > 38.0f) {
                // Respawn far-away enemies into newly explored chunks
                spawnEnemy(i, false)
                continue
            }

            if (!enemyAggro[i] && dist < 7.2f) {
                enemyAggro[i] = true
            } else if (enemyAggro[i] && dist > 14.0f) {
                enemyAggro[i] = false
            }

            if (!enemyAggro[i]) {
                val hx = enemyHomeX[i] - enemyX[i]
                val hz = enemyHomeZ[i] - enemyZ[i]
                val hd = sqrt(hx * hx + hz * hz)
                if (hd > 0.35f) {
                    enemyYaw[i] = atan2(hx, hz)
                    enemyGait[i] += dt * 5.0f
                    enemyX[i] += (hx / hd) * 1.4f * dt
                    enemyZ[i] += (hz / hd) * 1.4f * dt
                    enemyY[i] = WorldGenerator.getTerrainHeight(enemyX[i], enemyZ[i], worldSeed, worldType, genRivers)
                } else {
                    enemyGait[i] += dt * 1.4f
                }
                continue
            }

            enemyYaw[i] = atan2(dx, dz)
            if (enemyWindup[i] > 0.0f) {
                enemyWindup[i] -= dt
                if (enemyWindup[i] <= 0.0f) {
                    if (dist < 2.35f && dodgeTimer <= 0.0f && gameMode != 2) {
                        val rawDmg = 22 + level * 2 + (i % 3) * 6
                        val eDmg = if (wardBuffTimer > 0f) rawDmg / 2 else rawDmg
                        hp = max(0, hp - eDmg)
                        hurtFlash = 0.25f
                        if (hp <= 0) {
                            hp = maxHp
                            mp = maxMp
                            playerX = 0.0f
                            playerZ = 4.0f
                            groundY = WorldGenerator.getTerrainHeight(0f, 4f, worldSeed, worldType, genRivers)
                            playerY = groundY
                            statusBanner = "Revived at World Sanctuary"
                            bannerTimer = 3.0f
                        }
                    }
                    enemyCooldown[i] = 1.25f
                }
            } else if (dist > 1.55f) {
                enemyGait[i] += dt * 8.2f
                val ex = enemyX[i] + (dx / dist) * 2.25f * dt
                val ez = enemyZ[i] + (dz / dist) * 2.25f * dt
                if (!WorldGenerator.isBlockedByWorld(ex, ez)) {
                    enemyX[i] = ex
                    enemyZ[i] = ez
                    enemyY[i] = WorldGenerator.getTerrainHeight(ex, ez, worldSeed, worldType, genRivers)
                }
            } else if (enemyCooldown[i] <= 0.0f) {
                enemyWindup[i] = 0.42f
            }
        }
    }

    companion object {
        const val NUM_ENEMIES = 10
        const val MAX_LOOT = 12

        val SLOT_NAMES = arrayOf("Weapon", "Helm", "Shoulders", "Chest", "Gloves", "Legs", "Boots")
        val RUNE_GLYPHS = arrayOf("^", "*", "z", "~", ">", "/", "x", "v", "\u00b0", "\u00a7", "\u2020")
        val METAL_NAMES = arrayOf(
            "#%: Iron", "@%. Steel", "&o, Bronze", "\$s. Silver", "0o. Gold",
            "O*. Moonsteel", "Nightglass", "88: Bloodiron", "=-. Ossite", "*+. Emberstone"
        )
        val METAL_SHORT = arrayOf(
            "Iron", "Steel", "Bronze", "Silver", "Gold",
            "Moonsteel", "Nightglass", "Bloodiron", "Ossite", "Emberstone"
        )
        val METAL_RGB = arrayOf(
            floatArrayOf(0.76f, 0.79f, 0.82f), // Iron
            floatArrayOf(0.88f, 0.91f, 0.95f), // Steel
            floatArrayOf(0.84f, 0.60f, 0.38f), // Bronze
            floatArrayOf(0.95f, 0.97f, 1.00f), // Silver
            floatArrayOf(0.98f, 0.84f, 0.36f), // Gold
            floatArrayOf(0.62f, 0.84f, 1.00f), // Moonsteel
            floatArrayOf(0.58f, 0.50f, 0.82f), // Nightglass
            floatArrayOf(0.90f, 0.30f, 0.34f), // Bloodiron
            floatArrayOf(0.90f, 0.87f, 0.78f), // Ossite
            floatArrayOf(1.00f, 0.56f, 0.28f)  // Emberstone
        )
    }
}
