package com.ashveil.abyss;

/**
 * The Ashveil knight as a real 3D character: a skeleton (pelvis -> spine -> neck -> head, two-bone IK legs and arms),
 * built from armoured 3D primitives and drawn into a {@link Soft3D}.  Works on foot (planted-foot gait, slash, tuck-and-roll
 * dodge) and seated on the horse.
 *
 * Local frame: +y up, +z forward, +x = the knight's LEFT.  The sword is in the right hand (-x).
 */
final class Knight3D {
    static final float DODGE_DUR = 0.28f;
    static final float SLASH_DUR = 0.26f;
    private static final float PI = (float) Math.PI;

    // ---- inputs (set by the caller every frame) --------------------------------------------------
    float time, facingX = 1.0f, facingY = 0.0f, velX, velY, gait, dodgeTimer, slashTimer;
    /** Seated mode: saddle top (horse-local), spring of the spine, how hard the rider leans, reins target. */
    float seatY, seatZ, seatSpring, seatLean, headNod;

    // ---- smoothed state ---------------------------------------------------------------------------
    float yaw = 1.5707963f;
    private boolean yawInit = false;
    private float lastT = 0.0f, sWalk = 0.0f, sRun = 0.0f, sRec = 0.0f;

    // ---- pose output (local space) -----------------------------------------------------------------
    final float[] P = new float[3], Wst = new float[3], C = new float[3], S = new float[3], N = new float[3], Hd = new float[3];
    final float[][] hip = new float[2][3], knee = new float[2][3], ank = new float[2][3];
    final float[] footPitch = new float[2];
    final float[][] sh = new float[2][3], elb = new float[2][3], wri = new float[2][3];
    final float[] blade = new float[3], bladeBase = new float[3];
    final float[] hairAnchor = new float[3];
    final float[] rollM = new float[12], fullM = new float[12];
    float chestYaw = 0.0f, headYaw = 0.0f, headPitch = 0.0f, tuck = 0.0f, slashW = 0.0f;
    float rollAng = 0.0f, hopY = 0.0f;
    boolean seatedPose = false;
    /** The wrist of the rein hand in local space (left hand). */
    final float[] reinHand = new float[3];

    // tuck pose (ball), local
    private static final float[] T_P = {0.00f, 0.44f, -0.12f}, T_W = {0.00f, 0.54f, -0.05f}, T_C = {0.00f, 0.66f, 0.07f},
            T_S = {0.00f, 0.68f, 0.16f}, T_N = {0.00f, 0.64f, 0.24f}, T_H = {0.00f, 0.52f, 0.30f};
    private static final float[][] T_HIP = {{0.08f, 0.44f, -0.12f}, {-0.08f, 0.44f, -0.12f}};
    private static final float[][] T_KNEE = {{0.10f, 0.60f, 0.20f}, {-0.10f, 0.58f, 0.20f}};
    private static final float[][] T_ANK = {{0.08f, 0.30f, -0.08f}, {-0.08f, 0.28f, -0.08f}};
    private static final float[][] T_WRI = {{0.10f, 0.52f, 0.28f}, {-0.10f, 0.50f, 0.28f}};

    static float smooth01(float a, float b, float x) {
        float t = Math.max(0.0f, Math.min(1.0f, (x - a) / (b - a)));
        return t * t * (3.0f - 2.0f * t);
    }

    static float mix(float a, float b, float t) {
        return a + (b - a) * t;
    }

    static float cycleDist(float spd) {
        return Math.max(0.55f, Math.min(1.65f, 0.5f + 0.55f * spd));
    }

    private static void set(float[] a, float x, float y, float z) {
        a[0] = x; a[1] = y; a[2] = z;
    }

    private static void lerp3(float[] a, float[] b, float t) {
        a[0] = mix(a[0], b[0], t); a[1] = mix(a[1], b[1], t); a[2] = mix(a[2], b[2], t);
    }

    /** Two-bone IK. Moves 'foot' toward the hip if it is out of reach. Knee lands in 'out'. */
    static void ik(float[] hip, float[] foot, float l1, float l2, float px, float py, float pz, float[] out) {
        float dx = foot[0] - hip[0], dy = foot[1] - hip[1], dz = foot[2] - hip[2];
        float dist = (float) Math.sqrt(dx * dx + dy * dy + dz * dz) + 1.0e-6f;
        float ux = dx / dist, uy = dy / dist, uz = dz / dist;
        float reach = l1 + l2 - 0.004f;
        float dc = Math.max(Math.abs(l1 - l2) + 0.02f, Math.min(dist, reach));
        if (dist > reach) {
            foot[0] = hip[0] + ux * dc; foot[1] = hip[1] + uy * dc; foot[2] = hip[2] + uz * dc;
        }
        float a = (l1 * l1 - l2 * l2 + dc * dc) / (2.0f * dc);
        float h = (float) Math.sqrt(Math.max(0.0f, l1 * l1 - a * a));
        float pd = px * ux + py * uy + pz * uz;
        float qx = px - ux * pd, qy = py - uy * pd, qz = pz - uz * pd;
        float qn = (float) Math.sqrt(qx * qx + qy * qy + qz * qz);
        if (qn < 1.0e-4f) { qx = 0.0f; qy = 0.0f; qz = 1.0f; qn = 1.0f; }
        qx /= qn; qy /= qn; qz /= qn;
        out[0] = hip[0] + ux * a + qx * h;
        out[1] = hip[1] + uy * a + qy * h;
        out[2] = hip[2] + uz * a + qz * h;
    }

    // foot trajectory scratch
    private float fOff, fLift, fHeel, fPitch;

    private void footTraj(float theta, float duty, float stride, float lift) {
        float u = theta / 6.2831853f;
        u -= (float) Math.floor(u);
        if (u < duty) {
            float q = u / duty;
            fOff = stride * (1.0f - 2.0f * q);
            fLift = 0.0f;
            fHeel = 0.075f * smooth01(0.72f, 1.0f, q);
            fPitch = 0.30f * (1.0f - smooth01(0.0f, 0.30f, q)) - 0.55f * smooth01(0.72f, 1.0f, q);
        } else {
            float s = (u - duty) / (1.0f - duty);
            float e = s * s * (3.0f - 2.0f * s);
            fOff = -stride + 2.0f * stride * e;
            fLift = (float) Math.sin(Math.PI * Math.pow(s, 0.8)) * lift;
            fHeel = 0.0f;
            fPitch = -0.55f * (1.0f - smooth01(0.0f, 0.35f, s)) + 0.30f * smooth01(0.6f, 1.0f, s);
        }
    }

    // =============================================================================================
    // POSE
    // =============================================================================================
    private float dtStep() {
        float dt = Math.max(0.0f, Math.min(0.05f, time - lastT));
        lastT = time;
        return dt;
    }

    private void updateYaw(float dt) {
        float fl = (float) Math.sqrt(facingX * facingX + facingY * facingY);
        if (fl > 1.0e-4f) {
            float target = (float) Math.atan2(facingX / fl, facingY / fl);
            if (!yawInit) { yaw = target; yawInit = true; }
            float d = target - yaw;
            while (d > PI) d -= 2.0f * PI;
            while (d < -PI) d += 2.0f * PI;
            yaw += d * Math.min(1.0f, dt * 13.0f);
        }
    }

    /** Knight on foot. */
    void poseStanding() {
        seatedPose = false;
        final float dt = dtStep();
        updateYaw(dt);
        final float t = time;
        final float spd = (float) Math.sqrt(velX * velX + velY * velY);
        final boolean dodging = dodgeTimer > 0.0f;
        final float p = dodging ? Math.max(0.0f, 1.0f - dodgeTimer / DODGE_DUR) : 0.0f;
        sWalk += (smooth01(0.15f, 1.5f, spd) - sWalk) * Math.min(1.0f, dt * 10.0f);
        sRun += (smooth01(2.3f, 3.9f, spd) - sRun) * Math.min(1.0f, dt * 7.0f);
        final float walk = sWalk, idle = 1.0f - walk, run = sRun;

        final float breath = (float) Math.sin(t * 2.0f);
        final float breathLag = (float) Math.sin(t * 2.0f - 0.7f);
        final float shift = (float) Math.sin(t * 0.62f);
        final float gl = (float) Math.sin(t * 0.41f);
        final float glance = gl > 0.0f ? (float) Math.pow(gl, 6.0) : 0.0f;
        final float look = (float) Math.sin(t * 0.5f);

        float slashProg = slashTimer > 0.0f ? (1.0f - slashTimer / SLASH_DUR) : -1.0f;
        float slashE = slashProg >= 0.0f ? slashProg * slashProg * (3.0f - 2.0f * slashProg) : 0.0f;
        float lunge = slashProg >= 0.0f ? (float) Math.sin(Math.PI * slashProg) : 0.0f;
        float wS = slashProg >= 0.0f ? smooth01(0.0f, 0.12f, slashProg) * (1.0f - smooth01(0.82f, 1.0f, slashProg)) : 0.0f;
        slashW = wS;

        final float k = dodging ? smooth01(0.0f, 0.17f, p) * (1.0f - smooth01(0.78f, 0.97f, p)) : 0.0f;
        if (dodging) sRec = 1.0f;
        else sRec = Math.max(0.0f, sRec - dt / 0.22f);
        final float rec = dodging ? smooth01(0.80f, 1.0f, p) : smooth01(0.0f, 1.0f, sRec);
        tuck = k;
        rollAng = dodging ? 2.0f * PI * smooth01(0.10f, 0.92f, p) : 0.0f;
        hopY = dodging ? 0.15f * (float) Math.sin(PI * smooth01(0.06f, 0.94f, p)) : 0.0f;

        // ---- gait ----
        final float ph = gait;
        float cycle = cycleDist(spd);
        float duty = 0.60f - 0.14f * run;
        float stride = 0.5f * duty * cycle * 1.06f;
        float liftMax = 0.07f + 0.09f * run;
        float bobAmp = 0.018f + 0.034f * run;
        float stepBob = bobAmp * walk * (float) Math.cos(2.0f * ph);
        float down = stepBob + 0.020f * walk + 0.040f * run + 0.008f * breath * idle + 0.010f * shift * shift * idle
                + 0.07f * lunge + 0.10f * rec;
        float hipY = 0.885f - down;
        float hipX = 0.022f * shift * idle + 0.035f * (float) Math.cos(ph - 1.9f) * walk;

        // ---- spine ----
        float lean = 0.015f + 0.04f * walk + 0.075f * run + 0.11f * lunge + 0.08f * rec;
        float twist = slashProg >= 0.0f ? mix(-0.55f, 0.40f, slashE) * wS : 0.0f;
        chestYaw = twist;
        set(P, hipX, hipY, 0.0f);
        set(Wst, hipX + 0.1f * lean * 0.0f, hipY + 0.17f, 0.30f * lean);
        set(C, hipX, hipY + 0.355f + 0.012f * breath * idle, 0.65f * lean);
        set(S, hipX, hipY + 0.50f + 0.012f * breathLag * idle, lean);
        set(N, S[0], S[1] + 0.065f, S[2] + 0.2f * lean);
        headYaw = 0.40f * glance * idle + 0.10f * look * idle - 0.35f * twist;
        headPitch = 0.10f * run - 0.05f * rec;
        set(Hd, N[0], N[1] + 0.115f - 0.5f * stepBob - 0.004f * breath * idle - 0.02f * rec, N[2] + 0.035f);

        // ---- legs: leg 0 = left (+x), leg 1 = right (-x, sword side) ----
        for (int leg = 0; leg < 2; leg++) {
            boolean rightLeg = leg == 1;
            float side = rightLeg ? -1.0f : 1.0f;
            float theta = ph + (rightLeg ? 0.0f : PI);
            footTraj(theta, duty, stride, liftMax);
            float stance = rightLeg ? (0.10f + 0.20f * lunge) : (-0.08f - 0.12f * lunge);
            float off = mix(stance, fOff + (rightLeg ? 0.10f * lunge : 0.0f), walk);
            float lift = fLift * walk;
            float heel = fHeel * walk;
            footPitch[leg] = fPitch * walk;
            set(hip[leg], hipX + side * 0.085f, hipY - 0.02f, 0.0f);
            set(ank[leg], hipX * 0.4f + side * 0.095f, 0.080f + lift + heel, off);
        }

        // ---- arms (targets) ----
        float cw = (float) Math.cos(ph - 0.35f);
        float swing = 0.15f * walk + 0.13f * run;
        // off hand (left): hangs, swings opposite the sword-side leg, elbow folds when running
        float lhx = 0.25f - 0.06f * run, lhy = S[1] - 0.57f + 0.22f * run + 0.012f * breath * idle - 0.06f * rec;
        float lhz = 0.02f + swing * cw - 0.10f * rec + 0.04f * run;
        // sword hand (right): guard that bobs with the stride
        float rhx = -0.17f - 0.02f * run, rhy = hipY + 0.40f + 0.012f * breath - 0.03f * cw * walk * 0.5f;
        float rhz = 0.27f - 0.05f * cw * walk - 0.05f * run + 0.02f * breath;
        float bdy = mix(0.60f, 0.92f, run), bdz = mix(0.80f, 0.30f, run);
        set(blade, -0.05f * run, bdy, bdz);

        // ---- shoulders ----
        float cy = (float) Math.cos(chestYaw), sy = (float) Math.sin(chestYaw);
        // shoulder joint = S + R_y(chestYaw) * (side*0.20, -0.02, 0)
        set(sh[0], S[0] + 0.20f * cy, S[1] - 0.02f, S[2] - 0.20f * sy);
        set(sh[1], S[0] - 0.20f * cy, S[1] - 0.02f, S[2] + 0.20f * sy);

        // ---- slash blend ----
        if (wS > 0.0f) {
            float phi = mix(1.92f, -0.78f, slashE);
            float hxS = sh[1][0] + mix(-0.02f, 0.14f, slashE);
            float hyS = sh[1][1] + (float) Math.sin(phi) * 0.38f;
            float hzS = sh[1][2] + (float) Math.cos(phi) * 0.40f + 0.02f;
            float bAng = phi + 0.45f;
            float bxS = mix(-0.15f, 0.12f, slashE), byS = (float) Math.sin(bAng), bzS = (float) Math.cos(bAng);
            rhx = mix(rhx, hxS, wS); rhy = mix(rhy, hyS, wS); rhz = mix(rhz, hzS, wS);
            float bx = mix(blade[0], bxS, wS), by = mix(blade[1], byS, wS), bz = mix(blade[2], bzS, wS);
            set(blade, bx, by, bz);
            // off hand comes up to steady the body
            lhy = mix(lhy, S[1] - 0.40f, wS); lhz = mix(lhz, 0.10f, wS); lhx = mix(lhx, 0.30f, wS);
        }
        normalize(blade);
        set(wri[0], lhx, lhy, lhz);
        set(wri[1], rhx, rhy, rhz);

        // ---- dodge tuck: blend every joint toward a curled ball ----
        if (k > 0.0f) {
            lerp3(P, T_P, k); lerp3(Wst, T_W, k); lerp3(C, T_C, k); lerp3(S, T_S, k); lerp3(N, T_N, k); lerp3(Hd, T_H, k);
            for (int leg = 0; leg < 2; leg++) {
                lerp3(hip[leg], T_HIP[leg], k);
                lerp3(ank[leg], T_ANK[leg], k);
                lerp3(wri[leg], T_WRI[leg], k);
                footPitch[leg] = mix(footPitch[leg], -0.5f, k);
            }
            set(sh[0], S[0] + 0.19f, S[1] - 0.02f, S[2]);
            set(sh[1], S[0] - 0.19f, S[1] - 0.02f, S[2]);
            blade[0] = mix(blade[0], 0.0f, k); blade[1] = mix(blade[1], 0.35f, k); blade[2] = mix(blade[2], -0.93f, k);
            normalize(blade);
            chestYaw *= (1.0f - k);
            headYaw *= (1.0f - k);
        }
        solveLimbs(1.0f - 0.8f * k, false);
    }

    /** Knight seated on the horse (horse-local coordinates). Reins hand target comes from the caller. */
    void poseSeated(float reinX, float reinY, float reinZ) {
        seatedPose = true;
        final float dt = dtStep();
        final float t = time;
        final float spd = (float) Math.sqrt(velX * velX + velY * velY);
        final float sf = Math.min(1.0f, spd / 4.6f);
        final float mv = Math.min(1.0f, spd / 1.4f);
        final boolean dodging = dodgeTimer > 0.0f;
        final float p = dodging ? Math.max(0.0f, 1.0f - dodgeTimer / DODGE_DUR) : 0.0f;
        final float k = dodging ? smooth01(0.05f, 0.20f, p) * (1.0f - smooth01(0.82f, 0.97f, p)) : 0.0f;
        tuck = 0.0f;
        rollAng = 0.0f;
        hopY = 0.0f;

        float slashProg = slashTimer > 0.0f ? (1.0f - slashTimer / SLASH_DUR) : -1.0f;
        float slashE = slashProg >= 0.0f ? slashProg * slashProg * (3.0f - 2.0f * slashProg) : 0.0f;
        float wS = slashProg >= 0.0f ? smooth01(0.0f, 0.12f, slashProg) * (1.0f - smooth01(0.82f, 1.0f, slashProg)) : 0.0f;
        slashW = wS;
        float breath = (float) Math.sin(t * 1.8f);

        float lean = 0.05f * sf + 0.26f * k + 0.04f * seatLean;
        float spring = seatSpring;
        float py = seatY + 0.075f + spring * 0.3f;
        set(P, 0.0f, py, seatZ);
        set(Wst, 0.0f, py + 0.17f, seatZ + lean * 0.30f);
        set(C, 0.0f, py + 0.355f + 0.008f * breath * (1.0f - mv), seatZ + lean * 0.65f);
        set(S, 0.0f, py + 0.50f - 0.10f * k * 0.5f, seatZ + lean);
        set(N, S[0], S[1] + 0.065f, S[2] + 0.2f * lean);
        float twist = slashProg >= 0.0f ? mix(-0.55f, 0.40f, slashE) * wS : 0.0f;
        chestYaw = twist;
        headYaw = 0.10f * (float) Math.sin(t * 0.5f) * (1.0f - mv) - 0.35f * twist;
        headPitch = 0.05f + 0.15f * k;
        set(Hd, N[0], N[1] + 0.115f, N[2] + 0.035f);

        // legs: thighs wrap the barrel, boots in the stirrups
        for (int leg = 0; leg < 2; leg++) {
            float side = leg == 1 ? -1.0f : 1.0f;
            set(hip[leg], side * 0.105f, py - 0.02f, seatZ);
            float sw = 0.018f * (float) Math.sin(gait + (leg == 1 ? 1.0f : 0.0f)) * mv;
            set(ank[leg], side * 0.315f, py - 0.60f + sw, seatZ + 0.07f + sw);
            footPitch[leg] = -0.25f;
        }

        float cy = (float) Math.cos(chestYaw), sy = (float) Math.sin(chestYaw);
        set(sh[0], S[0] + 0.20f * cy, S[1] - 0.02f, S[2] - 0.20f * sy);
        set(sh[1], S[0] - 0.20f * cy, S[1] - 0.02f, S[2] + 0.20f * sy);

        // left hand holds the reins (follows the horse's head nod), sword hand holds the guard
        set(wri[0], reinX, reinY, reinZ);
        float rhx = -0.20f, rhy = S[1] - 0.30f, rhz = S[2] + 0.30f + 0.02f * breath;
        set(blade, 0.0f, 0.80f, 0.60f);
        if (wS > 0.0f) {
            float phi = mix(1.92f, -0.78f, slashE);
            float hxS = sh[1][0] + mix(-0.02f, 0.14f, slashE);
            float hyS = sh[1][1] + (float) Math.sin(phi) * 0.38f;
            float hzS = sh[1][2] + (float) Math.cos(phi) * 0.40f + 0.02f;
            float bAng = phi + 0.45f;
            rhx = mix(rhx, hxS, wS); rhy = mix(rhy, hyS, wS); rhz = mix(rhz, hzS, wS);
            set(blade, mix(blade[0], mix(-0.15f, 0.12f, slashE), wS), mix(blade[1], (float) Math.sin(bAng), wS),
                    mix(blade[2], (float) Math.cos(bAng), wS));
        }
        normalize(blade);
        set(wri[1], rhx, rhy, rhz);
        set(reinHand, wri[0][0], wri[0][1], wri[0][2]);
        solveLimbs(1.0f, true);
    }

    private static void normalize(float[] v) {
        float n = (float) Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]) + 1.0e-9f;
        v[0] /= n; v[1] /= n; v[2] /= n;
    }

    /** IK for both legs and both arms from the targets stored in ank[] / wri[]. */
    private void solveLimbs(float legBend, boolean seated) {
        for (int leg = 0; leg < 2; leg++) {
            float side = leg == 1 ? -1.0f : 1.0f;
            if (seated) ik(hip[leg], ank[leg], 0.42f, 0.42f, side * 0.45f, -0.05f, 1.0f, knee[leg]);
            else ik(hip[leg], ank[leg], 0.43f, 0.43f, 0.0f, 0.10f * (1.0f - legBend), 1.0f, knee[leg]);
            float side2 = leg == 1 ? -1.0f : 1.0f;
            ik(sh[leg], wri[leg], 0.29f, 0.27f, side2 * 0.55f, -0.30f, -0.80f, elb[leg]);
        }
        // hair anchor at the back of the head (local)
        set(hairAnchor, Hd[0], Hd[1] + 0.01f, Hd[2] - 0.10f);
    }

    // =============================================================================================
    // DRAW
    // =============================================================================================
    private final float[] tmpM = new float[12];

    /** Draws the foot knight (builds its own model matrix: yaw + dodge roll). */
    void drawStanding(Soft3D s) {
        // M = T(0,hop,0) * Ry(yaw) * Rx(roll about the lateral axis through the body centre)
        float[] ry = tmpM;
        Soft3D.rotY(ry, yaw, 0.0f, hopY, 0.0f);
        if (rollAng != 0.0f) {
            Soft3D.rotXPivot(rollM, rollAng, 0.47f, 0.05f);
            Soft3D.mul(ry, rollM, fullM);
        } else {
            System.arraycopy(ry, 0, fullM, 0, 12);
        }
        s.setModel(fullM);
        drawBody(s);
    }

    /** Draws the seated rider; the caller has already set the horse's model matrix. */
    void drawSeated(Soft3D s) {
        drawBody(s);
    }

    private void yawEll(Soft3D s, float cx, float cy, float cz, float rx, float ry, float rz, float yw, int tone, float base, float spec) {
        float c = (float) Math.cos(yw), sn = (float) Math.sin(yw);
        s.ellOri(cx, cy, cz, c, 0.0f, -sn, 0.0f, 1.0f, 0.0f, sn, 0.0f, c, rx, ry, rz, tone, base, spec);
    }

    /** Ellipsoid whose "forward" axis is f (any direction) and "up" is as close to +y as possible. */
    private void dirEll(Soft3D s, float cx, float cy, float cz, float fx, float fy, float fz, float rx, float ry, float rz,
                        int tone, float base, float spec) {
        float n = (float) Math.sqrt(fx * fx + fy * fy + fz * fz) + 1.0e-9f;
        fx /= n; fy /= n; fz /= n;
        float ux = 0.0f, uy = 1.0f, uz = 0.0f;
        if (Math.abs(fy) > 0.95f) { uy = 0.0f; uz = -1.0f; }
        // make u orthogonal to f
        float d = ux * fx + uy * fy + uz * fz;
        ux -= fx * d; uy -= fy * d; uz -= fz * d;
        float un = (float) Math.sqrt(ux * ux + uy * uy + uz * uz) + 1.0e-9f;
        ux /= un; uy /= un; uz /= un;
        // R = U x F
        float rx2 = uy * fz - uz * fy, ry2 = uz * fx - ux * fz, rz2 = ux * fy - uy * fx;
        s.ellOri(cx, cy, cz, rx2, ry2, rz2, ux, uy, uz, fx, fy, fz, rx, ry, rz, tone, base, spec);
    }

    private void dirBox(Soft3D s, float cx, float cy, float cz, float ux, float uy, float uz, float hx, float hy, float hz,
                        int tone, float base, float spec) {
        // U = blade direction, F = U x ref, R = U x F
        float rfx = 0.0f, rfy = 0.0f, rfz = 1.0f;
        if (Math.abs(uz) > 0.92f) { rfx = 1.0f; rfz = 0.0f; }
        float fx = uy * rfz - uz * rfy, fy = uz * rfx - ux * rfz, fz = ux * rfy - uy * rfx;
        float fn = (float) Math.sqrt(fx * fx + fy * fy + fz * fz) + 1.0e-9f;
        fx /= fn; fy /= fn; fz /= fn;
        float rx = uy * fz - uz * fy, ry = uz * fx - ux * fz, rz = ux * fy - uy * fx;
        s.box(cx, cy, cz, rx, ry, rz, ux, uy, uz, fx, fy, fz, hx, hy, hz, tone, base, spec);
    }

    private void drawBody(Soft3D s) {
        final int STEEL = Soft3D.T_STEEL, SKIN = Soft3D.T_SKIN, CLOTH = Soft3D.T_CLOTH, LEATHER = Soft3D.T_LEATHER,
                HAIR = Soft3D.T_HAIR, FIRE = Soft3D.T_FIRE, GOLD = Soft3D.T_GOLD;

        // ---- legs ----
        for (int leg = 0; leg < 2; leg++) {
            float[] h = hip[leg], kn = knee[leg], an = ank[leg];
            float lm = 1.0f;
            s.limb(h[0], h[1], h[2], kn[0], kn[1], kn[2], 0.088f, 0.062f, CLOTH, 0.95f * lm, 0.0f);       // thigh
            s.limb(kn[0], kn[1], kn[2], an[0], an[1], an[2], 0.060f, 0.046f, STEEL, 0.92f * lm, 0.55f);   // greave
            s.ell(kn[0], kn[1], kn[2] + 0.03f, 0.056f, 0.056f, 0.062f, STEEL, 0.95f * lm, 0.6f);          // knee cop
            float fp = footPitch[leg];
            float cf = (float) Math.cos(fp), sf = (float) Math.sin(fp);
            // foot: ellipsoid aligned with the pitched sole (forward axis = (0, sin, cos))
            s.ellOri(an[0], an[1] - 0.035f + 0.045f * sf, an[2] + 0.050f * cf,
                    1.0f, 0.0f, 0.0f, 0.0f, cf, -sf, 0.0f, sf, cf,
                    0.054f, 0.044f, 0.112f, STEEL, 0.90f * lm, 0.45f);
            s.limb(an[0], an[1] + 0.01f, an[2] - 0.01f, an[0], an[1] - 0.05f, an[2] - 0.02f, 0.050f, 0.054f, STEEL, 0.9f * lm, 0.4f); // ankle
        }

        // ---- torso ----
        float cyw = chestYaw;
        yawEll(s, P[0], P[1] - 0.095f, P[2] + 0.005f, 0.150f, 0.105f, 0.125f, cyw * 0.3f, CLOTH, 0.82f, 0.0f);   // tunic skirt
        yawEll(s, P[0], P[1] + 0.005f, P[2], 0.125f, 0.095f, 0.100f, cyw * 0.2f, CLOTH, 0.88f, 0.0f);            // pelvis
        yawEll(s, (P[0] + Wst[0]) * 0.5f, (P[1] + Wst[1]) * 0.5f + 0.02f, (P[2] + Wst[2]) * 0.5f, 0.112f, 0.105f, 0.085f,
                cyw * 0.5f, CLOTH, 0.92f, 0.0f);                                                                  // abdomen
        yawEll(s, C[0], C[1] - 0.005f, C[2], 0.150f, 0.150f, 0.098f, cyw, CLOTH, 0.95f, 0.0f);                    // chest (tunic)
        yawEll(s, C[0], C[1] + 0.010f, C[2] + 0.040f * (float) Math.cos(cyw), 0.138f, 0.130f, 0.082f, cyw, STEEL, 0.98f, 0.7f); // breastplate
        yawEll(s, Wst[0], Wst[1] - 0.005f, Wst[2], 0.128f, 0.024f, 0.100f, cyw * 0.5f, LEATHER, 0.85f, 0.0f);     // belt
        s.box(Wst[0] + 0.0f, Wst[1] - 0.005f, Wst[2] + 0.098f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f,
                0.026f, 0.020f, 0.010f, GOLD, 1.0f, 0.6f);                                                        // buckle
        // pauldrons (steel) over the shoulder joints
        for (int sd = 0; sd < 2; sd++) {
            float side = sd == 0 ? 1.0f : -1.0f;
            yawEll(s, sh[sd][0] + side * 0.025f, sh[sd][1] + 0.015f, sh[sd][2], 0.090f, 0.072f, 0.088f, cyw, STEEL, 1.0f, 0.7f);
        }
        // neck + head
        s.limb(N[0], N[1] - 0.02f, N[2], Hd[0], Hd[1] - 0.06f, Hd[2] - 0.01f, 0.046f, 0.040f, SKIN, 0.85f, 0.0f);
        float hy = headYaw;
        float cH = (float) Math.cos(hy), sH = (float) Math.sin(hy);
        float cp = (float) Math.cos(headPitch), sp = (float) Math.sin(headPitch);
        // head axes: F = yaw/pitch forward, U = up tilted, R = U x F
        float Fx = sH * cp, Fy = -sp, Fz = cH * cp;
        float Ux = sH * sp, Uy = cp, Uz = cH * sp;
        float Rx = Uy * Fz - Uz * Fy, Ry = Uz * Fx - Ux * Fz, Rz = Ux * Fy - Uy * Fx;
        s.ellOri(Hd[0], Hd[1], Hd[2], Rx, Ry, Rz, Ux, Uy, Uz, Fx, Fy, Fz, 0.090f, 0.118f, 0.102f, SKIN, 0.95f, 0.1f);           // skull / face
        s.ellOri(Hd[0] + Fx * 0.098f + Ux * (-0.005f), Hd[1] + Fy * 0.098f + Uy * (-0.005f), Hd[2] + Fz * 0.098f + Uz * (-0.005f),
                Rx, Ry, Rz, Ux, Uy, Uz, Fx, Fy, Fz, 0.026f, 0.034f, 0.030f, SKIN, 0.95f, 0.1f);                              // nose
        s.ellOri(Hd[0] - Fx * 0.030f + Ux * 0.034f, Hd[1] - Fy * 0.030f + Uy * 0.034f, Hd[2] - Fz * 0.030f + Uz * 0.034f,
                Rx, Ry, Rz, Ux, Uy, Uz, Fx, Fy, Fz, 0.098f, 0.112f, 0.108f, HAIR, 1.0f, 0.25f);                              // silver hair cap
        s.ellOri(Hd[0] - Fx * 0.080f + Ux * (-0.040f), Hd[1] - Fy * 0.080f + Uy * (-0.040f), Hd[2] - Fz * 0.080f + Uz * (-0.040f),
                Rx, Ry, Rz, Ux, Uy, Uz, Fx, Fy, Fz, 0.070f, 0.090f, 0.062f, HAIR, 1.0f, 0.2f);                               // back hair
        // eyes (dark)
        for (int e = -1; e <= 1; e += 2) {
            s.ellOri(Hd[0] + Fx * 0.088f + Rx * (0.036f * e) + Ux * 0.018f, Hd[1] + Fy * 0.088f + Ry * (0.036f * e) + Uy * 0.018f,
                    Hd[2] + Fz * 0.088f + Rz * (0.036f * e) + Uz * 0.018f,
                    Rx, Ry, Rz, Ux, Uy, Uz, Fx, Fy, Fz, 0.014f, 0.010f, 0.012f, Soft3D.T_DARK, 0.25f, 0.0f);
        }

        // ---- arms ----
        for (int a = 0; a < 2; a++) {
            float[] sj = sh[a], el = elb[a], wr = wri[a];
            s.limb(sj[0], sj[1], sj[2], el[0], el[1], el[2], 0.054f, 0.046f, CLOTH, 0.95f, 0.0f);            // sleeve
            s.limb(el[0], el[1], el[2], wr[0], wr[1], wr[2], 0.048f, 0.040f, STEEL, 0.95f, 0.55f);           // vambrace
            s.ell(el[0], el[1], el[2], 0.046f, 0.046f, 0.046f, STEEL, 1.0f, 0.5f);                           // elbow cop
            s.ell(wr[0], wr[1], wr[2], 0.046f, 0.048f, 0.052f, LEATHER, 0.9f, 0.1f);                         // gauntlet
        }

        // ---- sword (right hand) ----
        float[] wr = wri[1];
        float bx = blade[0], by = blade[1], bz = blade[2];
        s.limb(wr[0] - bx * 0.075f, wr[1] - by * 0.075f, wr[2] - bz * 0.075f, wr[0] + bx * 0.06f, wr[1] + by * 0.06f, wr[2] + bz * 0.06f,
                0.022f, 0.022f, LEATHER, 0.9f, 0.1f);                                                         // grip
        s.ell(wr[0] - bx * 0.095f, wr[1] - by * 0.095f, wr[2] - bz * 0.095f, 0.034f, 0.034f, 0.034f, GOLD, 1.0f, 0.6f); // pommel
        dirBox(s, wr[0] + bx * 0.075f, wr[1] + by * 0.075f, wr[2] + bz * 0.075f, bx, by, bz, 0.012f, 0.012f, 0.0f + 0.092f, GOLD, 1.0f, 0.7f); // guard
        // crossguard is wide along the side axis; dirBox puts F along (U x ref); make it wide by swapping extents
        dirBox(s, wr[0] + bx * 0.30f, wr[1] + by * 0.30f, wr[2] + bz * 0.30f, bx, by, bz, 0.034f, 0.21f, 0.017f, FIRE, 1.0f, 0.3f);      // blade (ember glow)
        s.limb(wr[0] + bx * 0.50f, wr[1] + by * 0.50f, wr[2] + bz * 0.50f, wr[0] + bx * 0.65f, wr[1] + by * 0.65f, wr[2] + bz * 0.65f,
                0.030f, 0.006f, FIRE, 1.0f, 0.2f);                                                            // tip
    }
}
