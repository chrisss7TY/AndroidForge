package com.ashveil.abyss;

/**
 * Tiny CPU 3D renderer used to build the knight and the horse as real 3D models, which are then
 * converted to ASCII glyphs ({@link #toAscii}).  Pure Java (no Android classes) so it can be tested on a desktop JVM.
 *
 * Pipeline:   3D primitives (tapered capsules, ellipsoids, boxes)  ->  z-buffered triangles with smooth
 *             per-pixel lighting  ->  supersampled framebuffer  ->  one glyph per cell.
 *
 * Model space: +x right, +y up, +z toward the viewer (= world "down the screen"), ground at y = 0.
 * Camera: orthographic, pitched down by {@link #setView}.  Every draw call goes through the current model matrix
 * (rigid: rotation + translation only), so a whole rig can be yawed / rolled / placed with one matrix.
 */
final class Soft3D {
    // ---- material tones ------------------------------------------------------------------------
    static final int T_STEEL = 0, T_SKIN = 1, T_CLOTH = 2, T_LEATHER = 3, T_HAIR = 4, T_FIRE = 5,
            T_COAT = 6, T_HOOF = 7, T_DARK = 8, T_GOLD = 9, T_BLANKET = 10;
    static final String HAIR_GLYPHS = "S8(3)~5s&${}";
    static final float EMPTY = -1.0e9f;

    // ---- framebuffer ---------------------------------------------------------------------------
    final int cols, rows, ssx, ssy, W, H;
    final float[] zbuf, lbuf;
    final byte[] tbuf;

    // ---- camera --------------------------------------------------------------------------------
    private float pxx = 1.0f, pxy = 1.0f, opx = 0.0f, opy = 0.0f;
    private float cosP = 1.0f, sinP = 0.0f;

    // light (view space: x right, y up, z toward viewer)
    private static final float LX, LY, LZ, HX, HY, HZ;
    static {
        float lx = -0.50f, ly = 0.66f, lz = 0.56f;
        float n = (float) Math.sqrt(lx * lx + ly * ly + lz * lz);
        LX = lx / n; LY = ly / n; LZ = lz / n;
        float hx = LX, hy = LY, hz = LZ + 1.0f;
        float hn = (float) Math.sqrt(hx * hx + hy * hy + hz * hz);
        HX = hx / hn; HY = hy / hn; HZ = hz / hn;
    }

    // ---- model matrix (3x4, row-major) ---------------------------------------------------------
    final float[] M = new float[12];

    // ---- static unit meshes --------------------------------------------------------------------
    private static final int SPH_RINGS = 9, SPH_SEGS = 14;
    private static final int SPH_V = SPH_RINGS * SPH_SEGS;
    private static final float[] SPH_P = new float[SPH_V * 3];
    private static final int[] SPH_I;
    private static final float[] BOX_P = new float[24 * 3], BOX_N = new float[24 * 3];
    private static final int[] BOX_I = new int[36];
    private static final int LMB_SEGS = 10, LMB_RINGS = 8;
    private static final int LMB_V = LMB_SEGS * LMB_RINGS;
    private static final int[] LMB_I;
    private static final float[] LMB_E = {-90.0f, -60.0f, -30.0f, 0.0f, 0.0f, 30.0f, 60.0f, 90.0f};
    private static final float[] LMB_COS = new float[LMB_RINGS], LMB_SIN = new float[LMB_RINGS];
    private static final float[] SEG_C = new float[LMB_SEGS], SEG_S = new float[LMB_SEGS];

    static {
        // unit sphere (lat rings from the bottom pole to the top pole)
        for (int i = 0; i < SPH_RINGS; i++) {
            double lat = Math.toRadians(-90.0 + 180.0 * i / (SPH_RINGS - 1));
            for (int j = 0; j < SPH_SEGS; j++) {
                double lon = 2.0 * Math.PI * j / SPH_SEGS;
                int v = (i * SPH_SEGS + j) * 3;
                SPH_P[v] = (float) (Math.cos(lat) * Math.cos(lon));
                SPH_P[v + 1] = (float) Math.sin(lat);
                SPH_P[v + 2] = (float) (Math.cos(lat) * Math.sin(lon));
            }
        }
        int[] si = new int[(SPH_RINGS - 1) * SPH_SEGS * 6];
        int k = 0;
        for (int i = 0; i < SPH_RINGS - 1; i++) {
            for (int j = 0; j < SPH_SEGS; j++) {
                int a = i * SPH_SEGS + j, b = i * SPH_SEGS + (j + 1) % SPH_SEGS;
                int c = (i + 1) * SPH_SEGS + j, d = (i + 1) * SPH_SEGS + (j + 1) % SPH_SEGS;
                si[k++] = a; si[k++] = c; si[k++] = b;
                si[k++] = b; si[k++] = c; si[k++] = d;
            }
        }
        SPH_I = si;

        // unit cube (-1..1), flat normals
        float[][] fn = {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
        float[][] fu = {{0, 1, 0}, {0, 1, 0}, {0, 0, 1}, {0, 0, 1}, {1, 0, 0}, {1, 0, 0}};
        for (int f = 0; f < 6; f++) {
            float[] n = fn[f], u = fu[f];
            float[] w = {n[1] * u[2] - n[2] * u[1], n[2] * u[0] - n[0] * u[2], n[0] * u[1] - n[1] * u[0]};
            int[][] sg = {{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
            for (int q = 0; q < 4; q++) {
                int v = (f * 4 + q) * 3;
                for (int c = 0; c < 3; c++) {
                    BOX_P[v + c] = n[c] + u[c] * sg[q][0] + w[c] * sg[q][1];
                    BOX_N[v + c] = n[c];
                }
            }
            int b = f * 4, t = f * 6;
            BOX_I[t] = b; BOX_I[t + 1] = b + 1; BOX_I[t + 2] = b + 2;
            BOX_I[t + 3] = b; BOX_I[t + 4] = b + 2; BOX_I[t + 5] = b + 3;
        }

        // tapered capsule topology
        for (int j = 0; j < LMB_SEGS; j++) {
            SEG_C[j] = (float) Math.cos(2.0 * Math.PI * j / LMB_SEGS);
            SEG_S[j] = (float) Math.sin(2.0 * Math.PI * j / LMB_SEGS);
        }
        for (int i = 0; i < LMB_RINGS; i++) {
            LMB_COS[i] = (float) Math.cos(Math.toRadians(LMB_E[i]));
            LMB_SIN[i] = (float) Math.sin(Math.toRadians(LMB_E[i]));
        }
        int[] li = new int[(LMB_RINGS - 1) * LMB_SEGS * 6];
        k = 0;
        for (int i = 0; i < LMB_RINGS - 1; i++) {
            for (int j = 0; j < LMB_SEGS; j++) {
                int a = i * LMB_SEGS + j, b = i * LMB_SEGS + (j + 1) % LMB_SEGS;
                int c = (i + 1) * LMB_SEGS + j, d = (i + 1) * LMB_SEGS + (j + 1) % LMB_SEGS;
                li[k++] = a; li[k++] = c; li[k++] = b;
                li[k++] = b; li[k++] = c; li[k++] = d;
            }
        }
        LMB_I = li;
    }

    // ---- scratch (no per-frame allocation) -----------------------------------------------------
    private static final int MAXV = 160;
    private final float[] wx = new float[MAXV], wy = new float[MAXV], wz = new float[MAXV];
    private final float[] nx = new float[MAXV], ny = new float[MAXV], nzz = new float[MAXV];
    private final float[] spx = new float[MAXV], spy = new float[MAXV], sd = new float[MAXV];
    private final float[] vnx = new float[MAXV], vny = new float[MAXV], vnz = new float[MAXV];
    private boolean cull = true;

    Soft3D(int cols, int rows, int ssx, int ssy) {
        this.cols = cols;
        this.rows = rows;
        this.ssx = ssx;
        this.ssy = ssy;
        this.W = cols * ssx;
        this.H = rows * ssy;
        zbuf = new float[W * H];
        lbuf = new float[W * H];
        tbuf = new byte[W * H];
        ident(M);
    }

    void setCulling(boolean on) {
        cull = on;
    }

    /**
     * @param pitchRad       camera tilt (0 = pure side elevation, larger = looking down more)
     * @param colsPerUnit    glyph columns per model unit (horizontal)
     * @param rowsPerUnit    glyph rows per model unit (vertical, already includes the glyph aspect)
     * @param groundCol/Row  continuous cell coordinates where the model origin (a ground point) lands
     */
    void setView(float pitchRad, float colsPerUnit, float rowsPerUnit, float groundCol, float groundRow) {
        cosP = (float) Math.cos(pitchRad);
        sinP = (float) Math.sin(pitchRad);
        pxx = colsPerUnit * ssx;
        pxy = rowsPerUnit * ssy;
        opx = groundCol * ssx;
        opy = groundRow * ssy;
    }

    float pitchCos() { return cosP; }
    float pitchSin() { return sinP; }

    void clear() {
        java.util.Arrays.fill(zbuf, EMPTY);
        java.util.Arrays.fill(lbuf, 0.0f);
        java.util.Arrays.fill(tbuf, (byte) 0);
    }

    // ---- matrix helpers ------------------------------------------------------------------------
    static void ident(float[] m) {
        m[0] = 1; m[1] = 0; m[2] = 0; m[3] = 0;
        m[4] = 0; m[5] = 1; m[6] = 0; m[7] = 0;
        m[8] = 0; m[9] = 0; m[10] = 1; m[11] = 0;
    }

    /** Rotation about +Y by a (local +z maps to (sin a, 0, cos a)) followed by translation. */
    static void rotY(float[] m, float a, float tx, float ty, float tz) {
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        m[0] = c; m[1] = 0; m[2] = s; m[3] = tx;
        m[4] = 0; m[5] = 1; m[6] = 0; m[7] = ty;
        m[8] = -s; m[9] = 0; m[10] = c; m[11] = tz;
    }

    /** Rotation about the local +X axis through pivot (py, pz) (positive angle pitches the head toward +z). */
    static void rotXPivot(float[] m, float a, float py, float pz) {
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        m[0] = 1; m[1] = 0; m[2] = 0; m[3] = 0;
        m[4] = 0; m[5] = c; m[6] = -s; m[7] = py - (c * py - s * pz);
        m[8] = 0; m[9] = s; m[10] = c; m[11] = pz - (s * py + c * pz);
    }

    /** out = a * b  (b is applied first). out may not alias a or b. */
    static void mul(float[] a, float[] b, float[] out) {
        for (int r = 0; r < 3; r++) {
            int o = r * 4;
            out[o] = a[o] * b[0] + a[o + 1] * b[4] + a[o + 2] * b[8];
            out[o + 1] = a[o] * b[1] + a[o + 1] * b[5] + a[o + 2] * b[9];
            out[o + 2] = a[o] * b[2] + a[o + 1] * b[6] + a[o + 2] * b[10];
            out[o + 3] = a[o] * b[3] + a[o + 1] * b[7] + a[o + 2] * b[11] + a[o + 3];
        }
    }

    void setModel(float[] m) {
        System.arraycopy(m, 0, M, 0, 12);
    }

    // ---- primitives ----------------------------------------------------------------------------
    /** Tapered capsule from A (radius r0) to B (radius r1), in model-local coordinates. */
    void limb(float ax, float ay, float az, float bx, float by, float bz, float r0, float r1,
              int tone, float base, float spec) {
        float Ax = M[0] * ax + M[1] * ay + M[2] * az + M[3];
        float Ay = M[4] * ax + M[5] * ay + M[6] * az + M[7];
        float Az = M[8] * ax + M[9] * ay + M[10] * az + M[11];
        float Bx = M[0] * bx + M[1] * by + M[2] * bz + M[3];
        float By = M[4] * bx + M[5] * by + M[6] * bz + M[7];
        float Bz = M[8] * bx + M[9] * by + M[10] * bz + M[11];
        float dx = Bx - Ax, dy = By - Ay, dz = Bz - Az;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0e-4f) {
            len = 1.0e-4f;
            dx = 0.0f; dy = 1.0f; dz = 0.0f;
        } else {
            dx /= len; dy /= len; dz /= len;
        }
        // perpendicular basis
        float hx = 0.0f, hy = 0.0f, hz = 1.0f;
        if (Math.abs(dz) > 0.9f) { hx = 1.0f; hz = 0.0f; }
        float e1x = dy * hz - dz * hy, e1y = dz * hx - dx * hz, e1z = dx * hy - dy * hx;
        float e1n = (float) Math.sqrt(e1x * e1x + e1y * e1y + e1z * e1z) + 1.0e-9f;
        e1x /= e1n; e1y /= e1n; e1z /= e1n;
        float e2x = dy * e1z - dz * e1y, e2y = dz * e1x - dx * e1z, e2z = dx * e1y - dy * e1x;
        float tilt = (r0 - r1) / len;
        int v = 0;
        for (int i = 0; i < LMB_RINGS; i++) {
            boolean capA = i < 4;
            float r = capA ? r0 : r1;
            float cx = capA ? Ax : Bx, cy = capA ? Ay : By, cz = capA ? Az : Bz;
            float ce = LMB_COS[i], se = LMB_SIN[i];
            for (int j = 0; j < LMB_SEGS; j++) {
                float rx = e1x * SEG_C[j] + e2x * SEG_S[j];
                float ry = e1y * SEG_C[j] + e2y * SEG_S[j];
                float rz = e1z * SEG_C[j] + e2z * SEG_S[j];
                wx[v] = cx + (rx * ce + dx * se) * r;
                wy[v] = cy + (ry * ce + dy * se) * r;
                wz[v] = cz + (rz * ce + dz * se) * r;
                float tl = ce * tilt;
                float qx = rx * ce + dx * (se + tl);
                float qy = ry * ce + dy * (se + tl);
                float qz = rz * ce + dz * (se + tl);
                float qn = 1.0f / ((float) Math.sqrt(qx * qx + qy * qy + qz * qz) + 1.0e-9f);
                nx[v] = qx * qn; ny[v] = qy * qn; nzz[v] = qz * qn;
                v++;
            }
        }
        float midD = ((Ay + By) * 0.5f) * sinP + ((Az + Bz) * 0.5f) * cosP;
        render(v, LMB_I, LMB_I.length / 3, tone, base, spec, midD);
    }

    /** Ellipsoid centred at C with half-axes (rx,ry,rz) along the model axes. */
    void ell(float cx, float cy, float cz, float rx, float ry, float rz, int tone, float base, float spec) {
        ellOri(cx, cy, cz, 1, 0, 0, 0, 1, 0, 0, 0, 1, rx, ry, rz, tone, base, spec);
    }

    /** Ellipsoid with explicit local axes: R (radius rx), U (radius ry), F (radius rz). Axes must be orthonormal. */
    void ellOri(float cx, float cy, float cz,
                float Rx, float Ry, float Rz, float Ux, float Uy, float Uz, float Fx, float Fy, float Fz,
                float rx, float ry, float rz, int tone, float base, float spec) {
        orient(cx, cy, cz, Rx, Ry, Rz, Ux, Uy, Uz, Fx, Fy, Fz);
        int v = 0;
        for (int i = 0; i < SPH_V; i++) {
            float px = SPH_P[i * 3], py = SPH_P[i * 3 + 1], pz = SPH_P[i * 3 + 2];
            placeScaled(v, px * rx, py * ry, pz * rz, px / rx, py / ry, pz / rz);
            v++;
        }
        render(v, SPH_I, SPH_I.length / 3, tone, base, spec, oDepth);
    }

    /** Box with half-extents (hx,hy,hz) and local axes R,U,F. */
    void box(float cx, float cy, float cz,
             float Rx, float Ry, float Rz, float Ux, float Uy, float Uz, float Fx, float Fy, float Fz,
             float hx, float hy, float hz, int tone, float base, float spec) {
        orient(cx, cy, cz, Rx, Ry, Rz, Ux, Uy, Uz, Fx, Fy, Fz);
        int v = 0;
        for (int i = 0; i < 24; i++) {
            placeScaled(v, BOX_P[i * 3] * hx, BOX_P[i * 3 + 1] * hy, BOX_P[i * 3 + 2] * hz,
                    BOX_N[i * 3] / hx, BOX_N[i * 3 + 1] / hy, BOX_N[i * 3 + 2] / hz);
            v++;
        }
        render(v, BOX_I, 12, tone, base, spec, oDepth);
    }


    /** Ellipsoid whose forward axis (radius rz) points along (fx,fy,fz); its up axis (radius ry) is as close to +y as possible. */
    void ellDir(float cx, float cy, float cz, float fx, float fy, float fz, float rx, float ry, float rz,
                int tone, float base, float spec) {
        float n = (float) Math.sqrt(fx * fx + fy * fy + fz * fz) + 1.0e-9f;
        fx /= n; fy /= n; fz /= n;
        float ux = 0.0f, uy = 1.0f, uz = 0.0f;
        if (Math.abs(fy) > 0.95f) { uy = 0.0f; uz = -1.0f; }
        float d = ux * fx + uy * fy + uz * fz;
        ux -= fx * d; uy -= fy * d; uz -= fz * d;
        float un = (float) Math.sqrt(ux * ux + uy * uy + uz * uz) + 1.0e-9f;
        ux /= un; uy /= un; uz /= un;
        float Rx = uy * fz - uz * fy, Ry = uz * fx - ux * fz, Rz = ux * fy - uy * fx;
        ellOri(cx, cy, cz, Rx, Ry, Rz, ux, uy, uz, fx, fy, fz, rx, ry, rz, tone, base, spec);
    }

    /** Model-local point -> rig coordinates used by the game's 2D overlays: out[0] = x, out[1] = screen-up (units above the ground row). */
    void screenOf(float x, float y, float z, float[] out) {
        float X = M[0] * x + M[1] * y + M[2] * z + M[3];
        float Y = M[4] * x + M[5] * y + M[6] * z + M[7];
        float Z = M[8] * x + M[9] * y + M[10] * z + M[11];
        out[0] = X;
        out[1] = Y * cosP - Z * sinP;
    }

    // oriented-primitive scratch: world-space centre and axes
    private float oCx, oCy, oCz, oRx, oRy, oRz, oUx, oUy, oUz, oFx, oFy, oFz, oDepth;

    private void orient(float cx, float cy, float cz,
                        float Rx, float Ry, float Rz, float Ux, float Uy, float Uz, float Fx, float Fy, float Fz) {
        oCx = M[0] * cx + M[1] * cy + M[2] * cz + M[3];
        oCy = M[4] * cx + M[5] * cy + M[6] * cz + M[7];
        oCz = M[8] * cx + M[9] * cy + M[10] * cz + M[11];
        oRx = M[0] * Rx + M[1] * Ry + M[2] * Rz; oRy = M[4] * Rx + M[5] * Ry + M[6] * Rz; oRz = M[8] * Rx + M[9] * Ry + M[10] * Rz;
        oUx = M[0] * Ux + M[1] * Uy + M[2] * Uz; oUy = M[4] * Ux + M[5] * Uy + M[6] * Uz; oUz = M[8] * Ux + M[9] * Uy + M[10] * Uz;
        oFx = M[0] * Fx + M[1] * Fy + M[2] * Fz; oFy = M[4] * Fx + M[5] * Fy + M[6] * Fz; oFz = M[8] * Fx + M[9] * Fy + M[10] * Fz;
        oDepth = oCy * sinP + oCz * cosP;
    }

    /** Position = C + R*a + U*b + F*c; normal = normalize(R*na + U*nb + F*nc) (inverse-scaled normal). */
    private void placeScaled(int v, float a, float b, float c, float na, float nb, float nc) {
        wx[v] = oCx + oRx * a + oUx * b + oFx * c;
        wy[v] = oCy + oRy * a + oUy * b + oFy * c;
        wz[v] = oCz + oRz * a + oUz * b + oFz * c;
        float qx = oRx * na + oUx * nb + oFx * nc;
        float qy = oRy * na + oUy * nb + oFy * nc;
        float qz = oRz * na + oUz * nb + oFz * nc;
        float qn = 1.0f / ((float) Math.sqrt(qx * qx + qy * qy + qz * qz) + 1.0e-9f);
        nx[v] = qx * qn; ny[v] = qy * qn; nzz[v] = qz * qn;
    }

    // ---- rasteriser ----------------------------------------------------------------------------
    private void render(int nv, int[] idx, int nt, int tone, float base, float spec, float centerDepth) {
        // project
        for (int i = 0; i < nv; i++) {
            float su = wy[i] * cosP - wz[i] * sinP;        // screen up
            spx[i] = opx + wx[i] * pxx;
            spy[i] = opy - su * pxy;
            sd[i] = wy[i] * sinP + wz[i] * cosP;           // depth toward viewer
            vnx[i] = nx[i];
            vny[i] = ny[i] * cosP - nzz[i] * sinP;
            vnz[i] = ny[i] * sinP + nzz[i] * cosP;
        }
        // gentle depth cue: parts further from the camera (relative to the model origin) are a touch darker
        float cue = 0.86f + 0.14f * Math.max(0.0f, Math.min(1.0f, (centerDepth + 0.45f) / 0.9f));
        final float mul = base * cue;
        final byte tb = (byte) tone;
        for (int t = 0; t < nt; t++) {
            int i0 = idx[t * 3], i1 = idx[t * 3 + 1], i2 = idx[t * 3 + 2];
            float x0 = spx[i0], y0 = spy[i0], x1 = spx[i1], y1 = spy[i1], x2 = spx[i2], y2 = spy[i2];
            float area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
            if (cull ? area >= -1.0e-7f : Math.abs(area) < 1.0e-7f) continue;
            float inv = 1.0f / area;
            int ix0 = (int) Math.floor(Math.min(x0, Math.min(x1, x2)) - 0.5f);
            int ix1 = (int) Math.ceil(Math.max(x0, Math.max(x1, x2)) - 0.5f);
            int iy0 = (int) Math.floor(Math.min(y0, Math.min(y1, y2)) - 0.5f);
            int iy1 = (int) Math.ceil(Math.max(y0, Math.max(y1, y2)) - 0.5f);
            if (ix0 < 0) ix0 = 0;
            if (iy0 < 0) iy0 = 0;
            if (ix1 > W - 1) ix1 = W - 1;
            if (iy1 > H - 1) iy1 = H - 1;
            if (ix0 > ix1 || iy0 > iy1) continue;
            float d0 = sd[i0], d1 = sd[i1], d2 = sd[i2];
            float ax0 = vnx[i0], ay0 = vny[i0], az0 = vnz[i0];
            float ax1 = vnx[i1], ay1 = vny[i1], az1 = vnz[i1];
            float ax2 = vnx[i2], ay2 = vny[i2], az2 = vnz[i2];
            for (int y = iy0; y <= iy1; y++) {
                float py = y + 0.5f;
                int row = y * W;
                for (int x = ix0; x <= ix1; x++) {
                    float px = x + 0.5f;
                    float w0 = ((x1 - px) * (y2 - py) - (x2 - px) * (y1 - py)) * inv;
                    float w1 = ((x2 - px) * (y0 - py) - (x0 - px) * (y2 - py)) * inv;
                    float w2 = 1.0f - w0 - w1;
                    if (w0 < -0.002f || w1 < -0.002f || w2 < -0.002f) continue;
                    float d = w0 * d0 + w1 * d1 + w2 * d2;
                    int p = row + x;
                    if (d <= zbuf[p]) continue;
                    float qx = w0 * ax0 + w1 * ax1 + w2 * ax2;
                    float qy = w0 * ay0 + w1 * ay1 + w2 * ay2;
                    float qz = w0 * az0 + w1 * az1 + w2 * az2;
                    float qi = 1.0f / ((float) Math.sqrt(qx * qx + qy * qy + qz * qz) + 1.0e-9f);
                    qx *= qi; qy *= qi; qz *= qi;
                    float dif = qx * LX + qy * LY + qz * LZ;
                    if (dif < 0.0f) dif = 0.0f;
                    float rimT = 1.0f - Math.max(0.0f, qz);
                    float lum = 0.20f + 0.80f * dif + 0.20f * rimT * rimT * (qy > -0.2f ? 1.0f : 0.4f);
                    lum *= mul;
                    if (spec > 0.0f) {
                        float hh = qx * HX + qy * HY + qz * HZ;
                        if (hh > 0.0f) {
                            hh *= hh; hh *= hh; hh *= hh; hh *= hh;     // ^16
                            lum += spec * hh;
                        }
                    }
                    zbuf[p] = d;
                    lbuf[p] = lum;
                    tbuf[p] = tb;
                }
            }
        }
    }

    // ---- 3D -> ASCII ---------------------------------------------------------------------------
    static int toneColor(int tone, float light) {
        int v = Math.max(52, Math.min(252, (int) (44.0f + light * 235.0f)));
        int rr = v, gg = v, bb = v + 6;
        switch (tone) {
            case T_STEEL: rr = v + 10; gg = v + 10; bb = v + 16; break;
            case T_SKIN: rr = v + 24; gg = v + 8; bb = v - 14; break;
            case T_CLOTH: rr = v + 40; gg = v / 4; bb = v / 4; break;
            case T_LEATHER: rr = v + 8; gg = v - 4; bb = v - 24; break;
            case T_HAIR: rr = v + 12; gg = v + 12; bb = v + 18; break;
            case T_FIRE: rr = 255; gg = 150 + v / 3; bb = 40 + v / 8; break;
            case T_COAT: rr = v + 6; gg = v + 6; bb = v + 12; break;
            case T_HOOF: rr = v - 6; gg = v - 14; bb = v - 26; break;
            case T_DARK: rr = v - 20; gg = v - 20; bb = v - 14; break;
            case T_GOLD: rr = v + 30; gg = v + 12; bb = v / 3; break;
            case T_BLANKET: rr = v + 28; gg = v / 3; bb = v / 3 + 12; break;
            default: break;
        }
        return 0xFF000000 | (clamp255(rr) << 16) | (clamp255(gg) << 8) | clamp255(bb);
    }

    private static int clamp255(int v) {
        return v < 0 ? 0 : (v > 255 ? 255 : v);
    }

    /**
     * Converts the 3D render into the game's glyph buffers.  Each glyph cell averages its ssx*ssy samples:
     * coverage decides whether a glyph is drawn at all (and softens silhouettes), shaded luminance picks the glyph
     * from the density ramp, and the front-most material picks the colour.
     * @param occ optional per-cell occupancy output (set to 1 where a glyph was written, else -9)
     */
    void toAscii(char[] g, float[] lumOut, int[] colOut, float[] occ, String ramp) {
        final int n = ramp.length();
        final float full = ssx * ssy;
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int cell = r * cols + c;
                int cnt = 0;
                float sum = 0.0f, zmax = EMPTY;
                int tone = 0;
                for (int sj = 0; sj < ssy; sj++) {
                    int rowBase = (r * ssy + sj) * W + c * ssx;
                    for (int si = 0; si < ssx; si++) {
                        float z = zbuf[rowBase + si];
                        if (z > EMPTY) {
                            cnt++;
                            sum += lbuf[rowBase + si];
                            if (z > zmax) {
                                zmax = z;
                                tone = tbuf[rowBase + si];
                            }
                        }
                    }
                }
                float cov = cnt / full;
                if (cov < 0.26f) {
                    g[cell] = ' ';
                    lumOut[cell] = -1.0f;
                    if (occ != null) occ[cell] = -9.0f;
                    continue;
                }
                float light = sum / cnt;
                light *= 0.64f + 0.36f * Math.min(1.0f, cov * 1.15f);     // soften partially covered (silhouette) cells
                if (light > 1.0f) light = 1.0f;
                int ri = Math.max(1, Math.min(n - 1, (int) (light * (n - 1) + 0.5f)));
                char ch = ramp.charAt(ri);
                if (tone == T_HAIR) {
                    ch = HAIR_GLYPHS.charAt(((r * 7 + c * 13) & 0x7fffffff) % HAIR_GLYPHS.length());
                }
                g[cell] = ch;
                lumOut[cell] = light;
                colOut[cell] = toneColor(tone, light);
                if (occ != null) occ[cell] = 1.0f;
            }
        }
    }
}
