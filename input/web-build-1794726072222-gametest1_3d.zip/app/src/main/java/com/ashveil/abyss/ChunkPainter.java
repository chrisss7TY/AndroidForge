package com.ashveil.abyss;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;

import java.util.Random;

/**
 * Paints one 4x4-unit chunk of ground (grass, tint, water, rock faces, flowers) into a bitmap.
 *
 * This used to run on the render thread, and a single chunk costs 10-40 ms (hundreds of software
 * drawText calls), so every new chunk was a visible hitch. It now lives in its own class with its
 * own scratch buffers so one background thread can own it: nothing here touches the view's state.
 * Everything painted is a pure function of (seed, chunk), so a chunk can be rebuilt identically.
 */
final class ChunkPainter {
    static final int MEADOW_TILE_PX = 1536;
    static final float CHUNK_WORLD_UNITS = 4.0f;
    static final int CHUNK_PX = 384;
    static final int CHUNK_CELLS = 24;
    static final int MASK_PX = CHUNK_CELLS * 4;

    private static final String[] GROUND_ASCII = new String[]{
            "0Q8B", "QQ0O", "80aa", "qQ80", "b0Q8", "O08Q"
    };

    private Bitmap mMeadowTileBitmap = null;
    private final Random mRng = new Random();
    private final Rect mSrcRect = new Rect();
    private final RectF mTmpRect = new RectF();
    private final char[] mSingleChar = new char[1];
    private final float[] mSample = new float[3];
    private final java.util.ArrayList<WorldGen.Obj> mChunkObjs = new java.util.ArrayList<WorldGen.Obj>();

    private Bitmap mTintBitmap = null;
    private final int[] mTintPx = new int[CHUNK_CELLS * CHUNK_CELLS];
    private final float[] mLatCliff = new float[(CHUNK_CELLS + 1) * (CHUNK_CELLS + 1)];
    private final float[] mLatWater = new float[(CHUNK_CELLS + 1) * (CHUNK_CELLS + 1)];
    private final float[] mLatMoist = new float[(CHUNK_CELLS + 1) * (CHUNK_CELLS + 1)];
    private final boolean[] mSolid = new boolean[CHUNK_CELLS * CHUNK_CELLS];
    private final boolean[] mWet = new boolean[CHUNK_CELLS * CHUNK_CELLS];
    private Bitmap mWaterMask = null;
    private Bitmap mCliffMask = null;
    private final int[] mMaskPx = new int[MASK_PX * MASK_PX];
    private final float[] mFoamDim = new float[900 * 4];

    private final Paint mGrassPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mChunkBgPaint = new Paint();
    private final Paint mChunkTxtPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mTintPaint = new Paint(Paint.FILTER_BITMAP_FLAG);

    ChunkPainter() {
        mGrassPaint.setStyle(Paint.Style.STROKE);
        mGrassPaint.setStrokeCap(Paint.Cap.ROUND);
        mChunkBgPaint.setStyle(Paint.Style.FILL);
        mChunkTxtPaint.setTypeface(Typeface.MONOSPACE);
        mChunkTxtPaint.setFakeBoldText(true);
    }

    private Bitmap meadow() {
        if (mMeadowTileBitmap == null) mMeadowTileBitmap = Gfx.grassTile(MEADOW_TILE_PX);
        return mMeadowTileBitmap;
    }

    /** Warm up the (slow) seamless grass tile so the first real chunk is not delayed by it. */
    void warmUp() {
        meadow();
    }

    /** Paints chunk (cxIdx, cyIdx) of world g into target (CHUNK_PX x CHUNK_PX, ARGB_8888). */
    void paint(Bitmap target, WorldGen g, int cxIdx, int cyIdx) {
        paintChunk(new Canvas(target), g, cxIdx, cyIdx);
    }

    /**
     * Water you can wade through (depth below WorldGen's 0.36 "deep" threshold) is a lighter teal that
     * darkens gently toward the drop-off; a thin bright ripple marks the edge, and beyond it the water
     * is dark navy. Before, deep and shallow water were almost the same colour, so the deep-water
     * barrier felt like an invisible wall in the middle of a lake.
     */
    private static int waterColor(float d, int jitter) {
        final float deep = WorldGen.DEEP_WATER;
        int r, g, b;
        if (d < deep) {
            float t = Math.max(0.0f, d / deep);
            r = (int) (34 + (18 - 34) * t);
            g = (int) (78 + (50 - 78) * t);
            b = (int) (88 + (78 - 88) * t);
            float rim = Math.max(0.0f, 1.0f - (deep - d) / 0.035f);   // brightest right at the drop-off
            r += (int) (26 * rim);
            g += (int) (40 * rim);
            b += (int) (44 * rim);
        } else {
            float t = Math.max(0.0f, Math.min(1.0f, (d - deep) / 0.12f));
            r = (int) (7 + (3 - 7) * t);
            g = (int) (16 + (7 - 16) * t);
            b = (int) (34 + (16 - 34) * t);
        }
        r += jitter;
        g += jitter;
        b += jitter + 1;
        return Color.rgb(Math.max(0, Math.min(255, r)), Math.max(0, Math.min(255, g)), Math.max(0, Math.min(255, b)));
    }

    private static float bilerp(float a, float b, float c, float d, float fx, float fy) {
        float top = a + (b - a) * fx;
        float bot = c + (d - c) * fx;
        return top + (bot - top) * fy;
    }

    private boolean solidCell(WorldGen g, int i, int j, float baseWx, float baseWy, float upc) {
        int n = CHUNK_CELLS;
        if (i >= 0 && j >= 0 && i < n && j < n) return mSolid[j * n + i];
        return g.cliff(baseWx + (i + 0.5f) * upc, baseWy + (j + 0.5f) * upc) > WorldGen.CLIFF_LEVEL;
    }

    /**
     * Paints one 4x4-unit chunk of ground: fine-blade grass, moisture tint, water, rock faces,
     * shore reeds, flower clusters. Everything comes from the seeded generator, so a chunk can
     * be thrown away and rebuilt identically at any time.
     */

    private void paintChunk(Canvas cc, WorldGen g, int cxIdx, int cyIdx) {
        final int n = CHUNK_CELLS;
        final int lat = n + 1;
        final float cellPx = CHUNK_PX / (float) n;
        final float baseWx = cxIdx * CHUNK_WORLD_UNITS;
        final float baseWy = cyIdx * CHUNK_WORLD_UNITS;
        final float upc = CHUNK_WORLD_UNITS / n;
        final float cliffLvl = WorldGen.CLIFF_LEVEL;
        final float wetEps = 0.012f;

        // 0) lattice of terrain samples at cell corners
        for (int j = 0; j <= n; j++) {
            for (int i = 0; i <= n; i++) {
                g.sample(baseWx + i * upc, baseWy + j * upc, mSample);
                int k = j * lat + i;
                mLatCliff[k] = mSample[0];
                mLatWater[k] = mSample[1];
                mLatMoist[k] = mSample[2];
            }
        }

        // 1) grass: world-aligned window of the seamless blade tile (so chunks join without seams),
        //    plus a few unique accent blades per chunk to break up the tile's repetition
        long hb = g.hashBits(cxIdx, cyIdx, 900);
        int tilesPerSide = MEADOW_TILE_PX / CHUNK_PX;
        int qx = Math.floorMod(cxIdx, tilesPerSide);
        int qy = Math.floorMod(cyIdx, tilesPerSide);
        mSrcRect.set(qx * CHUNK_PX, qy * CHUNK_PX, (qx + 1) * CHUNK_PX, (qy + 1) * CHUNK_PX);
        mTmpRect.set(0, 0, CHUNK_PX, CHUNK_PX);
        cc.drawBitmap(meadow(), mSrcRect, mTmpRect, null);
        mRng.setSeed(hb ^ 0xB1ADEL);
        for (int pass = 0; pass < 2; pass++) {
            int cntB = 0;
            for (int q = 0; q < 380; q++) {
                float bx = mRng.nextFloat() * CHUNK_PX;
                float by = 8.0f + mRng.nextFloat() * (CHUNK_PX - 8.0f);
                float len = 9.0f + mRng.nextFloat() * 9.0f;
                float lean = 1.0f + (mRng.nextFloat() - 0.5f) * 4.0f;
                mFoamDim[cntB++] = bx;
                mFoamDim[cntB++] = by;
                mFoamDim[cntB++] = bx + lean;
                mFoamDim[cntB++] = by - len;
            }
            mGrassPaint.setStrokeWidth(1.4f);
            mGrassPaint.setColor(pass == 0 ? Color.rgb(22, 52, 40) : Color.rgb(52, 98, 74));
            cc.drawLines(mFoamDim, 0, cntB, mGrassPaint);
        }

        // 2) smooth tint: lush groves, dry moor, darker highlands (bilinear-scaled, so no seams)
        for (int j = 0; j < n; j++) {
            for (int i = 0; i < n; i++) {
                int k = j * lat + i;
                float m = (mLatMoist[k] + mLatMoist[k + 1] + mLatMoist[k + lat] + mLatMoist[k + lat + 1]) * 0.25f;
                float cl = (mLatCliff[k] + mLatCliff[k + 1] + mLatCliff[k + lat] + mLatCliff[k + lat + 1]) * 0.25f;
                float wet = Math.max(-1.0f, Math.min(1.0f, (m - 0.5f) * 2.6f));
                int r;
                int gg;
                int b;
                int a;
                if (wet > 0.0f) {
                    r = 22;
                    gg = 84;
                    b = 40;
                    a = (int) (74.0f * wet);
                } else {
                    r = 52;
                    gg = 50;
                    b = 34;
                    a = (int) (96.0f * -wet);
                }
                float hi = Math.max(0.0f, Math.min(1.0f, (cl - 0.50f) / 0.15f));
                int a2 = (int) (135.0f * hi);
                if (a2 > 0) {
                    float w = a2 / (float) (a + a2 + 1);
                    r = (int) (r + (6 - r) * w);
                    gg = (int) (gg + (10 - gg) * w);
                    b = (int) (b + (12 - b) * w);
                    a = Math.max(a, a2);
                }
                mTintPx[j * n + i] = Color.argb(a, r, gg, b);
            }
        }
        if (mTintBitmap == null) {
            mTintBitmap = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888);
        }
        mTintBitmap.setPixels(mTintPx, 0, n, 0, 0, n, n);
        mTmpRect.set(0, 0, CHUNK_PX, CHUNK_PX);
        cc.drawBitmap(mTintBitmap, null, mTmpRect, mTintPaint);

        // 3) classify cells
        for (int j = 0; j < n; j++) {
            for (int i = 0; i < n; i++) {
                int k = j * lat + i;
                float cl = (mLatCliff[k] + mLatCliff[k + 1] + mLatCliff[k + lat] + mLatCliff[k + lat + 1]) * 0.25f;
                float wd = (mLatWater[k] + mLatWater[k + 1] + mLatWater[k + lat] + mLatWater[k + lat + 1]) * 0.25f;
                mSolid[j * n + i] = cl > cliffLvl;
                mWet[j * n + i] = wd > 0.008f;
            }
        }

        // 3b) water and rock as smooth masks: interpolate the corner samples at 4x resolution and let
        //     bilinear scaling soften the edge, so shorelines and cliff faces are not blocky
        float minW = 9.0f, maxW = -9.0f, maxC = -9.0f;
        for (int q = 0; q < lat * lat; q++) {
            if (mLatWater[q] > maxW) maxW = mLatWater[q];
            if (mLatWater[q] < minW) minW = mLatWater[q];
            if (mLatCliff[q] > maxC) maxC = mLatCliff[q];
        }
        mTmpRect.set(0, 0, CHUNK_PX, CHUNK_PX);
        if (maxW > wetEps) {
            if (mWaterMask == null) mWaterMask = Bitmap.createBitmap(MASK_PX, MASK_PX, Bitmap.Config.ARGB_8888);
            for (int my = 0; my < MASK_PX; my++) {
                int j = my >> 2;
                float fy = ((my & 3) + 0.5f) / 4.0f;
                for (int mx = 0; mx < MASK_PX; mx++) {
                    int i = mx >> 2;
                    float fx = ((mx & 3) + 0.5f) / 4.0f;
                    int k = j * lat + i;
                    float d = bilerp(mLatWater[k], mLatWater[k + 1], mLatWater[k + lat], mLatWater[k + lat + 1], fx, fy);
                    float a = (d - 0.004f) / 0.018f;
                    if (a <= 0.0f) {
                        mMaskPx[my * MASK_PX + mx] = 0;
                    } else {
                        int jit = (((cxIdx * n + i) * 7 + (cyIdx * n + j) * 13) & 7) - 3;
                        int col = waterColor(d, jit);
                        mMaskPx[my * MASK_PX + mx] = (col & 0x00FFFFFF) | ((int) (Math.min(1.0f, a) * 255.0f) << 24);
                    }
                }
            }
            mWaterMask.setPixels(mMaskPx, 0, MASK_PX, 0, 0, MASK_PX, MASK_PX);
            cc.drawBitmap(mWaterMask, null, mTmpRect, mTintPaint);
        }
        if (maxC > cliffLvl - 0.006f) {
            if (mCliffMask == null) mCliffMask = Bitmap.createBitmap(MASK_PX, MASK_PX, Bitmap.Config.ARGB_8888);
            for (int my = 0; my < MASK_PX; my++) {
                int j = my >> 2;
                float fy = ((my & 3) + 0.5f) / 4.0f;
                for (int mx = 0; mx < MASK_PX; mx++) {
                    int i = mx >> 2;
                    float fx = ((mx & 3) + 0.5f) / 4.0f;
                    int k = j * lat + i;
                    float v = bilerp(mLatCliff[k], mLatCliff[k + 1], mLatCliff[k + lat], mLatCliff[k + lat + 1], fx, fy);
                    float a = (v - (cliffLvl - 0.006f)) / 0.012f;
                    mMaskPx[my * MASK_PX + mx] = (a <= 0.0f) ? 0 : 0x00040608 | ((int) (Math.min(1.0f, a) * 255.0f) << 24);
                }
            }
            mCliffMask.setPixels(mMaskPx, 0, MASK_PX, 0, 0, MASK_PX, MASK_PX);
            cc.drawBitmap(mCliffMask, null, mTmpRect, mTintPaint);
        }

        mChunkObjs.clear();
        g.objectsIn(baseWx, baseWy, baseWx + CHUNK_WORLD_UNITS, baseWy + CHUNK_WORLD_UNITS, mChunkObjs);
        boolean haveHouse = false;
        for (int q = 0; q < mChunkObjs.size(); q++) {
            if (mChunkObjs.get(q).kind == WorldGen.HOUSE) haveHouse = true;
        }

        Paint bg = mChunkBgPaint;
        Paint tx = mChunkTxtPaint;
        tx.setTextAlign(Paint.Align.LEFT);
        tx.setTextSize(cellPx * 1.0f);
        final float sub = cellPx / 4.0f;
        final int nChars = Gfx.ROCK_CHARS.length();

        for (int j = 0; j < n; j++) {
            for (int i = 0; i < n; i++) {
                int k = j * lat + i;
                float px = i * cellPx;
                float py = j * cellPx;
                float w00 = mLatWater[k];
                float w10 = mLatWater[k + 1];
                float w01 = mLatWater[k + lat];
                float w11 = mLatWater[k + lat + 1];
                float c00 = mLatCliff[k];
                float c10 = mLatCliff[k + 1];
                float c01 = mLatCliff[k + lat];
                float c11 = mLatCliff[k + lat + 1];
                int gi = cxIdx * n + i;
                int gj = cyIdx * n + j;
                int ch = Math.abs((gi * 73856093) ^ (gj * 19349663));
                boolean anyW = w00 > wetEps || w10 > wetEps || w01 > wetEps || w11 > wetEps;
                boolean allW = w00 > wetEps && w10 > wetEps && w01 > wetEps && w11 > wetEps;
                boolean anyC = c00 > cliffLvl || c10 > cliffLvl || c01 > cliffLvl || c11 > cliffLvl;
                boolean allC = c00 > cliffLvl && c10 > cliffLvl && c01 > cliffLvl && c11 > cliffLvl;
                boolean solid = mSolid[j * n + i];

                // ---- water glyph texture (the water itself is the mask drawn above)
                if (allW && ch % 5 == 0) {
                    tx.setColor(Color.argb(150, 56, 80, 116));
                    cc.drawText(GROUND_ASCII[ch % GROUND_ASCII.length], 0, 3, px, py + cellPx * 0.85f, tx);
                }

                // ---- rock face
                if (anyC) {
                    if (solid) {
                        float gx = (c10 + c11 - c00 - c01) * 0.5f;
                        float gy = (c01 + c11 - c00 - c10) * 0.5f;
                        float sun = 0.5f - (gx + gy) * 38.0f;
                        float nz = (ch & 255) / 255.0f;
                        float lum = 0.42f + (sun - 0.5f) * 0.9f + (nz - 0.5f) * 0.28f;
                        if (!solidCell(g, i, j - 1, baseWx, baseWy, upc)) lum += 0.22f;
                        if (!solidCell(g, i, j + 1, baseWx, baseWy, upc) || !solidCell(g, i + 1, j, baseWx, baseWy, upc)) lum -= 0.16f;
                        lum = Math.max(0.16f, Math.min(1.0f, lum));
                        int idx = (int) ((1.0f - lum) * (nChars - 1) + (nz - 0.5f) * 3.0f);
                        idx = Math.max(0, Math.min(nChars - 1, idx));
                        int v = Math.max(70, Math.min(248, (int) (70.0f + lum * 175.0f)));
                        tx.setColor(Color.rgb(Math.max(0, v - 6), v, Math.min(255, v + 9)));
                        mSingleChar[0] = Gfx.ROCK_CHARS.charAt(idx);
                        cc.drawText(mSingleChar, 0, 1, px, py + cellPx * 0.86f, tx);
                    }
                } else if (!anyW) {
                    float cl = (c00 + c10 + c01 + c11) * 0.25f;
                    if (cl > cliffLvl - 0.05f) {
                        // rocky slope at the foot of a cliff
                        bg.setColor(Color.argb((int) (((cl - (cliffLvl - 0.05f)) / 0.05f) * 150.0f), 3, 6, 5));
                        cc.drawRect(px, py, px + cellPx + 0.5f, py + cellPx + 0.5f, bg);
                        if (ch % 100 < 40) {
                            tx.setColor(Color.argb(110, 74, 86, 98));
                            mSingleChar[0] = Gfx.ROCK_CHARS.charAt(14 + ch % 14);
                            cc.drawText(mSingleChar, 0, 1, px, py + cellPx * 0.86f, tx);
                        }
                    } else {
                        // soft shadow cast to the lower right of a cliff
                        if (solidCell(g, i - 1, j - 1, baseWx, baseWy, upc) || solidCell(g, i - 1, j, baseWx, baseWy, upc)
                                || solidCell(g, i, j - 1, baseWx, baseWy, upc)) {
                            bg.setColor(Color.argb(80, 2, 5, 4));
                            cc.drawRect(px, py, px + cellPx + 0.5f, py + cellPx + 0.5f, bg);
                        }
                        // reeds / pebbles on the bank
                        boolean bank = (i > 0 && mWet[j * n + i - 1]) || (i < n - 1 && mWet[j * n + i + 1])
                                || (j > 0 && mWet[(j - 1) * n + i]) || (j < n - 1 && mWet[(j + 1) * n + i]);
                        if (bank) {
                            if (ch % 3 == 0) {
                                tx.setColor(Color.rgb(92, 138, 86));
                                cc.drawText((ch % 2 == 0) ? "|" : "i", px, py + cellPx * 0.85f, tx);
                            } else if (ch % 5 == 0) {
                                tx.setColor(Color.rgb(108, 118, 126));
                                cc.drawText("o", px, py + cellPx * 0.85f, tx);
                            }
                        } else if (g.hash01(Math.floorDiv(gi, 3), Math.floorDiv(gj, 3), 910) > 0.87f && ch % 100 < 55) {
                            // sparse, dim ground-glyph patches (like the reference, not a carpet)
                            tx.setColor(Color.argb(105, 58, 78, 108));
                            cc.drawText(GROUND_ASCII[ch % GROUND_ASCII.length], px, py + cellPx * 0.85f, tx);
                        }
                        // worn path in front of cottage doors
                        if (haveHouse) {
                            float wx = baseWx + (i + 0.5f) * upc;
                            float wy = baseWy + (j + 0.5f) * upc;
                            for (int q = 0; q < mChunkObjs.size(); q++) {
                                WorldGen.Obj o = mChunkObjs.get(q);
                                if (o.kind == WorldGen.HOUSE && Math.abs(wx - o.x) < 0.72f && wy > o.y + 0.5f && wy < o.y + 2.8f) {
                                    bg.setColor(Color.argb(150, 26, 22, 18));
                                    cc.drawRect(px, py, px + cellPx + 0.5f, py + cellPx + 0.5f, bg);
                                    tx.setColor((ch % 2 == 0) ? Color.rgb(112, 102, 88) : Color.rgb(86, 78, 68));
                                    cc.drawText((ch % 3 == 0) ? ":" : ".", px, py + cellPx * 0.85f, tx);
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4) flowers: white star/ring sprinkles everywhere, lavender & pale-blue clusters in damp ground
        mRng.setSeed(hb ^ 0x51F0E5L);
        float moistAvg = mLatMoist[(n / 2) * lat + n / 2];
        int sprinkles = 22 + (int) (moistAvg * 34.0f);
        for (int f = 0; f < sprinkles; f++) {
            float fx = mRng.nextFloat() * CHUNK_PX;
            float fy = mRng.nextFloat() * CHUNK_PX;
            if (!landAt(fx, fy, cellPx)) continue;
            float kind = mRng.nextFloat();
            tx.setTextSize(kind < 0.58f ? 10.0f : 9.0f);
            tx.setColor(Color.rgb(8, 16, 10));
            cc.drawText(".", fx + 0.8f, fy + 1.6f, tx);
            if (kind < 0.58f) {
                tx.setColor((f % 3 == 0) ? Color.rgb(246, 248, 235) : Color.rgb(232, 240, 250));
                cc.drawText("*", fx, fy, tx);
            } else if (kind < 0.84f) {
                tx.setColor(Color.rgb(206, 222, 236));
                cc.drawText("o", fx, fy, tx);
            } else {
                tx.setColor(Color.rgb(230, 236, 240));
                cc.drawText(".", fx, fy, tx);
            }
        }
        int clusters = (moistAvg > 0.56f ? 2 : 0) + (mRng.nextFloat() < 0.5f ? 1 : 0);
        for (int c = 0; c < clusters; c++) {
            float ccx = 24.0f + mRng.nextFloat() * (CHUNK_PX - 48.0f);
            float ccy = 24.0f + mRng.nextFloat() * (CHUNK_PX - 48.0f);
            int kind = mRng.nextInt(3);
            int cnt = 16 + mRng.nextInt(20);
            float rad = 30.0f + mRng.nextFloat() * 50.0f;
            int col = (kind == 0) ? Color.rgb(186, 152, 232) : (kind == 1 ? Color.rgb(164, 132, 214) : Color.rgb(214, 232, 255));
            for (int q = 0; q < cnt; q++) {
                float a = mRng.nextFloat() * 6.2832f;
                float r = (float) Math.sqrt(mRng.nextFloat()) * rad;
                float fx = ccx + (float) Math.cos(a) * r;
                float fy = ccy + (float) Math.sin(a) * r * 0.8f;
                if (!landAt(fx, fy, cellPx)) continue;
                tx.setTextSize(12.0f);
                tx.setColor(Color.rgb(8, 16, 10));
                cc.drawText(".", fx + 1.0f, fy + 2.0f, tx);
                tx.setColor(col);
                cc.drawText("*", fx, fy, tx);
            }
        }
    }


    private boolean landAt(float px, float py, float cellPx) {
        int i = (int) (px / cellPx);
        int j = (int) (py / cellPx);
        if (i < 0 || j < 0 || i >= CHUNK_CELLS || j >= CHUNK_CELLS) return false;
        return !mSolid[j * CHUNK_CELLS + i] && !mWet[j * CHUNK_CELLS + i];
    }

}
