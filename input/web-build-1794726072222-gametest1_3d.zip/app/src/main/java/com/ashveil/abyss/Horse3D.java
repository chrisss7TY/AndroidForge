package com.ashveil.abyss;

/**
 * The white steed as a real 3D model: barrel / haunch / chest, a neck and head that nod with the gait (and graze when idle),
 * four IK legs on a 4-beat walk that blends into a gallop, saddle + stirrups + bridle + reins, and a leaping dodge.
 * It also carries the {@link Knight3D} rider (seated), drawn into the same 3D scene.
 *
 * Local frame: +y up, +z forward (the head), +x = the horse's LEFT.  Ground at y = 0.
 */
final class Horse3D {
    private static final float PI = (float) Math.PI;
    static final float HB = 1.02f;          // barrel centre height

    // ---- inputs ----
    float time, facingX = 1.0f, facingY = 0.0f, velX, velY, gait, dodgeTimer;

    // ---- state ----
    float yaw = 1.5707963f;
    private boolean yawInit = false;
    private float lastT = 0.0f;

    // ---- pose output (local) ----
    final float[] rear = new float[3], front = new float[3];
    final float[] neckBase = new float[3], neckTop = new float[3], muzzle = new float[3], hd = new float[3], upH = new float[3];
    final float[][] hipJ = new float[4][3], kneeJ = new float[4][3], fetJ = new float[4][3], hoofJ = new float[4][3];
    final float[] earTip = new float[3];
    float seatY, seatZ, spring, nod, earFlick;
    final float[] tailRoot = new float[3], maneTop = new float[3], maneBase = new float[3];
    final float[] modelM = new float[12];
    final float[] reinTarget = new float[3];
    float topY;

    private static final float[] LEG_HIP_Z = {-0.52f, 0.50f, -0.52f, 0.50f};
    private static final float[] LEG_X = {0.165f, 0.17f, -0.165f, -0.17f};
    private static final float[] WALK_FRAC = {0.50f, 0.75f, 0.00f, 0.25f};
    private static final float[] GALLOP_FRAC = {0.00f, 0.50f, 0.12f, 0.62f};
    private static final float[] LEG_BRIGHT = {0.80f, 0.82f, 1.0f, 1.0f};

    private float fOff, fLift;

    private static float smooth01(float a, float b, float x) {
        return Knight3D.smooth01(a, b, x);
    }

    private static float mix(float a, float b, float t) {
        return a + (b - a) * t;
    }

    private static void set(float[] a, float x, float y, float z) {
        a[0] = x; a[1] = y; a[2] = z;
    }

    private void footCycle(float theta, float duty, float stride, float lift) {
        float u = theta / 6.2831853f;
        u -= (float) Math.floor(u);
        if (u < duty) {
            fOff = stride * (1.0f - 2.0f * u / duty);
            fLift = 0.0f;
        } else {
            float s = (u - duty) / (1.0f - duty);
            float e = s * s * (3.0f - 2.0f * s);
            fOff = -stride + 2.0f * stride * e;
            fLift = (float) Math.sin(Math.PI * s) * lift;
        }
    }

    /** Computes the whole pose, the rider's seat and the rein target. */
    void update(Knight3D rider) {
        final float t = time;
        float dt = Math.max(0.0f, Math.min(0.05f, t - lastT));
        lastT = t;
        float fl = (float) Math.sqrt(facingX * facingX + facingY * facingY);
        if (fl > 1.0e-4f) {
            float target = (float) Math.atan2(facingX / fl, facingY / fl);
            if (!yawInit) { yaw = target; yawInit = true; }
            float d = target - yaw;
            while (d > PI) d -= 2.0f * PI;
            while (d < -PI) d += 2.0f * PI;
            yaw += d * Math.min(1.0f, dt * 11.0f);
        }

        final float spd = (float) Math.sqrt(velX * velX + velY * velY);
        final float sf = Math.min(1.0f, spd / 4.6f);
        final float g = smooth01(0.40f, 0.82f, sf);          // 0 = walk, 1 = gallop
        final float mv = Math.min(1.0f, spd / 1.4f);         // 0 = standing
        final float ph = gait;
        final boolean dodging = dodgeTimer > 0.0f;
        final float p = dodging ? Math.max(0.0f, 1.0f - dodgeTimer / Knight3D.DODGE_DUR) : 0.0f;
        final float k = dodging ? smooth01(0.05f, 0.20f, p) * (1.0f - smooth01(0.82f, 0.97f, p)) : 0.0f;
        final float leap = dodging ? (float) Math.sin(Math.PI * p) * 0.30f : 0.0f;

        // ---- body motion (y up) ----
        float bobDown = 0.035f * mv * (1.0f - g) * (float) Math.cos(2.0f * ph) + 0.070f * mv * g * (float) Math.cos(ph + 0.6f);
        float pitch = (float) Math.sin(ph) * 0.07f * g * mv;
        float breathe = (float) Math.sin(t * 1.8f) * 0.012f * (1.0f - mv);
        float bodyUp = -bobDown + breathe + leap;
        set(rear, 0.0f, HB + bodyUp - pitch - 0.02f, -0.56f);
        set(front, 0.0f, HB + bodyUp + pitch + 0.05f * k, 0.52f + 0.08f * k);

        // ---- legs ----
        final float strideS = (0.18f + 0.22f * g) * mv;
        final float liftL = (0.13f + 0.13f * g) * mv;
        final float duty = mix(0.62f, 0.38f, g);
        float pawT = t % 8.0f;
        float paw = 0.0f;
        if (mv < 0.15f && pawT < 1.6f) {
            paw = Math.max(0.0f, (float) Math.sin(pawT * 10.0f)) * 0.18f * (float) Math.sin(Math.PI * pawT / 1.6f);
        }
        for (int leg = 0; leg < 4; leg++) {
            boolean frontLeg = (leg & 1) == 1;
            float frac = mix(WALK_FRAC[leg], GALLOP_FRAC[leg], g);
            footCycle(ph + frac * 6.2831853f, duty, strideS, liftL);
            float hipY = (frontLeg ? front[1] : rear[1]) - 0.06f;
            set(hipJ[leg], LEG_X[leg] * 0.95f, hipY, LEG_HIP_Z[leg]);
            float fx = LEG_X[leg] * 0.93f;
            float fy = 0.125f + fLift;
            float fz = LEG_HIP_Z[leg] + fOff;
            if (leg == 3) fy += paw;
            if (k > 0.0f) {
                fz = mix(fz, LEG_HIP_Z[leg] + (frontLeg ? 0.52f : -0.50f), k);
                fy = mix(fy, hipY - 0.46f, k);
            }
            set(fetJ[leg], fx, fy, fz);
            Knight3D.ik(hipJ[leg], fetJ[leg], 0.50f, 0.50f, 0.0f, 0.0f, frontLeg ? 1.0f : -1.0f, kneeJ[leg]);
            // hoof trails the fetlock slightly
            set(hoofJ[leg], fetJ[leg][0], Math.max(0.025f, fetJ[leg][1] - 0.095f), fetJ[leg][2] + 0.03f);
        }

        // ---- neck / head ----
        float nodV = (float) Math.sin(ph - 0.8f) * 0.07f * (0.3f + 0.7f * mv) * mv;
        float dipEnv = Math.max(0.0f, (float) Math.sin(t * 0.45f));
        float dip = dipEnv * dipEnv * 0.30f * (1.0f - mv);
        nod = nodV;
        set(neckBase, 0.0f, front[1] + 0.02f, front[2] - 0.04f);
        float upN = 0.54f - 0.16f * g - nodV - dip - 0.18f * k;
        float fwdN = 0.40f + 0.10f * g + 0.12f * k - dip * 0.5f;
        set(neckTop, 0.0f, neckBase[1] + upN, neckBase[2] + fwdN);
        float a = 0.78f + 0.32f * g + 0.15f * k - 1.9f * dip + 0.5f * nodV;
        set(hd, 0.0f, -(float) Math.cos(a), (float) Math.sin(a));
        set(upH, 0.0f, (float) Math.sin(a), (float) Math.cos(a));
        set(muzzle, neckTop[0] + hd[0] * 0.50f, neckTop[1] + hd[1] * 0.50f, neckTop[2] + hd[2] * 0.50f);
        float earPhase = t % 3.7f;
        earFlick = earPhase < 0.25f ? (float) Math.sin(earPhase * 25.0f) * 0.05f : 0.0f;

        // ---- saddle ----
        seatZ = -0.06f;
        float tt = (seatZ - rear[2]) / (front[2] - rear[2]);
        float yc = mix(rear[1], front[1], tt);
        topY = yc + 0.330f;
        seatY = topY + 0.065f;
        spring = bodyUp * 0.45f;

        // ---- anchors for the soft mane / tail strands ----
        set(tailRoot, 0.0f, rear[1] + 0.20f, rear[2] - 0.20f);
        set(maneTop, 0.0f, neckTop[1] + 0.08f, neckTop[2] - 0.05f);
        set(maneBase, 0.0f, neckBase[1] + 0.22f, neckBase[2] - 0.06f);

        // ---- rider ----
        rider.time = t;
        rider.facingX = facingX;
        rider.facingY = facingY;
        rider.velX = velX;
        rider.velY = velY;
        rider.gait = ph;
        rider.dodgeTimer = dodgeTimer;
        rider.seatY = seatY;
        rider.seatZ = seatZ;
        rider.seatSpring = spring;
        rider.seatLean = sf;
        rider.headNod = nodV;
        set(reinTarget, 0.095f, seatY + 0.66f + nodV * 0.7f - 0.08f * k, seatZ + 0.42f);
        rider.poseSeated(reinTarget[0], reinTarget[1], reinTarget[2]);

        Soft3D.rotY(modelM, yaw, 0.0f, 0.0f, 0.0f);
    }

    // =============================================================================================
    // DRAW
    // =============================================================================================
    void draw(Soft3D s, Knight3D rider) {
        s.setModel(modelM);
        final int COAT = Soft3D.T_COAT, HOOF = Soft3D.T_HOOF, DARK = Soft3D.T_DARK, LEATHER = Soft3D.T_LEATHER,
                BLANKET = Soft3D.T_BLANKET, GOLD = Soft3D.T_GOLD, HAIR = Soft3D.T_HAIR;

        // ---- legs (far side darker for depth) ----
        for (int leg = 0; leg < 4; leg++) {
            boolean frontLeg = (leg & 1) == 1;
            float b = 0.92f * LEG_BRIGHT[leg];
            float[] h = hipJ[leg], kn = kneeJ[leg], ft = fetJ[leg], hf = hoofJ[leg];
            if (frontLeg) {
                s.limb(h[0], h[1], h[2], kn[0], kn[1], kn[2], 0.120f, 0.074f, COAT, b, 0.12f);          // forearm
            } else {
                s.limb(h[0], h[1], h[2], kn[0], kn[1], kn[2], 0.150f, 0.082f, COAT, b, 0.12f);          // thigh / gaskin
            }
            s.limb(kn[0], kn[1], kn[2], ft[0], ft[1], ft[2], 0.058f, 0.046f, COAT, b, 0.10f);           // cannon
            s.ell(kn[0], kn[1], kn[2], 0.066f, 0.066f, 0.066f, COAT, b, 0.1f);                           // knee / hock
            s.ell(ft[0], ft[1], ft[2], 0.056f, 0.056f, 0.056f, COAT, b, 0.1f);                           // fetlock
            s.limb(ft[0], ft[1], ft[2], hf[0], hf[1], hf[2], 0.050f, 0.064f, HOOF, 0.8f * b, 0.2f);     // pastern + hoof
        }

        // ---- barrel, haunch, chest ----
        float cx = 0.0f, cy = (rear[1] + front[1]) * 0.5f, cz = (rear[2] + front[2]) * 0.5f;
        float dyz = front[2] - rear[2], dyy = front[1] - rear[1];
        float len = (float) Math.sqrt(dyz * dyz + dyy * dyy);
        s.ellDir(cx, cy, cz, 0.0f, dyy, dyz, 0.285f, 0.335f, len * 0.5f + 0.14f, COAT, 1.0f, 0.12f);
        s.ellDir(0.0f, rear[1] + 0.03f, rear[2] + 0.10f, 0.0f, 0.0f, 1.0f, 0.300f, 0.350f, 0.330f, COAT, 1.0f, 0.12f);   // haunch
        s.ellDir(0.0f, front[1] + 0.00f, front[2] - 0.02f, 0.0f, 0.0f, 1.0f, 0.280f, 0.350f, 0.290f, COAT, 1.0f, 0.12f); // chest

        // ---- neck + head ----
        s.limb(neckBase[0], neckBase[1] - 0.02f, neckBase[2] - 0.08f, neckTop[0], neckTop[1], neckTop[2], 0.235f, 0.120f, COAT, 1.0f, 0.12f);
        float[] T = neckTop, M = muzzle;
        s.ellDir(T[0] + hd[0] * 0.17f, T[1] + hd[1] * 0.17f, T[2] + hd[2] * 0.17f, hd[0], hd[1], hd[2], 0.098f, 0.115f, 0.230f, COAT, 1.0f, 0.12f);
        s.ellDir(M[0] - hd[0] * 0.03f, M[1] - hd[1] * 0.03f, M[2] - hd[2] * 0.03f, hd[0], hd[1], hd[2], 0.066f, 0.066f, 0.082f, COAT, 0.95f, 0.1f);
        s.ellDir(M[0] - hd[0] * 0.01f + upH[0] * 0.02f, M[1] - hd[1] * 0.01f + upH[1] * 0.02f, M[2] - hd[2] * 0.01f + upH[2] * 0.02f,
                hd[0], hd[1], hd[2], 0.050f, 0.034f, 0.030f, DARK, 0.30f, 0.0f);                                      // nose
        for (int e = -1; e <= 1; e += 2) {
            float ex = T[0] + hd[0] * 0.10f + upH[0] * 0.035f + 0.092f * e;
            float ey = T[1] + hd[1] * 0.10f + upH[1] * 0.035f;
            float ez = T[2] + hd[2] * 0.10f + upH[2] * 0.035f;
            s.ell(ex, ey, ez, 0.024f, 0.030f, 0.030f, DARK, 0.18f, 0.0f);                                              // eyes
            s.limb(T[0] + 0.058f * e, T[1] + 0.05f, T[2] - 0.035f, T[0] + 0.052f * e, T[1] + 0.20f, T[2] + earFlick * 1.0f - 0.012f,
                    0.034f, 0.010f, COAT, 1.0f, 0.1f);                                                                 // ears
            // cheek strap
            s.limb(T[0] + 0.100f * e + hd[0] * 0.06f, T[1] + hd[1] * 0.06f + upH[1] * 0.04f, T[2] + hd[2] * 0.06f + upH[2] * 0.04f,
                    M[0] + 0.074f * e - hd[0] * 0.09f, M[1] - hd[1] * 0.09f + upH[1] * 0.025f, M[2] - hd[2] * 0.09f + upH[2] * 0.025f,
                    0.011f, 0.011f, LEATHER, 0.9f, 0.1f);
        }
        // browband
        s.limb(T[0] - 0.098f, T[1] + hd[1] * 0.05f + upH[1] * 0.06f, T[2] + hd[2] * 0.05f + upH[2] * 0.06f,
                T[0] + 0.098f, T[1] + hd[1] * 0.05f + upH[1] * 0.06f, T[2] + hd[2] * 0.05f + upH[2] * 0.06f,
                0.011f, 0.011f, LEATHER, 0.9f, 0.1f);
        // noseband
        s.limb(M[0] - 0.072f, M[1] - hd[1] * 0.10f + upH[1] * 0.03f, M[2] - hd[2] * 0.10f + upH[2] * 0.03f,
                M[0] + 0.072f, M[1] - hd[1] * 0.10f + upH[1] * 0.03f, M[2] - hd[2] * 0.10f + upH[2] * 0.03f,
                0.012f, 0.012f, LEATHER, 0.9f, 0.1f);

        // ---- tail dock (soft strands are drawn by the 2D overlay) ----
        s.limb(tailRoot[0], tailRoot[1], tailRoot[2], 0.0f, rear[1] + 0.02f, rear[2] - 0.40f, 0.060f, 0.034f, HAIR, 0.95f, 0.2f);

        // ---- saddle, blanket, stirrups ----
        s.ell(0.0f, topY - 0.02f, seatZ, 0.250f, 0.050f, 0.320f, BLANKET, 0.95f, 0.0f);
        s.ell(0.0f, topY + 0.020f, seatZ - 0.010f, 0.175f, 0.048f, 0.250f, LEATHER, 0.95f, 0.15f);
        s.ell(0.0f, topY + 0.065f, seatZ + 0.230f, 0.050f, 0.055f, 0.040f, LEATHER, 0.95f, 0.15f);
        s.ell(0.0f, topY + 0.075f, seatZ - 0.235f, 0.125f, 0.065f, 0.040f, LEATHER, 0.95f, 0.15f);
        for (int sd = 0; sd < 2; sd++) {
            float side = sd == 0 ? 1.0f : -1.0f;
            float[] an = rider.ank[sd];
            s.limb(side * 0.245f, topY - 0.01f, seatZ + 0.02f, an[0], an[1] - 0.03f, an[2] + 0.01f, 0.011f, 0.011f, LEATHER, 0.9f, 0.1f);
            s.box(an[0], an[1] - 0.045f, an[2] + 0.045f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f,
                    0.045f, 0.010f, 0.050f, GOLD, 0.9f, 0.5f);
        }

        // ---- reins from the bit to the rider's left hand ----
        float[] rh = rider.reinHand;
        for (int e = -1; e <= 1; e += 2) {
            s.limb(M[0] + 0.07f * e - hd[0] * 0.07f, M[1] - hd[1] * 0.07f, M[2] - hd[2] * 0.07f,
                    rh[0] + 0.012f * e, rh[1] - 0.01f, rh[2] + 0.01f, 0.008f, 0.008f, LEATHER, 0.85f, 0.05f);
        }

        // ---- rider ----
        rider.drawSeated(s);
    }
}
