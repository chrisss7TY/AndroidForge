# Knight + horse are now real 3D, then converted to ASCII

Pipeline (per frame): pose the skeleton -> draw 3D parts into a z-buffer -> shade -> convert each glyph cell to a character.

- `Soft3D.java`   Pure-Java CPU renderer: tapered capsules / ellipsoids / boxes -> triangles, z-buffer, per-pixel lighting
                  (key light + rim + steel specular), 3x4 supersampling, pitched orthographic camera (22 deg), and
                  `toAscii()` which turns each cell's coverage + luminance + material into a glyph from DENSE_RAMP and a tint.
- `Knight3D.java` 3D knight: spine, two-bone IK legs/arms, steel greaves/knee cops/boots/breastplate/pauldrons, crimson tunic,
                  head with face/hair, ember sword. Planted-foot walk->run, breathing/weight shift, slash (chest twist + lunge),
                  forward tuck-and-roll dodge. He now truly turns to any facing (front, back, sides). Also has a seated pose.
- `Horse3D.java`  3D steed: barrel/haunch/chest, arched neck + head (eyes, ears, bridle), 4 IK legs on the 4-beat walk -> gallop blend,
                  grazing / pawing / ear flicks, leaping dodge, saddle + blanket + stirrups + reins. Carries the seated knight.
- `MainActivity.java`  `rasterizeFootKnightAscii()` / `rasterizeHorseAndRiderAscii()` now drive the above and fill the same glyph buffers,
                  so the drawing, reflection, afterimage and portrait code are unchanged. Hair strands, mane and tail still use the
                  existing physics; their anchors now come from the 3D head / neck / tail. The old 2D rigs remain as `*Legacy2D`.
                  Horse glyph buffer is 96x76 (was 96x58) so the taller rider and raised sword are not clipped.

Tweakables: `CAM_PITCH` (MainActivity), light direction + ramp mapping (`Soft3D`), colours (`Soft3D.toneColor`).

`tools/` holds a desktop preview (`Preview.java`) that renders the 3D view and the ASCII view side by side:
  javac -d out app/src/main/java/com/ashveil/abyss/{Soft3D,Knight3D,Horse3D}.java tools/com/ashveil/abyss/Preview.java
  java -cp out com.ashveil.abyss.Preview hero|horse /tmp/prev

Not run on a device (no Android SDK here). The 3D classes were compiled and rendered on a desktop JVM; MainActivity compiles with the
same errors as before (only missing Android classes).
