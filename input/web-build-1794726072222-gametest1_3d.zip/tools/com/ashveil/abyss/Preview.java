package com.ashveil.abyss;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/** Desktop preview: renders the knight / horse in 3D, then the ASCII conversion next to it. Not part of the Android app. */
public class Preview {
    static final String RAMP = " .,:;-=+*oahkbdpqwmZOQ0N$%&8B#MW@";
    static final float PITCH = (float) Math.toRadians(22);

    static BufferedImage shaded(Soft3D s, float scale) {
        BufferedImage im = new BufferedImage(s.W, s.H, BufferedImage.TYPE_INT_RGB);
        for (int y = 0; y < s.H; y++) for (int x = 0; x < s.W; x++) {
            int p = y * s.W + x;
            if (s.zbuf[p] > Soft3D.EMPTY) {
                float l = Math.min(1f, s.lbuf[p]);
                im.setRGB(x, y, Soft3D.toneColor(s.tbuf[p], l) & 0xFFFFFF);
            } else im.setRGB(x, y, 0x050709);
        }
        BufferedImage out = new BufferedImage((int) (s.W * scale), (int) (s.H * scale), BufferedImage.TYPE_INT_RGB);
        Graphics2D g = out.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.drawImage(im, 0, 0, out.getWidth(), out.getHeight(), null);
        g.dispose();
        return out;
    }

    static BufferedImage ascii(Soft3D s, float cw, float ch) {
        char[] g = new char[s.cols * s.rows];
        float[] l = new float[s.cols * s.rows];
        int[] c = new int[s.cols * s.rows];
        s.toAscii(g, l, c, null, RAMP);
        BufferedImage out = new BufferedImage((int) (s.cols * cw), (int) (s.rows * ch), BufferedImage.TYPE_INT_RGB);
        Graphics2D gg = out.createGraphics();
        gg.setColor(new Color(5, 7, 9));
        gg.fillRect(0, 0, out.getWidth(), out.getHeight());
        gg.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        gg.setFont(new Font(Font.MONOSPACED, Font.BOLD, Math.round(cw / 0.6f)));
        for (int r = 0; r < s.rows; r++) for (int q = 0; q < s.cols; q++) {
            char ch2 = g[r * s.cols + q];
            if (ch2 == ' ') continue;
            gg.setColor(new Color(c[r * s.cols + q]));
            gg.drawString(String.valueOf(ch2), q * cw, (r + 0.86f) * ch);
        }
        gg.dispose();
        return out;
    }

    static Soft3D heroCanvas() {
        Soft3D s = new Soft3D(64, 58, 3, 4);
        s.setView(PITCH, 24.0f, 24.0f / 1.3f, 32.0f, 0.55f * 58 + 0.82f * (24.0f / 1.3f));
        return s;
    }

    static Soft3D horseCanvas() {
        Soft3D s = new Soft3D(96, 76, 3, 4);
        float cpu = 96.0f / 3.15f;
        s.setView(PITCH, cpu, cpu / 1.3f, 48.0f, 46.0f + 0.98f * (cpu / 1.3f));
        return s;
    }

    static float t = 0;

    static void heroFrame(Soft3D s, Knight3D k, float fx, float fy, float spd, float gait, float dodgeT, float slashT, int warm) {
        for (int i = 0; i < warm; i++) { t += 0.016f; k.time = t; k.facingX = fx; k.facingY = fy; k.velX = fx * spd; k.velY = fy * spd; k.gait = gait; k.dodgeTimer = dodgeT; k.slashTimer = slashT; k.poseStanding(); }
        s.clear();
        k.drawStanding(s);
    }

    static void horseFrame(Soft3D s, Horse3D h, Knight3D r, float fx, float fy, float spd, float gait, float dodgeT, float slashT, int warm) {
        for (int i = 0; i < warm; i++) { t += 0.016f; h.time = t; h.facingX = fx; h.facingY = fy; h.velX = fx * spd; h.velY = fy * spd; h.gait = gait; h.dodgeTimer = dodgeT; r.slashTimer = slashT; h.update(r); }
        s.clear();
        h.draw(s, r);
    }

    static void sheet(String name, java.util.List<BufferedImage> panels, int perRow, int gap) {
        int w = 0, h = 0;
        for (BufferedImage b : panels) { w = Math.max(w, b.getWidth()); h = Math.max(h, b.getHeight()); }
        int rows = (panels.size() + perRow - 1) / perRow;
        BufferedImage out = new BufferedImage(perRow * (w + gap), rows * (h + gap), BufferedImage.TYPE_INT_RGB);
        Graphics2D g = out.createGraphics();
        g.setColor(new Color(30, 30, 34)); g.fillRect(0, 0, out.getWidth(), out.getHeight());
        for (int i = 0; i < panels.size(); i++) g.drawImage(panels.get(i), (i % perRow) * (w + gap), (i / perRow) * (h + gap), null);
        g.dispose();
        try { ImageIO.write(out, "png", new File(name)); } catch (Exception e) { throw new RuntimeException(e); }
        System.out.println("wrote " + name + " " + out.getWidth() + "x" + out.getHeight());
    }

    public static void main(String[] a) throws Exception {
        String mode = a.length > 0 ? a[0] : "hero";
        String dir = a.length > 1 ? a[1] : "/tmp/prev";
        new File(dir).mkdirs();
        java.util.List<BufferedImage> P = new java.util.ArrayList<>();
        if (mode.equals("hero")) {
            Soft3D s = heroCanvas(); Knight3D k = new Knight3D();
            // idle views: right, toward camera, left, away
            float[][] views = {{1, 0}, {0, 1}, {-1, 0}, {0, -1}};
            for (float[] v : views) { heroFrame(s, k, v[0], v[1], 0, 0, 0, 0, 40); P.add(shaded(s, 2.0f)); P.add(ascii(s, 8, 10.4f)); }
            sheet(dir + "/hero_idle.png", P, 4, 6);
            P.clear();
            // walking / running (right)
            float gait = 0; k = new Knight3D();
            for (int i = 0; i < 40; i++) heroFrame(s, k, 1, 0, 2.0f, gait += 0.2f, 0, 0, 1);
            for (int i = 0; i < 4; i++) { for (int j = 0; j < 5; j++) heroFrame(s, k, 1, 0, 2.0f, gait += 0.2f, 0, 0, 1); P.add(ascii(s, 8, 10.4f)); }
            k = new Knight3D();
            for (int i = 0; i < 40; i++) heroFrame(s, k, 1, 0, 4.0f, gait += 0.3f, 0, 0, 1);
            for (int i = 0; i < 4; i++) { for (int j = 0; j < 4; j++) heroFrame(s, k, 1, 0, 4.0f, gait += 0.3f, 0, 0, 1); P.add(ascii(s, 8, 10.4f)); }
            sheet(dir + "/hero_walkrun.png", P, 4, 6);
            P.clear();
            // slash + dodge
            k = new Knight3D();
            for (int i = 0; i < 8; i++) { heroFrame(s, k, 1, 0, 0, 0, 0, 0.26f * (1 - i / 8f), 1); P.add(ascii(s, 8, 10.4f)); }
            sheet(dir + "/hero_slash.png", P, 4, 6);
            P.clear();
            k = new Knight3D();
            for (int i = 0; i < 8; i++) { heroFrame(s, k, 1, 0, 0, 0, 0.28f * (1 - (i + 0.5f) / 8f), 0, 1); P.add(shaded(s, 1.2f)); P.add(ascii(s, 8, 10.4f)); }
            sheet(dir + "/hero_dodge.png", P, 4, 6);
        } else {
            Soft3D s = horseCanvas(); Knight3D r = new Knight3D(); Horse3D h = new Horse3D();
            float[][] views = {{1, 0}, {0, 1}, {-1, 0}, {0, -1}};
            for (float[] v : views) { horseFrame(s, h, r, v[0], v[1], 0, 0, 0, 0, 40); P.add(shaded(s, 1.7f)); P.add(ascii(s, 8, 10.4f)); }
            sheet(dir + "/horse_idle.png", P, 2, 6);
            P.clear();
            float gait = 0; h = new Horse3D(); r = new Knight3D();
            for (int i = 0; i < 40; i++) horseFrame(s, h, r, 1, 0, 2.0f, gait += 0.1f, 0, 0, 1);
            for (int i = 0; i < 4; i++) { for (int j = 0; j < 4; j++) horseFrame(s, h, r, 1, 0, 2.0f, gait += 0.2f, 0, 0, 1); P.add(ascii(s, 8, 10.4f)); }
            for (int i = 0; i < 40; i++) horseFrame(s, h, r, 1, 0, 5.2f, gait += 0.32f, 0, 0, 1);
            for (int i = 0; i < 4; i++) { for (int j = 0; j < 3; j++) horseFrame(s, h, r, 1, 0, 5.2f, gait += 0.32f, 0, 0, 1); P.add(ascii(s, 8, 10.4f)); }
            sheet(dir + "/horse_gait.png", P, 2, 6);
            P.clear();
            for (int i = 0; i < 4; i++) { horseFrame(s, h, r, 1, 0, 0, 0, 0, 0.26f * (1 - i / 4f), 1); P.add(ascii(s, 8, 10.4f)); }
            for (int i = 0; i < 4; i++) { horseFrame(s, h, r, 1, 0, 3, gait += 0.2f, 0.28f * (1 - (i + 0.5f) / 4f), 0, 1); P.add(ascii(s, 8, 10.4f)); }
            sheet(dir + "/horse_slash_dodge.png", P, 2, 6);
        }
    }
}
