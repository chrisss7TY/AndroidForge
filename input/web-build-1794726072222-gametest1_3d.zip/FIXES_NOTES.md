# Fixes: invisible walls, wrong map, lag

## Invisible obstructions / map drawn in the wrong place
- **Ground was drawn as one flat quad per chunk** but entities and collision used the real terrain height,
  so rock, cliffs and shores were painted up to ~1 unit away from where they actually blocked you.
  Chunks are now drawn as an 8x8 mesh (`drawBitmapMesh`) whose vertices use the same cached height
  (`WorldGen.terrainHeightFast`) as everything else.
- **Stones/pillars could be solid but not drawn**: the sprite cache held 28 sprites and built 1 per frame,
  so with more stones in view they were evicted/rebuilt forever. Cache is 48, sprites are built on a
  background thread, and a dark silhouette is drawn until the sprite is ready.
- **Tall pillars popped out at the bottom screen edge** (object query stopped 4 units below the view).
- **Deep water looked the same as wadable shallows**: deep water is now dark navy with a bright rim at the
  drop-off; the walkable shallows are a lighter teal. (`WorldGen.DEEP_WATER` is the single threshold.)
- **Cottage collision was wider than the drawn cottage** (3.2 vs ~2.6 units): reduced.
- **Missing chunks showed fake grass** (a placeholder tile) hiding water/cliffs that were really there.
  Missing chunks are now plain dark ground, and a "Shaping the world..." gate waits for the visible ground
  after launch / New World.
- Movement uses sub-steps (dash no longer tunnels), enemies slide along obstacles instead of freezing, and
  the hero is moved to the nearest free spot if ever left inside solid ground.

## Lag
- **Chunk painting (10-40 ms each, hundreds of software drawText calls) ran on the render thread** and was
  forced at least once per frame. It now runs on a background thread (`ChunkPainter` + `AshveilView.painterLoop`),
  nearest-to-camera first, with a prefetch ring biased toward the direction of travel.
- **Stone sprites (~2000 drawText calls each) were also built on the render thread**: now background.
- **Chunk cache was 100 slots**; the Wide camera on a landscape phone needs ~105, so it evicted visible chunks
  every frame (constant rebuilding). Cache is now 150 and off-screen chunks are skipped.
- Terrain height is cached on a 0.5-unit lattice (grass blades, entities, mesh all share it).
- Shoreline-foam sites are found once per 8x8 block instead of ~3000 water probes every frame.
- The shared game RNG was being re-seeded by the chunk painter (making respawns repeat); the painter has its own.

Not run on a device (no Android SDK here). Everything was type-checked against stand-in Android classes and
`WorldGen` was tested on a desktop JVM.
