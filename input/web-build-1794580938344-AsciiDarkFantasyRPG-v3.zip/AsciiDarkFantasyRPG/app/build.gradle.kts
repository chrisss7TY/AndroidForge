import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val versionPropsFile = file("version.properties")
val versionProps = Properties().apply {
    if (versionPropsFile.exists()) {
        versionPropsFile.inputStream().use { load(it) }
    }
}
val currentVersionCode = versionProps.getProperty("VERSION_CODE", "3").toInt()
val currentVersionName = versionProps.getProperty("VERSION_NAME", "0.1.2")

android {
    namespace = "com.senje.asciirpg"
    compileSdk = 34

    signingConfigs {
        create("release") {
            storeFile = file("release-key.jks")
            storePassword = "senje1337"
            keyAlias = "senje_release"
            keyPassword = "senje1337"
            enableV1Signing = true
            enableV2Signing = true
        }
    }

    defaultConfig {
        applicationId = "com.senje.asciirpg"
        minSdk = 26
        targetSdk = 34
        versionCode = currentVersionCode
        versionName = "$currentVersionName-b$currentVersionCode"
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

// Automatically bump VERSION_CODE after each APK assemble so every build updates cleanly in-place
tasks.matching { it.name.startsWith("assemble") }.configureEach {
    doLast {
        val nextCode = currentVersionCode + 1
        versionProps.setProperty("VERSION_CODE", nextCode.toString())
        versionPropsFile.outputStream().use {
            versionProps.store(it, "Auto-incremented by Gradle on build")
        }
        println("Signed APK built (v$currentVersionCode). Next build auto-bumped to v$nextCode.")
    }
}

dependencies {
    // Pure Android SDK + OpenGL ES 3.0: zero third-party bloat for fast on-device APK builds
}
