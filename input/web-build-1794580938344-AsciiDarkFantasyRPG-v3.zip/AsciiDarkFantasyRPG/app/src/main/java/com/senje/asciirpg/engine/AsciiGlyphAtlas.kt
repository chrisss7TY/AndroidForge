package com.senje.asciirpg.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.opengl.GLES30
import android.opengl.GLUtils

object AsciiGlyphAtlas {

    const val LUMINANCE_RAMP = " .,:;~-=+*o08QM@"
    const val EDGE_GLYPHS = "|-/\\"

    fun createAtlasTexture(): Int {
        val cols = 16
        val rows = 16
        val cellSize = 32
        val bmp = Bitmap.createBitmap(cols * cellSize, rows * cellSize, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.BLACK)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 25f
            typeface = Typeface.MONOSPACE
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val fontMetrics = paint.fontMetrics
        val baselineOffset = -(fontMetrics.ascent + fontMetrics.descent) * 0.5f

        for (i in LUMINANCE_RAMP.indices) {
            val cx = i * cellSize + cellSize * 0.5f
            val cy = cellSize * 0.5f + baselineOffset
            canvas.drawText(LUMINANCE_RAMP[i].toString(), cx, cy, paint)
        }

        for (i in EDGE_GLYPHS.indices) {
            val cx = i * cellSize + cellSize * 0.5f
            val cy = cellSize * 1.5f + baselineOffset
            canvas.drawText(EDGE_GLYPHS[i].toString(), cx, cy, paint)
        }

        for (ascii in 32..126) {
            val idx = ascii - 32
            val col = idx % 16
            val row = 2 + (idx / 16)
            val cx = col * cellSize + cellSize * 0.5f
            val cy = row * cellSize + cellSize * 0.5f + baselineOffset
            canvas.drawText(ascii.toChar().toString(), cx, cy, paint)
        }

        val texIds = IntArray(1)
        GLES30.glGenTextures(1, texIds, 0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, texIds[0])
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0)
        bmp.recycle()

        return texIds[0]
    }
}
