package com.senje.asciirpg.world

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

class WorldGenerator(val seed: Int) {

    companion object {
        const val GRID_SIZE = 72
        const val TILE_SCALE = 0.65f
        const val GRASS_INSTANCE_COUNT = 5400
        const val PILLAR_COUNT = 14
    }

    val terrainVertexBuffer: FloatBuffer
    val terrainVertexCount: Int

    val grassInstanceBuffer: FloatBuffer
    val pillarData = FloatArray(PILLAR_COUNT * 4)

    init {
        val rng = Random(seed)

        val half = GRID_SIZE * 0.5f
        val quads = GRID_SIZE * GRID_SIZE
        terrainVertexCount = quads * 6
        terrainVertexBuffer = ByteBuffer.allocateDirect(terrainVertexCount * 10 * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()

        for (gz in 0 until GRID_SIZE) {
            for (gx in 0 until GRID_SIZE) {
                val x0 = (gx - half) * TILE_SCALE
                val z0 = (gz - half) * TILE_SCALE
                val x1 = x0 + TILE_SCALE
                val z1 = z0 + TILE_SCALE

                putTerrainVertex(x0, z0)
                putTerrainVertex(x0, z1)
                putTerrainVertex(x1, z1)

                putTerrainVertex(x0, z0)
                putTerrainVertex(x1, z1)
                putTerrainVertex(x1, z0)
            }
        }
        terrainVertexBuffer.position(0)

        for (i in 0 until PILLAR_COUNT) {
            val angle = (i.toFloat() / PILLAR_COUNT) * 6.28318f + rng.nextFloat() * 0.35f
            val dist = 7.5f + rng.nextFloat() * 11.0f
            pillarData[i * 4] = cos(angle) * dist
            pillarData[i * 4 + 1] = sin(angle) * dist
            pillarData[i * 4 + 2] = 0.65f + rng.nextFloat() * 0.45f
            pillarData[i * 4 + 3] = 2.2f + rng.nextFloat() * 2.4f
        }

        grassInstanceBuffer = ByteBuffer.allocateDirect(GRASS_INSTANCE_COUNT * 6 * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()

        var placed = 0
        var attempts = 0
        val worldRadius = half * TILE_SCALE * 0.92f
        while (placed < GRASS_INSTANCE_COUNT && attempts < GRASS_INSTANCE_COUNT * 4) {
            attempts++
            val wx = (rng.nextFloat() * 2f - 1f) * worldRadius
            val wz = (rng.nextFloat() * 2f - 1f) * worldRadius
            val surface = getSurfaceType(wx, wz)
            if (surface < 0.35f) {
                val wy = getTerrainHeight(wx, wz)
                val scale = 0.65f + rng.nextFloat() * 0.85f
                val phase = rng.nextFloat() * 6.28318f
                val isFlower = if (rng.nextFloat() < 0.085f) 1.0f else 0.0f
                grassInstanceBuffer.put(wx)
                grassInstanceBuffer.put(wy)
                grassInstanceBuffer.put(wz)
                grassInstanceBuffer.put(scale)
                grassInstanceBuffer.put(phase)
                grassInstanceBuffer.put(isFlower)
                placed++
            }
        }
        grassInstanceBuffer.position(0)
    }

    fun getTerrainHeight(x: Float, z: Float): Float {
        val riverDist = getRiverSignedDistance(x, z)
        if (riverDist < 0f) {
            return -0.28f
        }
        val n1 = sin(x * 0.22f + seed * 0.01f) * cos(z * 0.19f) * 0.35f
        val n2 = sin((x + z) * 0.45f) * 0.12f
        val bankBlend = (riverDist / 1.8f).coerceIn(0f, 1f)
        return (n1 + n2) * bankBlend
    }

    fun getSurfaceType(x: Float, z: Float): Float {
        val riverDist = getRiverSignedDistance(x, z)
        if (riverDist < 0.0f) return 2.0f

        val roadCenter = sin(z * 0.18f) * 3.2f
        val roadDist = kotlin.math.abs(x - roadCenter)
        if (roadDist < 1.35f) return 1.0f

        return 0.0f
    }

    private fun getRiverSignedDistance(x: Float, z: Float): Float {
        val riverZ = -9.5f + sin(x * 0.16f) * 2.6f
        return kotlin.math.abs(z - riverZ) - 2.3f
    }

    private fun putTerrainVertex(x: Float, z: Float) {
        val y = getTerrainHeight(x, z)
        val surface = getSurfaceType(x, z)

        val eps = 0.15f
        val hL = getTerrainHeight(x - eps, z)
        val hR = getTerrainHeight(x + eps, z)
        val hD = getTerrainHeight(x, z - eps)
        val hU = getTerrainHeight(x, z + eps)
        var nx = hL - hR
        var ny = 2f * eps
        var nz = hD - hU
        val len = sqrt(nx * nx + ny * ny + nz * nz).coerceAtLeast(0.001f)
        nx /= len
        ny /= len
        nz /= len

        val r: Float
        val g: Float
        val b: Float
        when {
            surface > 1.5f -> {
                r = 0.10f; g = 0.16f; b = 0.22f
            }
            surface > 0.5f -> {
                val grain = 0.36f + 0.16f * sin(x * 4.5f) * cos(z * 4.5f)
                r = grain; g = grain * 1.02f; b = grain * 1.08f
            }
            else -> {
                r = 0.05f; g = 0.13f; b = 0.06f
            }
        }

        terrainVertexBuffer.put(x)
        terrainVertexBuffer.put(y)
        terrainVertexBuffer.put(z)
        terrainVertexBuffer.put(nx)
        terrainVertexBuffer.put(ny)
        terrainVertexBuffer.put(nz)
        terrainVertexBuffer.put(r)
        terrainVertexBuffer.put(g)
        terrainVertexBuffer.put(b)
        terrainVertexBuffer.put(surface)
    }
}
