package com.senje.asciirpg.data

import android.content.Context
import org.json.JSONObject
import java.io.File

class SaveManager(context: Context) {

    data class PlayerSaveData(
        val schemaVersion: Int = CURRENT_SCHEMA_VERSION,
        val name: String = "Senje",
        val level: Int = 13,
        val xp: Int = 1943,
        val maxXp: Int = 6095,
        val hp: Int = 1612,
        val maxHp: Int = 1612,
        val mp: Int = 134,
        val maxMp: Int = 134,
        val gold: Int = 5194,
        val worldSeed: Int = 133742,
        val posX: Float = 0f,
        val posZ: Float = 0f,
        val isMounted: Boolean = true,
        val equippedHelmMetal: String = "Iron"
    )

    private val saveFile = File(context.filesDir, "senje_world_save.json")

    fun save(data: PlayerSaveData) {
        try {
            val json = JSONObject().apply {
                put("schemaVersion", CURRENT_SCHEMA_VERSION)
                put("name", data.name)
                put("level", data.level)
                put("xp", data.xp)
                put("maxXp", data.maxXp)
                put("hp", data.hp)
                put("maxHp", data.maxHp)
                put("mp", data.mp)
                put("maxMp", data.maxMp)
                put("gold", data.gold)
                put("worldSeed", data.worldSeed)
                put("posX", data.posX.toDouble())
                put("posZ", data.posZ.toDouble())
                put("isMounted", data.isMounted)
                put("equippedHelmMetal", data.equippedHelmMetal)
            }
            val tmpFile = File(saveFile.parentFile, "senje_world_save.tmp")
            tmpFile.writeText(json.toString())
            tmpFile.renameTo(saveFile)
        } catch (_: Exception) {
        }
    }

    fun load(): PlayerSaveData {
        if (!saveFile.exists()) return PlayerSaveData()
        return try {
            val json = JSONObject(saveFile.readText())
            PlayerSaveData(
                schemaVersion = json.optInt("schemaVersion", 1),
                name = json.optString("name", "Senje"),
                level = json.optInt("level", 13),
                xp = json.optInt("xp", 1943),
                maxXp = json.optInt("maxXp", 6095),
                hp = json.optInt("hp", 1612),
                maxHp = json.optInt("maxHp", 1612),
                mp = json.optInt("mp", 134),
                maxMp = json.optInt("maxMp", 134),
                gold = json.optInt("gold", 5194),
                worldSeed = json.optInt("worldSeed", 133742),
                posX = json.optDouble("posX", 0.0).toFloat(),
                posZ = json.optDouble("posZ", 0.0).toFloat(),
                isMounted = json.optBoolean("isMounted", true),
                equippedHelmMetal = json.optString("equippedHelmMetal", "Iron")
            )
        } catch (_: Exception) {
            PlayerSaveData()
        }
    }

    companion object {
        const val CURRENT_SCHEMA_VERSION = 1
    }
}
