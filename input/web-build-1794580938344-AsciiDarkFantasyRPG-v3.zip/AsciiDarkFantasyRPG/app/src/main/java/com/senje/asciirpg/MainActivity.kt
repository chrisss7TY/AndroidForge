package com.senje.asciirpg

import android.app.Activity
import android.content.Context
import android.opengl.GLSurfaceView
import android.os.Build
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import com.senje.asciirpg.data.SaveManager
import com.senje.asciirpg.engine.AsciiGameRenderer

class MainActivity : Activity() {

    private lateinit var glView: AsciiGLSurfaceView
    private lateinit var saveManager: SaveManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        saveManager = SaveManager(this)
        val initialState = saveManager.load()

        glView = AsciiGLSurfaceView(this, initialState, saveManager)
        setContentView(glView)
        hideSystemUI()
    }

    override fun onResume() {
        super.onResume()
        hideSystemUI()
        glView.onResume()
    }

    override fun onPause() {
        glView.persistState()
        glView.onPause()
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUI()
    }

    private fun hideSystemUI() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                )
        }
    }

    private class AsciiGLSurfaceView(
        context: Context,
        initialState: SaveManager.PlayerSaveData,
        private val saveManager: SaveManager
    ) : GLSurfaceView(context) {

        private val gameRenderer: AsciiGameRenderer

        init {
            setEGLContextClientVersion(3)
            preserveEGLContextOnPause = true
            gameRenderer = AsciiGameRenderer(initialState)
            setRenderer(gameRenderer)
            renderMode = RENDERMODE_CONTINUOUSLY
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            gameRenderer.handleTouchEvent(event)
            return true
        }

        fun persistState() {
            saveManager.save(gameRenderer.exportSaveData())
        }
    }
}
