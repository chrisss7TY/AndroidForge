package com.senje.asciirpg.engine

import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.MotionEvent
import com.senje.asciirpg.data.SaveManager
import com.senje.asciirpg.entities.PlayerController
import com.senje.asciirpg.ui.TerminalHudRenderer
import com.senje.asciirpg.world.WorldGenerator
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class AsciiGameRenderer(initialSave: SaveManager.PlayerSaveData) : GLSurfaceView.Renderer {

    private val world = WorldGenerator(initialSave.worldSeed)
    private val player = PlayerController(initialSave)

    private var screenW = 1280
    private var screenH = 720
    private var lastFrameNs = System.nanoTime()

    private val zoomLevels = floatArrayOf(11.5f, 7.2f, 16.5f)
    private val zoomLabels = arrayOf("ZOOM", "CLOSE", "WIDE")
    private var zoomIndex = 0

    private lateinit var worldShader: ShaderProgram
    private lateinit var grassShader: ShaderProgram
    private lateinit var asciiPostShader: ShaderProgram
    private lateinit var hudRenderer: TerminalHudRenderer

    private var fboId = 0
    private var fboColorTex = 0
    private var fboDepthRbo = 0
    private var gridCols = 160
    private var gridRows = 90
    private var atlasTexId = 0

    private var terrainVbo = 0
    private var grassBladeVbo = 0
    private var grassInstanceVbo = 0
    private var boxVbo = 0
    private var fullscreenQuadVbo = 0

    private val viewMatrix = FloatArray(16)
    private val projMatrix = FloatArray(16)
    private val vpMatrix = FloatArray(16)
    private val modelMatrix = FloatArray(16)

    private var joyPointerId = -1
    private var joyCenterX = 0f
    private var joyCenterY = 0f
    private var joyKnobX = 0f
    private var joyKnobY = 0f
    private var forgeOpen = false

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0.02f, 0.025f, 0.03f, 1f)
        atlasTexId = AsciiGlyphAtlas.createAtlasTexture()

        worldShader = ShaderProgram(WORLD_VERT, WORLD_FRAG)
        grassShader = ShaderProgram(GRASS_VERT, GRASS_FRAG)
        asciiPostShader = ShaderProgram(POST_VERT, POST_FRAG)
        hudRenderer = TerminalHudRenderer(atlasTexId)

        setupGeometryBuffers()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        screenW = width.coerceAtLeast(1)
        screenH = height.coerceAtLeast(1)

        val cellPx = (screenH / 84f).coerceIn(7f, 12f)
        gridCols = (screenW / cellPx).toInt().coerceAtLeast(64)
        gridRows = (screenH / cellPx).toInt().coerceAtLeast(36)

        rebuildFbo(gridCols, gridRows)

        val aspect = screenW.toFloat() / screenH.toFloat()
        Matrix.perspectiveM(projMatrix, 0, 42f, aspect, 0.5f, 80f)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = ((now - lastFrameNs) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
        lastFrameNs = now

        player.update(dt, world)

        val camDist = zoomLevels[zoomIndex]
        val camX = player.posX
        val camY = player.posY + camDist * 0.88f
        val camZ = player.posZ + camDist * 0.68f
        Matrix.setLookAtM(
            viewMatrix, 0,
            camX, camY, camZ,
            player.posX, player.posY + 0.5f, player.posZ,
            0f, 1f, 0f
        )
        Matrix.multiplyMM(vpMatrix, 0, projMatrix, 0, viewMatrix, 0)

        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fboId)
        GLES30.glViewport(0, 0, gridCols, gridRows)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glClearColor(0.015f, 0.02f, 0.025f, 1f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

        renderTerrainAndEntities()
        renderInstancedGrass()

        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        GLES30.glViewport(0, 0, screenW, screenH)
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)

        asciiPostShader.use()
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, fboColorTex)
        GLES30.glUniform1i(asciiPostShader.getUniformLocation("uSceneTex"), 0)

        GLES30.glActiveTexture(GLES30.GL_TEXTURE1)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, atlasTexId)
        GLES30.glUniform1i(asciiPostShader.getUniformLocation("uAtlasTex"), 1)

        GLES30.glUniform2f(
            asciiPostShader.getUniformLocation("uGridSize"),
            gridCols.toFloat(),
            gridRows.toFloat()
        )
        GLES30.glUniform1f(asciiPostShader.getUniformLocation("uTime"), player.animTime)

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, fullscreenQuadVbo)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 4 * 4, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, 4 * 4, 2 * 4)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 6)
        GLES30.glDisableVertexAttribArray(0)
        GLES30.glDisableVertexAttribArray(1)

        hudRenderer.render(
            screenW.toFloat(),
            screenH.toFloat(),
            player,
            zoomLabels[zoomIndex],
            joyCenterX,
            joyCenterY,
            joyKnobX,
            joyKnobY,
            joyPointerId != -1,
            forgeOpen
        )
    }

    private fun renderTerrainAndEntities() {
        worldShader.use()
        GLES30.glUniformMatrix4fv(worldShader.getUniformLocation("uVP"), 1, false, vpMatrix, 0)
        GLES30.glUniform1f(worldShader.getUniformLocation("uTime"), player.animTime)
        GLES30.glUniform3f(
            worldShader.getUniformLocation("uPlayerPos"),
            player.posX,
            player.posY,
            player.posZ
        )

        Matrix.setIdentityM(modelMatrix, 0)
        GLES30.glUniformMatrix4fv(worldShader.getUniformLocation("uModel"), 1, false, modelMatrix, 0)
        GLES30.glUniform1i(worldShader.getUniformLocation("uUseCustomTint"), 0)

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, terrainVbo)
        val stride = 10 * 4
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, stride, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, stride, 3 * 4)
        GLES30.glEnableVertexAttribArray(2)
        GLES30.glVertexAttribPointer(2, 3, GLES30.GL_FLOAT, false, stride, 6 * 4)
        GLES30.glEnableVertexAttribArray(3)
        GLES30.glVertexAttribPointer(3, 1, GLES30.GL_FLOAT, false, stride, 9 * 4)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, world.terrainVertexCount)
        GLES30.glDisableVertexAttribArray(3)

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, boxVbo)
        val boxStride = 9 * 4
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, boxStride, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, boxStride, 3 * 4)
        GLES30.glEnableVertexAttribArray(2)
        GLES30.glVertexAttribPointer(2, 3, GLES30.GL_FLOAT, false, boxStride, 6 * 4)
        GLES30.glUniform1i(worldShader.getUniformLocation("uUseCustomTint"), 1)

        for (i in 0 until WorldGenerator.PILLAR_COUNT) {
            val px = world.pillarData[i * 4]
            val pz = world.pillarData[i * 4 + 1]
            val rad = world.pillarData[i * 4 + 2]
            val h = world.pillarData[i * 4 + 3]
            val py = world.getTerrainHeight(px, pz)
            drawBox(px, py + h * 0.5f, pz, 0f, rad, h, rad, 0.34f, 0.36f, 0.40f)
        }

        val deg = Math.toDegrees(player.facingAngle.toDouble()).toFloat()
        val gallopBob = if (player.currentSpeed > 0.1f) {
            kotlin.math.abs(sin(player.animTime * 11f)) * 0.14f
        } else {
            sin(player.animTime * 2.5f) * 0.03f
        }

        if (player.isMounted) {
            val steedY = player.posY + 0.65f + gallopBob
            drawBox(player.posX, steedY, player.posZ, deg, 0.48f, 0.46f, 1.15f, 0.90f, 0.92f, 0.95f)
            val fwdX = sin(player.facingAngle)
            val fwdZ = cos(player.facingAngle)
            drawBox(player.posX + fwdX * 0.52f, steedY + 0.42f, player.posZ + fwdZ * 0.52f, deg, 0.24f, 0.52f, 0.32f, 0.94f, 0.95f, 0.98f)

            val legSwing = if (player.currentSpeed > 0.1f) sin(player.animTime * 12f) * 0.22f else 0f
            drawBox(player.posX + fwdX * 0.35f - fwdZ * 0.16f, player.posY + 0.26f, player.posZ + fwdZ * 0.35f + fwdX * 0.16f + legSwing, deg, 0.11f, 0.52f, 0.11f, 0.78f, 0.80f, 0.84f)
            drawBox(player.posX + fwdX * 0.35f + fwdZ * 0.16f, player.posY + 0.26f, player.posZ + fwdZ * 0.35f - fwdX * 0.16f - legSwing, deg, 0.11f, 0.52f, 0.11f, 0.78f, 0.80f, 0.84f)
            drawBox(player.posX - fwdX * 0.38f - fwdZ * 0.16f, player.posY + 0.26f, player.posZ - fwdZ * 0.38f + fwdX * 0.16f - legSwing, deg, 0.11f, 0.52f, 0.11f, 0.78f, 0.80f, 0.84f)
            drawBox(player.posX - fwdX * 0.38f + fwdZ * 0.16f, player.posY + 0.26f, player.posZ - fwdZ * 0.38f - fwdX * 0.16f + legSwing, deg, 0.11f, 0.52f, 0.11f, 0.78f, 0.80f, 0.84f)

            drawBox(player.posX, steedY + 0.52f, player.posZ - fwdZ * 0.05f, deg, 0.36f, 0.54f, 0.26f, 0.52f, 0.54f, 0.58f)
            drawBox(player.posX, steedY + 0.90f, player.posZ - fwdZ * 0.05f, deg, 0.22f, 0.24f, 0.22f, 0.82f, 0.84f, 0.88f)
        } else {
            val bodyY = player.posY + 0.55f + gallopBob
            drawBox(player.posX, bodyY, player.posZ, deg, 0.38f, 0.62f, 0.26f, 0.55f, 0.57f, 0.62f)
            drawBox(player.posX, bodyY + 0.45f, player.posZ, deg, 0.24f, 0.26f, 0.24f, 0.85f, 0.88f, 0.92f)
        }

        for (i in 0 until 6) {
            val thickness = 0.22f * (1f - i * 0.11f)
            drawBox(
                player.tailNodesX[i],
                player.tailNodesY[i],
                player.tailNodesZ[i],
                deg,
                thickness,
                thickness,
                0.24f,
                0.96f,
                0.97f,
                1.0f
            )
        }

        if (player.attackTimer > 0f) {
            val swingAngle = deg + (0.2f - player.attackTimer) * 380f
            val rad = Math.toRadians(swingAngle.toDouble()).toFloat()
            val sx = player.posX + sin(rad) * 1.15f
            val sz = player.posZ + cos(rad) * 1.15f
            drawBox(sx, player.posY + 0.85f, sz, swingAngle, 1.35f, 0.12f, 0.25f, 1.0f, 0.96f, 0.82f)
        }

        GLES30.glDisableVertexAttribArray(0)
        GLES30.glDisableVertexAttribArray(1)
        GLES30.glDisableVertexAttribArray(2)
    }

    private fun drawBox(
        x: Float, y: Float, z: Float,
        rotYDeg: Float,
        sx: Float, sy: Float, sz: Float,
        r: Float, g: Float, b: Float
    ) {
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, x, y, z)
        Matrix.rotateM(modelMatrix, 0, rotYDeg, 0f, 1f, 0f)
        Matrix.scaleM(modelMatrix, 0, sx, sy, sz)
        GLES30.glUniformMatrix4fv(worldShader.getUniformLocation("uModel"), 1, false, modelMatrix, 0)
        GLES30.glUniform3f(worldShader.getUniformLocation("uCustomTint"), r, g, b)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 36)
    }

    private fun renderInstancedGrass() {
        grassShader.use()
        GLES30.glUniformMatrix4fv(grassShader.getUniformLocation("uVP"), 1, false, vpMatrix, 0)
        GLES30.glUniform1f(grassShader.getUniformLocation("uTime"), player.animTime)
        GLES30.glUniform3f(
            grassShader.getUniformLocation("uPlayerPos"),
            player.posX,
            player.posY,
            player.posZ
        )

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, grassBladeVbo)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 3 * 4, 0)
        GLES30.glVertexAttribDivisor(0, 0)

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, grassInstanceVbo)
        val instStride = 6 * 4
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, instStride, 0)
        GLES30.glVertexAttribDivisor(1, 1)

        GLES30.glEnableVertexAttribArray(2)
        GLES30.glVertexAttribPointer(2, 3, GLES30.GL_FLOAT, false, instStride, 3 * 4)
        GLES30.glVertexAttribDivisor(2, 1)

        GLES30.glDrawArraysInstanced(
            GLES30.GL_TRIANGLES,
            0,
            6,
            WorldGenerator.GRASS_INSTANCE_COUNT
        )

        GLES30.glVertexAttribDivisor(1, 0)
        GLES30.glVertexAttribDivisor(2, 0)
        GLES30.glDisableVertexAttribArray(0)
        GLES30.glDisableVertexAttribArray(1)
        GLES30.glDisableVertexAttribArray(2)
    }

    fun handleTouchEvent(event: MotionEvent) {
        val scale = (screenH / 540f).coerceIn(1.0f, 3.0f)
        val action = event.actionMasked
        val idx = event.actionIndex
        val pointerId = event.getPointerId(idx)
        val x = event.getX(idx)
        val y = event.getY(idx)

        when (action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                if (x > screenW * 0.55f) {
                    handleActionTap(x, y, scale)
                } else if (joyPointerId == -1) {
                    joyPointerId = pointerId
                    joyCenterX = x
                    joyCenterY = y
                    joyKnobX = x
                    joyKnobY = y
                }
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.pointerCount) {
                    if (event.getPointerId(i) == joyPointerId) {
                        val mx = event.getX(i)
                        val my = event.getY(i)
                        val dx = mx - joyCenterX
                        val dy = my - joyCenterY
                        val maxR = 45f * scale
                        val dist = sqrt(dx * dx + dy * dy).coerceAtLeast(0.001f)
                        val clamped = dist.coerceAtMost(maxR)
                        joyKnobX = joyCenterX + (dx / dist) * clamped
                        joyKnobY = joyCenterY + (dy / dist) * clamped
                        player.moveInputX = (dx / maxR).coerceIn(-1f, 1f)
                        player.moveInputZ = (dy / maxR).coerceIn(-1f, 1f)
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                if (pointerId == joyPointerId) {
                    joyPointerId = -1
                    player.moveInputX = 0f
                    player.moveInputZ = 0f
                }
            }
        }
    }

    private fun handleActionTap(x: Float, y: Float, scale: Float) {
        val btnW = 92f * scale
        val btnH = 30f * scale
        val rightX = screenW - btnW - 16f * scale

        if (x >= rightX && x <= rightX + btnW) {
            when {
                y in (16f * scale)..(16f * scale + btnH) -> {
                    forgeOpen = !forgeOpen
                    return
                }
                y in (52f * scale)..(52f * scale + btnH) -> {
                    zoomIndex = (zoomIndex + 1) % zoomLabels.size
                    return
                }
                y in (88f * scale)..(88f * scale + btnH) -> {
                    player.toggleSteed()
                    return
                }
            }
        }

        val atkSize = 78f * scale
        val atkX = screenW - atkSize - 22f * scale
        val atkY = screenH - atkSize - 24f * scale
        if (x in atkX..(atkX + atkSize) && y in atkY..(atkY + atkSize)) {
            player.triggerAttack()
            return
        }

        val dodgeSize = 62f * scale
        val dodgeX = atkX - dodgeSize - 14f * scale
        val dodgeY = screenH - dodgeSize - 24f * scale
        if (x in dodgeX..(dodgeX + dodgeSize) && y in dodgeY..(dodgeY + dodgeSize)) {
            player.triggerDodge()
        }
    }

    fun exportSaveData(): SaveManager.PlayerSaveData {
        return SaveManager.PlayerSaveData(
            name = player.name,
            level = player.level,
            xp = player.xp,
            maxXp = player.maxXp,
            hp = player.hp,
            maxHp = player.maxHp,
            mp = player.mp,
            maxMp = player.maxMp,
            gold = player.gold,
            worldSeed = world.seed,
            posX = player.posX,
            posZ = player.posZ,
            isMounted = player.isMounted,
            equippedHelmMetal = player.equippedHelmMetal
        )
    }

    private fun setupGeometryBuffers() {
        val vbos = IntArray(4)
        GLES30.glGenBuffers(4, vbos, 0)
        terrainVbo = vbos[0]
        grassBladeVbo = vbos[1]
        grassInstanceVbo = vbos[2]
        boxVbo = vbos[3]

        val quadArr = IntArray(1)
        GLES30.glGenBuffers(1, quadArr, 0)
        fullscreenQuadVbo = quadArr[0]

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, terrainVbo)
        GLES30.glBufferData(
            GLES30.GL_ARRAY_BUFFER,
            world.terrainVertexBuffer.capacity() * 4,
            world.terrainVertexBuffer,
            GLES30.GL_STATIC_DRAW
        )

        val bladeVerts = floatArrayOf(
            -0.06f, 0.0f, 0.0f,
             0.06f, 0.0f, 0.0f,
             0.00f, 0.48f, 0.04f,
             0.00f, 0.0f, -0.06f,
             0.00f, 0.0f,  0.06f,
             0.04f, 0.48f, 0.00f
        )
        val bladeBuf = createFloatBuffer(bladeVerts)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, grassBladeVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, bladeVerts.size * 4, bladeBuf, GLES30.GL_STATIC_DRAW)

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, grassInstanceVbo)
        GLES30.glBufferData(
            GLES30.GL_ARRAY_BUFFER,
            world.grassInstanceBuffer.capacity() * 4,
            world.grassInstanceBuffer,
            GLES30.GL_STATIC_DRAW
        )

        val cube = buildUnitCube()
        val cubeBuf = createFloatBuffer(cube)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, boxVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, cube.size * 4, cubeBuf, GLES30.GL_STATIC_DRAW)

        val fsQuad = floatArrayOf(
            -1f, -1f, 0f, 0f,
             1f, -1f, 1f, 0f,
             1f,  1f, 1f, 1f,
            -1f, -1f, 0f, 0f,
             1f,  1f, 1f, 1f,
            -1f,  1f, 0f, 1f
        )
        val fsBuf = createFloatBuffer(fsQuad)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, fullscreenQuadVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, fsQuad.size * 4, fsBuf, GLES30.GL_STATIC_DRAW)
    }

    private fun rebuildFbo(w: Int, h: Int) {
        if (fboId != 0) {
            GLES30.glDeleteFramebuffers(1, intArrayOf(fboId), 0)
            GLES30.glDeleteTextures(1, intArrayOf(fboColorTex), 0)
            GLES30.glDeleteRenderbuffers(1, intArrayOf(fboDepthRbo), 0)
        }

        val fbos = IntArray(1)
        GLES30.glGenFramebuffers(1, fbos, 0)
        fboId = fbos[0]
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fboId)

        val texs = IntArray(1)
        GLES30.glGenTextures(1, texs, 0)
        fboColorTex = texs[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, fboColorTex)
        GLES30.glTexImage2D(
            GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA8, w, h, 0,
            GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null
        )
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glFramebufferTexture2D(
            GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0,
            GLES30.GL_TEXTURE_2D, fboColorTex, 0
        )

        val rbos = IntArray(1)
        GLES30.glGenRenderbuffers(1, rbos, 0)
        fboDepthRbo = rbos[0]
        GLES30.glBindRenderbuffer(GLES30.GL_RENDERBUFFER, fboDepthRbo)
        GLES30.glRenderbufferStorage(GLES30.GL_RENDERBUFFER, GLES30.GL_DEPTH_COMPONENT16, w, h)
        GLES30.glFramebufferRenderbuffer(
            GLES30.GL_FRAMEBUFFER, GLES30.GL_DEPTH_ATTACHMENT,
            GLES30.GL_RENDERBUFFER, fboDepthRbo
        )

        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
    }

    private fun createFloatBuffer(data: FloatArray): FloatBuffer =
        ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            put(data)
            position(0)
        }

    private fun buildUnitCube(): FloatArray {
        val p = arrayOf(
            floatArrayOf(-0.5f, -0.5f,  0.5f), floatArrayOf( 0.5f, -0.5f,  0.5f),
            floatArrayOf( 0.5f,  0.5f,  0.5f), floatArrayOf(-0.5f,  0.5f,  0.5f),
            floatArrayOf(-0.5f, -0.5f, -0.5f), floatArrayOf( 0.5f, -0.5f, -0.5f),
            floatArrayOf( 0.5f,  0.5f, -0.5f), floatArrayOf(-0.5f,  0.5f, -0.5f)
        )
        val faces = arrayOf(
            intArrayOf(0, 1, 2, 0, 2, 3),
            intArrayOf(5, 4, 7, 5, 7, 6),
            intArrayOf(4, 0, 3, 4, 3, 7),
            intArrayOf(1, 5, 6, 1, 6, 2),
            intArrayOf(3, 2, 6, 3, 6, 7),
            intArrayOf(4, 5, 1, 4, 1, 0)
        )
        val norms = arrayOf(
            floatArrayOf(0f, 0f, 1f), floatArrayOf(0f, 0f, -1f),
            floatArrayOf(-1f, 0f, 0f), floatArrayOf(1f, 0f, 0f),
            floatArrayOf(0f, 1f, 0f), floatArrayOf(0f, -1f, 0f)
        )
        val out = FloatArray(36 * 9)
        var k = 0
        for (f in 0 until 6) {
            for (v in faces[f]) {
                out[k++] = p[v][0]; out[k++] = p[v][1]; out[k++] = p[v][2]
                out[k++] = norms[f][0]; out[k++] = norms[f][1]; out[k++] = norms[f][2]
                out[k++] = 1f; out[k++] = 1f; out[k++] = 1f
            }
        }
        return out
    }

    companion object {
        private const val WORLD_VERT = """#version 300 es
            layout(location = 0) in vec3 aPos;
            layout(location = 1) in vec3 aNormal;
            layout(location = 2) in vec3 aColor;
            layout(location = 3) in float aSurface;

            uniform mat4 uVP;
            uniform mat4 uModel;

            out vec3 vWorldPos;
            out vec3 vNormal;
            out vec3 vColor;
            out float vSurface;

            void main() {
                vec4 wp = uModel * vec4(aPos, 1.0);
                vWorldPos = wp.xyz;
                vNormal = mat3(uModel) * aNormal;
                vColor = aColor;
                vSurface = aSurface;
                gl_Position = uVP * wp;
            }
        """

        private const val WORLD_FRAG = """#version 300 es
            precision mediump float;
            in vec3 vWorldPos;
            in vec3 vNormal;
            in vec3 vColor;
            in float vSurface;

            uniform float uTime;
            uniform vec3 uPlayerPos;
            uniform int uUseCustomTint;
            uniform vec3 uCustomTint;

            out vec4 fragColor;

            float hash(vec2 p) {
                return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
            }

            float noise(vec2 p) {
                vec2 i = floor(p);
                vec2 f = fract(p);
                f = f * f * (3.0 - 2.0 * f);
                return mix(
                    mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
                    mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x),
                    f.y
                );
            }

            void main() {
                vec3 N = normalize(vNormal);
                vec3 baseCol = (uUseCustomTint == 1) ? uCustomTint : vColor;

                if (uUseCustomTint == 0 && vSurface > 1.5) {
                    vec2 uv1 = vWorldPos.xz * 1.9 + vec2(uTime * 0.45, uTime * 0.25);
                    vec2 uv2 = vWorldPos.xz * 3.1 - vec2(uTime * 0.30, -uTime * 0.40);
                    float w1 = sin(uv1.x * 3.0 + noise(uv1) * 4.0);
                    float w2 = cos(uv2.y * 3.5 + noise(uv2) * 4.0);
                    N = normalize(vec3(w1 * 0.35, 1.0, w2 * 0.35));

                    float spec = pow(max(dot(N, normalize(vec3(-0.3, 0.85, -0.4))), 0.0), 12.0);
                    float reflDist = length(vWorldPos.xz - (uPlayerPos.xz + vec2(0.0, -1.6)));
                    float playerRefl = smoothstep(1.8, 0.2, reflDist) * 0.45;
                    baseCol = vec3(0.08, 0.14, 0.20) + vec3(0.65, 0.78, 0.88) * (spec + playerRefl);
                }

                vec3 moonDir = normalize(vec3(-0.35, 0.88, -0.32));
                float diff = max(dot(N, moonDir), 0.15);
                float lanternDist = length(vWorldPos.xz - uPlayerPos.xz);
                float lanternLight = smoothstep(6.5, 0.5, lanternDist) * 0.55;

                vec3 lit = baseCol * (diff + lanternLight);

                float fogNoise = noise(vWorldPos.xz * 0.22 + vec2(uTime * 0.14, uTime * 0.06));
                float distFog = smoothstep(8.0, 22.0, lanternDist);
                float mist = clamp(fogNoise * 0.42 + distFog * 0.65, 0.0, 0.85);
                vec3 fogColor = vec3(0.28, 0.33, 0.36);

                lit = mix(lit, fogColor, mist * 0.55);
                fragColor = vec4(lit, 1.0);
            }
        """

        private const val GRASS_VERT = """#version 300 es
            layout(location = 0) in vec3 aBladePos;
            layout(location = 1) in vec3 aInstPos;
            layout(location = 2) in vec3 aInstMeta;

            uniform mat4 uVP;
            uniform float uTime;
            uniform vec3 uPlayerPos;

            out float vTip;
            out float vIsFlower;

            void main() {
                float tip = clamp(aBladePos.y * 2.0, 0.0, 1.0);
                vec3 pos = aBladePos * aInstMeta.x;

                float gust = sin(uTime * 2.6 + aInstPos.x * 0.55 + aInstPos.z * 0.45 + aInstMeta.y);
                pos.x += gust * 0.14 * tip;
                pos.z += cos(uTime * 2.1 + aInstMeta.y) * 0.08 * tip;

                vec2 toGrass = aInstPos.xz - uPlayerPos.xz;
                float d = length(toGrass);
                if (d < 1.35 && d > 0.001) {
                    float push = (1.35 - d) * 0.45 * tip;
                    pos.xz += normalize(toGrass) * push;
                    pos.y *= (1.0 - 0.35 * tip);
                }

                vTip = tip;
                vIsFlower = aInstMeta.z;
                gl_Position = uVP * vec4(aInstPos + pos, 1.0);
            }
        """

        private const val GRASS_FRAG = """#version 300 es
            precision mediump float;
            in float vTip;
            in float vIsFlower;
            out vec4 fragColor;
            void main() {
                vec3 rootCol = vec3(0.05, 0.16, 0.07);
                vec3 tipCol = vec3(0.24, 0.54, 0.26);
                vec3 col = mix(rootCol, tipCol, vTip);
                if (vIsFlower > 0.5 && vTip > 0.65) {
                    col = vec3(0.86, 0.88, 0.96);
                }
                fragColor = vec4(col, 1.0);
            }
        """

        private const val POST_VERT = """#version 300 es
            layout(location = 0) in vec2 aPos;
            layout(location = 1) in vec2 aUv;
            out vec2 vUv;
            void main() {
                vUv = aUv;
                gl_Position = vec4(aPos, 0.0, 1.0);
            }
        """

        private const val POST_FRAG = """#version 300 es
            precision mediump float;
            in vec2 vUv;

            uniform sampler2D uSceneTex;
            uniform sampler2D uAtlasTex;
            uniform vec2 uGridSize;
            uniform float uTime;

            out vec4 fragColor;

            float luma(vec3 c) {
                return dot(c, vec3(0.299, 0.587, 0.114));
            }

            void main() {
                vec2 cellCoord = floor(vUv * uGridSize);
                vec2 cellCenterUv = (cellCoord + 0.5) / uGridSize;
                vec2 localUv = fract(vUv * uGridSize);

                vec3 centerCol = texture(uSceneTex, cellCenterUv).rgb;
                float lum = clamp(luma(centerCol) * 1.35, 0.0, 1.0);

                vec2 texel = 1.0 / uGridSize;
                float tl = luma(texture(uSceneTex, cellCenterUv + vec2(-texel.x,  texel.y)).rgb);
                float tc = luma(texture(uSceneTex, cellCenterUv + vec2(     0.0,  texel.y)).rgb);
                float tr = luma(texture(uSceneTex, cellCenterUv + vec2( texel.x,  texel.y)).rgb);
                float ml = luma(texture(uSceneTex, cellCenterUv + vec2(-texel.x,      0.0)).rgb);
                float mr = luma(texture(uSceneTex, cellCenterUv + vec2( texel.x,      0.0)).rgb);
                float bl = luma(texture(uSceneTex, cellCenterUv + vec2(-texel.x, -texel.y)).rgb);
                float bc = luma(texture(uSceneTex, cellCenterUv + vec2(     0.0, -texel.y)).rgb);
                float br = luma(texture(uSceneTex, cellCenterUv + vec2( texel.x, -texel.y)).rgb);

                float gx = -tl - 2.0 * ml - bl + tr + 2.0 * mr + br;
                float gy = -tl - 2.0 * tc - tr + bl + 2.0 * bc + br;
                float edgeMag = sqrt(gx * gx + gy * gy);

                float atlasCol;
                float atlasRow;

                if (edgeMag > 0.38) {
                    atlasRow = 1.0;
                    float angle = atan(gy, gx);
                    float normAngle = mod(angle + 3.14159265, 3.14159265);
                    if (normAngle < 0.39 || normAngle > 2.75) {
                        atlasCol = 0.0;
                    } else if (normAngle < 1.18) {
                        atlasCol = 3.0;
                    } else if (normAngle < 1.96) {
                        atlasCol = 1.0;
                    } else {
                        atlasCol = 2.0;
                    }
                } else {
                    atlasRow = 0.0;
                    atlasCol = floor(lum * 15.99);
                }

                vec2 glyphUv = (vec2(atlasCol, atlasRow) + localUv) / 16.0;
                float glyphMask = texture(uAtlasTex, glyphUv).r;

                vec3 bgTint = centerCol * 0.18;
                vec3 fgTint = clamp(centerCol * 1.55 + vec3(0.06), 0.0, 1.0);
                vec3 finalRgb = mix(bgTint, fgTint, glyphMask);

                fragColor = vec4(finalRgb, 1.0);
            }
        """
    }
}
