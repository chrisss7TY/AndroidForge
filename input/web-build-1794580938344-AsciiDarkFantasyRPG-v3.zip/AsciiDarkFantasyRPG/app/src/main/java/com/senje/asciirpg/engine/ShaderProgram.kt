package com.senje.asciirpg.engine

import android.opengl.GLES30
import android.util.Log

class ShaderProgram(vertexSource: String, fragmentSource: String) {

    val programId: Int

    init {
        val vertShader = compileShader(GLES30.GL_VERTEX_SHADER, vertexSource)
        val fragShader = compileShader(GLES30.GL_FRAGMENT_SHADER, fragmentSource)
        programId = GLES30.glCreateProgram()
        GLES30.glAttachShader(programId, vertShader)
        GLES30.glAttachShader(programId, fragShader)
        GLES30.glLinkProgram(programId)

        val linkStatus = IntArray(1)
        GLES30.glGetProgramiv(programId, GLES30.GL_LINK_STATUS, linkStatus, 0)
        if (linkStatus[0] == 0) {
            val info = GLES30.glGetProgramInfoLog(programId)
            GLES30.glDeleteProgram(programId)
            throw RuntimeException("Shader link error: $info")
        }
        GLES30.glDeleteShader(vertShader)
        GLES30.glDeleteShader(fragShader)
    }

    fun use() {
        GLES30.glUseProgram(programId)
    }

    fun getUniformLocation(name: String): Int = GLES30.glGetUniformLocation(programId, name)

    private fun compileShader(type: Int, source: String): Int {
        val shader = GLES30.glCreateShader(type)
        GLES30.glShaderSource(shader, source)
        GLES30.glCompileShader(shader)
        val compiled = IntArray(1)
        GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, compiled, 0)
        if (compiled[0] == 0) {
            val info = GLES30.glGetShaderInfoLog(shader)
            Log.e("AsciiShader", "Compile error: $info")
            GLES30.glDeleteShader(shader)
            throw RuntimeException("Shader compile error: $info")
        }
        return shader
    }
}
