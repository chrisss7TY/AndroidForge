plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.lumen"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.lumen"
        minSdk = 26
        targetSdk = 34
        // Always increasing, so every new build can be installed over the previous one
        versionCode = (System.currentTimeMillis() / 60000L).toInt()
        versionName = "1.2"
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    // One fixed signing key for every build. Android only lets you update an installed app when the
    // new APK is signed with the SAME key; a different key each build forces uninstall + reinstall.
    signingConfigs {
        create("lumen") {
            storeFile = file("lumen-release.jks")
            storePassword = "lumen2026"
            keyAlias = "lumen"
            keyPassword = "lumen2026"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("lumen")
        }
    }

    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += listOf(
            "-opt-in=androidx.media3.common.util.UnstableApi",
            "-opt-in=androidx.compose.foundation.ExperimentalFoundationApi",
            "-opt-in=androidx.compose.material3.ExperimentalMaterial3Api"
        )
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.2")
    // Installs the baseline profiles shipped inside Compose so UI code is precompiled (smooth first-run animations)
    implementation("androidx.profileinstaller:profileinstaller:1.3.1")
    implementation("dev.jdtech.mpv:libmpv:0.5.1")
    implementation("androidx.media3:media3-exoplayer:1.4.1")
}
