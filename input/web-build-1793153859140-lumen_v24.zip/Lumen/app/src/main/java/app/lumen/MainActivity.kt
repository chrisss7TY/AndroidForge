package app.lumen

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.RenderEffect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.view.Display
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import dev.jdtech.mpv.MPVLib
import kotlinx.coroutines.*
import java.io.File
import java.io.FileInputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.roundToInt

@Immutable
data class Vid(val uri: Uri, val name: String, val file: String, val dur: Long, val h: Int)

@Immutable
data class Cfg(
    val themeMode: String = "dark",
    val amoled: Boolean = true,
    val dynamic: Boolean = true,
    val skip: Int = 10,
    val speed: Float = 1f,
    val hide: Int = 3,
    val resume: Boolean = true,
    val hw: Boolean = true,
    val grid: Int = 160,
    val sort: String = "new",
    val autoLock: Boolean = true,
    val accent: String = "mint",
    val filter: String = "off",
    val filterStrength: Float = 1.0f,
    val info: Boolean = false,
    val showNames: Boolean = true,
    val preload: Boolean = true,
    val bufMb: Int = 128,
    val turbo4k: Boolean = true,
    val vcHash: String = "auto",
    val animations: Boolean = true,
    val engine: String = "auto"
) {
    fun save(sp: SharedPreferences) = sp.edit()
        .putString("themeMode", themeMode)
        .putBoolean("amoled", amoled)
        .putBoolean("dynamic", dynamic)
        .putInt("skip", skip)
        .putFloat("speed", speed)
        .putInt("hide", hide)
        .putBoolean("resume", resume)
        .putBoolean("hw", hw)
        .putInt("grid", grid)
        .putString("sort", sort)
        .putBoolean("autolock", autoLock)
        .putString("accent", accent)
        .putString("filter", filter)
        .putFloat("filterStrength", filterStrength)
        .putBoolean("info", info)
        .putBoolean("names", showNames)
        .putBoolean("preload", preload)
        .putInt("bufMb", bufMb)
        .putBoolean("turbo4k", turbo4k)
        .putString("vcHash", vcHash)
        .putBoolean("animations", animations)
        .putString("engine", engine)
        .apply()

    companion object {
        fun load(sp: SharedPreferences): Cfg {
            val rawFilter = sp.getString("filter", "off") ?: "off"
            val normFilter = if (rawFilter == "smooth") "soft" else rawFilter
            return Cfg(
                themeMode = sp.getString("themeMode", null)
                    ?: if (sp.getString("theme", "amoled") == "light") "light" else "dark",
                amoled = sp.getBoolean("amoled", true),
                dynamic = sp.getBoolean("dynamic", true),
                skip = sp.getInt("skip", 10),
                speed = sp.getFloat("speed", 1f),
                hide = sp.getInt("hide", 3),
                resume = sp.getBoolean("resume", true),
                hw = sp.getBoolean("hw", true),
                grid = sp.getInt("grid", 160),
                sort = sp.getString("sort", "new") ?: "new",
                autoLock = sp.getBoolean("autolock", true),
                accent = sp.getString("accent", "mint") ?: "mint",
                filter = normFilter,
                filterStrength = sp.getFloat("filterStrength", 1.0f).coerceIn(0.5f, 1.5f),
                info = sp.getBoolean("info", false),
                showNames = sp.getBoolean("names", true),
                preload = sp.getBoolean("preload", true),
                bufMb = sp.getInt("bufMb", 128).coerceIn(64, 256),
                turbo4k = sp.getBoolean("turbo4k", true),
                vcHash = sp.getString("vcHash", "auto") ?: "auto",
                animations = sp.getBoolean("animations", true),
                engine = sp.getString("engine", "auto") ?: "auto"
            )
        }
    }
}

private val ACCENTS = listOf(
    "mint" to (0xFF8FD9C9 to 0xFF17695B),
    "violet" to (0xFFB69CFF to 0xFF5B3FC4),
    "rose" to (0xFFFF9DB5 to 0xFFB3244F),
    "amber" to (0xFFFFC66B to 0xFF9A6200),
    "sky" to (0xFF8CC8FF to 0xFF1B64A8),
    "lime" to (0xFFC5E86C to 0xFF5B7A0A),
    "coral" to (0xFFFF9A85 to 0xFFB8421F)
)
@Composable
private fun Cfg.isLight(): Boolean = when (themeMode) {
    "light" -> true
    "dark" -> false
    else -> !isSystemInDarkTheme()
}
private val FILTERS = listOf(
    "off" to "Off",
    "soft" to "HDR Soft",
    "strong" to "HDR Strong",
    "cine" to "Cinematic"
)

/**
 * Hardware-accelerated MPV color-matrix grading parameters:
 * Applied directly inside mpv's single-pass YUV->RGB conversion matrix uniform (zero extra pass or CPU overhead).
 */
private data class MpvGrade(val contrast: Int, val brightness: Int, val gamma: Int, val saturation: Int, val hue: Int = 0)

private fun gradeFor(filter: String, strength: Float): MpvGrade {
    val s = strength.coerceIn(0.5f, 1.5f)
    // mpv: positive gamma lifts mid-tones (keeps the picture bright & open); negative gamma crushes them
    // and made the old presets look dark and muddy. These grades keep mid-tones lifted and add gentle
    // contrast / saturation so skin tones and highlights stay natural.
    return when (filter) {
        "soft" -> MpvGrade(
            contrast = (7 * s).roundToInt(),
            brightness = (1 * s).roundToInt(),
            gamma = (5 * s).roundToInt(),
            saturation = (10 * s).roundToInt()
        )
        "strong" -> MpvGrade(
            contrast = (13 * s).roundToInt(),
            brightness = 0,
            gamma = (4 * s).roundToInt(),
            saturation = (20 * s).roundToInt()
        )
        "cine" -> MpvGrade(
            contrast = (11 * s).roundToInt(),
            brightness = (-2 * s).roundToInt(),
            gamma = (2 * s).roundToInt(),
            saturation = (-9 * s).roundToInt()
        )
        else -> MpvGrade(0, 0, 0, 0, 0)
    }
}

/**
 * Builds an Android hardware ColorMatrix for ExoPlayer (API 31+ RenderEffect) matching the HDR/Cinematic look.
 */
private fun buildExoColorMatrix(filter: String, strength: Float): ColorMatrix? {
    if (filter == "off") return null
    val s = strength.coerceIn(0.5f, 1.5f)
    // contrast around mid-grey, then per-channel gain/offset (tint), then saturation
    fun grade(c: Float, lift: Float, r: Float, g: Float, b: Float, rOff: Float, bOff: Float, sat: Float): ColorMatrix {
        val t = (1f - c) * 127.5f + lift
        val cm = ColorMatrix(
            floatArrayOf(
                c * r, 0f, 0f, 0f, t + rOff,
                0f, c * g, 0f, 0f, t,
                0f, 0f, c * b, 0f, t + bOff,
                0f, 0f, 0f, 1f, 0f
            )
        )
        cm.postConcat(ColorMatrix().apply { setSaturation(sat) })
        return cm
    }
    return when (filter) {
        "soft" -> grade(1f + 0.07f * s, 4f * s, 1f, 1f, 1f, 0f, 0f, 1f + 0.12f * s)
        "strong" -> grade(1f + 0.13f * s, 2f * s, 1.015f, 1f, 0.99f, 0f, 0f, 1f + 0.22f * s)
        "cine" -> grade(1f + 0.10f * s, 3f * s, 1.035f, 1f, 0.96f, -2f * s, 5f * s, (1f - 0.09f * s).coerceAtLeast(0.75f))
        else -> null
    }
}

private class Snap(val pos: Double?, val dur: Double?, val paused: Boolean?, val info: String?)

private class PState {
    @Volatile var alive = true
    @Volatile var loaded = false
    @Volatile var target = ""
    val lock = Any()
}

@Immutable
class VList(val v: List<Vid>)

private val mpvQ = Executors.newSingleThreadExecutor { r ->
    Thread({
        runCatching { Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY) }
        r.run()
    }, "lumen-mpv")
}
@Volatile private var mpvUp = false
@Volatile private var mpvMade = false

private fun mpv(block: () -> Unit) {
    mpvQ.execute { if (mpvUp) try { block() } catch (e: Throwable) { } }
}

private fun <T : Any> mpvLatest(slot: AtomicReference<T?>, v: T, run: (T) -> Unit) {
    if (slot.getAndSet(v) == null) mpvQ.execute {
        val x = slot.getAndSet(null)
        if (x != null && mpvUp) try { run(x) } catch (e: Throwable) { }
    }
}
private val scrubSlot = AtomicReference<String?>(null)
private val zoomSlot = AtomicReference<DoubleArray?>(null)

@Composable private fun <A> stableCb(f: (A) -> Unit): (A) -> Unit {
    val s = rememberUpdatedState(f)
    return remember { { a: A -> s.value(a) } }
}
@Composable private fun stableCb0(f: () -> Unit): () -> Unit {
    val s = rememberUpdatedState(f)
    return remember { { s.value() } }
}

/**
 * Keeps a tab composed once built, with a cheap fade transition.
 * The fade runs entirely in the draw phase (no per-frame recomposition / re-measure) and uses
 * ModulateAlpha so no offscreen buffer is allocated for the whole screen.
 */
@Composable private fun TabHost(show: Boolean, animate: Boolean, content: @Composable () -> Unit) {
    val warm = remember { BooleanArray(1) }
    val alpha = remember { Animatable(if (show) 1f else 0f) }
    var hidden by remember { mutableStateOf(!show) }
    LaunchedEffect(show, animate) {
        if (show) hidden = false
        val target = if (show) 1f else 0f
        if (animate) alpha.animateTo(target, tween(140, easing = LinearOutSlowInEasing)) else alpha.snapTo(target)
        if (!show) hidden = true
    }
    Layout({
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    this.alpha = alpha.value
                    compositingStrategy = CompositingStrategy.ModulateAlpha
                }
        ) { content() }
    }) { ms, c ->
        if (!hidden || !warm[0]) {
            warm[0] = true
            val ps = ms.map { it.measure(c) }
            layout(c.maxWidth, c.maxHeight) { if (!hidden) ps.forEach { it.place(0, 0) } }
        } else layout(c.maxWidth, c.maxHeight) { }
    }
}

/**
 * Tactile spring press scale modifier operating purely in graphicsLayer (draw phase).
 * Observes pointer events on the Initial pass without consuming them so clicks and scrolling never conflict.
 */
@Composable
fun Modifier.pressBounce(enabled: Boolean = true): Modifier {
    if (!enabled) return this
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = spring(dampingRatio = 0.9f, stiffness = 700f),
        label = "pressBounce"
    )
    return this
        .pointerInput(Unit) {
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                pressed = true
                waitForUpOrCancellation(pass = PointerEventPass.Initial)
                pressed = false
            }
        }
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
}

private val RATES = listOf(1f, 1.25f, 1.5f, 2f, .5f, .75f)

// Larger memory cache (20% of heap) + RGB_565 bitmaps so thumbnails stay in RAM
private val THUMBS = object : LruCache<Uri, ImageBitmap>((Runtime.getRuntime().maxMemory() / 5).toInt()) {
    override fun sizeOf(key: Uri, value: ImageBitmap): Int = value.asAndroidBitmap().byteCount
}

// 4-to-6 thread parallel thumbnail pool + in-flight deduplication for ultra-fast grid loading
private val thumbPoolSize = Runtime.getRuntime().availableProcessors().coerceIn(4, 6)
private val thumbDisp = Executors.newFixedThreadPool(thumbPoolSize).asCoroutineDispatcher()
private val inFlightThumbs = ConcurrentHashMap<Uri, CompletableDeferred<ImageBitmap?>>()

fun fmt(s: Double) = "%d:%02d".format((s / 60).toInt(), (s % 60).toInt())

private suspend fun loadThumbFast(ctx: Context, uri: Uri): ImageBitmap? {
    THUMBS.get(uri)?.let { return it }
    val existing = inFlightThumbs[uri]
    if (existing != null) return existing.await()

    val deferred = CompletableDeferred<ImageBitmap?>()
    val prev = inFlightThumbs.putIfAbsent(uri, deferred)
    if (prev != null) return prev.await()

    return try {
        val res = withContext(thumbDisp) {
            Process.setThreadPriority(Process.THREAD_PRIORITY_DEFAULT + 2)
            THUMBS.get(uri)?.let { return@withContext it }

            val thumbDir = File(ctx.cacheDir, "thumbs").apply { mkdirs() }
            val cacheFile = File(thumbDir, "${uri.toString().hashCode()}.jpg")
            val decodeOpts = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.RGB_565 }

            // 1. Disk cache check (~1-2 ms)
            if (cacheFile.exists() && cacheFile.length() > 0L) {
                BitmapFactory.decodeFile(cacheFile.path, decodeOpts)?.let { bmp ->
                    val img = bmp.asImageBitmap()
                    THUMBS.put(uri, img)
                    return@withContext img
                }
            }

            // 2. Android 10+ MediaStore hardware thumbnail fast-path (~3-8 ms)
            if (Build.VERSION.SDK_INT >= 29 && uri.scheme == "content") {
                val sysBmp = runCatching {
                    ctx.contentResolver.loadThumbnail(uri, Size(512, 288), null)
                }.getOrNull()
                if (sysBmp != null && sysBmp.width > 16) {
                    runCatching { cacheFile.outputStream().use { sysBmp.compress(Bitmap.CompressFormat.JPEG, 82, it) } }
                    val img = sysBmp.asImageBitmap()
                    THUMBS.put(uri, img)
                    return@withContext img
                }
            }

            // 3. Hardware-scaled MediaMetadataRetriever fallback (supports all rotations)
            val extracted = frameOf(ctx, uri, 512)
            if (extracted != null) {
                runCatching { cacheFile.outputStream().use { extracted.compress(Bitmap.CompressFormat.JPEG, 82, it) } }
                val img = extracted.asImageBitmap()
                THUMBS.put(uri, img)
                return@withContext img
            }
            null
        }
        deferred.complete(res)
        res
    } catch (e: Throwable) {
        deferred.complete(null)
        null
    } finally {
        inFlightThumbs.remove(uri)
    }
}

/**
 * Pre-warms the OS page cache with the initial MBs of a 4K video file on a background IO thread
 * so neither the demuxer nor the software/hardware decoder stalls on flash storage reads.
 */
private suspend fun warmVideoPageCache(ctx: Context, uri: Uri, preloadMb: Int) = withContext(Dispatchers.IO) {
    runCatching {
        val bytesToWarm = preloadMb.coerceIn(32, 192) * 1024L * 1024L
        val buf = ByteArray(256 * 1024)
        var total = 0L
        if (uri.scheme == "file") {
            val f = File(uri.path ?: return@runCatching)
            if (!f.exists()) return@runCatching
            FileInputStream(f).use { fis ->
                while (isActive && total < bytesToWarm) {
                    val r = fis.read(buf)
                    if (r <= 0) break
                    total += r
                }
            }
        } else {
            ctx.contentResolver.openInputStream(uri)?.use { ins ->
                while (isActive && total < bytesToWarm) {
                    val r = ins.read(buf)
                    if (r <= 0) break
                    total += r
                }
            }
        }
    }
}

@Composable fun BoxScope.Badges(h: Int, dur: Long) {
    val k = h >= 2000
    if (h > 0) Text(
        if (k) "4K" else "${h}p",
        Modifier
            .align(Alignment.BottomStart)
            .padding(8.dp)
            .clip(RoundedCornerShape(7.dp))
            .background(if (k) Color(0xFFFFC66B) else Color(0x99000000))
            .padding(horizontal = 7.dp, vertical = 3.dp),
        fontSize = 11.sp,
        color = if (k) Color(0xFF2B1B00) else Color.White,
        fontWeight = FontWeight.SemiBold
    )
    Text(
        fmt(dur / 1000.0),
        Modifier
            .align(Alignment.BottomEnd)
            .padding(8.dp)
            .clip(RoundedCornerShape(7.dp))
            .background(Color(0x99000000))
            .padding(horizontal = 7.dp, vertical = 3.dp),
        fontSize = 11.sp,
        color = Color.White,
        fontWeight = FontWeight.SemiBold
    )
}

class MainActivity : ComponentActivity() {
    private var opened by mutableStateOf<Uri?>(null)
    private var vtick by mutableIntStateOf(0)
    private var forceMpv by mutableStateOf<Uri?>(null)
    private var forceWeb by mutableStateOf<Uri?>(null)
    private var live = false
    private var autoLock = true
    private var suppressLock = false
    private var tempPlay: File? = null
    private val vault by lazy { Vault(this) }
    private val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        @Suppress("DEPRECATION") run {
            window.statusBarColor = android.graphics.Color.TRANSPARENT
            window.navigationBarColor = android.graphics.Color.TRANSPARENT
        }
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        runCatching {
            @Suppress("DEPRECATION") val d = windowManager.defaultDisplay
            val cur = d.mode
            sameRes = d.supportedModes.filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
            maxMode = sameRes.maxByOrNull { it.refreshRate }
            setMode(null)
        }
        File(cacheDir, "play").deleteRecursively()
        opened = intent?.data
        setContent { App() }
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        i.data?.let { opened = it }
    }

    private var sameRes: List<Display.Mode> = emptyList()
    private var maxMode: Display.Mode? = null

    /** Keeps the panel at its highest refresh rate (e.g. 120Hz) so VSync never bottlenecks 4K frame delivery. */
    private fun setMode(m: Display.Mode?) {
        val t = m ?: maxMode ?: return
        runCatching {
            val lp = window.attributes
            if (lp.preferredDisplayModeId != t.modeId) {
                lp.preferredDisplayModeId = t.modeId
                lp.preferredRefreshRate = t.refreshRate
                window.attributes = lp
            }
        }
    }

    override fun onStop() {
        super.onStop()
        if (live) mpv { MPVLib.setPropertyBoolean("pause", true) }
        if (autoLock && !suppressLock && vault.unlocked) { vault.lock(); vtick++ }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) File(cacheDir, "play").deleteRecursively()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private suspend fun scan(): List<Vid> = withContext(Dispatchers.IO) {
        val out = ArrayList<Vid>()
        val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        contentResolver.query(base, arrayOf("_id", "_display_name", "duration", "height"), null, null, "date_added DESC")?.use {
            while (it.moveToNext()) {
                val file = it.getString(1) ?: "video.mp4"
                out += Vid(ContentUris.withAppendedId(base, it.getLong(0)), file.substringBeforeLast('.'), file, it.getLong(2), it.getInt(3))
            }
        }
        out
    }

    @Composable fun App() {
        val ctx = LocalContext.current
        val sp = remember { getSharedPreferences("s", 0) }
        var cfg by remember { mutableStateOf(Cfg.load(sp)) }
        var tab by remember { mutableIntStateOf(0) }
        var settingsCat by remember { mutableStateOf<String?>(null) }
        var list by remember { mutableStateOf(listOf<Vid>()) }
        var prep by remember { mutableStateOf(false) }
        var built by remember { mutableStateOf(setOf(0)) }
        val unlocked = vtick >= 0 && vault.unlocked
        val scope = rememberCoroutineScope()
        val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) scope.launch { list = scan() }
        }
        val del = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) {
            suppressLock = false
            scope.launch { list = scan() }
        }

        LaunchedEffect(Unit) {
            if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) list = scan() else ask.launch(perm)
        }
        // Background thumbnail pre-warmer: warms the first 24 videos right after scanning so scrolling is instant
        LaunchedEffect(list) {
            if (list.isNotEmpty()) {
                withContext(Dispatchers.IO) {
                    list.take(24).forEach { vid ->
                        launch { loadThumbFast(ctx, vid.uri) }
                    }
                }
            }
        }
        LaunchedEffect(Unit) { delay(500); built = built + 2; delay(350); built = built + 1 }
        LaunchedEffect(tab) {
            built = built + tab
            if (tab != 2) settingsCat = null
        }
        SideEffect { autoLock = cfg.autoLock }

        val light = cfg.isLight()
        val cs = remember(light, cfg.amoled, cfg.dynamic, cfg.accent) {
            val acc = ACCENTS.firstOrNull { it.first == cfg.accent } ?: ACCENTS[0]
            val prim = Color(if (light) acc.second.second else acc.second.first)
            val useDyn = cfg.dynamic && Build.VERSION.SDK_INT >= 31
            if (useDyn) {
                val base = if (light) dynamicLightColorScheme(ctx) else dynamicDarkColorScheme(ctx)
                if (!light && cfg.amoled) base.copy(
                    background = Color.Black,
                    surface = base.surfaceContainer
                ) else base.copy(surface = base.surfaceContainer)
            } else if (!light) {
                val bgc = if (cfg.amoled) 0xFF000000 else 0xFF0B0E11
                val sfc = if (cfg.amoled) 0xFF1E2025 else 0xFF1D2026
                darkColorScheme(
                    primary = prim,
                    onPrimary = Color.Black,
                    background = Color(bgc),
                    surface = Color(sfc),
                    onBackground = Color(0xFFF2F4F8),
                    onSurface = Color(0xFFF2F4F8),
                    onSurfaceVariant = Color(0xFF9AA0A6),
                    secondaryContainer = prim.copy(alpha = .28f).compositeOver(Color(sfc)),
                    onSecondaryContainer = Color(0xFFF2F4F8)
                )
            } else lightColorScheme(
                primary = prim,
                onPrimary = Color.White,
                background = Color(0xFFF3F7F6),
                surface = Color.White,
                onBackground = Color(0xFF101514),
                onSurface = Color(0xFF101514),
                onSurfaceVariant = Color(0xFF55615E),
                secondaryContainer = prim.copy(alpha = .18f).compositeOver(Color.White),
                onSecondaryContainer = Color(0xFF101514)
            )
        }
        LaunchedEffect(light) {
            val c = WindowInsetsControllerCompat(window, window.decorView)
            c.isAppearanceLightStatusBars = light
            c.isAppearanceLightNavigationBars = light
        }
        val shown = remember(list, cfg.sort) {
            VList(
                when (cfg.sort) {
                    "name" -> list.sortedBy { it.name.lowercase() }
                    "dur" -> list.sortedByDescending { it.dur }
                    else -> list
                }
            )
        }

        fun playTempFile(f: File) {
            tempPlay = f
            opened = Uri.fromFile(f)
        }

        val onOpen = stableCb<Uri> { opened = it }
        val onMove = stableCb<Vid> { }
        val onPlayFile = stableCb<Uri> { opened = it }
        val onNote = stableCb<String> { toast(it) }
        val onPick = stableCb<Boolean> { suppressLock = it }
        val onChange = stableCb0 { vtick++ }
        val onLock = stableCb0 { vault.lock(); vtick++ }
        val onUpd = stableCb<Cfg> { cfg = it; it.save(sp) }
        val navTabs = remember {
            listOf(
                Icons.Rounded.VideoLibrary to "Library",
                Icons.Rounded.Lock to "Vault",
                Icons.Rounded.Tune to "Settings"
            )
        }
        val playing = opened != null

        MaterialTheme(cs) {
            Surface(Modifier.fillMaxSize(), color = cs.background, contentColor = cs.onBackground) {
                Box(Modifier.fillMaxSize()) {
                    Column(
                        Modifier
                            .fillMaxSize()
                            .statusBarsPadding()
                            .padding(horizontal = if (tab == 2) 14.dp else 12.dp)
                    ) {
                        if (tab != 2) {
                            Text(
                                text = if (tab == 0) "Library" else "Vault",
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(start = 4.dp, top = 16.dp, bottom = 10.dp)
                            )
                        }
                        Box(Modifier.weight(1f).fillMaxWidth()) {
                            TabHost(tab == 0 && !playing, cfg.animations) {
                                Library(shown, cfg.grid, cfg.showNames, cfg.animations, onOpen, onMove)
                            }
                            if (1 in built) TabHost(tab == 1 && !playing, cfg.animations) {
                                VaultScreen(vault, vtick, cfg.vcHash, onChange, onPick, onNote)
                            }
                            if (2 in built) TabHost(tab == 2 && !playing, cfg.animations) {
                                CategorizedSettingsScreen(
                                    cfg = cfg,
                                    unlocked = unlocked,
                                    vault = vault,
                                    activeCategory = settingsCat,
                                    onSelectCategory = { settingsCat = it },
                                    onBackToLibrary = { tab = 0 },
                                    onUpdate = onUpd,
                                    onLockNow = onLock,
                                    onGoToVault = { tab = 1 },
                                    notify = onNote
                                )
                            }
                        }
                    }
                    if (!playing) {
                        LumenNav(
                            sel = tab,
                            tabs = navTabs,
                            animate = cfg.animations,
                            onSel = { tab = it },
                            m = Modifier
                                .align(Alignment.BottomCenter)
                                .navigationBarsPadding()
                                .padding(bottom = 14.dp)
                        )
                    }
                    if (vault.mounted != null) VaultBrowser(vault, onPlayFile, onPick, onNote)
                    opened?.let { u ->
                        key(u) {
                            val close: () -> Unit = {
                                opened = null
                                val tmp = tempPlay; tempPlay = null
                                if (tmp != null) scope.launch(Dispatchers.IO) { runCatching { tmp.delete() } }
                            }
                            // Auto: hardware player if a real HW decoder fits the file, else Chromium's pipeline, then MPV
                            val eng by produceState<String?>(null, u, cfg.engine, cfg.hw, forceMpv, forceWeb) {
                                value = when {
                                    cfg.engine != "auto" -> cfg.engine
                                    forceMpv == u -> "mpv"
                                    forceWeb == u -> "web"
                                    !cfg.hw -> if (u.scheme == "lumenvc") "web" else "mpv"
                                    else -> withContext(Dispatchers.IO) { if (hwCanDecode(this@MainActivity, u)) "exo" else "web" }
                                }
                            }
                            when (eng) {
                                null -> Box(Modifier.fillMaxSize().background(Color.Black))
                                "exo" -> ExoScreen(u, cfg, { forceWeb = u }, close)
                                "web" -> WebScreen(u, cfg, { forceMpv = u }, close)
                                else -> Player(u, cfg, close)
                            }
                        }
                    }
                    if (prep) {
                        Box(
                            Modifier
                                .fillMaxSize()
                                .background(Color(0xAA000000))
                                .pointerInput(Unit) { detectTapGestures { } },
                            contentAlignment = Alignment.Center
                        ) { CircularProgressIndicator() }
                    }
                }
            }
        }
    }

    /**
     * High-performance 4K MPV Player with:
     * - Asynchronous video & audio decoded-frame ring buffer (vd-queue-enable=yes, ad-queue-enable=yes)
     * - Single-pass direct screen rendering (gpu-dumb-mode=yes, opengl-pbo=no) eliminating 4K FBO GPU bottlenecks
     * - Non-reference-only decoder frame-drop protection (vd-lavc-framedrop=nonref, framedrop=vo) preventing 240-frame GOP drops
     * - URGENT_DISPLAY thread priority so Android schedules 4K decode threads on prime/big CPU cores
     * - OS page-cache readahead preloader + initial frame-queue pre-buffer warm-up
     */
    @Composable fun Player(uri: Uri, cfg: Cfg, onClose: () -> Unit) {
        val ctx = LocalContext.current
        val sp = remember { ctx.getSharedPreferences("s", 0) }
        val st = remember { PState() }
        var ready by remember { mutableStateOf(false) }
        var preloading by remember { mutableStateOf(cfg.preload) }
        var pos by remember { mutableDoubleStateOf(0.0) }
        var dur by remember { mutableDoubleStateOf(1.0) }
        var paused by remember { mutableStateOf(false) }
        var ui by remember { mutableStateOf(true) }
        var zoom by remember { mutableFloatStateOf(1f) }
        var px by remember { mutableFloatStateOf(0f) }
        var py by remember { mutableFloatStateOf(0f) }
        var w by remember { mutableIntStateOf(1) }
        var speed by remember { mutableFloatStateOf(cfg.speed) }
        var drag by remember { mutableStateOf<Float?>(null) }
        var filter by remember { mutableStateOf(cfg.filter) }
        var filterStrength by remember { mutableFloatStateOf(cfg.filterStrength) }
        var filterMenu by remember { mutableStateOf(false) }
        var info by remember { mutableStateOf("") }
        var seekIndicator by remember { mutableStateOf<String?>(null) }
        var seekTick by remember { mutableIntStateOf(0) }
        val skip = cfg.skip

        // Stage 1 Preloader: warm OS file page cache in background immediately
        LaunchedEffect(uri, cfg.preload, cfg.bufMb) {
            if (cfg.preload) {
                warmVideoPageCache(ctx, uri, cfg.bufMb)
            }
        }

        // Apply hardware YUV->RGB color matrix adjustments whenever filter or strength changes
        LaunchedEffect(filter, filterStrength, ready) {
            if (!ready) return@LaunchedEffect
            val g = gradeFor(filter, filterStrength)
            mpv {
                MPVLib.setPropertyInt("contrast", g.contrast)
                MPVLib.setPropertyInt("brightness", g.brightness)
                MPVLib.setPropertyInt("gamma", g.gamma)
                MPVLib.setPropertyInt("saturation", g.saturation)
                MPVLib.setPropertyInt("hue", g.hue)
            }
        }

        // Auto-hide double-tap seek indicator
        LaunchedEffect(seekTick) {
            if (seekIndicator != null) {
                delay(650)
                seekIndicator = null
            }
        }

        DisposableEffect(Unit) {
            live = true
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            val bars = WindowInsetsControllerCompat(window, window.decorView)
            bars.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            bars.hide(WindowInsetsCompat.Type.systemBars())
            setMode(null) // Lock display to max refresh rate (e.g. 120Hz) before surface creation

            val appCtx = ctx.applicationContext
            val hw = cfg.hw
            val speed0 = cfg.speed
            val resumeAt = if (cfg.resume) sp.getFloat("p:$uri", 0f) else 0f
            val bufMb = cfg.bufMb
            val turbo = cfg.turbo4k
            val initialGrade = gradeFor(cfg.filter, cfg.filterStrength)

            mpvQ.execute {
                if (!st.alive) return@execute
                try {
                    runCatching { Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY) }
                    st.target = if (uri.scheme == "file") uri.path!! else {
                        val fd = runCatching { appCtx.contentResolver.openFileDescriptor(uri, "r")?.detachFd() }.getOrNull()
                        if (fd != null) "fd://$fd" else uri.toString()
                    }
                    MPVLib.create(appCtx)
                    mpvMade = true
                    val threads = Runtime.getRuntime().availableProcessors().coerceIn(4, 8).toString()
                    val opts = mapOf(
                        "profile" to "fast",
                        "vo" to "gpu",
                        "gpu-context" to "android",
                        "opengl-es" to "yes",
                        // Single-pass direct screen rendering: avoids 3840x2160 intermediate FBO passes on non-4K mobile GPUs
                        "gpu-dumb-mode" to "yes",
                        "opengl-pbo" to "no",
                        "opengl-swapinterval" to "1",
                        // Zero-copy mediacodec first (frames stay on the GPU); mediacodec-copy (CPU readback, slow at 4K)
                        // is only a fallback, then software decode
                        "hwdec" to (if (hw) "mediacodec,mediacodec-copy" else "no"),
                        "hwdec-codecs" to "all",
                        "vd-lavc-software-fallback" to "yes",
                        // Multi-threaded 4K software decode tuned to never drop reference P-frames (fixes "dropped dec 240")
                        "vd-lavc-threads" to threads,
                        "vd-lavc-fast" to "yes",
                        "vd-lavc-dr" to "yes",
                        "vd-lavc-skiploopfilter" to (if (turbo) "all" else "nonkey"),
                        "vd-lavc-skipidct" to "nonref",
                        "vd-lavc-framedrop" to "nonref",
                        "framedrop" to "vo",
                        "video-sync" to "audio",
                        // Asynchronous decoded-frame ring buffer (pre-decodes 4K frames in background ahead of VSync)
                        "vd-queue-enable" to "yes",
                        "vd-queue-max-samples" to "48",
                        "vd-queue-max-bytes" to "${bufMb}MiB",
                        "vd-queue-max-secs" to "3.5",
                        "ad-queue-enable" to "yes",
                        "ad-queue-max-secs" to "3.5",
                        // Demuxer readahead & cache preloader
                        "demuxer-thread" to "yes",
                        "cache" to "yes",
                        "cache-secs" to "45",
                        "cache-pause" to "yes",
                        "cache-pause-initial" to "yes",
                        "cache-pause-wait" to "0.4",
                        "demuxer-max-bytes" to "${bufMb * 2}MiB",
                        "demuxer-max-back-bytes" to "64MiB",
                        "demuxer-readahead-secs" to "45",
                        // Fast scaling & color
                        "sws-fast" to "yes",
                        "sws-scaler" to "fast-bilinear",
                        "scale" to "bilinear",
                        "dscale" to "bilinear",
                        "cscale" to "bilinear",
                        "correct-downscaling" to "no",
                        "sigmoid-upscaling" to "no",
                        "deband" to "no",
                        "dither-depth" to "no",
                        "interpolation" to "no",
                        "blend-subtitles" to "no",
                        "hdr-compute-peak" to "no",
                        "tone-mapping" to "hable",
                        "contrast" to initialGrade.contrast.toString(),
                        "brightness" to initialGrade.brightness.toString(),
                        "gamma" to initialGrade.gamma.toString(),
                        "saturation" to initialGrade.saturation.toString(),
                        "hue" to initialGrade.hue.toString(),
                        "ao" to "audiotrack,opensles",
                        "keep-open" to "yes",
                        "speed" to speed0.toString()
                    )
                    opts.forEach { (k, v) -> MPVLib.setOptionString(k, v) }
                    if (resumeAt > 5f) MPVLib.setOptionString("start", resumeAt.toString())
                    MPVLib.init()
                    if (st.alive) { mpvUp = true; ready = true }
                } catch (e: Throwable) {
                    runOnUiThread { toast("Couldn’t start the player"); onClose() }
                }
            }
            onDispose {
                st.alive = false; mpvUp = false
                live = false
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                bars.show(WindowInsetsCompat.Type.systemBars())
                val key = "p:$uri"
                mpvQ.execute {
                    if (!mpvMade) return@execute
                    try {
                        synchronized(st.lock) {
                            val p = MPVLib.getPropertyDouble("time-pos")
                            val d = MPVLib.getPropertyDouble("duration")
                            sp.edit().apply {
                                if (p != null && d != null && p > 5 && p < d - 10) putFloat(key, p.toFloat()) else remove(key)
                            }.apply()
                            MPVLib.command(arrayOf("stop"))
                            MPVLib.detachSurface()
                            MPVLib.destroy()
                        }
                    } catch (e: Throwable) { } finally {
                        mpvMade = false; mpvUp = false
                    }
                }
            }
        }

        // Stage 2 Preloader: let vd-queue fill decoded frames for 380ms on initial open so playback starts with a full ring buffer
        LaunchedEffect(ready) {
            if (!ready) return@LaunchedEffect
            if (cfg.preload) {
                delay(380)
                if (st.alive && mpvUp && !paused) {
                    mpv { MPVLib.setPropertyBoolean("pause", false) }
                }
                preloading = false
            }
        }

        LaunchedEffect(ui, ready) {
            var n = 0
            while (ui && ready && st.alive) {
                val wantInfo = cfg.info && n % 3 == 0; n++
                val r = withContext(Dispatchers.Default) {
                    synchronized(st.lock) {
                        if (!st.alive || !mpvUp) null else Snap(
                            MPVLib.getPropertyDouble("time-pos"),
                            MPVLib.getPropertyDouble("duration"),
                            MPVLib.getPropertyBoolean("pause"),
                            if (wantInfo) {
                                fun p(k: String) = MPVLib.getPropertyString(k) ?: "?"
                                val hwStr = p("hwdec-current").let { if (it == "no" || it.isEmpty()) "sw-turbo (${Runtime.getRuntime().availableProcessors()}c)" else it }
                                "hw: $hwStr · ${p("video-format")} ${p("width")}x${p("height")} · ${p("container-fps").take(5)}fps · q:${cfg.bufMb}M · drop dec ${p("decoder-frame-drop-count")} / vo ${p("frame-drop-count")}"
                            } else null
                        )
                    }
                }
                if (r != null) {
                    if (drag == null) pos = r.pos ?: pos
                    dur = (r.dur ?: dur).coerceAtLeast(0.1)
                    if (!preloading) paused = r.paused ?: false
                    r.info?.let { info = it }
                }
                delay(250)
            }
        }

        LaunchedEffect(ui, paused) {
            if (ui && !paused && cfg.hide > 0) {
                delay(cfg.hide * 1000L)
                ui = false
            }
        }

        fun seek(s: Int) {
            seekIndicator = if (s < 0) "« ${abs(s)}s" else "${s}s »"
            seekTick++
            mpv { MPVLib.command(arrayOf("seek", s.toString(), "relative")) }
        }

        fun applyZoom() {
            mpvLatest(zoomSlot, doubleArrayOf(ln(zoom.toDouble()) / ln(2.0), (px / w).toDouble(), (py / w).toDouble())) {
                MPVLib.setPropertyDouble("video-zoom", it[0])
                MPVLib.setPropertyDouble("video-pan-x", it[1])
                MPVLib.setPropertyDouble("video-pan-y", it[2])
            }
        }

        val hudAlpha by animateFloatAsState(
            targetValue = if (ui) 1f else 0f,
            animationSpec = tween(200, easing = FastOutSlowInEasing),
            label = "hudAlpha"
        )

        BackHandler(onBack = onClose)
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black)
                .onSizeChanged { w = it.width.coerceAtLeast(1) }
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, z, _ ->
                        val nz = (zoom * z).coerceIn(1f, 6f)
                        if (nz > 1f) { px += pan.x; py += pan.y } else { px = 0f; py = 0f }
                        if (nz != zoom || nz > 1f) { zoom = nz; applyZoom() }
                    }
                }
                .pointerInput(skip) {
                    detectTapGestures(
                        onDoubleTap = { seek(if (it.x < size.width / 2) -skip else skip) },
                        onTap = { ui = !ui }
                    )
                }
        ) {
            if (ready) {
                AndroidView(
                    factory = { c ->
                        SurfaceView(c).apply {
                            holder.addCallback(object : SurfaceHolder.Callback {
                                override fun surfaceCreated(h: SurfaceHolder) {
                                    if (!st.alive || !mpvUp) return
                                    val sf = h.surface
                                    val doPreload = cfg.preload
                                    mpv {
                                        if (!sf.isValid) return@mpv
                                        MPVLib.attachSurface(sf)
                                        MPVLib.setOptionString("force-window", "yes")
                                        if (!st.loaded) {
                                            st.loaded = true
                                            if (doPreload) MPVLib.setPropertyBoolean("pause", true)
                                            MPVLib.command(arrayOf("loadfile", st.target))
                                        } else {
                                            MPVLib.setPropertyString("vo", "gpu")
                                        }
                                    }
                                }
                                override fun surfaceChanged(h: SurfaceHolder, f: Int, a: Int, b: Int) {
                                    if (st.alive && mpvUp) mpv { MPVLib.setPropertyString("android-surface-size", "${a}x$b") }
                                }
                                override fun surfaceDestroyed(h: SurfaceHolder) {
                                    if (!st.alive || !mpvUp) return
                                    MPVLib.setPropertyString("vo", "null")
                                    MPVLib.setOptionString("force-window", "no")
                                    MPVLib.detachSurface()
                                }
                            })
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }


            // Preloading / buffering pill
            AnimatedVisibility(
                visible = preloading,
                enter = fadeIn() + scaleIn(initialScale = 0.9f),
                exit = fadeOut() + scaleOut(targetScale = 0.9f),
                modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 60.dp)
            ) {
                Row(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color(0xCC181B22))
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CircularProgressIndicator(Modifier.size(15.dp), strokeWidth = 2.dp, color = Color(0xFF63D2EB))
                    Text("Preloading 4K buffer (${cfg.bufMb} MB)…", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
            }

            // Double-tap seek pill
            AnimatedVisibility(
                visible = seekIndicator != null,
                enter = fadeIn(tween(120)) + scaleIn(tween(120), initialScale = 0.85f),
                exit = fadeOut(tween(180)),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Text(
                    text = seekIndicator ?: "",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color(0xAA000000))
                        .padding(horizontal = 22.dp, vertical = 10.dp)
                )
            }

            if (ui || hudAlpha > 0.01f) {
                Column(
                    Modifier
                        .fillMaxSize()
                        .graphicsLayer { alpha = hudAlpha }
                        .background(Brush.verticalGradient(listOf(Color(0x99000000), Color.Transparent, Color(0xB3000000))))
                        .statusBarsPadding()
                        .navigationBarsPadding()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { if (ui) onClose() }) {
                            Icon(Icons.Rounded.ArrowBackIosNew, null, tint = Color.White)
                        }
                        if (cfg.info) {
                            Text(
                                info,
                                Modifier.weight(1f).padding(start = 8.dp),
                                color = Color.White.copy(.88f),
                                fontSize = 10.5.sp,
                                lineHeight = 13.sp
                            )
                        }
                    }
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton({ if (ui) seek(-skip) }) {
                            Icon(Icons.Rounded.Replay10, null, tint = Color.White, modifier = Modifier.size(36.dp))
                        }
                        Spacer(Modifier.width(24.dp))
                        FilledIconButton(
                            onClick = {
                                if (ui) {
                                    val np = !paused; paused = np
                                    mpv { MPVLib.setPropertyBoolean("pause", np) }
                                }
                            },
                            modifier = Modifier.size(76.dp).pressBounce(),
                            colors = IconButtonDefaults.filledIconButtonColors(Color.White, Color.Black)
                        ) {
                            Icon(if (paused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause, null, Modifier.size(40.dp))
                        }
                        Spacer(Modifier.width(24.dp))
                        IconButton({ if (ui) seek(skip) }) {
                            Icon(Icons.Rounded.Forward10, null, tint = Color.White, modifier = Modifier.size(36.dp))
                        }
                    }
                    Column {
                        AnimatedVisibility(visible = filterMenu) {
                            FilterPanel(
                                filter = filter,
                                strength = filterStrength,
                                onFilter = { if (ui) filter = it },
                                onStrength = { if (ui) filterStrength = it }
                            )
                        }
                        Slider(
                            value = drag ?: (pos / dur).toFloat().coerceIn(0f, 1f),
                            onValueChange = {
                                if (ui) {
                                    drag = it
                                    mpvLatest(scrubSlot, (it * dur).toString()) { s ->
                                        MPVLib.command(arrayOf("seek", s, "absolute+keyframes"))
                                    }
                                }
                            },
                            onValueChangeFinished = {
                                drag?.let { f ->
                                    val s = (f * dur).toString()
                                    mpv { MPVLib.command(arrayOf("seek", s, "absolute+exact")) }
                                }
                                drag = null
                            }
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("${fmt(pos)} / ${fmt(dur)}", color = Color.White, fontSize = 12.sp)
                            Spacer(Modifier.weight(1f))
                            FilterButton(filter, filterMenu) { if (ui) filterMenu = !filterMenu }
                            TextButton({
                                if (ui) {
                                    speed = RATES[(RATES.indexOf(speed) + 1) % RATES.size]
                                    val sp2 = speed.toDouble()
                                    mpv { MPVLib.setPropertyDouble("speed", sp2) }
                                }
                            }) { Text("${speed}×", color = Color.White) }
                        }
                    }
                }
            }
        }
    }

    /**
     * ExoPlayer hardware screen with a large preload buffer (DefaultLoadControl)
     * and automatic fallback to the 4K-tuned MPV engine if the device's MediaCodec rejects 4K or drops frames.
     */
    @androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
    @Composable fun ExoScreen(uri: Uri, cfg: Cfg, onFail: () -> Unit, onClose: () -> Unit) {
        val ctx = LocalContext.current
        val sp = remember { ctx.getSharedPreferences("s", 0) }
        val failCb by rememberUpdatedState(onFail)
        val failed = remember { BooleanArray(1) }
        var pos by remember { mutableDoubleStateOf(0.0) }
        var dur by remember { mutableDoubleStateOf(1.0) }
        var paused by remember { mutableStateOf(false) }
        var ui by remember { mutableStateOf(true) }
        var zoom by remember { mutableFloatStateOf(1f) }
        var px by remember { mutableFloatStateOf(0f) }
        var py by remember { mutableFloatStateOf(0f) }
        var speed by remember { mutableFloatStateOf(cfg.speed) }
        var drag by remember { mutableStateOf<Float?>(null) }
        var filter by remember { mutableStateOf(cfg.filter) }
        var filterStrength by remember { mutableFloatStateOf(cfg.filterStrength) }
        var filterMenu by remember { mutableStateOf(false) }
        var info by remember { mutableStateOf("") }
        var dec by remember { mutableStateOf("…") }
        var dropped by remember { mutableIntStateOf(0) }
        var ratio by remember { mutableFloatStateOf(16f / 9f) }
        var isBuffering by remember { mutableStateOf(false) }
        val skip = cfg.skip
        val last = remember { LongArray(1) }

        LaunchedEffect(uri, cfg.preload, cfg.bufMb) {
            if (cfg.preload) warmVideoPageCache(ctx, uri, cfg.bufMb)
        }

        val exo = remember {
            val loadControl = androidx.media3.exoplayer.DefaultLoadControl.Builder()
                .setBufferDurationsMs(15_000, 60_000, 800, 1_800)
                .setTargetBufferBytes(cfg.bufMb * 1024 * 1024)
                .setPrioritizeTimeOverSizeThresholds(true)
                .build()
            // Hardware video decoders only: if none fits, fail cleanly (to Chromium/MPV) instead of silently lagging on a software decoder
            val renderersFactory = androidx.media3.exoplayer.DefaultRenderersFactory(ctx)
                .setEnableDecoderFallback(false)
                .setMediaCodecSelector(androidx.media3.exoplayer.mediacodec.MediaCodecSelector { mime, secure, tunneling ->
                    val all = androidx.media3.exoplayer.mediacodec.MediaCodecSelector.DEFAULT.getDecoderInfos(mime, secure, tunneling)
                    if (mime.startsWith("video/")) all.filter { !it.softwareOnly } else all
                })
            androidx.media3.exoplayer.ExoPlayer.Builder(ctx, renderersFactory)
                .setMediaSourceFactory(androidx.media3.exoplayer.source.DefaultMediaSourceFactory(routedDataSourceFactory(ctx)))
                .setLoadControl(loadControl)
                .build()
                .apply {
                    setMediaItem(androidx.media3.common.MediaItem.fromUri(uri))
                    setPlaybackSpeed(cfg.speed)
                    val at = if (cfg.resume) sp.getFloat("p:$uri", 0f) else 0f
                    if (at > 5f) seekTo((at * 1000).toLong())
                    playWhenReady = true
                    prepare()
                }
        }

        DisposableEffect(exo) {
            val bars = WindowInsetsControllerCompat(window, window.decorView)
            bars.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            bars.hide(WindowInsetsCompat.Type.systemBars())
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            setMode(null)
            val l = object : androidx.media3.common.Player.Listener {
                override fun onVideoSizeChanged(v: androidx.media3.common.VideoSize) {
                    if (v.width > 0 && v.height > 0) ratio = v.width * v.pixelWidthHeightRatio / v.height
                }
                override fun onPlaybackStateChanged(playbackState: Int) {
                    isBuffering = playbackState == androidx.media3.common.Player.STATE_BUFFERING
                }
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    if (!failed[0]) { failed[0] = true; failCb() }
                }
            }
            val ob = androidx.lifecycle.LifecycleEventObserver { _, e ->
                if (e == androidx.lifecycle.Lifecycle.Event.ON_STOP) exo.pause()
            }
            val al = object : androidx.media3.exoplayer.analytics.AnalyticsListener {
                override fun onVideoDecoderInitialized(eventTime: androidx.media3.exoplayer.analytics.AnalyticsListener.EventTime, decoderName: String, initializedTimestampMs: Long, initializationDurationMs: Long) { dec = decoderName }
                override fun onDroppedVideoFrames(eventTime: androidx.media3.exoplayer.analytics.AnalyticsListener.EventTime, droppedFrames: Int, elapsedMs: Long) { dropped += droppedFrames }
            }
            lifecycle.addObserver(ob); exo.addListener(l); exo.addAnalyticsListener(al)
            onDispose {
                lifecycle.removeObserver(ob); exo.removeListener(l); exo.removeAnalyticsListener(al)
                if (!failed[0]) {
                    val p = exo.currentPosition / 1000.0; val d = exo.duration / 1000.0
                    sp.edit().apply {
                        if (d > 0 && p > 5 && p < d - 10) putFloat("p:$uri", p.toFloat()) else remove("p:$uri")
                    }.apply()
                }
                exo.release()
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                bars.show(WindowInsetsCompat.Type.systemBars())
                setMode(null)
            }
        }

        LaunchedEffect(ui) {
            var n = 0
            while (ui) {
                if (drag == null) pos = exo.currentPosition / 1000.0
                val d = exo.duration; if (d > 0) dur = d / 1000.0
                paused = !exo.playWhenReady || exo.playbackState == androidx.media3.common.Player.STATE_ENDED
                if (cfg.info && n % 4 == 0) {
                    val v = exo.videoSize
                    info = "$dec · ${v.width}x${v.height} · dropped $dropped"
                }
                n++; delay(250)
            }
        }

        LaunchedEffect(ui, paused) {
            if (ui && !paused && cfg.hide > 0) {
                delay(cfg.hide * 1000L)
                ui = false
            }
        }

        fun seekBy(sec: Int) {
            val t = (exo.currentPosition + sec * 1000L).coerceAtLeast(0L)
            val d = exo.duration
            exo.seekTo(if (d > 0) minOf(t, d) else t)
        }
        fun scrub(f: Float) {
            val now = android.os.SystemClock.uptimeMillis()
            if (now - last[0] > 180) {
                last[0] = now
                exo.seekTo((f * dur * 1000).toLong())
            }
        }

        val hudAlpha by animateFloatAsState(
            targetValue = if (ui) 1f else 0f,
            animationSpec = tween(200, easing = FastOutSlowInEasing),
            label = "exoHudAlpha"
        )

        BackHandler(onBack = onClose)
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black)
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, z, _ ->
                        val nz = (zoom * z).coerceIn(1f, 6f)
                        if (nz > 1f) { px += pan.x; py += pan.y } else { px = 0f; py = 0f }
                        zoom = nz
                    }
                }
                .pointerInput(skip) {
                    detectTapGestures(
                        onDoubleTap = { seekBy(if (it.x < size.width / 2) -skip else skip) },
                        onTap = { ui = !ui }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            val exoColorMatrix = remember(filter, filterStrength) { buildExoColorMatrix(filter, filterStrength) }
            AndroidView(
                factory = { c -> SurfaceView(c).also { exo.setVideoSurfaceView(it) } },
                modifier = Modifier
                    .aspectRatio(ratio)
                    .graphicsLayer {
                        scaleX = zoom; scaleY = zoom
                        translationX = px; translationY = py
                        if (Build.VERSION.SDK_INT >= 31 && exoColorMatrix != null) {
                            renderEffect = RenderEffect.createColorFilterEffect(ColorMatrixColorFilter(exoColorMatrix)).asComposeRenderEffect()
                        }
                    }
            )


            if (isBuffering) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(36.dp))
            }

            if (ui || hudAlpha > 0.01f) {
                Column(
                    Modifier
                        .fillMaxSize()
                        .graphicsLayer { alpha = hudAlpha }
                        .background(Brush.verticalGradient(listOf(Color(0x99000000), Color.Transparent, Color(0xB3000000))))
                        .statusBarsPadding()
                        .navigationBarsPadding()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { if (ui) onClose() }) {
                            Icon(Icons.Rounded.ArrowBackIosNew, null, tint = Color.White)
                        }
                        if (cfg.info) {
                            Text(
                                info,
                                Modifier.weight(1f).padding(start = 8.dp),
                                color = Color.White.copy(.88f),
                                fontSize = 10.5.sp,
                                lineHeight = 13.sp
                            )
                        }
                    }
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton({ if (ui) seekBy(-skip) }) {
                            Icon(Icons.Rounded.Replay10, null, tint = Color.White, modifier = Modifier.size(36.dp))
                        }
                        Spacer(Modifier.width(24.dp))
                        FilledIconButton(
                            onClick = {
                                if (ui) {
                                    if (paused) {
                                        if (exo.playbackState == androidx.media3.common.Player.STATE_ENDED) exo.seekTo(0)
                                        exo.play()
                                    } else exo.pause()
                                    paused = !paused
                                }
                            },
                            modifier = Modifier.size(76.dp).pressBounce(),
                            colors = IconButtonDefaults.filledIconButtonColors(Color.White, Color.Black)
                        ) {
                            Icon(if (paused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause, null, Modifier.size(40.dp))
                        }
                        Spacer(Modifier.width(24.dp))
                        IconButton({ if (ui) seekBy(skip) }) {
                            Icon(Icons.Rounded.Forward10, null, tint = Color.White, modifier = Modifier.size(36.dp))
                        }
                    }
                    Column {
                        AnimatedVisibility(visible = filterMenu) {
                            FilterPanel(
                                filter = filter,
                                strength = filterStrength,
                                onFilter = { if (ui) filter = it },
                                onStrength = { if (ui) filterStrength = it }
                            )
                        }
                        Slider(
                            value = drag ?: (pos / dur).toFloat().coerceIn(0f, 1f),
                            onValueChange = { if (ui) { drag = it; scrub(it) } },
                            onValueChangeFinished = {
                                drag?.let { f -> exo.seekTo((f * dur * 1000).toLong()) }
                                drag = null
                            }
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("${fmt(pos)} / ${fmt(dur)}", color = Color.White, fontSize = 12.sp)
                            Spacer(Modifier.weight(1f))
                            FilterButton(filter, filterMenu) { if (ui) filterMenu = !filterMenu }
                            TextButton({
                                if (ui) {
                                    speed = RATES[(RATES.indexOf(speed) + 1) % RATES.size]
                                    exo.setPlaybackSpeed(speed)
                                }
                            }) { Text("${speed}×", color = Color.White) }
                        }
                    }
                }
            }
        }
    }
}

@Composable fun Library(
    list: VList,
    grid: Int,
    showNames: Boolean,
    animations: Boolean,
    onOpen: (Uri) -> Unit,
    onVault: (Vid) -> Unit
) {
    if (list.v.isEmpty()) Text("No videos found", color = MaterialTheme.colorScheme.onSurfaceVariant)
    LazyVerticalGrid(
        columns = GridCells.Fixed(if (grid <= 130) 4 else if (grid >= 220) 2 else 3),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(if (showNames) 12.dp else 8.dp),
        contentPadding = PaddingValues(bottom = 120.dp)
    ) {
        items(list.v, key = { it.uri }, contentType = { 0 }) { v ->
            LibCard(v, showNames, animations, onOpen, onVault)
        }
    }
}

@Composable private fun LibCard(
    v: Vid,
    showNames: Boolean,
    animations: Boolean,
    onOpen: (Uri) -> Unit,
    onVault: (Vid) -> Unit
) {
    val ctx = LocalContext.current
    val thumb by produceState<ImageBitmap?>(THUMBS.get(v.uri), v.uri) {
        if (value == null) value = loadThumbFast(ctx, v.uri)
    }
    val thumbAlpha by animateFloatAsState(
        targetValue = if (thumb != null) 1f else 0f,
        animationSpec = if (animations) tween(120) else snap(),
        label = "thumbAlpha"
    )
    Column {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(24.dp))
                .background(MaterialTheme.colorScheme.surface)
                .clickable { onOpen(v.uri) }
        ) {
            if (thumb == null) {
                Icon(
                    Icons.Rounded.Videocam,
                    null,
                    Modifier.align(Alignment.Center).size(40.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            thumb?.let {
                Image(
                    bitmap = it,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize().graphicsLayer { alpha = thumbAlpha },
                    contentScale = ContentScale.Crop,
                    filterQuality = FilterQuality.Low
                )
            }
            Box(
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(8.dp)
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.PlayArrow, null, Modifier.size(18.dp), tint = Color.Black)
            }
            Text(
                fmt(v.dur / 1000.0),
                Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(7.dp))
                    .background(Color(0x99000000))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                fontSize = 10.sp,
                color = Color.White,
                fontWeight = FontWeight.SemiBold
            )
        }
        if (showNames) {
            Text(
                v.name,
                Modifier.padding(top = 6.dp, start = 4.dp, end = 4.dp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontWeight = FontWeight.Medium,
                fontSize = 13.sp
            )
        }
    }
}

private data class SettingsCategoryItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val circleColor: Color
)

/**
 * Categorized Settings Screen styled after the user's reference screenshot:
 * - Top bar with circular dark slate back button (`←`) + title ("Settings" or active category name)
 * - Grouped dark cards with 24.dp outer group corners, 4.dp inner corners, and 46.dp pastel circle icons
 * - Smooth animated transitions into each category sub-screen
 */
@Composable
fun CategorizedSettingsScreen(
    cfg: Cfg,
    unlocked: Boolean,
    vault: Vault,
    activeCategory: String?,
    onSelectCategory: (String?) -> Unit,
    onBackToLibrary: () -> Unit,
    onUpdate: (Cfg) -> Unit,
    onLockNow: () -> Unit,
    onGoToVault: () -> Unit,
    notify: (String) -> Unit
) {
    val ctx = LocalContext.current
    val isLight = cfg.isLight()
    BackHandler(enabled = activeCategory != null) {
        onSelectCategory(null)
    }

    val categoryTitle = when (activeCategory) {
        "security" -> "Security"
        "veracrypt" -> "VeraCrypt Containers"
        "appearance" -> "Appearance"
        "library" -> "Library & Grid"
        "playback" -> "Playback & 4K Engine"
        "hdr" -> "HDR & Color Filters"
        "backup" -> "Backup & Cache"
        "about" -> "About"
        else -> "Settings"
    }

    Column(Modifier.fillMaxSize()) {
        // Top Header Bar matching Screenshot 1: Circular back button + Title
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp, bottom = 16.dp, start = 2.dp, end = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .pressBounce(cfg.animations)
                    .clip(CircleShape)
                    .background(
                        if (isLight) Color(0xFFE0E5EC) else Color(0xFF282C37)
                    )
                    .clickable {
                        if (activeCategory != null) onSelectCategory(null) else onBackToLibrary()
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.ArrowBack,
                    contentDescription = "Back",
                    tint = if (isLight) Color(0xFF101514) else Color(0xFFE8ECF4),
                    modifier = Modifier.size(21.dp)
                )
            }
            Spacer(Modifier.width(16.dp))
            Text(
                text = categoryTitle,
                fontSize = 23.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        AnimatedContent(
            targetState = activeCategory,
            transitionSpec = { fadeIn(tween(140)) togetherWith fadeOut(tween(90)) },
            label = "settingsNav"
        ) { cat ->
            if (cat == null) {
                // Main Categorized Card Groups (matching Screenshot 1)
                val group1 = listOf(
                    SettingsCategoryItem(
                        id = "security",
                        title = "Security",
                        subtitle = "Vault password, auto-lock, quick lock",
                        icon = Icons.Rounded.Shield,
                        circleColor = Color(0xFF5CE1E6)
                    ),
                    SettingsCategoryItem(
                        id = "veracrypt",
                        title = "VeraCrypt Containers",
                        subtitle = "Mount .hc/.vc volumes, PIM, hash mode",
                        icon = Icons.Rounded.EnhancedEncryption,
                        circleColor = Color(0xFFF4989C)
                    )
                )
                val group2 = listOf(
                    SettingsCategoryItem(
                        id = "appearance",
                        title = "Appearance",
                        subtitle = "Theme, dynamic colors, language",
                        icon = Icons.Rounded.Palette,
                        circleColor = Color(0xFFF6B27A)
                    ),
                    SettingsCategoryItem(
                        id = "library",
                        title = "Library & Thumbnails",
                        subtitle = "Grid size, sorting, file names, fast cache",
                        icon = Icons.Rounded.GridView,
                        circleColor = Color(0xFF6CD4B8)
                    )
                )
                val group3 = listOf(
                    SettingsCategoryItem(
                        id = "playback",
                        title = "Playback & 4K Engine",
                        subtitle = "Preloading buffer, 4K software turbo, decoder, speed",
                        icon = Icons.Rounded.Speed,
                        circleColor = Color(0xFFA7B0F5)
                    ),
                    SettingsCategoryItem(
                        id = "hdr",
                        title = "HDR & Color Filters",
                        subtitle = "HDR Soft, HDR Strong, Cinematic tone mapping",
                        icon = Icons.Rounded.AutoAwesome,
                        circleColor = Color(0xFFFACC15)
                    )
                )
                val group4 = listOf(
                    SettingsCategoryItem(
                        id = "backup",
                        title = "Backup & Cache",
                        subtitle = "Clear thumbnail cache, reset settings to default",
                        icon = Icons.Rounded.Save,
                        circleColor = Color(0xFFA7B0F5)
                    ),
                    SettingsCategoryItem(
                        id = "about",
                        title = "About",
                        subtitle = "Version, 4K async engine, VeraCrypt XTS-AES-256",
                        icon = Icons.Rounded.Info,
                        circleColor = Color(0xFFC4C4C4)
                    )
                )

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(bottom = 130.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    SettingsCardGroup(group1, isLight, cfg.animations) { onSelectCategory(it) }
                    SettingsCardGroup(group2, isLight, cfg.animations) { onSelectCategory(it) }
                    SettingsCardGroup(group3, isLight, cfg.animations) { onSelectCategory(it) }
                    SettingsCardGroup(group4, isLight, cfg.animations) { onSelectCategory(it) }
                }
            } else {
                // Category Sub-Screen Content
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 4.dp)
                        .padding(bottom = 130.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    when (cat) {
                        "security" -> {
                            SettingsDetailCard {
                                SwitchRow(
                                    title = "Auto-lock when you leave the app",
                                    sub = "Locks the Vault and unmounts VeraCrypt volumes when backgrounded",
                                    on = cfg.autoLock
                                ) { onUpdate(cfg.copy(autoLock = it)) }
                            }
                            SettingsDetailCard {
                                Text("Vault Status", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text(
                                    if (unlocked) "A VeraCrypt volume is mounted." else "No VeraCrypt volume is mounted.",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 6.dp)) {
                                    if (unlocked) {
                                        Button(onClick = { onLockNow(); notify("Vault locked") }, shape = RoundedCornerShape(12.dp)) {
                                            Icon(Icons.Rounded.Lock, null, Modifier.size(18.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text("Lock vault now")
                                        }
                                    } else {
                                        Button(onClick = onGoToVault, shape = RoundedCornerShape(12.dp)) {
                                            Icon(Icons.Rounded.LockOpen, null, Modifier.size(18.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text("Open Vault tab")
                                        }
                                    }
                                }
                            }
                        }

                        "veracrypt" -> {
                            SettingsDetailCard {
                                Lbl("Default Key Derivation Hash")
                                Text(
                                    "Used when unlocking .hc / .vc / .tc VeraCrypt volumes",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Chips(
                                    opts = listOf("auto" to "Auto-detect", "sha512" to "HMAC-SHA-512", "sha256" to "HMAC-SHA-256"),
                                    sel = cfg.vcHash
                                ) { onUpdate(cfg.copy(vcHash = it)) }
                            }
                            SettingsDetailCard {
                                Text("VeraCrypt Containers", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text(
                                    "Supports standard VeraCrypt XTS-AES-256 volumes formatted as FAT16, FAT32, or exFAT, with custom PIM and password visibility toggle.",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Button(
                                    onClick = onGoToVault,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.padding(top = 6.dp)
                                ) {
                                    Icon(Icons.Rounded.FolderSpecial, null, Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Manage & Mount in Vault")
                                }
                            }
                        }

                        "appearance" -> AppearanceSettings(cfg, onUpdate)

                        "library" -> {
                            SettingsDetailCard {
                                Lbl("Library grid size")
                                Chips(
                                    opts = listOf(130 to "Compact", 160 to "Comfortable", 220 to "Large"),
                                    sel = cfg.grid
                                ) { onUpdate(cfg.copy(grid = it)) }
                                Spacer(Modifier.height(6.dp))
                                Lbl("Sort videos by")
                                Chips(
                                    opts = listOf("new" to "Newest", "name" to "Name", "dur" to "Longest"),
                                    sel = cfg.sort
                                ) { onUpdate(cfg.copy(sort = it)) }
                            }
                            SettingsDetailCard {
                                SwitchRow(
                                    title = "Show file names in library",
                                    sub = "Displays the video title below each thumbnail card",
                                    on = cfg.showNames
                                ) { onUpdate(cfg.copy(showNames = it)) }
                            }
                        }

                        "playback" -> {
                            SettingsDetailCard {
                                SwitchRow(
                                    title = "4K Preload & Frame Ring-Buffer",
                                    sub = "Pre-decodes 4K frames into RAM ahead of playback and warms OS file cache to eliminate stutter",
                                    on = cfg.preload
                                ) { onUpdate(cfg.copy(preload = it)) }
                                HorizontalDivider(Modifier.padding(vertical = 6.dp), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                Lbl("Preload buffer size")
                                Chips(
                                    opts = listOf(64 to "64 MB", 128 to "128 MB (Recommended)", 256 to "256 MB (Max)"),
                                    sel = cfg.bufMb
                                ) { onUpdate(cfg.copy(bufMb = it)) }
                            }
                            SettingsDetailCard {
                                SwitchRow(
                                    title = "4K Software Turbo Mode",
                                    sub = "For phones without a 4K HW decoder: uses async vd-queue, single-pass GPU dumb mode & non-ref frame drop guard",
                                    on = cfg.turbo4k
                                ) { onUpdate(cfg.copy(turbo4k = it)) }
                                HorizontalDivider(Modifier.padding(vertical = 6.dp), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                SwitchRow(
                                    title = "Hardware decoding first",
                                    sub = "Tries MediaCodec hardware acceleration first; falls back to 4K Software Turbo if unsupported",
                                    on = cfg.hw
                                ) { onUpdate(cfg.copy(hw = it)) }
                                HorizontalDivider(Modifier.padding(vertical = 6.dp), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                Lbl("Video engine")
                                Chips(listOf("auto" to "Auto", "exo" to "Hardware", "web" to "Chromium", "mpv" to "Software"), cfg.engine) { onUpdate(cfg.copy(engine = it)) }
                            }
                            SettingsDetailCard {
                                Lbl("Double-tap skip interval")
                                Chips(listOf(5 to "5s", 10 to "10s", 15 to "15s", 30 to "30s"), cfg.skip) { onUpdate(cfg.copy(skip = it)) }
                                Spacer(Modifier.height(6.dp))
                                Lbl("Default playback speed")
                                Chips(listOf(.5f to "0.5×", 1f to "1×", 1.25f to "1.25×", 1.5f to "1.5×", 2f to "2×"), cfg.speed) { onUpdate(cfg.copy(speed = it)) }
                                Spacer(Modifier.height(6.dp))
                                Lbl("Hide player controls after")
                                Chips(listOf(2 to "2s", 3 to "3s", 5 to "5s", 0 to "Never"), cfg.hide) { onUpdate(cfg.copy(hide = it)) }
                            }
                            SettingsDetailCard {
                                SwitchRow(
                                    title = "Resume where you left off",
                                    sub = "Remembers the last playback position of each video",
                                    on = cfg.resume
                                ) { onUpdate(cfg.copy(resume = it)) }
                                HorizontalDivider(Modifier.padding(vertical = 6.dp), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                SwitchRow(
                                    title = "Show playback diagnostics",
                                    sub = "Displays decoder mode, resolution, fps, buffer & dropped frame counters",
                                    on = cfg.info
                                ) { onUpdate(cfg.copy(info = it)) }
                            }
                        }

                        "hdr" -> {
                            SettingsDetailCard {
                                Lbl("Default HDR / Color Filter")
                                Text(
                                    "Combines hardware YUV-to-RGB color matrix grading with multi-zone optical luminance shaping",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Chips(FILTERS, cfg.filter) { onUpdate(cfg.copy(filter = it)) }
                                Spacer(Modifier.height(8.dp))
                                Lbl("Filter Intensity")
                                Chips(
                                    opts = listOf(0.75f to "Subtle (75%)", 1.0f to "Balanced (100%)", 1.35f to "Vivid (135%)"),
                                    sel = cfg.filterStrength
                                ) { onUpdate(cfg.copy(filterStrength = it)) }
                            }
                            SettingsDetailCard {
                                Text("Filter Profiles", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text("• HDR Soft: Natural dynamic range lift, open shadow detail, crisp highlights (+9 contrast, +14% vibrance, -2 gamma).", fontSize = 12.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("• HDR Strong: Deep OLED blacks, high specular pop & wide-gamut color richness (+20 contrast, +28% vibrance, -6 gamma).", fontSize = 12.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("• Cinematic: 35mm Kodak 2383 film print curve with golden-amber highlights & cool teal shadow balance.", fontSize = 12.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }

                        "backup" -> {
                            SettingsDetailCard {
                                Text("Thumbnail & Playback Cache", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text(
                                    "Clears cached disk/memory thumbnails so they are freshly generated.",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                OutlinedButton(
                                    onClick = {
                                        THUMBS.evictAll()
                                        File(ctx.cacheDir, "thumbs").deleteRecursively()
                                        notify("Thumbnail cache cleared")
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.padding(top = 4.dp)
                                ) {
                                    Icon(Icons.Rounded.DeleteSweep, null, Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Clear thumbnail cache")
                                }
                            }
                            SettingsDetailCard {
                                Text("Reset Preferences", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text(
                                    "Restores all playback, filter, and appearance settings to their defaults (does not touch Vault files).",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                OutlinedButton(
                                    onClick = {
                                        onUpdate(Cfg())
                                        notify("Settings reset to defaults")
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.padding(top = 4.dp)
                                ) {
                                    Icon(Icons.Rounded.RestartAlt, null, Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Reset all settings")
                                }
                            }
                        }

                        "about" -> {
                            SettingsDetailCard {
                                Text("Lumen 4K Player & Vault", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                Text("Version 1.1 • Kotlin & Jetpack Compose", fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    "Engineered for smooth 4K video playback on mobile devices without hardware 4K decoders using asynchronous decoded-frame buffering (vd-queue), single-pass OpenGL ES rendering, and OS readahead caching.",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    "Opens VeraCrypt (XTS-AES-256) volumes: browse photos, videos and files.",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    "Made by Chris",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsCardGroup(
    items: List<SettingsCategoryItem>,
    isLight: Boolean,
    animations: Boolean,
    onClick: (String) -> Unit
) {
    val cardBg = if (isLight) Color.White else Color(0xFF1E2025)
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        items.forEachIndexed { idx, item ->
            val topCorner = if (idx == 0) 24.dp else 4.dp
            val bottomCorner = if (idx == items.lastIndex) 24.dp else 4.dp
            val shape = RoundedCornerShape(
                topStart = topCorner,
                topEnd = topCorner,
                bottomStart = bottomCorner,
                bottomEnd = bottomCorner
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .pressBounce(animations)
                    .clip(shape)
                    .background(cardBg)
                    .clickable { onClick(item.id) }
                    .padding(horizontal = 18.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(item.circleColor),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.title,
                        tint = Color(0xFF1A1C20),
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(Modifier.width(18.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        text = item.title,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isLight) Color(0xFF101514) else Color(0xFFF2F4F8)
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = item.subtitle,
                        fontSize = 13.5.sp,
                        color = if (isLight) Color(0xFF55615E) else Color(0xFF9AA0A6),
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsDetailCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

@Composable fun Swatches(sel: String, light: Boolean, set: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        ACCENTS.forEach { (k, p) ->
            Box(
                Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color(if (light) p.second else p.first))
                    .then(if (sel == k) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape) else Modifier)
                    .clickable { set(k) },
                contentAlignment = Alignment.Center
            ) { if (sel == k) Icon(Icons.Rounded.Check, null, tint = Color.Black.copy(.7f)) }
        }
    }
}

@Composable fun Lbl(t: String) = Text(t, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)

private val CHIP = RoundedCornerShape(12.dp)

@Composable fun Chip(on: Boolean, label: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Text(
        label,
        Modifier
            .clip(CHIP)
            .background(if (on) cs.secondaryContainer else Color.Transparent)
            .then(if (on) Modifier else Modifier.border(1.dp, cs.onSurface.copy(.22f), CHIP))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        fontSize = 14.sp,
        fontWeight = FontWeight.Medium,
        color = if (on) cs.onSecondaryContainer else cs.onSurface
    )
}

@Composable fun <T> Chips(opts: List<Pair<T, String>>, sel: T, set: (T) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        opts.forEach { (k, n) -> Chip(sel == k, n) { set(k) } }
    }
}

@Composable fun SwitchRow(title: String, sub: String, on: Boolean, set: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(sub, fontSize = 12.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 16.sp)
        }
        Switch(on, set)
    }
}

/**
 * Frosted-glass bottom navigation pill with drag-to-switch.
 * Performance notes: no shadow layer (it is very costly under a translucent background),
 * and everything that moves per frame (indicator position / squish) is read inside
 * graphicsLayer, so dragging never recomposes the bar.
 */
@Composable
fun LumenNav(
    sel: Int,
    tabs: List<Pair<ImageVector, String>>,
    animate: Boolean,
    onSel: (Int) -> Unit,
    m: Modifier
) {
    val itemW = 92.dp
    val itemH = 54.dp
    val iw = with(LocalDensity.current) { itemW.toPx() }
    val cs = MaterialTheme.colorScheme
    val ink = cs.onSurface
    val shape = RoundedCornerShape(50)
    val scope = rememberCoroutineScope()

    val rest = remember { Animatable(sel * iw) }       // resting indicator x
    val dragX = remember { mutableFloatStateOf(sel * iw) }
    val held = remember { mutableStateOf(false) }
    val hot = remember { mutableIntStateOf(sel) }
    val squish = remember { Animatable(1f) }

    val settle = if (animate) spring<Float>(dampingRatio = 0.75f, stiffness = 380f) else snap()
    LaunchedEffect(sel) {
        if (!held.value) {
            hot.intValue = sel
            rest.animateTo(sel * iw, settle)
        }
    }

    val pillBrush = remember(cs.primary) { Brush.verticalGradient(listOf(cs.primary.copy(.45f), cs.primary.copy(.16f))) }
    val pillBorder = remember(ink) { Brush.verticalGradient(listOf(ink.copy(.40f), ink.copy(.05f))) }

    Box(
        m
            .clip(shape)
            .background(Color.Black)
            .border(1.dp, Color.White.copy(alpha = .14f), shape)
            .padding(6.dp)
            .pointerInput(tabs.size, iw) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    held.value = true
                    dragX.floatValue = rest.value
                    val maxX = iw * (tabs.size - 1)
                    fun go(px: Float, k: Float) {
                        val t = (px - iw / 2).coerceIn(0f, maxX)
                        dragX.floatValue += (t - dragX.floatValue) * k
                        // pick tab under the finger, not the lagging indicator
                        val fh = (t / iw + .5f).toInt().coerceIn(0, tabs.size - 1)
                        if (fh != hot.intValue) hot.intValue = fh
                    }
                    if (animate) scope.launch { squish.animateTo(1.08f, spring(0.6f, 320f)) }
                    go(down.position.x, .6f)
                    do {
                        val e = awaitPointerEvent()
                        e.changes.firstOrNull()?.let { c -> go(c.position.x, .6f); c.consume() }
                    } while (e.changes.any { it.pressed })
                    val target = hot.intValue
                    scope.launch {
                        rest.snapTo(dragX.floatValue)
                        held.value = false
                        launch { squish.animateTo(1f, spring(0.6f, 320f)) }
                        rest.animateTo(target * iw, settle)
                    }
                    onSel(target)
                }
            }
    ) {
        Box(
            Modifier
                .size(itemW, itemH)
                .graphicsLayer {
                    translationX = if (held.value) dragX.floatValue else rest.value
                    scaleX = squish.value
                    scaleY = squish.value
                }
                .clip(shape)
                .background(pillBrush)
                .border(1.dp, pillBorder, shape)
        )
        Row {
            tabs.forEachIndexed { i, (icon, name) ->
                val on = i == (if (held.value) hot.intValue else sel)
                Column(
                    Modifier.size(itemW, itemH),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(icon, name, Modifier.size(22.dp), tint = if (on) ink else cs.onSurfaceVariant)
                    Text(
                        name,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (on) ink else cs.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun AppearanceSection(title: String) {
    Text(
        title,
        fontSize = 15.sp,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 20.dp, top = 8.dp)
    )
}

@Composable
private fun AppearanceToggle(
    title: String,
    sub: String,
    on: Boolean,
    shape: Shape,
    enabled: Boolean = true,
    set: (Boolean) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(cs.surface)
            .clickable(enabled = enabled) { set(!on) }
            .padding(horizontal = 22.dp, vertical = 20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface.copy(if (enabled) 1f else .5f))
            Spacer(Modifier.height(4.dp))
            Text(sub, fontSize = 16.sp, color = cs.onSurfaceVariant.copy(if (enabled) 1f else .5f), lineHeight = 21.sp)
        }
        Switch(
            checked = on,
            onCheckedChange = set,
            enabled = enabled,
            thumbContent = if (on) {
                { Icon(Icons.Rounded.Check, null, Modifier.size(SwitchDefaults.IconSize)) }
            } else null
        )
    }
}

@Composable
private fun AppearanceSettings(cfg: Cfg, onUpdate: (Cfg) -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val big = 28.dp
    val small = 6.dp

    AppearanceSection("Theme mode")
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(big))
            .background(cs.surface)
            .padding(horizontal = 22.dp, vertical = 22.dp)
    ) {
        val modes = listOf("system" to "System", "light" to "Light", "dark" to "Dark")
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            modes.forEachIndexed { i, (k, n) ->
                SegmentedButton(
                    selected = cfg.themeMode == k,
                    onClick = { onUpdate(cfg.copy(themeMode = k)) },
                    shape = SegmentedButtonDefaults.itemShape(i, modes.size),
                    modifier = Modifier.height(48.dp)
                ) { Text(n, fontSize = 16.sp, fontWeight = FontWeight.Medium) }
            }
        }
    }

    AppearanceSection("Display")
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        AppearanceToggle(
            "AMOLED Glass", "Pure black backgrounds with frosted glass", cfg.amoled,
            RoundedCornerShape(topStart = big, topEnd = big, bottomStart = small, bottomEnd = small)
        ) { onUpdate(cfg.copy(amoled = it)) }
        AppearanceToggle(
            "Dynamic colors", "Use wallpaper-derived colors (Android 12+)",
            cfg.dynamic && Build.VERSION.SDK_INT >= 31,
            RoundedCornerShape(topStart = small, topEnd = small, bottomStart = small, bottomEnd = small),
            enabled = Build.VERSION.SDK_INT >= 31
        ) { onUpdate(cfg.copy(dynamic = it)) }
        AppearanceToggle(
            "Smooth UI animations", "Spring press feedback, tab transitions and thumbnail fade-in", cfg.animations,
            RoundedCornerShape(topStart = small, topEnd = small, bottomStart = big, bottomEnd = big)
        ) { onUpdate(cfg.copy(animations = it)) }
    }

    AppearanceSection("Language")
    var langLabel by remember { mutableStateOf(currentAppLanguage(ctx)) }
    DisposableEffect(ctx) {
        val lc = (ctx as? ComponentActivity)?.lifecycle
        val obs = androidx.lifecycle.LifecycleEventObserver { _, e ->
            if (e == androidx.lifecycle.Lifecycle.Event.ON_RESUME) langLabel = currentAppLanguage(ctx)
        }
        lc?.addObserver(obs)
        onDispose { lc?.removeObserver(obs) }
    }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(big))
            .background(cs.surface)
            .clickable { openAppLanguageSettings(ctx) }
            .padding(horizontal = 22.dp, vertical = 26.dp)
    ) {
        Text("App Language", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface)
        Spacer(Modifier.height(4.dp))
        Text(langLabel, fontSize = 16.sp, color = cs.onSurfaceVariant)
    }
}

private fun currentAppLanguage(ctx: Context): String {
    if (Build.VERSION.SDK_INT >= 33) {
        val l = runCatching {
            ctx.getSystemService(android.app.LocaleManager::class.java).applicationLocales
        }.getOrNull()
        if (l != null && !l.isEmpty) return l[0].let { it.getDisplayName(it) }
    }
    return "System default"
}

private fun openAppLanguageSettings(ctx: Context) {
    val pkg = Uri.fromParts("package", ctx.packageName, null)
    val tries = buildList {
        if (Build.VERSION.SDK_INT >= 33) add(Intent(android.provider.Settings.ACTION_APP_LOCALE_SETTINGS, pkg))
        add(Intent(android.provider.Settings.ACTION_LOCALE_SETTINGS))
    }
    for (i in tries) {
        if (runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess) return
    }
}


@Composable
private fun FilterButton(filter: String, open: Boolean, onClick: () -> Unit) {
    val on = filter != "off"
    val label = FILTERS.firstOrNull { it.first == filter }?.second ?: "Filter"
    val lit = on || open
    Row(
        Modifier
            .padding(end = 6.dp)
            .clip(RoundedCornerShape(50))
            .background(if (lit) Color.White else Color(0x33FFFFFF))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.AutoAwesome, null, Modifier.size(16.dp), tint = if (lit) Color.Black else Color.White)
        Spacer(Modifier.width(6.dp))
        Text(
            if (on) label else "Filter",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (lit) Color.Black else Color.White
        )
    }
}

@Composable
private fun FilterPanel(
    filter: String,
    strength: Float,
    onFilter: (String) -> Unit,
    onStrength: (Float) -> Unit
) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .clip(shape)
            .background(Color(0x99000000))
            .border(1.dp, Color(0x33FFFFFF), shape)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FILTERS.forEach { (k, n) ->
                val on = filter == k
                Text(
                    n,
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (on) Color.White else Color(0x26FFFFFF))
                        .clickable { onFilter(k) }
                        .padding(vertical = 9.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    color = if (on) Color.Black else Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1
                )
            }
        }
        if (filter != "off") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0.75f to "Subtle", 1.0f to "Balanced", 1.35f to "Vivid").forEach { (str, lbl) ->
                    val on = abs(strength - str) < 0.1f
                    Text(
                        lbl,
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(50))
                            .background(if (on) Color(0xFF63D2EB) else Color(0x1AFFFFFF))
                            .clickable { onStrength(str) }
                            .padding(vertical = 6.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        color = if (on) Color.Black else Color.White.copy(alpha = 0.85f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}
