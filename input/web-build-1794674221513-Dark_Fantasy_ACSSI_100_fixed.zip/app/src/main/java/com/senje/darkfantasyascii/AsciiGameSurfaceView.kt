package com.senje.darkfantasyascii

import android.content.Context
import android.graphics.Canvas
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * 60 FPS Hardware-Accelerated 2.5D Game Loop for "Dark Fantasy ACSSI 100".
 *
 * Combines:
 * - LandMap25D (Whispering Meadow, Moonlit Reflective River, Climbable 2.5D Cylindrical Watchtower
 *   High Ground with flickering brazier & ivy, and Forest Trail / Citadel Twin Bastions / Chasm Bridges)
 * - SenjeCharacterRenderer (Micro-ASCII Knight in Bloody Mail Coif & crimson surcoat, blazing ember
 *   longsword with dynamic point lighting & sparks, elongated shadow, and White ASCII Warhorse mount)
 * - HudAndControlsRenderer (Video 1 bottom XP/hotbar HUD, left virtual joystick, right tap-to-slash,
 *   and smooth pinch-to-zoom).
 */
class AsciiGameSurfaceView(context: Context) : SurfaceView(context), SurfaceHolder.Callback, Runnable {

    @Volatile
    private var running = false
    private var renderThread: Thread? = null

    private val landMap = LandMap25D()
    private val charRenderer = SenjeCharacterRenderer()
    private val hudRenderer = HudAndControlsRenderer()

    // Player (Senje) state in 2.5D world coordinates
    private var playerX = landMap.meadowSpawnX
    private var playerY = landMap.meadowSpawnY
    private var playerZ = 0f
    private var facingX = -0.65f
    private var facingY = 0.75f
    private var moveSpeed = 0f
    private var slashTimer = 0f
    private var isMounted = false
    private var flameBoost = false

    // Wild horse world position when dismounted (waits near the river/tower approach like Video 2)
    private var wildHorseX = landMap.meadowSpawnX - 115f
    private var wildHorseY = landMap.meadowSpawnY - 140f
    private var wildHorseZ = 0f

    // Ambient sentinels (Video 2 marsh & tower battlement figures)
    private val sentinelX = floatArrayOf(
        (landMap.towerCenterX - 310f),
        (landMap.towerCenterX + 210f),
        (landMap.citadelLeftTowerX - 70f)
    )
    private val sentinelY = floatArrayOf(
        (landMap.towerCenterY + 340f),
        (landMap.towerCenterY - 190f),
        (landMap.citadelLeftTowerY + 140f)
    )

    // Camera state (smoothly interpolates toward Senje + supports pinch-to-zoom & presets)
    private var camX = playerX
    private var camY = playerY
    private var camZ = playerZ
    private var zoomIndex = 0
    private var currentZoom = WorldConfig.ZOOM_PRESETS[0]
    private var targetZoom = WorldConfig.ZOOM_PRESETS[0]

    // Zone Waypoint cycle index (for Hotbar Slot 4 quick testing of all 3 video scenes)
    private var currentZoneWaypoint = 0
    private var currentZoneLabel = "Whispering Meadow  ·  Chainmail & Grass"

    // Player progression display matching Video 1 ("LV 25 - 5023 / 6000 XP")
    private var playerLevel = 25
    private var playerXp = 5023
    private val playerXpMax = 6000

    // Touch & Virtual Joystick state
    private var joyPointerId = MotionEvent.INVALID_POINTER_ID
    private var joyActive = false
    private var joyOriginX = 0f
    private var joyOriginY = 0f
    private var joyCurX = 0f
    private var joyCurY = 0f
    private var joyVecX = 0f
    private var joyVecY = 0f

    private var gameTime = 0f

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                targetZoom = (targetZoom * detector.scaleFactor).coerceIn(0.45f, 2.35f)
                return true
            }
        }
    )

    init {
        holder.addCallback(this)
        isFocusable = true
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        resumeGame()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        // Screen dimensions updated automatically on each frame
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        pauseGame()
    }

    fun resumeGame() {
        if (running) return
        running = true
        renderThread = Thread(this, "DarkFantasyASCII-RenderLoop").apply {
            start()
        }
    }

    fun pauseGame() {
        if (!running) return
        running = false
        try {
            renderThread?.join(600)
        } catch (_: InterruptedException) {
        }
        renderThread = null
    }

    override fun run() {
        var lastNano = System.nanoTime()
        while (running) {
            val now = System.nanoTime()
            val dt = ((now - lastNano) * 1e-9f).coerceIn(0.001f, 0.05f)
            lastNano = now

            updateSimulation(dt)

            val surfaceHolder = holder
            var canvas: Canvas? = null
            try {
                canvas = surfaceHolder.lockCanvas()
                if (canvas != null) {
                    renderFrame(canvas)
                }
            } catch (_: Exception) {
            } finally {
                if (canvas != null) {
                    try {
                        surfaceHolder.unlockCanvasAndPost(canvas)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }

    private fun updateSimulation(dt: Float) {
        gameTime += dt

        if (slashTimer > 0f) {
            slashTimer = (slashTimer - dt).coerceAtLeast(0f)
        }

        // Smooth zoom interpolation
        currentZoom += (targetZoom - currentZoom) * (dt * 9f).coerceAtMost(1f)

        // Move Senje via Virtual Joystick
        val baseMaxSpeed = if (isMounted) 235f else 138f
        if (joyActive && (joyVecX * joyVecX + joyVecY * joyVecY) > 0.01f) {
            val len = sqrt(joyVecX * joyVecX + joyVecY * joyVecY).coerceAtMost(1f)
            val nx = joyVecX / (if (len > 0.001f) len else 1f)
            val ny = joyVecY / (if (len > 0.001f) len else 1f)

            facingX = nx
            facingY = ny
            moveSpeed = len

            val stepX = nx * baseMaxSpeed * len * dt
            val stepY = ny * baseMaxSpeed * len * dt

            // Slide along obstacles smoothly on X and Y axes independently
            if (landMap.canWalkTo(playerX + stepX, playerY, playerZ)) {
                playerX += stepX
            }
            if (landMap.canWalkTo(playerX, playerY + stepY, playerZ)) {
                playerY += stepY
            }
        } else {
            moveSpeed = 0f
        }

        // Smoothly adjust Senje's 2.5D height Z to the terrain/ramp/tower roof under his feet
        val targetGroundZ = landMap.sampleHeightAtWorld(playerX, playerY).coerceAtLeast(0f)
        playerZ += (targetGroundZ - playerZ) * (dt * 12f).coerceAtMost(1f)

        if (isMounted) {
            wildHorseX = playerX
            wildHorseY = playerY
            wildHorseZ = playerZ
        }

        // Update active zone caption based on where Senje is exploring
        val currentTile = landMap.sampleTileAtWorld(playerX, playerY)
        currentZoneLabel = when {
            currentTile == WorldConfig.TILE_TOWER_ROOF || playerZ > 95f ->
                "Tower High Ground  ·  Elevation ${playerZ.toInt()}m"
            currentTile == WorldConfig.TILE_TOWER_RAMP ->
                "Watchtower Ascent  ·  Mossy Stone Ramp"
            currentTile == WorldConfig.TILE_WATER_RIVER ->
                "Moonlit River  ·  Abyssal Reflections"
            currentTile == WorldConfig.TILE_CITADEL_BRIDGE || currentTile == WorldConfig.TILE_CITADEL_WALL ->
                "Citadel Bastion  ·  Chasm Bridges & Banners"
            currentTile == WorldConfig.TILE_STONE_PATH ->
                "Dark Forest Trail  ·  Ancient Canopy"
            else ->
                "Whispering Meadow  ·  Chainmail & Grass"
        }

        // Smooth camera tracking
        camX += (playerX - camX) * (dt * 7.5f).coerceAtMost(1f)
        camY += (playerY - camY) * (dt * 7.5f).coerceAtMost(1f)
        camZ += (playerZ - camZ) * (dt * 7.5f).coerceAtMost(1f)

        // Update ember sparks rising from Senje's flaming longsword
        val swordBaseX = playerX - 10f
        val swordBaseY = playerY + 4f
        val swordTipX = playerX - 42f
        val swordTipY = playerY + 26f
        charRenderer.updateSparks(
            dt = dt,
            swordTipWorldX = swordTipX,
            swordTipWorldY = swordTipY,
            swordBaseWorldX = swordBaseX,
            swordBaseWorldY = swordBaseY,
            swordZ = playerZ,
            isSlashing = slashTimer > 0f
        )
    }

    private fun renderFrame(canvas: Canvas) {
        val w = width
        val h = height
        if (w <= 0 || h <= 0) return

        val halfW = w * 0.5f
        val halfH = h * 0.5f

        // 1. Deep void-black clear
        canvas.drawColor(WorldConfig.COL_BG_VOID)

        // Calculate dynamic point-light center from Senje's flaming longsword
        val swordLightWorldX = playerX - 24f
        val swordLightWorldY = playerY + 14f
        val swordLightRadius = when {
            slashTimer > 0f -> 310f
            flameBoost -> 285f
            else -> 215f
        }

        // 2. Render the 2.5D Land (Ground Substrate, Reflective River & Moon, 2.5D Watchtower,
        //    Wind-Swaying Grass Blades & Wildflowers, Citadel Bridges, Crimson Banners, and Trees)
        landMap.drawLand(
            canvas = canvas,
            camX = camX,
            camY = camY,
            camZ = camZ,
            zoom = currentZoom,
            screenW = w,
            screenH = h,
            time = gameTime,
            playerX = playerX,
            playerY = playerY,
            playerZ = playerZ,
            swordLightX = swordLightWorldX,
            swordLightY = swordLightWorldY,
            swordLightRadius = swordLightRadius,
            isMounted = isMounted,
            charRenderer = charRenderer
        )

        // 3. If dismounted, draw the White ASCII Warhorse waiting in the world (Video 2)
        if (!isMounted) {
            val hx = (wildHorseX - camX) * currentZoom + halfW
            val hy = ((wildHorseY - camY) * WorldConfig.Y_TILT - wildHorseZ * WorldConfig.Z_LIFT) * currentZoom + halfH
            if (hx in -120f..(w + 120f) && hy in -120f..(h + 120f)) {
                val dHorse = WorldConfig.dist(wildHorseX, wildHorseY, swordLightWorldX, swordLightWorldY)
                val hEmber = if (dHorse < swordLightRadius) (1f - dHorse / swordLightRadius) else 0f
                charRenderer.drawWildHorse(canvas, hx, hy, currentZoom, gameTime, hEmber)
            }
        }

        // 4. Draw ambient marsh/battlement sentinel figures (Video 2)
        for (i in sentinelX.indices) {
            val sx = sentinelX[i]
            val sy = sentinelY[i]
            val sz = landMap.sampleHeightAtWorld(sx, sy).coerceAtLeast(0f)
            val scrX = (sx - camX) * currentZoom + halfW
            val scrY = ((sy - camY) * WorldConfig.Y_TILT - sz * WorldConfig.Z_LIFT) * currentZoom + halfH
            if (scrX in -80f..(w + 80f) && scrY in -80f..(h + 80f)) {
                charRenderer.drawAmbientSentinel(canvas, scrX, scrY, currentZoom, gameTime, i * 1.7f, 0.25f)
            }
        }

        // 5. Render Senje (Shadow, Optional Horse Mount, Micro-ASCII Chainmail Coif & Crimson Surcoat,
        //    Blazing Ember Longsword, Floating Ember Sparks, and "Senje" Nameplate)
        val playerScreenX = (playerX - camX) * currentZoom + halfW
        val playerScreenY = ((playerY - camY) * WorldConfig.Y_TILT - playerZ * WorldConfig.Z_LIFT) * currentZoom + halfH

        charRenderer.drawSenje(
            canvas = canvas,
            screenX = playerScreenX,
            screenY = playerScreenY,
            zoom = currentZoom,
            time = gameTime,
            facingX = facingX,
            facingY = facingY,
            moveSpeed = moveSpeed,
            slashTimer = slashTimer,
            isMounted = isMounted,
            flameBoost = flameBoost,
            worldToScreenX = { wx -> (wx - camX) * currentZoom + halfW },
            worldToScreenY = { wy, wz -> ((wy - camY) * WorldConfig.Y_TILT - wz * WorldConfig.Z_LIFT) * currentZoom + halfH }
        )

        // 6. Render Bottom HUD Bar (LV 25, Golden XP Bar, 10-slot Hotbar) & Virtual Joystick
        hudRenderer.drawHud(
            canvas = canvas,
            screenW = w,
            screenH = h,
            xpValue = playerXp,
            xpMax = playerXpMax,
            level = playerLevel,
            isMounted = isMounted,
            zoomIndex = zoomIndex,
            zoneName = currentZoneLabel,
            flameBoost = flameBoost,
            joyActive = joyActive,
            joyOriginX = joyOriginX,
            joyOriginY = joyOriginY,
            joyCurX = joyCurX,
            joyCurY = joyCurY
        )
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)

        val action = event.actionMasked
        val index = event.actionIndex
        val pointerId = event.getPointerId(index)
        val x = event.getX(index)
        val y = event.getY(index)

        when (action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                // 1. Check if tapping a Bottom Hotbar Slot (1..0)
                val slot = hudRenderer.hitTestHotbarSlot(x, y, width, height)
                if (slot != -1) {
                    handleHotbarAction(slot)
                    return true
                }

                // 2. Left half of screen -> Virtual Joystick for 8-directional movement
                if (x < width * 0.55f && !joyActive) {
                    joyPointerId = pointerId
                    joyActive = true
                    joyOriginX = x
                    joyOriginY = y
                    joyCurX = x
                    joyCurY = y
                    joyVecX = 0f
                    joyVecY = 0f
                } else {
                    // 3. Right half of screen -> Trigger Fiery Longsword Slash!
                    triggerSwordSlash()
                }
            }

            MotionEvent.ACTION_MOVE -> {
                if (joyActive) {
                    val jIdx = event.findPointerIndex(joyPointerId)
                    if (jIdx != -1) {
                        val mx = event.getX(jIdx)
                        val my = event.getY(jIdx)
                        val dx = mx - joyOriginX
                        val dy = my - joyOriginY
                        val maxRad = 64f
                        val dist = sqrt(dx * dx + dy * dy)
                        if (dist > maxRad) {
                            joyCurX = joyOriginX + (dx / dist) * maxRad
                            joyCurY = joyOriginY + (dy / dist) * maxRad
                            joyVecX = dx / dist
                            joyVecY = dy / dist
                        } else {
                            joyCurX = mx
                            joyCurY = my
                            joyVecX = dx / maxRad
                            joyVecY = dy / maxRad
                        }
                    }
                }
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                if (pointerId == joyPointerId || action == MotionEvent.ACTION_CANCEL) {
                    joyActive = false
                    joyPointerId = MotionEvent.INVALID_POINTER_ID
                    joyVecX = 0f
                    joyVecY = 0f
                }
            }
        }
        return true
    }

    private fun triggerSwordSlash() {
        slashTimer = 0.38f
        playerXp = (playerXp + 17).coerceAtMost(playerXpMax)
        if (playerXp >= playerXpMax) {
            playerLevel++
            playerXp = 120
        }
    }

    private fun handleHotbarAction(slotIndex: Int) {
        when (slotIndex) {
            0 -> {
                // Slot 1: Fiery Longsword Slash
                triggerSwordSlash()
            }
            1 -> {
                // Slot 2: Toggle White ASCII Warhorse Mount (Video 2)
                isMounted = !isMounted
            }
            2 -> {
                // Slot 3: Cycle Camera Zoom Presets (Close-up Chainmail / Mid / Wide Overview)
                zoomIndex = (zoomIndex + 1) % WorldConfig.ZOOM_PRESETS.size
                targetZoom = WorldConfig.ZOOM_PRESETS[zoomIndex]
            }
            3 -> {
                // Slot 4: Cycle through the 4 signature scenes from the 3 videos for instant inspection
                currentZoneWaypoint = (currentZoneWaypoint + 1) % 4
                when (currentZoneWaypoint) {
                    0 -> {
                        // Video 1: Whispering Meadow & Chainmail Close-Up
                        playerX = landMap.meadowSpawnX
                        playerY = landMap.meadowSpawnY
                    }
                    1 -> {
                        // Video 2 (00:02): Moonlit River & Watchtower Base Ramp
                        playerX = landMap.moonReflectX + 35f
                        playerY = landMap.moonReflectY - 65f
                    }
                    2 -> {
                        // Video 2 (00:18): Watchtower High Ground Roof next to the Flickering Brazier
                        playerX = landMap.towerCenterX - 18f
                        playerY = landMap.towerCenterY + 22f
                    }
                    3 -> {
                        // Video 3 (00:22): Citadel Chasm Bridge & Swaying Crimson Banners
                        playerX = 148f * WorldConfig.CELL_SIZE
                        playerY = 64f * WorldConfig.CELL_SIZE
                    }
                }
                playerZ = landMap.sampleHeightAtWorld(playerX, playerY).coerceAtLeast(0f)
                camX = playerX
                camY = playerY
                camZ = playerZ
            }
            4 -> {
                // Slot 5: Toggle Ember Sword Flame Aura Boost
                flameBoost = !flameBoost
            }
            else -> {
                triggerSwordSlash()
            }
        }
    }
}
