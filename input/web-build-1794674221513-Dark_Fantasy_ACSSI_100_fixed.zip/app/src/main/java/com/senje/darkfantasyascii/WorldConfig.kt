package com.senje.darkfantasyascii

import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Core 2.5D projection constants, color palettes, and zero-allocation lighting math
 * matching the reference videos (Chainmail test, Tower high ground, Citadel & Forest).
 */
object WorldConfig {

    // World grid dimensions (each cell is 18x18 world units)
    const val GRID_W = 220
    const val GRID_H = 220
    const val CELL_SIZE = 18f
    const val WORLD_W = GRID_W * CELL_SIZE
    const val WORLD_H = GRID_H * CELL_SIZE

    // 2.5D Oblique Top-Down Projection factor:
    // screenX = (worldX - camX) * zoom + screenCenterX
    // screenY = ((worldY - camY) * Y_TILT - worldZ * Z_LIFT) * zoom + screenCenterY
    const val Y_TILT = 0.82f
    const val Z_LIFT = 1.08f

    // Camera zoom presets matching the videos:
    // 0: Close-up Chainmail Inspection (Video 1 00:00 & 00:42)
    // 1: Mid-range Exploration (Video 2 00:18 & Video 3 00:08)
    // 2: Wide Tower / River / Citadel Overview (Video 1 00:39 & Video 2 00:02)
    val ZOOM_PRESETS = floatArrayOf(1.65f, 1.02f, 0.56f)

    // Biome / Tile types
    const val TILE_VOID_CHASM = 0
    const val TILE_WATER_RIVER = 1
    const val TILE_MEADOW_GRASS = 2
    const val TILE_STONE_PATH = 3
    const val TILE_TOWER_WALL = 4
    const val TILE_TOWER_ROOF = 5
    const val TILE_TOWER_RAMP = 6
    const val TILE_TOWER_ARCH = 7
    const val TILE_CITADEL_WALL = 8
    const val TILE_CITADEL_BRIDGE = 9
    const val TILE_FOREST_SOIL = 10

    // Reference Palette Colors (ARGB)
    const val COL_BG_VOID = 0xFF040609.toInt()
    const val COL_WATER_DEEP = 0xFF06090E.toInt()
    const val COL_WATER_RIPPLE = 0xFF283442.toInt()
    const val COL_MOON_BRIGHT = 0xFFDCE6F2.toInt()
    const val COL_MOON_MID = 0xFF8C9EB2.toInt()
    const val COL_MOON_DIM = 0xFF425062.toInt()

    // Meadow substrate ASCII (Q08dBOaq) & Grass blades
    const val COL_SUBSTRATE_SLATE = 0xFF56687A.toInt()
    const val COL_SUBSTRATE_DARK = 0xFF34414E.toInt()
    const val COL_GRASS_ROOT = 0xFF172B19.toInt()
    const val COL_GRASS_BODY = 0xFF395E36.toInt()
    const val COL_GRASS_TIP = 0xFF66915B.toInt()
    const val COL_GRASS_HIGHLIGHT = 0xFF82AD74.toInt()
    const val COL_FLOWER_WHITE = 0xFFE8F2FC.toInt()
    const val COL_FLOWER_BLUE = 0xFFAEC4DC.toInt()

    // Stone Tower & Citadel Masonry
    const val COL_STONE_BRIGHT = 0xFFAEBCCA.toInt()
    const val COL_STONE_MID = 0xFF728191.toInt()
    const val COL_STONE_DARK = 0xFF3B4552.toInt()
    const val COL_STONE_DEEP = 0xFF1B2129.toInt()
    const val COL_IVY_DARK = 0xFF2D4F2B.toInt()
    const val COL_IVY_MID = 0xFF4E7D46.toInt()
    const val COL_IVY_BRIGHT = 0xFF7CAE6D.toInt()

    // Trees & Banners (Video 3)
    const val COL_TREE_FOLIAGE_BRIGHT = 0xFF8CC2AD.toInt()
    const val COL_TREE_FOLIAGE_MID = 0xFF568C78.toInt()
    const val COL_TREE_FOLIAGE_DARK = 0xFF2B4D41.toInt()
    const val COL_TREE_TRUNK = 0xFF5B6770.toInt()
    const val COL_BANNER_CRIMSON = 0xFFB8432A.toInt()
    const val COL_BANNER_DARK = 0xFF732415.toInt()
    const val COL_LANTERN_GOLD = 0xFFD99B4E.toInt()

    // Character (Senje) Palette (Video 1 & Video 2)
    const val COL_MAIL_SPECULAR = 0xFFF2F7FC.toInt()
    const val COL_MAIL_SILVER = 0xFFC2CEDB.toInt()
    const val COL_MAIL_MID = 0xFF7C8B9B.toInt()
    const val COL_MAIL_SHADOW = 0xFF36404C.toInt()
    const val COL_SURCOAT_LIT = 0xFFB83622.toInt()
    const val COL_SURCOAT_CRIMSON = 0xFF751B16.toInt()
    const val COL_SURCOAT_DARK = 0xFF3D0C0B.toInt()
    const val COL_SWORD_CORE = 0xFFFFF5C2.toInt()
    const val COL_SWORD_FLAME = 0xFFFF7E1C.toInt()
    const val COL_SWORD_EMBER = 0xFFC9380A.toInt()

    /**
     * Zero-allocation dynamic point light + directional shadow color mixer.
     * Applies warm orange ember light (from Senje's flaming sword and tower braziers)
     * and darkens pixels inside cast shadows.
     */
    fun applyDynamicLight(
        baseColor: Int,
        ambientMul: Float,
        emberLight: Float,
        shadowDarken: Float
    ): Int {
        val a = (baseColor ushr 24) and 0xFF
        var r = ((baseColor ushr 16) and 0xFF).toFloat()
        var g = ((baseColor ushr 8) and 0xFF).toFloat()
        var b = (baseColor and 0xFF).toFloat()

        val effMul = (ambientMul * (1f - shadowDarken * 0.68f)).coerceIn(0.12f, 1.5f)
        r *= effMul
        g *= effMul
        b *= effMul

        if (emberLight > 0.005f) {
            val e = emberLight.coerceAtMost(1.35f)
            r += 235f * e
            g += 112f * e
            b += 24f * e
        }

        val ri = r.toInt().coerceIn(0, 255)
        val gi = g.toInt().coerceIn(0, 255)
        val bi = b.toInt().coerceIn(0, 255)
        return (a shl 24) or (ri shl 16) or (gi shl 8) or bi
    }

    /**
     * Fast deterministic hash for procedural ASCII glyph placement without allocations.
     */
    fun hash2D(x: Int, y: Int): Int {
        var h = x * 374761393 + y * 668265263
        h = (h xor (h ushr 13)) * 1274126177
        return (h xor (h ushr 16)) and 0x7FFFFFFF
    }

    fun smoothStep(edge0: Float, edge1: Float, x: Float): Float {
        val t = ((x - edge0) / (edge1 - edge0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    fun dist(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x2 - x1
        val dy = y2 - y1
        return sqrt(dx * dx + dy * dy)
    }
}
