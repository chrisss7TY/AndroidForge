package com.senje.darkfantasyascii

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * 2.5D Land Generator and Renderer for "Dark Fantasy ACSSI 100".
 *
 * Implements the three interconnected zones from the reference videos:
 * 1. The Whispering Meadow (Video 1 - 1000461713.mp4):
 *    - Slate-blue/grey ASCII substrate clusters (Q, 0, 8, O, d, B, a, q) on deep black void.
 *    - High-density 2.5D wind-swaying green grass blades that bend around Senje and catch sword light.
 *    - Bright white/ice-blue ASCII wildflower clusters (o*o, *, o, O).
 * 2. The Moonlit River & Overgrown Cylindrical Watchtower High Ground (Video 2 - 1000461712.mp4):
 *    - Abyssal water with horizontal ASCII ripples (-, ~, =, :, .) and the Giant Silver ASCII Full Moon Reflection.
 *    - 2.5D cylindrical stone watchtower (WMMMQB#@, 0&BQ$q, %wxdp, #brzbb) with arched dungeon doorway,
 *      clinging green ASCII ivy/moss tendrils, walkable spiral stone ramp up to the roof (z = 148f),
 *      crenellated battlements, and a flickering orange roof brazier.
 * 3. The Dark Forest Trail, Citadel Twin Bastions, Crimson Banners & Chasm Bridges (Video 3 - 1000461710.mp4):
 *    - Cobblestone ASCII path flanked by tall 2.5D cyan-sage ASCII trees.
 *    - Twin citadel bastion towers, two angled stone bridges over a dark chasm, swaying crimson banners,
 *      and hanging iron gallows lanterns.
 */
class LandMap25D {

    private val gw = WorldConfig.GRID_W
    private val gh = WorldConfig.GRID_H
    private val totalCells = gw * gh

    // Flat primitive arrays for zero-allocation 60 FPS access
    val tileType = IntArray(totalCells)
    val heightZ = FloatArray(totalCells)
    val groundGlyph = CharArray(totalCells)
    val ivyMask = ByteArray(totalCells)
    val flowerMask = ByteArray(totalCells)

    // Key landmark coordinates (in world units)
    // 1. Meadow Spawn (Video 1)
    val meadowSpawnX = 110f * WorldConfig.CELL_SIZE
    val meadowSpawnY = 148f * WorldConfig.CELL_SIZE

    // 2. Watchtower High Ground (Video 2)
    val towerCenterX = 88f * WorldConfig.CELL_SIZE
    val towerCenterY = 92f * WorldConfig.CELL_SIZE
    val towerRadius = 21.5f * WorldConfig.CELL_SIZE
    val towerRoofZ = 148f
    val towerBrazierX = towerCenterX + 5.5f * WorldConfig.CELL_SIZE
    val towerBrazierY = towerCenterY + 2.5f * WorldConfig.CELL_SIZE

    // Giant ASCII Moon Reflection center in the river south-west of the tower (Video 2 00:02)
    val moonReflectX = 68f * WorldConfig.CELL_SIZE
    val moonReflectY = 116f * WorldConfig.CELL_SIZE
    val moonReflectRadius = 11.5f * WorldConfig.CELL_SIZE

    // 3. Citadel Twin Bastions & Chasm Bridges (Video 3)
    val citadelLeftTowerX = 152f * WorldConfig.CELL_SIZE
    val citadelLeftTowerY = 58f * WorldConfig.CELL_SIZE
    val citadelRightTowerX = 176f * WorldConfig.CELL_SIZE
    val citadelRightTowerY = 54f * WorldConfig.CELL_SIZE

    // Ambient torch/brazier light sources (X, Y, Z, Radius)
    val lightCount = 6
    val lightX = FloatArray(lightCount)
    val lightY = FloatArray(lightCount)
    val lightZ = FloatArray(lightCount)
    val lightRadius = FloatArray(lightCount)

    // Swaying Crimson Banners (Video 3 00:16 - 00:24)
    val bannerCount = 5
    val bannerX = FloatArray(bannerCount)
    val bannerY = FloatArray(bannerCount)
    val bannerZ = FloatArray(bannerCount)

    // Hanging Iron Gallows Lanterns (Video 3 00:18 - 00:22)
    val lanternCount = 4
    val lanternX = FloatArray(lanternCount)
    val lanternY = FloatArray(lanternCount)
    val lanternZ = FloatArray(lanternCount)

    // 2.5D Trees in Forest Zone (Video 3 00:00 - 00:06)
    val treeCount = 26
    val treeX = FloatArray(treeCount)
    val treeY = FloatArray(treeCount)
    val treeZ = FloatArray(treeCount)
    val treeScale = FloatArray(treeCount)

    // Reusable Paints
    private val asciiPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }

    private val grassPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val charBuf = CharArray(1)
    private val flowerBuf = charArrayOf('o', '*', 'o')

    private val meadowSubstrateChars = charArrayOf('Q', '0', '8', 'O', 'd', 'B', 'a', 'q', 'p', 'c')
    private val stoneMasonryChars = charArrayOf(
        'W', 'M', 'Q', 'B', '#', '@', '%', '$', '0', '8',
        'd', 'p', 'w', 'z', 'r', 'x', 'v', 'c', '+', '=', '~', ':'
    )
    private val ivyChars = charArrayOf('c', 'v', 'r', 's', 'z', '*', '+', '/', '\\', '(')
    private val waterRippleChars = charArrayOf('-', '~', '=', ':', '.')

    init {
        buildWorld()
    }

    private fun idx(cx: Int, cy: Int): Int = cy * gw + cx

    private fun buildWorld() {
        val tcx = 88f
        val tcy = 92f
        val tRad = 21.5f

        for (cy in 0 until gh) {
            for (cx in 0 until gw) {
                val i = idx(cx, cy)
                val h = WorldConfig.hash2D(cx, cy)
                val fx = cx.toFloat()
                val fy = cy.toFloat()

                // Default: Whispering Meadow (Zone 1)
                var type = WorldConfig.TILE_MEADOW_GRASS
                var z = 0f
                var glyph = ' '

                // Organic clusters of Q08dBOaq substrate characters under the meadow grass (v1_01.png)
                val clusterNoise = sin(fx * 0.23f) * cos(fy * 0.19f) + sin((fx + fy) * 0.11f) * 0.5f
                if (clusterNoise > -0.15f && (h % 100) < 64) {
                    glyph = meadowSubstrateChars[h % meadowSubstrateChars.size]
                }

                // Wildflowers (o*o, *, o) scattered in the meadow (v1_01.png)
                if ((h % 1000) < 38) {
                    flowerMask[i] = (1 + (h % 3)).toByte()
                }

                // Zone 2: Moonlit River & Moat curving around the southern and western base of the Watchtower
                val dxTower = fx - tcx
                val dyTower = fy - tcy
                val distTower = sqrt(dxTower * dxTower + dyTower * dyTower)

                val riverCenterCurveX = 72f + sin(fy * 0.055f) * 18f
                val distFromRiver = abs(fx - riverCenterCurveX)
                val inMoat = distTower > tRad + 1.2f && distTower < tRad + 16.5f && (dyTower > -8f || dxTower < 6f)

                if (inMoat || (fy in 96f..145f && distFromRiver < 13.5f && fy < 132f)) {
                    type = WorldConfig.TILE_WATER_RIVER
                    z = -6f
                    glyph = waterRippleChars[h % waterRippleChars.size]
                    flowerMask[i] = 0
                }

                // Walkable Spiral/Sloped Stone & Moss Ramp on the western/south-western flank of the Watchtower
                // Lets the player walk seamlessly from the river bank (z=0) up to the Watchtower Roof (z=148f)!
                val angleTower = atan2(dyTower, dxTower) // -PI to PI
                if (distTower in (tRad - 3.2f)..(tRad + 4.2f)) {
                    // Ramp wraps from south-west (angle ~ 2.1 rad) counter-clockwise up to north-west (angle ~ -1.2 rad)
                    var normAng = angleTower
                    if (normAng < -1.6f) normAng += (Math.PI * 2.0).toFloat()
                    if (normAng in -1.1f..2.35f) {
                        val rampProgress = ((2.35f - normAng) / 3.45f).coerceIn(0f, 1f)
                        type = WorldConfig.TILE_TOWER_RAMP
                        z = rampProgress * towerRoofZ
                        glyph = stoneMasonryChars[h % stoneMasonryChars.size]
                        if ((h % 100) < 42) ivyMask[i] = 1
                        flowerMask[i] = 0
                    }
                }

                // Cylindrical Stone Watchtower Interior & Roof High Ground (Video 2 00:08 - 00:35)
                if (distTower <= tRad) {
                    flowerMask[i] = 0
                    // Dark arched doorway at the southern base (v2_05.png)
                    if (dyTower > tRad - 5.5f && abs(dxTower) < 3.6f) {
                        type = WorldConfig.TILE_TOWER_ARCH
                        z = 0f
                        glyph = ' '
                    } else if (distTower >= tRad - 2.4f && type != WorldConfig.TILE_TOWER_RAMP) {
                        // Crenellated outer stone wall & battlements
                        type = WorldConfig.TILE_TOWER_WALL
                        val merlon = ((atan2(dyTower, dxTower) * 12f).toInt() and 1) == 0
                        z = if (merlon) towerRoofZ + 10f else towerRoofZ + 2f
                        glyph = stoneMasonryChars[h % stoneMasonryChars.size]
                        if ((h % 100) < 46) ivyMask[i] = 1
                    } else if (type != WorldConfig.TILE_TOWER_RAMP) {
                        // Walkable Tower High Ground Roof!
                        type = WorldConfig.TILE_TOWER_ROOF
                        z = towerRoofZ
                        glyph = stoneMasonryChars[h % stoneMasonryChars.size]
                        // Lush green ASCII ivy/moss patches growing across the tower roof (v2_09.png)
                        val ivyNoise = sin(fx * 0.35f) * cos(fy * 0.32f)
                        if (ivyNoise > 0.18f || (h % 100) < 28) {
                            ivyMask[i] = 1
                        }
                    }
                }

                // Zone 3: North-East Forest Path, Chasm Bridges & Citadel Twin Bastions (Video 3)
                // Forest cobblestone trail leading from Meadow (110, 140) -> North-East (142, 78)
                val pathCenterX = 112f + (148f - fy).coerceAtLeast(0f) * 0.45f + sin(fy * 0.12f) * 3.5f
                if (fy in 68f..146f && abs(fx - pathCenterX) < 3.8f && type == WorldConfig.TILE_MEADOW_GRASS) {
                    type = WorldConfig.TILE_STONE_PATH
                    z = 2f
                    glyph = if ((h % 3) == 0) 'Q' else if ((h % 3) == 1) '0' else '8'
                    flowerMask[i] = 0
                }

                // Deep Abyssal Chasm in the North-East Citadel zone (Video 3 00:25 - 00:31)
                if (fx > 128f && fy < 76f) {
                    type = WorldConfig.TILE_VOID_CHASM
                    z = -120f
                    glyph = ' '
                    flowerMask[i] = 0

                    // Two parallel diagonal ASCII stone bridges spanning the chasm (Video 3 00:26 - 00:31)
                    // Upper bridge & lower bridge angling from (128, 72) & (128, 60) toward the Citadel Bastions
                    val b1Y = 72f - (fx - 128f) * 0.42f
                    val b2Y = 82f - (fx - 128f) * 0.42f
                    if ((abs(fy - b1Y) < 2.3f || abs(fy - b2Y) < 2.3f) && fx <= 178f) {
                        type = WorldConfig.TILE_CITADEL_BRIDGE
                        z = 24f + (fx - 128f) * 0.65f
                        glyph = if ((h % 2) == 0) 'Q' else '0'
                    }

                    // Twin Cylindrical Citadel Bastion Towers (v3_12.png)
                    val dLeft = WorldConfig.dist(fx, fy, 152f, 58f)
                    val dRight = WorldConfig.dist(fx, fy, 174f, 54f)
                    val inCitadelKeep = (fx in 146f..184f && fy in 42f..68f && (dLeft < 11f || dRight < 11f || (fx in 152f..174f && fy in 48f..62f)))
                    if (inCitadelKeep) {
                        type = WorldConfig.TILE_CITADEL_WALL
                        z = 52f + (if (dLeft < 8f || dRight < 8f) 42f else 0f)
                        glyph = if ((h % 3) == 0) 'Q' else if ((h % 3) == 1) '@' else '#'
                    }
                }

                tileType[i] = type
                heightZ[i] = z
                groundGlyph[i] = glyph
            }
        }

        // Populate dynamic world braziers / lights
        // 0: Watchtower High Ground Roof Brazier (Video 2 00:18 - 00:35)
        lightX[0] = towerBrazierX
        lightY[0] = towerBrazierY
        lightZ[0] = towerRoofZ + 12f
        lightRadius[0] = 280f

        // 1: Watchtower Southern Arch Torch
        lightX[1] = towerCenterX - 75f
        lightY[1] = towerCenterY + towerRadius + 18f
        lightZ[1] = 14f
        lightRadius[1] = 210f

        // 2 & 3: Citadel Twin Bastion Braziers (Video 3 00:21 - 00:27)
        lightX[2] = citadelLeftTowerX
        lightY[2] = citadelLeftTowerY + 95f
        lightZ[2] = 64f
        lightRadius[2] = 260f

        lightX[3] = citadelRightTowerX - 45f
        lightY[3] = citadelRightTowerY + 115f
        lightZ[3] = 58f
        lightRadius[3] = 260f

        // 4 & 5: Forest Path & Citadel Gate Braziers
        lightX[4] = 136f * WorldConfig.CELL_SIZE
        lightY[4] = 84f * WorldConfig.CELL_SIZE
        lightZ[4] = 18f
        lightRadius[4] = 220f

        lightX[5] = 162f * WorldConfig.CELL_SIZE
        lightY[5] = 74f * WorldConfig.CELL_SIZE
        lightZ[5] = 45f
        lightRadius[5] = 230f

        // Swaying Crimson Banners in the Citadel & Forest Approach (Video 3 00:16 - 00:22)
        val bCoords = arrayOf(
            floatArrayOf(134f, 88f, 12f),
            floatArrayOf(145f, 82f, 18f),
            floatArrayOf(158f, 72f, 44f),
            floatArrayOf(169f, 68f, 48f),
            floatArrayOf(148f, 64f, 52f)
        )
        for (b in 0 until bannerCount) {
            bannerX[b] = bCoords[b][0] * WorldConfig.CELL_SIZE
            bannerY[b] = bCoords[b][1] * WorldConfig.CELL_SIZE
            bannerZ[b] = bCoords[b][2]
        }

        // Hanging Iron Gallows Lanterns (Video 3 00:18 - 00:22)
        val lCoords = arrayOf(
            floatArrayOf(139f, 86f, 14f),
            floatArrayOf(154f, 76f, 38f),
            floatArrayOf(165f, 71f, 46f),
            floatArrayOf(104f, 122f, 6f)
        )
        for (l in 0 until lanternCount) {
            lanternX[l] = lCoords[l][0] * WorldConfig.CELL_SIZE
            lanternY[l] = lCoords[l][1] * WorldConfig.CELL_SIZE
            lanternZ[l] = lCoords[l][2]
        }

        // Towering 2.5D ASCII Trees along the Forest Trail (Video 3 00:00 - 00:06)
        var tIdx = 0
        for (s in 0 until treeCount) {
            val h = WorldConfig.hash2D(s * 19, s * 37)
            val side = if (s % 2 == 0) -1f else 1f
            val tyCell = 78f + (s * 2.7f)
            val pathX = 112f + (148f - tyCell).coerceAtLeast(0f) * 0.45f
            val txCell = pathX + side * (7.5f + (h % 14))
            treeX[tIdx] = txCell * WorldConfig.CELL_SIZE
            treeY[tIdx] = tyCell * WorldConfig.CELL_SIZE
            treeZ[tIdx] = sampleHeightAtWorld(treeX[tIdx], treeY[tIdx]).coerceAtLeast(0f)
            treeScale[tIdx] = 0.88f + ((h % 35) / 100f)
            tIdx++
        }
    }

    fun sampleHeightAtWorld(wx: Float, wy: Float): Float {
        val cx = (wx / WorldConfig.CELL_SIZE).toInt().coerceIn(0, gw - 1)
        val cy = (wy / WorldConfig.CELL_SIZE).toInt().coerceIn(0, gh - 1)
        return heightZ[idx(cx, cy)]
    }

    fun sampleTileAtWorld(wx: Float, wy: Float): Int {
        val cx = (wx / WorldConfig.CELL_SIZE).toInt().coerceIn(0, gw - 1)
        val cy = (wy / WorldConfig.CELL_SIZE).toInt().coerceIn(0, gh - 1)
        return tileType[idx(cx, cy)]
    }

    /**
     * Checks whether Senje can walk to (targetX, targetY) from currentZ,
     * allowing smooth climbing up the Watchtower ramp, walking on the roof high ground,
     * wading into shallow river water, and crossing the Citadel chasm bridges.
     */
    fun canWalkTo(targetX: Float, targetY: Float, currentZ: Float): Boolean {
        if (targetX < 36f || targetX > WorldConfig.WORLD_W - 36f ||
            targetY < 36f || targetY > WorldConfig.WORLD_H - 36f
        ) {
            return false
        }
        val tile = sampleTileAtWorld(targetX, targetY)
        if (tile == WorldConfig.TILE_VOID_CHASM) return false

        val targetZ = sampleHeightAtWorld(targetX, targetY)
        // Prevent stepping directly through sheer vertical cliff/tower walls unless on the ramp or already on the roof
        return abs(targetZ - currentZ) <= 46f
    }

    /**
     * Renders the visible 2.5D Land (Ground Substrate, Reflective Moonlit River, 2.5D Cylindrical
     * Watchtower Masonry & Overgrown Ivy, Wind-Swaying 2.5D Grass Blades & Wildflowers,
     * Citadel Bridges, Swaying Crimson Banners, Iron Lanterns, Braziers, and ASCII Trees).
     */
    fun drawLand(
        canvas: Canvas,
        camX: Float,
        camY: Float,
        camZ: Float,
        zoom: Float,
        screenW: Int,
        screenH: Int,
        time: Float,
        playerX: Float,
        playerY: Float,
        playerZ: Float,
        swordLightX: Float,
        swordLightY: Float,
        swordLightRadius: Float,
        isMounted: Boolean,
        charRenderer: SenjeCharacterRenderer
    ) {
        val halfW = screenW * 0.5f
        val halfH = screenH * 0.5f
        val cs = WorldConfig.CELL_SIZE

        // Compute visible grid bounds in world space with generous padding for 2.5D verticality
        val viewSpanX = (halfW / zoom) + 220f
        val viewSpanY = (halfH / (zoom * WorldConfig.Y_TILT)) + 320f

        val minCx = ((camX - viewSpanX) / cs).toInt().coerceIn(1, gw - 2)
        val maxCx = ((camX + viewSpanX) / cs).toInt().coerceIn(1, gw - 2)
        val minCy = ((camY - viewSpanY) / cs).toInt().coerceIn(1, gh - 2)
        val maxCy = ((camY + viewSpanY) / cs).toInt().coerceIn(1, gh - 2)

        asciiPaint.textSize = (11.5f * zoom).coerceIn(5.5f, 26f)
        grassPaint.strokeWidth = (1.65f * zoom).coerceIn(1.0f, 3.8f)

        val playerScreenX = (playerX - camX) * zoom + halfW
        val playerScreenY = ((playerY - camY) * WorldConfig.Y_TILT - playerZ * WorldConfig.Z_LIFT) * zoom + halfH

        var drewPlayer = false

        // Front-to-back / Painter's algorithm row-by-row in Y so 2.5D elevation & character occlude naturally
        for (cy in minCy..maxCy) {
            val rowWorldY = cy * cs

            for (cx in minCx..maxCx) {
                val i = idx(cx, cy)
                val type = tileType[i]
                if (type == WorldConfig.TILE_VOID_CHASM) continue

                val wx = cx * cs
                val wy = rowWorldY
                val wz = heightZ[i]

                val sx = (wx - camX) * zoom + halfW
                val sy = ((wy - camY) * WorldConfig.Y_TILT - wz * WorldConfig.Z_LIFT) * zoom + halfH

                if (sx < -60f || sx > screenW + 60f || sy < -120f || sy > screenH + 120f) continue

                // Calculate dynamic point-light illumination from Senje's flaming sword + nearby braziers
                val dxSword = wx - swordLightX
                val dySword = wy - swordLightY
                val dzSword = (wz - playerZ) * 0.7f
                val distSword = sqrt(dxSword * dxSword + dySword * dySword + dzSword * dzSword)
                var emberIllum = if (distSword < swordLightRadius) {
                    val t = 1f - (distSword / swordLightRadius)
                    t * t * 1.15f
                } else {
                    0f
                }

                // Add static world brazier light
                for (l in 0 until lightCount) {
                    val dlx = wx - lightX[l]
                    val dly = wy - lightY[l]
                    val dlz = (wz - lightZ[l]) * 0.6f
                    val dLight = sqrt(dlx * dlx + dly * dly + dlz * dlz)
                    val rad = lightRadius[l]
                    if (dLight < rad) {
                        val lt = 1f - (dLight / rad)
                        val flicker = 0.88f + 0.12f * sin(time * 14f + l * 2.1f)
                        emberIllum += lt * lt * 1.05f * flicker
                    }
                }

                // Directional shadow cast by Senje to the right / bottom-right (v1_01.png)
                val relPx = wx - playerX
                val relPy = wy - playerY
                val shadowFactor = if (abs(wz - playerZ) < 28f && relPx in -6f..68f && abs(relPy - relPx * 0.28f) < 18f) {
                    (1f - (relPx / 68f)).coerceIn(0f, 0.85f)
                } else {
                    0f
                }

                when (type) {
                    WorldConfig.TILE_WATER_RIVER -> {
                        drawWaterCell(canvas, cx, cy, wx, wy, sx, sy, zoom, time, emberIllum)
                    }
                    WorldConfig.TILE_MEADOW_GRASS -> {
                        drawMeadowCell(
                            canvas = canvas,
                            cellIdx = i,
                            cx = cx,
                            cy = cy,
                            wx = wx,
                            wy = wy,
                            sx = sx,
                            sy = sy,
                            zoom = zoom,
                            time = time,
                            emberIllum = emberIllum,
                            shadowFactor = shadowFactor,
                            playerX = playerX,
                            playerY = playerY
                        )
                    }
                    WorldConfig.TILE_TOWER_ROOF,
                    WorldConfig.TILE_TOWER_WALL,
                    WorldConfig.TILE_TOWER_RAMP,
                    WorldConfig.TILE_TOWER_ARCH -> {
                        drawTowerCell(
                            canvas = canvas,
                            cellIdx = i,
                            cx = cx,
                            cy = cy,
                            wx = wx,
                            wy = wy,
                            wz = wz,
                            sx = sx,
                            sy = sy,
                            zoom = zoom,
                            emberIllum = emberIllum,
                            shadowFactor = shadowFactor
                        )
                    }
                    WorldConfig.TILE_STONE_PATH,
                    WorldConfig.TILE_CITADEL_BRIDGE,
                    WorldConfig.TILE_CITADEL_WALL -> {
                        drawCitadelOrPathCell(
                            canvas = canvas,
                            cellIdx = i,
                            type = type,
                            cx = cx,
                            cy = cy,
                            wx = wx,
                            wy = wy,
                            wz = wz,
                            sx = sx,
                            sy = sy,
                            zoom = zoom,
                            emberIllum = emberIllum,
                            shadowFactor = shadowFactor
                        )
                    }
                }
            }

            // Draw water reflection of Senje when near the river
            if (!drewPlayer && rowWorldY >= playerY) {
                val nearWater = sampleTileAtWorld(playerX, playerY + 28f) == WorldConfig.TILE_WATER_RIVER ||
                    sampleTileAtWorld(playerX, playerY) == WorldConfig.TILE_WATER_RIVER
                if (nearWater && playerZ <= 12f) {
                    charRenderer.drawWaterReflection(
                        canvas = canvas,
                        screenX = playerScreenX,
                        screenY = playerScreenY,
                        zoom = zoom,
                        time = time,
                        isMounted = isMounted
                    )
                }
                drewPlayer = true
            }
        }

        // Draw flickering Braziers, Swaying Crimson Banners, Iron Lanterns, and 2.5D Forest Trees
        drawPropsAndTrees(canvas, camX, camY, halfW, halfH, zoom, screenW, screenH, time, swordLightX, swordLightY, swordLightRadius)
    }

    private fun drawWaterCell(
        canvas: Canvas,
        cx: Int,
        cy: Int,
        wx: Float,
        wy: Float,
        sx: Float,
        sy: Float,
        zoom: Float,
        time: Float,
        emberIllum: Float
    ) {
        // Horizontal wave distortion
        val wave = sin(wy * 0.09f + time * 3.4f + cx * 0.35f)
        val dxMoon = wx - moonReflectX + wave * 9f
        val dyMoon = (wy - moonReflectY) * 1.15f
        val distMoon = sqrt(dxMoon * dxMoon + dyMoon * dyMoon)

        // Giant Silver-White ASCII Full Moon Reflection in the river (Video 2 00:02 - 00:03)
        if (distMoon < moonReflectRadius) {
            val mNorm = 1f - (distMoon / moonReflectRadius)
            val craterNoise = sin(wx * 0.045f) * cos(wy * 0.052f)
            val moonGlyph = when {
                mNorm > 0.72f && craterNoise > -0.2f -> '@'
                mNorm > 0.52f -> 'Q'
                mNorm > 0.35f -> '0'
                mNorm > 0.18f -> '#'
                else -> '~'
            }
            val baseCol = when {
                mNorm > 0.65f -> WorldConfig.COL_MOON_BRIGHT
                mNorm > 0.35f -> WorldConfig.COL_MOON_MID
                else -> WorldConfig.COL_MOON_DIM
            }
            asciiPaint.color = WorldConfig.applyDynamicLight(baseCol, 0.95f + 0.12f * wave, emberIllum, 0f)
            charBuf[0] = moonGlyph
            canvas.drawText(charBuf, 0, 1, sx + wave * 2.5f * zoom, sy, asciiPaint)
            return
        }

        // Tower & shoreline water reflection ripples (-, ~, =, :)
        val dxTower = wx - towerCenterX
        val dyTower = wy - (towerCenterY + towerRadius * 1.25f)
        val inTowerReflection = abs(dxTower) < towerRadius * 0.92f && dyTower in 0f..(towerRadius * 1.35f)

        if (inTowerReflection) {
            val h = WorldConfig.hash2D(cx, cy + (time * 3f).toInt())
            charBuf[0] = if ((h and 1) == 0) '=' else '-'
            val refCol = WorldConfig.applyDynamicLight(0xFF435162.toInt(), 0.78f, emberIllum * 0.6f, 0f)
            asciiPaint.color = refCol
            canvas.drawText(charBuf, 0, 1, sx + wave * 2f * zoom, sy, asciiPaint)
        } else if (((cx + cy + (time * 2.5f).toInt()) % 3) == 0) {
            charBuf[0] = if (wave > 0.2f) '~' else '-'
            asciiPaint.color = WorldConfig.applyDynamicLight(WorldConfig.COL_WATER_RIPPLE, 0.85f, emberIllum * 0.5f, 0f)
            canvas.drawText(charBuf, 0, 1, sx, sy, asciiPaint)
        }
    }

    private fun drawMeadowCell(
        canvas: Canvas,
        cellIdx: Int,
        cx: Int,
        cy: Int,
        wx: Float,
        wy: Float,
        sx: Float,
        sy: Float,
        zoom: Float,
        time: Float,
        emberIllum: Float,
        shadowFactor: Float,
        playerX: Float,
        playerY: Float
    ) {
        // 1. Draw the slate-blue/grey monospace ASCII substrate character (Q, 0, 8, O, d, B, a, q)
        val subCh = groundGlyph[cellIdx]
        if (subCh != ' ') {
            asciiPaint.color = WorldConfig.applyDynamicLight(
                WorldConfig.COL_SUBSTRATE_SLATE,
                0.88f,
                emberIllum * 0.75f,
                shadowFactor
            )
            charBuf[0] = subCh
            canvas.drawText(charBuf, 0, 1, sx, sy, asciiPaint)
        }

        // 2. Draw 3 high-density 2.5D wind-swaying green grass blades per meadow cell (matching v1_01.png)
        val h = WorldConfig.hash2D(cx, cy)
        val windWave = sin(wx * 0.016f + wy * 0.011f + time * 2.35f) * 0.38f +
            cos(wx * 0.029f - time * 1.65f) * 0.18f

        // Part grass away from Senje's feet
        val dpx = wx - playerX
        val dpy = wy - playerY
        val distPlayerSq = dpx * dpx + dpy * dpy
        val tramplePush = if (distPlayerSq < 1600f && distPlayerSq > 1f) {
            val d = sqrt(distPlayerSq)
            ((40f - d) / 40f) * (if (dpx >= 0f) 0.65f else -0.65f)
        } else {
            0f
        }

        val bladeCount = if (zoom > 0.75f) 3 else 2
        for (b in 0 until bladeCount) {
            val bh = WorldConfig.hash2D(cx * 7 + b, cy * 13 + b)
            val offX = (((bh and 0xFF) / 255f) - 0.5f) * 15f * zoom
            val offY = ((((bh ushr 8) and 0xFF) / 255f) - 0.5f) * 13f * zoom

            val bx0 = sx + offX
            val by0 = sy + offY

            val baseTilt = (((bh ushr 16) and 0xFF) / 255f - 0.5f) * 0.52f
            val totalAngle = baseTilt + windWave + tramplePush
            val bladeLen = (11.5f + (bh % 7)) * zoom

            val bx1 = bx0 + sin(totalAngle) * bladeLen
            val by1 = by0 - cos(totalAngle) * bladeLen

            // Lower grass stem in deeper forest green
            grassPaint.color = WorldConfig.applyDynamicLight(
                WorldConfig.COL_GRASS_BODY,
                0.92f,
                emberIllum * 0.85f,
                shadowFactor
            )
            canvas.drawLine(bx0, by0, (bx0 + bx1) * 0.5f, (by0 + by1) * 0.5f, grassPaint)

            // Upper grass tip in lighter sage-green
            val tipCol = if ((bh and 3) == 0) WorldConfig.COL_GRASS_HIGHLIGHT else WorldConfig.COL_GRASS_TIP
            grassPaint.color = WorldConfig.applyDynamicLight(
                tipCol,
                0.98f,
                emberIllum * 0.95f,
                shadowFactor
            )
            canvas.drawLine((bx0 + bx1) * 0.5f, (by0 + by1) * 0.5f, bx1, by1, grassPaint)
        }

        // 3. Draw white/ice-blue ASCII wildflower clusters (o*o, *, o) on top of grass (v1_01.png)
        val fType = flowerMask[cellIdx].toInt()
        if (fType > 0) {
            val swayX = windWave * 4.5f * zoom
            val fCol = if ((h and 1) == 0) WorldConfig.COL_FLOWER_WHITE else WorldConfig.COL_FLOWER_BLUE
            asciiPaint.color = WorldConfig.applyDynamicLight(fCol, 1.05f, emberIllum * 0.6f, shadowFactor)
            if (fType == 1 && zoom > 0.85f) {
                // Iconic "o*o" triplet from v1_01.png!
                canvas.drawText(flowerBuf, 0, 3, sx + swayX, sy - 4f * zoom, asciiPaint)
            } else {
                charBuf[0] = if (fType == 2) '*' else 'o'
                canvas.drawText(charBuf, 0, 1, sx + swayX, sy - 4f * zoom, asciiPaint)
            }
        }
    }

    private fun drawTowerCell(
        canvas: Canvas,
        cellIdx: Int,
        cx: Int,
        cy: Int,
        wx: Float,
        wy: Float,
        wz: Float,
        sx: Float,
        sy: Float,
        zoom: Float,
        emberIllum: Float,
        shadowFactor: Float
    ) {
        val type = tileType[cellIdx]

        // Cylindrical 3D normal shading across the Watchtower width (brighter left/center, shadowed right edge)
        val nx = ((wx - towerCenterX) / towerRadius).coerceIn(-1f, 1f)
        val cylShade = (0.96f - nx * 0.28f).coerceIn(0.45f, 1.22f)

        // If this cell is on the front/southern facade of the Watchtower or Ramp, render vertical 2.5D stone wall columns!
        val dyCenter = wy - towerCenterY
        val isSouthernFacade = dyCenter > -towerRadius * 0.25f &&
            (type == WorldConfig.TILE_TOWER_WALL || type == WorldConfig.TILE_TOWER_RAMP)

        if (isSouthernFacade && wz > 12f) {
            val vSteps = (wz / 16f).toInt().coerceIn(1, 9)
            for (v in 0 until vSteps) {
                val vz = v * 16f
                val vsy = sy + (wz - vz) * WorldConfig.Z_LIFT * zoom
                val vh = WorldConfig.hash2D(cx * 11 + v, cy * 19 + v)

                // Leave dark recessed arched doorway opening at the southern base (v2_05.png)
                val nearArch = abs(wx - towerCenterX) < 62f && dyCenter > towerRadius * 0.65f && vz < 78f
                if (nearArch) continue

                val hasWallIvy = ((vh % 100) < 34)
                if (hasWallIvy) {
                    charBuf[0] = ivyChars[vh % ivyChars.size]
                    val ivyCol = if ((vh and 1) == 0) WorldConfig.COL_IVY_BRIGHT else WorldConfig.COL_IVY_MID
                    asciiPaint.color = WorldConfig.applyDynamicLight(ivyCol, cylShade, emberIllum, 0f)
                } else {
                    charBuf[0] = stoneMasonryChars[vh % stoneMasonryChars.size]
                    val stoneCol = when {
                        cylShade > 0.95f -> WorldConfig.COL_STONE_BRIGHT
                        cylShade > 0.72f -> WorldConfig.COL_STONE_MID
                        else -> WorldConfig.COL_STONE_DARK
                    }
                    asciiPaint.color = WorldConfig.applyDynamicLight(stoneCol, cylShade * (0.65f + 0.35f * (vz / wz)), emberIllum, 0f)
                }
                canvas.drawText(charBuf, 0, 1, sx, vsy, asciiPaint)
            }
        }

        // Draw top surface glyph (Roof High Ground, Ramp steps, or Crenellations)
        if (type == WorldConfig.TILE_TOWER_ARCH) return

        val ch = groundGlyph[cellIdx]
        if (ch != ' ') {
            val baseCol = when {
                type == WorldConfig.TILE_TOWER_WALL -> WorldConfig.COL_STONE_BRIGHT
                cylShade > 0.92f -> WorldConfig.COL_STONE_BRIGHT
                cylShade > 0.68f -> WorldConfig.COL_STONE_MID
                else -> WorldConfig.COL_STONE_DARK
            }
            asciiPaint.color = WorldConfig.applyDynamicLight(baseCol, cylShade, emberIllum, shadowFactor)
            charBuf[0] = ch
            canvas.drawText(charBuf, 0, 1, sx, sy, asciiPaint)
        }

        // Draw clinging green ASCII ivy & moss tendrils on the Watchtower roof & walls (v2_09.png)
        if (ivyMask[cellIdx].toInt() != 0) {
            val h = WorldConfig.hash2D(cx * 3, cy * 5)
            charBuf[0] = ivyChars[h % ivyChars.size]
            val ivyCol = if ((h and 1) == 0) WorldConfig.COL_IVY_BRIGHT else WorldConfig.COL_IVY_MID
            asciiPaint.color = WorldConfig.applyDynamicLight(ivyCol, cylShade * 1.05f, emberIllum * 0.8f, shadowFactor)
            canvas.drawText(charBuf, 0, 1, sx + 3f * zoom, sy - 3f * zoom, asciiPaint)
        }
    }

    private fun drawCitadelOrPathCell(
        canvas: Canvas,
        cellIdx: Int,
        type: Int,
        cx: Int,
        cy: Int,
        wx: Float,
        wy: Float,
        wz: Float,
        sx: Float,
        sy: Float,
        zoom: Float,
        emberIllum: Float,
        shadowFactor: Float
    ) {
        // If Citadel Wall or Chasm Bridge, draw 2.5D vertical masonry depth into the chasm below (v3_12.png)
        if (type == WorldConfig.TILE_CITADEL_WALL || type == WorldConfig.TILE_CITADEL_BRIDGE) {
            val depthRows = if (type == WorldConfig.TILE_CITADEL_WALL) 6 else 2
            for (d in 1..depthRows) {
                val vy = sy + d * 13f * zoom
                val vh = WorldConfig.hash2D(cx + d * 7, cy + d * 13)
                charBuf[0] = if ((vh and 1) == 0) 'Q' else '0'
                val fade = (1f - d * 0.13f).coerceAtLeast(0.28f)
                asciiPaint.color = WorldConfig.applyDynamicLight(WorldConfig.COL_STONE_MID, fade, emberIllum, 0f)
                canvas.drawText(charBuf, 0, 1, sx, vy, asciiPaint)
            }
        }

        val ch = groundGlyph[cellIdx]
        if (ch != ' ') {
            val baseCol = if (type == WorldConfig.TILE_CITADEL_WALL) {
                WorldConfig.COL_STONE_BRIGHT
            } else {
                WorldConfig.COL_STONE_MID
            }
            asciiPaint.color = WorldConfig.applyDynamicLight(baseCol, 0.92f, emberIllum, shadowFactor)
            charBuf[0] = ch
            canvas.drawText(charBuf, 0, 1, sx, sy, asciiPaint)
        }
    }

    private fun drawPropsAndTrees(
        canvas: Canvas,
        camX: Float,
        camY: Float,
        halfW: Float,
        halfH: Float,
        zoom: Float,
        screenW: Int,
        screenH: Int,
        time: Float,
        swordLightX: Float,
        swordLightY: Float,
        swordLightRadius: Float
    ) {
        // 1. Draw flickering Fire Braziers (Watchtower High Ground Roof & Citadel Towers)
        for (l in 0 until lightCount) {
            val sx = (lightX[l] - camX) * zoom + halfW
            val sy = ((lightY[l] - camY) * WorldConfig.Y_TILT - lightZ[l] * WorldConfig.Z_LIFT) * zoom + halfH
            if (sx < -80f || sx > screenW + 80f || sy < -80f || sy > screenH + 80f) continue

            val pulse = 1f + 0.14f * sin(time * 16f + l * 1.9f)
            glowPaint.color = 0x36FF6E14
            canvas.drawCircle(sx, sy - 6f * zoom, 34f * zoom * pulse, glowPaint)
            glowPaint.color = 0x55FFA834
            canvas.drawCircle(sx, sy - 6f * zoom, 16f * zoom * pulse, glowPaint)

            // Multi-glyph ASCII fire cluster (*, @, #, %, +)
            val fireGlyphs = charArrayOf('*', '@', '#', '%', '+')
            for (f in -2..2) {
                val fyOff = sin(time * 18f + f * 1.4f) * 4.5f * zoom
                charBuf[0] = fireGlyphs[(abs(f) + (time * 12f).toInt()) % fireGlyphs.size]
                asciiPaint.color = if (f == 0) WorldConfig.COL_SWORD_CORE else WorldConfig.COL_SWORD_FLAME
                canvas.drawText(charBuf, 0, 1, sx + f * 5.5f * zoom, sy + fyOff, asciiPaint)
            }
        }

        // 2. Draw Swaying Crimson Medieval Banners (Video 3 00:16 - 00:24)
        for (b in 0 until bannerCount) {
            val sx = (bannerX[b] - camX) * zoom + halfW
            val sy = ((bannerY[b] - camY) * WorldConfig.Y_TILT - bannerZ[b] * WorldConfig.Z_LIFT) * zoom + halfH
            if (sx < -100f || sx > screenW + 100f || sy < -140f || sy > screenH + 140f) continue

            val stepX = 5.5f * zoom
            val stepY = 6.8f * zoom
            val topY = sy - 76f * zoom

            // Horizontal crossbar pole
            asciiPaint.color = WorldConfig.COL_STONE_BRIGHT
            for (c in -4..4) {
                charBuf[0] = if (abs(c) == 4) '+' else '='
                canvas.drawText(charBuf, 0, 1, sx + c * stepX, topY, asciiPaint)
            }

            // Vertical swaying crimson cloth rows with notched swallowtail bottom (v3_12.png)
            for (r in 1..11) {
                val windShift = sin(time * 3.2f + r * 0.45f + b) * (r * 0.42f) * zoom
                val ry = topY + r * stepY
                for (c in -3..3) {
                    // Swallowtail notch at bottom rows
                    if (r >= 9 && abs(c) <= (r - 8)) continue
                    charBuf[0] = if (abs(c) == 3) 'Q' else if ((r + c) % 2 == 0) '0' else '#'
                    asciiPaint.color = if (c <= 0) WorldConfig.COL_BANNER_CRIMSON else WorldConfig.COL_BANNER_DARK
                    canvas.drawText(charBuf, 0, 1, sx + c * stepX + windShift, ry, asciiPaint)
                }
            }
        }

        // 3. Draw Hanging Iron Gallows Lanterns (Video 3 00:18 - 00:22)
        for (l in 0 until lanternCount) {
            val sx = (lanternX[l] - camX) * zoom + halfW
            val sy = ((lanternY[l] - camY) * WorldConfig.Y_TILT - lanternZ[l] * WorldConfig.Z_LIFT) * zoom + halfH
            if (sx < -80f || sx > screenW + 80f || sy < -120f || sy > screenH + 120f) continue

            val stepY = 6.5f * zoom
            asciiPaint.color = WorldConfig.COL_LANTERN_GOLD
            for (r in 0..8) {
                charBuf[0] = if (r == 8) 'Q' else '|'
                canvas.drawText(charBuf, 0, 1, sx, sy - r * stepY, asciiPaint)
            }
            // Top horizontal arm
            for (c in 0..4) {
                charBuf[0] = '='
                canvas.drawText(charBuf, 0, 1, sx + c * 5.2f * zoom, sy - 8 * stepY, asciiPaint)
            }
            // Hanging lantern cage with warm glow
            val lx = sx + 20f * zoom + sin(time * 2.8f + l) * 2.2f * zoom
            val ly = sy - 6.2f * stepY
            glowPaint.color = 0x33FF8820
            canvas.drawCircle(lx, ly, 18f * zoom, glowPaint)
            asciiPaint.color = WorldConfig.COL_SWORD_CORE
            charBuf[0] = '@'
            canvas.drawText(charBuf, 0, 1, lx, ly, asciiPaint)
        }

        // 4. Draw Towering 2.5D ASCII Trees (Video 3 00:00 - 00:06)
        for (t in 0 until treeCount) {
            val wx = treeX[t]
            val wy = treeY[t]
            val wz = treeZ[t]
            val sx = (wx - camX) * zoom + halfW
            val sy = ((wy - camY) * WorldConfig.Y_TILT - wz * WorldConfig.Z_LIFT) * zoom + halfH
            if (sx < -140f || sx > screenW + 140f || sy < -180f || sy > screenH + 180f) continue

            val scale = treeScale[t] * zoom
            val dSword = WorldConfig.dist(wx, wy, swordLightX, swordLightY)
            val ember = if (dSword < swordLightRadius) (1f - dSword / swordLightRadius) * 0.75f else 0f

            // Vertical ASCII bark trunk (H, #, |, Q)
            val stepX = 6.2f * scale
            val stepY = 7.2f * scale
            for (r in 0..7) {
                val ry = sy - r * stepY
                for (c in -1..1) {
                    charBuf[0] = if (c == 0) '#' else '|'
                    asciiPaint.color = WorldConfig.applyDynamicLight(WorldConfig.COL_TREE_TRUNK, 0.9f, ember, 0f)
                    canvas.drawText(charBuf, 0, 1, sx + c * stepX, ry, asciiPaint)
                }
            }

            // Layered cyan-sage ASCII foliage canopy (@, Q, 0, O, %, &, *) swaying in the wind (v3_01.png)
            val canopyCenterY = sy - 9.5f * stepY
            val sway = sin(time * 2.1f + t * 0.9f) * 4.2f * scale
            for (ryIdx in -4..3) {
                val rowSpan = (5 - abs(ryIdx)).coerceAtLeast(2)
                val py = canopyCenterY + ryIdx * stepY
                for (cxIdx in -rowSpan..rowSpan) {
                    val h = WorldConfig.hash2D(t * 31 + cxIdx, ryIdx * 17)
                    if ((h % 10) < 2) continue
                    val px = sx + cxIdx * stepX * 1.15f + sway * (1f - ryIdx * 0.1f)
                    charBuf[0] = when (h % 5) {
                        0 -> 'Q'
                        1 -> '@'
                        2 -> '0'
                        3 -> '%'
                        else -> '&'
                    }
                    val folCol = when {
                        ryIdx < -1 -> WorldConfig.COL_TREE_FOLIAGE_BRIGHT
                        ryIdx <= 1 -> WorldConfig.COL_TREE_FOLIAGE_MID
                        else -> WorldConfig.COL_TREE_FOLIAGE_DARK
                    }
                    asciiPaint.color = WorldConfig.applyDynamicLight(folCol, 0.96f, ember, 0f)
                    canvas.drawText(charBuf, 0, 1, px, py, asciiPaint)
                }
            }
        }
    }
}
