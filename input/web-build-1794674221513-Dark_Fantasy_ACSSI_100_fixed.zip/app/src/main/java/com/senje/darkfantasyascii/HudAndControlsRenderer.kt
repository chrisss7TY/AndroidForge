package com.senje.darkfantasyascii

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface

/**
 * Renders the exact bottom HUD bar from Video 1 (1000461713.mp4):
 * - Segmented golden-amber XP/Stamina progress bar ("LV 25  -  5023 / 6000 XP")
 * - 10-slot numbered hotbar (1..9, 0) with interactive touch triggers for:
 *   [1] Flame Sword Slash
 *   [2] Mount / Dismount White ASCII Horse
 *   [3] Camera Zoom Cycle (Close-Up Chainmail / Mid Tactical / Wide Tower Overview)
 *   [4] Zone Fast-Travel (Meadow -> River & Tower -> Tower High Ground Roof -> Citadel Bridges)
 *   [5] Ember Aura Boost
 * - Floating responsive virtual joystick on left touch-drag + subtle zone indicator.
 */
class HudAndControlsRenderer {

    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private val hudTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }

    private val hudSmallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        textAlign = Paint.Align.CENTER
    }

    private val hotbarRect = RectF()
    private val slotLabels = arrayOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
    private val slotIcons = arrayOf("/*\\", "@Q~", "[+]", "^^^", "***", " . ", " . ", " . ", " . ", " . ")
    private val slotSubtitles = arrayOf("SLASH", "HORSE", "ZOOM", "ZONE", "FLAME", "", "", "", "", "")

    fun drawHud(
        canvas: Canvas,
        screenW: Int,
        screenH: Int,
        xpValue: Int,
        xpMax: Int,
        level: Int,
        isMounted: Boolean,
        zoomIndex: Int,
        zoneName: String,
        flameBoost: Boolean,
        joyActive: Boolean,
        joyOriginX: Float,
        joyOriginY: Float,
        joyCurX: Float,
        joyCurY: Float
    ) {
        val w = screenW.toFloat()
        val h = screenH.toFloat()

        // Top subtle atmospheric zone caption (matches the clean video title placement)
        hudSmallPaint.textSize = (w * 0.028f).coerceIn(20f, 32f)
        hudSmallPaint.color = 0x99C4D0DC.toInt()
        canvas.drawText(zoneName, w * 0.5f, h * 0.048f, hudSmallPaint)

        // Floating Virtual Joystick on Left Side when dragging
        if (joyActive) {
            borderPaint.color = 0x668CA0B5
            borderPaint.strokeWidth = 2.5f
            canvas.drawCircle(joyOriginX, joyOriginY, 64f, borderPaint)
            boxPaint.color = 0x88D99B4E.toInt()
            canvas.drawCircle(joyCurX, joyCurY, 26f, boxPaint)
        }

        // Bottom HUD Container matching v1_01.png (centered at bottom of screen)
        val barWidth = (w * 0.88f).coerceAtMost(920f)
        val barLeft = (w - barWidth) * 0.5f
        val barRight = barLeft + barWidth
        val slotW = barWidth / 10f
        val slotH = (slotW * 0.92f).coerceIn(52f, 84f)
        val xpBarH = (slotH * 0.28f).coerceAtLeast(18f)

        val bottomMargin = (h * 0.022f).coerceAtLeast(16f)
        val slotsBottom = h - bottomMargin
        val slotsTop = slotsBottom - slotH
        val xpTop = slotsTop - xpBarH - 3f

        hotbarRect.set(barLeft, xpTop, barRight, slotsBottom)

        // Dark terminal panel background
        boxPaint.color = 0xE606080C.toInt()
        canvas.drawRect(barLeft, xpTop, barRight, slotsBottom, boxPaint)

        // Outer metallic grey frame
        borderPaint.color = 0xFF7D8894.toInt()
        borderPaint.strokeWidth = 2f
        canvas.drawRect(barLeft, xpTop, barRight, slotsBottom, borderPaint)

        // 1. Top XP / Stamina Segmented Golden Bar ("||||||||||||||||||||   LV 25 - 5023 / 6000 XP")
        canvas.drawLine(barLeft, slotsTop, barRight, slotsTop, borderPaint)
        val xpRatio = (xpValue.toFloat() / xpMax.toFloat()).coerceIn(0f, 1f)
        val totalTicks = 56
        val filledTicks = (totalTicks * xpRatio).toInt()
        val tickSpacing = (barWidth - 16f) / totalTicks

        boxPaint.color = 0xFFD99F38.toInt()
        for (t in 0 until filledTicks) {
            val tx = barLeft + 8f + t * tickSpacing
            canvas.drawRect(tx, xpTop + 4f, tx + tickSpacing * 0.62f, slotsTop - 4f, boxPaint)
        }

        // Centered XP label with dark backing for readability
        hudTextPaint.textSize = (xpBarH * 0.68f).coerceIn(11f, 19f)
        val xpText = "LV $level  ·  $xpValue / $xpMax XP"
        boxPaint.color = 0xCC06080C.toInt()
        val textHalfW = hudTextPaint.measureText(xpText) * 0.55f
        canvas.drawRect(w * 0.5f - textHalfW, xpTop + 2f, w * 0.5f + textHalfW, slotsTop - 2f, boxPaint)
        hudTextPaint.color = 0xFFDCE6F0.toInt()
        canvas.drawText(xpText, w * 0.5f, slotsTop - xpBarH * 0.24f, hudTextPaint)

        // 2. 10-Slot Numbered Hotbar (1 through 0)
        val headerRowH = slotH * 0.28f
        canvas.drawLine(barLeft, slotsTop + headerRowH, barRight, slotsTop + headerRowH, borderPaint)

        for (s in 0 until 10) {
            val sLeft = barLeft + s * slotW
            val sRight = sLeft + slotW
            val sCenterX = sLeft + slotW * 0.5f

            if (s > 0) {
                canvas.drawLine(sLeft, slotsTop, sLeft, slotsBottom, borderPaint)
            }

            // Highlight active toggles (Horse mounted on slot 2, Flame Boost on slot 5)
            val isHighlighted = (s == 0) || (s == 1 && isMounted) || (s == 4 && flameBoost)
            if (isHighlighted) {
                boxPaint.color = if (s == 0) 0x33B83622 else 0x33D99B4E
                canvas.drawRect(sLeft + 2f, slotsTop + headerRowH + 2f, sRight - 2f, slotsBottom - 2f, boxPaint)
            }

            // Slot number (1..9, 0)
            hudTextPaint.textSize = (headerRowH * 0.76f).coerceIn(11f, 18f)
            hudTextPaint.color = 0xFFC8D2DC.toInt()
            canvas.drawText(slotLabels[s], sCenterX, slotsTop + headerRowH * 0.78f, hudTextPaint)

            // ASCII mini-icon inside slot
            hudTextPaint.textSize = (slotH * 0.24f).coerceIn(12f, 22f)
            hudTextPaint.color = when (s) {
                0 -> WorldConfig.COL_SWORD_FLAME
                1 -> if (isMounted) WorldConfig.COL_SWORD_CORE else WorldConfig.COL_MAIL_SILVER
                2, 3 -> 0xFF9AB4CC.toInt()
                4 -> if (flameBoost) WorldConfig.COL_SWORD_CORE else WorldConfig.COL_SWORD_EMBER
                else -> 0xFF55606E.toInt()
            }
            canvas.drawText(slotIcons[s], sCenterX, slotsTop + headerRowH + (slotH - headerRowH) * 0.48f, hudTextPaint)

            // Action subtitle on slots 1..5
            if (slotSubtitles[s].isNotEmpty()) {
                hudSmallPaint.textSize = (slotH * 0.14f).coerceIn(8.5f, 13f)
                hudSmallPaint.color = 0xFF8896A6.toInt()
                val sub = if (s == 2) "Z:${zoomIndex + 1}" else slotSubtitles[s]
                canvas.drawText(sub, sCenterX, slotsBottom - 5f, hudSmallPaint)
            }
        }
    }

    /**
     * Returns hotbar slot index (0..9) if (x, y) tapped inside the bottom hotbar, or -1 otherwise.
     */
    fun hitTestHotbarSlot(x: Float, y: Float, screenW: Int, screenH: Int): Int {
        if (!hotbarRect.contains(x, y)) return -1
        val slotW = hotbarRect.width() / 10f
        val idx = ((x - hotbarRect.left) / slotW).toInt()
        return idx.coerceIn(0, 9)
    }
}
