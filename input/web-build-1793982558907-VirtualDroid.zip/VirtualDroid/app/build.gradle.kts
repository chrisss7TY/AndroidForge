plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Set from CI: -PversionCode=12 -PversionName=1.0.12
val vCode = (findProperty("versionCode") as String?)?.toInt() ?: 1
val vName = (findProperty("versionName") as String?) ?: "1.0.0"
val updateRepo = (findProperty("updateRepo") as String?) ?: "YOUR_GITHUB_USER/VirtualDroid"

android {
    namespace = "com.virtualdroid.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.virtualdroid.app"
        minSdk = 26
        targetSdk = 30 // sandbox engines need targetSdk <= 30 for legacy storage/package visibility behavior
        versionCode = vCode
        versionName = vName
        buildConfigField("String", "UPDATE_REPO", "\"$updateRepo\"")
    }

    signingConfigs {
        create("release") {
            // CI supplies these via env vars from repository secrets. Keep the SAME key forever,
            // otherwise Android will refuse to install updates over the old version.
            val ks = System.getenv("KEYSTORE_PATH")
            if (ks != null) {
                storeFile = file(ks)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = if (System.getenv("KEYSTORE_PATH") != null)
                signingConfigs.getByName("release") else signingConfigs.getByName("debug")
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.3")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
