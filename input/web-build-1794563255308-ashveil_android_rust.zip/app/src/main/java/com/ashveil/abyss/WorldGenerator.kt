package com.ashveil.abyss

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Minecraft-style deterministic seeded procedural chunk & biome generator for ASHVEIL.
 * Generates infinite 16x16 world chunks from a 64-bit seed with zero per-frame allocations.
 */
object WorldGenerator {

    const val CHUNK_SIZE = 16.0f
    const val ACTIVE_GRID_RADIUS = 3 // 7x7 chunks active around player (49 chunks cached)
    const val GRID_DIM = ACTIVE_GRID_RADIUS * 2 + 1
    const val MAX_CACHED_CHUNKS = GRID_DIM * GRID_DIM

    // World Types (Minecraft-like generator presets)
    val WORLD_TYPE_NAMES = arrayOf(
        "Standard Realm",
        "Amplified Crags",
        "Elderwood Forest",
        "Moonlit Basin"
    )

    val GAME_MODE_NAMES = arrayOf(
        "Survival RPG",
        "Hardcore Abyss",
        "Creative Sandbox"
    )

    val PRESET_WORLD_NAMES = arrayOf(
        "Ashveil Wilds",
        "Senje's Hollow",
        "Moonlit Sanctuary",
        "Obsidian Reach",
        "Whispering Crags",
        "Elderwood Vale",
        "Nightglass Fen",
        "Bloodiron Gorge"
    )

    val PRESET_SEEDS = longArrayOf(
        -4918273645L, // Classic Senje Canyon + Moonlit Cave + Winding River
        77283910421L, // Twin Rivers & Dense Wildflower Meadow
        -9012847561L, // Towering Obsidian Pillars & Deep Cave
        13374206999L  // Ancient Runic Forest & Glowing Shrines
    )

    val PRESET_SEED_LABELS = arrayOf(
        "Senje Canyon (-4918273645)",
        "Twin Rivers (77283910421)",
        "Obsidian Pillars (-9012847561)",
        "Elderwood Shrines (13374206999)"
    )

    class PropInstance(
        var x: Float = 0f,
        var y: Float = 0f,
        var z: Float = 0f,
        var radiusX: Float = 1f,
        var heightY: Float = 1f,
        var radiusZ: Float = 1f,
        var variant: Int = 0
    )

    class WorldChunk {
        var chunkX: Int = Int.MIN_VALUE
        var chunkZ: Int = Int.MIN_VALUE
        var builtSeed: Long = Long.MIN_VALUE
        var builtType: Int = -1
        var biomeId: Int = 0 // 0=Emerald Meadow, 1=Dense Forest, 2=Rocky Crags, 3=Moonlit Cave

        var rockCount: Int = 0
        val rocks = Array(10) { PropInstance() }

        var treeCount: Int = 0
        val trees = Array(8) { PropInstance() }

        var crystalCount: Int = 0
        val crystals = Array(6) { PropInstance() }

        var hasShrine: Boolean = false
        var shrineX: Float = 0f
        var shrineY: Float = 0f
        var shrineZ: Float = 0f
    }

    val chunkGrid = Array(MAX_CACHED_CHUNKS) { WorldChunk() }
    private var lastCenterChunkX = Int.MIN_VALUE
    private var lastCenterChunkZ = Int.MIN_VALUE
    private var lastSeed = Long.MIN_VALUE
    private var lastWorldType = -1

    fun splitMix64(x: Long): Long {
        var z = x + -0x61c8864680b583ebL
        z = (z xor (z ushr 30)) * -0x40a7b892e31b1a47L
        z = (z xor (z ushr 27)) * -0x6b2fb644ecceee15L
        return z xor (z ushr 31)
    }

    fun hashCoords(cx: Int, cz: Int, seed: Long, salt: Long): Long {
        val h = seed xor (cx.toLong() * 341873128712L) xor (cz.toLong() * 132897987541L) xor salt
        return splitMix64(h)
    }

    fun randFloat01(h: Long): Float {
        return ((h ushr 40) and 0xFFFFFFL).toFloat() / 16777216.0f
    }

    private fun hash2D(ix: Int, iz: Int, seed: Long): Float {
        val n = ix.toLong() * 374761393L + iz.toLong() * 668265263L + (seed and 0x7FFFFFFFL) * 1442695041L
        val m = (n xor (n ushr 13)) * 1274126177L
        return ((m xor (m ushr 16)) and 0x7FFFFFL).toFloat() / 8388608.0f
    }

    fun valueNoise2D(x: Float, z: Float, seed: Long): Float {
        val ix = floor(x).toInt()
        val iz = floor(z).toInt()
        val fx = x - ix
        val fz = z - iz
        val ux = fx * fx * (3.0f - 2.0f * fx)
        val uz = fz * fz * (3.0f - 2.0f * fz)

        val a = hash2D(ix, iz, seed)
        val b = hash2D(ix + 1, iz, seed)
        val c = hash2D(ix, iz + 1, seed)
        val d = hash2D(ix + 1, iz + 1, seed)

        val ab = a + (b - a) * ux
        val cd = c + (d - c) * ux
        return ab + (cd - ab) * uz
    }

    fun fbm2D(x: Float, z: Float, seed: Long): Float {
        var v = 0.0f
        var amp = 0.5f
        var px = x
        var pz = z
        for (i in 0 until 3) {
            v += valueNoise2D(px, pz, seed + i * 997L) * amp
            px *= 2.03f
            pz *= 2.03f
            amp *= 0.5f
        }
        return v
    }

    fun riverCenterZ(wx: Float, seed: Long, worldType: Int): Float {
        val phase = ((seed and 0xFFFFL).toFloat() / 65535.0f) * 6.28318f
        val amp = if (worldType == 3) 3.4f else 2.2f
        return -6.5f + sin(wx * 0.13f + phase) * amp + cos(wx * 0.055f - phase * 0.5f) * 1.35f
    }

    fun riverHalfWidth(worldType: Int, genRivers: Boolean): Float {
        if (!genRivers) return 0.0f
        return if (worldType == 3) 3.5f else 2.55f
    }

    fun isInsideRiver(wx: Float, wz: Float, seed: Long, worldType: Int, genRivers: Boolean): Boolean {
        if (!genRivers) return false
        val rz = riverCenterZ(wx, seed, worldType)
        return abs(wz - rz) < riverHalfWidth(worldType, genRivers)
    }

    fun isInsideMoonlitCave(wx: Float, wz: Float, seed: Long, genCaves: Boolean): Boolean {
        if (!genCaves) return false
        // Primary Moonlit Cave Sanctuary north of spawn (matches `1000461481.jpg`)
        val dx0 = wx - 0.0f
        val dz0 = wz - (-18.5f)
        if (dx0 * dx0 + dz0 * dz0 < 10.5f * 10.5f) return true

        // Procedural regional caves every 64 units in distant regions
        val regX = floor((wx + 32.0f) / 64.0f).toInt()
        val regZ = floor((wz + 32.0f) / 64.0f).toInt()
        if (regX == 0 && regZ == 0) return false
        val h = hashCoords(regX, regZ, seed, 0xCA7E5L)
        if ((h and 3L) == 0L) {
            val cx = regX * 64.0f + (randFloat01(h) - 0.5f) * 24.0f
            val cz = regZ * 64.0f + (randFloat01(splitMix64(h)) - 0.5f) * 24.0f
            val dx = wx - cx
            val dz = wz - cz
            if (dx * dx + dz * dz < 10.0f * 10.0f) return true
        }
        return false
    }

    /**
     * Deterministic terrain elevation at (wx, wz).
     * Flat near the river and spawn sanctuary so planar water reflections stay razor-sharp,
     * with gentle rolling elevation in outer forest/crag chunks.
     */
    fun getTerrainHeight(wx: Float, wz: Float, seed: Long, worldType: Int, genRivers: Boolean): Float {
        if (genRivers) {
            val distRiver = abs(wz - riverCenterZ(wx, seed, worldType))
            if (distRiver < 5.2f) {
                return 0.0f
            }
        }
        val distSpawn = sqrt(wx * wx + (wz - 4.0f) * (wz - 4.0f))
        val spawnFlatten = min(1.0f, max(0.0f, (distSpawn - 9.0f) / 10.0f))
        if (spawnFlatten <= 0.001f) return 0.0f

        val n = fbm2D(wx * 0.045f, wz * 0.045f, seed) - 0.42f
        val scale = when (worldType) {
            1 -> 1.65f // Amplified Crags
            2 -> 0.75f // Elderwood Forest
            3 -> 0.45f // Moonlit Basin
            else -> 0.95f
        }
        return max(0.0f, n * scale * spawnFlatten)
    }

    fun getBiomeAt(wx: Float, wz: Float, seed: Long, worldType: Int, genCaves: Boolean): Int {
        if (isInsideMoonlitCave(wx, wz, seed, genCaves)) return 3
        val m = valueNoise2D(wx * 0.03f + 17.3f, wz * 0.03f - 9.1f, seed)
        return when (worldType) {
            1 -> if (m > 0.45f) 2 else 0
            2 -> if (m > 0.30f) 1 else 0
            else -> when {
                m > 0.66f -> 2 // Rocky Crags
                m > 0.38f -> 1 // Whispering Forest
                else -> 0      // Emerald Wildflower Meadow
            }
        }
    }

    fun getBiomeName(biomeId: Int): String = when (biomeId) {
        1 -> "Whispering Forest"
        2 -> "Obsidian Crags"
        3 -> "Moonlit Cave"
        else -> "Emerald Meadow"
    }

    fun ensureChunksAroundPlayer(
        playerX: Float,
        playerZ: Float,
        seed: Long,
        worldType: Int,
        genCaves: Boolean,
        genRivers: Boolean,
        genShrines: Boolean
    ) {
        val pcx = floor(playerX / CHUNK_SIZE).toInt()
        val pcz = floor(playerZ / CHUNK_SIZE).toInt()
        if (pcx == lastCenterChunkX && pcz == lastCenterChunkZ && seed == lastSeed && worldType == lastWorldType) {
            return
        }
        lastCenterChunkX = pcx
        lastCenterChunkZ = pcz
        lastSeed = seed
        lastWorldType = worldType

        var slot = 0
        for (dz in -ACTIVE_GRID_RADIUS..ACTIVE_GRID_RADIUS) {
            for (dx in -ACTIVE_GRID_RADIUS..ACTIVE_GRID_RADIUS) {
                val cx = pcx + dx
                val cz = pcz + dz
                val chunk = chunkGrid[slot++]
                if (chunk.chunkX != cx || chunk.chunkZ != cz || chunk.builtSeed != seed || chunk.builtType != worldType) {
                    populateChunk(chunk, cx, cz, seed, worldType, genCaves, genRivers, genShrines)
                }
            }
        }
    }

    fun forceRebuildAllChunks() {
        lastSeed = Long.MIN_VALUE
        for (c in chunkGrid) {
            c.builtSeed = Long.MIN_VALUE
        }
    }

    private fun populateChunk(
        chunk: WorldChunk,
        cx: Int,
        cz: Int,
        seed: Long,
        worldType: Int,
        genCaves: Boolean,
        genRivers: Boolean,
        genShrines: Boolean
    ) {
        chunk.chunkX = cx
        chunk.chunkZ = cz
        chunk.builtSeed = seed
        chunk.builtType = worldType
        chunk.rockCount = 0
        chunk.treeCount = 0
        chunk.crystalCount = 0
        chunk.hasShrine = false

        val baseX = cx * CHUNK_SIZE
        val baseZ = cz * CHUNK_SIZE
        val centerX = baseX + CHUNK_SIZE * 0.5f
        val centerZ = baseZ + CHUNK_SIZE * 0.5f
        chunk.biomeId = getBiomeAt(centerX, centerZ, seed, worldType, genCaves)

        // Origin Sanctuary & Canyon Layout around Spawn (cx in -1..0, cz in -2..0)
        // Guarantees the iconic canyon cliffs, foreground twin boulders, and Moonlit Cave archway from the reference images!
        if (cx == -1 && cz == 0) {
            addRock(chunk, -5.2f, 1.5f, 2.2f, 5.8f, 2.4f, seed, worldType, genRivers)
            addRock(chunk, -5.6f, 4.2f, 2.5f, 6.4f, 2.6f, seed, worldType, genRivers)
            addRock(chunk, -5.0f, 6.8f, 2.1f, 5.2f, 2.2f, seed, worldType, genRivers)
            addRock(chunk, -1.8f, 8.2f, 1.85f, 2.2f, 1.45f, seed, worldType, genRivers)
            addTree(chunk, -8.2f, 5.5f, 3.8f, 2.3f, seed, worldType, genRivers)
            addTree(chunk, -6.8f, 10.5f, 3.9f, 2.4f, seed, worldType, genRivers)
            return
        }
        if (cx == 0 && cz == 0) {
            addRock(chunk, 4.6f, 0.8f, 2.3f, 6.2f, 2.3f, seed, worldType, genRivers)
            addRock(chunk, 5.2f, 3.4f, 2.6f, 5.8f, 2.5f, seed, worldType, genRivers)
            addRock(chunk, 7.2f, 4.8f, 2.8f, 5.4f, 2.6f, seed, worldType, genRivers)
            addRock(chunk, 3.0f, 7.8f, 1.65f, 2.0f, 1.35f, seed, worldType, genRivers)
            addTree(chunk, 9.2f, 7.5f, 3.7f, 2.2f, seed, worldType, genRivers)
            addTree(chunk, 6.4f, 10.8f, 3.8f, 2.3f, seed, worldType, genRivers)
            if (genShrines) {
                chunk.hasShrine = true
                chunk.shrineX = 9.8f
                chunk.shrineZ = 2.4f
                chunk.shrineY = getTerrainHeight(9.8f, 2.4f, seed, worldType, genRivers)
            }
            return
        }
        if (cx == -1 && cz == -1) {
            addRock(chunk, -3.2f, -2.5f, 2.8f, 5.5f, 2.4f, seed, worldType, genRivers)
            addRock(chunk, -3.8f, -11.5f, 2.6f, 7.2f, 2.6f, seed, worldType, genRivers)
            addRock(chunk, -5.5f, -15.0f, 3.2f, 8.0f, 3.2f, seed, worldType, genRivers)
            addTree(chunk, -8.8f, -1.5f, 4.1f, 2.5f, seed, worldType, genRivers)
            if (genCaves) {
                addCrystal(chunk, -2.6f, -14.2f, 0.45f, 1.45f, 0, seed, worldType, genRivers)
                addCrystal(chunk, -1.4f, -15.5f, 0.38f, 1.20f, 1, seed, worldType, genRivers)
            }
            return
        }
        if (cx == 0 && cz == -1) {
            addRock(chunk, 3.8f, -11.5f, 2.6f, 7.2f, 2.6f, seed, worldType, genRivers)
            addRock(chunk, 5.5f, -15.0f, 3.2f, 8.0f, 3.2f, seed, worldType, genRivers)
            addTree(chunk, 8.6f, -1.2f, 3.9f, 2.4f, seed, worldType, genRivers)
            if (genCaves) {
                addCrystal(chunk, 2.5f, -14.0f, 0.45f, 1.50f, 1, seed, worldType, genRivers)
                addCrystal(chunk, 1.2f, -15.6f, 0.36f, 1.15f, 0, seed, worldType, genRivers)
            }
            return
        }

        // Procedural Minecraft-Style Seeded Chunk Population for all other chunks
        var h = hashCoords(cx, cz, seed, 0x9E3779B97F4A7C15UL.toLong())

        val targetRocks = when (worldType) {
            1 -> 4 + (abs(h.toInt()) % 4) // Amplified Crags: more towering ASCII pillars
            2 -> 1 + (abs(h.toInt()) % 3) // Elderwood: fewer rocks, more trees
            else -> 2 + (abs(h.toInt()) % 3)
        }

        val targetTrees = when (worldType) {
            1 -> 1 + (abs((h ushr 8).toInt()) % 2)
            2 -> 4 + (abs((h ushr 8).toInt()) % 4) // Elderwood: lush dense trees
            else -> 2 + (abs((h ushr 8).toInt()) % 3)
        }

        // 1. Place Ground-Anchored ASCII Rock Formations / Cliff Pillars
        for (i in 0 until targetRocks) {
            h = splitMix64(h)
            val rx = baseX + 2.2f + randFloat01(h) * (CHUNK_SIZE - 4.4f)
            h = splitMix64(h)
            val rz = baseZ + 2.2f + randFloat01(h) * (CHUNK_SIZE - 4.4f)
            if (isInsideRiver(rx, rz, seed, worldType, genRivers)) continue
            if (isTooCloseToExisting(chunk, rx, rz, 3.4f)) continue

            h = splitMix64(h)
            val isTallPillar = (randFloat01(h) < (if (worldType == 1) 0.72f else 0.48f))
            val radX = if (isTallPillar) (1.8f + randFloat01(splitMix64(h)) * 1.1f) else (1.4f + randFloat01(splitMix64(h)) * 0.8f)
            val heightY = if (isTallPillar) (4.8f + randFloat01(splitMix64(h xor 7L)) * 3.4f) else (1.7f + randFloat01(splitMix64(h xor 13L)) * 1.1f)
            val radZ = radX * (0.85f + randFloat01(splitMix64(h xor 29L)) * 0.3f)
            addRock(chunk, rx, rz, radX, heightY, radZ, seed, worldType, genRivers)
        }

        // 2. Place Ground-Anchored Ancient Forest Trees
        if (chunk.biomeId != 3) {
            for (i in 0 until targetTrees) {
                h = splitMix64(h)
                val tx = baseX + 2.0f + randFloat01(h) * (CHUNK_SIZE - 4.0f)
                h = splitMix64(h)
                val tz = baseZ + 2.0f + randFloat01(h) * (CHUNK_SIZE - 4.0f)
                if (isInsideRiver(tx, tz, seed, worldType, genRivers)) continue
                if (isInsideMoonlitCave(tx, tz, seed, genCaves)) continue
                if (isTooCloseToExisting(chunk, tx, tz, 3.0f)) continue

                h = splitMix64(h)
                val trunkH = 3.3f + randFloat01(h) * 1.3f
                val canopyR = 2.0f + randFloat01(splitMix64(h)) * 0.8f
                addTree(chunk, tx, tz, trunkH, canopyR, seed, worldType, genRivers)
            }
        }

        // 3. Place Bioluminescent Cave Crystals in Cave / Crag Chunks
        if (genCaves && (chunk.biomeId == 3 || chunk.biomeId == 2)) {
            val numCrystals = if (chunk.biomeId == 3) 4 else 2
            for (i in 0 until numCrystals) {
                h = splitMix64(h)
                val gx = baseX + 2.5f + randFloat01(h) * (CHUNK_SIZE - 5.0f)
                h = splitMix64(h)
                val gz = baseZ + 2.5f + randFloat01(h) * (CHUNK_SIZE - 5.0f)
                if (isInsideRiver(gx, gz, seed, worldType, genRivers)) continue
                if (isTooCloseToExisting(chunk, gx, gz, 1.8f)) continue
                val cH = 1.0f + randFloat01(splitMix64(h)) * 0.7f
                addCrystal(chunk, gx, gz, 0.38f, cH, i and 1, seed, worldType, genRivers)
            }
        }

        // 4. Place Ancient Runic Shrine in ~18% of outer chunks
        h = splitMix64(h)
        if (genShrines && randFloat01(h) < 0.18f) {
            val sx = baseX + CHUNK_SIZE * 0.5f
            val sz = baseZ + CHUNK_SIZE * 0.5f
            if (!isInsideRiver(sx, sz, seed, worldType, genRivers) && !isTooCloseToExisting(chunk, sx, sz, 2.8f)) {
                chunk.hasShrine = true
                chunk.shrineX = sx
                chunk.shrineZ = sz
                chunk.shrineY = getTerrainHeight(sx, sz, seed, worldType, genRivers)
            }
        }
    }

    private fun isTooCloseToExisting(chunk: WorldChunk, x: Float, z: Float, minDist: Float): Boolean {
        val minD2 = minDist * minDist
        for (i in 0 until chunk.rockCount) {
            val r = chunk.rocks[i]
            val dx = x - r.x
            val dz = z - r.z
            if (dx * dx + dz * dz < minD2) return true
        }
        for (i in 0 until chunk.treeCount) {
            val t = chunk.trees[i]
            val dx = x - t.x
            val dz = z - t.z
            if (dx * dx + dz * dz < minD2) return true
        }
        return false
    }

    private fun addRock(
        chunk: WorldChunk,
        x: Float,
        z: Float,
        radX: Float,
        heightY: Float,
        radZ: Float,
        seed: Long,
        worldType: Int,
        genRivers: Boolean
    ) {
        if (chunk.rockCount >= chunk.rocks.size) return
        val p = chunk.rocks[chunk.rockCount++]
        p.x = x
        p.z = z
        p.y = getTerrainHeight(x, z, seed, worldType, genRivers)
        p.radiusX = radX
        p.heightY = heightY
        p.radiusZ = radZ
    }

    private fun addTree(
        chunk: WorldChunk,
        x: Float,
        z: Float,
        trunkH: Float,
        canopyR: Float,
        seed: Long,
        worldType: Int,
        genRivers: Boolean
    ) {
        if (chunk.treeCount >= chunk.trees.size) return
        val p = chunk.trees[chunk.treeCount++]
        p.x = x
        p.z = z
        p.y = getTerrainHeight(x, z, seed, worldType, genRivers)
        p.radiusX = canopyR
        p.heightY = trunkH
        p.radiusZ = canopyR
    }

    private fun addCrystal(
        chunk: WorldChunk,
        x: Float,
        z: Float,
        rad: Float,
        heightY: Float,
        variant: Int,
        seed: Long,
        worldType: Int,
        genRivers: Boolean
    ) {
        if (chunk.crystalCount >= chunk.crystals.size) return
        val p = chunk.crystals[chunk.crystalCount++]
        p.x = x
        p.z = z
        p.y = getTerrainHeight(x, z, seed, worldType, genRivers)
        p.radiusX = rad
        p.heightY = heightY
        p.radiusZ = rad
        p.variant = variant
    }

    fun isBlockedByWorld(wx: Float, wz: Float): Boolean {
        for (cIdx in 0 until MAX_CACHED_CHUNKS) {
            val c = chunkGrid[cIdx]
            if (c.builtSeed == Long.MIN_VALUE) continue
            for (rIdx in 0 until c.rockCount) {
                val rf = c.rocks[rIdx]
                val dx = (wx - rf.x) / (rf.radiusX * 0.54f)
                val dz = (wz - rf.z) / (rf.radiusZ * 0.54f)
                if (dx * dx + dz * dz < 1.0f) return true
            }
            for (tIdx in 0 until c.treeCount) {
                val tr = c.trees[tIdx]
                val dx = wx - tr.x
                val dz = wz - tr.z
                if (dx * dx + dz * dz < 0.62f * 0.62f) return true
            }
        }
        return false
    }
}
