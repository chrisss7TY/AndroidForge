package com.ashveil.abyss;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Seeded, stateless, infinite terrain and structure generator (Minecraft-style).
 *
 * Biomes & Landmarks (Matching All 3 Reference Videos):
 *   1. Emerald Meadow, River & Watchtower Biome (East / Center / North - 1000461713.mp4 & 1000461712.mp4):
 *      - Dense slate-blue 0Q8Qdba ASCII ground matrix under wind-swept GrassFx blades & o*o wildflowers
 *      - Shallow river with shoreline foam & entity reflections
 *      - Massive Overgrown Stone Watchtower ("Tower high ground") just north of spawn (spawnX, spawnY - 9.0f)
 *   2. Dark Abyssal Forest, Ruin Courtyard, Banner Plaza & Citadel Biome (West - 1000461710.mp4):
 *      - Pure pitch-black void ground (rgb(6, 8, 14)) with slate-blue Q08B cobblestone road & courtyard
 *      - Large branching mint-green ASCII forest trees & small ||UQd/o shrubs
 *      - Ancient slate-blue & warm-ochre stone ruin walls, hanging red-orange pennant banners,
 *        amber gallows lantern posts, and flickering ground campfires
 *      - Massive Multi-Tower ASCII Citadel with blazing torch columns & walkable diagonal bridges
 */
final class WorldGen {

    // ---- object kinds -------------------------------------------------------------
    static final int PILLAR = 0;        // tall standing stone monolith
    static final int BOULDER = 1;       // low wide rock cluster
    static final int HOUSE = 2;         // cottage with amber brazier
    static final int SHRINE = 3;        // cyan runestone
    static final int CAVE = 4;          // moonlit cave mouth in a rock face
    static final int WATCHTOWER = 5;    // overgrown stone watchtower ("Tower high ground")
    static final int CITADEL = 6;       // multi-tower ASCII citadel with diagonal bridges
    static final int TREE = 7;          // large branching green ASCII forest tree
    static final int BANNER = 8;        // hanging crimson/orange pennant banner on frame
    static final int LANTERN = 9;       // iron gallows lantern post + ground campfire
    static final int RUIN_WALL = 10;    // ancient stone ruin wall / archway block
    static final int SHRUB = 11;        // small green ASCII bush/shrub (from 1000461710.mp4)

    static final float CELL = 12.0f;

    // ---- thresholds ---------------------------------------------------------------
    static final float SEA_LEVEL = 0.33f;
    static final float DEEP_LEVEL = 0.255f;
    static final float CLIFF_LEVEL = 0.685f;

    static final class Obj {
        int kind;
        float x, y;      // base position (feet) in world units
        float w, h;      // footprint width, visual height (world units)
        int variant;     // stable per-object random number for shape / glyph jitter
        long id;         // stable unique id (for sprite caches)
    }

    final long seed;
    private final int[] perm = new int[512];
    private final float[] ofs = new float[16];

    float spawnX, spawnY;

    private final HashMap<Long, Obj[]> cellCache = new HashMap<Long, Obj[]>();

    WorldGen(long seed) {
        this.seed = seed;
        long s = mix64(seed ^ 0x9E3779B97F4A7C15L);
        int[] p = new int[256];
        for (int i = 0; i < 256; i++) p[i] = i;
        for (int i = 255; i > 0; i--) {
            s = mix64(s + 0x9E3779B97F4A7C15L);
            int j = (int) ((s >>> 33) % (i + 1));
            int t = p[i];
            p[i] = p[j];
            p[j] = t;
        }
        for (int i = 0; i < 512; i++) perm[i] = p[i & 255];
        for (int i = 0; i < ofs.length; i++) {
            s = mix64(s + 0x9E3779B97F4A7C15L);
            ofs[i] = ((s >>> 40) & 0xFFFF) / 8.0f;
        }
        findSpawn();
    }

    // ===============================================================================
    // Noise
    // ===============================================================================

    static long mix64(long z) {
        z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
        z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
        return z ^ (z >>> 31);
    }

    float hash01(int a, int b, int salt) {
        long h = mix64(seed + a * 0x632BE59BD9B4E019L + b * 0x9E3779B97F4A7C15L + salt * 0xD1B54A32D192ED03L);
        return ((h >>> 40) & 0xFFFFFF) / 16777216.0f;
    }

    long hashBits(int a, int b, int salt) {
        return mix64(seed + a * 0x632BE59BD9B4E019L + b * 0x9E3779B97F4A7C15L + salt * 0xD1B54A32D192ED03L);
    }

    private static float fade(float t) {
        return t * t * t * (t * (t * 6.0f - 15.0f) + 10.0f);
    }

    private float grad(int h, float x, float y) {
        switch (h & 7) {
            case 0: return x + y;
            case 1: return x - y;
            case 2: return -x + y;
            case 3: return -x - y;
            case 4: return x;
            case 5: return -x;
            case 6: return y;
            default: return -y;
        }
    }

    float perlin(float x, float y) {
        int xi = (int) Math.floor(x);
        int yi = (int) Math.floor(y);
        float xf = x - xi;
        float yf = y - yi;
        xi &= 255;
        yi &= 255;
        float u = fade(xf);
        float v = fade(yf);
        int aa = perm[perm[xi] + yi];
        int ab = perm[perm[xi] + yi + 1];
        int ba = perm[perm[xi + 1] + yi];
        int bb = perm[perm[xi + 1] + yi + 1];
        float x1 = grad(aa, xf, yf) + u * (grad(ba, xf - 1, yf) - grad(aa, xf, yf));
        float x2 = grad(ab, xf, yf - 1) + u * (grad(bb, xf - 1, yf - 1) - grad(ab, xf, yf - 1));
        return (x1 + v * (x2 - x1)) * 1.4142f;
    }

    float fbm(float x, float y, int octaves, float freq, int field) {
        float sum = 0.0f;
        float amp = 0.5f;
        float norm = 0.0f;
        float ox = ofs[field * 2 & 15];
        float oy = ofs[(field * 2 + 1) & 15];
        for (int o = 0; o < octaves; o++) {
            sum += amp * perlin((x + ox) * freq, (y + oy) * freq);
            norm += amp;
            amp *= 0.5f;
            freq *= 2.03f;
            ox += 17.3f;
            oy += 31.7f;
        }
        return Math.max(0.0f, Math.min(1.0f, 0.5f + 0.5f * sum / norm * 1.35f));
    }

    // ===============================================================================
    // Biomes, Terrain fields & Stone Pathways
    // ===============================================================================

    /**
     * True when (x, y) is in the Dark Abyssal Citadel & Forest Biome (matching 1000461710.mp4),
     * where the ground is pitch-black void with slate-blue stone paths and no GrassFx blades!
     */
    boolean isDarkCitadelBiome(float x, float y) {
        float dx = x - spawnX;
        float dy = y - spawnY;
        if (dx < -3.2f && dx > -28.0f && dy > -18.0f && dy < 12.0f) {
            return true;
        }
        return fbm(x + 300.0f, y - 300.0f, 2, 0.015f, 3) > 0.72f;
    }

    float elevation(float x, float y) {
        return fbm(x, y, 5, 0.018f, 0);
    }

    float moisture(float x, float y) {
        return fbm(x, y, 3, 0.022f, 1);
    }

    /**
     * Returns >0 when (x, y) lies on a cobblestone / flagstone path or courtyard floor
     * (like the forest path & citadel approach in 1000461710.mp4 and tower path in 1000461712.mp4).
     */
    float pathMask(float x, float y) {
        float dx = x - spawnX;
        float dy = y - spawnY;
        // 1. Stone approach path leading into the Watchtower south archway (matching tower_entrance.png)
        if (dy >= -8.8f && dy <= -1.5f) {
            float dist = Math.abs(dx);
            if (dist < 1.15f) return 1.0f - dist / 1.15f;
        }
        // 2. Westward forest-and-ruins road from spawn to the Citadel & Diagonal Bridges (matching 1000461710.mp4)
        if (dx >= -22.0f && dx <= -1.8f) {
            float targetY = -0.22f * Math.max(-14.0f, Math.min(0.0f, dx + 2.0f));
            float dist = Math.abs(dy - targetY);
            if (dist < 1.45f) return 1.0f - dist / 1.45f;
        }
        // 3. North-South forest path in the Dark Forest zone (matching forest_trees.png 00:00-00:03)
        if (dx >= -7.8f && dx <= -5.0f && dy >= -6.0f && dy <= 6.5f) {
            float dist = Math.abs(dx + 6.4f);
            if (dist < 1.35f) return 1.0f - dist / 1.35f;
        }
        // 4. Paved ruin courtyard & banner plaza around (-10.5, -2.8) (matching 00:04-00:20 of 1000461710.mp4)
        float cdx = dx + 10.2f;
        float cdy = dy + 2.6f;
        if (Math.abs(cdx) < 3.6f && Math.abs(cdy) < 3.4f) {
            return 0.92f;
        }
        return 0.0f;
    }

    float waterDepth(float x, float y) {
        return waterFrom(elevation(x, y), x, y);
    }

    private float waterFrom(float e, float x, float y) {
        if (isDarkCitadelBiome(x, y)) return 0.0f;
        // Keep the spawn & watchtower meadow dry
        float sdx = x - spawnX;
        float sdy = y - (spawnY - 4.0f);
        if (sdx * sdx + sdy * sdy < 11.5f * 11.5f) {
            return 0.0f;
        }
        // Scenic shallow stream just east/southeast of spawn (matching 00:01-00:05 of 1000461712.mp4)
        float rdx = (x - (spawnX + 6.8f)) + (float) Math.sin((y - spawnY) * 0.32f) * 1.8f;
        float rdy = y - spawnY;
        if (Math.abs(rdy) < 16.0f && Math.abs(rdx) < 2.2f) {
            float t = 1.0f - Math.abs(rdx) / 2.2f;
            return 0.05f + t * 0.24f;
        }

        float d = 0.0f;
        if (e < SEA_LEVEL) {
            d = (SEA_LEVEL - e) / (SEA_LEVEL - DEEP_LEVEL) * 0.35f + 0.02f;
        }
        float r = Math.abs(perlin((x + ofs[4]) * 0.021f, (y + ofs[5]) * 0.021f)
                + 0.28f * perlin((x + ofs[6]) * 0.07f, (y + ofs[7]) * 0.07f));
        float width = 0.050f;
        if (e < CLIFF_LEVEL - 0.05f && r < width) {
            float t = 1.0f - r / width;
            float rd = 0.05f + t * 0.29f;
            if (rd > d) d = rd;
        }
        return d;
    }

    boolean isWater(float x, float y) {
        return waterDepth(x, y) > 0.0f;
    }

    boolean isDeepWater(float x, float y) {
        return waterDepth(x, y) > 0.36f;
    }

    float cliff(float x, float y) {
        return cliffFrom(elevation(x, y), x, y);
    }

    private float cliffFrom(float e, float x, float y) {
        float detail = perlin((x + ofs[8]) * 0.11f, (y + ofs[9]) * 0.11f) * 0.045f;
        float v = e + detail;
        float dx = x - (spawnX - 5.0f);
        float dy = y - (spawnY - 4.0f);
        float d2 = dx * dx + dy * dy;
        if (d2 < 400.0f) v -= (400.0f - d2) / 400.0f * 0.55f;
        return v;
    }

    void sample(float x, float y, float[] out) {
        float e = elevation(x, y);
        out[0] = cliffFrom(e, x, y);
        out[1] = waterFrom(e, x, y);
        out[2] = moisture(x, y);
    }

    boolean isCliff(float x, float y) {
        return cliff(x, y) > CLIFF_LEVEL;
    }

    boolean terrainBlocked(float x, float y) {
        return isCliff(x, y) || isDeepWater(x, y);
    }

    /**
     * Checks if (x, y) is on a walkable diagonal suspension bridge attached to a Citadel.
     */
    boolean onCitadelBridge(float x, float y) {
        int cx = (int) Math.floor(x / CELL);
        int cy = (int) Math.floor(y / CELL);
        for (int j = -2; j <= 2; j++) {
            for (int i = -2; i <= 2; i++) {
                Obj[] cell = cell(cx + i, cy + j);
                for (int k = 0; k < cell.length; k++) {
                    Obj o = cell[k];
                    if (o.kind != CITADEL) continue;
                    float relX = x - o.x;
                    float relY = y - o.y;
                    if (relX >= -10.5f && relX <= -1.0f) {
                        float by1 = -2.2f + (relX + 1.8f) * 0.42f;
                        if (Math.abs(relY - by1) < 0.95f) return true;
                        float by2 = 0.5f + (relX + 1.8f) * 0.42f;
                        if (Math.abs(relY - by2) < 0.95f) return true;
                    }
                }
            }
        }
        return false;
    }

    boolean blocked(float x, float y) {
        if (onCitadelBridge(x, y)) return false;
        if (terrainBlocked(x, y)) return true;
        int cx = (int) Math.floor(x / CELL);
        int cy = (int) Math.floor(y / CELL);
        for (int j = -2; j <= 2; j++) {
            for (int i = -2; i <= 2; i++) {
                Obj[] cell = cell(cx + i, cy + j);
                for (int k = 0; k < cell.length; k++) {
                    Obj o = cell[k];
                    if (o.kind == CAVE || o.kind == BANNER || o.kind == LANTERN || o.kind == SHRUB) continue;
                    if (o.kind == WATCHTOWER) {
                        float dx = x - o.x;
                        float dy = y - o.y;
                        // South arched doorway is open so the hero can walk inside to ascend!
                        if (Math.abs(dx) < 1.35f && dy > 0.2f && dy < 4.5f) continue;
                        float rx = o.w * 0.43f;
                        float ry = o.w * 0.31f;
                        if ((dx * dx) / (rx * rx) + (dy * dy) / (ry * ry) < 1.0f) return true;
                        continue;
                    }
                    if (o.kind == CITADEL) {
                        float dx = x - o.x;
                        float dy = y - o.y;
                        if (dx < -1.0f && Math.abs(dy) < 3.2f) continue;
                        float rx = o.w * 0.38f;
                        float ry = o.w * 0.28f;
                        if ((dx * dx) / (rx * rx) + (dy * dy) / (ry * ry) < 1.0f) return true;
                        continue;
                    }
                    if (o.kind == TREE) {
                        float dx = x - o.x;
                        float dy = y - o.y;
                        if (dx * dx + dy * dy < 0.55f * 0.55f) return true;
                        continue;
                    }
                    if (o.kind == RUIN_WALL) {
                        float dx = Math.abs(x - o.x);
                        float dy = Math.abs(y - o.y);
                        if (dx < o.w * 0.44f && dy < 0.48f) return true;
                        continue;
                    }
                    float rx = o.w * 0.45f;
                    float ry = (o.kind == HOUSE) ? 0.85f : Math.min(o.w * 0.30f, 0.85f);
                    float dx = (x - o.x) / rx;
                    float dy = (y - o.y) / ry;
                    if (dx * dx + dy * dy < 1.0f) return true;
                }
            }
        }
        return false;
    }

    Obj findWatchtowerNear(float x, float y, float maxDist) {
        int cx = (int) Math.floor(x / CELL);
        int cy = (int) Math.floor(y / CELL);
        for (int j = -2; j <= 2; j++) {
            for (int i = -2; i <= 2; i++) {
                Obj[] cell = cell(cx + i, cy + j);
                for (int k = 0; k < cell.length; k++) {
                    Obj o = cell[k];
                    if (o.kind == WATCHTOWER) {
                        float dx = x - o.x;
                        float dy = y - o.y;
                        if (dx * dx + dy * dy <= maxDist * maxDist) return o;
                    }
                }
            }
        }
        return null;
    }

    float shoreSigned(float x, float y) {
        float d = waterDepth(x, y);
        return d > 0.0f ? d : -1.0f;
    }

    // ===============================================================================
    // Objects (placed per cell from hash(seed, cell) + Spawn Landmark Showcase)
    // ===============================================================================

    private Obj[] cell(int cx, int cy) {
        long key = ((long) cx << 32) ^ (cy & 0xFFFFFFFFL);
        Obj[] got = cellCache.get(key);
        if (got != null) return got;
        if (cellCache.size() > 600) cellCache.clear();
        got = buildCell(cx, cy);
        cellCache.put(key, got);
        return got;
    }

    private Obj make(int kind, float x, float y, float w, float h, int cx, int cy, int idx) {
        Obj o = new Obj();
        o.kind = kind;
        o.x = x;
        o.y = y;
        o.w = w;
        o.h = h;
        long bits = hashBits(cx, cy, 100 + idx);
        o.variant = (int) (bits >>> 20) & 0x7FFFFFFF;
        o.id = bits ^ ((long) kind << 48) ^ (idx * 0x9E3779B9L);
        return o;
    }

    private boolean openGround(float x, float y, float margin) {
        if (isWater(x, y) || isCliff(x, y)) return false;
        float m = margin;
        return !isWater(x + m, y) && !isWater(x - m, y) && !isWater(x, y + m) && !isWater(x, y - m)
                && !isCliff(x + m, y) && !isCliff(x - m, y) && !isCliff(x, y + m) && !isCliff(x - m, y);
    }

    private Obj[] buildCell(int cx, int cy) {
        ArrayList<Obj> list = new ArrayList<Obj>(20);
        float bx = cx * CELL;
        float by = cy * CELL;

        int spawnCx = (int) Math.floor(spawnX / CELL);
        int spawnCy = (int) Math.floor(spawnY / CELL);

        // --- GUARANTEED SIGNATURE LANDMARKS AROUND SPAWN (Matching the 3 Reference Videos) ---
        if (cx == spawnCx && cy == spawnCy) {
            // 1. Massive Overgrown Stone Watchtower ("Tower high ground" from 1000461712.mp4) north of spawn
            list.add(make(WATCHTOWER, spawnX, spawnY - 8.6f, 10.6f, 9.6f, cx, cy, 501));
            // 2. Branching ASCII Forest Trees & Small Shrubs framing the western forest road (1000461710.mp4 00:00-00:03)
            list.add(make(TREE, spawnX - 4.8f, spawnY + 1.8f, 5.8f, 6.6f, cx, cy, 502));
            list.add(make(TREE, spawnX - 8.2f, spawnY + 2.4f, 5.4f, 6.2f, cx, cy, 503));
            list.add(make(SHRUB, spawnX - 4.4f, spawnY + 3.4f, 1.2f, 1.2f, cx, cy, 504));
            list.add(make(SHRUB, spawnX - 7.6f, spawnY + 4.1f, 1.2f, 1.2f, cx, cy, 505));
            list.add(make(SHRUB, spawnX - 5.2f, spawnY - 1.2f, 1.2f, 1.2f, cx, cy, 506));
        } else if (cx == spawnCx - 1 && cy == spawnCy) {
            // West of spawn: Dark Citadel Biome (1000461710.mp4): Forest Trees, Ruin Courtyard, Pennant Banners, Gallows Lanterns & Citadel Bridges!
            list.add(make(TREE, spawnX - 5.0f, spawnY - 2.6f, 5.8f, 6.6f, cx, cy, 600));
            list.add(make(TREE, spawnX - 8.0f, spawnY - 3.2f, 5.4f, 6.2f, cx, cy, 601));
            list.add(make(RUIN_WALL, spawnX - 9.4f, spawnY - 5.2f, 4.0f, 2.6f, cx, cy, 602));
            list.add(make(RUIN_WALL, spawnX - 9.4f, spawnY + 0.4f, 4.0f, 2.6f, cx, cy, 603));
            list.add(make(BANNER, spawnX - 9.2f, spawnY - 2.4f, 1.6f, 3.2f, cx, cy, 604));
            list.add(make(BANNER, spawnX - 11.4f, spawnY - 1.8f, 1.6f, 3.2f, cx, cy, 605));
            list.add(make(BANNER, spawnX - 11.8f, spawnY - 4.4f, 1.6f, 3.2f, cx, cy, 606));
            list.add(make(LANTERN, spawnX - 10.4f, spawnY - 3.8f, 1.4f, 2.8f, cx, cy, 607));
            list.add(make(LANTERN, spawnX - 10.6f, spawnY - 0.8f, 1.4f, 2.8f, cx, cy, 608));
            list.add(make(SHRUB, spawnX - 12.6f, spawnY + 1.2f, 1.2f, 1.2f, cx, cy, 609));
            list.add(make(SHRUB, spawnX - 15.2f, spawnY - 0.6f, 1.2f, 1.2f, cx, cy, 610));
            list.add(make(SHRUB, spawnX - 17.8f, spawnY - 2.2f, 1.2f, 1.2f, cx, cy, 611));
            // Massive Multi-Tower ASCII Citadel with Blazing Torch Columns & Walkable Diagonal Bridges
            list.add(make(CITADEL, spawnX - 14.8f, spawnY - 3.6f, 10.4f, 11.2f, cx, cy, 612));
        }

        // --- PROCEDURAL STRUCTURES & ENVIRONMENT ACROSS ALL WORLD CELLS ---
        float ancient = fbm(bx + CELL * 0.5f, by + CELL * 0.5f, 2, 0.035f, 2);
        float forest = moisture(bx + CELL * 0.5f, by + CELL * 0.5f);

        if ((cx != spawnCx || cy != spawnCy) && (cx != spawnCx - 1 || cy != spawnCy)) {
            if (hash01(cx, cy, 70) > 0.84f) {
                float px = bx + 3.5f + hash01(cx, cy, 71) * (CELL - 7.0f);
                float py = by + 3.5f + hash01(cx, cy, 72) * (CELL - 7.0f);
                if (openGround(px, py, 2.6f) && dist2(px, py, spawnX, spawnY) > 140.0f) {
                    boolean isCitadel = hash01(cx, cy, 73) > 0.55f;
                    list.add(make(isCitadel ? CITADEL : WATCHTOWER, px, py,
                            isCitadel ? 10.4f : 10.6f, isCitadel ? 11.2f : 9.6f, cx, cy, 70));
                }
            }
        }

        // Procedural Branching ASCII Forest Trees
        int nTrees = (forest > 0.54f) ? (1 + (hash01(cx, cy, 80) > 0.45f ? 1 : 0)) : (hash01(cx, cy, 80) > 0.72f ? 1 : 0);
        for (int t = 0; t < nTrees; t++) {
            float px = bx + 1.8f + hash01(cx, cy, 81 + t * 3) * (CELL - 3.6f);
            float py = by + 1.8f + hash01(cx, cy, 82 + t * 3) * (CELL - 3.6f);
            if (!openGround(px, py, 1.4f)) continue;
            if (dist2(px, py, spawnX, spawnY) < 32.0f) continue;
            if (!clearOf(list, px, py, 3.2f)) continue;
            float tw = 5.0f + hash01(cx, cy, 83 + t) * 1.4f;
            float th = 5.8f + hash01(cx, cy, 84 + t) * 1.6f;
            list.add(make(TREE, px, py, tw, th, cx, cy, 80 + t));
        }

        // Procedural Stone Monoliths (PILLAR) and Boulders (BOULDER)
        int nStones = 0;
        float sr = hash01(cx, cy, 1);
        if (ancient > 0.62f) nStones = 1 + (sr > 0.55f ? 1 : 0);
        else if (ancient > 0.48f) nStones = (sr > 0.45f) ? 1 : 0;
        for (int s = 0; s < nStones; s++) {
            float px = bx + 1.5f + hash01(cx, cy, 10 + s * 3) * (CELL - 3.0f);
            float py = by + 1.5f + hash01(cx, cy, 11 + s * 3) * (CELL - 3.0f);
            if (!openGround(px, py, 1.4f)) continue;
            if (dist2(px, py, spawnX, spawnY) < 36.0f) continue;
            if (!clearOf(list, px, py, 2.8f)) continue;
            boolean pillar = hash01(cx, cy, 12 + s * 3) > 0.42f;
            float w = pillar ? 1.9f + hash01(cx, cy, 40 + s) * 1.1f : 2.6f + hash01(cx, cy, 40 + s) * 1.6f;
            float h = pillar ? 4.4f + hash01(cx, cy, 50 + s) * 2.2f : 1.5f + hash01(cx, cy, 50 + s) * 0.9f;
            list.add(make(pillar ? PILLAR : BOULDER, px, py, w, h, cx, cy, s));
        }

        // Procedural Banners, Lanterns & Ruin Walls
        if (hash01(cx, cy, 90) > 0.68f) {
            float px = bx + 2.2f + hash01(cx, cy, 91) * (CELL - 4.4f);
            float py = by + 2.2f + hash01(cx, cy, 92) * (CELL - 4.4f);
            if (openGround(px, py, 1.5f) && dist2(px, py, spawnX, spawnY) > 36.0f && clearOf(list, px, py, 2.4f)) {
                float kindRoll = hash01(cx, cy, 93);
                if (kindRoll < 0.38f) {
                    list.add(make(BANNER, px, py, 1.6f, 3.2f, cx, cy, 90));
                } else if (kindRoll < 0.72f) {
                    list.add(make(LANTERN, px, py, 1.4f, 2.8f, cx, cy, 91));
                } else {
                    list.add(make(RUIN_WALL, px, py, 3.8f, 2.5f, cx, cy, 92));
                }
            }
        }

        return list.toArray(new Obj[0]);
    }

    private static float dist2(float ax, float ay, float bx, float by) {
        float dx = ax - bx;
        float dy = ay - by;
        return dx * dx + dy * dy;
    }

    private static boolean clearOf(ArrayList<Obj> list, float x, float y, float r) {
        for (int i = 0; i < list.size(); i++) {
            Obj o = list.get(i);
            float minR = r + o.w * 0.45f;
            if (dist2(x, y, o.x, o.y) < minR * minR) return false;
        }
        return true;
    }

    void objectsIn(float x0, float y0, float x1, float y1, ArrayList<Obj> out) {
        out.clear();
        int cx0 = (int) Math.floor((x0 - 12.0f) / CELL);
        int cx1 = (int) Math.floor((x1 + 12.0f) / CELL);
        int cy0 = (int) Math.floor((y0 - 12.0f) / CELL);
        int cy1 = (int) Math.floor((y1 + 10.0f) / CELL);
        for (int cy = cy0; cy <= cy1; cy++) {
            for (int cx = cx0; cx <= cx1; cx++) {
                Obj[] cell = cell(cx, cy);
                for (int k = 0; k < cell.length; k++) out.add(cell[k]);
            }
        }
    }

    // ===============================================================================
    // Spawn
    // ===============================================================================

    private void findSpawn() {
        spawnX = 0.0f;
        spawnY = 0.0f;
        float best = -1.0f;
        float bx = 0.0f;
        float by = 0.0f;
        for (int ring = 0; ring < 90; ring++) {
            int pts = Math.max(1, ring * 6);
            for (int k = 0; k < pts; k++) {
                float a = (float) (k * (Math.PI * 2.0) / pts);
                float x = (float) Math.cos(a) * ring * 1.5f;
                float y = (float) Math.sin(a) * ring * 1.5f;
                if (!roomy(x, y)) continue;
                bx = x;
                by = y;
                best = 1.0f;
                break;
            }
            if (best > 0.0f) break;
        }
        spawnX = bx;
        spawnY = by;
    }

    private boolean roomy(float x, float y) {
        for (int j = -3; j <= 3; j++) {
            for (int i = -3; i <= 3; i++) {
                float px = x + i * 1.6f;
                float py = y + j * 1.6f;
                float e = elevation(px, py);
                if (e < SEA_LEVEL + 0.05f || e > CLIFF_LEVEL - 0.12f) return false;
            }
        }
        return true;
    }

    float[] randomOpenPoint(java.util.Random rng, float cx, float cy, float minD, float maxD) {
        for (int t = 0; t < 40; t++) {
            float a = rng.nextFloat() * 6.2831853f;
            float d = minD + rng.nextFloat() * (maxD - minD);
            float x = cx + (float) Math.cos(a) * d;
            float y = cy + (float) Math.sin(a) * d;
            if (!blocked(x, y) && !isWater(x, y)) return new float[]{x, y};
        }
        return null;
    }

    float[] randomWaterPoint(java.util.Random rng, float cx, float cy, float minD, float maxD) {
        for (int t = 0; t < 40; t++) {
            float a = rng.nextFloat() * 6.2831853f;
            float d = minD + rng.nextFloat() * (maxD - minD);
            float x = cx + (float) Math.cos(a) * d;
            float y = cy + (float) Math.sin(a) * d;
            if (waterDepth(x, y) > 0.08f) return new float[]{x, y};
        }
        return null;
    }

    static long seedFromText(String text) {
        if (text == null) return randomSeed();
        String t = text.trim();
        if (t.length() == 0) return randomSeed();
        try {
            return Long.parseLong(t);
        } catch (NumberFormatException e) {
            return t.hashCode();
        }
    }

    static long randomSeed() {
        return mix64(System.nanoTime() ^ (System.currentTimeMillis() * 0x9E3779B97F4A7C15L)) % 1000000000L;
    }
}
