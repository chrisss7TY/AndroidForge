package com.ashveil.abyss;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;

import java.util.Random;

/**
 * Pre-baked art for the world view. Everything here is drawn once and cached by the caller,
 * so none of it runs per frame.
 *
 * Includes 1:1 video-accurate baked ASCII sprites:
 *   - Overgrown Stone Watchtower ("Tower high ground" - watchtowerSprite, matching 1000461712.mp4)
 *   - Multi-Tower ASCII Citadel with diagonal suspension bridges & torch columns (citadelSprite, matching 1000461710.mp4)
 *   - Large Branching Mint-Green ASCII Forest Trees (treeSprite, matching 1000461710.mp4)
 *   - Standing stones & boulders (rockSprite)
 */
final class Gfx {
    static final String ROCK_CHARS = "@WM#B8&%$N0QOZmwqpdbkhao*+=-:;,.";
    static final String CITADEL_CHARS = "Q0O8B@#%&dqpboac*+=-:;,.";
    static final String TREE_CHARS = "Q08B#&%$aodq*+-:.";
    // Authentic horizontal ASCII masonry strings from tower_rooftop.png & tower_entrance.png (1000461712.mp4)
    private static final String[] TOWER_MASONRY_ROWS = new String[]{
            "WMMMQB#@  @M$|Qb%%%%(QQ  @BHH#WB",
            "O&BQ$q)$$Q$@80%  M$80|#WB  @008 qD#",
            "bedNN#0%z**-+~  bvv;*=%DNr  iv++ivv~",
            "#brzbb;~~;~-;~~ uorqp&rn+=rs+*z)~",
            "#N00)podr~~ ;;:-~;;***rd%c^^^rx+xzw~",
            "d%d0#0r  ~+i=^^`snrzopps  !^**d`i^+vcr00",
            "vpr*~+++rcusxz*o  aQ/8Q 98/ =^xz",
            "i;;-+=odwad%czz  Q0Q/8s[B, 0+-+s",
            "**+urqzq%!  qwee|8w/%%a* ocx*i^",
            "\\+iuccpwbb%p  aw&_D00qa8dz0wq%xnz",
            "zsnczb&8wD_$  0Od%%p(q&88%rz",
            "vsww%p)wpeb8&$%  d8wO0Q(b;  |Qq%w /%w;",
            "*xosu|dp)$$)D&  D&Qpd x&D+  $$wwe%oo/_x",
            "q*zsx%rbw0e%%&  Q0W  &0wd$bqpd%s;**--",
            "W/*que\\awd8$&D  Q\\0C  0pqQ0/wqadbs :+^",
            "ew(a&(&Q&\\\\v0&w&0&&$\\%ew8dDa%0b",
            "s0%- r0ww%(%aQ0O)Q&D&//q0$$8e%%wzx%cx",
            "!iw@&qpwd0000QO($Q%@%#$0&w0bewwq0NDQ",
            "+q8@WMN@B#b\\w0&$QOQ(%@#%#D8dQ0www0#@@MW",
            "%DOWW#Mbr=qbbb%#00|_QQwo00%&8w$brd/&#",
            "$ba%8r  /baqQQ/\\$(O$p$a08D$&$r*v!+c",
            "uv+n&##WD%bvw&Oe/0QQ/_wQr *u",
            "wc!/*~ ;za&D00$e$Q/zc;io*",
            "wauv*;=%0bxeqqw_ 0&%paqQpe",
            "uqacc+qa%8&0p%Q$0&%  w08$W0$8Wbrr"
    };

    static final int SPRITE_PPU = 84;
    private static final int GLYPH_W = 9;
    private static final int GLYPH_H = 13;

    private Gfx() {
    }

    private static float smooth(float a, float b, float v) {
        float t = Math.max(0.0f, Math.min(1.0f, (v - a) / (b - a)));
        return t * t * (3.0f - 2.0f * t);
    }

    private static float cellNoise(int x, int y, long id) {
        long h = WorldGen.mix64(id + x * 0x632BE59BD9B4E019L + y * 0x9E3779B97F4A7C15L);
        return ((h >>> 40) & 0xFFFF) / 65536.0f;
    }

    static Bitmap buildObjectSprite(WorldGen.Obj o, float[] baseOut) {
        if (o.kind == WorldGen.WATCHTOWER) {
            return watchtowerSprite(o, baseOut);
        } else if (o.kind == WorldGen.CITADEL) {
            return citadelSprite(o, baseOut);
        } else if (o.kind == WorldGen.TREE) {
            return treeSprite(o, baseOut);
        }
        return rockSprite(o, baseOut);
    }

    /**
     * Overgrown Stone Watchtower ("Tower high ground" from 1000461712.mp4):
     *   - Uses the exact multi-character ASCII masonry rows from tower_rooftop.png & tower_entrance.png
     *   - Circular/octagonal crenelated rooftop deck + sloped lower wall + pitch-black arched south doorway
     *   - Draped with curly olive-green moss & climbing vines
     */
    static Bitmap watchtowerSprite(WorldGen.Obj o, float[] baseOut) {
        int ppu = 68;
        int w = (int) (o.w * 1.18f * ppu);
        int h = (int) (o.h * 1.18f * ppu);
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);

        float cx = w * 0.5f;
        float baseCy = h * 0.72f;
        float roofCy = h * 0.36f;
        float rxRoof = o.w * 0.44f * ppu;
        float ryRoof = rxRoof * 0.76f;
        float rxBase = o.w * 0.49f * ppu;
        float ryBase = rxBase * 0.68f;

        Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Color.rgb(3, 5, 7));

        RectF oval = new RectF();
        for (int step = 0; step <= 26; step++) {
            float t = step / 26.0f;
            float cy = roofCy + (baseCy - roofCy) * t;
            float rx = rxRoof + (rxBase - rxRoof) * (t * t);
            float ry = ryRoof + (ryBase - ryRoof) * (t * t);
            oval.set(cx - rx, cy - ry, cx + rx, cy + ry);
            c.drawOval(oval, fill);
        }

        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setTypeface(Typeface.MONOSPACE);
        tp.setFakeBoldText(true);
        tp.setTextSize(13.0f);
        char[] one = new char[1];

        int rowIdx = 0;
        for (int gy = 8; gy < h - 8; gy += 12) {
            String rowPattern = TOWER_MASONRY_ROWS[rowIdx % TOWER_MASONRY_ROWS.length];
            rowIdx++;
            int charCol = 0;
            for (int gx = 8; gx < w - 8; gx += 8) {
                char patCh = rowPattern.charAt(charCol % rowPattern.length());
                charCol++;

                float dx = gx - cx;
                float ndxR = dx / rxRoof;
                float ndyR = (gy - roofCy) / ryRoof;
                float dRoof = ndxR * ndxR + ndyR * ndyR;

                float wallT = Math.max(0.0f, Math.min(1.0f, (gy - roofCy) / Math.max(1.0f, baseCy - roofCy)));
                float curRx = rxRoof + (rxBase - rxRoof) * (wallT * wallT);
                float curCy = roofCy + (baseCy - roofCy) * wallT;
                float curRy = ryRoof + (ryBase - ryRoof) * (wallT * wallT);
                float ndxW = dx / curRx;
                float ndyW = (gy - curCy) / curRy;
                boolean inWall = (gy >= roofCy && gy <= baseCy + curRy * 0.92f) && (Math.abs(ndxW) <= 1.02f && ndyW <= 1.0f && ndyW >= -0.95f);
                boolean inRoof = dRoof <= 1.08f;
                if (!inRoof && !inWall) continue;

                // Crenelated merlon notches around the rooftop perimeter
                double ang = Math.atan2(ndyR, ndxR);
                int merlon = ((int) Math.floor((ang + Math.PI) / (Math.PI * 2.0) * 16.0));
                boolean isRim = dRoof > 0.80f && dRoof <= 1.08f;
                if (isRim && (merlon % 2 == 1) && dRoof > 0.92f) continue;

                // Deep pitch-black arched south doorway at the base (matching tower_entrance.png!)
                float doorDx = dx / (rxBase * 0.25f);
                float doorDy = (gy - (baseCy + ryBase * 0.38f)) / (ryBase * 0.56f);
                if (!inRoof && doorDx * doorDx + doorDy * doorDy < 1.0f && gy > roofCy + ryRoof * 0.72f) {
                    if (doorDx * doorDx + doorDy * doorDy > 0.76f) {
                        tp.setColor(Color.rgb(98, 112, 124));
                        one[0] = (Math.abs(doorDx) > 0.6f) ? '|' : '=';
                        c.drawText(one, 0, 1, gx, gy, tp);
                    }
                    continue;
                }

                float n = cellNoise(gx, gy, o.id);
                // Curly olive-green moss & climbing vines draped over the battlements and walls (matching tower_rooftop.png & tower_entrance.png!)
                float mossNoise = cellNoise(gx / 3, gy / 3, o.id ^ 0x4F55L);
                float mossBand = (float) Math.sin(gx * 0.042f + gy * 0.032f) * 0.26f + mossNoise;
                if ((isRim && mossBand > 0.52f) || (!inRoof && mossBand > 0.58f) || (inRoof && dRoof > 0.58f && mossBand > 0.65f)) {
                    int mg = Math.max(85, Math.min(220, (int) (92.0f + n * 122.0f)));
                    int mr = (int) (mg * 0.62f);
                    int mb = (int) (mg * 0.48f);
                    tp.setColor(Color.rgb(mr, mg, mb));
                    String mossChars = "~+*,;v%w()r";
                    one[0] = mossChars.charAt(Math.abs(gx * 7 + gy * 13) % mossChars.length());
                    c.drawText(one, 0, 1, gx, gy, tp);
                    continue;
                }

                if (patCh == ' ') continue;

                float lum;
                if (inRoof && !isRim) {
                    // Warm campfire bounce light on the rooftop flagstones
                    float fireDx = (gx - (cx + rxRoof * 0.14f)) / (rxRoof * 0.56f);
                    float fireDy = (gy - (roofCy + ryRoof * 0.12f)) / (ryRoof * 0.56f);
                    float fireDist = (float) Math.sqrt(fireDx * fireDx + fireDy * fireDy);
                    float fireLit = Math.max(0.0f, 1.0f - fireDist);
                    lum = 0.54f + 0.24f * n + 0.34f * fireLit - 0.12f * dRoof;
                    int vv = Math.max(92, Math.min(248, (int) (84.0f + lum * 155.0f)));
                    int rr = Math.min(255, vv + (int) (fireLit * 82.0f));
                    int gg = Math.min(255, vv + (int) (fireLit * 30.0f));
                    int bb = Math.max(0, Math.min(255, vv + 12 - (int) (fireLit * 36.0f)));
                    tp.setColor(Color.rgb(rr, gg, bb));
                } else {
                    float lit = 0.58f - 0.36f * ndxW - 0.18f * wallT;
                    if (isRim) lit += 0.18f;
                    lum = Math.max(0.22f, Math.min(1.0f, 0.38f + 0.46f * lit + 0.20f * n));
                    int vv = Math.max(75, Math.min(248, (int) (68.0f + lum * 172.0f)));
                    tp.setColor(Color.rgb(Math.max(0, vv - 6), vv, Math.min(255, vv + 12)));
                }
                one[0] = patCh;
                c.drawText(one, 0, 1, gx, gy, tp);
            }
        }

        baseOut[0] = cx;
        baseOut[1] = baseCy + ryBase * 0.45f;
        return bmp;
    }

    /**
     * Multi-Tower ASCII Citadel Fortress with Walkable Diagonal Suspension Bridges & Blazing Torch Pillars
     * (matching citadel_bridges.png from 1000461710.mp4 00:21-00:31).
     */
    static Bitmap citadelSprite(WorldGen.Obj o, float[] baseOut) {
        int ppu = 56;
        int w = (int) (19.5f * ppu);
        int h = (int) (13.5f * ppu);
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);

        float keepCx = w * 0.66f;
        float keepBaseY = h * 0.72f;

        Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Color.rgb(4, 6, 10));

        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setTypeface(Typeface.MONOSPACE);
        tp.setFakeBoldText(true);
        tp.setTextSize(11.5f);
        char[] one = new char[1];
        int nChars = CITADEL_CHARS.length();

        // 1. Two parallel diagonal ASCII stone/rope bridges extending upper-left and lower-left
        for (int bIdx = 0; bIdx < 2; bIdx++) {
            float startX = keepCx - 1.4f * ppu;
            float startY = keepBaseY + (bIdx == 0 ? -2.2f : 0.5f) * ppu;
            float endX = keepCx - 10.2f * ppu;
            float endY = startY - 3.6f * ppu;
            float bridgeHalfH = 0.66f * ppu;

            for (float gx = endX; gx <= startX; gx += 7.5f) {
                float u = (gx - endX) / Math.max(1.0f, startX - endX);
                float midY = endY + (startY - endY) * u + (float) Math.sin(u * Math.PI) * (0.20f * ppu);
                fill.setColor(Color.argb(235, 4, 6, 10));
                c.drawRect(gx - 4, midY - bridgeHalfH, gx + 5, midY + bridgeHalfH, fill);
                for (float gy = midY - bridgeHalfH; gy <= midY + bridgeHalfH; gy += 10.0f) {
                    boolean rail = Math.abs(gy - midY) > bridgeHalfH * 0.65f;
                    float n = cellNoise((int) gx, (int) gy, o.id + bIdx * 31L);
                    float lum = rail ? (0.82f + 0.16f * n) : (0.54f + 0.24f * n);
                    int vv = Math.max(92, Math.min(246, (int) (82.0f + lum * 160.0f)));
                    tp.setColor(Color.rgb(vv - 4, vv, Math.min(255, vv + 14)));
                    one[0] = rail ? 'Q' : CITADEL_CHARS.charAt((int) ((1.0f - lum) * (nChars - 1)));
                    c.drawText(one, 0, 1, gx, gy, tp);
                }
            }
        }

        // 2. Three Massive Interlocking Citadel Keep Towers with Conical Battlement Roofs (matching citadel_bridges.png!)
        float[][] towers = {
                {keepCx - 2.3f * ppu, keepBaseY - 1.4f * ppu, 2.05f * ppu, 5.8f * ppu},
                {keepCx + 2.0f * ppu, keepBaseY - 1.9f * ppu, 2.15f * ppu, 6.2f * ppu},
                {keepCx - 0.1f * ppu, keepBaseY + 0.5f * ppu, 2.35f * ppu, 5.4f * ppu}
        };

        for (int ti = 0; ti < towers.length; ti++) {
            float tcx = towers[ti][0];
            float tby = towers[ti][1];
            float radX = towers[ti][2];
            float tall = towers[ti][3];
            float topY = tby - tall;
            float roofPeakY = topY - radX * 0.82f;

            Path p = new Path();
            p.moveTo(tcx, roofPeakY);
            p.lineTo(tcx + radX * 1.08f, topY);
            p.lineTo(tcx + radX, tby);
            p.lineTo(tcx - radX, tby);
            p.lineTo(tcx - radX * 1.08f, topY);
            p.close();
            fill.setColor(Color.rgb(4, 6, 10));
            c.drawPath(p, fill);

            for (float gy = roofPeakY; gy <= tby; gy += 10.5f) {
                boolean inConicalRoof = gy < topY;
                float halfW = inConicalRoof
                        ? radX * 1.08f * ((gy - roofPeakY) / Math.max(1.0f, topY - roofPeakY))
                        : radX * (0.96f + 0.08f * ((gy - topY) / Math.max(1.0f, tall)));
                for (float gx = tcx - halfW; gx <= tcx + halfW; gx += 7.5f) {
                    float nx = (gx - tcx) / Math.max(1.0f, halfW);
                    float ny = (gy - topY) / Math.max(1.0f, tall);
                    if (!inConicalRoof && Math.abs(nx) < 0.14f && ((ny > 0.22f && ny < 0.42f) || (ny > 0.58f && ny < 0.78f))) {
                        continue;
                    }
                    float n = cellNoise((int) gx, (int) gy, o.id + ti * 97L);
                    float lit = 0.60f - 0.36f * nx - (inConicalRoof ? 0.10f : 0.08f * ny);
                    float torchDx = (gx - (tcx + radX * 0.72f)) / (radX * 0.95f);
                    float torchDy = (gy - (tby - tall * 0.28f)) / (radX * 0.95f);
                    float torchGlow = Math.max(0.0f, 1.0f - (float) Math.sqrt(torchDx * torchDx + torchDy * torchDy));

                    float lum = Math.max(0.22f, Math.min(1.0f, 0.40f + 0.46f * lit + 0.20f * n + 0.28f * torchGlow));
                    int vv = Math.max(82, Math.min(248, (int) (76.0f + lum * 170.0f)));
                    int rr = Math.min(255, vv + (int) (torchGlow * 92.0f));
                    int gg = Math.min(255, vv + (int) (torchGlow * 28.0f));
                    int bb = Math.max(0, Math.min(255, vv + 14 - (int) (torchGlow * 42.0f)));
                    tp.setColor(Color.rgb(rr, gg, bb));
                    int idx = Math.max(0, Math.min(nChars - 1, (int) ((1.0f - lum) * (nChars - 1))));
                    one[0] = CITADEL_CHARS.charAt(idx);
                    c.drawText(one, 0, 1, gx, gy, tp);
                }
            }
        }

        // 3. Flanked Fluted Torch Columns with Blazing Orange Braziers (matching citadel_bridges.png!)
        float[][] pillars = {
                {keepCx + 1.5f * ppu, keepBaseY + 0.65f * ppu},
                {keepCx + 3.6f * ppu, keepBaseY - 0.55f * ppu}
        };
        for (int pi = 0; pi < pillars.length; pi++) {
            float px = pillars[pi][0];
            float py = pillars[pi][1];
            float pw = 0.54f * ppu;
            float ph = 2.35f * ppu;
            fill.setColor(Color.rgb(5, 7, 10));
            c.drawRect(px - pw, py - ph, px + pw, py, fill);
            for (float gy = py - ph; gy <= py; gy += 10.0f) {
                boolean brazierTop = gy < py - ph + 26.0f;
                for (float gx = px - pw; gx <= px + pw; gx += 7.5f) {
                    if (brazierTop) {
                        tp.setColor(Color.rgb(255, 178 + (int) (cellNoise((int) gx, (int) gy, pi) * 70), 68));
                        one[0] = "W@M#*+".charAt(Math.abs((int) (gx + gy)) % 6);
                    } else {
                        float nx = (gx - px) / pw;
                        int vv = Math.max(98, Math.min(240, (int) (165 - nx * 55)));
                        tp.setColor(Color.rgb(vv + 22, vv + 4, vv - 8));
                        one[0] = (Math.abs(nx) > 0.6f) ? '|' : 'Q';
                    }
                    c.drawText(one, 0, 1, gx, gy, tp);
                }
            }
        }

        baseOut[0] = keepCx;
        baseOut[1] = keepBaseY;
        return bmp;
    }

    /**
     * Large Branching Mint-Green ASCII Forest Tree (matching forest_trees.png from 1000461710.mp4 00:00-00:03).
     */
    static Bitmap treeSprite(WorldGen.Obj o, float[] baseOut) {
        int ppu = 64;
        int w = Math.max(64, (int) (o.w * 1.25f * ppu));
        int h = Math.max(64, (int) (o.h * 1.20f * ppu));
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);

        float cx = w * 0.5f;
        float baseY = h * 0.90f;
        float forkY = h * 0.56f;

        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setTypeface(Typeface.MONOSPACE);
        tp.setFakeBoldText(true);
        tp.setTextSize(11.5f);
        char[] one = new char[1];

        String bark = "Q08Sqd/\\|";
        for (float gy = forkY; gy <= baseY; gy += 10.0f) {
            float v = (gy - forkY) / Math.max(1.0f, baseY - forkY);
            float roots = (v > 0.75f) ? (v - 0.75f) * 3.2f : 0.0f;
            float halfW = (14.0f + roots * 26.0f);
            float curve = (float) Math.sin(v * 3.1f) * 8.0f;
            for (float gx = cx + curve - halfW; gx <= cx + curve + halfW; gx += 7.5f) {
                float nx = (gx - (cx + curve)) / Math.max(1.0f, halfW);
                int vv = Math.max(115, Math.min(235, (int) (178 - nx * 48)));
                tp.setColor(Color.rgb(vv - 24, vv + 14, vv - 4));
                one[0] = bark.charAt(Math.abs((int) (gx * 3 + gy * 7)) % bark.length());
                c.drawText(one, 0, 1, gx, gy, tp);
            }
        }
        float[][] limbs = {
                {cx, forkY, cx - w * 0.25f, h * 0.34f},
                {cx, forkY, cx + w * 0.26f, h * 0.32f},
                {cx - w * 0.10f, h * 0.45f, cx - w * 0.04f, h * 0.24f},
                {cx + w * 0.12f, h * 0.44f, cx + w * 0.08f, h * 0.22f}
        };
        for (int li = 0; li < limbs.length; li++) {
            float ax = limbs[li][0], ay = limbs[li][1], bx = limbs[li][2], by = limbs[li][3];
            for (int s = 0; s <= 18; s++) {
                float t = s / 18.0f;
                float lx = ax + (bx - ax) * t;
                float ly = ay + (by - ay) * t;
                float rad = 11.0f * (1.0f - 0.45f * t);
                for (float dx = -rad; dx <= rad; dx += 7.5f) {
                    tp.setColor(Color.rgb(148, 196, 168));
                    one[0] = (bx < ax) ? '\\' : '/';
                    c.drawText(one, 0, 1, lx + dx, ly, tp);
                }
            }
        }

        float[][] lobes = {
                {cx - w * 0.24f, h * 0.34f, w * 0.24f, h * 0.15f},
                {cx + w * 0.24f, h * 0.32f, w * 0.24f, h * 0.15f},
                {cx, h * 0.22f, w * 0.30f, h * 0.16f},
                {cx - w * 0.12f, h * 0.27f, w * 0.22f, h * 0.14f},
                {cx + w * 0.14f, h * 0.26f, w * 0.22f, h * 0.14f}
        };
        Paint backFill = new Paint(Paint.ANTI_ALIAS_FLAG);
        backFill.setColor(Color.argb(185, 4, 8, 8));

        for (int gy = 10; gy < (int) (h * 0.56f); gy += 10) {
            for (int gx = 10; gx < w - 10; gx += 7) {
                float best = 9.0f;
                float lobeLit = 0.5f;
                for (int k = 0; k < lobes.length; k++) {
                    float dx = (gx - lobes[k][0]) / lobes[k][2];
                    float dy = (gy - lobes[k][1]) / lobes[k][3];
                    float d = dx * dx + dy * dy;
                    if (d < best) {
                        best = d;
                        lobeLit = 0.64f - 0.28f * dx - 0.32f * dy;
                    }
                }
                float n = cellNoise(gx, gy, o.id ^ 0x72EEL);
                if (best > 0.85f + 0.35f * n) continue;
                if (n < 0.14f) continue;
                c.drawRect(gx - 1, gy - 9, gx + 7, gy + 2, backFill);
                float lum = Math.max(0.28f, Math.min(1.0f, lobeLit * 0.72f + n * 0.38f));
                int gg = Math.max(108, Math.min(246, (int) (96.0f + lum * 150.0f)));
                int rr = Math.max(62, (int) (gg * 0.68f));
                int bb = Math.max(78, (int) (gg * 0.80f));
                tp.setColor(Color.rgb(rr, gg, bb));
                int idx = Math.max(0, Math.min(TREE_CHARS.length() - 1, (int) ((1.0f - lum) * (TREE_CHARS.length() - 1))));
                one[0] = TREE_CHARS.charAt(idx);
                c.drawText(one, 0, 1, gx, gy, tp);
            }
        }

        baseOut[0] = cx;
        baseOut[1] = baseY;
        return bmp;
    }

    static Bitmap rockSprite(WorldGen.Obj o, float[] baseOut) {
        boolean pillar = o.kind == WorldGen.PILLAR;
        float wUnits = o.w * (pillar ? 1.30f : 1.12f);
        int w = Math.max(32, (int) (wUnits * SPRITE_PPU));
        float depthU = o.w * 0.34f;
        int footPx = (int) (depthU * SPRITE_PPU);
        int h = Math.max(32, (int) ((o.h + depthU) * SPRITE_PPU));

        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Random rnd = new Random(o.id);
        float ph1 = rnd.nextFloat() * 6.2832f;
        float ph2 = rnd.nextFloat() * 6.2832f;
        float lean = rnd.nextFloat() * 2.0f - 1.0f;

        float[] left = new float[h];
        float[] right = new float[h];
        for (int r = 0; r < h; r++) {
            float v = r / (float) (h - 1);
            float half;
            if (pillar) {
                float base = 0.5f * o.w * SPRITE_PPU;
                half = base * (0.70f + 0.42f * smooth(0.66f, 1.0f, v));
                if (v < 0.06f) half *= (float) Math.sqrt(v / 0.06f);
                if (v > 0.95f) half *= (float) Math.sqrt(Math.max(0.0f, (1.0f - v) / 0.05f));
            } else {
                float e = 2.0f * v - 1.0f;
                half = 0.5f * w * (float) Math.sqrt(Math.max(0.0f, 1.0f - e * e));
            }
            half *= 1.0f + 0.07f * (float) Math.sin(v * 19.0f + ph1) + 0.04f * (float) Math.sin(v * 47.0f + ph2);
            float cx = w * 0.5f + (pillar ? lean * (1.0f - v) * o.w * SPRITE_PPU * 0.10f : 0.0f);
            left[r] = cx - half;
            right[r] = cx + half;
        }

        Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Color.rgb(4, 6, 8));
        Path path = new Path();
        int first = -1;
        int last = -1;
        for (int r = 0; r < h; r++) {
            if (right[r] - left[r] > 1.0f) {
                if (first < 0) first = r;
                last = r;
            }
        }
        if (first >= 0) {
            path.moveTo(left[first], first);
            for (int r = first; r <= last; r++) path.lineTo(left[r], r);
            for (int r = last; r >= first; r--) path.lineTo(right[r], r);
            path.close();
            c.drawPath(path, fill);
        }

        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setTypeface(Typeface.MONOSPACE);
        tp.setFakeBoldText(true);
        tp.setTextSize(14.0f);
        char[] one = new char[1];
        int nChars = ROCK_CHARS.length();
        for (int gy = 4; gy < h - 2; gy += GLYPH_H) {
            int rr = Math.min(h - 1, gy);
            float l = left[rr];
            float rg = right[rr];
            if (rg - l < GLYPH_W) continue;
            float cx = (l + rg) * 0.5f;
            float half = (rg - l) * 0.5f;
            float v = gy / (float) h;
            for (float gx = l + 2.0f; gx < rg - GLYPH_W + 2.0f; gx += GLYPH_W) {
                float nx = ((gx + GLYPH_W * 0.5f) - cx) / half;
                float ny = pillar ? 0.0f : (v - 0.5f) * 2.0f;
                float lit = 0.55f - 0.42f * nx - 0.28f * ny;
                float n = cellNoise((int) gx, gy, o.id);
                float lum = 0.34f + 0.46f * lit + 0.20f * n;
                if (pillar && v < 0.10f) lum += 0.12f;
                if (nx > 0.78f || ny > 0.80f) lum -= 0.18f;
                lum = Math.max(0.15f, Math.min(1.0f, lum));
                int idx = (int) ((1.0f - lum) * (nChars - 1) + (n - 0.5f) * 3.0f);
                idx = Math.max(0, Math.min(nChars - 1, idx));
                int vv = Math.max(70, Math.min(248, (int) (70.0f + lum * 175.0f)));
                tp.setColor(Color.rgb(Math.max(0, vv - 6), vv, Math.min(255, vv + 9)));
                one[0] = ROCK_CHARS.charAt(idx);
                c.drawText(one, 0, 1, gx, gy + GLYPH_H * 0.8f, tp);
            }
        }

        baseOut[0] = w * 0.5f;
        baseOut[1] = h - footPx * 0.5f;
        return bmp;
    }

    static Bitmap fogTile(long seed) {
        final int n = 256;
        int[] px = new int[n * n];
        Random rnd = new Random(seed ^ 0xF06F06L);
        int[] sizes = {4, 8, 16, 32};
        float[] amps = {0.50f, 0.28f, 0.14f, 0.08f};
        float[][] lat = new float[4][];
        for (int o = 0; o < 4; o++) {
            lat[o] = new float[sizes[o] * sizes[o]];
            for (int i = 0; i < lat[o].length; i++) lat[o][i] = rnd.nextFloat();
        }
        for (int y = 0; y < n; y++) {
            for (int x = 0; x < n; x++) {
                float sum = 0.0f;
                for (int o = 0; o < 4; o++) {
                    int s = sizes[o];
                    float fx = x * s / (float) n;
                    float fy = y * s / (float) n;
                    int x0 = (int) fx;
                    int y0 = (int) fy;
                    float tx = fx - x0;
                    float ty = fy - y0;
                    tx = tx * tx * (3.0f - 2.0f * tx);
                    ty = ty * ty * (3.0f - 2.0f * ty);
                    int x1 = (x0 + 1) % s;
                    int y1 = (y0 + 1) % s;
                    x0 %= s;
                    y0 %= s;
                    float a = lat[o][y0 * s + x0];
                    float b = lat[o][y0 * s + x1];
                    float cc = lat[o][y1 * s + x0];
                    float d = lat[o][y1 * s + x1];
                    float top = a + (b - a) * tx;
                    float bot = cc + (d - cc) * tx;
                    sum += amps[o] * (top + (bot - top) * ty);
                }
                float a = Math.max(0.0f, Math.min(1.0f, (sum - 0.46f) * 3.4f));
                float grain = 0.55f + 0.45f * rnd.nextFloat();
                px[y * n + x] = Color.argb((int) (a * grain * 118.0f), 206, 224, 232);
            }
        }
        Bitmap bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888);
        bmp.setPixels(px, 0, n, 0, 0, n, n);
        return bmp;
    }

    private static final class FloatList {
        float[] a = new float[4096];
        int n = 0;

        void add4(float x0, float y0, float x1, float y1) {
            if (n + 4 > a.length) a = java.util.Arrays.copyOf(a, a.length * 2);
            a[n++] = x0;
            a[n++] = y0;
            a[n++] = x1;
            a[n++] = y1;
        }
    }

    static Bitmap grassTile(int t) {
        Bitmap bmp = Bitmap.createBitmap(t, t, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        c.drawColor(Color.rgb(6, 12, 11));
        Random rnd = new Random(0x5EEDBEEFL);

        int[] colors = {
                Color.rgb(7, 17, 14), Color.rgb(11, 28, 22), Color.rgb(17, 42, 32),
                Color.rgb(27, 62, 46), Color.rgb(40, 86, 62), Color.rgb(74, 122, 92)
        };
        int[] counts = {30000, 30000, 28000, 20000, 9000, 2600};
        float k = t / 1536.0f;
        Paint pb = new Paint(Paint.ANTI_ALIAS_FLAG);
        pb.setStyle(Paint.Style.STROKE);
        pb.setStrokeCap(Paint.Cap.ROUND);
        pb.setStrokeWidth(1.35f * Math.max(0.8f, k));

        float margin = 26.0f * k;
        for (int ci = 0; ci < colors.length; ci++) {
            FloatList fl = new FloatList();
            for (int i = 0; i < counts[ci]; i += 3) {
                float tx = rnd.nextFloat() * t;
                float ty = rnd.nextFloat() * t;
                for (int b = 0; b < 3; b++) {
                    float bx = tx + (b - 1) * 2.2f * k;
                    float by = ty + (b == 1 ? -1.0f : 0.5f) * k;
                    float len = (8.0f + rnd.nextFloat() * 8.0f) * k * (0.75f + 0.1f * ci);
                    float lean = ((b - 1) * 1.5f + (rnd.nextFloat() - 0.5f) * 3.0f + 1.4f) * k;
                    for (int ox = -1; ox <= 1; ox++) {
                        if (ox == -1 && bx < t - margin) continue;
                        if (ox == 1 && bx > margin) continue;
                        for (int oy = -1; oy <= 1; oy++) {
                            if (oy == -1 && by < t - margin) continue;
                            if (oy == 1 && by > margin) continue;
                            float ax = bx + ox * t;
                            float ay = by + oy * t;
                            fl.add4(ax, ay, ax + lean, ay - len);
                        }
                    }
                }
            }
            pb.setColor(colors[ci]);
            c.drawLines(fl.a, 0, fl.n, pb);
        }
        return bmp;
    }
}
