package com.ashveil.abyss;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class MainActivity extends Activity {
    private static boolean sRustLoaded = false;
    static {
        try {
            System.loadLibrary("ashveil_ascii_3d");
            sRustLoaded = true;
        } catch (Throwable ignored) {
            sRustLoaded = false;
        }
    }

    public static native long nativeInit(long seed);
    public static native int nativeStep(long handle, float dt);
    public static native void nativeTouch(long handle, int action, long pointerId, float normX, float normY);
    public static native void nativeDestroy(long handle);

    private AshveilView mView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );
        mView = new AshveilView(this);
        setContentView(mView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mView != null) mView.resumeGame();
    }

    @Override
    protected void onPause() {
        if (mView != null) mView.pauseGame();
        super.onPause();
    }

    private static final class AshveilView extends SurfaceView implements Runnable, SurfaceHolder.Callback {
        private static final String DENSE_RAMP = " .,:;-=+*oahkbdpqwmZOQ0N$%&8B#MW@";
        private static final String CLIFF_CHARS = "@WM#B8&%$N0QOZmwqpdbkhao*+=-:;,.";
        // Dense slate-blue 0Q8Qdba ASCII ground matrix strings matching hero_chainmail.png & hero_idle_blade.png!
        private static final String[] GROUND_ASCII = new String[]{
                "0Q8Q", "QQ0O", "80aa", "qQ80", "d800", "00QQ", "8Q08", "dQc8", "QQBQ", "0d00"
        };
        private static final String[] PATH_ASCII = new String[]{
                "Q08Q", "aQ80", "08QQ", "dQ8a", "QQ08", "8Q0a", "0QQ8", "Q8QQ"
        };

        // Handcrafted ASCII House / Cottage (warm hearth + shingled roof)
        private static final String[] HOUSE_ART = new String[]{
                "      .::::::::::.      ",
                "    .:////////////:.    ",
                "  .:////////////////:.  ",
                " .====================. ",
                " |  [##]        [##]  | ",
                " |  |..|  .--.  |..|  | ",
                " |______| |**| |______| ",
                " |######| |**| |######| "
        };

        // Hanging Crimson/Orange Pennant Banner on Frame (matching banners_lanterns.png from 1000461710.mp4!)
        private static final String[] BANNER_ART = new String[]{
                "Q",
                "QQQQQQQQ Q Q a",
                "Q``````` Q `Q0",
                "Q dQQccQ0Q",
                "Q QQQQQQQQ",
                "Q dQ8 8 0Q",
                "Q dQ0dQ QQ",
                "Q QQQ | QQ",
                "Q QQ| ` QQ",
                "Q dQQQQQQQ",
                "Q QQQ*8QQ_",
                "Q `QQQQQQQ",
                "Q  QQQQ88",
                "Q   QQB",
                "Q   *QQ",
                "8    d8"
        };

        // Gallows-style Iron Lantern Post (matching banners_lanterns.png from 1000461710.mp4!)
        private static final String[] LANTERN_ART = new String[]{
                "Q\\______Q",
                "Q*00Q0Q0Q0*",
                "Q Qd  * 8",
                "Q_Q0    8",
                "Q 8     0",
                "QQ    Q_QQ",
                "Q*    *QQQD",
                "QB    *QQQQ",
                "Q0    -QQQc",
                "Qc     aQQQ"
        };

        // Small triangular green ASCII bush/shrub (matching forest_trees.png & banners_lanterns.png from 1000461710.mp4!)
        private static final String[] SHRUB_ART = new String[]{
                "    ]    ",
                "    d    ",
                " <].8) o ",
                " / QU[d`c",
                " ||UQd/o "
        };

        // Ancient Stone Ruin Wall / Courtyard Block (matching 1000461710.mp4 00:04-00:15)
        private static final String[] RUIN_WALL_ART = new String[]{
                "8 Q 8 8c]8]<8 QQQ*`0*`0QQ`*8Q`O",
                "8 Q Qc8[|]]c8Q*00Q0Q0QQQ*`*8Q0c",
                "Q Q 8 ]  ][`Q8Q0*`8O*8Q00   QQ`dQ",
                "0 Q 8 c] |c`8Q0QQQ 0QQ-`  d`8QQQ",
                "Q Q 8 [ [Q|]]QQ`QQQQ0Q0000 ` dBQQQ",
                "0 Q 8 ] |][]8Q`QQQQ8`*QQ`   `8QQQ"
        };

        private Thread mThread;
        private volatile boolean mRunning = false;
        private long mRustHandle = 0;

        // Reusable Paints (zero per-frame allocations)
        private final Paint mAsciiPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mGrassPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mShadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mUiPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mUiSubPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mPanelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mBitmapPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
        private final Paint mGlowPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
        private final Paint mChunkBgPaint = new Paint();
        private final Paint mChunkTxtPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final char[] mSingleChar = new char[1];
        private final RectF mTmpRect = new RectF();
        private final Rect mSrcRect = new Rect();

        // Pre-baked World & Glow Caches
        private static final int MEADOW_TILE_PX = 1536;
        private static final float CHUNK_WORLD_UNITS = 4.0f;
        private static final int CHUNK_PX = 384;
        private static final int CHUNK_CELLS = 24;
        private static final int CHUNK_CACHE_CAP = 100;

        private Bitmap mMeadowTileBitmap = null;
        private Bitmap mFogBitmap = null;
        private Bitmap mAmberGlowBitmap = null;
        private Bitmap mCyanGlowBitmap = null;
        private Bitmap mVignetteBitmap = null;

        private final int[] mChunkKeys = new int[CHUNK_CACHE_CAP];
        private final Bitmap[] mChunkBitmaps = new Bitmap[CHUNK_CACHE_CAP];
        private final Canvas[] mChunkCanvases = new Canvas[CHUNK_CACHE_CAP];
        private final int[] mChunkAge = new int[CHUNK_CACHE_CAP];
        private int mChunkTick = 1;

        // Procedural world
        private volatile WorldGen mGen;
        private long mWorldSeed = 0L;
        private volatile boolean mWorldDirty = false;
        private volatile long mPendingSeed = 0L;
        private SharedPreferences mPrefs;
        private final ArrayList<WorldGen.Obj> mObjs = new ArrayList<WorldGen.Obj>();
        private final Random mRng = new Random();
        private final float[] mSample = new float[3];

        // Object sprites (pillars, boulders, watchtowers, citadels, forest trees), baked once and cached
        private static final int SPRITE_CACHE_CAP = 36;
        private final HashMap<Long, Bitmap> mSpriteCache = new HashMap<Long, Bitmap>();
        private final HashMap<Long, float[]> mSpriteBase = new HashMap<Long, float[]>();
        private final ArrayList<Long> mSpriteOrder = new ArrayList<Long>();
        private int mSpriteBudget = 2;
        private long mFrameStartNs = 0L;

        // Wispy world-anchored fog
        private Bitmap mFogTile = null;
        private final BitmapShader[] mFogShader = new BitmapShader[2];
        private final Paint[] mFogPaint = new Paint[]{new Paint(Paint.FILTER_BITMAP_FLAG), new Paint(Paint.FILTER_BITMAP_FLAG)};
        private final Matrix[] mFogMatrix = new Matrix[]{new Matrix(), new Matrix()};

        // Chunk painter scratch
        private Bitmap mTintBitmap = null;
        private final int[] mTintPx = new int[CHUNK_CELLS * CHUNK_CELLS];
        private final float[] mLatCliff = new float[(CHUNK_CELLS + 1) * (CHUNK_CELLS + 1)];
        private final float[] mLatWater = new float[(CHUNK_CELLS + 1) * (CHUNK_CELLS + 1)];
        private final float[] mLatMoist = new float[(CHUNK_CELLS + 1) * (CHUNK_CELLS + 1)];
        private final boolean[] mSolid = new boolean[CHUNK_CELLS * CHUNK_CELLS];
        private final boolean[] mWet = new boolean[CHUNK_CELLS * CHUNK_CELLS];
        private final Paint mTintPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
        private static final int MASK_PX = CHUNK_CELLS * 4;
        private Bitmap mWaterMask = null;
        private Bitmap mCliffMask = null;
        private final int[] mMaskPx = new int[MASK_PX * MASK_PX];
        private final float[] mFoamBright = new float[900 * 4];
        private final float[] mFoamDim = new float[900 * 4];
        private final float[] mTickPts = new float[400 * 4];

        // Screen mode: 0 = Start Menu, 1 = Gameplay, 2 = Character / Inventory / Forge Modal
        private int mScreenMode = 0;
        private boolean mMounted = false;
        private boolean mAttackButtonOnly = true;
        private int mZoomPreset = 0; // Default to Close-up (1.48f) so the hero & chainmail look just like 1000461713.mp4!
        private float mCameraZoom = 1.48f;
        private int mWindPreset = 1;

        // World, Camera & Elevation State ("Tower high ground")
        private float mPlayerX = 0.0f;
        private float mPlayerY = 0.0f;
        private int mPlayerElevation = 0; // 0 = Ground/Bridges, 1 = On Watchtower High Ground Rooftop
        private float mTowerRoofCx = 0.0f;
        private float mTowerRoofCy = 0.0f;
        private float mTowerBaseY = 0.0f;
        private float mCamX = 0.0f;
        private float mCamY = 0.0f;
        private float mVelX = 0.0f;
        private float mVelY = 0.0f;
        private float mFacingX = -0.78f;
        private float mFacingY = 0.62f;
        private float mGaitPhase = 0.0f;
        private float mTimeSec = 0.0f;
        private float mSlashTimer = 0.0f;
        private float mSlashCooldown = 0.0f;
        private int mSlashCombo = 0;
        private float mBladeWorldX = 0.0f;
        private float mBladeWorldY = 0.0f;
        private float mDodgeTimer = 0.0f;
        private float mDodgeCooldown = 0.0f;
        private float mDodgeDirX = 1.0f;
        private float mDodgeDirY = 0.0f;
        private float mPlayerHurtFlash = 0.0f;

        private static final int MAX_AFTERIMAGES = 5;
        private final float[] mGhostX = new float[MAX_AFTERIMAGES];
        private final float[] mGhostY = new float[MAX_AFTERIMAGES];
        private final float[] mGhostLife = new float[MAX_AFTERIMAGES];
        private float mGhostSpawnAccum = 0.0f;

        private float mCursorX = 0.54f;
        private float mCursorY = 0.52f;

        // Touch Controls
        private int mMovePointerId = -1;
        private float mJoyBaseX = 0.0f;
        private float mJoyBaseY = 0.0f;
        private float mJoyCurrX = 0.0f;
        private float mJoyCurrY = 0.0f;
        private float mInputX = 0.0f;
        private float mInputY = 0.0f;

        // Offline Single-Player RPG & Craft State (matching 1000461713.mp4 "Chainmail test")
        private int mLevel = 15;
        private int mXp = 1943;
        private int mXpNext = 6995;
        private int mHp = 1850;
        private int mMaxHp = 1850;
        private int mMp = 160;
        private int mMaxMp = 160;
        private int mGold = 5420;
        private int mStatPoints = 3;
        private int mVit = 20;
        private int mStr = 24;
        private int mDex = 18;
        private int mForgeLevel = 3;
        private int mForgeSlot = 1; // 1=Helm ("Bloody Mail Coif")
        private int mForgeMetal = 1; // 1=Iron
        private int mHelmVariant = 0;
        private int mLegsVariant = 0;
        private int mRuneSlot1 = -1;
        private int mRuneSlot2 = -1;
        private float mCoifRot = 0.0f;
        private String mEquippedWeapon = "Emberstone Greatsword";
        private String mEquippedArmor = "Bloody Mail Coif & Dark Greaves";
        private final String[] mInventory = new String[16];
        private int mInvCount = 2;

        // Toast Banner
        private String mStatusBanner = "North: Watchtower High Ground • West: Forest & Citadel Bridges";
        private float mBannerTimer = 5.0f;

        // Verlet Hair / Mane / Tail Physics
        private static final int TAIL_STRANDS = 12;
        private static final int TAIL_NODES = 10;
        private final float[][] mTailX = new float[TAIL_STRANDS][TAIL_NODES];
        private final float[][] mTailY = new float[TAIL_STRANDS][TAIL_NODES];
        private final float[][] mTailPrevX = new float[TAIL_STRANDS][TAIL_NODES];
        private final float[][] mTailPrevY = new float[TAIL_STRANDS][TAIL_NODES];

        private static final int MANE_STRANDS = 14;
        private static final int MANE_NODES = 7;
        private final float[][] mManeX = new float[MANE_STRANDS][MANE_NODES];
        private final float[][] mManeY = new float[MANE_STRANDS][MANE_NODES];
        private final float[][] mManePrevX = new float[MANE_STRANDS][MANE_NODES];
        private final float[][] mManePrevY = new float[MANE_STRANDS][MANE_NODES];

        private static final int HAIR_STRANDS = 10;
        private static final int HAIR_NODES = 9;
        private final float[][] mHairX = new float[HAIR_STRANDS][HAIR_NODES];
        private final float[][] mHairY = new float[HAIR_STRANDS][HAIR_NODES];
        private final float[][] mHairPrevX = new float[HAIR_STRANDS][HAIR_NODES];
        private final float[][] mHairPrevY = new float[HAIR_STRANDS][HAIR_NODES];

        private final GrassFx mGrassFx = new GrassFx();
        private final HairFx mTailFx = new HairFx(34, 11, 0.105f, 7L);
        private final HairFx mManeFx = new HairFx(24, 8, 0.085f, 9L);
        private float mNeckBaseLocX = 0.4f, mNeckBaseLocY = -0.1f, mNeckTopLocX = 0.8f, mNeckTopLocY = -0.6f;
        private float mAsciiAdv = 0.0f;

        // High-Resolution ASCII Entity Buffers
        private static final float HORSE_SPAN_PPU = 3.15f;
        private static final float HORSE_ROW_ASPECT = 1.3f;
        private static final int HORSE_BUF_W = 96;
        private static final int HORSE_BUF_H = 58;
        private final char[] mHorseGlyphBuf = new char[HORSE_BUF_W * HORSE_BUF_H];
        private final float[] mHorseLumBuf = new float[HORSE_BUF_W * HORSE_BUF_H];
        private final int[] mHorseColorBuf = new int[HORSE_BUF_W * HORSE_BUF_H];

        private static final int FOOT_BUF_W = 64;
        private static final int FOOT_BUF_H = 58;
        private final char[] mFootGlyphBuf = new char[FOOT_BUF_W * FOOT_BUF_H];
        private final float[] mFootLumBuf = new float[FOOT_BUF_W * FOOT_BUF_H];
        private final int[] mFootColorBuf = new int[FOOT_BUF_W * FOOT_BUF_H];
        private final float[] mFootZBuf = new float[FOOT_BUF_W * FOOT_BUF_H];
        private static final float HERO_COLS_PER_UNIT = 24.0f;
        private static final float HERO_ROWS_PER_UNIT = 24.0f / 1.3f;
        private static final float HERO_UNIT_PPU = 0.98f;
        private float mHLastT = 0.0f, mHWalk = 0.0f, mHRun = 0.0f, mHRec = 0.0f;
        private float mHSfx = -0.78f, mHSfy = 0.62f;

        private static final int ENEMY_BUF_W = 42;
        private static final int ENEMY_BUF_H = 48;
        private final char[] mEnemyGlyphBuf = new char[ENEMY_BUF_W * ENEMY_BUF_H];
        private final float[] mEnemyLumBuf = new float[ENEMY_BUF_W * ENEMY_BUF_H];
        private final int[] mEnemyColorBuf = new int[ENEMY_BUF_W * ENEMY_BUF_H];

        private static final int NUM_ENEMIES = 8;
        private final float[] mEnemyX = new float[NUM_ENEMIES];
        private final float[] mEnemyY = new float[NUM_ENEMIES];
        private final float[] mEnemyHomeX = new float[NUM_ENEMIES];
        private final float[] mEnemyHomeY = new float[NUM_ENEMIES];
        private final float[] mEnemyFacingX = new float[NUM_ENEMIES];
        private final float[] mEnemyFacingY = new float[NUM_ENEMIES];
        private final float[] mEnemyGait = new float[NUM_ENEMIES];
        private final float[] mEnemyAtkWindup = new float[NUM_ENEMIES];
        private final float[] mEnemyAtkCooldown = new float[NUM_ENEMIES];
        private final boolean[] mEnemyAggro = new boolean[NUM_ENEMIES];
        private final int[] mEnemyHp = new int[NUM_ENEMIES];
        private final int[] mEnemyMaxHp = new float[NUM_ENEMIES].length > 0 ? new int[NUM_ENEMIES] : new int[0];
        private final float[] mEnemyHurt = new float[NUM_ENEMIES];
        private final int[] mEnemyKind = new int[NUM_ENEMIES];

        private static final int MAX_LOOT = 16;
        private final float[] mLootX = new float[MAX_LOOT];
        private final float[] mLootY = new float[MAX_LOOT];
        private final boolean[] mLootActive = new boolean[MAX_LOOT];
        private final int[] mLootRarity = new int[MAX_LOOT];

        private static final int MAX_PARTICLES = 64;
        private final float[] mPartX = new float[MAX_PARTICLES];
        private final float[] mPartY = new float[MAX_PARTICLES];
        private final float[] mPartVx = new float[MAX_PARTICLES];
        private final float[] mPartVy = new float[MAX_PARTICLES];
        private final float[] mPartLife = new float[MAX_PARTICLES];
        private final int[] mPartColor = new int[MAX_PARTICLES];
        private int mPartCursor = 0;

        private int mHerbMoon = 4;
        private int mHerbCinder = 3;
        private int mHerbMoss = 3;
        private int mCinderShards = 3;
        private int mPotions = 3;

        private static final int NUM_FLORA = 14;
        private final float[] mFloraX = new float[NUM_FLORA];
        private final float[] mFloraY = new float[NUM_FLORA];
        private final int[] mFloraKind = new int[NUM_FLORA];
        private final float[] mFloraRegrow = new float[NUM_FLORA];

        private static final int NUM_FAUNA = 12;
        private final float[] mFaunaX = new float[NUM_FAUNA];
        private final float[] mFaunaY = new float[NUM_FAUNA];
        private final float[] mFaunaVx = new float[NUM_FAUNA];
        private final float[] mFaunaVy = new float[NUM_FAUNA];
        private final int[] mFaunaKind = new int[NUM_FAUNA];
        private final float[] mFaunaPhase = new float[NUM_FAUNA];

        private static final int MAX_POPUPS = 12;
        private final float[] mPopX = new float[MAX_POPUPS];
        private final float[] mPopY = new float[MAX_POPUPS];
        private final float[] mPopLife = new float[MAX_POPUPS];
        private final String[] mPopText = new String[MAX_POPUPS];
        private final int[] mPopColor = new int[MAX_POPUPS];
        private int mPopCursor = 0;

        private static final int[] METAL_COLS = {
                Color.rgb(212, 218, 226), // as forged
                Color.rgb(198, 206, 214), // Iron
                Color.rgb(228, 234, 242), // Steel
                Color.rgb(212, 156, 98),  // Bronze
                Color.rgb(242, 246, 252), // Silver
                Color.rgb(248, 214, 94),  // Gold
                Color.rgb(162, 214, 252), // Moonsteel
                Color.rgb(152, 136, 210), // Nightglass
                Color.rgb(226, 82, 90),   // Bloodiron
                Color.rgb(228, 222, 202), // Ossite
                Color.rgb(252, 152, 76)   // Emberstone
        };

        public AshveilView(Context context) {
            super(context);
            getHolder().addCallback(this);
            setFocusable(true);
            setKeepScreenOn(true);

            mAsciiPaint.setTypeface(Typeface.MONOSPACE);
            mAsciiPaint.setFakeBoldText(true);
            mGrassPaint.setStyle(Paint.Style.STROKE);
            mGrassPaint.setStrokeCap(Paint.Cap.ROUND);
            mShadowPaint.setStyle(Paint.Style.FILL);
            mUiPaint.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
            mUiSubPaint.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL));
            mPanelPaint.setStyle(Paint.Style.FILL);
            mBorderPaint.setStyle(Paint.Style.STROKE);
            mBorderPaint.setStrokeWidth(2.2f);
            mGlowPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));
            mChunkBgPaint.setStyle(Paint.Style.FILL);
            mChunkTxtPaint.setTypeface(Typeface.MONOSPACE);
            mChunkTxtPaint.setFakeBoldText(true);

            mInventory[0] = mEquippedWeapon;
            mInventory[1] = mEquippedArmor;

            for (int i = 0; i < CHUNK_CACHE_CAP; i++) {
                mChunkKeys[i] = Integer.MIN_VALUE;
            }
            mPrefs = context.getSharedPreferences("ashveil_world", Context.MODE_PRIVATE);
            long seed;
            if (mPrefs.contains("seed")) {
                seed = mPrefs.getLong("seed", 0L);
            } else {
                seed = WorldGen.randomSeed();
                mPrefs.edit().putLong("seed", seed).apply();
            }
            buildWorld(seed, true);
        }

        private void buildWorld(long seed, boolean restorePos) {
            WorldGen g = new WorldGen(seed);
            mGen = g;
            mWorldSeed = seed;
            mRng.setSeed(seed ^ 0xA5A5A5L);
            mSpriteCache.clear();
            mSpriteBase.clear();
            mSpriteOrder.clear();
            for (int i = 0; i < CHUNK_CACHE_CAP; i++) {
                mChunkKeys[i] = Integer.MIN_VALUE;
            }
            float px = g.spawnX;
            float py = g.spawnY;
            if (restorePos && mPrefs != null && mPrefs.getLong("pos_seed", Long.MIN_VALUE) == seed) {
                float sx = mPrefs.getFloat("pos_x", px);
                float sy = mPrefs.getFloat("pos_y", py);
                if (!g.blocked(sx, sy)) {
                    px = sx;
                    py = sy;
                }
            }
            mPlayerX = px;
            mPlayerY = py;
            mPlayerElevation = 0;
            mCamX = px;
            mCamY = py;
            mVelX = 0.0f;
            mVelY = 0.0f;
            initWorld();
        }

        private void requestWorld(long seed) {
            mPendingSeed = seed;
            mWorldDirty = true;
        }

        private void promptForSeed() {
            final Context ctx = getContext();
            if (!(ctx instanceof Activity)) return;
            ((Activity) ctx).runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    final EditText input = new EditText(ctx);
                    input.setInputType(InputType.TYPE_CLASS_TEXT);
                    input.setSingleLine(true);
                    input.setHint("Blank = random world");
                    new AlertDialog.Builder(ctx)
                            .setTitle("World seed")
                            .setMessage("Same seed, same world. Numbers or any text.")
                            .setView(input)
                            .setPositiveButton("Create", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface d, int which) {
                                    requestWorld(WorldGen.seedFromText(input.getText().toString()));
                                }
                            })
                            .setNegativeButton("Cancel", null)
                            .show();
                }
            });
        }

        private void saveProgress() {
            if (mPrefs == null) return;
            mPrefs.edit().putLong("seed", mWorldSeed)
                    .putLong("pos_seed", mWorldSeed)
                    .putFloat("pos_x", mPlayerX)
                    .putFloat("pos_y", mPlayerY)
                    .apply();
        }

        private Bitmap spriteFor(WorldGen.Obj o, float[] baseOut) {
            Long key = Long.valueOf(o.id);
            Bitmap b = mSpriteCache.get(key);
            if (b == null) {
                if (mSpriteBudget <= 0) return null;
                mSpriteBudget--;
                float[] base = new float[2];
                b = Gfx.buildObjectSprite(o, base);
                if (mSpriteOrder.size() >= SPRITE_CACHE_CAP) {
                    Long old = mSpriteOrder.remove(0);
                    mSpriteCache.remove(old);
                    mSpriteBase.remove(old);
                }
                mSpriteCache.put(key, b);
                mSpriteBase.put(key, base);
                mSpriteOrder.add(key);
            }
            float[] bs = mSpriteBase.get(key);
            baseOut[0] = bs[0];
            baseOut[1] = bs[1];
            return b;
        }

        private void initWorld() {
            mTailFx.reset();
            mManeFx.reset();
            for (int s = 0; s < TAIL_STRANDS; s++) {
                for (int n = 0; n < TAIL_NODES; n++) {
                    mTailX[s][n] = mTailPrevX[s][n] = mPlayerX - 1.1f - n * 0.14f;
                    mTailY[s][n] = mTailPrevY[s][n] = mPlayerY + n * 0.12f;
                }
            }
            for (int s = 0; s < MANE_STRANDS; s++) {
                for (int n = 0; n < MANE_NODES; n++) {
                    mManeX[s][n] = mManePrevX[s][n] = mPlayerX + 0.4f;
                    mManeY[s][n] = mManePrevY[s][n] = mPlayerY - 0.6f + n * 0.08f;
                }
            }
            for (int s = 0; s < HAIR_STRANDS; s++) {
                for (int n = 0; n < HAIR_NODES; n++) {
                    mHairX[s][n] = mHairPrevX[s][n] = mPlayerX - 0.1f - n * 0.10f;
                    mHairY[s][n] = mHairPrevY[s][n] = mPlayerY - 1.25f + n * 0.08f;
                }
            }
            for (int i = 0; i < NUM_ENEMIES; i++) {
                spawnEnemy(i, i < 4);
            }
            for (int i = 0; i < NUM_FLORA; i++) {
                float[] p = mGen.randomOpenPoint(mRng, mPlayerX, mPlayerY, 2.8f, 14.0f);
                mFloraX[i] = (p != null) ? p[0] : mPlayerX + 3.0f + i * 0.5f;
                mFloraY[i] = (p != null) ? p[1] : mPlayerY + 1.0f;
                mFloraKind[i] = i % 3;
                mFloraRegrow[i] = 0.0f;
            }
            for (int i = 0; i < NUM_FAUNA; i++) {
                mFaunaKind[i] = i % 4;
                float[] p = null;
                if (mFaunaKind[i] == 3) {
                    p = mGen.randomWaterPoint(mRng, mPlayerX, mPlayerY, 4.0f, 22.0f);
                    if (p == null) mFaunaKind[i] = 1;
                }
                if (p == null) p = mGen.randomOpenPoint(mRng, mPlayerX, mPlayerY, 3.2f, 14.0f);
                mFaunaX[i] = (p != null) ? p[0] : mPlayerX + 4.0f;
                mFaunaY[i] = (p != null) ? p[1] : mPlayerY + 2.0f;
                mFaunaVx[i] = (i % 2 == 0) ? 0.6f : -0.6f;
                mFaunaVy[i] = 0.2f;
                mFaunaPhase[i] = i * 1.1f;
            }
        }

        private void ensureStaticCaches() {
            if (mMeadowTileBitmap == null) {
                mMeadowTileBitmap = Gfx.grassTile(MEADOW_TILE_PX);
            }

            if (mFogTile == null) {
                mFogTile = Gfx.fogTile(0xF06L);
                for (int i = 0; i < 2; i++) {
                    mFogShader[i] = new BitmapShader(mFogTile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
                    mFogPaint[i].setShader(mFogShader[i]);
                }
            }

            if (mFogBitmap == null) {
                mFogBitmap = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888);
                Canvas fc = new Canvas(mFogBitmap);
                Paint fp = new Paint(Paint.ANTI_ALIAS_FLAG);
                fp.setShader(new RadialGradient(
                        128f, 128f, 128f,
                        Color.argb(62, 205, 222, 228),
                        Color.argb(0, 205, 222, 228),
                        Shader.TileMode.CLAMP
                ));
                fc.drawCircle(128f, 128f, 128f, fp);
            }

            if (mAmberGlowBitmap == null) {
                mAmberGlowBitmap = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888);
                Canvas ac = new Canvas(mAmberGlowBitmap);
                Paint ap = new Paint(Paint.ANTI_ALIAS_FLAG);
                ap.setShader(new RadialGradient(
                        128f, 128f, 128f,
                        new int[]{Color.argb(165, 255, 195, 88), Color.argb(70, 238, 126, 40), Color.argb(0, 0, 0, 0)},
                        new float[]{0.0f, 0.45f, 1.0f},
                        Shader.TileMode.CLAMP
                ));
                ac.drawCircle(128f, 128f, 128f, ap);
            }

            if (mCyanGlowBitmap == null) {
                mCyanGlowBitmap = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888);
                Canvas cc = new Canvas(mCyanGlowBitmap);
                Paint cp = new Paint(Paint.ANTI_ALIAS_FLAG);
                cp.setShader(new RadialGradient(
                        128f, 128f, 128f,
                        new int[]{Color.argb(140, 120, 245, 220), Color.argb(55, 60, 190, 175), Color.argb(0, 0, 0, 0)},
                        new float[]{0.0f, 0.45f, 1.0f},
                        Shader.TileMode.CLAMP
                ));
                cc.drawCircle(128f, 128f, 128f, cp);
            }

            if (mVignetteBitmap == null) {
                mVignetteBitmap = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888);
                Canvas vc = new Canvas(mVignetteBitmap);
                Paint vp = new Paint(Paint.ANTI_ALIAS_FLAG);
                vp.setShader(new RadialGradient(
                        128f, 128f, 168f,
                        new int[]{Color.argb(0, 0, 0, 0), Color.argb(30, 3, 6, 6), Color.argb(135, 2, 5, 5)},
                        new float[]{0.50f, 0.80f, 1.0f},
                        Shader.TileMode.CLAMP
                ));
                vc.drawRect(0, 0, 256, 256, vp);
            }
        }

        private boolean isCliff(float wx, float wy) {
            WorldGen g = mGen;
            if (g == null) return false;
            if (mPlayerElevation == 1) {
                float dx = (wx - mTowerRoofCx) / 3.45f;
                float dy = (wy - mTowerRoofCy) / 2.65f;
                if (Math.abs(wx - mTowerRoofCx) < 1.25f && wy > mTowerRoofCy && dy < 1.38f) {
                    return false;
                }
                return (dx * dx + dy * dy) > 1.0f;
            }
            return g.blocked(wx, wy);
        }

        private void spawnEnemy(int i, boolean close) {
            float ex, ey;
            if (i == 0) {
                ex = mGen.spawnX - 3.8f;
                ey = mGen.spawnY - 7.2f;
            } else if (i == 1) {
                ex = mGen.spawnX + 6.4f;
                ey = mGen.spawnY - 2.2f;
            } else if (i == 2) {
                ex = mGen.spawnX - 10.6f;
                ey = mGen.spawnY - 2.8f;
            } else {
                float[] p = mGen.randomOpenPoint(mRng, mPlayerX, mPlayerY, close ? 5.5f : 9.0f, close ? 13.0f : 22.0f);
                ex = (p != null) ? p[0] : mPlayerX + 5.2f + i;
                ey = (p != null) ? p[1] : mPlayerY + 3.8f;
            }
            mEnemyX[i] = ex;
            mEnemyY[i] = ey;
            mEnemyHomeX[i] = ex;
            mEnemyHomeY[i] = ey;
            mEnemyFacingX[i] = -1.0f;
            mEnemyFacingY[i] = 0.0f;
            mEnemyGait[i] = i * 0.7f;
            mEnemyAtkWindup[i] = 0.0f;
            mEnemyAtkCooldown[i] = 0.6f;
            mEnemyAggro[i] = false;
            mEnemyKind[i] = i % 4;
            mEnemyMaxHp[i] = 110 + mLevel * 14 + (i % 3) * 35;
            mEnemyHp[i] = mEnemyMaxHp[i];
            mEnemyHurt[i] = 0.0f;
        }

        private void spawnParticles(float wx, float wy, int count, int color) {
            for (int k = 0; k < count; k++) {
                int idx = mPartCursor;
                mPartCursor = (mPartCursor + 1) % MAX_PARTICLES;
                float ang = (float) ((k * 2.399f) + mTimeSec * 3.7f);
                float spd = 1.4f + (k % 4) * 0.85f;
                mPartX[idx] = wx;
                mPartY[idx] = wy;
                mPartVx[idx] = (float) Math.cos(ang) * spd;
                mPartVy[idx] = (float) Math.sin(ang) * spd - 0.6f;
                mPartLife[idx] = 0.42f + (k % 3) * 0.10f;
                mPartColor[idx] = color;
            }
        }

        private void spawnPopup(float wx, float wy, String text, int color) {
            int idx = mPopCursor;
            mPopCursor = (mPopCursor + 1) % MAX_POPUPS;
            mPopX[idx] = wx;
            mPopY[idx] = wy;
            mPopLife[idx] = 0.85f;
            mPopText[idx] = text;
            mPopColor[idx] = color;
        }

        @Override
        public void surfaceCreated(SurfaceHolder holder) {
            if (sRustLoaded && mRustHandle == 0) {
                try {
                    mRustHandle = nativeInit(mWorldSeed);
                } catch (Throwable ignored) {
                    mRustHandle = 0;
                }
            }
            resumeGame();
        }

        @Override
        public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        }

        @Override
        public void surfaceDestroyed(SurfaceHolder holder) {
            pauseGame();
            if (sRustLoaded && mRustHandle != 0) {
                try {
                    nativeDestroy(mRustHandle);
                } catch (Throwable ignored) {
                }
                mRustHandle = 0;
            }
        }

        public void resumeGame() {
            if (mRunning) return;
            if (mThread != null && mThread.isAlive()) {
                try {
                    mThread.join(400);
                } catch (InterruptedException ignored) {
                }
            }
            mRunning = true;
            mThread = new Thread(this, "AshveilRenderLoop");
            mThread.setPriority(Thread.MAX_PRIORITY);
            mThread.start();
        }

        public void pauseGame() {
            saveProgress();
            mRunning = false;
            if (mThread != null) {
                try {
                    mThread.join(400);
                } catch (InterruptedException ignored) {
                }
                if (!mThread.isAlive()) mThread = null;
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            int action = event.getActionMasked();
            int idx = event.getActionIndex();
            int pointerId = event.getPointerId(idx);
            float x = event.getX(idx);
            float y = event.getY(idx);
            float w = Math.max(1.0f, getWidth());
            float h = Math.max(1.0f, getHeight());

            if (sRustLoaded && mRustHandle != 0) {
                try {
                    nativeTouch(mRustHandle, action, pointerId, x / w, y / h);
                } catch (Throwable ignored) {
                }
            }

            if (mScreenMode == 0) {
                if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                    handleStartMenuTap(x, y, w, h);
                }
                return true;
            }

            if (mScreenMode == 2) {
                if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                    handleModalTap(x, y, w, h);
                }
                return true;
            }

            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                float boxH = Math.min(h * 0.14f, 156.0f);
                float pillW = Math.min(w * 0.18f, 172.0f);
                float pillH = Math.max(36.0f, boxH * 0.34f);
                float px = w - pillW - 18.0f;
                float y0 = 18.0f;

                if (x >= px && x <= px + pillW) {
                    if (y >= y0 && y <= y0 + pillH) {
                        mMovePointerId = -1;
                        mInputX = 0.0f;
                        mInputY = 0.0f;
                        mScreenMode = 0;
                        return true;
                    }
                    float py2 = y0 + pillH + 8.0f;
                    if (y >= py2 && y <= py2 + pillH) {
                        mZoomPreset = (mZoomPreset + 1) % 3;
                        mCameraZoom = (mZoomPreset == 0) ? 1.48f : (mZoomPreset == 1 ? 1.15f : 0.78f);
                        showBanner(mZoomPreset == 0 ? "Camera: Close-up (Chainmail Detail)" : (mZoomPreset == 1 ? "Camera: Medium" : "Camera: Wide"));
                        return true;
                    }
                    float py3 = py2 + pillH + 8.0f;
                    if (y >= py3 && y <= py3 + pillH) {
                        if (mPlayerElevation == 1) {
                            showBanner("Step down from the Watchtower to mount steed");
                            return true;
                        }
                        mMounted = !mMounted;
                        mTailFx.reset();
                        mManeFx.reset();
                        spawnParticles(mPlayerX, mPlayerY, 14, Color.rgb(220, 235, 228));
                        showBanner(mMounted ? "Mounted White Steed" : "Dismounted (Senje Foot Knight)");
                        return true;
                    }
                }

                if (x < w * 0.34f && y < h * 0.18f) {
                    mMovePointerId = -1;
                    mInputX = 0.0f;
                    mInputY = 0.0f;
                    mScreenMode = 2;
                    return true;
                }

                float hbW = hbWidth(w, h);
                float hbX = (w - hbW) * 0.5f;
                float hbY = h - hbSlotH(hbW);
                if (y >= hbY && y <= h && x >= hbX && x <= hbX + hbW) {
                    float slotW = hbW / 10.0f;
                    int slotIdx = (int) ((x - hbX) / slotW);
                    if (slotIdx == 0) {
                        if (mPotions > 0 && mHp < mMaxHp) {
                            mPotions--;
                            mHp = Math.min(mMaxHp, mHp + 450);
                            mMp = Math.min(mMaxMp, mMp + 60);
                            spawnParticles(mPlayerX, mPlayerY - 0.2f, 12, Color.rgb(145, 245, 200));
                            spawnPopup(mPlayerX, mPlayerY - 0.9f, "+450 HP", Color.rgb(145, 245, 200));
                        } else if (mPotions <= 0) {
                            showBanner("No Healing Draughts left (craft in Forge)");
                        }
                    } else if (slotIdx == 1) {
                        mScreenMode = 2;
                    }
                    return true;
                }

                float atkR = Math.min(w, h) * 0.088f;
                float atkCx = w - atkR - 26.0f;
                float atkCy = h - atkR - 26.0f - btnLift(w, h);
                float dxA = x - atkCx;
                float dyA = y - atkCy;
                if (dxA * dxA + dyA * dyA <= (atkR * 1.25f) * (atkR * 1.25f)) {
                    triggerSlash();
                    return true;
                }

                float dodgeR = Math.min(w, h) * 0.070f;
                float dodgeCx = atkCx - atkR - dodgeR - 22.0f;
                float dodgeCy = h - dodgeR - 26.0f - btnLift(w, h);
                float dxD = x - dodgeCx;
                float dyD = y - dodgeCy;
                if (dxD * dxD + dyD * dyD <= (dodgeR * 1.25f) * (dodgeR * 1.25f)) {
                    triggerDodge();
                    return true;
                }

                if (x < w * 0.50f) {
                    mMovePointerId = pointerId;
                    mJoyBaseX = x;
                    mJoyBaseY = y;
                    mJoyCurrX = x;
                    mJoyCurrY = y;
                    mInputX = 0.0f;
                    mInputY = 0.0f;
                } else {
                    mCursorX = x / w;
                    mCursorY = y / h;
                    if (!mAttackButtonOnly) {
                        triggerSlash();
                    }
                }
            } else if (action == MotionEvent.ACTION_MOVE) {
                int count = event.getPointerCount();
                for (int i = 0; i < count; i++) {
                    int pId = event.getPointerId(i);
                    float px = event.getX(i);
                    float py = event.getY(i);
                    if (pId == mMovePointerId) {
                        mJoyCurrX = px;
                        mJoyCurrY = py;
                        float dx = px - mJoyBaseX;
                        float dy = py - mJoyBaseY;
                        float maxR = Math.min(w, h) * 0.14f;
                        float len = (float) Math.sqrt(dx * dx + dy * dy);
                        if (len > 4.0f) {
                            float mag = Math.min(1.0f, len / maxR);
                            mInputX = (dx / len) * mag;
                            mInputY = (dy / len) * mag;
                        } else {
                            mInputX = 0.0f;
                            mInputY = 0.0f;
                        }
                    } else {
                        mCursorX = px / w;
                        mCursorY = py / h;
                    }
                }
            } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP || action == MotionEvent.ACTION_CANCEL) {
                if (pointerId == mMovePointerId) {
                    mMovePointerId = -1;
                    mInputX = 0.0f;
                    mInputY = 0.0f;
                }
            }
            return true;
        }

        private float hbWidth(float w, float h) {
            return Math.min(w, Math.max(w * 0.46f, h * 0.9f));
        }

        private float btnLift(float w, float h) {
            float hw = hbWidth(w, h);
            return (hw > w * 0.7f) ? hbSlotH(hw) + 30.0f : 0.0f;
        }

        private float hbSlotH(float hbW) {
            return Math.min(hbW / 10.0f * 0.8f, 92.0f);
        }

        private static final float[] MENU_TOPS = {0.33f, 0.425f, 0.52f, 0.615f, 0.71f, 0.805f};
        private static final float MENU_H = 0.078f;

        private void handleStartMenuTap(float x, float y, float w, float h) {
            if (x < w * 0.18f || x > w * 0.82f) return;
            int row = -1;
            for (int r = 0; r < MENU_TOPS.length; r++) {
                if (y >= h * MENU_TOPS[r] && y <= h * (MENU_TOPS[r] + MENU_H)) row = r;
            }
            if (row == 0) {
                mScreenMode = 1;
                showBanner("North: Watchtower High Ground • West: Forest & Citadel Bridges");
            } else if (row == 1) {
                if (x < w * 0.5f) {
                    requestWorld(WorldGen.randomSeed());
                } else {
                    promptForSeed();
                }
            } else if (row == 2) {
                mZoomPreset = (mZoomPreset + 1) % 3;
                mCameraZoom = (mZoomPreset == 0) ? 1.48f : (mZoomPreset == 1 ? 1.15f : 0.78f);
            } else if (row == 3) {
                mMounted = !mMounted;
                mTailFx.reset();
                mManeFx.reset();
            } else if (row == 4) {
                mAttackButtonOnly = !mAttackButtonOnly;
            } else if (row == 5) {
                mScreenMode = 2;
            }
        }

        private void handleModalTap(float x, float y, float w, float h) {
            if ((y < h * 0.05f && x > w * 0.88f) || (y > h * 0.88f && x > w * 0.72f)) {
                mScreenMode = 1;
                return;
            }
            if (y >= h * 0.05f && y <= h * 0.115f) {
                int s = (int) ((x - w * 0.04f) / ((w * 0.92f) / 7.0f));
                if (s >= 0 && s < 7) mForgeSlot = s;
                return;
            }
            if (y >= h * 0.13f && y <= h * 0.205f) {
                int r = (int) ((x - w * 0.04f) / ((w * 0.92f) / 12.0f));
                if (r == 0) {
                    mRuneSlot1 = -1;
                    mRuneSlot2 = -1;
                    showBanner("Cleared Runes");
                } else if (r > 0 && r < 12) {
                    if (mRuneSlot1 == -1) mRuneSlot1 = r;
                    else if (mRuneSlot2 == -1) mRuneSlot2 = r;
                    else {
                        mRuneSlot1 = r;
                        mRuneSlot2 = -1;
                    }
                    mStr += 1;
                    showBanner("Inscribed Rune onto Armor (+1 STR)");
                }
                return;
            }
            if (y >= h * 0.22f && y <= h * 0.31f) {
                int row = (y > h * 0.265f) ? 1 : 0;
                int cols = (row == 0) ? 6 : 5;
                int col = (int) ((x - w * 0.04f) / ((w * 0.92f) / cols));
                col = Math.max(0, Math.min(cols - 1, col));
                int idx = (row == 0) ? col : (6 + col);
                mForgeMetal = Math.max(0, Math.min(METAL_COLS.length - 1, idx));
                mForgeLevel = Math.max(mForgeLevel, idx + 1);
                showBanner("Forged Armor in " + getMetalName(mForgeMetal));
                return;
            }
            if (y > h * 0.33f && y < h * 0.85f && x < w * 0.70f) {
                if (mForgeSlot == 1) {
                    mHelmVariant = (mHelmVariant + 1) % 3;
                } else if (mForgeSlot == 5) {
                    mLegsVariant = (mLegsVariant + 1) % 3;
                }
                return;
            }
            if (y >= h * 0.88f && x <= w * 0.36f && mStatPoints > 0) {
                mStatPoints--;
                mVit += 2;
                mStr += 2;
                mDex += 1;
                mMaxHp += 48;
                mHp = mMaxHp;
                showBanner("Upgraded Stats (" + mStatPoints + " pts left)");
            } else if (y >= h * 0.88f && x > w * 0.36f && x <= w * 0.72f) {
                if (mHerbMoon >= 2 && mHerbMoss >= 1) {
                    mHerbMoon -= 2;
                    mHerbMoss -= 1;
                    mPotions++;
                    mHp = Math.min(mMaxHp, mHp + 450);
                    showBanner("Crafted Healing Draught (+450 HP)");
                } else {
                    showBanner("Need 2 Moonpetal + 1 Ashmoss");
                }
            }
        }

        private static String getMetalName(int idx) {
            String[] metals = {"as forged", "Iron", "Steel", "Bronze", "Silver", "Gold", "Moonsteel", "Nightglass", "Bloodiron", "Ossite", "Emberstone"};
            return metals[Math.max(0, Math.min(metals.length - 1, idx))];
        }

        private void showBanner(String msg) {
            mStatusBanner = msg;
            mBannerTimer = 2.8f;
        }

        private void triggerDodge() {
            if (mDodgeCooldown > 0.0f) return;
            mDodgeTimer = 0.28f;
            mDodgeCooldown = 0.82f;
            float len = (float) Math.sqrt(mInputX * mInputX + mInputY * mInputY);
            if (len > 0.15f) {
                mDodgeDirX = mInputX / len;
                mDodgeDirY = mInputY / len;
            } else {
                mDodgeDirX = mFacingX;
                mDodgeDirY = mFacingY;
            }
            mFacingX = mDodgeDirX;
            mFacingY = mDodgeDirY;
            mGhostSpawnAccum = 0.06f;
            spawnParticles(mPlayerX, mPlayerY + 0.15f, 12, Color.rgb(165, 240, 230));
        }

        private void triggerSlash() {
            if (mSlashCooldown > 0.0f) return;
            mSlashCombo = (mSlashCombo + 1) % 3;
            mSlashTimer = (mSlashCombo == 2) ? 0.38f : 0.32f;
            mSlashCooldown = 0.34f;

            spawnParticles(mPlayerX + mFacingX * 0.75f, mPlayerY + mFacingY * 0.45f - 0.25f, 10, Color.rgb(255, 175, 68));

            if (mPlayerElevation == 1) return;

            float dmg = 42 + mStr * 3 + mForgeLevel * 14 + (mSlashCombo == 2 ? 28 : 0);
            for (int i = 0; i < NUM_ENEMIES; i++) {
                float dx = mEnemyX[i] - mPlayerX;
                float dy = mEnemyY[i] - mPlayerY;
                float d2 = dx * dx + dy * dy;
                if (d2 < 3.6f * 3.6f) {
                    int dealt = (int) dmg;
                    mEnemyHp[i] -= dealt;
                    mEnemyHurt[i] = 0.24f;
                    mEnemyAggro[i] = true;
                    float len = (float) Math.sqrt(d2 + 0.001f);
                    mEnemyX[i] += (dx / len) * 0.55f;
                    mEnemyY[i] += (dy / len) * 0.55f;
                    spawnParticles(mEnemyX[i], mEnemyY[i] - 0.3f, 10, Color.rgb(255, 195, 95));
                    spawnPopup(mEnemyX[i], mEnemyY[i] - 0.8f, "-" + dealt, Color.rgb(255, 224, 125));
                    if (mEnemyHp[i] <= 0) {
                        onEnemyDefeated(i);
                    }
                }
            }
        }

        private void onEnemyDefeated(int i) {
            spawnParticles(mEnemyX[i], mEnemyY[i] - 0.2f, 18, Color.rgb(220, 235, 240));
            int gainedXp = 160 + mLevel * 28;
            int gainedGold = 45 + (i * 17) % 60;
            mXp += gainedXp;
            mGold += gainedGold;
            mCinderShards += 1;
            if (mXp >= mXpNext) {
                mXp -= mXpNext;
                mLevel++;
                mXpNext = (int) (mXpNext * 1.28f);
                mStatPoints += 3;
                mMaxHp += 95;
                mHp = mMaxHp;
                mMaxMp += 16;
                mMp = mMaxMp;
                showBanner("Level Up! LV." + mLevel + " (+3 Stat Points)");
            } else {
                showBanner("Defeated Fallen Knight (+" + gainedXp + " XP, +" + gainedGold + "g)");
            }

            for (int l = 0; l < MAX_LOOT; l++) {
                if (!mLootActive[l]) {
                    mLootActive[l] = true;
                    mLootX[l] = mEnemyX[i];
                    mLootY[l] = mEnemyY[i];
                    mLootRarity[l] = (i + mLevel) % 4;
                    break;
                }
            }
            spawnEnemy(i, false);
        }

        @Override
        public void run() {
            long lastNs = System.nanoTime();
            while (mRunning) {
                long nowNs = System.nanoTime();
                float dt = (nowNs - lastNs) / 1_000_000_000.0f;
                lastNs = nowNs;
                if (dt > 0.05f) dt = 0.05f;
                if (dt < 0.001f) dt = 0.001f;

                if (sRustLoaded && mRustHandle != 0) {
                    try {
                        nativeStep(mRustHandle, dt);
                    } catch (Throwable ignored) {
                    }
                }

                try {
                    updateSimulation(dt);
                    drawFrame();
                } catch (RuntimeException e) {
                    android.util.Log.w("Ashveil", "frame skipped: " + e);
                }

                long spentMs = (System.nanoTime() - nowNs) / 1_000_000L;
                long waitMs = 16L - spentMs;
                try {
                    Thread.sleep(waitMs > 1L ? waitMs : 1L);
                } catch (InterruptedException ignored) {
                }
            }
        }

        private void updateSimulation(float dt) {
            if (mWorldDirty) {
                mWorldDirty = false;
                buildWorld(mPendingSeed, false);
                saveProgress();
                showBanner("New world \u2022 seed " + mWorldSeed);
            }
            mTimeSec += dt;
            if (mBannerTimer > 0.0f) mBannerTimer -= dt;
            if (mSlashTimer > 0.0f) mSlashTimer -= dt;
            if (mSlashCooldown > 0.0f) mSlashCooldown -= dt;
            if (mDodgeTimer > 0.0f) mDodgeTimer -= dt;
            if (mDodgeCooldown > 0.0f) mDodgeCooldown -= dt;
            if (mPlayerHurtFlash > 0.0f) mPlayerHurtFlash -= dt;

            for (int g = 0; g < MAX_AFTERIMAGES; g++) {
                if (mGhostLife[g] > 0.0f) mGhostLife[g] -= dt;
            }

            if (mScreenMode == 0) {
                mCamX = mPlayerX + (float) Math.sin(mTimeSec * 0.25f) * 1.4f;
                mCamY = mPlayerY - 1.2f + (float) Math.cos(mTimeSec * 0.18f) * 0.9f;
                mFacingX = -0.78f;
                mFacingY = 0.62f;
                mGaitPhase += dt * 1.8f;
            } else if (mScreenMode == 1) {
                if (mDodgeTimer > 0.0f) {
                    float dashSpeed = mMounted ? 13.5f : 11.2f;
                    mVelX = mDodgeDirX * dashSpeed;
                    mVelY = mDodgeDirY * dashSpeed;
                    mGhostSpawnAccum += dt;
                    if (mGhostSpawnAccum >= 0.045f) {
                        mGhostSpawnAccum = 0.0f;
                        for (int g = 0; g < MAX_AFTERIMAGES; g++) {
                            if (mGhostLife[g] <= 0.0f) {
                                mGhostX[g] = mPlayerX;
                                mGhostY[g] = mPlayerY;
                                mGhostLife[g] = 0.24f;
                                break;
                            }
                        }
                    }
                } else {
                    float topSpeed = mMounted ? 5.6f : 3.9f;
                    float targetVx = mInputX * topSpeed;
                    float targetVy = mInputY * topSpeed;
                    float accel = Math.min(1.0f, dt * 11.0f);
                    mVelX += (targetVx - mVelX) * accel;
                    mVelY += (targetVy - mVelY) * accel;
                }

                float nx = mPlayerX + mVelX * dt;
                float ny = mPlayerY + mVelY * dt;
                if (!isCliff(nx, mPlayerY)) mPlayerX = nx;
                if (!isCliff(mPlayerX, ny)) mPlayerY = ny;

                // --- WATCHTOWER HIGH GROUND ELEVATION TRANSITION (matching 1000461712.mp4 00:06-00:13!) ---
                WorldGen gen = mGen;
                if (gen != null) {
                    if (mPlayerElevation == 0) {
                        WorldGen.Obj tw = gen.findWatchtowerNear(mPlayerX, mPlayerY, 5.2f);
                        if (tw != null) {
                            float dx = mPlayerX - tw.x;
                            float dy = mPlayerY - tw.y;
                            if (Math.abs(dx) < 1.35f && dy > 0.3f && dy < 3.0f && mVelY < 0.1f) {
                                mPlayerElevation = 1;
                                mMounted = false;
                                mTowerRoofCx = tw.x;
                                mTowerRoofCy = tw.y - 3.1f;
                                mTowerBaseY = tw.y;
                                mPlayerX = tw.x;
                                mPlayerY = mTowerRoofCy + 1.25f;
                                spawnParticles(mPlayerX, mPlayerY, 16, Color.rgb(255, 195, 95));
                                showBanner("Tower High Ground • Protected from Ground Enemies");
                            }
                        }
                    } else if (mPlayerElevation == 1) {
                        float dx = mPlayerX - mTowerRoofCx;
                        float dy = mPlayerY - mTowerRoofCy;
                        if (Math.abs(dx) < 1.30f && dy > 2.35f && mVelY > 0.0f) {
                            mPlayerElevation = 0;
                            mPlayerX = mTowerRoofCx;
                            mPlayerY = mTowerBaseY + 3.4f;
                            showBanner("Descended from Watchtower");
                        }
                    }
                }

                float spd = (float) Math.sqrt(mVelX * mVelX + mVelY * mVelY);
                if (spd > 0.25f) {
                    mFacingX = mVelX / spd;
                    mFacingY = mVelY / spd;
                    if (mMounted) {
                        mGaitPhase += dt * (5.2f + spd * 2.1f);
                    } else {
                        mGaitPhase += Math.min(spd, 5.0f) * dt * 6.2831853f / heroCycleDist(spd);
                    }
                } else {
                    mGaitPhase += dt * 1.6f;
                }

                mCamX += (mPlayerX - mCamX) * Math.min(1.0f, dt * 8.0f);
                mCamY += (mPlayerY - mCamY) * Math.min(1.0f, dt * 8.0f);

                for (int f = 0; f < NUM_FLORA; f++) {
                    float fdx0 = mFloraX[f] - mPlayerX;
                    float fdy0 = mFloraY[f] - mPlayerY;
                    if (fdx0 * fdx0 + fdy0 * fdy0 > 38.0f * 38.0f) {
                        float[] np = mGen.randomOpenPoint(mRng, mPlayerX + mVelX * 2.0f, mPlayerY + mVelY * 2.0f, 10.0f, 24.0f);
                        if (np != null) {
                            mFloraX[f] = np[0];
                            mFloraY[f] = np[1];
                            mFloraRegrow[f] = 0.0f;
                        }
                    }
                    if (mFloraRegrow[f] > 0.0f) {
                        mFloraRegrow[f] -= dt;
                    } else if (mPlayerElevation == 0) {
                        float dx = mFloraX[f] - mPlayerX;
                        float dy = mFloraY[f] - mPlayerY;
                        if (dx * dx + dy * dy < 1.05f * 1.05f) {
                            mFloraRegrow[f] = 18.0f;
                            if (mFloraKind[f] == 0) {
                                mHerbMoon++;
                                spawnPopup(mFloraX[f], mFloraY[f] - 0.5f, "+1 Moonpetal", Color.rgb(175, 225, 255));
                            } else if (mFloraKind[f] == 1) {
                                mHerbCinder++;
                                spawnPopup(mFloraX[f], mFloraY[f] - 0.5f, "+1 Cinderbloom", Color.rgb(255, 185, 105));
                            } else {
                                mHerbMoss++;
                                spawnPopup(mFloraX[f], mFloraY[f] - 0.5f, "+1 Ashmoss", Color.rgb(145, 240, 170));
                            }
                            spawnParticles(mFloraX[f], mFloraY[f], 8, Color.rgb(210, 248, 220));
                        }
                    }
                }

                for (int a = 0; a < NUM_FAUNA; a++) {
                    mFaunaPhase[a] += dt * (mFaunaKind[a] == 1 ? 7.5f : 4.2f);
                    float fdx = mFaunaX[a] - mPlayerX;
                    float fdy = mFaunaY[a] - mPlayerY;
                    if (fdx * fdx + fdy * fdy > 34.0f * 34.0f) {
                        float[] np = (mFaunaKind[a] == 3)
                                ? mGen.randomWaterPoint(mRng, mPlayerX, mPlayerY, 6.0f, 24.0f)
                                : mGen.randomOpenPoint(mRng, mPlayerX + mVelX * 2.0f, mPlayerY + mVelY * 2.0f, 10.0f, 22.0f);
                        if (np != null) {
                            mFaunaX[a] = np[0];
                            mFaunaY[a] = np[1];
                        }
                    }
                    if (mFaunaKind[a] == 3) {
                        float nxK = mFaunaX[a] + mFaunaVx[a] * dt;
                        float nyK = mFaunaY[a] + mFaunaVy[a] * dt;
                        if (mGen.waterDepth(nxK, nyK) > 0.06f) {
                            mFaunaX[a] = nxK;
                            mFaunaY[a] = nyK;
                        } else {
                            mFaunaVx[a] = -mFaunaVx[a] + (float) Math.sin(mFaunaPhase[a]) * 0.3f;
                            mFaunaVy[a] = -mFaunaVy[a] + (float) Math.cos(mFaunaPhase[a]) * 0.3f;
                        }
                    } else {
                        float dx = mFaunaX[a] - mPlayerX;
                        float dy = mFaunaY[a] - mPlayerY;
                        float d2 = dx * dx + dy * dy;
                        if (mPlayerElevation == 0 && d2 < 3.5f * 3.5f) {
                            float d = (float) Math.sqrt(d2 + 0.001f);
                            float fleeSpd = (mFaunaKind[a] == 2) ? 4.4f : 3.4f;
                            mFaunaVx[a] = (dx / d) * fleeSpd;
                            mFaunaVy[a] = (dy / d) * fleeSpd;
                        } else if (((int) (mTimeSec * 2.0f + a)) % 7 == 0) {
                            mFaunaVx[a] = (float) Math.cos(mTimeSec * 0.8f + a) * 0.65f;
                            mFaunaVy[a] = (float) Math.sin(mTimeSec * 0.7f + a) * 0.65f;
                        }
                        float nxF = mFaunaX[a] + mFaunaVx[a] * dt;
                        float nyF = mFaunaY[a] + mFaunaVy[a] * dt;
                        if (mFaunaKind[a] == 2 || !mGen.blocked(nxF, nyF)) {
                            mFaunaX[a] = nxF;
                            mFaunaY[a] = nyF;
                        } else {
                            mFaunaVx[a] = -mFaunaVx[a];
                            mFaunaVy[a] = -mFaunaVy[a];
                        }
                    }
                }

                for (int l = 0; l < MAX_LOOT; l++) {
                    if (mLootActive[l]) {
                        float dx = mLootX[l] - mPlayerX;
                        float dy = mLootY[l] - mPlayerY;
                        if (dx * dx + dy * dy < 1.15f * 1.15f) {
                            mLootActive[l] = false;
                            String[] pool = {
                                    "Emberstone Greatsword",
                                    "Bloody Mail Coif",
                                    "Dark Greaves of the Abyss",
                                    "Crimson Surcoat of Senje",
                                    "Moonsteel Signet Ring"
                            };
                            String item = pool[mLootRarity[l] % pool.length] + " +" + (1 + mLevel / 4);
                            if (mInvCount < mInventory.length) {
                                mInventory[mInvCount++] = item;
                            }
                            mEquippedWeapon = item;
                            showBanner("Equipped: " + item);
                        }
                    }
                }

                for (int i = 0; i < NUM_ENEMIES; i++) {
                    if (mEnemyHurt[i] > 0.0f) mEnemyHurt[i] -= dt;
                    if (mEnemyAtkCooldown[i] > 0.0f) mEnemyAtkCooldown[i] -= dt;

                    float dx = mPlayerX - mEnemyX[i];
                    float dy = mPlayerY - mEnemyY[i];
                    float dist = (float) Math.sqrt(dx * dx + dy * dy + 0.001f);

                    if (mPlayerElevation == 1) {
                        mEnemyAggro[i] = false;
                        float patrolAng = mTimeSec * 0.48f + i * 1.57f;
                        float tx = mEnemyHomeX[i] + (float) Math.cos(patrolAng) * 2.4f;
                        float ty = mEnemyHomeY[i] + (float) Math.sin(patrolAng) * 1.8f;
                        float hx = tx - mEnemyX[i];
                        float hy = ty - mEnemyY[i];
                        float hd = (float) Math.sqrt(hx * hx + hy * hy + 1e-4f);
                        mEnemyFacingX[i] = hx / hd;
                        mEnemyFacingY[i] = hy / hd;
                        mEnemyGait[i] += dt * 4.5f;
                        float nex = mEnemyX[i] + mEnemyFacingX[i] * 1.10f * dt;
                        float ney = mEnemyY[i] + mEnemyFacingY[i] * 1.10f * dt;
                        if (!mGen.blocked(nex, ney)) {
                            mEnemyX[i] = nex;
                            mEnemyY[i] = ney;
                        }
                        continue;
                    }

                    if (!mEnemyAggro[i] && dist < 5.6f) {
                        mEnemyAggro[i] = true;
                    } else if (mEnemyAggro[i] && dist > 11.0f) {
                        mEnemyAggro[i] = false;
                    }

                    if (!mEnemyAggro[i]) {
                        float patrolAng = mTimeSec * 0.35f + i * 1.9f;
                        float tx = mEnemyHomeX[i] + (float) Math.cos(patrolAng) * 1.8f;
                        float ty = mEnemyHomeY[i] + (float) Math.sin(patrolAng) * 1.4f;
                        float hx = tx - mEnemyX[i];
                        float hy = ty - mEnemyY[i];
                        float hd = (float) Math.sqrt(hx * hx + hy * hy);
                        if (hd > 0.25f) {
                            mEnemyFacingX[i] = hx / hd;
                            mEnemyFacingY[i] = hy / hd;
                            mEnemyGait[i] += dt * 4.2f;
                            float nex = mEnemyX[i] + mEnemyFacingX[i] * 1.05f * dt;
                            float ney = mEnemyY[i] + mEnemyFacingY[i] * 1.05f * dt;
                            if (!mGen.blocked(nex, ney)) {
                                mEnemyX[i] = nex;
                                mEnemyY[i] = ney;
                            }
                        } else {
                            mEnemyGait[i] += dt * 1.2f;
                        }
                        continue;
                    }

                    mEnemyFacingX[i] = dx / dist;
                    mEnemyFacingY[i] = dy / dist;

                    if (mEnemyAtkWindup[i] > 0.0f) {
                        mEnemyAtkWindup[i] -= dt;
                        if (mEnemyAtkWindup[i] <= 0.0f) {
                            if (dist < 2.15f && mDodgeTimer <= 0.0f) {
                                int enemyDmg = 18 + mLevel * 2 + (mEnemyKind[i] * 5);
                                mHp -= enemyDmg;
                                mPlayerHurtFlash = 0.22f;
                                spawnParticles(mPlayerX, mPlayerY - 0.2f, 10, Color.rgb(245, 78, 78));
                                spawnPopup(mPlayerX, mPlayerY - 0.9f, "-" + enemyDmg, Color.rgb(255, 88, 88));
                                if (mHp <= 0) {
                                    mHp = mMaxHp;
                                    mPlayerX = mGen.spawnX;
                                    mPlayerY = mGen.spawnY;
                                    mPlayerElevation = 0;
                                    showBanner("Revived at Ashveil Crossroads");
                                }
                            } else if (dist < 2.15f && mDodgeTimer > 0.0f) {
                                spawnPopup(mPlayerX, mPlayerY - 0.9f, "DODGED!", Color.rgb(150, 245, 230));
                            }
                            mEnemyAtkCooldown[i] = 1.25f;
                        }
                    } else if (dist > 1.45f) {
                        mEnemyGait[i] += dt * 8.2f;
                        float ex = mEnemyX[i] + mEnemyFacingX[i] * 1.90f * dt;
                        float ey = mEnemyY[i] + mEnemyFacingY[i] * 1.90f * dt;
                        if (!mGen.blocked(ex, ey)) {
                            mEnemyX[i] = ex;
                            mEnemyY[i] = ey;
                        }
                    } else if (mEnemyAtkCooldown[i] <= 0.0f) {
                        mEnemyAtkWindup[i] = 0.42f;
                    }
                }
            }

            if (((int) (mTimeSec * 60.0f)) % 7 == 0) {
                float fx = mCamX + ((float) Math.sin(mTimeSec * 3.1f) * 6.5f);
                float fy = mCamY + ((float) Math.cos(mTimeSec * 2.3f) * 4.5f);
                boolean ember = (((int) (mTimeSec * 15.0f)) % 3 == 0);
                if (ember) {
                    spawnParticles(mBladeWorldX, mBladeWorldY, 1, Color.rgb(255, 178, 66));
                } else {
                    spawnParticles(fx, fy, 1, Color.rgb(245, 242, 220));
                }
            }

            for (int pIdx = 0; pIdx < MAX_PARTICLES; pIdx++) {
                if (mPartLife[pIdx] > 0.0f) {
                    mPartLife[pIdx] -= dt;
                    mPartX[pIdx] += mPartVx[pIdx] * dt;
                    mPartY[pIdx] += mPartVy[pIdx] * dt;
                }
            }
            for (int k = 0; k < MAX_POPUPS; k++) {
                if (mPopLife[k] > 0.0f) {
                    mPopLife[k] -= dt;
                    mPopY[k] -= 0.9f * dt;
                }
            }

            mCoifRot += dt * 1.15f;
            updateVerletHairAndCloak(dt);
            if (mMounted) {
                rasterizeHorseAndRiderAscii();
            } else {
                rasterizeFootKnightAscii();
            }
        }

        private void updateVerletHairAndCloak(float dt) {
            float windMult = (mWindPreset == 0) ? 0.55f : (mWindPreset == 1 ? 1.0f : 1.75f);
            float windX = (float) Math.sin(mTimeSec * 2.1f) * 4.2f * windMult - mVelX * 0.50f;
            float windY = (float) Math.cos(mTimeSec * 1.6f) * 1.8f * windMult + 1.2f;

            float tailAnchorX = mPlayerX + mTailLocX;
            float tailAnchorY = mPlayerY + mTailLocY;
            stepVerletChain(mTailX, mTailY, mTailPrevX, mTailPrevY, TAIL_STRANDS, TAIL_NODES,
                    tailAnchorX, tailAnchorY, 0.14f, windX, windY, dt, 0.06f);

            float neckX = mPlayerX + mManeLocX;
            float neckY = mPlayerY + mManeLocY;
            stepVerletChain(mManeX, mManeY, mManePrevX, mManePrevY, MANE_STRANDS, MANE_NODES,
                    neckX, neckY, 0.085f, windX * 0.7f, windY * 0.8f, dt, 0.045f);

            if (mMounted) {
                float spd2 = (float) Math.sqrt(mVelX * mVelX + mVelY * mVelY);
                float fl = (float) Math.sqrt(mFacingX * mFacingX + mFacingY * mFacingY) + 1e-5f;
                float fdx = mFacingX / fl;
                float fdy = mFacingY / fl;
                float airX = -mVelX * 0.55f + windMult * 1.1f + (float) Math.sin(mTimeSec * 0.8f) * 0.8f;
                float airY = -mVelY * 0.35f + (float) Math.cos(mTimeSec * 0.7f) * 0.5f;
                float gallop = Math.min(1.0f, spd2 / 4.6f);
                mTailFx.step(dt, mPlayerX + mTailLocX, mPlayerY + mTailLocY - 0.04f,
                        mPlayerX + mTailLocX - fdx * 0.08f, mPlayerY + mTailLocY + 0.06f,
                        -fdx, -fdy * 0.4f + 0.25f, 8.5f + gallop * 6.0f, 3.2f, airX, airY,
                        2.2f + gallop * 1.6f, 0.48f, mTimeSec);
                mManeFx.step(dt, mPlayerX + mNeckTopLocX, mPlayerY + mNeckTopLocY,
                        mPlayerX + mNeckBaseLocX, mPlayerY + mNeckBaseLocY,
                        -fdx, 0.35f, 7.0f + gallop * 5.0f, 2.8f, airX * 0.85f, airY * 0.85f,
                        1.9f + gallop * 1.4f, 0.36f, mTimeSec);
            }
        }

        private void stepVerletChain(
                float[][] x, float[][] y, float[][] px, float[][] py,
                int strands, int nodes, float ax, float ay, float segLen,
                float windX, float windY, float dt, float spread
        ) {
            float dt2 = dt * dt;
            for (int s = 0; s < strands; s++) {
                float sOff = (s - strands * 0.5f) * spread;
                x[s][0] = ax + sOff * 0.35f;
                y[s][0] = ay + Math.abs(sOff) * 0.25f;
                for (int n = 1; n < nodes; n++) {
                    float vx = (x[s][n] - px[s][n]) * 0.91f;
                    float vy = (y[s][n] - py[s][n]) * 0.91f;
                    px[s][n] = x[s][n];
                    py[s][n] = y[s][n];
                    float gust = (float) Math.sin(mTimeSec * 4.2f + s * 0.9f + n * 0.5f) * 0.9f;
                    x[s][n] += vx + (windX + gust) * dt2;
                    y[s][n] += vy + windY * dt2;
                }
                for (int iter = 0; iter < 3; iter++) {
                    x[s][0] = ax + sOff * 0.35f;
                    y[s][0] = ay + Math.abs(sOff) * 0.25f;
                    for (int n = 0; n < nodes - 1; n++) {
                        int j = n + 1;
                        float dx = x[s][j] - x[s][n];
                        float dy = y[s][j] - y[s][n];
                        float dist = (float) Math.sqrt(dx * dx + dy * dy + 1e-6f);
                        float diff = (dist - segLen) / dist;
                        if (n == 0) {
                            x[s][j] -= dx * diff;
                            y[s][j] -= dy * diff;
                        } else {
                            x[s][n] += dx * diff * 0.30f;
                            y[s][n] += dy * diff * 0.30f;
                            x[s][j] -= dx * diff * 0.70f;
                            y[s][j] -= dy * diff * 0.70f;
                        }
                    }
                }
            }
        }

        // =========================================================================
        // ANIMATION HELPERS (shared by hero + horse rigs)
        // =========================================================================
        private static final float DODGE_DUR = 0.28f;
        private float mRotC = 1.0f, mRotS = 0.0f, mRotPx = 0.0f, mRotPy = 0.0f;
        private float mRtx, mRty;
        private float mFootOff, mFootLift;
        private float mHeadLocX = 0.0f, mHeadLocY = -0.65f;
        private float mManeLocX = 0.45f, mManeLocY = -0.65f;
        private float mTailLocX = -0.65f, mTailLocY = -0.10f;

        private static float smooth01(float a, float b, float x) {
            float t = Math.max(0.0f, Math.min(1.0f, (x - a) / (b - a)));
            return t * t * (3.0f - 2.0f * t);
        }

        private static float mixF(float a, float b, float t) {
            return a + (b - a) * t;
        }

        private void rotPt(float x, float y) {
            float dx = x - mRotPx;
            float dy = y - mRotPy;
            float rx = mRotPx + dx * mRotC - dy * mRotS;
            float ry = mRotPy + dx * mRotS + dy * mRotC;
            mRtx = rx;
            mRty = mRotPy + (ry - mRotPy) * mRotSy + mRotDy;
        }

        private void hcap(float ax, float ay, float bx, float by, float r, float lum, int tone) {
            plotHorseCap(ax, ay, bx, floatBy(by), r, lum, tone);
        }

        private static float floatBy(float v) {
            return v;
        }

        private void footCycle(float theta, float duty, float stride, float liftMax) {
            float u = theta / 6.2831853f;
            u -= (float) Math.floor(u);
            if (u < duty) {
                mFootOff = stride * (1.0f - 2.0f * u / duty);
                mFootLift = 0.0f;
            } else {
                float s = (u - duty) / (1.0f - duty);
                float e = s * s * (3.0f - 2.0f * s);
                mFootOff = -stride + 2.0f * stride * e;
                mFootLift = (float) Math.sin(Math.PI * s) * liftMax;
            }
        }

        private void legKnee(float hx, float hy, float fx, float fy, float l1, float l2,
                             float bendSign, float bendScale) {
            float dx = fx - hx;
            float dy = fy - hy;
            float d = (float) Math.sqrt(dx * dx + dy * dy + 1e-6f);
            float dc = Math.min(d, l1 + l2 - 0.01f);
            float a = (l1 * l1 - l2 * l2 + dc * dc) / (2.0f * dc);
            float h = (float) Math.sqrt(Math.max(0.0f, l1 * l1 - a * a)) * bendScale;
            float ux = dx / d;
            float uy = dy / d;
            float nx = -uy;
            float ny = ux;
            if (nx * bendSign < 0.0f) {
                nx = -nx;
                ny = -ny;
            }
            mRtx = hx + ux * a + nx * h;
            mRty = hy + uy * a + ny * h;
        }

        // =========================================================================
        // 1:1 VIDEO-ACCURATE HERO ("Senje" from hero_chainmail.png & tower_rooftop.png):
        //   - Clean hooded 3D Chainmail Coif & wide Bishop's Mantle (TONE_CHAINMAIL)
        //   - Full ankle-length Deep Crimson Surcoat / Robe with horizontal grid bands (TONE_SURCOAT)
        //   - Bright Silver-Rimmed Dark Greaves along the outer leg contour (TONE_GREAVES)
        //   - Shadowed Dark Train behind the lower robe (TONE_CLOAK)
        //   - Blazing Ember Greatsword held diagonally down-left or sweeping through 3-stage cleave/360-spin
        // =========================================================================
        // ===== HERO RIG BEGIN =====
        private float mFootHeel = 0.0f, mFootPitch = 0.0f;
        private final float[] mHKneeX = new float[2], mHKneeY = new float[2], mHAnkX = new float[2], mHAnkY = new float[2];
        private final float[] mHToeX = new float[2], mHToeY = new float[2], mHHipX = new float[2], mHHipY = new float[2];
        private float mDirX = 0.0f, mDirY = 0.0f;
        private float mRotSy = 1.0f, mRotDy = 0.0f;
        private float mRigBladeAx = -0.25f, mRigBladeAy = 0.05f, mRigBladeBx = -0.68f, mRigBladeBy = 0.48f;

        private static final int TONE_CHAINMAIL = 0; // Bloody Mail Coif & Shoulder Mantle
        private static final int TONE_SURCOAT = 1;   // Deep Crimson Surcoat / Full Robe with grid bands
        private static final int TONE_GREAVES = 2;   // Dark Greaves with bright silver contour rim
        private static final int TONE_LEATHER = 3;   // Waist belt & grip
        private static final int TONE_CLOAK = 4;     // Shadowed lower cloak train
        private static final int TONE_FIRE = 5;      // Blazing Ember Greatsword
        private static final int TONE_VISOR = 6;     // Dark shadowed face inside coif

        private static final String CHAINMAIL_GLYPHS = "S8$#c()35@%";
        private static final String SURCOAT_GLYPHS = "#80Qo:;.|=";
        private static final String GREAVES_GLYPHS = "S8(3)c/|";
        private static final String FIRE_GLYPHS = "*+@#8S%o:.";

        private static float heroCycleDist(float spd) {
            return Math.max(0.55f, Math.min(1.65f, 0.5f + 0.55f * spd));
        }

        private void heroDir(float a, float gx, float gy) {
            float c = (float) Math.cos(a);
            mDirX = c * gx;
            mDirY = c * gy + (float) Math.sin(a);
        }

        private void heroFoot(float theta, float duty, float stride, float lift) {
            float u = theta / 6.2831853f;
            u -= (float) Math.floor(u);
            if (u < duty) {
                float q = u / duty;
                mFootOff = stride * (1.0f - 2.0f * q);
                mFootLift = 0.0f;
                mFootHeel = 0.075f * smooth01(0.72f, 1.0f, q);
                mFootPitch = 0.30f * (1.0f - smooth01(0.0f, 0.30f, q)) - 0.55f * smooth01(0.72f, 1.0f, q);
            } else {
                float s = (u - duty) / (1.0f - duty);
                float e = s * s * (3.0f - 2.0f * s);
                mFootOff = -stride + 2.0f * stride * e;
                mFootLift = (float) Math.sin(Math.PI * Math.pow(s, 0.8)) * lift;
                mFootHeel = 0.0f;
                mFootPitch = -0.55f * (1.0f - smooth01(0.0f, 0.35f, s)) + 0.30f * smooth01(0.6f, 1.0f, s);
            }
        }

        private void heroKnee(float hx, float hy, float fx, float fy, float l1, float l2, float c) {
            float dx = fx - hx;
            float dy = fy - hy;
            float d = (float) Math.sqrt(dx * dx + dy * dy + 1e-6f);
            float dc = Math.min(d, l1 + l2 - 0.01f);
            float a = (l1 * l1 - l2 * l2 + dc * dc) / (2.0f * dc);
            float h = (float) Math.sqrt(Math.max(0.0f, l1 * l1 - a * a));
            float ux = dx / d;
            float uy = dy / d;
            float nx = -uy;
            float ny = ux;
            if (nx < 0.0f) {
                nx = -nx;
                ny = -ny;
            }
            mRtx = hx + ux * a + nx * h * c;
            mRty = hy + uy * a + ny * h * c;
        }

        private void hcapH(float ax, float ay, float bx, float by, float r, float lum, float z, float edge, int tone) {
            rotPt(ax, ay);
            float tax = mRtx;
            float tay = mRty;
            rotPt(bx, by);
            plotHeroCap(tax, tay, mRtx, mRty, r, lum, z, edge, tone);
        }

        private float bladeBounceLight(float px, float py) {
            float abx = mRigBladeBx - mRigBladeAx;
            float aby = mRigBladeBy - mRigBladeAy;
            float ab2 = abx * abx + aby * aby + 1e-5f;
            float t = ((px - mRigBladeAx) * abx + (py - mRigBladeAy) * aby) / ab2;
            if (t < 0.0f) t = 0.0f;
            else if (t > 1.0f) t = 1.0f;
            float dx = px - (mRigBladeAx + t * abx);
            float dy = py - (mRigBladeAy + t * aby);
            float d = (float) Math.sqrt(dx * dx + dy * dy);
            return Math.max(0.0f, 1.0f - d / 0.44f);
        }

        private void plotHeroCap(float ax, float ay, float bx, float by, float radius, float baseLum,
                                 float z, float edge, int tone) {
            final int bufW = FOOT_BUF_W;
            final int bufH = FOOT_BUF_H;
            final float cx = bufW * 0.5f;
            final float cy = bufH * 0.55f;
            final float sx = HERO_COLS_PER_UNIT;
            final float sy = HERO_ROWS_PER_UNIT;
            int minC = Math.max(0, (int) (cx + (Math.min(ax, bx) - radius) * sx) - 1);
            int maxC = Math.min(bufW - 1, (int) (cx + (Math.max(ax, bx) + radius) * sx) + 1);
            int minR = Math.max(0, (int) (cy + (Math.min(ay, by) - radius) * sy) - 1);
            int maxR = Math.min(bufH - 1, (int) (cy + (Math.max(ay, by) + radius) * sy) + 1);
            float abx = bx - ax;
            float aby = by - ay;
            float ab2 = abx * abx + aby * aby + 1e-6f;
            float r2 = radius * radius;
            int metalBase = METAL_COLS[Math.max(0, Math.min(METAL_COLS.length - 1, mForgeMetal))];
            float mR = Color.red(metalBase) / 225.0f;
            float mG = Color.green(metalBase) / 225.0f;
            float mB = Color.blue(metalBase) / 225.0f;

            for (int r = minR; r <= maxR; r++) {
                float py = (r - cy) / sy;
                for (int c = minC; c <= maxC; c++) {
                    float px = (c - cx) / sx;
                    float t = ((px - ax) * abx + (py - ay) * aby) / ab2;
                    if (t < 0.0f) t = 0.0f;
                    else if (t > 1.0f) t = 1.0f;
                    float dx = px - (ax + t * abx);
                    float dy = py - (ay + t * aby);
                    float d2 = dx * dx + dy * dy;
                    if (d2 > r2) continue;
                    float distNorm = (float) Math.sqrt(d2) / radius;
                    float nz = (float) Math.sqrt(Math.max(0.0f, 1.0f - distNorm * distNorm));
                    float nx = dx / radius;
                    float ny = dy / radius;
                    float light = (nz * 0.68f - nx * 0.28f - ny * 0.32f + 0.18f) * baseLum;
                    if (distNorm > 0.82f && tone != TONE_GREAVES) light *= edge;
                    int idx = r * bufW + c;
                    if (z > mFootZBuf[idx] || (z == mFootZBuf[idx] && light > mFootLumBuf[idx])) {
                        mFootZBuf[idx] = z;
                        mFootLumBuf[idx] = light;
                        float ember = (tone == TONE_FIRE) ? 0.0f : bladeBounceLight(px, py);
                        int v = Math.max(38, Math.min(254, (int) (36.0f + light * 228.0f)));
                        int rr, gg, bb;

                        if (tone == TONE_CHAINMAIL) {
                            mFootGlyphBuf[idx] = CHAINMAIL_GLYPHS.charAt(((r * 7 + c * 3 + (r & 1)) & 0x7fffffff) % CHAINMAIL_GLYPHS.length());
                            rr = (int) (v * mR + ember * 105.0f);
                            gg = (int) (v * mG + ember * 44.0f);
                            bb = (int) (v * mB - ember * 20.0f);
                        } else if (tone == TONE_SURCOAT) {
                            // Horizontal grid-banded crimson surcoat matching hero_chainmail.png!
                            boolean band = (r % 3 == 0);
                            float bandMul = band ? 0.58f : 1.0f;
                            mFootGlyphBuf[idx] = band ? ':' : SURCOAT_GLYPHS.charAt(((r * 5 + c * 11) & 0x7fffffff) % SURCOAT_GLYPHS.length());
                            rr = (int) ((58 + v * 0.74f) * bandMul + ember * 115.0f);
                            gg = (int) ((10 + v * 0.12f) * bandMul + ember * 38.0f);
                            bb = (int) ((12 + v * 0.11f) * bandMul);
                        } else if (tone == TONE_GREAVES) {
                            // Bright silver-white outer contour rim on the Dark Greaves (matching hero_chainmail.png & craft_greaves.png!)
                            boolean rim = distNorm > 0.62f && (nx >= 0.05f || distNorm > 0.78f);
                            if (rim) {
                                mFootGlyphBuf[idx] = (Math.abs(nx) > 0.55f) ? 'S' : ((nx > 0) ? '8' : '(');
                                rr = (int) (226 * mR + ember * 45.0f);
                                gg = (int) (232 * mG + ember * 18.0f);
                                bb = (int) (242 * mB);
                            } else {
                                mFootGlyphBuf[idx] = GREAVES_GLYPHS.charAt(((r * 7 + c * 5) & 0x7fffffff) % GREAVES_GLYPHS.length());
                                rr = (int) ((28 + v * 0.42f) * mR + ember * 55.0f);
                                gg = (int) ((30 + v * 0.44f) * mG + ember * 20.0f);
                                bb = (int) ((36 + v * 0.48f) * mB);
                            }
                        } else if (tone == TONE_LEATHER) {
                            mFootGlyphBuf[idx] = (c % 2 == 0) ? '=' : '#';
                            rr = (int) (75 + v * 0.55f + ember * 70.0f);
                            gg = (int) (48 + v * 0.36f + ember * 28.0f);
                            bb = (int) (24 + v * 0.18f);
                        } else if (tone == TONE_CLOAK) {
                            int rampIdx = Math.max(1, Math.min(10, (int) (light * 12.0f)));
                            mFootGlyphBuf[idx] = DENSE_RAMP.charAt(rampIdx);
                            rr = (int) (12 + v * 0.18f);
                            gg = (int) (12 + v * 0.18f);
                            bb = (int) (16 + v * 0.22f);
                        } else if (tone == TONE_VISOR) {
                            mFootGlyphBuf[idx] = (c % 2 == 0) ? '.' : ':';
                            rr = (int) (16 + ember * 48.0f);
                            gg = (int) (14 + ember * 18.0f);
                            bb = 18;
                        } else {
                            // TONE_FIRE: Blazing Ember Greatsword blade (*+@#8S%o:.)
                            float flick = 0.5f + 0.5f * (float) Math.sin(mTimeSec * 22.0f + r * 0.8f + c * 0.5f);
                            float core = (1.0f - distNorm) * (0.75f + 0.25f * flick);
                            mFootGlyphBuf[idx] = FIRE_GLYPHS.charAt(Math.max(0, Math.min(FIRE_GLYPHS.length() - 1,
                                    (int) ((1.0f - core) * (FIRE_GLYPHS.length() - 1)))));
                            rr = 255;
                            gg = Math.max(78, Math.min(250, (int) (98.0f + core * 155.0f)));
                            bb = Math.max(18, Math.min(188, (int) (18.0f + core * core * 168.0f)));
                        }
                        mFootColorBuf[idx] = Color.rgb(
                                Math.max(0, Math.min(255, rr)),
                                Math.max(0, Math.min(255, gg)),
                                Math.max(0, Math.min(255, bb))
                        );
                    }
                }
            }
        }

        private void rasterizeFootKnightAscii() {
            final int total = FOOT_BUF_W * FOOT_BUF_H;
            for (int i = 0; i < total; i++) {
                mFootGlyphBuf[i] = ' ';
                mFootLumBuf[i] = -1.0f;
                mFootZBuf[i] = -9.0f;
            }
            final float PI = (float) Math.PI;
            final float t = mTimeSec;
            float dtH = Math.max(0.0f, Math.min(0.05f, t - mHLastT));
            mHLastT = t;

            float spd = (float) Math.sqrt(mVelX * mVelX + mVelY * mVelY);
            boolean dodging = mDodgeTimer > 0.0f;
            float p = dodging ? Math.max(0.0f, 1.0f - mDodgeTimer / DODGE_DUR) : 0.0f;
            mHWalk += (smooth01(0.15f, 1.5f, spd) - mHWalk) * Math.min(1.0f, dtH * 10.0f);
            mHRun += (smooth01(2.3f, 3.9f, spd) - mHRun) * Math.min(1.0f, dtH * 7.0f);
            final float walk = mHWalk;
            final float idle = 1.0f - walk;
            final float run = mHRun;

            float slashDur = (mSlashCombo == 2) ? 0.38f : 0.32f;
            float slashProg = (mSlashTimer > 0.0f) ? (1.0f - mSlashTimer / slashDur) : -1.0f;
            float slashE = slashProg >= 0.0f ? slashProg * slashProg * (3.0f - 2.0f * slashProg) : 0.0f;
            float lunge = slashProg >= 0.0f ? (float) Math.sin(Math.PI * slashProg) : 0.0f;
            float wS = slashProg >= 0.0f
                    ? smooth01(0.0f, 0.10f, slashProg) * (1.0f - smooth01(0.84f, 1.0f, slashProg)) : 0.0f;

            float fx = mFacingX;
            float fy = mFacingY;
            if (wS > 0.0f && mSlashCombo == 2) {
                float spinAng = slashE * PI * 2.0f;
                float cSp = (float) Math.cos(spinAng);
                float sSp = (float) Math.sin(spinAng);
                float rfx = fx * cSp - fy * sSp;
                float rfy = fx * sSp + fy * cSp;
                fx = rfx;
                fy = rfy;
            }

            float rate = Math.min(1.0f, dtH * 16.0f);
            mHSfx += (fx - mHSfx) * rate;
            mHSfy += (fy - mHSfy) * rate;
            final float sfx = (wS > 0.0f && mSlashCombo == 2) ? fx : mHSfx;
            final float sfy = (wS > 0.0f && mSlashCombo == 2) ? fy : mHSfy;
            final float sgn = sfx >= 0.0f ? 1.0f : -1.0f;
            final float sgnS = Math.max(-1.0f, Math.min(1.0f, sfx * 4.0f));
            final float ay = Math.min(1.0f, Math.abs(sfy));
            final float gx = sfx;
            final float gy = 0.35f * sfy;
            final float nearOff = mixF(0.45f * sgnS, 1.0f, ay);
            final float farOff = mixF(-0.45f * sgnS, -1.0f, ay);

            final float ph = mGaitPhase;
            final float breath = (float) Math.sin(t * 2.0f);
            final float breathLag = (float) Math.sin(t * 2.0f - 0.7f);
            final float shift = (float) Math.sin(t * 0.62f);

            final float k = dodging ? smooth01(0.0f, 0.17f, p) * (1.0f - smooth01(0.78f, 0.97f, p)) : 0.0f;
            if (dodging) mHRec = 1.0f;
            else mHRec = Math.max(0.0f, mHRec - dtH / 0.22f);
            final float rec = dodging ? smooth01(0.80f, 1.0f, p) : smooth01(0.0f, 1.0f, mHRec);
            final float rollAmt = Math.abs(fx) > 0.30f ? 1.0f : 0.0f;
            float ang = dodging ? sgn * 2.0f * PI * smooth01(0.10f, 0.92f, p) * rollAmt : 0.0f;
            float hop = dodging ? 0.15f * (float) Math.sin(PI * smooth01(0.06f, 0.94f, p)) : 0.0f;
            mRotC = (float) Math.cos(ang);
            mRotS = (float) Math.sin(ang);
            mRotPx = 0.05f * sgn;
            mRotPy = 0.47f;
            mRotSy = 1.0f - 0.28f * k * (1.0f - rollAmt);
            mRotDy = -hop;

            final float ground = 0.82f;
            float cycle = heroCycleDist(spd);
            float duty = 0.60f - 0.14f * run;
            float stride = 0.5f * duty * cycle * 1.08f;
            float liftMax = 0.08f + 0.10f * run;
            float bobAmp = 0.018f + 0.034f * run;
            float stepBob = bobAmp * walk * (float) Math.cos(2.0f * ph);

            float bodyY = stepBob + 0.020f * walk + 0.040f * run
                    + 0.008f * breath * idle + 0.010f * shift * shift * idle
                    + 0.08f * lunge + 0.10f * rec;
            float swayAmp = 0.035f * (0.35f + 0.65f * ay);
            float hipX = 0.020f * shift * idle + swayAmp * (float) Math.cos(ph - 1.9f) * walk;
            float hipY = -0.005f + bodyY;

            // ---------- spine ----------
            float lean = sfx * (0.015f + 0.045f * walk + 0.085f * run + 0.13f * lunge + 0.08f * rec);
            float twist = slashProg >= 0.0f ? (slashE - 0.5f) * 0.18f * sgnS : 0.0f;
            float Px = hipX, Py = hipY;
            float Wx = Px + 0.30f * lean + 0.4f * twist, Wy = Py - 0.17f;
            float Cx = Px + 0.65f * lean + 0.8f * twist, Cy = Py - 0.36f - 0.012f * breath * idle;
            float Sx = Px + lean + twist, Sy = Py - 0.50f - 0.012f * breathLag * idle;
            float Nx = Sx + 0.20f * lean, Ny = Sy - 0.06f;
            float Hx = Nx + sfx * 0.022f;
            float Hy = Ny - 0.115f - 0.5f * stepBob - 0.004f * breath * idle + 0.02f * rec;
            float Snx = Sx + nearOff * 0.18f, Sny = Sy + 0.02f;
            float Sfx = Sx + farOff * 0.18f, Sfy = Sy + 0.02f;

            // ---------- legs ----------
            final float[] kneeXs = mHKneeX, kneeYs = mHKneeY, ankXs = mHAnkX, ankYs = mHAnkY;
            final float[] toeXs = mHToeX, toeYs = mHToeY, hipXs = mHHipX, hipYs = mHHipY;
            for (int leg = 0; leg < 2; leg++) {
                boolean nl = leg == 0;
                float side = nl ? nearOff : farOff;
                float theta = ph + (nl ? 0.0f : PI);
                heroFoot(theta, duty, stride, liftMax);
                float stance = nl ? (0.10f + 0.22f * lunge) : (-0.09f - 0.14f * lunge);
                float off = mixF(stance, mFootOff + (nl ? 0.10f * lunge : 0.0f), walk);
                float lift = mFootLift * walk;
                float heel = mFootHeel * walk;
                float pitch = mFootPitch * walk;
                float hjx = hipX + side * 0.080f;
                float hjy = hipY + 0.01f;
                float ankX = hipX * 0.4f + side * 0.090f + fx * off;
                float ankY = ground - 0.05f - lift * (1.0f + 0.9f * ay) - heel + fy * off * 0.55f;
                heroKnee(hjx, hjy, ankX, ankY, 0.40f, 0.40f, sgnS);
                float knX = mRtx;
                float knY = mRty - 0.9f * lift * (1.0f - Math.abs(sgnS));
                float toeX = ankX + fx * 0.125f * (float) Math.cos(pitch);
                float toeY = ankY + 0.035f + fy * 0.035f - 0.10f * (float) Math.sin(pitch);
                hipXs[leg] = hjx; hipYs[leg] = hjy;
                kneeXs[leg] = knX; kneeYs[leg] = knY;
                ankXs[leg] = ankX; ankYs[leg] = ankY;
                toeXs[leg] = toeX; toeYs[leg] = toeY;
            }

            // ---------- arms & Blazing Ember Greatsword ----------
            final float UL = 0.26f, FL = 0.24f;
            float cw = (float) Math.cos(ph - 0.35f);
            float aF = PI * 0.5f - 0.05f + 0.02f * breathLag * idle - (0.28f * walk + 0.50f * run) * cw - 0.5f * rec;
            float bF = 0.14f + 0.02f * breath * idle + 0.15f * walk + (0.85f + 0.25f * cw) * run;

            // Default carry: greatsword held at waist/hip pointing diagonally downward-left/outward (matching hero_idle_blade.png & tower_rooftop.png!)
            float aN = mixF(1.05f + 0.02f * breathLag, 0.95f - 0.10f * cw * walk, walk);
            float bN = mixF(0.42f + 0.02f * breath, 0.50f + 0.14f * run, walk);
            heroDir(aF, gx, gy);
            float fEx = Sfx + UL * mDirX, fEy = Sfy + UL * mDirY;
            heroDir(aF - bF, gx, gy);
            float fWx = fEx + FL * mDirX, fWy = fEy + FL * mDirY;
            float fHx = fWx + 0.05f * mDirX, fHy = fWy + 0.05f * mDirY;

            heroDir(aN, gx, gy);
            float nEx = Snx + UL * mDirX, nEy = Sny + UL * mDirY;
            heroDir(aN - bN, gx, gy);
            float nWx = nEx + FL * mDirX, nWy = nEy + FL * mDirY;
            float nHx = nWx + 0.04f * mDirX, nHy = nWy + 0.04f * mDirY;

            // Greatsword direction: when idle/walking, angle diagonally down-left (-0.70, +0.66) like 1000461713.mp4 & 1000461712.mp4!
            float bdx, bdy;
            if (wS > 0.0f) {
                float aSs;
                if (mSlashCombo == 0) {
                    aSs = -1.95f + 4.10f * slashE;
                } else if (mSlashCombo == 1) {
                    aSs = 2.20f - 4.10f * slashE;
                } else {
                    aSs = 0.12f + (float) Math.sin(slashProg * PI) * 0.35f;
                }
                heroDir(aSs, gx, gy);
                bdx = mDirX;
                bdy = mDirY;
            } else {
                // Iconic diagonal downward-left carry across the crimson surcoat (or raised guard when moving right)
                float carryDirX = (sfx > 0.35f) ? 0.42f : -0.72f;
                float carryDirY = (sfx > 0.35f) ? -0.58f : 0.68f;
                float clen = (float) Math.sqrt(carryDirX * carryDirX + carryDirY * carryDirY);
                bdx = carryDirX / clen;
                bdy = carryDirY / clen;
                if (sfx <= 0.35f) {
                    nHx = Wx - 0.12f;
                    nHy = Wy + 0.04f;
                } else {
                    nHx = Cx + 0.10f;
                    nHy = Cy + 0.02f;
                }
            }
            float bladeLen = (sfx > 0.35f && wS <= 0.0f) ? 0.56f : 0.76f;
            float tipX = nHx + bdx * bladeLen, tipY = nHy + bdy * bladeLen;

            // Dodge tuck
            if (k > 0.0f) {
                Px = mixF(Px, -0.16f * sgn, k);  Py = mixF(Py, 0.62f, k);
                Wx = mixF(Wx, -0.24f * sgn, k);  Wy = mixF(Wy, 0.46f, k);
                Cx = mixF(Cx, -0.14f * sgn, k);  Cy = mixF(Cy, 0.26f, k);
                Sx = mixF(Sx, 0.04f * sgn, k);   Sy = mixF(Sy, 0.20f, k);
                Nx = mixF(Nx, 0.16f * sgn, k);   Ny = mixF(Ny, 0.27f, k);
                Hx = mixF(Hx, 0.26f * sgn, k);   Hy = mixF(Hy, 0.42f, k);
                Snx = mixF(Snx, 0.06f * sgn, k); Sny = mixF(Sny, 0.24f, k);
                Sfx = mixF(Sfx, 0.00f * sgn, k); Sfy = mixF(Sfy, 0.24f, k);
                tipX = mixF(tipX, nHx - 0.50f * sgn, k);
                tipY = mixF(tipY, nHy - 0.26f, k);
            }

            mRigBladeAx = nHx + bdx * 0.06f;
            mRigBladeAy = nHy + bdy * 0.06f;
            mRigBladeBx = tipX;
            mRigBladeBy = tipY;
            mBladeWorldX = mPlayerX + (mRigBladeAx + mRigBladeBx) * 0.5f * HERO_UNIT_PPU;
            mBladeWorldY = mPlayerY - 0.19f + (mRigBladeAy + mRigBladeBy) * 0.5f * HERO_UNIT_PPU;

            // ---------- 1. Grounded Dark Shadow Cloak Train (lower-right behind the robe, matching hero_chainmail.png!) ----------
            hcapH(Wx + 0.06f, Wy + 0.08f, ankXs[0] + 0.18f, ground - 0.04f, 0.135f, 0.55f, 0.05f, 0.45f, TONE_CLOAK);

            // ---------- 2. Full Ankle-Length Deep Crimson Surcoat / Robe (matching hero_chainmail.png & tower_rooftop.png!) ----------
            float robeBottomX = hipX - sfx * 0.03f * walk;
            float robeBottomY = ground - 0.10f;
            // Solid full-length crimson robe column from chest to ankles
            hcapH(Cx, Cy, Wx, Wy, 0.148f, 0.90f, 0.48f, 0.65f, TONE_SURCOAT);
            hcapH(Wx, Wy, Px, Py + 0.18f, 0.156f, 0.88f, 0.49f, 0.65f, TONE_SURCOAT);
            hcapH(Px - 0.02f, Py + 0.12f, robeBottomX - 0.02f, robeBottomY, 0.152f, 0.84f, 0.50f, 0.65f, TONE_SURCOAT);

            // ---------- 3. Articulated Dark Greaves with Bright Silver Rim Highlight on the Right/Striding Edge ----------
            for (int leg = 0; leg < 2; leg++) {
                boolean nl = leg == 0;
                float z = nl ? 0.72f : 0.14f;
                float lm = nl ? 1.0f : 0.82f;
                // Right/near leg shows the iconic vertical silver chainmail/greave rim along the side of the crimson robe!
                float gxOff = nl ? 0.065f : -0.04f;
                hcapH(hipXs[leg] + gxOff, hipYs[leg], kneeXs[leg] + gxOff, kneeYs[leg], 0.078f, 0.86f * lm, z, 0.65f, TONE_GREAVES);
                hcapH(kneeXs[leg] + gxOff, kneeYs[leg], ankXs[leg] + gxOff, ankYs[leg], 0.066f, 0.92f * lm, z + 0.01f, 0.70f, TONE_GREAVES);
                hcapH(ankXs[leg] + gxOff - fx * 0.02f, ankYs[leg] + 0.01f, toeXs[leg] + gxOff, toeYs[leg], 0.056f, 0.94f * lm, z + 0.02f, 0.75f, TONE_GREAVES);
            }

            // Studded golden-amber waist belt across the crimson surcoat (matching hero_chainmail.png!)
            hcapH(Wx - 0.11f, Wy + 0.015f, Wx + 0.11f, Wy + 0.015f, 0.038f, 0.96f, 0.56f, 0.65f, TONE_LEATHER);

            // ---------- 4. Smooth Bell-Hood 3D Chainmail Coif & Bishop's Mantle (matching hero_chainmail.png & tower_rooftop.png!) ----------
            hcapH(Snx, Sny + 0.02f, Cx, Cy + 0.04f, 0.112f, 1.04f, 0.62f, 0.85f, TONE_CHAINMAIL);
            hcapH(Sfx, Sfy + 0.02f, Cx, Cy + 0.04f, 0.106f, 1.00f, 0.62f, 0.85f, TONE_CHAINMAIL);
            hcapH(Hx - 0.03f, Hy + 0.02f, Snx * 0.78f, Sny + 0.01f, 0.118f, 1.08f, 0.72f, 0.88f, TONE_CHAINMAIL);
            hcapH(Hx + 0.03f, Hy + 0.02f, Sfx * 0.78f, Sfy + 0.01f, 0.114f, 1.04f, 0.72f, 0.88f, TONE_CHAINMAIL);
            hcapH(Hx - 0.025f, Hy - 0.035f, Hx + 0.025f, Hy + 0.035f, 0.138f, 1.12f, 0.86f, 0.90f, TONE_CHAINMAIL);
            if (sfy > -0.35f) {
                hcapH(Hx + 0.055f, Hy - 0.010f, Hx + 0.062f, Hy + 0.018f, 0.028f, 0.35f, 0.89f, 0.50f, TONE_VISOR);
            }

            // ---------- 5. Armored Arms & Thick Blazing Ember Greatsword ----------
            hcapH(Sfx, Sfy, fEx, fEy, 0.056f, 0.82f, 0.15f, 0.50f, TONE_CHAINMAIL);
            hcapH(fEx, fEy, fWx, fWy, 0.048f, 0.84f, 0.16f, 0.55f, TONE_GREAVES);
            hcapH(Snx, Sny, nEx, nEy, 0.060f, 0.96f, 0.80f, 0.50f, TONE_CHAINMAIL);
            hcapH(nEx, nEy, nHx, nHy, 0.052f, 0.96f, 0.81f, 0.55f, TONE_GREAVES);

            // Crossguard & Pommel
            float gdx = nHx + bdx * 0.06f, gdy = nHy + bdy * 0.06f;
            float pnx = -bdy, pny = bdx;
            hcapH(gdx - pnx * 0.092f, gdy - pny * 0.092f, gdx + pnx * 0.092f, gdy + pny * 0.092f, 0.038f, 0.98f, 0.96f, 0.75f, TONE_CHAINMAIL);
            hcapH(nHx - bdx * 0.05f, nHy - bdy * 0.05f, nHx, nHy, 0.040f, 0.96f, 0.95f, 0.65f, TONE_LEATHER);

            // Thick Blazing Ember Greatsword Blade (3-4 chars wide, incandescent core!)
            float midBx = mixF(nHx + bdx * 0.06f, tipX, 0.68f);
            float midBy = mixF(nHy + bdy * 0.06f, tipY, 0.68f);
            hcapH(nHx + bdx * 0.06f, nHy + bdy * 0.06f, midBx, midBy, 0.068f, 1.05f, 0.97f, 0.92f, TONE_FIRE);
            hcapH(midBx, midBy, tipX, tipY, 0.048f, 1.05f, 0.98f, 0.92f, TONE_FIRE);

            mHeadLocX = Sx;
            mHeadLocY = Sy;
        }
        // ===== HERO RIG END =====

        private void rasterizeEnemyHumanoidAscii(int eIdx) {
            int total = ENEMY_BUF_W * ENEMY_BUF_H;
            for (int i = 0; i < total; i++) {
                mEnemyGlyphBuf[i] = ' ';
                mEnemyLumBuf[i] = -1.0f;
            }

            float sx = 19.0f;
            float sy = 19.0f;
            float cx = ENEMY_BUF_W * 0.5f;
            float cy = ENEMY_BUF_H * 0.56f;

            float g = mEnemyGait[eIdx];
            boolean moving = mEnemyAggro[eIdx] || ((int) (mTimeSec + eIdx) % 3 != 0);
            float bob = moving ? (float) Math.abs(Math.sin(g)) * 0.065f : (float) Math.sin(g) * 0.022f;
            float fx = mEnemyFacingX[eIdx];
            float fy = mEnemyFacingY[eIdx];

            for (int leg = 0; leg < 2; leg++) {
                float ph = g + (leg == 1 ? (float) Math.PI : 0.0f);
                float side = (leg == 0 ? -0.13f : 0.13f);
                float st = moving ? (float) Math.sin(ph) * 0.25f : 0.0f;
                float lift = moving ? Math.max(0.0f, (float) Math.cos(ph)) * 0.14f : 0.0f;
                plotEnemyCap(cx, cy, sx, sy, side, 0.12f - bob, side + st, 0.68f - lift, 0.082f, 0.76f, TONE_GREAVES);
            }

            plotEnemyCap(cx, cy, sx, sy, 0.0f, 0.24f - bob, fx * 0.06f, -0.30f - bob, 0.17f, 0.84f,
                    (eIdx % 2 == 0) ? TONE_SURCOAT : TONE_GREAVES);
            plotEnemyCap(cx, cy, sx, sy, -0.20f, -0.28f - bob, 0.20f, -0.28f - bob, 0.10f, 0.92f, TONE_CHAINMAIL);
            plotEnemyCap(cx, cy, sx, sy, fx * 0.07f, -0.48f - bob, fx * 0.07f, -0.62f - bob, 0.125f, 0.98f, TONE_CHAINMAIL);

            float windupRaise = (mEnemyAtkWindup[eIdx] > 0.0f) ? -1.45f * (mEnemyAtkWindup[eIdx] / 0.42f) : 0.35f;
            float wAng = (float) Math.atan2(fy, fx) + windupRaise;
            float hx = 0.18f + (float) Math.cos(wAng) * 0.24f;
            float hy = -0.24f - bob + (float) Math.sin(wAng) * 0.24f;
            float tx = hx + (float) Math.cos(wAng) * 0.56f;
            float ty = hy + (float) Math.sin(wAng) * 0.56f;
            plotEnemyCap(cx, cy, sx, sy, 0.18f, -0.24f - bob, hx, hy, 0.072f, 0.82f, TONE_CHAINMAIL);
            plotEnemyCap(cx, cy, sx, sy, hx, hy, tx, ty, 0.048f, 0.98f, (eIdx % 3 == 0) ? TONE_FIRE : TONE_CHAINMAIL);
        }

        private void plotEnemyCap(float cx, float cy, float sx, float sy,
                                  float ax, float ay, float bx, float by,
                                  float radius, float baseLum, int tone) {
            int minC = Math.max(0, (int) (cx + (Math.min(ax, bx) - radius) * sx) - 1);
            int maxC = Math.min(ENEMY_BUF_W - 1, (int) (cx + (Math.max(ax, bx) + radius) * sx) + 1);
            int minR = Math.max(0, (int) (cy + (Math.min(ay, by) - radius) * sy) - 1);
            int maxR = Math.min(ENEMY_BUF_H - 1, (int) (cy + (Math.max(ay, by) + radius) * sy) + 1);
            float abx = bx - ax;
            float aby = by - ay;
            float ab2 = abx * abx + aby * aby + 1e-6f;
            float r2 = radius * radius;
            for (int r = minR; r <= maxR; r++) {
                float py = (r - cy) / sy;
                for (int c = minC; c <= maxC; c++) {
                    float px = (c - cx) / sx;
                    float t = ((px - ax) * abx + (py - ay) * aby) / ab2;
                    if (t < 0.0f) t = 0.0f;
                    else if (t > 1.0f) t = 1.0f;
                    float dx = px - (ax + t * abx);
                    float dy = py - (ay + t * aby);
                    float d2 = dx * dx + dy * dy;
                    if (d2 <= r2) {
                        float distNorm = (float) Math.sqrt(d2) / radius;
                        float nz = (float) Math.sqrt(Math.max(0.0f, 1.0f - distNorm * distNorm));
                        float ny = dy / radius;
                        float light = (nz * 0.72f - ny * 0.38f + 0.15f) * baseLum;
                        int idx = r * ENEMY_BUF_W + c;
                        if (light > mEnemyLumBuf[idx]) {
                            mEnemyLumBuf[idx] = light;
                            int v = Math.max(48, Math.min(248, (int) (42.0f + light * 215.0f)));
                            if (tone == TONE_CHAINMAIL) {
                                mEnemyGlyphBuf[idx] = CHAINMAIL_GLYPHS.charAt((r * 5 + c * 3) % CHAINMAIL_GLYPHS.length());
                                mEnemyColorBuf[idx] = Color.rgb(v, v + 4, Math.min(255, v + 12));
                            } else if (tone == TONE_SURCOAT) {
                                mEnemyGlyphBuf[idx] = SURCOAT_GLYPHS.charAt((r * 7 + c * 3) % SURCOAT_GLYPHS.length());
                                mEnemyColorBuf[idx] = Color.rgb(Math.min(255, 60 + v / 2), v / 5, v / 5);
                            } else if (tone == TONE_FIRE) {
                                mEnemyGlyphBuf[idx] = FIRE_GLYPHS.charAt((r + c) % FIRE_GLYPHS.length());
                                mEnemyColorBuf[idx] = Color.rgb(255, 165, 62);
                            } else {
                                int rampIdx = Math.max(1, Math.min(DENSE_RAMP.length() - 1, (int) (light * (DENSE_RAMP.length() - 1))));
                                mEnemyGlyphBuf[idx] = DENSE_RAMP.charAt(rampIdx);
                                mEnemyColorBuf[idx] = Color.rgb(v - 10, v - 6, v + 4);
                            }
                        }
                    }
                }
            }
        }

        private void rasterizeHorseAndRiderAscii() {
            for (int i = 0; i < HORSE_BUF_W * HORSE_BUF_H; i++) {
                mHorseGlyphBuf[i] = ' ';
                mHorseLumBuf[i] = -1.0f;
            }

            final float t = mTimeSec;
            float fx = mFacingX;
            float fy = mFacingY;
            float sgn = fx >= 0.0f ? 1.0f : -1.0f;
            float spd = (float) Math.sqrt(mVelX * mVelX + mVelY * mVelY);
            float sf = Math.min(1.0f, spd / 4.6f);
            float g = smooth01(0.40f, 0.82f, sf);
            float mv = Math.min(1.0f, spd / 1.4f);
            float ph = mGaitPhase;

            boolean dodging = mDodgeTimer > 0.0f;
            float p = dodging ? Math.max(0.0f, 1.0f - mDodgeTimer / DODGE_DUR) : 0.0f;
            float k = dodging ? smooth01(0.05f, 0.20f, p) * (1.0f - smooth01(0.82f, 0.97f, p)) : 0.0f;
            float leap = dodging ? (float) Math.sin(Math.PI * p) * 0.30f : 0.0f;

            float bob = 0.035f * mv * (1.0f - g) * (float) Math.cos(2.0f * ph)
                    + 0.070f * mv * g * (float) Math.cos(ph + 0.6f);
            float pitch = (float) Math.sin(ph) * 0.07f * g * mv;
            float breathe = (float) Math.sin(t * 1.8f) * 0.012f * (1.0f - mv);
            float bodyOff = bob + breathe - leap;

            float rearX = -fx * 0.56f;
            float rearY = -fy * 0.22f - 0.05f + bodyOff + pitch;
            float frontX = fx * (0.52f + 0.08f * k);
            float frontY = fy * 0.22f - 0.08f + bodyOff - pitch - 0.05f * k;

            final float ground = 0.98f;
            float[] legHipOff = {-0.58f, 0.52f, -0.46f, 0.62f};
            float[] legBright = {0.42f, 0.45f, 0.72f, 0.76f};
            float[] walkFrac = {0.50f, 0.75f, 0.00f, 0.25f};
            float[] gallopFrac = {0.00f, 0.50f, 0.12f, 0.62f};
            float strideS = (0.18f + 0.22f * g) * mv;
            float liftL = (0.13f + 0.13f * g) * mv;
            float duty = mixF(0.62f, 0.38f, g);
            float bendScale = 0.5f + 0.5f * Math.min(1.0f, Math.abs(fx) * 1.4f);

            float pawT = t % 8.0f;
            float paw = 0.0f;
            if (mv < 0.15f && pawT < 1.6f) {
                paw = Math.max(0.0f, (float) Math.sin(pawT * 10.0f)) * 0.18f * (float) Math.sin(Math.PI * pawT / 1.6f);
            }

            for (int leg = 0; leg < 4; leg++) {
                boolean front = (leg & 1) == 1;
                float frac = mixF(walkFrac[leg], gallopFrac[leg], g);
                footCycle(ph + frac * 6.2831853f, duty, strideS, liftL);
                float off = mFootOff;
                float lift = mFootLift;

                float hipX = fx * legHipOff[leg];
                float hipY = fy * legHipOff[leg] * 0.35f + 0.08f + bodyOff + (front ? -pitch : pitch);
                float footX = hipX + fx * off;
                float footY = ground + fy * off * 0.35f - lift;
                if (leg == 3) footY -= paw;
                if (k > 0.0f) {
                    float sx = front ? 0.52f * sgn : -0.50f * sgn;
                    footX = mixF(footX, hipX + sx, k);
                    footY = mixF(footY, hipY + (front ? 0.50f : 0.46f), k);
                }
                legKnee(hipX, hipY, footX, footY, 0.47f, 0.49f, front ? sgn : -sgn, bendScale);
                float kneeX = mRtx;
                float kneeY = mRty;

                hcap(hipX, hipY, kneeX, kneeY, 0.085f, legBright[leg], -1);
                hcap(kneeX, kneeY, footX, footY, 0.060f, legBright[leg] * 0.9f, -1);
                hcap(footX, footY, footX + sgn * 0.04f, footY + 0.03f, 0.060f, legBright[leg] * 0.6f, -1);
            }

            hcap(rearX, rearY, frontX, frontY, 0.31f, 0.88f, -1);
            hcap(rearX, rearY - 0.06f, rearX * 0.5f, rearY - 0.08f, 0.24f, 0.96f, -1);

            float nod = (float) Math.sin(ph - 0.8f) * 0.07f * (0.3f + 0.7f * mv) * mv;
            float dipEnv = Math.max(0.0f, (float) Math.sin(t * 0.45f));
            float dip = dipEnv * dipEnv * 0.30f * (1.0f - mv);
            float neckTopX = frontX + fx * (0.42f + 0.10f * g + 0.12f * k - dip * 0.4f);
            float neckTopY = frontY - 0.52f + 0.16f * g + nod + dip + 0.20f * k;
            hcap(frontX, frontY - 0.05f, neckTopX, neckTopY, 0.22f, 0.92f, -1);

            float muzzleX = neckTopX + fx * 0.38f;
            float muzzleY = neckTopY + 0.14f + 0.10f * g + dip * 0.35f;
            hcap(neckTopX, neckTopY, muzzleX, muzzleY, 0.14f, 0.95f, -1);

            float earPhase = t % 3.7f;
            float flick = earPhase < 0.25f ? (float) Math.sin(earPhase * 25.0f) * 0.05f : 0.0f;
            hcap(neckTopX - fx * 0.05f, neckTopY - 0.08f, neckTopX - fx * 0.02f + flick, neckTopY - 0.24f, 0.06f, 0.98f, -1);

            float saddleX = -fx * 0.06f;
            float saddleY = -0.30f + bodyOff * 0.9f;
            float lean = sgn * (0.04f * sf + 0.26f * k);
            float spring = bob * 0.5f;
            float rPx = saddleX, rPy = saddleY + 0.02f;
            float rWx = rPx + lean * 0.30f, rWy = rPy - 0.17f + spring * 0.3f;
            float rCx = rPx + lean * 0.65f, rCy = rPy - 0.36f + spring * 0.6f - 0.010f * breathe * 20.0f;
            float rSx = rPx + lean, rSy = rPy - 0.50f + spring + 0.10f * k;
            float rNx = rSx + lean * 0.2f + fx * 0.01f, rNy = rSy - 0.06f;
            float rHx = rNx + fx * 0.035f;
            float rHy = rNy - 0.115f - spring * 0.5f + 0.02f * k;

            float kneeRx = rPx + fx * 0.26f, kneeRy = rPy + 0.20f + 0.02f * (float) Math.sin(ph) * mv;
            float stirX = kneeRx - fx * 0.02f, stirY = kneeRy + 0.34f + 0.015f * (float) Math.sin(ph + 1.0f) * mv;
            hcap(rPx, rPy + 0.02f, kneeRx, kneeRy, 0.090f, 0.92f, TONE_GREAVES);
            hcap(kneeRx, kneeRy, stirX, stirY, 0.064f, 0.96f, TONE_GREAVES);
            hcap(stirX - fx * 0.02f, stirY, stirX + fx * 0.09f, stirY + 0.03f, 0.054f, 0.95f, TONE_GREAVES);

            hcap(rPx - sgn * 0.02f, rPy, rWx, rWy, 0.112f, 0.86f, TONE_SURCOAT);
            hcap(rWx, rWy, rCx, rCy, 0.120f, 0.90f, TONE_SURCOAT);
            hcap(rCx, rCy, rSx, rSy + 0.03f, 0.130f, 0.94f, TONE_SURCOAT);
            hcap(rWx - 0.05f, rWy + 0.015f, rWx + 0.05f, rWy + 0.015f, 0.036f, 0.98f, TONE_LEATHER);
            hcap(rSx - 0.08f, rSy + 0.02f, rSx + 0.08f, rSy + 0.02f, 0.078f, 0.96f, TONE_CHAINMAIL);
            hcap(rNx, rNy + 0.02f, rHx, rHy + 0.06f, 0.062f, 0.94f, TONE_CHAINMAIL);
            hcap(rHx - sgn * 0.01f, rHy - 0.03f, rHx + sgn * 0.01f, rHy + 0.04f, 0.105f, 1.0f, TONE_CHAINMAIL);

            float rSnx = rSx + sgn * 0.06f, rSny = rSy + 0.02f;
            float rSfx = rSx - sgn * 0.06f, rSfy = rSy + 0.02f;
            float rnHx = rSfx + fx * 0.36f, rnHy = rSfy + 0.30f + nod * 0.6f;
            legKnee(rSfx, rSfy, rnHx, rnHy, 0.29f, 0.26f, -sgn, 1.0f);
            float rnEx = mRtx, rnEy = mRty;
            hcap(rSfx, rSfy, rnEx, rnEy, 0.050f, 0.80f, TONE_CHAINMAIL);
            hcap(rnEx, rnEy, rnHx, rnHy, 0.044f, 0.82f, TONE_GREAVES);

            float slashProgR = (mSlashTimer > 0.0f) ? (1.0f - mSlashTimer / 0.32f) : -1.0f;
            float slashER = slashProgR >= 0.0f ? slashProgR * slashProgR * (3.0f - 2.0f * slashProgR) : 0.0f;
            float wSR = slashProgR >= 0.0f
                    ? smooth01(0.0f, 0.12f, slashProgR) * (1.0f - smooth01(0.82f, 1.0f, slashProgR)) : 0.0f;
            float aBlade = mixF(-1.15f + 0.05f * (float) Math.sin(t * 1.1f), -1.7f + 3.5f * slashER, wSR);
            float gdx = fx, gdy = 0.35f * fy;
            float bx0 = (float) Math.cos(aBlade) * gdx, by0 = (float) Math.cos(aBlade) * gdy + (float) Math.sin(aBlade);
            float rhx = mixF(rSnx + fx * 0.26f, rSnx + bx0 * 0.45f, wSR);
            float rhy = mixF(rSny + 0.14f + nod * 0.3f, rSny + by0 * 0.45f, wSR);
            legKnee(rSnx, rSny, rhx, rhy, 0.29f, 0.26f, -sgn, 1.0f);
            hcap(rSnx, rSny, mRtx, mRty, 0.054f, 0.92f, TONE_CHAINMAIL);
            hcap(mRtx, mRty, rhx, rhy, 0.046f, 0.94f, TONE_GREAVES);
            hcap(rhx, rhy, rhx + bx0 * 0.58f, rhy + by0 * 0.58f, 0.044f, 1.0f, TONE_FIRE);

            mBladeWorldX = mPlayerX + (rhx + bx0 * 0.30f);
            mBladeWorldY = mPlayerY + (rhy + by0 * 0.30f);

            mTailLocX = rearX * 1.1f;
            mTailLocY = rearY - 0.05f;
            mManeLocX = (frontX + neckTopX) * 0.5f;
            mManeLocY = (frontY + neckTopY) * 0.5f - 0.05f;
            mHeadLocX = rSx - sgn * 0.07f;
            mHeadLocY = rSy + 0.02f;
            mNeckBaseLocX = frontX - fx * 0.02f;
            mNeckBaseLocY = frontY - 0.12f;
            mNeckTopLocX = neckTopX - fx * 0.06f;
            mNeckTopLocY = neckTopY - 0.04f;
        }

        private void plotHorseCap(float ax, float ay, float bx, float by, float radius, float baseLum, int tone) {
            final int bufW = HORSE_BUF_W;
            final int bufH = HORSE_BUF_H;
            final float cx = bufW * 0.5f;
            final float cy = bufH * 0.56f;
            final float sx = bufW / HORSE_SPAN_PPU;
            final float sy = sx / HORSE_ROW_ASPECT;
            int minC = Math.max(0, (int) (cx + (Math.min(ax, bx) - radius) * sx) - 1);
            int maxC = Math.min(bufW - 1, (int) (cx + (Math.max(ax, bx) + radius) * sx) + 1);
            int minR = Math.max(0, (int) (cy + (Math.min(ay, by) - radius) * sy) - 1);
            int maxR = Math.min(bufH - 1, (int) (cy + (Math.max(ay, by) + radius) * sy) + 1);

            float abx = bx - ax;
            float aby = by - ay;
            float ab2 = abx * abx + aby * aby + 1e-6f;
            float r2 = radius * radius;

            for (int r = minR; r <= maxR; r++) {
                float py = (r - cy) / sy;
                for (int c = minC; c <= maxC; c++) {
                    float px = (c - cx) / sx;
                    float t = ((px - ax) * abx + (py - ay) * aby) / ab2;
                    if (t < 0.0f) t = 0.0f;
                    else if (t > 1.0f) t = 1.0f;
                    float dx = px - (ax + t * abx);
                    float dy = py - (ay + t * aby);
                    float d2 = dx * dx + dy * dy;
                    if (d2 <= r2) {
                        float distNorm = (float) Math.sqrt(d2) / radius;
                        float nz = (float) Math.sqrt(Math.max(0.0f, 1.0f - distNorm * distNorm));
                        float ny = dy / radius;
                        float light = (nz * 0.72f - ny * 0.38f + 0.15f) * baseLum;
                        if (distNorm > 0.80f && tone < 0) light *= 0.25f;
                        int idx = r * bufW + c;
                        if (light > mHorseLumBuf[idx]) {
                            mHorseLumBuf[idx] = light;
                            int v = Math.max(52, Math.min(252, (int) (44.0f + light * 235.0f)));
                            if (tone == TONE_CHAINMAIL) {
                                mHorseGlyphBuf[idx] = CHAINMAIL_GLYPHS.charAt((r * 7 + c * 3) % CHAINMAIL_GLYPHS.length());
                                mHorseColorBuf[idx] = Color.rgb(v, v + 4, Math.min(255, v + 12));
                            } else if (tone == TONE_SURCOAT) {
                                mHorseGlyphBuf[idx] = SURCOAT_GLYPHS.charAt((r * 5 + c * 7) % SURCOAT_GLYPHS.length());
                                mHorseColorBuf[idx] = Color.rgb(Math.min(255, 65 + (int) (v * 0.68f)), v / 5, v / 5);
                            } else if (tone == TONE_GREAVES) {
                                mHorseGlyphBuf[idx] = GREAVES_GLYPHS.charAt((r * 5 + c * 3) % GREAVES_GLYPHS.length());
                                mHorseColorBuf[idx] = Color.rgb(v / 2 + 20, v / 2 + 24, v / 2 + 32);
                            } else if (tone == TONE_FIRE) {
                                mHorseGlyphBuf[idx] = FIRE_GLYPHS.charAt((r + c) % FIRE_GLYPHS.length());
                                mHorseColorBuf[idx] = Color.rgb(255, 172, 58);
                            } else {
                                int rampIdx = Math.max(1, Math.min(DENSE_RAMP.length() - 1, (int) (light * (DENSE_RAMP.length() - 1))));
                                mHorseGlyphBuf[idx] = DENSE_RAMP.charAt(rampIdx);
                                mHorseColorBuf[idx] = Color.rgb(v, v, Math.min(255, v + 6));
                            }
                        }
                    }
                }
            }
        }

        private Bitmap getOrBuildChunk(int cxIdx, int cyIdx, int[] builtThisFrame) {
            int key = ((cxIdx & 0xFFFF) << 16) | (cyIdx & 0xFFFF);
            int lruIdx = 0;
            int minAge = Integer.MAX_VALUE;
            for (int i = 0; i < CHUNK_CACHE_CAP; i++) {
                if (mChunkKeys[i] == key && mChunkBitmaps[i] != null) {
                    mChunkAge[i] = ++mChunkTick;
                    return mChunkBitmaps[i];
                }
                if (mChunkBitmaps[i] == null) {
                    lruIdx = i;
                    minAge = -1;
                } else if (minAge != -1 && mChunkAge[i] < minAge) {
                    minAge = mChunkAge[i];
                    lruIdx = i;
                }
            }

            if (builtThisFrame[0] >= 1 && System.nanoTime() > mFrameStartNs + 9_000_000L) {
                return null;
            }
            if (builtThisFrame[0] >= 4) {
                return null;
            }
            builtThisFrame[0]++;

            if (mChunkBitmaps[lruIdx] == null) {
                mChunkBitmaps[lruIdx] = Bitmap.createBitmap(CHUNK_PX, CHUNK_PX, Bitmap.Config.ARGB_8888);
                mChunkCanvases[lruIdx] = new Canvas(mChunkBitmaps[lruIdx]);
            }
            mChunkKeys[lruIdx] = key;
            mChunkAge[lruIdx] = ++mChunkTick;

            paintChunk(mChunkCanvases[lruIdx], cxIdx, cyIdx);
            return mChunkBitmaps[lruIdx];
        }

        private static int waterColor(float d, int jitter) {
            float t = Math.max(0.0f, Math.min(1.0f, d / 0.45f));
            int r = (int) (12 + (3 - 12) * t) + jitter;
            int g = (int) (24 + (7 - 24) * t) + jitter;
            int b = (int) (42 + (16 - 42) * t) + jitter + 1;
            return Color.rgb(Math.max(0, r), Math.max(0, g), Math.max(0, b));
        }

        private static float bilerp(float a, float b, float c, float d, float fx, float fy) {
            float top = a + (b - a) * fx;
            float bot = c + (d - c) * fx;
            return top + (bot - top) * fy;
        }

        private boolean solidCell(WorldGen g, int i, int j, float baseWx, float baseWy, float upc) {
            int n = CHUNK_CELLS;
            if (i >= 0 && j >= 0 && i < n && j < n) return mSolid[j * n + i];
            return g.cliff(baseWx + (i + 0.5f) * upc, baseWy + (j + 0.5f) * upc) > WorldGen.CLIFF_LEVEL;
        }

        private void paintChunk(Canvas cc, int cxIdx, int cyIdx) {
            final WorldGen g = mGen;
            final int n = CHUNK_CELLS;
            final int lat = n + 1;
            final float cellPx = CHUNK_PX / (float) n;
            final float baseWx = cxIdx * CHUNK_WORLD_UNITS;
            final float baseWy = cyIdx * CHUNK_WORLD_UNITS;
            final float upc = CHUNK_WORLD_UNITS / n;
            final float cliffLvl = WorldGen.CLIFF_LEVEL;
            final float wetEps = 0.012f;

            boolean darkBiomeChunk = g.isDarkCitadelBiome(baseWx + CHUNK_WORLD_UNITS * 0.5f, baseWy + CHUNK_WORLD_UNITS * 0.5f);

            for (int j = 0; j <= n; j++) {
                for (int i = 0; i <= n; i++) {
                    g.sample(baseWx + i * upc, baseWy + j * upc, mSample);
                    int k = j * lat + i;
                    mLatCliff[k] = mSample[0];
                    mLatWater[k] = mSample[1];
                    mLatMoist[k] = mSample[2];
                }
            }

            long hb = g.hashBits(cxIdx, cyIdx, 900);
            if (darkBiomeChunk) {
                // Dark Abyssal Citadel & Forest Biome (matching 1000461710.mp4!): pure dark void background!
                cc.drawColor(Color.rgb(6, 8, 14));
            } else {
                int tilesPerSide = MEADOW_TILE_PX / CHUNK_PX;
                int qx = Math.floorMod(cxIdx, tilesPerSide);
                int qy = Math.floorMod(cyIdx, tilesPerSide);
                mSrcRect.set(qx * CHUNK_PX, qy * CHUNK_PX, (qx + 1) * CHUNK_PX, (qy + 1) * CHUNK_PX);
                mTmpRect.set(0, 0, CHUNK_PX, CHUNK_PX);
                cc.drawBitmap(mMeadowTileBitmap, mSrcRect, mTmpRect, null);
            }

            for (int j = 0; j < n; j++) {
                for (int i = 0; i < n; i++) {
                    int k = j * lat + i;
                    float cl = (mLatCliff[k] + mLatCliff[k + 1] + mLatCliff[k + lat] + mLatCliff[k + lat + 1]) * 0.25f;
                    float wd = (mLatWater[k] + mLatWater[k + 1] + mLatWater[k + lat] + mLatWater[k + lat + 1]) * 0.25f;
                    mSolid[j * n + i] = cl > cliffLvl;
                    mWet[j * n + i] = wd > 0.008f;
                }
            }

            float maxW = -9.0f, maxC = -9.0f;
            for (int q = 0; q < lat * lat; q++) {
                if (mLatWater[q] > maxW) maxW = mLatWater[q];
                if (mLatCliff[q] > maxC) maxC = mLatCliff[q];
            }
            mTmpRect.set(0, 0, CHUNK_PX, CHUNK_PX);
            if (maxW > wetEps) {
                if (mWaterMask == null) mWaterMask = Bitmap.createBitmap(MASK_PX, MASK_PX, Bitmap.Config.ARGB_8888);
                for (int my = 0; my < MASK_PX; my++) {
                    int j = my >> 2;
                    float fy = ((my & 3) + 0.5f) / 4.0f;
                    for (int mx = 0; mx < MASK_PX; mx++) {
                        int i = mx >> 2;
                        float fx = ((mx & 3) + 0.5f) / 4.0f;
                        int k = j * lat + i;
                        float d = bilerp(mLatWater[k], mLatWater[k + 1], mLatWater[k + lat], mLatWater[k + lat + 1], fx, fy);
                        float a = (d - 0.004f) / 0.018f;
                        if (a <= 0.0f) {
                            mMaskPx[my * MASK_PX + mx] = 0;
                        } else {
                            int jit = (((cxIdx * n + i) * 7 + (cyIdx * n + j) * 13) & 7) - 3;
                            int col = waterColor(d, jit);
                            mMaskPx[my * MASK_PX + mx] = (col & 0x00FFFFFF) | ((int) (Math.min(1.0f, a) * 255.0f) << 24);
                        }
                    }
                }
                mWaterMask.setPixels(mMaskPx, 0, MASK_PX, 0, 0, MASK_PX, MASK_PX);
                cc.drawBitmap(mWaterMask, null, mTmpRect, mTintPaint);
            }
            if (maxC > cliffLvl - 0.006f) {
                if (mCliffMask == null) mCliffMask = Bitmap.createBitmap(MASK_PX, MASK_PX, Bitmap.Config.ARGB_8888);
                for (int my = 0; my < MASK_PX; my++) {
                    int j = my >> 2;
                    float fy = ((my & 3) + 0.5f) / 4.0f;
                    for (int mx = 0; mx < MASK_PX; mx++) {
                        int i = mx >> 2;
                        float fx = ((mx & 3) + 0.5f) / 4.0f;
                        int k = j * lat + i;
                        float v = bilerp(mLatCliff[k], mLatCliff[k + 1], mLatCliff[k + lat], mLatCliff[k + lat + 1], fx, fy);
                        float a = (v - (cliffLvl - 0.006f)) / 0.012f;
                        mMaskPx[my * MASK_PX + mx] = (a <= 0.0f) ? 0 : 0x00040608 | ((int) (Math.min(1.0f, a) * 255.0f) << 24);
                    }
                }
                mCliffMask.setPixels(mMaskPx, 0, MASK_PX, 0, 0, MASK_PX, MASK_PX);
                cc.drawBitmap(mCliffMask, null, mTmpRect, mTintPaint);
            }

            Paint bg = mChunkBgPaint;
            Paint tx = mChunkTxtPaint;
            tx.setTextAlign(Paint.Align.LEFT);
            tx.setTextSize(cellPx * 0.92f);
            final int nChars = Gfx.ROCK_CHARS.length();

            for (int j = 0; j < n; j++) {
                for (int i = 0; i < n; i++) {
                    int k = j * lat + i;
                    float px = i * cellPx;
                    float py = j * cellPx;
                    float wx = baseWx + (i + 0.5f) * upc;
                    float wy = baseWy + (j + 0.5f) * upc;
                    float w00 = mLatWater[k], w10 = mLatWater[k + 1], w01 = mLatWater[k + lat], w11 = mLatWater[k + lat + 1];
                    float c00 = mLatCliff[k], c10 = mLatCliff[k + 1], c01 = mLatCliff[k + lat], c11 = mLatCliff[k + lat + 1];
                    int gi = cxIdx * n + i;
                    int gj = cyIdx * n + j;
                    int ch = Math.abs((gi * 73856093) ^ (gj * 19349663));
                    boolean anyW = w00 > wetEps || w10 > wetEps || w01 > wetEps || w11 > wetEps;
                    boolean allW = w00 > wetEps && w10 > wetEps && w01 > wetEps && w11 > wetEps;
                    boolean anyC = c00 > cliffLvl || c10 > cliffLvl || c01 > cliffLvl || c11 > cliffLvl;
                    boolean solid = mSolid[j * n + i];

                    if (allW && ch % 4 == 0) {
                        tx.setColor(Color.argb(155, 62, 86, 122));
                        cc.drawText(GROUND_ASCII[ch % GROUND_ASCII.length], 0, 3, px, py + cellPx * 0.85f, tx);
                    }

                    if (anyC) {
                        if (solid) {
                            float gx = (c10 + c11 - c00 - c01) * 0.5f;
                            float gy = (c01 + c11 - c00 - c10) * 0.5f;
                            float sun = 0.5f - (gx + gy) * 38.0f;
                            float nz = (ch & 255) / 255.0f;
                            float lum = 0.42f + (sun - 0.5f) * 0.9f + (nz - 0.5f) * 0.28f;
                            if (!solidCell(g, i, j - 1, baseWx, baseWy, upc)) lum += 0.22f;
                            if (!solidCell(g, i, j + 1, baseWx, baseWy, upc) || !solidCell(g, i + 1, j, baseWx, baseWy, upc)) lum -= 0.16f;
                            lum = Math.max(0.16f, Math.min(1.0f, lum));
                            int idx = (int) ((1.0f - lum) * (nChars - 1) + (nz - 0.5f) * 3.0f);
                            idx = Math.max(0, Math.min(nChars - 1, idx));
                            int v = Math.max(70, Math.min(248, (int) (70.0f + lum * 175.0f)));
                            tx.setColor(Color.rgb(Math.max(0, v - 6), v, Math.min(255, v + 9)));
                            mSingleChar[0] = Gfx.ROCK_CHARS.charAt(idx);
                            cc.drawText(mSingleChar, 0, 1, px, py + cellPx * 0.86f, tx);
                        }
                    } else if (!anyW) {
                        float pathVal = g.pathMask(wx, wy);
                        if (pathVal > 0.08f) {
                            bg.setColor(Color.argb((int) (Math.min(1.0f, pathVal) * 210.0f), 6, 8, 14));
                            cc.drawRect(px, py, px + cellPx + 0.5f, py + cellPx + 0.5f, bg);
                            if (ch % 100 < 78) {
                                int pv = 96 + (ch % 52);
                                tx.setColor(Color.argb(215, pv - 12, pv - 4, Math.min(255, pv + 26)));
                                cc.drawText(PATH_ASCII[ch % PATH_ASCII.length], 0, 3, px, py + cellPx * 0.85f, tx);
                            }
                        } else if (!darkBiomeChunk && ch % 100 < 68) {
                            // Iconic dense slate-blue 0Q8Qdba ASCII ground matrix underneath the grass blades (matching hero_chainmail.png!)
                            int gv = 104 + (ch % 42);
                            tx.setColor(Color.argb(168, gv - 10, gv + 2, Math.min(255, gv + 28)));
                            cc.drawText(GROUND_ASCII[ch % GROUND_ASCII.length], 0, (ch % 3 == 0) ? 2 : 3, px, py + cellPx * 0.85f, tx);
                        }
                    }
                }
            }

            // Wildflowers in the Meadow Biome: white "o*o" motifs, "*", and "o" rings (matching hero_chainmail.png!)
            if (!darkBiomeChunk) {
                mRng.setSeed(hb ^ 0x51F0E5L);
                float moistAvg = mLatMoist[(n / 2) * lat + n / 2];
                int sprinkles = 24 + (int) (moistAvg * 32.0f);
                for (int f = 0; f < sprinkles; f++) {
                    float fx = mRng.nextFloat() * CHUNK_PX;
                    float fy = mRng.nextFloat() * CHUNK_PX;
                    if (!landAt(fx, fy, cellPx)) continue;
                    float kind = mRng.nextFloat();
                    tx.setTextSize(kind < 0.28f ? 11.5f : 10.0f);
                    tx.setColor(Color.rgb(238, 244, 248));
                    if (kind < 0.24f) {
                        cc.drawText("o*o", fx, fy, tx);
                    } else if (kind < 0.65f) {
                        cc.drawText("*", fx, fy, tx);
                    } else {
                        cc.drawText("o", fx, fy, tx);
                    }
                }
            }
        }

        private boolean landAt(float px, float py, float cellPx) {
            int i = (int) (px / cellPx);
            int j = (int) (py / cellPx);
            if (i < 0 || j < 0 || i >= CHUNK_CELLS || j >= CHUNK_CELLS) return false;
            return !mSolid[j * CHUNK_CELLS + i] && !mWet[j * CHUNK_CELLS + i];
        }

        private void drawAsciiBufferSpanBatched(
                Canvas canvas, char[] gBuf, int[] cBuf, int bufW, int bufH,
                float originX, float originY, float cellPx,
                boolean darkBacking, int overrideColor
        ) {
            mAsciiPaint.setTextSize(Math.max(5.5f, cellPx * 1.18f));
            mAsciiPaint.setTextAlign(Paint.Align.LEFT);
            for (int r = 0; r < bufH; r++) {
                float drawY = originY + r * cellPx;
                int rowOff = r * bufW;
                int c = 0;
                while (c < bufW) {
                    if (gBuf[rowOff + c] == ' ') {
                        c++;
                        continue;
                    }
                    int startC = c;
                    int firstColor = (overrideColor != 0) ? overrideColor : cBuf[rowOff + c];
                    while (c < bufW && gBuf[rowOff + c] != ' ') {
                        if (overrideColor == 0 && Math.abs(Color.red(cBuf[rowOff + c]) - Color.red(firstColor)) > 32) {
                            break;
                        }
                        c++;
                    }
                    int spanLen = c - startC;
                    float sx = originX + startC * cellPx;
                    if (darkBacking) {
                        mPanelPaint.setColor(Color.argb(225, 5, 7, 9));
                        canvas.drawRect(sx - 1.0f, drawY - cellPx * 0.88f, sx + spanLen * cellPx + 1.0f, drawY + cellPx * 0.16f, mPanelPaint);
                    }
                    mAsciiPaint.setColor(firstColor);
                    canvas.drawText(gBuf, rowOff + startC, spanLen, sx, drawY, mAsciiPaint);
                }
            }
        }

        private void drawHeroGlyphs(Canvas canvas, float hx, float hy, float ppu, boolean backing, int overrideColor) {
            final float unit = ppu * HERO_UNIT_PPU;
            final float cellW = unit / HERO_COLS_PER_UNIT;
            final float cellH = unit / HERO_ROWS_PER_UNIT;
            drawHeroGlyphsAt(canvas, hx - (FOOT_BUF_W * 0.5f) * cellW,
                    hy - 0.19f * ppu - (FOOT_BUF_H * 0.55f) * cellH, cellW, cellH, backing, overrideColor);
        }

        private void drawHeroGlyphsAt(Canvas canvas, float originX, float originY, float cellW, float cellH,
                                      boolean backing, int overrideColor) {
            if (mAsciiAdv <= 0.0f) {
                mAsciiPaint.setTextSize(100.0f);
                mAsciiAdv = Math.max(0.3f, mAsciiPaint.measureText("M") / 100.0f);
            }
            mAsciiPaint.setTextSize(cellW / mAsciiAdv);
            mAsciiPaint.setTextAlign(Paint.Align.LEFT);
            if (backing) {
                mPanelPaint.setColor(Color.argb(225, 4, 6, 8));
                for (int r = 0; r < FOOT_BUF_H; r++) {
                    final float drawY = originY + r * cellH;
                    final int rowOff = r * FOOT_BUF_W;
                    int c = 0;
                    while (c < FOOT_BUF_W) {
                        if (mFootGlyphBuf[rowOff + c] == ' ') {
                            c++;
                            continue;
                        }
                        final int startC = c;
                        while (c < FOOT_BUF_W && mFootGlyphBuf[rowOff + c] != ' ') {
                            c++;
                        }
                        final float sx = originX + startC * cellW;
                        canvas.drawRect(sx - 1.0f, drawY - cellH * 0.90f, sx + (c - startC) * cellW + 1.0f, drawY + cellH * 0.15f, mPanelPaint);
                    }
                }
            }
            for (int r = 0; r < FOOT_BUF_H; r++) {
                final float drawY = originY + r * cellH;
                final int rowOff = r * FOOT_BUF_W;
                int c = 0;
                while (c < FOOT_BUF_W) {
                    if (mFootGlyphBuf[rowOff + c] == ' ') {
                        c++;
                        continue;
                    }
                    final int startC = c;
                    final int firstColor = (overrideColor != 0) ? overrideColor : mFootColorBuf[rowOff + c];
                    while (c < FOOT_BUF_W && mFootGlyphBuf[rowOff + c] != ' ') {
                        if (overrideColor == 0 && Math.abs(Color.red(mFootColorBuf[rowOff + c]) - Color.red(firstColor)) > 18) {
                            break;
                        }
                        c++;
                    }
                    final int spanLen = c - startC;
                    final float sx = originX + startC * cellW;
                    mAsciiPaint.setColor(firstColor);
                    canvas.drawText(mFootGlyphBuf, rowOff + startC, spanLen, sx, drawY, mAsciiPaint);
                }
            }
        }

        private void drawHorseGlyphs(Canvas canvas, float hx, float hy, float ppu, boolean backing, int overrideColor) {
            final float cellW = (ppu * HORSE_SPAN_PPU) / HORSE_BUF_W;
            final float cellH = cellW * HORSE_ROW_ASPECT;
            if (mAsciiAdv <= 0.0f) {
                mAsciiPaint.setTextSize(100.0f);
                mAsciiAdv = Math.max(0.3f, mAsciiPaint.measureText("M") / 100.0f);
            }
            mAsciiPaint.setTextSize(cellW / mAsciiAdv);
            mAsciiPaint.setTextAlign(Paint.Align.LEFT);
            final float originX = hx - (HORSE_BUF_W * 0.5f) * cellW;
            final float originY = hy - (HORSE_BUF_H * 0.56f) * cellH;
            for (int r = 0; r < HORSE_BUF_H; r++) {
                final float drawY = originY + r * cellH;
                final int rowOff = r * HORSE_BUF_W;
                int c = 0;
                while (c < HORSE_BUF_W) {
                    if (mHorseGlyphBuf[rowOff + c] == ' ') {
                        c++;
                        continue;
                    }
                    final int startC = c;
                    final int firstColor = (overrideColor != 0) ? overrideColor : mHorseColorBuf[rowOff + c];
                    while (c < HORSE_BUF_W && mHorseGlyphBuf[rowOff + c] != ' ') {
                        if (overrideColor == 0 && Math.abs(Color.red(mHorseColorBuf[rowOff + c]) - Color.red(firstColor)) > 22) {
                            break;
                        }
                        c++;
                    }
                    final int spanLen = c - startC;
                    final float sx = originX + startC * cellW;
                    if (backing) {
                        mPanelPaint.setColor(Color.argb(150, 5, 7, 9));
                        canvas.drawRect(sx, drawY - cellH * 0.86f, sx + spanLen * cellW, drawY + cellH * 0.14f, mPanelPaint);
                    }
                    mAsciiPaint.setColor(firstColor);
                    canvas.drawText(mHorseGlyphBuf, rowOff + startC, spanLen, sx, drawY, mAsciiPaint);
                }
            }
        }

        private void drawHeroEntity(Canvas canvas, float centerX, float centerY, float pixelsPerUnit) {
            float hx = centerX + (mPlayerX - mCamX) * pixelsPerUnit;
            float hy = centerY + (mPlayerY - mCamY) * pixelsPerUnit;

            if (mMounted) {
                mShadowPaint.setColor(Color.argb(185, 4, 7, 6));
                mTmpRect.set(hx - pixelsPerUnit * 0.9f, hy + pixelsPerUnit * 0.15f, hx + pixelsPerUnit * 1.0f, hy + pixelsPerUnit * 0.78f);
                canvas.drawOval(mTmpRect, mShadowPaint);

                mAsciiPaint.setTextSize(Math.max(11.0f, pixelsPerUnit * 0.17f));
                mAsciiPaint.setColor(Color.rgb(232, 236, 234));
                mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                canvas.drawText("Senje", hx, hy - 1.92f * pixelsPerUnit, mAsciiPaint);

                drawHorseGlyphs(canvas, hx, hy, pixelsPerUnit, true,
                        mPlayerHurtFlash > 0.0f ? Color.rgb(255, 95, 95) : 0);
                mTailFx.draw(canvas, mPlayerX, mPlayerY, hx, hy, pixelsPerUnit, Math.max(1.2f, pixelsPerUnit * 0.018f), 228, 0.95f);
                mManeFx.draw(canvas, mPlayerX, mPlayerY, hx, hy, pixelsPerUnit, Math.max(1.1f, pixelsPerUnit * 0.016f), 232, 0.92f);
            } else {
                // Long directional shadow under the hero's feet extending to the right (matching hero_chainmail.png!)
                mShadowPaint.setColor(Color.argb(215, 2, 4, 4));
                mTmpRect.set(hx - pixelsPerUnit * 0.18f, hy + pixelsPerUnit * 0.42f, hx + pixelsPerUnit * 1.08f, hy + pixelsPerUnit * 0.78f);
                canvas.drawOval(mTmpRect, mShadowPaint);

                mAsciiPaint.setTextSize(Math.max(11.0f, pixelsPerUnit * 0.165f));
                mAsciiPaint.setColor(Color.rgb(232, 236, 234));
                mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                canvas.drawText("Senje", hx, hy - 1.02f * pixelsPerUnit, mAsciiPaint);

                drawHeroGlyphs(canvas, hx, hy, pixelsPerUnit, true,
                        mPlayerHurtFlash > 0.0f ? Color.rgb(255, 95, 95) : 0);
            }

            float bx = centerX + (mBladeWorldX - mCamX) * pixelsPerUnit;
            float by = centerY + (mBladeWorldY - mCamY) * pixelsPerUnit;
            float bRad = pixelsPerUnit * (mSlashTimer > 0.0f ? 2.1f : 1.35f);
            mGlowPaint.setAlpha(mSlashTimer > 0.0f ? 225 : 165);
            mTmpRect.set(bx - bRad, by - bRad, bx + bRad, by + bRad);
            canvas.drawBitmap(mAmberGlowBitmap, null, mTmpRect, mGlowPaint);
            mGlowPaint.setAlpha(255);
        }

        private void drawFrame() {
            SurfaceHolder holder = getHolder();
            Canvas canvas = null;
            try {
                if (Build.VERSION.SDK_INT >= 26) {
                    canvas = holder.lockHardwareCanvas();
                } else {
                    canvas = holder.lockCanvas();
                }
                if (canvas == null) return;

                ensureStaticCaches();

                int screenW = canvas.getWidth();
                int screenH = canvas.getHeight();
                canvas.drawColor(Color.rgb(6, 8, 12));

                float pixelsPerUnit = Math.min(screenW, screenH) * 0.095f * mCameraZoom;
                float centerX = screenW * 0.5f;
                float centerY = screenH * 0.48f;

                float halfUnitsW = (screenW * 0.5f) / pixelsPerUnit + 1.5f;
                float halfUnitsH = (screenH * 0.5f) / pixelsPerUnit + 1.5f;

                int minCx = (int) Math.floor((mCamX - halfUnitsW) / CHUNK_WORLD_UNITS);
                int maxCx = (int) Math.floor((mCamX + halfUnitsW) / CHUNK_WORLD_UNITS);
                int minCy = (int) Math.floor((mCamY - halfUnitsH) / CHUNK_WORLD_UNITS);
                int maxCy = (int) Math.floor((mCamY + halfUnitsH) / CHUNK_WORLD_UNITS);
                int[] builtThisFrame = new int[]{0};
                mFrameStartNs = System.nanoTime();

                for (int cy = minCy; cy <= maxCy; cy++) {
                    for (int cx = minCx; cx <= maxCx; cx++) {
                        float sx0 = centerX + (cx * CHUNK_WORLD_UNITS - mCamX) * pixelsPerUnit;
                        float sy0 = centerY + (cy * CHUNK_WORLD_UNITS - mCamY) * pixelsPerUnit;
                        float chunkScreenPx = CHUNK_WORLD_UNITS * pixelsPerUnit;
                        Bitmap chunk = getOrBuildChunk(cx, cy, builtThisFrame);
                        mTmpRect.set(sx0 - 2.0f, sy0 - 2.0f, sx0 + chunkScreenPx + 2.0f, sy0 + chunkScreenPx + 2.0f);
                        if (chunk != null) {
                            canvas.drawBitmap(chunk, null, mTmpRect, mBitmapPaint);
                        } else {
                            mSrcRect.set(0, 0, CHUNK_PX, CHUNK_PX);
                            canvas.drawBitmap(mMeadowTileBitmap, mSrcRect, mTmpRect, mBitmapPaint);
                        }
                    }
                }

                boolean ringFits = (maxCx - minCx + 3) * (maxCy - minCy + 3) <= CHUNK_CACHE_CAP;
                for (int cy = minCy - 1; ringFits && cy <= maxCy + 1 && builtThisFrame[0] < 2; cy++) {
                    for (int cx = minCx - 1; cx <= maxCx + 1 && builtThisFrame[0] < 2; cx++) {
                        if (cx >= minCx && cx <= maxCx && cy >= minCy && cy <= maxCy) continue;
                        getOrBuildChunk(cx, cy, builtThisFrame);
                    }
                }

                float windScale = (mWindPreset == 0) ? 0.6f : (mWindPreset == 1 ? 1.0f : 1.75f);
                final WorldGen gen = mGen;
                mObjs.clear();
                gen.objectsIn(mCamX - halfUnitsW, mCamY - halfUnitsH, mCamX + halfUnitsW, mCamY + halfUnitsH, mObjs);
                mSpriteBudget = 2;

                mGrassFx.clearPushers();
                if (mPlayerElevation == 0) {
                    mGrassFx.addPusher(mPlayerX, mPlayerY + 0.25f, mVelX, mVelY, mMounted ? 1.7f : 1.1f);
                }
                for (int eg = 0; eg < NUM_ENEMIES; eg++) {
                    mGrassFx.addPusher(mEnemyX[eg], mEnemyY[eg] + 0.2f, 0.0f, 0.0f, 0.9f);
                }
                mGrassFx.drawField(canvas, gen, mCamX, mCamY, centerX, centerY, pixelsPerUnit,
                        halfUnitsW, halfUnitsH, mTimeSec, windScale);
                mGrassFx.drawSparkles(canvas, gen, mCamX, mCamY, centerX, centerY, pixelsPerUnit,
                        halfUnitsW, halfUnitsH, mTimeSec);

                for (int oi = 0; oi < mObjs.size(); oi++) {
                    WorldGen.Obj o = mObjs.get(oi);
                    if (o.kind != WorldGen.CAVE) continue;
                    float cvx = centerX + (o.x - mCamX) * pixelsPerUnit;
                    float cvy = centerY + (o.y - mCamY) * pixelsPerUnit;
                    if (cvx < -320 || cvx > screenW + 320 || cvy < -320 || cvy > screenH + 320) continue;
                    drawCaveMouth(canvas, o, cvx, cvy, pixelsPerUnit);
                }

                drawWaterEffects(canvas, centerX, centerY, pixelsPerUnit, halfUnitsW, halfUnitsH);
                drawWorldProps(canvas, centerX, centerY, pixelsPerUnit, screenW, screenH);

                mAsciiPaint.setTextSize(Math.max(10.0f, pixelsPerUnit * 0.20f));
                mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                for (int f = 0; f < NUM_FLORA; f++) {
                    if (mFloraRegrow[f] > 0.0f) continue;
                    float fx = centerX + (mFloraX[f] - mCamX) * pixelsPerUnit;
                    float fy = centerY + (mFloraY[f] - mCamY) * pixelsPerUnit;
                    if (fx < -80 || fx > screenW + 80 || fy < -80 || fy > screenH + 80) continue;
                    if (mFloraKind[f] == 0) {
                        mAsciiPaint.setColor(Color.rgb(175, 225, 255));
                        canvas.drawText("(*)", fx, fy, mAsciiPaint);
                    } else if (mFloraKind[f] == 1) {
                        mAsciiPaint.setColor(Color.rgb(255, 175, 95));
                        canvas.drawText("{@}", fx, fy, mAsciiPaint);
                    } else {
                        mAsciiPaint.setColor(Color.rgb(135, 238, 165));
                        canvas.drawText("[#]", fx, fy, mAsciiPaint);
                    }
                }

                mAsciiPaint.setTextSize(Math.max(9.5f, pixelsPerUnit * 0.19f));
                for (int a = 0; a < NUM_FAUNA; a++) {
                    float ax = centerX + (mFaunaX[a] - mCamX) * pixelsPerUnit;
                    float ay = centerY + (mFaunaY[a] - mCamY) * pixelsPerUnit;
                    if (ax < -100 || ax > screenW + 100 || ay < -100 || ay > screenH + 100) continue;
                    float hop = Math.abs((float) Math.sin(mFaunaPhase[a])) * pixelsPerUnit * 0.14f;
                    if (mFaunaKind[a] == 0) {
                        mAsciiPaint.setColor(Color.rgb(212, 178, 134));
                        canvas.drawText(mFaunaVx[a] >= 0 ? "^..^>" : "<^..^", ax, ay - hop * 0.6f, mAsciiPaint);
                    } else if (mFaunaKind[a] == 1) {
                        mAsciiPaint.setColor(Color.rgb(238, 240, 235));
                        canvas.drawText("()o", ax, ay - hop, mAsciiPaint);
                    } else if (mFaunaKind[a] == 2) {
                        boolean flap = ((int) (mFaunaPhase[a] * 1.8f)) % 2 == 0;
                        mAsciiPaint.setColor(Color.rgb(185, 198, 215));
                        canvas.drawText(flap ? "\\v/" : "-v-", ax, ay - pixelsPerUnit * 0.35f - hop, mAsciiPaint);
                    } else {
                        mAsciiPaint.setColor(Color.rgb(245, 165, 115));
                        canvas.drawText(mFaunaVx[a] >= 0 ? "<><" : "><>", ax, ay, mAsciiPaint);
                    }
                }

                mAsciiPaint.setTextAlign(Paint.Align.LEFT);
                for (int lIdx = 0; lIdx < MAX_LOOT; lIdx++) {
                    if (mLootActive[lIdx]) {
                        float lx = centerX + (mLootX[lIdx] - mCamX) * pixelsPerUnit;
                        float ly = centerY + (mLootY[lIdx] - mCamY) * pixelsPerUnit;
                        mAsciiPaint.setColor(Color.rgb(245, 212, 98));
                        canvas.drawText("@WM#*+", lx - pixelsPerUnit * 0.3f, ly, mAsciiPaint);
                    }
                }

                float enemyCellPx = (pixelsPerUnit * 2.15f) / ENEMY_BUF_W;
                for (int eIdx = 0; eIdx < NUM_ENEMIES; eIdx++) {
                    float ex = centerX + (mEnemyX[eIdx] - mCamX) * pixelsPerUnit;
                    float ey = centerY + (mEnemyY[eIdx] - mCamY) * pixelsPerUnit;
                    if (ex < -140 || ex > screenW + 140 || ey < -140 || ey > screenH + 140) continue;

                    mShadowPaint.setColor(Color.argb(175, 5, 8, 7));
                    mTmpRect.set(ex - pixelsPerUnit * 0.36f, ey + pixelsPerUnit * 0.14f, ex + pixelsPerUnit * 0.56f, ey + pixelsPerUnit * 0.44f);
                    canvas.drawOval(mTmpRect, mShadowPaint);

                    rasterizeEnemyHumanoidAscii(eIdx);
                    int tint = 0;
                    if (mEnemyHurt[eIdx] > 0.0f) tint = Color.rgb(242, 82, 82);
                    else if (mEnemyAtkWindup[eIdx] > 0.0f) tint = Color.rgb(255, 175, 95);
                    drawAsciiBufferSpanBatched(
                            canvas, mEnemyGlyphBuf, mEnemyColorBuf, ENEMY_BUF_W, ENEMY_BUF_H,
                            ex - (ENEMY_BUF_W * 0.5f) * enemyCellPx,
                            ey - (ENEMY_BUF_H * 0.65f) * enemyCellPx,
                            enemyCellPx, true, tint
                    );
                }

                drawStructuresAndStones(canvas, centerX, centerY, pixelsPerUnit, screenW, screenH, true);

                for (int g = 0; g < MAX_AFTERIMAGES; g++) {
                    if (mGhostLife[g] > 0.0f) {
                        float gx = centerX + (mGhostX[g] - mCamX) * pixelsPerUnit;
                        float gy = centerY + (mGhostY[g] - mCamY) * pixelsPerUnit;
                        int alpha = Math.max(30, Math.min(180, (int) ((mGhostLife[g] / 0.24f) * 165.0f)));
                        int gCol = Color.argb(alpha, 150, 240, 225);
                        if (mMounted) {
                            drawHorseGlyphs(canvas, gx, gy, pixelsPerUnit, false, gCol);
                        } else {
                            drawHeroGlyphs(canvas, gx, gy, pixelsPerUnit, false, gCol);
                        }
                    }
                }

                drawHeroEntity(canvas, centerX, centerY, pixelsPerUnit);

                if (mPlayerElevation == 0) {
                    mGrassFx.drawForeground(canvas, gen, mPlayerX, mPlayerY, mCamX, mCamY, centerX, centerY,
                            pixelsPerUnit, mTimeSec, windScale);
                }

                drawStructuresAndStones(canvas, centerX, centerY, pixelsPerUnit, screenW, screenH, false);

                mAsciiPaint.setTextSize(Math.max(10.0f, pixelsPerUnit * 0.17f));
                mAsciiPaint.setTextAlign(Paint.Align.LEFT);
                for (int pIdx = 0; pIdx < MAX_PARTICLES; pIdx++) {
                    if (mPartLife[pIdx] > 0.0f) {
                        float px = centerX + (mPartX[pIdx] - mCamX) * pixelsPerUnit;
                        float py = centerY + (mPartY[pIdx] - mCamY) * pixelsPerUnit;
                        mAsciiPaint.setColor(mPartColor[pIdx]);
                        canvas.drawText("*", px, py, mAsciiPaint);
                    }
                }

                if (mSlashTimer > 0.0f) {
                    mAsciiPaint.setTextSize(Math.max(13.0f, pixelsPerUnit * 0.25f));
                    float hx = centerX + (mPlayerX - mCamX) * pixelsPerUnit;
                    float hy = centerY + (mPlayerY - mCamY) * pixelsPerUnit;
                    float baseAng = (float) Math.atan2(mFacingY, mFacingX);
                    int steps = (mSlashCombo == 2) ? 14 : 7;
                    for (int a = -steps; a <= steps; a++) {
                        float ang = baseAng + a * 0.22f;
                        float rx = hx + (float) Math.cos(ang) * pixelsPerUnit * 1.42f;
                        float ry = hy + (float) Math.sin(ang) * pixelsPerUnit * 1.08f;
                        mAsciiPaint.setColor(Math.abs(a) <= 2 ? Color.rgb(255, 244, 185) : Color.rgb(255, 148, 52));
                        int sIdx = Math.abs(a + 14) % 5;
                        canvas.drawText("*+@#8", sIdx, sIdx + 1, rx, ry, mAsciiPaint);
                    }
                }

                mUiPaint.setTextAlign(Paint.Align.CENTER);
                mUiPaint.setTextSize(Math.max(14.0f, pixelsPerUnit * 0.22f));
                for (int k = 0; k < MAX_POPUPS; k++) {
                    if (mPopLife[k] > 0.0f && mPopText[k] != null) {
                        float px = centerX + (mPopX[k] - mCamX) * pixelsPerUnit;
                        float py = centerY + (mPopY[k] - mCamY) * pixelsPerUnit;
                        mUiPaint.setColor(mPopColor[k]);
                        canvas.drawText(mPopText[k], px, py, mUiPaint);
                    }
                }

                for (int oi = 0; oi < mObjs.size(); oi++) {
                    WorldGen.Obj o = mObjs.get(oi);
                    if (o.kind == WorldGen.PILLAR || o.kind == WorldGen.BOULDER || o.kind == WorldGen.TREE
                            || o.kind == WorldGen.RUIN_WALL || o.kind == WorldGen.SHRUB || o.kind == WorldGen.BANNER) {
                        continue;
                    }
                    boolean cyan = (o.kind == WorldGen.SHRINE || o.kind == WorldGen.CAVE);
                    mGlowPaint.setAlpha(o.kind == WorldGen.CAVE ? 85 : 235);
                    float gx = centerX + (o.x - mCamX) * pixelsPerUnit;
                    float gy = centerY + (o.y + (o.kind == WorldGen.WATCHTOWER ? -2.8f : (o.kind == WorldGen.HOUSE ? 0.8f : (o.kind == WorldGen.CAVE ? -o.h * 0.4f : 0.0f))) - mCamY) * pixelsPerUnit;
                    float gRad = pixelsPerUnit * ((o.kind == WorldGen.WATCHTOWER || o.kind == WorldGen.CITADEL ? 3.2f : 2.5f)
                            + 0.25f * (float) Math.sin(mTimeSec * 4.2f + oi));
                    if (gx < -gRad || gx > screenW + gRad || gy < -gRad || gy > screenH + gRad) continue;
                    mTmpRect.set(gx - gRad, gy - gRad, gx + gRad, gy + gRad);
                    canvas.drawBitmap(cyan ? mCyanGlowBitmap : mAmberGlowBitmap, null, mTmpRect, mGlowPaint);
                }
                mGlowPaint.setAlpha(255);

                if (!gen.isDarkCitadelBiome(mCamX, mCamY)) {
                    float moistHere = gen.moisture(mCamX, mCamY);
                    int fogA = (int) (255.0f * Math.max(0.28f, Math.min(0.75f, 0.35f + moistHere * 0.65f)));
                    float tileUnits = 9.0f;
                    float sc = tileUnits * pixelsPerUnit / 256.0f;
                    float ddx = 0.55f * mTimeSec;
                    float ddy = 0.18f * mTimeSec;
                    mFogMatrix[0].setScale(sc, sc);
                    mFogMatrix[0].postTranslate(centerX + (ddx - mCamX) * pixelsPerUnit, centerY + (ddy - mCamY) * pixelsPerUnit);
                    mFogShader[0].setLocalMatrix(mFogMatrix[0]);
                    mFogPaint[0].setAlpha(fogA);
                    canvas.drawRect(0, 0, screenW, screenH, mFogPaint[0]);
                }

                mTmpRect.set(0, 0, screenW, screenH);
                canvas.drawBitmap(mVignetteBitmap, null, mTmpRect, mBitmapPaint);

                if (mScreenMode == 1 && mPlayerElevation == 1) {
                    mUiPaint.setTextAlign(Paint.Align.CENTER);
                    mUiPaint.setTextSize(Math.min(screenW, screenH) * 0.046f);
                    mUiPaint.setColor(Color.rgb(245, 248, 246));
                    canvas.drawText("Tower high ground", screenW * 0.5f, screenH * 0.19f, mUiPaint);
                }

                if (mScreenMode == 1) {
                    float curX = mCursorX * screenW;
                    float curY = mCursorY * screenH;
                    float arm = Math.min(screenW, screenH) * 0.017f;
                    mBorderPaint.setColor(Color.argb(215, 236, 241, 238));
                    mBorderPaint.setStrokeWidth(2.2f);
                    canvas.drawLine(curX - arm, curY, curX + arm, curY, mBorderPaint);
                    canvas.drawLine(curX, curY - arm, curX, curY + arm, mBorderPaint);
                }

                if (mScreenMode == 0) {
                    drawStartMenuOverlay(canvas, screenW, screenH);
                } else if (mScreenMode == 1) {
                    drawModernHud(canvas, screenW, screenH);
                } else if (mScreenMode == 2) {
                    drawCharacterAndInventoryModal(canvas, screenW, screenH);
                }
            } finally {
                if (canvas != null) {
                    holder.unlockCanvasAndPost(canvas);
                }
            }
        }

        private void drawWorldProps(Canvas canvas, float centerX, float centerY, float ppu, int screenW, int screenH) {
            float propFontPx = Math.max(8.5f, ppu * 0.16f);
            mAsciiPaint.setTextSize(propFontPx);

            for (int oi = 0; oi < mObjs.size(); oi++) {
                WorldGen.Obj o = mObjs.get(oi);
                float hx = centerX + (o.x - mCamX) * ppu;
                float hy = centerY + (o.y - mCamY) * ppu;
                if (hx < -360 || hx > screenW + 360 || hy < -360 || hy > screenH + 360) continue;

                if (o.kind == WorldGen.SHRINE) {
                    mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                    mAsciiPaint.setColor(Color.rgb(125, 245, 220));
                    canvas.drawText("[*]", hx, hy, mAsciiPaint);
                } else if (o.kind == WorldGen.SHRUB) {
                    // Small triangular green ASCII bush/shrub (matching forest_trees.png & banners_lanterns.png!)
                    mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                    for (int sr = 0; sr < SHRUB_ART.length; sr++) {
                        float ry = hy - (SHRUB_ART.length - sr) * propFontPx * 0.85f;
                        mAsciiPaint.setColor(sr < 2 ? Color.rgb(138, 198, 158) : Color.rgb(92, 156, 118));
                        canvas.drawText(SHRUB_ART[sr], hx, ry, mAsciiPaint);
                    }
                } else if (o.kind == WorldGen.BANNER) {
                    // Notched Crimson/Orange Pennant Banner (matching banners_lanterns.png!)
                    mAsciiPaint.setTextAlign(Paint.Align.LEFT);
                    float bH = BANNER_ART.length * propFontPx * 0.84f;
                    for (int br = 0; br < BANNER_ART.length; br++) {
                        float ry = hy - bH + br * propFontPx * 0.84f;
                        mAsciiPaint.setColor(br <= 2 ? Color.rgb(218, 108, 72) : Color.rgb(212, 86, 56));
                        canvas.drawText(BANNER_ART[br], hx - propFontPx * 4.0f, ry, mAsciiPaint);
                    }
                } else if (o.kind == WorldGen.LANTERN) {
                    // Gallows-style Iron Lantern Post + Flickering Ground Campfire (matching banners_lanterns.png!)
                    mAsciiPaint.setTextAlign(Paint.Align.LEFT);
                    float lH = LANTERN_ART.length * propFontPx * 0.84f;
                    for (int lr = 0; lr < LANTERN_ART.length; lr++) {
                        float ry = hy - lH + lr * propFontPx * 0.84f;
                        mAsciiPaint.setColor((lr >= 5) ? Color.rgb(245, 185, 86) : Color.rgb(214, 152, 74));
                        canvas.drawText(LANTERN_ART[lr], hx - propFontPx * 3.0f, ry, mAsciiPaint);
                    }
                    mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                    drawCampfireCluster(canvas, hx - ppu * 1.05f, hy + ppu * 0.35f, propFontPx, oi);
                } else if (o.kind == WorldGen.RUIN_WALL) {
                    mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                    float rH = RUIN_WALL_ART.length * propFontPx * 0.88f;
                    float rW = propFontPx * 18.0f;
                    for (int rr = 0; rr < RUIN_WALL_ART.length; rr++) {
                        float ry = hy - rH + rr * propFontPx * 0.88f;
                        mPanelPaint.setColor(Color.argb(235, 4, 6, 10));
                        canvas.drawRect(hx - rW * 0.5f, ry - propFontPx * 0.82f, hx + rW * 0.5f, ry + propFontPx * 0.15f, mPanelPaint);
                        boolean warmLit = ((oi + rr) % 4 == 0);
                        mAsciiPaint.setColor(warmLit ? Color.rgb(214, 154, 96) : Color.rgb(138, 156, 182));
                        canvas.drawText(RUIN_WALL_ART[rr], hx, ry, mAsciiPaint);
                    }
                } else if (o.kind == WorldGen.HOUSE) {
                    mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                    float hW = propFontPx * 13.8f;
                    float hH = HOUSE_ART.length * propFontPx * 0.90f;
                    mShadowPaint.setColor(Color.argb(180, 4, 7, 6));
                    mTmpRect.set(hx - hW * 0.48f, hy + hH * 0.28f, hx + hW * 0.56f, hy + hH * 0.52f);
                    canvas.drawOval(mTmpRect, mShadowPaint);

                    for (int hr = 0; hr < HOUSE_ART.length; hr++) {
                        float ry = hy - hH * 0.5f + hr * propFontPx * 0.90f;
                        mPanelPaint.setColor(Color.rgb(7, 9, 11));
                        canvas.drawRect(hx - hW * 0.5f, ry - propFontPx * 0.82f, hx + hW * 0.5f, ry + propFontPx * 0.14f, mPanelPaint);
                        mAsciiPaint.setColor(hr < 4 ? Color.rgb(165, 178, 192) : (hr >= 6 ? Color.rgb(248, 200, 110) : Color.rgb(210, 214, 218)));
                        canvas.drawText(HOUSE_ART[hr], hx, ry, mAsciiPaint);
                    }
                    drawCampfireCluster(canvas, hx + ppu * 1.45f, hy + ppu * 0.65f, propFontPx, oi);
                }
            }
        }

        private void drawCampfireCluster(Canvas canvas, float cx, float cy, float fontPx, int salt) {
            int fPhase = ((int) (mTimeSec * 10.0f + salt)) % 3;
            String[] fireRows = (fPhase == 0)
                    ? new String[]{"  * ^ *  ", " %@###@% ", "Q88@@@88Q"}
                    : (fPhase == 1
                    ? new String[]{" ^ * + ^ ", " #@%%%@# ", "Q8@@@@@8Q"}
                    : new String[]{"  + * ^  ", " @#%@%#@ ", "Q88@@@88Q"});
            for (int r = 0; r < 3; r++) {
                mAsciiPaint.setColor(r == 0 ? Color.rgb(255, 238, 155) : (r == 1 ? Color.rgb(255, 168, 58) : Color.rgb(225, 98, 38)));
                canvas.drawText(fireRows[r], cx, cy + (r - 1) * fontPx * 0.78f, mAsciiPaint);
            }
        }

        private final float[] mSpriteBaseTmp = new float[2];

        private void drawStructuresAndStones(Canvas canvas, float centerX, float centerY, float ppu,
                                             int screenW, int screenH, boolean behind) {
            for (int oi = 0; oi < mObjs.size(); oi++) {
                WorldGen.Obj o = mObjs.get(oi);
                if (o.kind != WorldGen.PILLAR && o.kind != WorldGen.BOULDER
                        && o.kind != WorldGen.WATCHTOWER && o.kind != WorldGen.CITADEL && o.kind != WorldGen.TREE) {
                    continue;
                }
                boolean objBehindHero;
                if (o.kind == WorldGen.WATCHTOWER && mPlayerElevation == 1) {
                    objBehindHero = true;
                } else if (o.kind == WorldGen.CITADEL) {
                    objBehindHero = (o.y - 0.8f <= mPlayerY) || mGen.onCitadelBridge(mPlayerX, mPlayerY);
                } else {
                    objBehindHero = (o.y <= mPlayerY);
                }
                if (objBehindHero != behind) continue;

                float sx = centerX + (o.x - mCamX) * ppu;
                float sy = centerY + (o.y - mCamY) * ppu;
                float reachX = o.w * 1.5f * ppu;
                float top0 = sy - (o.h + o.w * 0.4f) * ppu;
                float bot0 = sy + o.w * 0.5f * ppu;
                if (bot0 < -140 || top0 > screenH + 140 || sx < -reachX || sx > screenW + reachX) continue;

                Bitmap b = spriteFor(o, mSpriteBaseTmp);
                float unitPpu = (o.kind == WorldGen.WATCHTOWER) ? 68.0f
                        : (o.kind == WorldGen.CITADEL ? 56.0f : (o.kind == WorldGen.TREE ? 64.0f : Gfx.SPRITE_PPU));
                float scale = ppu / unitPpu;

                mShadowPaint.setColor(Color.argb(150, 2, 5, 4));
                mTmpRect.set(sx - o.w * 0.52f * ppu, sy - o.w * 0.16f * ppu, sx + o.w * 0.88f * ppu, sy + o.w * 0.30f * ppu);
                canvas.drawOval(mTmpRect, mShadowPaint);
                if (b == null) continue;
                float left = sx - mSpriteBaseTmp[0] * scale;
                float top = sy - mSpriteBaseTmp[1] * scale;
                mTmpRect.set(left, top, left + b.getWidth() * scale, top + b.getHeight() * scale);
                canvas.drawBitmap(b, null, mTmpRect, mBitmapPaint);

                if (o.kind == WorldGen.WATCHTOWER) {
                    float fireX = sx + 0.55f * ppu;
                    float fireY = sy - 2.85f * ppu;
                    mAsciiPaint.setTextSize(Math.max(9.0f, ppu * 0.16f));
                    mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                    drawCampfireCluster(canvas, fireX, fireY, Math.max(9.0f, ppu * 0.16f), oi);
                }
            }
        }

        private static float h01(int a) {
            int x = a * 0x9E3779B1;
            x ^= (x >>> 15);
            x *= 0x85EBCA6B;
            x ^= (x >>> 13);
            return (x & 0xFFFF) / 65535.0f;
        }

        private void drawCaveMouth(Canvas canvas, WorldGen.Obj o, float cx, float cy, float ppu) {
            float rw = o.w * 0.5f * ppu;
            float rh = o.h * 0.5f * ppu;
            mShadowPaint.setColor(Color.argb(150, 2, 4, 6));
            mTmpRect.set(cx - rw * 1.25f, cy - rh * 1.95f, cx + rw * 1.25f, cy + rh * 0.55f);
            canvas.drawOval(mTmpRect, mShadowPaint);
            mShadowPaint.setColor(Color.rgb(2, 4, 7));
            mTmpRect.set(cx - rw, cy - rh * 1.6f, cx + rw, cy + rh * 0.35f);
            canvas.drawOval(mTmpRect, mShadowPaint);
            mAsciiPaint.setTextAlign(Paint.Align.CENTER);
            mAsciiPaint.setTextSize(Math.max(8.0f, ppu * 0.12f));
            mAsciiPaint.setColor(Color.argb(120, 70, 92, 118));
            for (int r = 0; r < 4; r++) {
                canvas.drawText(". : . : . : .", cx, cy - rh * 1.2f + r * ppu * 0.24f, mAsciiPaint);
            }
            for (int k = 0; k < 26; k++) {
                float ax = h01(o.variant + k * 31 + 1);
                float ay = h01(o.variant + k * 57 + 7);
                float tw = 0.5f + 0.5f * (float) Math.sin(mTimeSec * 2.4f + k * 1.7f);
                float mx = cx + (ax - 0.5f) * 1.7f * rw;
                float my = cy - rh * 1.5f + ay * rh * 1.7f;
                mPanelPaint.setColor(Color.argb((int) (80 + 160 * tw), 190, 250, 240));
                canvas.drawCircle(mx, my, Math.max(1.4f, ppu * (0.010f + 0.012f * tw)), mPanelPaint);
            }
        }

        private void drawWaterEffects(Canvas canvas, float centerX, float centerY, float ppu, float halfW, float halfH) {
            final WorldGen gen = mGen;
            int nb = 0;
            int nd = 0;
            final float step = 0.9f;
            float x0 = (float) Math.floor((mCamX - halfW) / step) * step;
            float y0 = (float) Math.floor((mCamY - halfH) / step) * step;
            for (float wy = y0; wy <= mCamY + halfH; wy += step) {
                for (float wx = x0; wx <= mCamX + halfW; wx += step) {
                    int hx = (int) Math.floor(wx / step);
                    int hy = (int) Math.floor(wy / step);
                    float jx = wx + (gen.hash01(hx, hy, 1) - 0.5f) * step;
                    float jy = wy + (gen.hash01(hx, hy, 2) - 0.5f) * step;
                    float d = gen.waterDepth(jx, jy);
                    if (d <= 0.0f || d > 0.13f) continue;
                    float e = 0.25f;
                    float gx = gen.waterDepth(jx + e, jy) - gen.waterDepth(jx - e, jy);
                    float gy = gen.waterDepth(jx, jy + e) - gen.waterDepth(jx, jy - e);
                    float gl = (float) Math.sqrt(gx * gx + gy * gy);
                    if (gl < 1e-4f) continue;
                    float nxs = gx / gl;
                    float nys = gy / gl;
                    float tx = -nys;
                    float ty = nxs;
                    float ph = mTimeSec * 0.9f + gen.hash01(hx, hy, 3) * 6.2832f;
                    float k = 0.5f + 0.5f * (float) Math.sin(ph);
                    if (k < 0.22f) continue;
                    float drift = (float) Math.sin(ph * 0.7f) * 0.14f;
                    float len = 0.55f + gen.hash01(hx, hy, 4) * 0.6f;
                    float cxw = jx + nxs * drift;
                    float cyw = jy + nys * drift;
                    float bend = 0.10f * (float) Math.sin(ph * 1.3f);
                    float p0x = centerX + (cxw - tx * len * 0.5f - mCamX) * ppu;
                    float p0y = centerY + (cyw - ty * len * 0.5f - mCamY) * ppu;
                    float p1x = centerX + (cxw + nxs * bend - mCamX) * ppu;
                    float p1y = centerY + (cyw + nys * bend - mCamY) * ppu;
                    float p2x = centerX + (cxw + tx * len * 0.5f - mCamX) * ppu;
                    float p2y = centerY + (cyw + ty * len * 0.5f - mCamY) * ppu;
                    float[] arr = (k > 0.7f) ? mFoamBright : mFoamDim;
                    int cnt = (k > 0.7f) ? nb : nd;
                    if (cnt + 8 > arr.length) continue;
                    arr[cnt++] = p0x; arr[cnt++] = p0y; arr[cnt++] = p1x; arr[cnt++] = p1y;
                    arr[cnt++] = p1x; arr[cnt++] = p1y; arr[cnt++] = p2x; arr[cnt++] = p2y;
                    if (k > 0.7f) nb = cnt; else nd = cnt;
                }
            }
            mGrassPaint.setStrokeWidth(Math.max(1.8f, ppu * 0.022f));
            if (nd > 0) {
                mGrassPaint.setColor(Color.argb(150, 120, 150, 188));
                canvas.drawLines(mFoamDim, 0, nd, mGrassPaint);
            }
            if (nb > 0) {
                mGrassPaint.setStrokeWidth(Math.max(2.2f, ppu * 0.03f));
                mGrassPaint.setColor(Color.argb(235, 226, 238, 250));
                canvas.drawLines(mFoamBright, 0, nb, mGrassPaint);
            }

            if (mPlayerElevation == 0 && gen.waterDepth(mPlayerX, mPlayerY + 0.45f) > 0.0f) {
                float hx = centerX + (mPlayerX - mCamX) * ppu;
                float hy = centerY + (mPlayerY - mCamY) * ppu;
                int reflCol = Color.argb(95, 140, 175, 205);
                canvas.save();
                canvas.scale(1.0f, -1.0f, hx, hy + ppu * 0.22f);
                if (mMounted) {
                    drawHorseGlyphs(canvas, hx, hy, ppu, false, reflCol);
                } else {
                    drawHeroGlyphs(canvas, hx, hy, ppu, false, reflCol);
                }
                canvas.restore();
            }
        }

        private void drawStartMenuOverlay(Canvas canvas, int w, int h) {
            mPanelPaint.setColor(Color.argb(120, 5, 9, 8));
            canvas.drawRect(0, 0, w, h, mPanelPaint);

            mUiPaint.setTextAlign(Paint.Align.CENTER);
            float titleSize = Math.min(w, h) * 0.085f;
            mUiPaint.setTextSize(titleSize);
            mUiPaint.setColor(Color.rgb(244, 248, 245));
            canvas.drawText("A S H V E I L", w * 0.5f, h * 0.20f, mUiPaint);

            mUiSubPaint.setTextAlign(Paint.Align.CENTER);
            mUiSubPaint.setTextSize(titleSize * 0.36f);
            mUiSubPaint.setColor(Color.rgb(185, 204, 194));
            canvas.drawText("Senje • Chainmail, Watchtower High Ground & Citadel", w * 0.5f, h * 0.26f, mUiSubPaint);

            float btnTextSize = Math.min(w, h) * 0.031f;
            mUiPaint.setTextSize(btnTextSize);

            String zoomLabel = (mZoomPreset == 0) ? "Close-up" : (mZoomPreset == 1 ? "Medium" : "Wide");
            String modeLabel = mMounted ? "Mounted Steed" : "Foot Knight (Senje)";
            String atkLabel = mAttackButtonOnly ? "Action Button" : "Tap Anywhere";

            String[] buttons = {
                    "[ Enter the World ]",
                    null,
                    "Camera Zoom: " + zoomLabel,
                    "Style: " + modeLabel,
                    "Attack Mode: " + atkLabel,
                    "CRAFT · Bloody Mail Coif & Dark Greaves"
            };
            for (int b = 0; b < buttons.length; b++) {
                float top = h * MENU_TOPS[b];
                float bot = top + h * MENU_H;
                if (buttons[b] == null) {
                    String[] half = {"[ New World ]", "Seed: " + mWorldSeed};
                    for (int k = 0; k < 2; k++) {
                        float l = (k == 0) ? w * 0.22f : w * 0.505f;
                        float r = (k == 0) ? w * 0.495f : w * 0.78f;
                        mTmpRect.set(l, top, r, bot);
                        mPanelPaint.setColor(Color.argb(225, 4, 6, 8));
                        canvas.drawRect(mTmpRect, mPanelPaint);
                        mBorderPaint.setColor(Color.rgb(150, 160, 165));
                        canvas.drawRect(mTmpRect, mBorderPaint);
                        mUiPaint.setTextSize(btnTextSize * (k == 1 ? 0.92f : 1.0f));
                        mUiPaint.setColor(Color.rgb(242, 246, 244));
                        canvas.drawText(half[k], (l + r) * 0.5f, (top + bot) * 0.5f + btnTextSize * 0.35f, mUiPaint);
                    }
                    mUiPaint.setTextSize(btnTextSize);
                    continue;
                }
                mTmpRect.set(w * 0.22f, top, w * 0.78f, bot);
                mPanelPaint.setColor(b == 0 ? Color.argb(235, 10, 26, 20) : Color.argb(225, 4, 6, 8));
                canvas.drawRect(mTmpRect, mPanelPaint);
                mBorderPaint.setColor(b == 0 ? Color.rgb(155, 232, 185) : Color.rgb(150, 160, 165));
                canvas.drawRect(mTmpRect, mBorderPaint);
                mUiPaint.setColor(Color.rgb(242, 246, 244));
                canvas.drawText(buttons[b], w * 0.5f, (top + bot) * 0.5f + btnTextSize * 0.35f, mUiPaint);
            }
        }

        private void drawTickBar(Canvas canvas, float x, float y, float bw, float bh, float ratio, int tickColor) {
            mTmpRect.set(x, y, x + bw, y + bh);
            mBorderPaint.setColor(Color.rgb(205, 208, 212));
            mBorderPaint.setStrokeWidth(1.6f);
            canvas.drawRect(mTmpRect, mBorderPaint);
            float pitch = Math.max(3.0f, bh * 0.26f);
            int ticks = (int) ((bw - 6.0f) / pitch);
            int lit = (int) (ticks * Math.max(0.0f, Math.min(1.0f, ratio)) + 0.5f);
            lit = Math.min(lit, mTickPts.length / 4);
            for (int i = 0; i < lit; i++) {
                float tx = x + 4.0f + i * pitch;
                mTickPts[i * 4] = tx;
                mTickPts[i * 4 + 1] = y + 3.0f;
                mTickPts[i * 4 + 2] = tx;
                mTickPts[i * 4 + 3] = y + bh - 3.0f;
            }
            mGrassPaint.setStrokeWidth(1.5f);
            mGrassPaint.setColor(tickColor);
            if (lit > 0) canvas.drawLines(mTickPts, 0, lit * 4, mGrassPaint);
            mBorderPaint.setStrokeWidth(2.2f);
        }

        private void drawModernHud(Canvas canvas, int w, int h) {
            float cardW = Math.min(w * 0.46f, 520.0f);
            float cardH = cardW * 0.345f;
            float x0 = 8.0f;
            float y0 = 10.0f;
            mTmpRect.set(x0, y0, x0 + cardW, y0 + cardH);
            mPanelPaint.setColor(Color.rgb(0, 0, 0));
            canvas.drawRect(mTmpRect, mPanelPaint);
            mBorderPaint.setColor(Color.rgb(176, 178, 180));
            mBorderPaint.setStrokeWidth(3.0f);
            canvas.drawRect(mTmpRect, mBorderPaint);
            mBorderPaint.setStrokeWidth(2.2f);

            float pcellH = (cardH * 0.80f) / FOOT_BUF_H;
            drawHeroGlyphsAt(canvas, x0 + cardW * 0.045f, y0 + cardH * 0.10f, pcellH / 1.3f, pcellH, false, 0);

            float colX = x0 + cardW * 0.235f;
            mUiPaint.setTextAlign(Paint.Align.LEFT);
            mUiPaint.setTextSize(cardH * 0.17f);
            mUiPaint.setColor(Color.rgb(232, 236, 238));
            canvas.drawText("Senje", colX, y0 + cardH * 0.27f, mUiPaint);

            float barX = colX + cardW * 0.075f;
            float barW = cardW * 0.375f;
            float barH = cardH * 0.135f;
            float numX = barX + barW + cardW * 0.02f;
            mUiSubPaint.setTextAlign(Paint.Align.LEFT);
            mUiSubPaint.setTextSize(cardH * 0.125f);

            float hpY = y0 + cardH * 0.345f;
            mUiSubPaint.setColor(Color.rgb(205, 208, 212));
            canvas.drawText("HP", colX, hpY + barH * 0.95f, mUiSubPaint);
            drawTickBar(canvas, barX, hpY, barW, barH, mHp / (float) Math.max(1, mMaxHp), Color.rgb(214, 218, 222));
            mUiSubPaint.setColor(Color.rgb(226, 230, 232));
            canvas.drawText(mHp + "/" + mMaxHp, numX, hpY + barH * 0.95f, mUiSubPaint);

            float mpY = y0 + cardH * 0.54f;
            mUiSubPaint.setColor(Color.rgb(205, 208, 212));
            canvas.drawText("MP", colX, mpY + barH * 0.95f, mUiSubPaint);
            drawTickBar(canvas, barX, mpY, barW, barH, mMp / (float) Math.max(1, mMaxMp), Color.rgb(214, 218, 222));
            mUiSubPaint.setColor(Color.rgb(226, 230, 232));
            canvas.drawText(mMp + "/" + mMaxMp, numX, mpY + barH * 0.95f, mUiSubPaint);

            mUiSubPaint.setColor(Color.rgb(226, 230, 232));
            canvas.drawText("LV " + mLevel + " \u00B7 " + mGold + "g  [CRAFT]", colX, y0 + cardH * 0.86f, mUiSubPaint);

            float pillW = Math.min(w * 0.18f, 172.0f);
            float pillH = Math.max(36.0f, cardH * 0.34f);
            float px = w - pillW - 18.0f;
            String[] pills = {"[MENU]", "[ZOOM]", mMounted ? "[DISMOUNT]" : "[STEED]"};
            for (int i = 0; i < 3; i++) {
                float py = y0 + i * (pillH + 8.0f);
                mTmpRect.set(px, py, px + pillW, py + pillH);
                mPanelPaint.setColor(Color.rgb(0, 0, 0));
                canvas.drawRect(mTmpRect, mPanelPaint);
                mBorderPaint.setColor((i == 2 && mMounted) ? Color.rgb(155, 232, 185) : Color.rgb(200, 203, 206));
                canvas.drawRect(mTmpRect, mBorderPaint);
                mUiPaint.setTextAlign(Paint.Align.CENTER);
                mUiPaint.setTextSize(pillH * 0.40f);
                mUiPaint.setColor(Color.rgb(240, 245, 242));
                canvas.drawText(pills[i], px + pillW * 0.5f, py + pillH * 0.64f, mUiPaint);
            }

            float atkR = Math.min(w, h) * 0.088f;
            float atkCx = w - atkR - 26.0f;
            float atkCy = h - atkR - 26.0f - btnLift(w, h);
            mPanelPaint.setColor(mSlashTimer > 0.0f ? Color.argb(235, 92, 52, 28) : Color.argb(190, 4, 6, 8));
            mBorderPaint.setColor(mSlashCooldown > 0.0f ? Color.rgb(140, 118, 95) : Color.rgb(252, 195, 110));
            canvas.drawCircle(atkCx, atkCy, atkR, mPanelPaint);
            canvas.drawCircle(atkCx, atkCy, atkR, mBorderPaint);
            mUiPaint.setTextSize(atkR * 0.40f);
            mUiPaint.setColor(Color.rgb(252, 242, 224));
            canvas.drawText("[ATK]", atkCx, atkCy + atkR * 0.15f, mUiPaint);

            float dodgeR = Math.min(w, h) * 0.070f;
            float dodgeCx = atkCx - atkR - dodgeR - 22.0f;
            float dodgeCy = h - dodgeR - 26.0f - btnLift(w, h);
            mPanelPaint.setColor(mDodgeTimer > 0.0f ? Color.argb(235, 42, 98, 106) : Color.argb(190, 4, 8, 10));
            mBorderPaint.setColor(mDodgeCooldown > 0.0f ? Color.rgb(95, 112, 118) : Color.rgb(145, 228, 220));
            canvas.drawCircle(dodgeCx, dodgeCy, dodgeR, mPanelPaint);
            canvas.drawCircle(dodgeCx, dodgeCy, dodgeR, mBorderPaint);
            mUiPaint.setTextSize(dodgeR * 0.32f);
            mUiPaint.setColor(mDodgeCooldown > 0.0f ? Color.rgb(145, 162, 166) : Color.rgb(226, 238, 240));
            canvas.drawText(mDodgeCooldown > 0.0f ? (((int) (mDodgeCooldown * 10.0f + 0.9f) / 10.0f) + "s") : "[DODGE]", dodgeCx, dodgeCy + dodgeR * 0.12f, mUiPaint);

            if (mMovePointerId != -1) {
                mBorderPaint.setColor(Color.argb(130, 195, 228, 210));
                canvas.drawCircle(mJoyBaseX, mJoyBaseY, Math.min(w, h) * 0.11f, mBorderPaint);
                mPanelPaint.setColor(Color.argb(150, 215, 240, 225));
                canvas.drawCircle(mJoyCurrX, mJoyCurrY, Math.min(w, h) * 0.036f, mPanelPaint);
            }

            float hbW = hbWidth(w, h);
            float hbX = (w - hbW) * 0.5f;
            float slotH = hbSlotH(hbW);
            float hbY = h - slotH;
            float xpH = 20.0f;
            float xpY = hbY - xpH - 2.0f;
            float xpRatio = Math.max(0.0f, Math.min(1.0f, mXp / (float) Math.max(1, mXpNext)));
            mTmpRect.set(hbX, xpY, hbX + hbW, xpY + xpH);
            mPanelPaint.setColor(Color.rgb(8, 9, 9));
            canvas.drawRect(mTmpRect, mPanelPaint);
            mTmpRect.set(hbX + 2.0f, xpY + 2.0f, hbX + 2.0f + (hbW - 4.0f) * xpRatio, xpY + xpH - 2.0f);
            mPanelPaint.setColor(Color.rgb(214, 176, 86));
            canvas.drawRect(mTmpRect, mPanelPaint);
            int xpTicks = Math.min(mTickPts.length / 4, (int) ((hbW - 4.0f) * xpRatio / 4.0f));
            for (int i = 0; i < xpTicks; i++) {
                float tx = hbX + 4.0f + i * 4.0f;
                mTickPts[i * 4] = tx;
                mTickPts[i * 4 + 1] = xpY + 2.0f;
                mTickPts[i * 4 + 2] = tx;
                mTickPts[i * 4 + 3] = xpY + xpH - 2.0f;
            }
            mGrassPaint.setStrokeWidth(1.0f);
            mGrassPaint.setColor(Color.argb(110, 90, 66, 20));
            if (xpTicks > 0) canvas.drawLines(mTickPts, 0, xpTicks * 4, mGrassPaint);
            mTmpRect.set(hbX, xpY, hbX + hbW, xpY + xpH);
            mBorderPaint.setColor(Color.rgb(150, 154, 158));
            mBorderPaint.setStrokeWidth(1.6f);
            canvas.drawRect(mTmpRect, mBorderPaint);
            mBorderPaint.setStrokeWidth(2.2f);
            mUiSubPaint.setTextAlign(Paint.Align.CENTER);
            mUiSubPaint.setTextSize(xpH * 0.62f);
            mUiSubPaint.setColor(Color.rgb(14, 12, 6));
            canvas.drawText("LV " + mLevel + " \u00B7 " + mXp + " / " + mXpNext + " XP", w * 0.5f + 1.0f, xpY + xpH * 0.74f + 1.0f, mUiSubPaint);
            mUiSubPaint.setColor(Color.rgb(246, 244, 232));
            canvas.drawText("LV " + mLevel + " \u00B7 " + mXp + " / " + mXpNext + " XP", w * 0.5f, xpY + xpH * 0.74f, mUiSubPaint);

            float slotW = hbW / 10.0f;
            mTmpRect.set(hbX, hbY, hbX + hbW, h);
            mPanelPaint.setColor(Color.rgb(0, 0, 0));
            canvas.drawRect(mTmpRect, mPanelPaint);
            for (int sIdx = 0; sIdx < 10; sIdx++) {
                float sx0 = hbX + sIdx * slotW;
                mTmpRect.set(sx0, hbY, sx0 + slotW, h + 2.0f);
                mBorderPaint.setColor(sIdx == 0 ? Color.rgb(185, 82, 74) : Color.rgb(120, 124, 128));
                mBorderPaint.setStrokeWidth(1.4f);
                canvas.drawRect(mTmpRect, mBorderPaint);
                mUiSubPaint.setTextSize(slotH * 0.22f);
                mUiSubPaint.setColor(Color.rgb(196, 200, 204));
                canvas.drawText(String.valueOf((sIdx + 1) % 10), sx0 + slotW * 0.5f, hbY + slotH * 0.28f, mUiSubPaint);
                if (sIdx == 0) {
                    mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                    mAsciiPaint.setTextSize(slotH * 0.24f);
                    mAsciiPaint.setColor(Color.rgb(218, 68, 56));
                    canvas.drawText("#8Q", sx0 + slotW * 0.5f, hbY + slotH * 0.68f, mAsciiPaint);
                } else if (sIdx == 1) {
                    mUiSubPaint.setColor(Color.rgb(195, 212, 224));
                    canvas.drawText("CRAFT", sx0 + slotW * 0.5f, hbY + slotH * 0.66f, mUiSubPaint);
                }
            }
            mBorderPaint.setStrokeWidth(2.2f);

            if (mBannerTimer > 0.0f) {
                mUiSubPaint.setTextAlign(Paint.Align.CENTER);
                mUiSubPaint.setTextSize(Math.min(w, h) * 0.026f);
                mUiSubPaint.setColor(Color.rgb(245, 238, 195));
                canvas.drawText(mStatusBanner, w * 0.5f, xpY - 14.0f, mUiSubPaint);
            }
        }

        private static final int[] RUNE_COLS = {
                0xFFD8DEE4, 0xFFE8504A, 0xFF6CC8F0, 0xFFE8D060, 0xFFE86088, 0xFF58D890,
                0xFF78E0A8, 0xFF9060E8, 0xFF60D868, 0xFFE8E8E8, 0xFF78F0A0, 0xFFE05050
        };

        private void drawDashedRect(Canvas canvas, float l, float t, float r, float b, int col) {
            mGrassPaint.setStrokeWidth(1.4f);
            mGrassPaint.setColor(col);
            int n = 0;
            float d = 7.0f;
            for (float x = l; x < r - d; x += d * 2.0f) {
                mTickPts[n++] = x; mTickPts[n++] = t; mTickPts[n++] = x + d; mTickPts[n++] = t;
                mTickPts[n++] = x; mTickPts[n++] = b; mTickPts[n++] = x + d; mTickPts[n++] = b;
            }
            for (float y = t; y < b - d; y += d * 2.0f) {
                mTickPts[n++] = l; mTickPts[n++] = y; mTickPts[n++] = l; mTickPts[n++] = y + d;
                mTickPts[n++] = r; mTickPts[n++] = y; mTickPts[n++] = r; mTickPts[n++] = y + d;
            }
            canvas.drawLines(mTickPts, 0, n, mGrassPaint);
        }

        private void drawCharacterAndInventoryModal(Canvas canvas, int w, int h) {
            mPanelPaint.setColor(Color.rgb(4, 5, 6));
            canvas.drawRect(0, 0, w, h, mPanelPaint);

            String[] slots = {"Weapon", "Helm", "Shoulders", "Chest", "Gloves", "Legs", "Boots"};
            String[] runes = {"+", "^", "*", "z", "~", ">", "/", "x", "v", "\u00B0", "\u00A7", "\u2020"};
            String[] metals = {"as forged", "Iron", "Steel", "Bronze", "Silver", "Gold", "Moonsteel", "Nightglass", "Bloodiron", "Ossite", "Emberstone"};
            String[] metalTag = {"", "#%:", "@%.", "&o,", "$s.", "0o.", "0\u00B0.", "N/~", "88:", "=-.", "*+."};
            String[] pieceTitles = {
                    "Ember Greatsword",
                    mHelmVariant == 0 ? "Bloody Mail Coif" : (mHelmVariant == 1 ? "Crusader Greathelm" : "Pointed Bascinet"),
                    "Mail Pauldrons",
                    "Crimson Mail Hauberk",
                    "Vambrace Gauntlets",
                    "Dark Greaves",
                    "Armored Sabatons"
            };

            float ts = Math.min(w, h) * 0.024f;
            mUiPaint.setTextSize(ts);
            mUiSubPaint.setTextSize(ts * 0.86f);

            mAsciiPaint.setTextAlign(Paint.Align.LEFT);
            mAsciiPaint.setTextSize(ts * 1.02f);
            mAsciiPaint.setColor(Color.rgb(214, 218, 222));
            canvas.drawText("CRAFT  \u00B7  " + pieceTitles[mForgeSlot], w * 0.04f, h * 0.034f, mAsciiPaint);
            mAsciiPaint.setTextAlign(Paint.Align.RIGHT);
            canvas.drawText("[x]", w * 0.96f, h * 0.034f, mAsciiPaint);

            float slotW = (w * 0.92f) / 7.0f;
            for (int i = 0; i < 7; i++) {
                float sx = w * 0.04f + i * slotW;
                mTmpRect.set(sx + 2f, h * 0.05f, sx + slotW - 2f, h * 0.11f);
                mPanelPaint.setColor(i == mForgeSlot ? Color.rgb(34, 42, 32) : Color.rgb(10, 12, 14));
                canvas.drawRect(mTmpRect, mPanelPaint);
                mBorderPaint.setColor(i == mForgeSlot ? Color.rgb(218, 212, 145) : Color.rgb(68, 74, 78));
                canvas.drawRect(mTmpRect, mBorderPaint);
                mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                mAsciiPaint.setTextSize(ts * 0.88f);
                mAsciiPaint.setColor(Color.rgb(235, 238, 236));
                canvas.drawText(slots[i], sx + slotW * 0.5f, h * 0.088f, mAsciiPaint);
            }

            float rW = (w * 0.92f) / 12.0f;
            for (int i = 0; i < 12; i++) {
                float rx = w * 0.04f + i * rW;
                mTmpRect.set(rx + 2f, h * 0.135f, rx + rW - 2f, h * 0.20f);
                mPanelPaint.setColor(Color.rgb(10, 12, 14));
                canvas.drawRect(mTmpRect, mPanelPaint);
                mBorderPaint.setColor(Color.rgb(65, 72, 76));
                canvas.drawRect(mTmpRect, mBorderPaint);
                mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                mAsciiPaint.setTextSize(ts * 1.08f);
                mAsciiPaint.setColor(RUNE_COLS[i]);
                canvas.drawText(runes[i], rx + rW * 0.5f, h * 0.178f, mAsciiPaint);
            }

            for (int i = 0; i < 11; i++) {
                int row = (i < 6) ? 0 : 1;
                int col = (i < 6) ? i : (i - 6);
                int colsInRow = (row == 0) ? 6 : 5;
                float mW = (w * 0.92f) / colsInRow;
                float mx = w * 0.04f + col * mW;
                float my = h * (0.22f + row * 0.044f);
                mTmpRect.set(mx + 2f, my, mx + mW - 2f, my + h * 0.039f);
                mPanelPaint.setColor(i == mForgeMetal ? Color.rgb(28, 34, 28) : Color.rgb(10, 12, 13));
                canvas.drawRect(mTmpRect, mPanelPaint);
                mBorderPaint.setColor(i == mForgeMetal ? METAL_COLS[i] : Color.rgb(55, 60, 64));
                canvas.drawRect(mTmpRect, mBorderPaint);
                mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                mAsciiPaint.setTextSize(ts * 0.76f);
                mAsciiPaint.setColor(METAL_COLS[i]);
                canvas.drawText((metalTag[i].isEmpty() ? "" : metalTag[i] + " ") + metals[i], mx + mW * 0.5f, my + h * 0.026f, mAsciiPaint);
            }

            float prevCx = w * 0.38f;
            float prevCy = h * 0.58f;
            float prevR = Math.min(w, h) * 0.22f;
            int baseC = METAL_COLS[mForgeMetal];

            if (mForgeSlot == 5) {
                drawRotatingDarkGreaves(canvas, prevCx, prevCy, prevR, baseC);
            } else if (mForgeSlot == 0) {
                drawRotatingGreatsword(canvas, prevCx, prevCy, prevR);
            } else {
                drawRotatingChainmailCoif(canvas, prevCx, prevCy, prevR, baseC);
            }

            float rpX = w * 0.72f;
            mUiSubPaint.setTextAlign(Paint.Align.LEFT);
            mUiSubPaint.setColor(Color.rgb(185, 195, 192));
            canvas.drawText("Enchant slots", rpX, h * 0.36f, mUiSubPaint);
            for (int e = 0; e < 2; e++) {
                float ex = rpX + e * (w * 0.11f);
                mTmpRect.set(ex, h * 0.38f, ex + w * 0.09f, h * 0.47f);
                mPanelPaint.setColor(Color.rgb(8, 9, 10));
                canvas.drawRect(mTmpRect, mPanelPaint);
                drawDashedRect(canvas, mTmpRect.left, mTmpRect.top, mTmpRect.right, mTmpRect.bottom, Color.rgb(120, 126, 130));
                int rIdx = (e == 0) ? mRuneSlot1 : mRuneSlot2;
                mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                mAsciiPaint.setTextSize(ts * 1.3f);
                mAsciiPaint.setColor(rIdx >= 0 ? RUNE_COLS[rIdx] : Color.rgb(110, 120, 122));
                canvas.drawText(rIdx >= 0 ? runes[rIdx] : "+", ex + w * 0.045f, h * 0.435f, mAsciiPaint);
            }
            canvas.drawText("Metal: " + metals[mForgeMetal], rpX, h * 0.53f, mUiSubPaint);
            int rCount = (mRuneSlot1 >= 0 ? 1 : 0) + (mRuneSlot2 >= 0 ? 0 : 0);
            if (mRuneSlot2 >= 0) rCount++;
            canvas.drawText("Runes: " + rCount + " / 2", rpX, h * 0.58f, mUiSubPaint);
            canvas.drawText(rCount == 0 ? "no enchantments" : ("+" + rCount + " Rune Power"), rpX, h * 0.625f, mUiSubPaint);
            canvas.drawText("LV " + mLevel + " \u00B7 " + mGold + "g", rpX, h * 0.69f, mUiSubPaint);
            canvas.drawText("HP " + mHp + "/" + mMaxHp, rpX, h * 0.74f, mUiSubPaint);
            canvas.drawText("Tap 3D model to cycle style", rpX, h * 0.80f, mUiSubPaint);

            String[] botLabels = {"+Stat (" + mStatPoints + ")", "Craft Potion", "Return to World"};
            float[] botX0 = {w * 0.06f, w * 0.38f, w * 0.72f};
            float[] botX1 = {w * 0.36f, w * 0.70f, w * 0.94f};
            for (int b = 0; b < 3; b++) {
                mTmpRect.set(botX0[b], h * 0.88f, botX1[b], h * 0.95f);
                mPanelPaint.setColor(b == 2 ? Color.rgb(26, 48, 38) : Color.rgb(16, 22, 20));
                canvas.drawRect(mTmpRect, mPanelPaint);
                mBorderPaint.setColor(Color.rgb(95, 118, 108));
                canvas.drawRect(mTmpRect, mBorderPaint);
                mUiPaint.setTextAlign(Paint.Align.CENTER);
                mUiPaint.setColor(Color.rgb(238, 244, 240));
                canvas.drawText(botLabels[b], (botX0[b] + botX1[b]) * 0.5f, h * 0.925f, mUiPaint);
            }
        }

        private void drawRotatingDarkGreaves(Canvas canvas, float cx, float cy, float R, int baseC) {
            String chainChars = (mLegsVariant == 1) ? "#%80Qo:." : "S8(3)co:";
            mAsciiPaint.setTextAlign(Paint.Align.CENTER);
            mAsciiPaint.setTextSize(Math.max(8.5f, R * 0.065f));
            int rows = 36;
            float rotC = (float) Math.cos(mCoifRot * 0.65f);
            float rotS = (float) Math.sin(mCoifRot * 0.65f);

            for (int leg = 0; leg < 2; leg++) {
                float legSide = (leg == 0) ? -0.34f : 0.34f;
                float legX3d = legSide * rotC;
                float legZ3d = legSide * rotS;
                for (int yr = -rows; yr <= rows; yr++) {
                    float ny = yr / (float) rows;
                    float hipJoin = Math.max(0.0f, (-0.55f - ny) / 0.45f);
                    float curCenterX = cx + mixF(legX3d, legSide * 0.45f, hipJoin) * R;
                    float kneeBulge = 0.04f * (float) Math.exp(-((ny - 0.05f) * (ny - 0.05f)) / 0.03f);
                    float calfTaper = (ny > 0.1f) ? (1.0f - (ny - 0.1f) * 0.28f) : 1.0f;
                    float rad = (0.24f * calfTaper + kneeBulge + hipJoin * 0.16f) * R;
                    int cols = Math.max(5, (int) (rad / (R * 0.026f)));

                    for (int xc = -cols; xc <= cols; xc++) {
                        float u = xc / (float) cols;
                        float ang = u * (float) (Math.PI * 0.5f);
                        float nx = (float) Math.sin(ang);
                        float nz = (float) Math.cos(ang);
                        float sx = curCenterX + nx * rad;
                        float sy = cy + ny * R * 1.08f;

                        boolean edge = Math.abs(u) >= 0.88f;
                        float light = nz * 0.65f - nx * 0.42f + (legZ3d * 0.15f);
                        if (light < 0.08f && !edge) continue;

                        int lum = edge ? 215 : Math.max(65, Math.min(255, (int) (light * 185 + 70)));
                        mAsciiPaint.setColor(Color.rgb(
                                Math.min(255, (Color.red(baseC) * lum) / 210),
                                Math.min(255, (Color.green(baseC) * lum) / 210),
                                Math.min(255, (Color.blue(baseC) * lum) / 210)
                        ));
                        if (edge) {
                            mSingleChar[0] = (Math.abs(ny) < 0.2f) ? '/' : '|';
                        } else {
                            mSingleChar[0] = chainChars.charAt(Math.abs(yr * 5 + xc * 3 + leg) % chainChars.length());
                        }
                        canvas.drawText(mSingleChar, 0, 1, sx, sy, mAsciiPaint);
                    }
                }
            }
        }

        private void drawRotatingGreatsword(Canvas canvas, float cx, float cy, float R) {
            mAsciiPaint.setTextAlign(Paint.Align.CENTER);
            mAsciiPaint.setTextSize(Math.max(9.0f, R * 0.068f));
            float tilt = (float) Math.sin(mCoifRot * 0.8f) * 0.35f;
            float cosT = (float) Math.cos(tilt);
            float sinT = (float) Math.sin(tilt);
            for (int r = -36; r <= 36; r++) {
                float ny = r / 36.0f;
                boolean isGuard = Math.abs(ny - 0.48f) < 0.06f;
                boolean isGrip = ny > 0.48f;
                float halfW = isGuard ? 0.46f : (isGrip ? 0.07f : 0.11f * (1.0f - Math.max(0.0f, (-0.5f - ny) * 1.8f)));
                int cols = Math.max(1, (int) (halfW * 28));
                for (int c = -cols; c <= cols; c++) {
                    float nx = (c / (float) Math.max(1, cols)) * halfW;
                    float sx = cx + (nx * cosT - ny * sinT) * R;
                    float sy = cy + (nx * sinT + ny * cosT) * R * 1.05f;
                    if (isGuard || isGrip) {
                        mAsciiPaint.setColor(isGuard ? Color.rgb(215, 222, 230) : Color.rgb(168, 118, 74));
                        mSingleChar[0] = isGuard ? '=' : '#';
                    } else {
                        float core = 1.0f - Math.abs(c) / (float) Math.max(1, cols);
                        mAsciiPaint.setColor(Color.rgb(255, Math.min(255, (int) (130 + core * 115)), (int) (45 + core * 110)));
                        mSingleChar[0] = FIRE_GLYPHS.charAt(Math.abs(r * 3 + c) % FIRE_GLYPHS.length());
                    }
                    canvas.drawText(mSingleChar, 0, 1, sx, sy, mAsciiPaint);
                }
            }
        }

        private void drawRotatingChainmailCoif(Canvas canvas, float coifCx, float coifCy, float coifR, int baseC) {
            String chainChars = (mHelmVariant == 1) ? "=#|[]+-" : "S8$#c()35";
            mAsciiPaint.setTextAlign(Paint.Align.CENTER);
            mAsciiPaint.setTextSize(Math.max(8.0f, coifR * 0.062f));
            int rings = 34;
            for (int yr = -rings; yr <= rings; yr++) {
                float ny = yr / (float) rings;
                float profile;
                if (mHelmVariant == 1) {
                    profile = (ny < 0.25f) ? 0.48f : (0.48f + (ny - 0.25f) * 0.62f);
                } else {
                    profile = (ny < -0.15f)
                            ? (float) Math.sqrt(Math.max(0.0f, 1.0f - ((ny + 0.35f) * (ny + 0.35f)) * 1.4f)) * 0.58f
                            : (0.56f + (ny + 0.15f) * 0.48f);
                }
                int cols = Math.max(6, (int) (profile * 46));
                for (int xc = -cols; xc <= cols; xc++) {
                    float angle = ((xc + (yr & 1) * 0.5f) / (float) Math.max(1, cols)) * (float) Math.PI + mCoifRot;
                    float nz = (float) Math.cos(angle);
                    if (nz < -0.10f) continue;
                    if (ny > -0.45f && ny < -0.12f && Math.abs((float) Math.sin(angle)) < 0.32f && nz > 0.4f) continue;
                    float sx = coifCx + (float) Math.sin(angle) * profile * coifR;
                    float sy = coifCy + ny * coifR * 1.05f;
                    int lum = Math.max(110, Math.min(255, (int) (nz * 150 + 105)));
                    mAsciiPaint.setColor(Color.rgb(
                            Math.min(255, (Color.red(baseC) * lum) / 200),
                            Math.min(255, (Color.green(baseC) * lum) / 200),
                            Math.min(255, (Color.blue(baseC) * lum) / 200)
                    ));
                    mSingleChar[0] = chainChars.charAt(Math.abs(yr * 7 + xc * 3) % chainChars.length());
                    canvas.drawText(mSingleChar, 0, 1, sx, sy, mAsciiPaint);
                }
            }
        }
    }
}
