# Hero model, design & animations (`gametest1` / v5.0.0)

All in `MainActivity.java` (search `HERO RIG BEGIN`).

- **Video-Accurate "Senje" Armor & Chainmail Model (`1000461713.mp4` & `1000461712.mp4`)**:
  - **Nameplate**: `"Senje"` above the hero and in the top-left HUD plate.
  - **Bloody Mail Coif & Bishop's Mantle (`TONE_CHAINMAIL`)**: Rounded 3D chainmail coif hood and wide shoulder-draped mantle rendered with spiral interlocking link glyphs (`S8$#c()35@%`), shadowed visor opening (`TONE_VISOR`), and dynamic metal tinting from the Craft UI (`METAL_COLS[mForgeMetal]`).
  - **Deep Crimson Surcoat / Split Tabard (`TONE_SURCOAT`)**: Blood-crimson tunic and split thigh-length surcoat panels (`#80Qo:;.|=`) cinched with a studded belt (`TONE_LEATHER`), catching warm orange-amber bounce light (`bladeBounceLight`) from the glowing Ember Greatsword.
  - **Dark Greaves & Sabatons (`TONE_GREAVES`)**: Articulated chainmail/plate leggings (`S8(3)c/|`) with a bright silver-white specular contour rim (`|`, `(`, `)`) matching the `CRAFT · Dark Greaves` preview.
  - **Flowing Dark Cloak (`TONE_CLOAK`)**: Multi-strand Verlet cloak anchored to the back of the shoulders.
  - **Blazing Ember Greatsword (`TONE_FIRE`)**: Held in the signature low diagonal downward-outward carry across the crimson surcoat, radiating real additive orange light (`mAmberGlowBitmap`) and drifting ember sparks.
- **Animations**:
  - **Idle**: Breathing (chest + mantle), slow weight shift, flickering ember blade, swaying cloak.
  - **8-Directional Walk -> Run**: Distance-driven gait clock (`heroCycleDist`), heel-strike to toe-off foot roll, silver-rimmed Dark Greaves kicking back behind the flaring crimson surcoat, torso lean, and counter-swinging off-arm.
  - **3-Stage Greatsword Slash Combo (`mSlashCombo = 0, 1, 2`)**:
    1. Wide 210° diagonal cleave with lunge step and torso twist.
    2. Reverse rising wrath backhand slash.
    3. Full 360° Whirlwind Spin Cleave (`1000461713.mp4` 00:41–00:44 & `1000461712.mp4` 00:15–00:23) carving a full ring of ember fire around Senje.
  - **Dodge**: Crouch -> tucked ball roll / low dive -> recovery crouch with afterimages.
  - **Mounted White Steed + Chainmail Rider**: Same Chainmail Coif, Crimson Surcoat, Dark Greaves, and Ember Greatsword on horseback, with soft Verlet `HairFx` horse mane and tail.
  - **7-Tab Craft UI (`1000461713.mp4`)**: `Weapon`, `Helm`, `Shoulders`, `Chest`, `Gloves`, `Legs`, `Boots` with 3D rotating previews for `Bloody Mail Coif`, `Dark Greaves`, and `Ember Greatsword`.
