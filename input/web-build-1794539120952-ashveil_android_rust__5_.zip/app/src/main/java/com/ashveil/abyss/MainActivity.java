package com.ashveil.abyss;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
    private static boolean sRustLoaded = false;
    static {
        try {
            System.loadLibrary("ashveil_ascii_3d");
            sRustLoaded = true;
        } catch (Throwable ignored) {
            sRustLoaded = false;
        }
    }

    public static native long nativeInit(long seed);
    public static native int nativeStep(long handle, float dt);
    public static native void nativeTouch(long handle, int action, long pointerId, float normX, float normY);
    public static native void nativeDestroy(long handle);

    private AshveilView mView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );
        mView = new AshveilView(this);
        setContentView(mView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mView != null) mView.resumeGame();
    }

    @Override
    protected void onPause() {
        if (mView != null) mView.pauseGame();
        super.onPause();
    }

    private static final class AshveilView extends SurfaceView implements Runnable, SurfaceHolder.Callback {
        private static final String DENSE_RAMP = " .,:;-=+*oahkbdpqwmZOQ0N$%&8B#MW@";
        private static final String CLIFF_CHARS = "@WM#B8&%$N0QOZmwqpdbkhao*+=-:;,.";
        private static final String[] GROUND_ASCII = new String[]{
                "0Q8B", "QQ0O", "80aa", "qQ80", "b0Q8", "O08Q"
        };
        private static final String[] PORTRAIT_ART = new String[]{
                " .--. ",
                "|@##@|",
                "/####\\",
                "|####|",
                " |||| ",
                " _||_ "
        };

        private Thread mThread;
        private volatile boolean mRunning = false;
        private long mRustHandle = 0;

        // Reusable Paints (ZERO allocations in drawFrame)
        private final Paint mAsciiPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mGrassPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mShadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mUiPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mPanelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mFogPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mBitmapPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
        private final RectF mTmpRect = new RectF();

        // Pre-baked static terrain & fog caches (60-120 FPS!)
        private static final int MEADOW_TILE_PX = 1024;
        private static final float CHUNK_WORLD_UNITS = 4.0f;
        private static final int CHUNK_PX = 256; // 64 px per world unit
        private static final int CHUNK_CACHE_CAP = 24;

        private Bitmap mMeadowTileBitmap = null;
        private Bitmap mFogBitmap = null;
        private Bitmap mVignetteBitmap = null;
        private final int[] mChunkKeys = new int[CHUNK_CACHE_CAP];
        private final Bitmap[] mChunkBitmaps = new Bitmap[CHUNK_CACHE_CAP];
        private final Canvas[] mChunkCanvases = new Canvas[CHUNK_CACHE_CAP];
        private final int[] mChunkAge = new int[CHUNK_CACHE_CAP];
        private int mChunkTick = 1;

        // Batched dynamic wind-swaying grass tips
        private static final int WIND_BLADES_PER_LAYER = 180;
        private final float[] mWindPtsDark = new float[WIND_BLADES_PER_LAYER * 4];
        private final float[] mWindPtsBright = new float[WIND_BLADES_PER_LAYER * 4];

        // Screen mode: 0 = Start Menu, 1 = Gameplay, 2 = Character / Loot / Forge Modal
        private int mScreenMode = 0;
        private boolean mMounted = false; // Default Foot Knight (toggleable to Mounted Steed)
        private boolean mAttackButtonOnly = true; // true = dedicated [ATK] button, false = tap anywhere
        private int mZoomPreset = 1;      // 0 = Close-up, 1 = Medium, 2 = Wide
        private float mCameraZoom = 1.15f;
        private int mWindPreset = 1;

        // World & Camera State
        private float mPlayerX = 0.0f;
        private float mPlayerY = 0.0f;
        private float mCamX = 0.0f;
        private float mCamY = 0.0f;
        private float mVelX = 0.0f;
        private float mVelY = 0.0f;
        private float mFacingX = 0.85f;
        private float mFacingY = 0.52f;
        private float mGaitPhase = 0.0f;
        private float mTimeSec = 0.0f;
        private float mSlashTimer = 0.0f;
        private float mSlashCooldown = 0.0f;
        private float mDodgeTimer = 0.0f;
        private float mDodgeCooldown = 0.0f;
        private float mDodgeDirX = 1.0f;
        private float mDodgeDirY = 0.0f;
        private static final int MAX_AFTERIMAGES = 5;
        private final float[] mGhostX = new float[MAX_AFTERIMAGES];
        private final float[] mGhostY = new float[MAX_AFTERIMAGES];
        private final float[] mGhostLife = new float[MAX_AFTERIMAGES];
        private float mGhostSpawnAccum = 0.0f;
        private float mCursorX = 0.54f;
        private float mCursorY = 0.52f;

        // Touch Controls
        private int mMovePointerId = -1;
        private float mJoyBaseX = 0.0f;
        private float mJoyBaseY = 0.0f;
        private float mJoyCurrX = 0.0f;
        private float mJoyCurrY = 0.0f;
        private float mInputX = 0.0f;
        private float mInputY = 0.0f;

        // Offline Single-Player RPG State
        private int mLevel = 13;
        private int mXp = 420;
        private int mXpNext = 900;
        private int mHp = 1612;
        private int mMaxHp = 1612;
        private int mMp = 134;
        private int mMaxMp = 134;
        private int mGold = 5194;
        private int mStatPoints = 3;
        private int mVit = 18;
        private int mStr = 21;
        private int mDex = 16;
        private int mForgeLevel = 2;
        private String mEquippedWeapon = "[R] Pale-Moon Greatsword";
        private String mEquippedArmor = "[U] Silver-Weave Mail";
        private final String[] mInventory = new String[16];
        private int mInvCount = 2;

        // Toast Feedback
        private String mStatusBanner = "LEFT THUMB: MOVE | RIGHT: TAP SLASH / SWIPE GALLOP";
        private float mBannerTimer = 4.0f;

        // Verlet Hair / Mane / Tail / Cloak Physics (Mounted + Foot Knight)
        private static final int TAIL_STRANDS = 12;
        private static final int TAIL_NODES = 10;
        private final float[][] mTailX = new float[TAIL_STRANDS][TAIL_NODES];
        private final float[][] mTailY = new float[TAIL_STRANDS][TAIL_NODES];
        private final float[][] mTailPrevX = new float[TAIL_STRANDS][TAIL_NODES];
        private final float[][] mTailPrevY = new float[TAIL_STRANDS][TAIL_NODES];

        private static final int MANE_STRANDS = 14;
        private static final int MANE_NODES = 7;
        private final float[][] mManeX = new float[MANE_STRANDS][MANE_NODES];
        private final float[][] mManeY = new float[MANE_STRANDS][MANE_NODES];
        private final float[][] mManePrevX = new float[MANE_STRANDS][MANE_NODES];
        private final float[][] mManePrevY = new float[MANE_STRANDS][MANE_NODES];

        private static final int HAIR_STRANDS = 8;
        private static final int HAIR_NODES = 8;
        private final float[][] mHairX = new float[HAIR_STRANDS][HAIR_NODES];
        private final float[][] mHairY = new float[HAIR_STRANDS][HAIR_NODES];
        private final float[][] mHairPrevX = new float[HAIR_STRANDS][HAIR_NODES];
        private final float[][] mHairPrevY = new float[HAIR_STRANDS][HAIR_NODES];

        // ASCII Entity Buffers (Mounted Horse, Foot Knight, Humanoid Enemies)
        private static final int HORSE_BUF_W = 56;
        private static final int HORSE_BUF_H = 44;
        private final char[] mHorseGlyphBuf = new char[HORSE_BUF_W * HORSE_BUF_H];
        private final float[] mHorseLumBuf = new float[HORSE_BUF_W * HORSE_BUF_H];
        private final int[] mHorseColorBuf = new int[HORSE_BUF_W * HORSE_BUF_H];

        private static final int FOOT_BUF_W = 42;
        private static final int FOOT_BUF_H = 50;
        private final char[] mFootGlyphBuf = new char[FOOT_BUF_W * FOOT_BUF_H];
        private final float[] mFootLumBuf = new float[FOOT_BUF_W * FOOT_BUF_H];
        private final int[] mFootColorBuf = new int[FOOT_BUF_W * FOOT_BUF_H];

        private static final int ENEMY_BUF_W = 32;
        private static final int ENEMY_BUF_H = 40;
        private final char[] mEnemyGlyphBuf = new char[ENEMY_BUF_W * ENEMY_BUF_H];
        private final float[] mEnemyLumBuf = new float[ENEMY_BUF_W * ENEMY_BUF_H];
        private final int[] mEnemyColorBuf = new int[ENEMY_BUF_W * ENEMY_BUF_H];

        // Humanoid Enemies & Loot Drops
        private static final int NUM_ENEMIES = 10;
        private final float[] mEnemyX = new float[NUM_ENEMIES];
        private final float[] mEnemyY = new float[NUM_ENEMIES];
        private final float[] mEnemyFacingX = new float[NUM_ENEMIES];
        private final float[] mEnemyFacingY = new float[NUM_ENEMIES];
        private final float[] mEnemyGait = new float[NUM_ENEMIES];
        private final float[] mEnemyAttackAnim = new float[NUM_ENEMIES];
        private final int[] mEnemyHp = new int[NUM_ENEMIES];
        private final int[] mEnemyMaxHp = new int[NUM_ENEMIES];
        private final float[] mEnemyHurt = new float[NUM_ENEMIES];
        private final int[] mEnemyKind = new int[NUM_ENEMIES];

        private static final int MAX_LOOT = 16;
        private final float[] mLootX = new float[MAX_LOOT];
        private final float[] mLootY = new float[MAX_LOOT];
        private final boolean[] mLootActive = new boolean[MAX_LOOT];
        private final int[] mLootRarity = new int[MAX_LOOT];

        // Ash / Spark Particles on Hit & Death
        private static final int MAX_PARTICLES = 48;
        private final float[] mPartX = new float[MAX_PARTICLES];
        private final float[] mPartY = new float[MAX_PARTICLES];
        private final float[] mPartVx = new float[MAX_PARTICLES];
        private final float[] mPartVy = new float[MAX_PARTICLES];
        private final float[] mPartLife = new float[MAX_PARTICLES];
        private final int[] mPartColor = new int[MAX_PARTICLES];
        private int mPartCursor = 0;

        public AshveilView(Context context) {
            super(context);
            getHolder().addCallback(this);
            setFocusable(true);
            setKeepScreenOn(true);

            mAsciiPaint.setTypeface(Typeface.MONOSPACE);
            mAsciiPaint.setFakeBoldText(true);
            mGrassPaint.setStyle(Paint.Style.STROKE);
            mGrassPaint.setStrokeCap(Paint.Cap.ROUND);
            mShadowPaint.setStyle(Paint.Style.FILL);
            mUiPaint.setTypeface(Typeface.MONOSPACE);
            mUiPaint.setFakeBoldText(true);
            mPanelPaint.setStyle(Paint.Style.FILL);
            mBorderPaint.setStyle(Paint.Style.STROKE);
            mBorderPaint.setStrokeWidth(2.4f);

            mInventory[0] = mEquippedWeapon;
            mInventory[1] = mEquippedArmor;

            for (int i = 0; i < CHUNK_CACHE_CAP; i++) {
                mChunkKeys[i] = Integer.MIN_VALUE;
            }
            initWorld();
        }

        private void initWorld() {
            for (int s = 0; s < TAIL_STRANDS; s++) {
                for (int n = 0; n < TAIL_NODES; n++) {
                    mTailX[s][n] = mTailPrevX[s][n] = mPlayerX - 1.1f - n * 0.14f;
                    mTailY[s][n] = mTailPrevY[s][n] = mPlayerY + n * 0.12f;
                }
            }
            for (int s = 0; s < MANE_STRANDS; s++) {
                for (int n = 0; n < MANE_NODES; n++) {
                    mManeX[s][n] = mManePrevX[s][n] = mPlayerX + 0.4f;
                    mManeY[s][n] = mManePrevY[s][n] = mPlayerY - 0.6f + n * 0.08f;
                }
            }
            for (int s = 0; s < HAIR_STRANDS; s++) {
                for (int n = 0; n < HAIR_NODES; n++) {
                    mHairX[s][n] = mHairPrevX[s][n] = mPlayerX - 0.1f - n * 0.10f;
                    mHairY[s][n] = mHairPrevY[s][n] = mPlayerY - 1.25f + n * 0.08f;
                }
            }
            for (int i = 0; i < NUM_ENEMIES; i++) {
                spawnEnemy(i, i < 3);
            }
        }

        private void ensureStaticCaches() {
            if (mMeadowTileBitmap == null) {
                mMeadowTileBitmap = Bitmap.createBitmap(MEADOW_TILE_PX, MEADOW_TILE_PX, Bitmap.Config.ARGB_8888);
                Canvas mc = new Canvas(mMeadowTileBitmap);
                mc.drawColor(Color.rgb(7, 11, 10));

                // Organic dark soil & mossy clearing patches for rich depth
                Paint pPatch = new Paint(Paint.ANTI_ALIAS_FLAG);
                int seed = 1337420;
                for (int i = 0; i < 65; i++) {
                    seed = seed * 1664525 + 1013904223;
                    float px = ((seed >>> 16) & 1023);
                    seed = seed * 1664525 + 1013904223;
                    float py = ((seed >>> 16) & 1023);
                    float rad = 45.0f + ((seed >>> 8) & 63);
                    boolean dark = (i % 2 == 0);
                    int cIn = dark ? Color.argb(95, 4, 8, 7) : Color.argb(65, 18, 44, 24);
                    pPatch.setShader(new RadialGradient(px, py, rad, cIn, Color.argb(0, 0, 0, 0), Shader.TileMode.CLAMP));
                    mc.drawCircle(px, py, rad, pPatch);
                }
                pPatch.setShader(null);

                // Subtle blue-grey `0Q8B` ground ASCII matrix organically scattered
                Paint pText = new Paint(Paint.ANTI_ALIAS_FLAG);
                pText.setTypeface(Typeface.MONOSPACE);
                pText.setFakeBoldText(true);
                pText.setTextSize(13.0f);
                for (int y = 14; y < MEADOW_TILE_PX; y += 22) {
                    for (int x = 6; x < MEADOW_TILE_PX; x += 22) {
                        int h = Math.abs((x * 73856093) ^ (y * 19349663));
                        if ((h % 5) < 3) {
                            String gTxt = GROUND_ASCII[h % GROUND_ASCII.length];
                            pText.setColor((h % 3 == 0) ? Color.rgb(74, 92, 110) : Color.rgb(46, 62, 76));
                            mc.drawText(gTxt, x + (h % 7) - 3, y + ((h >> 3) % 7) - 3, pText);
                        }
                    }
                }

                // 45,000+ TINY tufted emerald grass blades (dark root -> bright sunlit tip)
                Paint pBlade = new Paint(Paint.ANTI_ALIAS_FLAG);
                pBlade.setStyle(Paint.Style.STROKE);
                pBlade.setStrokeCap(Paint.Cap.ROUND);
                pBlade.setStrokeWidth(1.25f);

                int[] colors = new int[]{
                        Color.rgb(10, 26, 14),
                        Color.rgb(18, 48, 22),
                        Color.rgb(32, 84, 38),
                        Color.rgb(54, 124, 56),
                        Color.rgb(86, 158, 82),
                        Color.rgb(116, 188, 102)
                };

                int totalBlades = 45000;
                int perBucket = totalBlades / colors.length;
                float[] pts = new float[perBucket * 4];
                for (int cIdx = 0; cIdx < colors.length; cIdx++) {
                    pBlade.setColor(colors[cIdx]);
                    for (int i = 0; i < perBucket; i += 3) {
                        seed = seed * 1664525 + 1013904223;
                        float tx = ((seed >>> 16) & 1023);
                        seed = seed * 1664525 + 1013904223;
                        float ty = ((seed >>> 16) & 1023);
                        for (int b = 0; b < 3 && (i + b) < perBucket; b++) {
                            seed = seed * 1664525 + 1013904223;
                            float bx = tx + (b - 1) * 1.8f;
                            float by = ty + ((b == 1) ? -0.8f : 0.4f);
                            float lean = (b - 1) * 1.35f + (((seed >>> 20) & 7) - 3) * 0.35f + 0.9f;
                            float len = 4.8f + ((seed >>> 12) & 7) * 0.78f;
                            int o = (i + b) * 4;
                            pts[o] = bx;
                            pts[o + 1] = by;
                            pts[o + 2] = bx + lean;
                            pts[o + 3] = by - len;
                        }
                    }
                    mc.drawLines(pts, pBlade);
                }

                // Tiny crisp wildflowers (* and o)
                pText.setTextSize(9.5f);
                for (int i = 0; i < 480; i++) {
                    seed = seed * 1664525 + 1013904223;
                    float fx = ((seed >>> 16) & 1023);
                    seed = seed * 1664525 + 1013904223;
                    float fy = ((seed >>> 16) & 1023);
                    pText.setColor((i % 3 == 0) ? Color.rgb(245, 248, 228) : Color.rgb(198, 222, 186));
                    mc.drawText((i % 2 == 0) ? "*" : "o", fx, fy, pText);
                }
            }

            if (mFogBitmap == null) {
                mFogBitmap = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888);
                Canvas fc = new Canvas(mFogBitmap);
                Paint fp = new Paint(Paint.ANTI_ALIAS_FLAG);
                fp.setShader(new RadialGradient(
                        128f, 128f, 128f,
                        Color.argb(64, 205, 222, 228),
                        Color.argb(0, 205, 222, 228),
                        Shader.TileMode.CLAMP
                ));
                fc.drawCircle(128f, 128f, 128f, fp);
            }

            if (mVignetteBitmap == null) {
                mVignetteBitmap = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888);
                Canvas vc = new Canvas(mVignetteBitmap);
                Paint vp = new Paint(Paint.ANTI_ALIAS_FLAG);
                vp.setShader(new RadialGradient(
                        128f, 128f, 168f,
                        new int[]{Color.argb(0, 0, 0, 0), Color.argb(35, 3, 6, 6), Color.argb(145, 2, 5, 5)},
                        new float[]{0.48f, 0.78f, 1.0f},
                        Shader.TileMode.CLAMP
                ));
                vc.drawRect(0, 0, 256, 256, vp);
            }
        }

        private float riverCenterY(float wx) {
            return -5.8f + (float) Math.sin(wx * 0.16f) * 2.1f;
        }

        private float cliffDensity(float wx, float wy) {
            if (wx * wx + wy * wy < 14.0f) return 0.0f;
            float n = (float) (Math.sin(wx * 0.24f + 0.7f) * Math.cos(wy * 0.21f - 0.4f)
                    + 0.45f * Math.sin(wx * 0.52f - wy * 0.37f));
            return n;
        }

        private boolean isCliff(float wx, float wy) {
            return cliffDensity(wx, wy) > 0.68f;
        }

        private void spawnEnemy(int i, boolean close) {
            float ang = i * 1.1f + 0.4f;
            float dist = close ? (4.5f + i * 1.7f) : (8.5f + (i % 5) * 2.8f);
            float ex = mPlayerX + (float) Math.cos(ang) * dist;
            float ey = mPlayerY + (float) Math.sin(ang) * dist;
            if (isCliff(ex, ey)) {
                ex = mPlayerX + 4.0f;
                ey = mPlayerY + 3.0f;
            }
            mEnemyX[i] = ex;
            mEnemyY[i] = ey;
            mEnemyFacingX[i] = -1.0f;
            mEnemyFacingY[i] = 0.0f;
            mEnemyGait[i] = i * 0.7f;
            mEnemyAttackAnim[i] = 0.0f;
            mEnemyKind[i] = i % 4;
            mEnemyMaxHp[i] = 95 + mLevel * 14 + (i % 3) * 35;
            mEnemyHp[i] = mEnemyMaxHp[i];
            mEnemyHurt[i] = 0.0f;
        }

        private void spawnParticles(float wx, float wy, int count, int color) {
            for (int k = 0; k < count; k++) {
                int idx = mPartCursor;
                mPartCursor = (mPartCursor + 1) % MAX_PARTICLES;
                float ang = (float) ((k * 2.399f) + mTimeSec * 3.7f);
                float spd = 1.4f + (k % 4) * 0.85f;
                mPartX[idx] = wx;
                mPartY[idx] = wy;
                mPartVx[idx] = (float) Math.cos(ang) * spd;
                mPartVy[idx] = (float) Math.sin(ang) * spd - 0.6f;
                mPartLife[idx] = 0.38f + (k % 3) * 0.10f;
                mPartColor[idx] = color;
            }
        }

        @Override
        public void surfaceCreated(SurfaceHolder holder) {
            if (sRustLoaded && mRustHandle == 0) {
                try {
                    mRustHandle = nativeInit(0xA547E11L);
                } catch (Throwable ignored) {
                    mRustHandle = 0;
                }
            }
            resumeGame();
        }

        @Override
        public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        }

        @Override
        public void surfaceDestroyed(SurfaceHolder holder) {
            pauseGame();
            if (sRustLoaded && mRustHandle != 0) {
                try {
                    nativeDestroy(mRustHandle);
                } catch (Throwable ignored) {
                }
                mRustHandle = 0;
            }
        }

        public void resumeGame() {
            if (mRunning) return;
            mRunning = true;
            mThread = new Thread(this, "AshveilRenderLoop");
            mThread.setPriority(Thread.MAX_PRIORITY);
            mThread.start();
        }

        public void pauseGame() {
            mRunning = false;
            if (mThread != null) {
                try {
                    mThread.join(400);
                } catch (InterruptedException ignored) {
                }
                mThread = null;
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            int action = event.getActionMasked();
            int idx = event.getActionIndex();
            int pointerId = event.getPointerId(idx);
            float x = event.getX(idx);
            float y = event.getY(idx);
            float w = Math.max(1.0f, getWidth());
            float h = Math.max(1.0f, getHeight());

            if (sRustLoaded && mRustHandle != 0) {
                try {
                    nativeTouch(mRustHandle, action, pointerId, x / w, y / h);
                } catch (Throwable ignored) {
                }
            }

            if (mScreenMode == 0) {
                if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                    handleStartMenuTap(x, y, w, h);
                }
                return true;
            }

            if (mScreenMode == 2) {
                if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                    handleModalTap(x, y, w, h);
                }
                return true;
            }

            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                float boxH = Math.min(h * 0.13f, 150.0f);
                float pillW = Math.min(w * 0.22f, 180.0f);
                float pillH = boxH * 0.38f;
                float px = w - pillW - 18.0f;
                float y0 = 18.0f;

                // Top-right pills: [MENU], [ZOOM], [MOUNT/DISMOUNT]
                if (x >= px && x <= px + pillW) {
                    if (y >= y0 && y <= y0 + pillH) {
                        mScreenMode = 0;
                        return true;
                    }
                    float py2 = y0 + pillH + 10.0f;
                    if (y >= py2 && y <= py2 + pillH) {
                        mZoomPreset = (mZoomPreset + 1) % 3;
                        mCameraZoom = (mZoomPreset == 0) ? 1.55f : (mZoomPreset == 1 ? 1.15f : 0.78f);
                        showBanner(mZoomPreset == 0 ? "CAMERA: CLOSE-UP" : (mZoomPreset == 1 ? "CAMERA: MEADOW VIEW" : "CAMERA: WIDE VIEW"));
                        return true;
                    }
                    float py3 = py2 + pillH + 10.0f;
                    if (y >= py3 && y <= py3 + pillH) {
                        mMounted = !mMounted;
                        spawnParticles(mPlayerX, mPlayerY, 12, Color.rgb(220, 232, 226));
                        showBanner(mMounted ? "MOUNTED WHITE STEED" : "DISMOUNTED (FOOT KNIGHT)");
                        return true;
                    }
                }

                if (x < w * 0.36f && y < h * 0.16f) {
                    mScreenMode = 2;
                    return true;
                }

                // Bottom-right Action Buttons: [ATK] and [DODGE]
                float atkR = Math.min(w, h) * 0.088f;
                float atkCx = w - atkR - 26.0f;
                float atkCy = h - atkR - 26.0f;
                float dxA = x - atkCx;
                float dyA = y - atkCy;
                if (dxA * dxA + dyA * dyA <= (atkR * 1.25f) * (atkR * 1.25f)) {
                    triggerSlash();
                    return true;
                }

                float dodgeR = Math.min(w, h) * 0.070f;
                float dodgeCx = atkCx - atkR - dodgeR - 22.0f;
                float dodgeCy = h - dodgeR - 26.0f;
                float dxD = x - dodgeCx;
                float dyD = y - dodgeCy;
                if (dxD * dxD + dyD * dyD <= (dodgeR * 1.25f) * (dodgeR * 1.25f)) {
                    triggerDodge();
                    return true;
                }

                if (x < w * 0.50f) {
                    mMovePointerId = pointerId;
                    mJoyBaseX = x;
                    mJoyBaseY = y;
                    mJoyCurrX = x;
                    mJoyCurrY = y;
                    mInputX = 0.0f;
                    mInputY = 0.0f;
                } else {
                    mCursorX = x / w;
                    mCursorY = y / h;
                    if (!mAttackButtonOnly) {
                        triggerSlash();
                    }
                }
            } else if (action == MotionEvent.ACTION_MOVE) {
                int count = event.getPointerCount();
                for (int i = 0; i < count; i++) {
                    int pId = event.getPointerId(i);
                    float px = event.getX(i);
                    float py = event.getY(i);
                    if (pId == mMovePointerId) {
                        mJoyCurrX = px;
                        mJoyCurrY = py;
                        float dx = px - mJoyBaseX;
                        float dy = py - mJoyBaseY;
                        float maxR = Math.min(w, h) * 0.14f;
                        float len = (float) Math.sqrt(dx * dx + dy * dy);
                        if (len > 4.0f) {
                            float mag = Math.min(1.0f, len / maxR);
                            mInputX = (dx / len) * mag;
                            mInputY = (dy / len) * mag;
                        } else {
                            mInputX = 0.0f;
                            mInputY = 0.0f;
                        }
                    } else {
                        mCursorX = px / w;
                        mCursorY = py / h;
                    }
                }
            } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP || action == MotionEvent.ACTION_CANCEL) {
                if (pointerId == mMovePointerId) {
                    mMovePointerId = -1;
                    mInputX = 0.0f;
                    mInputY = 0.0f;
                }
            }
            return true;
        }

        private void handleStartMenuTap(float x, float y, float w, float h) {
            if (x >= w * 0.15f && x <= w * 0.85f) {
                if (y >= h * 0.39f && y <= h * 0.47f) {
                    mScreenMode = 1;
                    showBanner(mAttackButtonOnly ? "LEFT: MOVE | [ATK] SLASH | [DODGE] DASH" : "LEFT: MOVE | TAP RIGHT: SLASH | [DODGE]");
                } else if (y >= h * 0.49f && y <= h * 0.57f) {
                    mZoomPreset = (mZoomPreset + 1) % 3;
                    mCameraZoom = (mZoomPreset == 0) ? 1.55f : (mZoomPreset == 1 ? 1.15f : 0.78f);
                } else if (y >= h * 0.59f && y <= h * 0.67f) {
                    mMounted = !mMounted;
                } else if (y >= h * 0.69f && y <= h * 0.77f) {
                    mAttackButtonOnly = !mAttackButtonOnly;
                } else if (y >= h * 0.79f && y <= h * 0.87f) {
                    mScreenMode = 2;
                }
            }
        }

        private void handleModalTap(float x, float y, float w, float h) {
            if (y > h * 0.84f) {
                mScreenMode = 1;
                return;
            }
            if (y >= h * 0.34f && y <= h * 0.44f && mStatPoints > 0) {
                mStatPoints--;
                mVit += 2;
                mStr += 2;
                mDex += 1;
                mMaxHp += 48;
                mHp = mMaxHp;
                mMaxMp += 10;
                mMp = mMaxMp;
                showBanner("ATTRIBUTES UPGRADED! (" + mStatPoints + " PTS LEFT)");
            } else if (y >= h * 0.46f && y <= h * 0.56f) {
                int cost = 150 + mForgeLevel * 120;
                if (mGold >= cost) {
                    mGold -= cost;
                    mForgeLevel++;
                    showBanner("BLADE TEMPERED TO +" + mForgeLevel + "!");
                } else {
                    showBanner("NEED " + cost + "g TO TEMPER");
                }
            }
        }

        private void showBanner(String msg) {
            mStatusBanner = msg;
            mBannerTimer = 2.6f;
        }

        private void triggerDodge() {
            if (mDodgeCooldown > 0.0f) return;
            mDodgeTimer = 0.28f;
            mDodgeCooldown = 0.85f;
            float len = (float) Math.sqrt(mInputX * mInputX + mInputY * mInputY);
            if (len > 0.15f) {
                mDodgeDirX = mInputX / len;
                mDodgeDirY = mInputY / len;
            } else {
                mDodgeDirX = mFacingX;
                mDodgeDirY = mFacingY;
            }
            mFacingX = mDodgeDirX;
            mFacingY = mDodgeDirY;
            mGhostSpawnAccum = 0.06f;
            spawnParticles(mPlayerX, mPlayerY + 0.15f, 10, Color.rgb(185, 232, 224));
        }

        private void triggerSlash() {
            if (mSlashCooldown > 0.0f) return;
            mSlashTimer = 0.24f;
            mSlashCooldown = 0.32f;

            float dmg = 34 + mStr * 3 + mForgeLevel * 14;
            for (int i = 0; i < NUM_ENEMIES; i++) {
                float dx = mEnemyX[i] - mPlayerX;
                float dy = mEnemyY[i] - mPlayerY;
                float d2 = dx * dx + dy * dy;
                if (d2 < 3.4f * 3.4f) {
                    mEnemyHp[i] -= (int) dmg;
                    mEnemyHurt[i] = 0.24f;
                    float len = (float) Math.sqrt(d2 + 0.001f);
                    mEnemyX[i] += (dx / len) * 0.55f;
                    mEnemyY[i] += (dy / len) * 0.55f;
                    spawnParticles(mEnemyX[i], mEnemyY[i] - 0.3f, 8, Color.rgb(245, 210, 120));
                    if (mEnemyHp[i] <= 0) {
                        onEnemyDefeated(i);
                    }
                }
            }
        }

        private void onEnemyDefeated(int i) {
            spawnParticles(mEnemyX[i], mEnemyY[i] - 0.2f, 16, Color.rgb(220, 230, 235));
            int gainedXp = 140 + mLevel * 28;
            int gainedGold = 45 + (i * 17) % 60;
            mXp += gainedXp;
            mGold += gainedGold;
            if (mXp >= mXpNext) {
                mXp -= mXpNext;
                mLevel++;
                mXpNext = (int) (mXpNext * 1.28f);
                mStatPoints += 3;
                mMaxHp += 95;
                mHp = mMaxHp;
                mMaxMp += 16;
                mMp = mMaxMp;
                showBanner("LEVEL UP! LV." + mLevel + " (+3 STAT PTS)");
            } else {
                showBanner("SLAIN WANDERER (+" + gainedXp + " XP | +" + gainedGold + "g)");
            }

            for (int l = 0; l < MAX_LOOT; l++) {
                if (!mLootActive[l]) {
                    mLootActive[l] = true;
                    mLootX[l] = mEnemyX[i];
                    mLootY[l] = mEnemyY[i];
                    mLootRarity[l] = (i + mLevel) % 4;
                    break;
                }
            }
            spawnEnemy(i, false);
        }

        @Override
        public void run() {
            long lastNs = System.nanoTime();
            while (mRunning) {
                long nowNs = System.nanoTime();
                float dt = (nowNs - lastNs) / 1_000_000_000.0f;
                lastNs = nowNs;
                if (dt > 0.05f) dt = 0.05f;
                if (dt < 0.001f) dt = 0.001f;

                if (sRustLoaded && mRustHandle != 0) {
                    try {
                        nativeStep(mRustHandle, dt);
                    } catch (Throwable ignored) {
                    }
                }

                updateSimulation(dt);
                drawFrame();

                try {
                    Thread.sleep(4);
                } catch (InterruptedException ignored) {
                }
            }
        }

        private void updateSimulation(float dt) {
            mTimeSec += dt;
            if (mBannerTimer > 0.0f) mBannerTimer -= dt;
            if (mSlashTimer > 0.0f) mSlashTimer -= dt;
            if (mSlashCooldown > 0.0f) mSlashCooldown -= dt;
            if (mDodgeTimer > 0.0f) mDodgeTimer -= dt;
            if (mDodgeCooldown > 0.0f) mDodgeCooldown -= dt;
            for (int g = 0; g < MAX_AFTERIMAGES; g++) {
                if (mGhostLife[g] > 0.0f) mGhostLife[g] -= dt;
            }

            if (mScreenMode == 0) {
                mCamX = (float) Math.sin(mTimeSec * 0.25f) * 1.8f;
                mCamY = (float) Math.cos(mTimeSec * 0.18f) * 1.1f;
                mFacingX = 0.88f;
                mFacingY = 0.42f;
                mGaitPhase += dt * 4.0f;
            } else if (mScreenMode == 1) {
                if (mDodgeTimer > 0.0f) {
                    float dashSpeed = mMounted ? 13.5f : 11.2f;
                    mVelX = mDodgeDirX * dashSpeed;
                    mVelY = mDodgeDirY * dashSpeed;
                    mGhostSpawnAccum += dt;
                    if (mGhostSpawnAccum >= 0.045f) {
                        mGhostSpawnAccum = 0.0f;
                        for (int g = 0; g < MAX_AFTERIMAGES; g++) {
                            if (mGhostLife[g] <= 0.0f) {
                                mGhostX[g] = mPlayerX;
                                mGhostY[g] = mPlayerY;
                                mGhostLife[g] = 0.24f;
                                break;
                            }
                        }
                    }
                } else {
                    float topSpeed = mMounted ? 5.6f : 3.9f;
                    float targetVx = mInputX * topSpeed;
                    float targetVy = mInputY * topSpeed;
                    float accel = Math.min(1.0f, dt * 11.0f);
                    mVelX += (targetVx - mVelX) * accel;
                    mVelY += (targetVy - mVelY) * accel;
                }

                float nx = mPlayerX + mVelX * dt;
                float ny = mPlayerY + mVelY * dt;
                if (!isCliff(nx, mPlayerY)) mPlayerX = nx;
                if (!isCliff(mPlayerX, ny)) mPlayerY = ny;

                float spd = (float) Math.sqrt(mVelX * mVelX + mVelY * mVelY);
                if (spd > 0.25f) {
                    mFacingX = mVelX / spd;
                    mFacingY = mVelY / spd;
                    mGaitPhase += dt * (mMounted ? 5.0f + spd * 2.1f : 4.2f + spd * 2.8f);
                } else {
                    mGaitPhase += dt * 1.4f;
                }

                mCamX += (mPlayerX - mCamX) * Math.min(1.0f, dt * 8.0f);
                mCamY += (mPlayerY - mCamY) * Math.min(1.0f, dt * 8.0f);

                for (int l = 0; l < MAX_LOOT; l++) {
                    if (mLootActive[l]) {
                        float dx = mLootX[l] - mPlayerX;
                        float dy = mLootY[l] - mPlayerY;
                        if (dx * dx + dy * dy < 1.1f * 1.1f) {
                            mLootActive[l] = false;
                            String[] pool = {
                                    "[R] Pale-Moon Greatsword",
                                    "[E] Wraith-Weave Cloak",
                                    "[L] Crown of the First Kiln",
                                    "[E] Obsidian Courser Barding",
                                    "[R] Starlight Signet Ring"
                            };
                            String item = pool[mLootRarity[l] % pool.length] + " +" + (1 + mLevel / 4);
                            if (mInvCount < mInventory.length) {
                                mInventory[mInvCount++] = item;
                            }
                            mEquippedWeapon = item;
                            showBanner("EQUIPPED: " + item);
                        }
                    }
                }

                for (int i = 0; i < NUM_ENEMIES; i++) {
                    if (mEnemyHurt[i] > 0.0f) mEnemyHurt[i] -= dt;
                    if (mEnemyAttackAnim[i] > 0.0f) mEnemyAttackAnim[i] -= dt;
                    float dx = mPlayerX - mEnemyX[i];
                    float dy = mPlayerY - mEnemyY[i];
                    float dist = (float) Math.sqrt(dx * dx + dy * dy + 0.001f);
                    if (dist < 10.5f && dist > 1.15f) {
                        float dirX = dx / dist;
                        float dirY = dy / dist;
                        mEnemyFacingX[i] = dirX;
                        mEnemyFacingY[i] = dirY;
                        mEnemyGait[i] += dt * 8.2f;
                        float ex = mEnemyX[i] + dirX * 1.55f * dt;
                        float ey = mEnemyY[i] + dirY * 1.55f * dt;
                        if (!isCliff(ex, ey)) {
                            mEnemyX[i] = ex;
                            mEnemyY[i] = ey;
                        }
                    } else if (dist <= 1.25f) {
                        mEnemyFacingX[i] = dx / dist;
                        mEnemyFacingY[i] = dy / dist;
                        mEnemyAttackAnim[i] += dt * 4.5f;
                        if (mDodgeTimer <= 0.0f && ((int) (mTimeSec * 2.0f + i)) % 3 == 0 && dt > 0) {
                            mHp = Math.max(120, mHp - (int) (3 * dt));
                        }
                    } else {
                        mEnemyGait[i] += dt * 1.8f;
                    }
                }
            }

            // Update ash/spark particles
            for (int pIdx = 0; pIdx < MAX_PARTICLES; pIdx++) {
                if (mPartLife[pIdx] > 0.0f) {
                    mPartLife[pIdx] -= dt;
                    mPartX[pIdx] += mPartVx[pIdx] * dt;
                    mPartY[pIdx] += mPartVy[pIdx] * dt;
                    mPartVy[pIdx] += 2.2f * dt;
                }
            }

            updateVerletHairAndCloak(dt);
            if (mMounted) {
                rasterizeHorseAndRiderAscii();
            } else {
                rasterizeFootKnightAscii();
            }
        }

        private void updateVerletHairAndCloak(float dt) {
            float windMult = (mWindPreset == 0) ? 0.55f : (mWindPreset == 1 ? 1.0f : 1.75f);
            float windX = (float) Math.sin(mTimeSec * 2.1f) * 3.8f * windMult - mVelX * 0.45f;
            float windY = (float) Math.cos(mTimeSec * 1.6f) * 1.6f * windMult + 1.2f;

            float tailAnchorX = mPlayerX - mFacingX * 0.65f;
            float tailAnchorY = mPlayerY - mFacingY * 0.25f - 0.10f;
            stepVerletChain(mTailX, mTailY, mTailPrevX, mTailPrevY, TAIL_STRANDS, TAIL_NODES,
                    tailAnchorX, tailAnchorY, 0.14f, windX, windY, dt, 0.06f);

            float neckX = mPlayerX + mFacingX * 0.45f;
            float neckY = mPlayerY + mFacingY * 0.15f - 0.65f;
            stepVerletChain(mManeX, mManeY, mManePrevX, mManePrevY, MANE_STRANDS, MANE_NODES,
                    neckX, neckY, 0.085f, windX * 0.7f, windY * 0.8f, dt, 0.045f);

            float headX = mMounted ? (mPlayerX - mFacingX * 0.10f) : (mPlayerX - mFacingX * 0.14f);
            float headY = mMounted ? (mPlayerY - 1.25f) : (mPlayerY - 1.05f);
            stepVerletChain(mHairX, mHairY, mHairPrevX, mHairPrevY, HAIR_STRANDS, HAIR_NODES,
                    headX, headY, mMounted ? 0.10f : 0.13f, windX * 1.15f, windY, dt, 0.035f);
        }

        private void stepVerletChain(
                float[][] x, float[][] y, float[][] px, float[][] py,
                int strands, int nodes, float ax, float ay, float segLen,
                float windX, float windY, float dt, float spread
        ) {
            float dt2 = dt * dt;
            for (int s = 0; s < strands; s++) {
                float sOff = (s - strands * 0.5f) * spread;
                x[s][0] = ax + sOff * 0.35f;
                y[s][0] = ay + Math.abs(sOff) * 0.25f;
                for (int n = 1; n < nodes; n++) {
                    float vx = (x[s][n] - px[s][n]) * 0.91f;
                    float vy = (y[s][n] - py[s][n]) * 0.91f;
                    px[s][n] = x[s][n];
                    py[s][n] = y[s][n];
                    float gust = (float) Math.sin(mTimeSec * 4.2f + s * 0.9f + n * 0.5f) * 0.9f;
                    x[s][n] += vx + (windX + gust) * dt2;
                    y[s][n] += vy + windY * dt2;
                }
                for (int iter = 0; iter < 3; iter++) {
                    x[s][0] = ax + sOff * 0.35f;
                    y[s][0] = ay + Math.abs(sOff) * 0.25f;
                    for (int n = 0; n < nodes - 1; n++) {
                        int j = n + 1;
                        float dx = x[s][j] - x[s][n];
                        float dy = y[s][j] - y[s][n];
                        float dist = (float) Math.sqrt(dx * dx + dy * dy + 1e-6f);
                        float diff = (dist - segLen) / dist;
                        if (n == 0) {
                            x[s][j] -= dx * diff;
                            y[s][j] -= dy * diff;
                        } else {
                            x[s][n] += dx * diff * 0.30f;
                            y[s][n] += dy * diff * 0.30f;
                            x[s][j] -= dx * diff * 0.70f;
                            y[s][j] -= dy * diff * 0.70f;
                        }
                    }
                }
            }
        }

        // =========================================================================
        // PROCEDURAL ANIMATED FOOT KNIGHT (NO STATIC PNG!)
        // =========================================================================
        private void rasterizeFootKnightAscii() {
            int total = FOOT_BUF_W * FOOT_BUF_H;
            for (int i = 0; i < total; i++) {
                mFootGlyphBuf[i] = ' ';
                mFootLumBuf[i] = -1.0f;
            }

            float sx = 17.0f;
            float sy = 17.0f;
            float cx = FOOT_BUF_W * 0.5f;
            float cy = FOOT_BUF_H * 0.54f;

            float spd = (float) Math.sqrt(mVelX * mVelX + mVelY * mVelY);
            float moveAmt = Math.min(1.0f, spd / 3.2f);
            float bob = (float) Math.abs(Math.sin(mGaitPhase)) * 0.07f * moveAmt
                    + (float) Math.sin(mTimeSec * 2.6f) * 0.02f;

            float fx = mFacingX;
            float fy = mFacingY;
            boolean dodging = (mDodgeTimer > 0.0f);
            float crouchY = dodging ? 0.24f : 0.0f;
            float leanX = fx * (dodging ? 0.34f : 0.10f * moveAmt);
            bob -= crouchY;

            // 1. Flowing Verlet Cape / Hair behind knight
            for (int hs = 0; hs < HAIR_STRANDS; hs++) {
                float lumBase = 0.78f + (hs % 3) * 0.06f;
                for (int hn = 0; hn < HAIR_NODES - 1; hn++) {
                    float lx0 = mHairX[hs][hn] - mPlayerX;
                    float ly0 = mHairY[hs][hn] - mPlayerY + 0.55f;
                    float lx1 = mHairX[hs][hn + 1] - mPlayerX;
                    float ly1 = mHairY[hs][hn + 1] - mPlayerY + 0.55f;
                    plotHairToBuf(mFootGlyphBuf, mFootLumBuf, mFootColorBuf, FOOT_BUF_W, FOOT_BUF_H,
                            cx, cy, sx, sy, lx0, ly0, lx1, ly1, 0.085f, lumBase - hn * 0.05f);
                }
            }

            // 2. Animated 2-Leg Walk/Run Stride (Left + Right legs with knee bend)
            for (int leg = 0; leg < 2; leg++) {
                float ph = mGaitPhase + (leg == 1 ? (float) Math.PI : 0.0f);
                float side = (leg == 0 ? -0.17f : 0.17f);
                float strideX = (float) Math.sin(ph) * 0.30f * moveAmt * (Math.abs(fx) * 0.6f + 0.4f);
                float strideY = (float) Math.sin(ph) * 0.18f * moveAmt * fy;
                float lift = Math.max(0.0f, (float) Math.cos(ph)) * 0.16f * moveAmt;

                float hipX = side + leanX * 0.3f;
                float hipY = 0.18f - bob;
                float kneeX = hipX + strideX * 0.55f;
                float kneeY = hipY + 0.34f - lift * 0.6f;
                float bootX = hipX + strideX;
                float bootY = hipY + 0.68f + strideY - lift;

                float lLum = (leg == 0) ? 0.72f : 0.86f;
                plotCapsuleToBuf(mFootGlyphBuf, mFootLumBuf, mFootColorBuf, FOOT_BUF_W, FOOT_BUF_H,
                        cx, cy, sx, sy, hipX, hipY, kneeX, kneeY, 0.11f, lLum);
                plotCapsuleToBuf(mFootGlyphBuf, mFootLumBuf, mFootColorBuf, FOOT_BUF_W, FOOT_BUF_H,
                        cx, cy, sx, sy, kneeX, kneeY, bootX, bootY, 0.095f, lLum * 0.95f);
            }

            // 3. Articulated Torso + Pauldrons + Helm
            float pelvisX = 0.0f;
            float pelvisY = 0.16f - bob;
            float chestX = leanX;
            float chestY = -0.34f - bob;
            plotCapsuleToBuf(mFootGlyphBuf, mFootLumBuf, mFootColorBuf, FOOT_BUF_W, FOOT_BUF_H,
                    cx, cy, sx, sy, pelvisX, pelvisY, chestX, chestY, 0.23f, 0.88f);
            // Shoulders / Pauldrons
            plotCapsuleToBuf(mFootGlyphBuf, mFootLumBuf, mFootColorBuf, FOOT_BUF_W, FOOT_BUF_H,
                    cx, cy, sx, sy, chestX - 0.24f, chestY + 0.04f, chestX + 0.24f, chestY + 0.04f, 0.13f, 0.94f);
            // Helm / Head
            float headX = chestX + fx * 0.06f;
            float headY = chestY - 0.32f;
            plotCapsuleToBuf(mFootGlyphBuf, mFootLumBuf, mFootColorBuf, FOOT_BUF_W, FOOT_BUF_H,
                    cx, cy, sx, sy, headX, headY + 0.06f, headX, headY - 0.12f, 0.15f, 0.98f);

            // 4. Left Shield Arm (counter-swings with stride)
            float armSwing = (float) Math.sin(mGaitPhase) * 0.26f * moveAmt;
            float lShX = chestX - 0.26f;
            float lShY = chestY + 0.05f;
            float lHandX = lShX - 0.10f - armSwing * 0.4f;
            float lHandY = lShY + 0.36f - armSwing * 0.3f;
            plotCapsuleToBuf(mFootGlyphBuf, mFootLumBuf, mFootColorBuf, FOOT_BUF_W, FOOT_BUF_H,
                    cx, cy, sx, sy, lShX, lShY, lHandX, lHandY, 0.09f, 0.78f);

            // 5. Right Greatsword Arm + Blade (Idle stance, run swing, OR full slash sweep!)
            float rShX = chestX + 0.26f;
            float rShY = chestY + 0.05f;
            float slashProg = (mSlashTimer > 0.0f) ? (1.0f - (mSlashTimer / 0.24f)) : -1.0f;
            float swordAngle = (slashProg >= 0.0f)
                    ? ((float) Math.atan2(fy, fx) - 1.35f + slashProg * 2.7f)
                    : ((float) Math.atan2(fy, fx) + 0.45f + armSwing * 0.6f);
            float rHandX = rShX + (float) Math.cos(swordAngle) * 0.28f;
            float rHandY = rShY + (float) Math.sin(swordAngle) * 0.28f;
            float tipX = rHandX + (float) Math.cos(swordAngle) * 0.64f;
            float tipY = rHandY + (float) Math.sin(swordAngle) * 0.64f;

            plotCapsuleToBuf(mFootGlyphBuf, mFootLumBuf, mFootColorBuf, FOOT_BUF_W, FOOT_BUF_H,
                    cx, cy, sx, sy, rShX, rShY, rHandX, rHandY, 0.09f, 0.88f);
            plotCapsuleToBuf(mFootGlyphBuf, mFootLumBuf, mFootColorBuf, FOOT_BUF_W, FOOT_BUF_H,
                    cx, cy, sx, sy, rHandX, rHandY, tipX, tipY, 0.055f, 1.0f);
        }

        // =========================================================================
        // PROCEDURAL ANIMATED HUMANOID ENEMY
        // =========================================================================
        private void rasterizeEnemyHumanoidAscii(int eIdx) {
            int total = ENEMY_BUF_W * ENEMY_BUF_H;
            for (int i = 0; i < total; i++) {
                mEnemyGlyphBuf[i] = ' ';
                mEnemyLumBuf[i] = -1.0f;
            }

            float sx = 14.5f;
            float sy = 14.5f;
            float cx = ENEMY_BUF_W * 0.5f;
            float cy = ENEMY_BUF_H * 0.55f;

            float g = mEnemyGait[eIdx];
            float bob = (float) Math.abs(Math.sin(g)) * 0.06f;
            float fx = mEnemyFacingX[eIdx];
            float fy = mEnemyFacingY[eIdx];

            // Legs striding
            for (int leg = 0; leg < 2; leg++) {
                float ph = g + (leg == 1 ? (float) Math.PI : 0.0f);
                float side = (leg == 0 ? -0.15f : 0.15f);
                float st = (float) Math.sin(ph) * 0.26f;
                float lift = Math.max(0.0f, (float) Math.cos(ph)) * 0.14f;
                plotCapsuleToBuf(mEnemyGlyphBuf, mEnemyLumBuf, mEnemyColorBuf, ENEMY_BUF_W, ENEMY_BUF_H,
                        cx, cy, sx, sy, side, 0.15f - bob, side + st, 0.72f - lift, 0.09f, 0.68f);
            }

            // Torso & Pauldrons
            plotCapsuleToBuf(mEnemyGlyphBuf, mEnemyLumBuf, mEnemyColorBuf, ENEMY_BUF_W, ENEMY_BUF_H,
                    cx, cy, sx, sy, 0.0f, 0.14f - bob, fx * 0.08f, -0.32f - bob, 0.21f, 0.80f);
            plotCapsuleToBuf(mEnemyGlyphBuf, mEnemyLumBuf, mEnemyColorBuf, ENEMY_BUF_W, ENEMY_BUF_H,
                    cx, cy, sx, sy, -0.22f, -0.28f - bob, 0.22f, -0.28f - bob, 0.11f, 0.86f);
            // Head / Hooded Helm
            plotCapsuleToBuf(mEnemyGlyphBuf, mEnemyLumBuf, mEnemyColorBuf, ENEMY_BUF_W, ENEMY_BUF_H,
                    cx, cy, sx, sy, fx * 0.08f, -0.50f - bob, fx * 0.08f, -0.66f - bob, 0.13f, 0.92f);

            // Weapon Arm & Halberd/Blade (swings on windup!)
            float atkSwing = (float) Math.sin(mEnemyAttackAnim[eIdx]) * 0.85f;
            float wAng = (float) Math.atan2(fy, fx) + atkSwing;
            float hx = 0.22f + (float) Math.cos(wAng) * 0.25f;
            float hy = -0.26f - bob + (float) Math.sin(wAng) * 0.25f;
            float tx = hx + (float) Math.cos(wAng) * 0.55f;
            float ty = hy + (float) Math.sin(wAng) * 0.55f;
            plotCapsuleToBuf(mEnemyGlyphBuf, mEnemyLumBuf, mEnemyColorBuf, ENEMY_BUF_W, ENEMY_BUF_H,
                    cx, cy, sx, sy, 0.22f, -0.26f - bob, hx, hy, 0.08f, 0.75f);
            plotCapsuleToBuf(mEnemyGlyphBuf, mEnemyLumBuf, mEnemyColorBuf, ENEMY_BUF_W, ENEMY_BUF_H,
                    cx, cy, sx, sy, hx, hy, tx, ty, 0.05f, 0.96f);
        }

        private void rasterizeHorseAndRiderAscii() {
            for (int i = 0; i < HORSE_BUF_W * HORSE_BUF_H; i++) {
                mHorseGlyphBuf[i] = ' ';
                mHorseLumBuf[i] = -1.0f;
            }

            float scaleX = 18.0f;
            float scaleY = 18.0f;
            float cx = HORSE_BUF_W * 0.5f;
            float cy = HORSE_BUF_H * 0.56f;

            float fx = mFacingX;
            float fy = mFacingY;
            float bob = (float) Math.abs(Math.sin(mGaitPhase)) * 0.045f;

            float[] legHipOff = {-0.58f, 0.52f, -0.46f, 0.62f};
            float[] legPhaseOff = {0.0f, (float) Math.PI, (float) (Math.PI * 0.5), (float) (Math.PI * 1.5)};
            float[] legBrightness = {0.42f, 0.45f, 0.72f, 0.76f};
            float speedFactor = Math.min(1.0f, (float) Math.sqrt(mVelX * mVelX + mVelY * mVelY) / 3.5f);

            for (int leg = 0; leg < 4; leg++) {
                float ph = mGaitPhase + legPhaseOff[leg];
                float swing = (float) Math.sin(ph) * 0.28f * speedFactor;
                float lift = Math.max(0.0f, (float) Math.cos(ph)) * 0.18f * speedFactor;

                float hipX = fx * legHipOff[leg];
                float hipY = fy * legHipOff[leg] * 0.35f + 0.08f - bob;
                float kneeX = hipX + fx * (swing * 0.5f + 0.04f);
                float kneeY = hipY + 0.36f - lift * 0.5f;
                float hoofX = kneeX + fx * swing;
                float hoofY = hipY + 0.74f - lift;

                plotCapsuleToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                        cx, cy, scaleX, scaleY, hipX, hipY, kneeX, kneeY, 0.11f, legBrightness[leg]);
                plotCapsuleToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                        cx, cy, scaleX, scaleY, kneeX, kneeY, hoofX, hoofY, 0.085f, legBrightness[leg] * 0.9f);
            }

            float rearX = -fx * 0.56f;
            float rearY = -fy * 0.22f - 0.05f - bob;
            float frontX = fx * 0.52f;
            float frontY = fy * 0.22f - 0.08f - bob;
            plotCapsuleToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                    cx, cy, scaleX, scaleY, rearX, rearY, frontX, frontY, 0.34f, 0.88f);
            plotCapsuleToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                    cx, cy, scaleX, scaleY, rearX, rearY - 0.06f, rearX * 0.5f, rearY - 0.08f, 0.26f, 0.96f);

            float neckTopX = frontX + fx * 0.42f;
            float neckTopY = frontY - 0.52f;
            plotCapsuleToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                    cx, cy, scaleX, scaleY, frontX, frontY - 0.05f, neckTopX, neckTopY, 0.22f, 0.92f);

            float muzzleX = neckTopX + fx * 0.38f;
            float muzzleY = neckTopY + 0.14f;
            plotCapsuleToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                    cx, cy, scaleX, scaleY, neckTopX, neckTopY, muzzleX, muzzleY, 0.14f, 0.95f);
            plotCapsuleToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                    cx, cy, scaleX, scaleY, neckTopX - fx * 0.05f, neckTopY - 0.08f, neckTopX - fx * 0.02f, neckTopY - 0.24f, 0.06f, 0.98f);

            float saddleX = -fx * 0.06f;
            float saddleY = -0.32f - bob;
            plotCapsuleToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                    cx, cy, scaleX, scaleY, saddleX, saddleY + 0.18f, saddleX + fx * 0.12f, saddleY + 0.58f, 0.10f, 0.38f);
            plotCapsuleToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                    cx, cy, scaleX, scaleY, saddleX, saddleY, saddleX - fx * 0.04f, saddleY - 0.52f, 0.21f, 0.62f);
            plotCapsuleToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                    cx, cy, scaleX, scaleY, saddleX - fx * 0.04f, saddleY - 0.66f, saddleX - fx * 0.02f, saddleY - 0.80f, 0.13f, 0.84f);
            plotCapsuleToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                    cx, cy, scaleX, scaleY, saddleX + fx * 0.05f, saddleY - 0.36f, frontX + fx * 0.20f, frontY - 0.25f, 0.08f, 0.70f);

            for (int ts = 0; ts < TAIL_STRANDS; ts++) {
                float tLum = 0.80f + (ts % 4) * 0.05f;
                for (int tn = 0; tn < TAIL_NODES - 1; tn++) {
                    plotHairToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                            cx, cy, scaleX, scaleY,
                            mTailX[ts][tn] - mPlayerX, mTailY[ts][tn] - mPlayerY,
                            mTailX[ts][tn + 1] - mPlayerX, mTailY[ts][tn + 1] - mPlayerY,
                            0.095f - tn * 0.007f, tLum - tn * 0.04f);
                }
            }
            for (int ms = 0; ms < MANE_STRANDS; ms++) {
                float mLum = 0.88f + (ms % 3) * 0.04f;
                for (int mn = 0; mn < MANE_NODES - 1; mn++) {
                    plotHairToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                            cx, cy, scaleX, scaleY,
                            mManeX[ms][mn] - mPlayerX, mManeY[ms][mn] - mPlayerY,
                            mManeX[ms][mn + 1] - mPlayerX, mManeY[ms][mn + 1] - mPlayerY,
                            0.075f, mLum - mn * 0.03f);
                }
            }
            for (int hs = 0; hs < HAIR_STRANDS; hs++) {
                for (int hn = 0; hn < HAIR_NODES - 1; hn++) {
                    plotHairToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                            cx, cy, scaleX, scaleY,
                            mHairX[hs][hn] - mPlayerX, mHairY[hs][hn] - mPlayerY,
                            mHairX[hs][hn + 1] - mPlayerX, mHairY[hs][hn + 1] - mPlayerY,
                            0.070f, 0.96f - hn * 0.04f);
                }
            }
        }

        private void plotCapsuleToBuf(
                char[] gBuf, float[] lBuf, int[] cBuf, int bufW, int bufH,
                float cx, float cy, float sx, float sy,
                float ax, float ay, float bx, float by,
                float radius, float baseLum
        ) {
            int minC = Math.max(0, (int) (cx + (Math.min(ax, bx) - radius) * sx) - 1);
            int maxC = Math.min(bufW - 1, (int) (cx + (Math.max(ax, bx) + radius) * sx) + 1);
            int minR = Math.max(0, (int) (cy + (Math.min(ay, by) - radius) * sy) - 1);
            int maxR = Math.min(bufH - 1, (int) (cy + (Math.max(ay, by) + radius) * sy) + 1);

            float abx = bx - ax;
            float aby = by - ay;
            float ab2 = abx * abx + aby * aby + 1e-6f;
            float r2 = radius * radius;

            for (int r = minR; r <= maxR; r++) {
                float py = (r - cy) / sy;
                for (int c = minC; c <= maxC; c++) {
                    float px = (c - cx) / sx;
                    float t = ((px - ax) * abx + (py - ay) * aby) / ab2;
                    if (t < 0.0f) t = 0.0f;
                    else if (t > 1.0f) t = 1.0f;
                    float qx = ax + t * abx;
                    float qy = ay + t * aby;
                    float dx = px - qx;
                    float dy = py - qy;
                    float d2 = dx * dx + dy * dy;
                    if (d2 <= r2) {
                        float distNorm = (float) Math.sqrt(d2) / radius;
                        float nz = (float) Math.sqrt(Math.max(0.0f, 1.0f - distNorm * distNorm));
                        float ny = dy / radius;
                        float light = (nz * 0.72f - ny * 0.38f + 0.15f) * baseLum;
                        if (distNorm > 0.80f) light *= 0.25f;
                        int idx = r * bufW + c;
                        if (light > lBuf[idx]) {
                            lBuf[idx] = light;
                            int rampIdx = Math.max(1, Math.min(DENSE_RAMP.length() - 1, (int) (light * (DENSE_RAMP.length() - 1))));
                            gBuf[idx] = DENSE_RAMP.charAt(rampIdx);
                            int v = Math.max(20, Math.min(250, (int) (light * 255.0f)));
                            cBuf[idx] = Color.rgb(v, v, Math.min(255, v + 6));
                        }
                    }
                }
            }
        }

        private void plotHairToBuf(
                char[] gBuf, float[] lBuf, int[] cBuf, int bufW, int bufH,
                float cx, float cy, float sx, float sy,
                float ax, float ay, float bx, float by,
                float radius, float lum
        ) {
            int steps = 4;
            for (int i = 0; i <= steps; i++) {
                float t = i / (float) steps;
                float px = ax + (bx - ax) * t;
                float py = ay + (by - ay) * t;
                int c0 = Math.round(cx + px * sx);
                int r0 = Math.round(cy + py * sy);
                int radCells = Math.max(1, Math.round(radius * sx));
                for (int dr = -radCells; dr <= radCells; dr++) {
                    for (int dc = -radCells; dc <= radCells; dc++) {
                        int c = c0 + dc;
                        int r = r0 + dr;
                        if (c >= 0 && c < bufW && r >= 0 && r < bufH) {
                            float falloff = 1.0f - ((float) Math.sqrt(dc * dc + dr * dr) / (radCells + 0.6f));
                            if (falloff > 0.0f) {
                                float l = lum * (0.65f + 0.35f * falloff);
                                int idx = r * bufW + c;
                                if (l >= lBuf[idx]) {
                                    lBuf[idx] = l;
                                    int rIdx = Math.max(4, Math.min(DENSE_RAMP.length() - 1, (int) (l * (DENSE_RAMP.length() - 1))));
                                    gBuf[idx] = DENSE_RAMP.charAt(rIdx);
                                    int v = Math.max(95, Math.min(252, (int) (l * 255.0f)));
                                    cBuf[idx] = Color.rgb(v, v, Math.min(255, v + 5));
                                }
                            }
                        }
                    }
                }
            }
        }

        private Bitmap getOrBuildChunk(int cxIdx, int cyIdx, int[] builtThisFrame) {
            int key = ((cxIdx & 0xFFFF) << 16) | (cyIdx & 0xFFFF);
            int lruIdx = 0;
            int minAge = Integer.MAX_VALUE;
            for (int i = 0; i < CHUNK_CACHE_CAP; i++) {
                if (mChunkKeys[i] == key && mChunkBitmaps[i] != null) {
                    mChunkAge[i] = ++mChunkTick;
                    return mChunkBitmaps[i];
                }
                if (mChunkBitmaps[i] == null) {
                    lruIdx = i;
                    minAge = -1;
                } else if (minAge != -1 && mChunkAge[i] < minAge) {
                    minAge = mChunkAge[i];
                    lruIdx = i;
                }
            }

            if (builtThisFrame[0] >= 2) {
                return null;
            }
            builtThisFrame[0]++;

            if (mChunkBitmaps[lruIdx] == null) {
                mChunkBitmaps[lruIdx] = Bitmap.createBitmap(CHUNK_PX, CHUNK_PX, Bitmap.Config.ARGB_8888);
                mChunkCanvases[lruIdx] = new Canvas(mChunkBitmaps[lruIdx]);
            }
            mChunkKeys[lruIdx] = key;
            mChunkAge[lruIdx] = ++mChunkTick;

            Canvas cc = mChunkCanvases[lruIdx];
            // 1. Blit pre-baked ultra-dense meadow tile quadrant (28,000+ tiny grass blades + 0Q8B + wildflowers)
            int qx = Math.abs(cxIdx) % 4;
            int qy = Math.abs(cyIdx) % 4;
            android.graphics.Rect srcRect = new android.graphics.Rect(qx * 256, qy * 256, qx * 256 + 256, qy * 256 + 256);
            mTmpRect.set(0, 0, CHUNK_PX, CHUNK_PX);
            cc.drawBitmap(mMeadowTileBitmap, srcRect, mTmpRect, null);

            // 2. River + Sculpted 3D Normal-Lit Dark-Backed ASCII Cliffs + AO Shadow Rim
            float cellPx = 10.666f;
            int cells = (int) (CHUNK_PX / cellPx) + 1;
            float baseWx = cxIdx * CHUNK_WORLD_UNITS;
            float baseWy = cyIdx * CHUNK_WORLD_UNITS;
            float unitsPerCell = CHUNK_WORLD_UNITS / (CHUNK_PX / cellPx);

            Paint cBg = new Paint();
            cBg.setStyle(Paint.Style.FILL);
            Paint cTxt = new Paint(Paint.ANTI_ALIAS_FLAG);
            cTxt.setTypeface(Typeface.MONOSPACE);
            cTxt.setFakeBoldText(true);
            cTxt.setTextSize(cellPx * 1.05f);

            for (int r = 0; r < cells; r++) {
                float wy = baseWy + r * unitsPerCell;
                float py = r * cellPx;
                for (int c = 0; c < cells; c++) {
                    float wx = baseWx + c * unitsPerCell;
                    float px = c * cellPx;
                    float distRiver = Math.abs(wy - riverCenterY(wx));
                    if (distRiver < 2.15f) {
                        int dShade = (distRiver < 1.35f) ? 7 : 12;
                        cBg.setColor(Color.rgb(dShade, dShade + 5, dShade + 13));
                        cc.drawRect(px, py, px + cellPx + 1.0f, py + cellPx + 1.0f, cBg);
                    } else {
                        float dens = cliffDensity(wx, wy);
                        if (dens > 0.68f) {
                            cBg.setColor(Color.rgb(7, 9, 11));
                            cc.drawRect(px, py, px + cellPx + 1.0f, py + cellPx + 1.0f, cBg);
                            // 3D surface normal from density gradient for sculptural top-left lighting
                            float gx = cliffDensity(wx + 0.12f, wy) - cliffDensity(wx - 0.12f, wy);
                            float gy = cliffDensity(wx, wy + 0.12f) - cliffDensity(wx, wy - 0.12f);
                            float sun = Math.max(-0.4f, Math.min(1.0f, (-gx - gy) * 2.6f + 0.48f));
                            int cHash = Math.abs(((cxIdx * 37 + c) * 73856093) ^ ((cyIdx * 37 + r) * 19349663));
                            char ch = CLIFF_CHARS.charAt(cHash % CLIFF_CHARS.length());
                            int lum = Math.max(58, Math.min(242, (int) (82 + sun * 135 + (cHash % 28))));
                            cTxt.setColor(Color.rgb(lum - 4, lum, Math.min(255, lum + 10)));
                            cc.drawText(String.valueOf(ch), px, py + cellPx * 0.86f, cTxt);
                        } else if (dens > 0.56f) {
                            // Soft ambient-occlusion shadow rim around cliff base
                            int alpha = (int) (((dens - 0.56f) / 0.12f) * 145.0f);
                            cBg.setColor(Color.argb(alpha, 3, 6, 5));
                            cc.drawRect(px, py, px + cellPx + 1.0f, py + cellPx + 1.0f, cBg);
                        }
                    }
                }
            }
            return mChunkBitmaps[lruIdx];
        }

        private void drawAsciiBufferSpanBatched(
                Canvas canvas, char[] gBuf, int[] cBuf, int bufW, int bufH,
                float originX, float originY, float cellPx,
                boolean darkBacking, int overrideColor
        ) {
            mAsciiPaint.setTextSize(Math.max(5.5f, cellPx * 1.18f));
            mAsciiPaint.setTextAlign(Paint.Align.LEFT);
            for (int r = 0; r < bufH; r++) {
                float drawY = originY + r * cellPx;
                int rowOff = r * bufW;
                int c = 0;
                while (c < bufW) {
                    if (gBuf[rowOff + c] == ' ') {
                        c++;
                        continue;
                    }
                    int startC = c;
                    int firstColor = (overrideColor != 0) ? overrideColor : cBuf[rowOff + c];
                    while (c < bufW && gBuf[rowOff + c] != ' ') {
                        if (overrideColor == 0 && Math.abs(Color.red(cBuf[rowOff + c]) - Color.red(firstColor)) > 36) {
                            break;
                        }
                        c++;
                    }
                    int spanLen = c - startC;
                    float sx = originX + startC * cellPx;
                    if (darkBacking) {
                        mPanelPaint.setColor(Color.argb(225, 6, 8, 10));
                        canvas.drawRect(sx - 1.0f, drawY - cellPx * 0.88f, sx + spanLen * cellPx + 1.0f, drawY + cellPx * 0.16f, mPanelPaint);
                    }
                    mAsciiPaint.setColor(firstColor);
                    canvas.drawText(gBuf, rowOff + startC, spanLen, sx, drawY, mAsciiPaint);
                }
            }
        }

        private void drawFrame() {
            SurfaceHolder holder = getHolder();
            Canvas canvas = null;
            try {
                if (Build.VERSION.SDK_INT >= 26) {
                    canvas = holder.lockHardwareCanvas();
                } else {
                    canvas = holder.lockCanvas();
                }
                if (canvas == null) return;

                ensureStaticCaches();

                int screenW = canvas.getWidth();
                int screenH = canvas.getHeight();
                canvas.drawColor(Color.rgb(8, 12, 11));

                float pixelsPerUnit = Math.min(screenW, screenH) * 0.095f * mCameraZoom;
                float centerX = screenW * 0.5f;
                float centerY = screenH * 0.48f;

                float halfUnitsW = (screenW * 0.5f) / pixelsPerUnit + 1.5f;
                float halfUnitsH = (screenH * 0.5f) / pixelsPerUnit + 1.5f;

                // ----------------------------------------------------------------
                // 1. PRE-BAKED CHUNK CACHE (ULTRA-DENSE TINY GRASS + 0Q8B + CLIFFS + RIVER)
                // ----------------------------------------------------------------
                int minCx = (int) Math.floor((mCamX - halfUnitsW) / CHUNK_WORLD_UNITS);
                int maxCx = (int) Math.floor((mCamX + halfUnitsW) / CHUNK_WORLD_UNITS);
                int minCy = (int) Math.floor((mCamY - halfUnitsH) / CHUNK_WORLD_UNITS);
                int maxCy = (int) Math.floor((mCamY + halfUnitsH) / CHUNK_WORLD_UNITS);
                int[] builtThisFrame = new int[]{0};

                for (int cy = minCy; cy <= maxCy; cy++) {
                    for (int cx = minCx; cx <= maxCx; cx++) {
                        float sx0 = centerX + (cx * CHUNK_WORLD_UNITS - mCamX) * pixelsPerUnit;
                        float sy0 = centerY + (cy * CHUNK_WORLD_UNITS - mCamY) * pixelsPerUnit;
                        float chunkScreenPx = CHUNK_WORLD_UNITS * pixelsPerUnit;
                        mTmpRect.set(sx0, sy0, sx0 + chunkScreenPx + 1.5f, sy0 + chunkScreenPx + 1.5f);
                        Bitmap chunk = getOrBuildChunk(cx, cy, builtThisFrame);
                        if (chunk != null) {
                            canvas.drawBitmap(chunk, null, mTmpRect, mBitmapPaint);
                        } else {
                            canvas.drawBitmap(mMeadowTileBitmap, null, mTmpRect, mBitmapPaint);
                        }
                    }
                }

                // ----------------------------------------------------------------
                // 2. BATCHED DYNAMIC WIND GRASS TIPS (2 drawLines CALLS = 60+ FPS!)
                // ----------------------------------------------------------------
                float windScale = (mWindPreset == 0) ? 0.6f : (mWindPreset == 1 ? 1.0f : 1.75f);
                float bladeScreenLen = Math.max(5.0f, pixelsPerUnit * 0.13f);
                mGrassPaint.setStrokeWidth(Math.max(1.3f, pixelsPerUnit * 0.017f));
                int minWx = (int) Math.floor(mCamX - halfUnitsW);
                int maxWx = (int) Math.ceil(mCamX + halfUnitsW);
                int minWy = (int) Math.floor(mCamY - halfUnitsH);
                int maxWy = (int) Math.ceil(mCamY + halfUnitsH);

                int dCount = 0;
                int bCount = 0;
                for (int wy = minWy; wy <= maxWy && (dCount < WIND_BLADES_PER_LAYER || bCount < WIND_BLADES_PER_LAYER); wy++) {
                    for (int wx = minWx; wx <= maxWx; wx++) {
                        if (Math.abs(wy - riverCenterY(wx)) < 2.1f || isCliff(wx, wy)) continue;
                        float sx = centerX + (wx - mCamX) * pixelsPerUnit;
                        float sy = centerY + (wy - mCamY) * pixelsPerUnit;
                        float sway = (float) Math.sin(wx * 0.45f + wy * 0.30f - mTimeSec * 3.4f * windScale) * bladeScreenLen * 0.55f;
                        int h = Math.abs((wx * 19349663) ^ (wy * 83492791));
                        if (dCount < WIND_BLADES_PER_LAYER) {
                            int o = dCount * 4;
                            float ox = ((h & 15) / 15.0f - 0.5f) * pixelsPerUnit * 0.8f;
                            float oy = (((h >> 4) & 15) / 15.0f - 0.5f) * pixelsPerUnit * 0.8f;
                            mWindPtsDark[o] = sx + ox;
                            mWindPtsDark[o + 1] = sy + oy;
                            mWindPtsDark[o + 2] = sx + ox + sway;
                            mWindPtsDark[o + 3] = sy + oy - bladeScreenLen;
                            dCount++;
                        }
                        if (bCount < WIND_BLADES_PER_LAYER && (h % 2 == 0)) {
                            int o = bCount * 4;
                            float ox = (((h >> 8) & 15) / 15.0f - 0.5f) * pixelsPerUnit * 0.8f;
                            float oy = (((h >> 12) & 15) / 15.0f - 0.5f) * pixelsPerUnit * 0.8f;
                            mWindPtsBright[o] = sx + ox;
                            mWindPtsBright[o + 1] = sy + oy;
                            mWindPtsBright[o + 2] = sx + ox + sway * 1.15f;
                            mWindPtsBright[o + 3] = sy + oy - bladeScreenLen * 1.1f;
                            bCount++;
                        }
                    }
                }
                if (dCount > 0) {
                    mGrassPaint.setColor(Color.rgb(42, 104, 48));
                    canvas.drawLines(mWindPtsDark, 0, dCount * 4, mGrassPaint);
                }
                if (bCount > 0) {
                    mGrassPaint.setColor(Color.rgb(98, 172, 92));
                    canvas.drawLines(mWindPtsBright, 0, bCount * 4, mGrassPaint);
                }

                // River foam streaks
                mAsciiPaint.setTextSize(Math.max(10.0f, pixelsPerUnit * 0.22f));
                mAsciiPaint.setTextAlign(Paint.Align.LEFT);
                for (int wx = minWx; wx <= maxWx; wx++) {
                    float ry = riverCenterY(wx);
                    float wave = (float) Math.sin(wx * 0.6f - mTimeSec * 2.8f);
                    if (wave > 0.25f) {
                        float sx = centerX + (wx - mCamX) * pixelsPerUnit;
                        float sy = centerY + (ry + (wave - 0.5f) * 0.8f - mCamY) * pixelsPerUnit;
                        mAsciiPaint.setColor(wave > 0.7f ? Color.rgb(215, 225, 235) : Color.rgb(88, 108, 134));
                        canvas.drawText("0Q8~=", sx, sy, mAsciiPaint);
                    }
                }

                // ----------------------------------------------------------------
                // 3. LOOT + ANIMATED HUMANOID ENEMIES + ANIMATED HERO
                // ----------------------------------------------------------------
                for (int lIdx = 0; lIdx < MAX_LOOT; lIdx++) {
                    if (mLootActive[lIdx]) {
                        float lx = centerX + (mLootX[lIdx] - mCamX) * pixelsPerUnit;
                        float ly = centerY + (mLootY[lIdx] - mCamY) * pixelsPerUnit;
                        mAsciiPaint.setColor(Color.rgb(245, 212, 98));
                        canvas.drawText("@WM#*+", lx - pixelsPerUnit * 0.3f, ly, mAsciiPaint);
                    }
                }

                float enemyCellPx = (pixelsPerUnit * 2.15f) / ENEMY_BUF_W;
                for (int eIdx = 0; eIdx < NUM_ENEMIES; eIdx++) {
                    float ex = centerX + (mEnemyX[eIdx] - mCamX) * pixelsPerUnit;
                    float ey = centerY + (mEnemyY[eIdx] - mCamY) * pixelsPerUnit;
                    if (ex < -140 || ex > screenW + 140 || ey < -140 || ey > screenH + 140) continue;

                    mShadowPaint.setColor(Color.argb(175, 5, 8, 7));
                    mTmpRect.set(ex - pixelsPerUnit * 0.36f, ey + pixelsPerUnit * 0.14f, ex + pixelsPerUnit * 0.56f, ey + pixelsPerUnit * 0.44f);
                    canvas.drawOval(mTmpRect, mShadowPaint);

                    rasterizeEnemyHumanoidAscii(eIdx);
                    int hitTint = (mEnemyHurt[eIdx] > 0.0f) ? Color.rgb(242, 82, 82) : 0;
                    drawAsciiBufferSpanBatched(
                            canvas, mEnemyGlyphBuf, mEnemyColorBuf, ENEMY_BUF_W, ENEMY_BUF_H,
                            ex - (ENEMY_BUF_W * 0.5f) * enemyCellPx,
                            ey - (ENEMY_BUF_H * 0.65f) * enemyCellPx,
                            enemyCellPx, true, hitTint
                    );
                }

                // Dodge Afterimage Ghosts
                for (int g = 0; g < MAX_AFTERIMAGES; g++) {
                    if (mGhostLife[g] > 0.0f) {
                        float gx = centerX + (mGhostX[g] - mCamX) * pixelsPerUnit;
                        float gy = centerY + (mGhostY[g] - mCamY) * pixelsPerUnit;
                        int alpha = Math.max(30, Math.min(180, (int) ((mGhostLife[g] / 0.24f) * 165.0f)));
                        int gCol = Color.argb(alpha, 160, 235, 225);
                        if (mMounted) {
                            float hCellPx = (pixelsPerUnit * 3.15f) / HORSE_BUF_W;
                            drawAsciiBufferSpanBatched(
                                    canvas, mHorseGlyphBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                                    gx - (HORSE_BUF_W * 0.5f) * hCellPx,
                                    gy - (HORSE_BUF_H * 0.56f) * hCellPx,
                                    hCellPx, false, gCol
                            );
                        } else {
                            float fCellPx = (pixelsPerUnit * 2.35f) / FOOT_BUF_W;
                            drawAsciiBufferSpanBatched(
                                    canvas, mFootGlyphBuf, mFootColorBuf, FOOT_BUF_W, FOOT_BUF_H,
                                    gx - (FOOT_BUF_W * 0.5f) * fCellPx,
                                    gy - (FOOT_BUF_H * 0.62f) * fCellPx,
                                    fCellPx, false, gCol
                            );
                        }
                    }
                }

                if (mMounted) {
                    float hCellPx = (pixelsPerUnit * 3.15f) / HORSE_BUF_W;
                    float hx = centerX + (mPlayerX - mCamX) * pixelsPerUnit;
                    float hy = centerY + (mPlayerY - mCamY) * pixelsPerUnit;
                    mShadowPaint.setColor(Color.argb(185, 4, 7, 6));
                    mTmpRect.set(hx - pixelsPerUnit * 0.9f, hy + pixelsPerUnit * 0.15f, hx + pixelsPerUnit * 1.0f, hy + pixelsPerUnit * 0.78f);
                    canvas.drawOval(mTmpRect, mShadowPaint);
                    drawAsciiBufferSpanBatched(
                            canvas, mHorseGlyphBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                            hx - (HORSE_BUF_W * 0.5f) * hCellPx,
                            hy - (HORSE_BUF_H * 0.56f) * hCellPx,
                            hCellPx, true, 0
                    );
                } else {
                    float fCellPx = (pixelsPerUnit * 2.35f) / FOOT_BUF_W;
                    float hx = centerX + (mPlayerX - mCamX) * pixelsPerUnit;
                    float hy = centerY + (mPlayerY - mCamY) * pixelsPerUnit;
                    mShadowPaint.setColor(Color.argb(185, 4, 7, 6));
                    mTmpRect.set(hx - pixelsPerUnit * 0.35f, hy + pixelsPerUnit * 0.18f, hx + pixelsPerUnit * 0.75f, hy + pixelsPerUnit * 0.52f);
                    canvas.drawOval(mTmpRect, mShadowPaint);

                    mAsciiPaint.setTextSize(Math.max(11.0f, pixelsPerUnit * 0.18f));
                    mAsciiPaint.setColor(Color.rgb(232, 236, 234));
                    mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                    canvas.drawText("Ashveil", hx, hy - (FOOT_BUF_H * 0.68f) * fCellPx, mAsciiPaint);

                    drawAsciiBufferSpanBatched(
                            canvas, mFootGlyphBuf, mFootColorBuf, FOOT_BUF_W, FOOT_BUF_H,
                            hx - (FOOT_BUF_W * 0.5f) * fCellPx,
                            hy - (FOOT_BUF_H * 0.62f) * fCellPx,
                            fCellPx, true, 0
                    );
                }

                // Ash / Spark Particles
                mAsciiPaint.setTextSize(Math.max(10.0f, pixelsPerUnit * 0.18f));
                mAsciiPaint.setTextAlign(Paint.Align.LEFT);
                for (int pIdx = 0; pIdx < MAX_PARTICLES; pIdx++) {
                    if (mPartLife[pIdx] > 0.0f) {
                        float px = centerX + (mPartX[pIdx] - mCamX) * pixelsPerUnit;
                        float py = centerY + (mPartY[pIdx] - mCamY) * pixelsPerUnit;
                        mAsciiPaint.setColor(mPartColor[pIdx]);
                        canvas.drawText("*", px, py, mAsciiPaint);
                    }
                }

                // Greatsword Slash Arc
                if (mSlashTimer > 0.0f) {
                    mAsciiPaint.setTextSize(Math.max(12.0f, pixelsPerUnit * 0.25f));
                    mAsciiPaint.setColor(Color.rgb(245, 248, 242));
                    float hx = centerX + (mPlayerX - mCamX) * pixelsPerUnit;
                    float hy = centerY + (mPlayerY - mCamY) * pixelsPerUnit;
                    for (int a = -5; a <= 5; a++) {
                        float ang = (float) Math.atan2(mFacingY, mFacingX) + a * 0.22f;
                        float rx = hx + (float) Math.cos(ang) * pixelsPerUnit * 1.45f;
                        float ry = hy + (float) Math.sin(ang) * pixelsPerUnit * 1.15f;
                        int sIdx = (a + 5) % 4;
                        canvas.drawText("@W#*+", sIdx, sIdx + 1, rx, ry, mAsciiPaint);
                    }
                }

                // ----------------------------------------------------------------
                // 4. PRE-BAKED MISTY FOG CLOUDS (ZERO ALLOCATIONS)
                // ----------------------------------------------------------------
                for (int fIdx = 0; fIdx < 4; fIdx++) {
                    float fx = (float) (((mTimeSec * (18.0f + fIdx * 7.0f) + fIdx * 310.0f) % (screenW + 400)) - 200.0f);
                    float fy = screenH * (0.20f + fIdx * 0.22f) + (float) Math.sin(mTimeSec * 0.4f + fIdx) * 45.0f;
                    float fRad = Math.min(screenW, screenH) * (0.28f + (fIdx % 2) * 0.10f);
                    mTmpRect.set(fx - fRad, fy - fRad, fx + fRad, fy + fRad);
                    canvas.drawBitmap(mFogBitmap, null, mTmpRect, mBitmapPaint);
                }

                // Subtle cinematic vignette around screen edges
                mTmpRect.set(0, 0, screenW, screenH);
                canvas.drawBitmap(mVignetteBitmap, null, mTmpRect, mBitmapPaint);

                // ----------------------------------------------------------------
                // 5. CROSSHAIR `+` & UI OVERLAYS
                // ----------------------------------------------------------------
                if (mScreenMode == 1) {
                    mAsciiPaint.setTextSize(Math.max(20.0f, pixelsPerUnit * 0.34f));
                    mAsciiPaint.setColor(Color.rgb(238, 242, 240));
                    canvas.drawText("+", mCursorX * screenW - 8, mCursorY * screenH + 8, mAsciiPaint);
                }

                if (mScreenMode == 0) {
                    drawStartMenuOverlay(canvas, screenW, screenH);
                } else if (mScreenMode == 1) {
                    drawTopLeftPortraitHud(canvas, screenW, screenH);
                } else if (mScreenMode == 2) {
                    drawCharacterAndLootModal(canvas, screenW, screenH);
                }
            } finally {
                if (canvas != null) {
                    holder.unlockCanvasAndPost(canvas);
                }
            }
        }

        private void drawStartMenuOverlay(Canvas canvas, int w, int h) {
            mPanelPaint.setColor(Color.argb(95, 6, 10, 8));
            canvas.drawRect(0, 0, w, h, mPanelPaint);

            mUiPaint.setTextAlign(Paint.Align.CENTER);
            float titleSize = Math.min(w, h) * 0.082f;
            mUiPaint.setTextSize(titleSize);
            mUiPaint.setColor(Color.rgb(244, 246, 242));
            canvas.drawText("A S H V E I L", w * 0.5f, h * 0.28f, mUiPaint);

            mUiPaint.setTextSize(titleSize * 0.42f);
            mUiPaint.setColor(Color.rgb(198, 208, 202));
            canvas.drawText("Pure-ASCII 3D Open-World RPG & Hair Physics", w * 0.5f, h * 0.34f, mUiPaint);

            mAsciiPaint.setTextAlign(Paint.Align.CENTER);
            float btnTextSize = Math.min(w, h) * 0.036f;
            mAsciiPaint.setTextSize(btnTextSize);

            String zoomLabel = (mZoomPreset == 0) ? "CLOSE-UP" : (mZoomPreset == 1 ? "MEDIUM" : "WIDE");
            String modeLabel = mMounted ? "MOUNTED STEED" : "FOOT KNIGHT";
            String atkLabel = mAttackButtonOnly ? "ATK BUTTON" : "TAP ANYWHERE";

            String[] buttons = {
                    "[ ENTER THE WORLD ]",
                    "[ CAMERA ZOOM: " + zoomLabel + " ]",
                    "[ STYLE: " + modeLabel + " ]",
                    "[ ATTACK MODE: " + atkLabel + " ]",
                    "[ CHARACTER, LOOT & FORGE (LV." + mLevel + ") ]"
            };
            float[] yTops = {0.39f, 0.49f, 0.59f, 0.69f, 0.79f};
            for (int b = 0; b < buttons.length; b++) {
                float top = h * yTops[b];
                float bot = top + h * 0.08f;
                mPanelPaint.setColor(b == 0 ? Color.argb(230, 14, 28, 20) : Color.argb(215, 8, 12, 11));
                canvas.drawRect(w * 0.15f, top, w * 0.85f, bot, mPanelPaint);
                mBorderPaint.setColor(b == 0 ? Color.rgb(218, 232, 224) : Color.rgb(120, 140, 128));
                canvas.drawRect(w * 0.15f, top, w * 0.85f, bot, mBorderPaint);
                mAsciiPaint.setColor(Color.rgb(240, 244, 240));
                canvas.drawText(buttons[b], w * 0.5f, (top + bot) * 0.5f + btnTextSize * 0.35f, mAsciiPaint);
            }
            mAsciiPaint.setTextAlign(Paint.Align.LEFT);
        }

        private void drawTopLeftPortraitHud(Canvas canvas, int w, int h) {
            float boxW = Math.min(w * 0.44f, 450.0f);
            float boxH = Math.min(h * 0.13f, 150.0f);
            float x0 = 18.0f;
            float y0 = 18.0f;

            mPanelPaint.setColor(Color.argb(235, 8, 10, 11));
            canvas.drawRect(x0, y0, x0 + boxW, y0 + boxH, mPanelPaint);
            mBorderPaint.setColor(Color.rgb(220, 224, 222));
            canvas.drawRect(x0, y0, x0 + boxW, y0 + boxH, mBorderPaint);

            mAsciiPaint.setTextAlign(Paint.Align.LEFT);
            float pSize = boxH * 0.145f;
            mAsciiPaint.setTextSize(pSize);
            mAsciiPaint.setColor(Color.rgb(215, 220, 218));
            for (int pr = 0; pr < PORTRAIT_ART.length; pr++) {
                canvas.drawText(PORTRAIT_ART[pr], x0 + 12.0f, y0 + pSize * 1.45f + pr * pSize * 0.98f, mAsciiPaint);
            }

            float tx = x0 + boxW * 0.25f;
            float tSize = boxH * 0.175f;
            mUiPaint.setTextAlign(Paint.Align.LEFT);
            mUiPaint.setTextSize(tSize);
            mUiPaint.setColor(Color.rgb(240, 242, 240));
            canvas.drawText("Ashveil", tx, y0 + tSize * 1.25f, mUiPaint);

            mAsciiPaint.setTextSize(tSize * 0.85f);
            mAsciiPaint.setColor(Color.rgb(225, 230, 228));
            canvas.drawText("HP |||||||||||||||| " + mHp + "/" + mMaxHp, tx, y0 + tSize * 2.35f, mAsciiPaint);
            canvas.drawText("MP |||||||||||||||| " + mMp + "/" + mMaxMp, tx, y0 + tSize * 3.40f, mAsciiPaint);
            canvas.drawText("LV " + mLevel + " \u00b7 " + mGold + "g" + (mStatPoints > 0 ? " *+STAT*" : ""), tx, y0 + tSize * 4.55f, mAsciiPaint);

            float pillW = Math.min(w * 0.22f, 180.0f);
            float pillH = boxH * 0.38f;
            float px = w - pillW - 18.0f;

            mPanelPaint.setColor(Color.argb(215, 8, 12, 11));
            mBorderPaint.setColor(Color.rgb(180, 190, 185));
            canvas.drawRect(px, y0, px + pillW, y0 + pillH, mPanelPaint);
            canvas.drawRect(px, y0, px + pillW, y0 + pillH, mBorderPaint);
            mAsciiPaint.setTextAlign(Paint.Align.CENTER);
            mAsciiPaint.setColor(Color.rgb(235, 240, 238));
            canvas.drawText("[MENU]", px + pillW * 0.5f, y0 + pillH * 0.65f, mAsciiPaint);

            float py2 = y0 + pillH + 10.0f;
            canvas.drawRect(px, py2, px + pillW, py2 + pillH, mPanelPaint);
            canvas.drawRect(px, py2, px + pillW, py2 + pillH, mBorderPaint);
            canvas.drawText("[ZOOM]", px + pillW * 0.5f, py2 + pillH * 0.65f, mAsciiPaint);

            float py3 = py2 + pillH + 10.0f;
            mPanelPaint.setColor(mMounted ? Color.argb(225, 22, 46, 34) : Color.argb(215, 8, 12, 11));
            mBorderPaint.setColor(mMounted ? Color.rgb(180, 235, 198) : Color.rgb(180, 190, 185));
            canvas.drawRect(px, py3, px + pillW, py3 + pillH, mPanelPaint);
            canvas.drawRect(px, py3, px + pillW, py3 + pillH, mBorderPaint);
            mAsciiPaint.setColor(mMounted ? Color.rgb(210, 248, 220) : Color.rgb(235, 240, 238));
            canvas.drawText(mMounted ? "[DISMOUNT]" : "[STEED]", px + pillW * 0.5f, py3 + pillH * 0.65f, mAsciiPaint);

            // Bottom-Right Combat Buttons: [ATK] and [DODGE]
            float atkR = Math.min(w, h) * 0.088f;
            float atkCx = w - atkR - 26.0f;
            float atkCy = h - atkR - 26.0f;
            mPanelPaint.setColor(mSlashTimer > 0.0f ? Color.argb(235, 58, 92, 72) : Color.argb(215, 10, 15, 13));
            mBorderPaint.setColor(mSlashCooldown > 0.0f ? Color.rgb(130, 145, 138) : Color.rgb(225, 235, 228));
            canvas.drawCircle(atkCx, atkCy, atkR, mPanelPaint);
            canvas.drawCircle(atkCx, atkCy, atkR, mBorderPaint);
            mAsciiPaint.setTextSize(atkR * 0.42f);
            mAsciiPaint.setColor(Color.rgb(242, 246, 242));
            canvas.drawText("[ATK]", atkCx, atkCy + atkR * 0.14f, mAsciiPaint);

            float dodgeR = Math.min(w, h) * 0.070f;
            float dodgeCx = atkCx - atkR - dodgeR - 22.0f;
            float dodgeCy = h - dodgeR - 26.0f;
            mPanelPaint.setColor(mDodgeTimer > 0.0f ? Color.argb(235, 42, 92, 98) : Color.argb(215, 10, 14, 15));
            mBorderPaint.setColor(mDodgeCooldown > 0.0f ? Color.rgb(110, 125, 128) : Color.rgb(175, 230, 225));
            canvas.drawCircle(dodgeCx, dodgeCy, dodgeR, mPanelPaint);
            canvas.drawCircle(dodgeCx, dodgeCy, dodgeR, mBorderPaint);
            mAsciiPaint.setTextSize(dodgeR * 0.38f);
            mAsciiPaint.setColor(mDodgeCooldown > 0.0f ? Color.rgb(145, 160, 162) : Color.rgb(210, 245, 240));
            canvas.drawText(mDodgeCooldown > 0.0f ? String.format("%.1fs", mDodgeCooldown) : "[DODGE]", dodgeCx, dodgeCy + dodgeR * 0.14f, mAsciiPaint);

            mAsciiPaint.setTextAlign(Paint.Align.LEFT);

            if (mMovePointerId != -1) {
                mBorderPaint.setColor(Color.argb(140, 210, 230, 220));
                canvas.drawCircle(mJoyBaseX, mJoyBaseY, Math.min(w, h) * 0.11f, mBorderPaint);
                mAsciiPaint.setColor(Color.argb(200, 235, 242, 238));
                canvas.drawText("( + )", mJoyCurrX - 24, mJoyCurrY + 8, mAsciiPaint);
            }

            if (mBannerTimer > 0.0f) {
                mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                mAsciiPaint.setColor(Color.rgb(244, 240, 210));
                canvas.drawText(mStatusBanner, w * 0.5f, h * 0.94f, mAsciiPaint);
                mAsciiPaint.setTextAlign(Paint.Align.LEFT);
            }
        }

        private void drawCharacterAndLootModal(Canvas canvas, int w, int h) {
            mPanelPaint.setColor(Color.argb(242, 8, 11, 10));
            canvas.drawRect(w * 0.06f, h * 0.06f, w * 0.94f, h * 0.94f, mPanelPaint);
            mBorderPaint.setColor(Color.rgb(210, 220, 215));
            canvas.drawRect(w * 0.06f, h * 0.06f, w * 0.94f, h * 0.94f, mBorderPaint);

            float ts = Math.min(w, h) * 0.032f;
            mAsciiPaint.setTextAlign(Paint.Align.LEFT);
            mAsciiPaint.setTextSize(ts);
            mAsciiPaint.setColor(Color.rgb(240, 244, 240));
            float x0 = w * 0.10f;
            canvas.drawText("[ PILGRIM LEVELING, LOOT & CINDER FORGE ]", x0, h * 0.13f, mAsciiPaint);
            canvas.drawText("LEVEL: " + mLevel + "   XP: " + mXp + "/" + mXpNext + "   STAT PTS: " + mStatPoints, x0, h * 0.20f, mAsciiPaint);
            canvas.drawText("HP: " + mHp + "/" + mMaxHp + "   VIT:" + mVit + "  STR:" + mStr + "  DEX:" + mDex + "   GOLD:" + mGold + "g", x0, h * 0.26f, mAsciiPaint);

            mAsciiPaint.setColor(mStatPoints > 0 ? Color.rgb(160, 240, 175) : Color.rgb(140, 150, 145));
            canvas.drawText("> [TAP HERE TO SPEND STAT PT (+VIT/+STR/+DEX)]", x0, h * 0.39f, mAsciiPaint);

            int cost = 150 + mForgeLevel * 120;
            mAsciiPaint.setColor(Color.rgb(245, 205, 110));
            canvas.drawText("> [TAP HERE TO TEMPER WEAPON +" + (mForgeLevel + 1) + " (COST: " + cost + "g)]", x0, h * 0.51f, mAsciiPaint);

            mAsciiPaint.setColor(Color.rgb(220, 228, 224));
            canvas.drawText("WPN: " + mEquippedWeapon + " (+" + mForgeLevel + ")", x0, h * 0.62f, mAsciiPaint);
            canvas.drawText("ARM: " + mEquippedArmor + "   BAG: " + mInvCount + "/16", x0, h * 0.68f, mAsciiPaint);

            mAsciiPaint.setColor(Color.rgb(235, 242, 238));
            canvas.drawText("[ TAP BOTTOM TO RETURN TO WORLD ]", x0, h * 0.88f, mAsciiPaint);
        }
    }
}
