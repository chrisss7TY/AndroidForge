# Seeded world generation (added)

- `WorldGen.java`   Minecraft-style generator. Same seed = same world, infinite in every direction.
                    Elevation / moisture noise -> lakes, winding rivers, rock massifs, standing stones,
                    boulders, cottages, runestones, moonlit caves. Pure Java (no Android classes).
- `Gfx.java`        Baked art: glyph-skinned stone sprites, seamless fine-blade grass tile, wispy fog texture.
- `MainActivity.java` now generates the world from the seed. Menu has [ New World ] (random seed) and
                    Seed: <n> (tap to type a seed; numbers or any text, like Minecraft). The seed and your
                    position are saved, so relaunching returns you to the same world.

Not tested on a real device: I had no Android SDK. I compiled everything against desktop stand-ins for the
Android graphics classes and rendered frames from the real drawing code to check the look.
