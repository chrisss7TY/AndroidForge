package app.lumen

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import dev.jdtech.mpv.MPVLib
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.ln
import kotlin.math.roundToInt

data class Vid(val uri: Uri, val name: String, val file: String, val dur: Long, val h: Int)

data class Cfg(
    val theme: String = "dark", val skip: Int = 10, val speed: Float = 1f, val hide: Int = 3,
    val resume: Boolean = true, val hw: Boolean = true, val grid: Int = 160, val sort: String = "new", val autoLock: Boolean = true
) {
    fun save(sp: SharedPreferences) = sp.edit().putString("theme", theme).putInt("skip", skip).putFloat("speed", speed).putInt("hide", hide)
        .putBoolean("resume", resume).putBoolean("hw", hw).putInt("grid", grid).putString("sort", sort).putBoolean("autolock", autoLock).apply()

    companion object {
        fun load(sp: SharedPreferences) = Cfg(
            sp.getString("theme", "dark") ?: "dark", sp.getInt("skip", 10), sp.getFloat("speed", 1f), sp.getInt("hide", 3),
            sp.getBoolean("resume", true), sp.getBoolean("hw", true), sp.getInt("grid", 160), sp.getString("sort", "new") ?: "new", sp.getBoolean("autolock", true)
        )
    }
}

private class PState { @Volatile var alive = true; var loaded = false }

private val RATES = listOf(1f, 1.25f, 1.5f, 2f, .5f, .75f)
private val THUMBS = object : LruCache<Uri, ImageBitmap>((Runtime.getRuntime().maxMemory() / 8).toInt()) {
    override fun sizeOf(key: Uri, value: ImageBitmap): Int = value.asAndroidBitmap().byteCount
}
private val thumbSem = Semaphore(2)

fun fmt(s: Double) = "%d:%02d".format((s / 60).toInt(), (s % 60).toInt())

private fun loadThumb(ctx: Context, uri: Uri): ImageBitmap? {
    frameOf(ctx, uri, 720)?.let { return it.asImageBitmap() }
    if (Build.VERSION.SDK_INT >= 29) {
        try { return ctx.contentResolver.loadThumbnail(uri, Size(960, 540), null).asImageBitmap() } catch (e: Exception) { }
    }
    return null
}

@Composable fun BoxScope.Badges(h: Int, dur: Long) {
    val k = h >= 2000
    if (h > 0) Text(
        if (k) "4K" else "${h}p",
        Modifier.align(Alignment.BottomStart).padding(8.dp).clip(RoundedCornerShape(7.dp)).background(if (k) Color(0xFFFFC66B) else Color(0x99000000)).padding(horizontal = 7.dp, vertical = 3.dp),
        fontSize = 11.sp, color = if (k) Color(0xFF2B1B00) else Color.White, fontWeight = FontWeight.SemiBold
    )
    Text(
        fmt(dur / 1000.0),
        Modifier.align(Alignment.BottomEnd).padding(8.dp).clip(RoundedCornerShape(7.dp)).background(Color(0x99000000)).padding(horizontal = 7.dp, vertical = 3.dp),
        fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.SemiBold
    )
}

class MainActivity : ComponentActivity() {
    private var opened by mutableStateOf<Uri?>(null)
    private var vtick by mutableIntStateOf(0)
    private var live = false
    private var autoLock = true
    private var suppressLock = false
    private var tempPlay: File? = null
    private val vault by lazy { Vault(this) }
    private val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        @Suppress("DEPRECATION") run { window.statusBarColor = android.graphics.Color.TRANSPARENT; window.navigationBarColor = android.graphics.Color.TRANSPARENT }
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        File(cacheDir, "play").deleteRecursively()
        opened = intent?.data
        setContent { App() }
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); i.data?.let { opened = it } }

    override fun onStop() {
        super.onStop()
        if (live) MPVLib.setPropertyBoolean("pause", true)
        if (autoLock && !suppressLock && vault.unlocked) { vault.lock(); vtick++ }
    }

    override fun onDestroy() { super.onDestroy(); if (isFinishing) File(cacheDir, "play").deleteRecursively() }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private suspend fun scan(): List<Vid> = withContext(Dispatchers.IO) {
        val out = ArrayList<Vid>(); val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        contentResolver.query(base, arrayOf("_id", "_display_name", "duration", "height"), null, null, "date_added DESC")?.use {
            while (it.moveToNext()) {
                val file = it.getString(1) ?: "video.mp4"
                out += Vid(ContentUris.withAppendedId(base, it.getLong(0)), file.substringBeforeLast('.'), file, it.getLong(2), it.getInt(3))
            }
        }
        out
    }

    @Composable fun App() {
        val sp = remember { getSharedPreferences("s", 0) }
        var cfg by remember { mutableStateOf(Cfg.load(sp)) }
        var tab by remember { mutableIntStateOf(0) }
        var list by remember { mutableStateOf(listOf<Vid>()) }
        var prep by remember { mutableStateOf(false) }
        val unlocked = vtick >= 0 && vault.unlocked
        val scope = rememberCoroutineScope()
        val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) scope.launch { list = scan() } }
        val del = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { suppressLock = false; scope.launch { list = scan() } }
        LaunchedEffect(Unit) { if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) list = scan() else ask.launch(perm) }
        SideEffect { autoLock = cfg.autoLock }

        val amoled = cfg.theme == "amoled"; val light = cfg.theme == "light"
        val cs = if (!light) darkColorScheme(
            primary = Color(0xFF8FD9C9), background = if (amoled) Color.Black else Color(0xFF0A0F11),
            surface = if (amoled) Color(0xFF111213) else Color(0xFF121A1D),
            onBackground = Color(0xFFE8F0EE), onSurface = Color(0xFFE8F0EE), onSurfaceVariant = Color(0xFF9DB0AC)
        ) else lightColorScheme(
            primary = Color(0xFF17695B), background = Color(0xFFF3F7F6), surface = Color.White,
            onBackground = Color(0xFF101514), onSurface = Color(0xFF101514), onSurfaceVariant = Color(0xFF55615E)
        )
        SideEffect {
            val c = WindowInsetsControllerCompat(window, window.decorView)
            c.isAppearanceLightStatusBars = light; c.isAppearanceLightNavigationBars = light
        }
        val shown = remember(list, cfg.sort) {
            when (cfg.sort) { "name" -> list.sortedBy { it.name.lowercase() }; "dur" -> list.sortedByDescending { it.dur }; else -> list }
        }
        fun move(v: Vid) {
            if (!vault.unlocked) { tab = 1; toast("Unlock your vault first"); return }
            scope.launch {
                toast("Encrypting “${v.name}”…")
                val ok = withContext(Dispatchers.IO) { runCatching { vault.add(v.uri, v.file) }.isSuccess }
                vtick++
                if (!ok) { toast("Couldn’t add to vault"); return@launch }
                if (Build.VERSION.SDK_INT >= 30) {
                    suppressLock = true
                    del.launch(IntentSenderRequest.Builder(MediaStore.createDeleteRequest(contentResolver, listOf(v.uri)).intentSender).build())
                } else toast("Added to vault. Original kept; delete it manually.")
            }
        }
        fun playVault(v: VItem) {
            scope.launch {
                prep = true
                val f = withContext(Dispatchers.IO) { runCatching { vault.playFile(v) }.getOrNull() }
                prep = false
                if (f == null) toast("Couldn’t open video") else { tempPlay = f; opened = Uri.fromFile(f) }
            }
        }

        MaterialTheme(cs) {
            Surface(Modifier.fillMaxSize(), color = cs.background, contentColor = cs.onBackground) {
                Box(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 18.dp)) {
                        Text(when (tab) { 0 -> "Library"; 1 -> "Vault"; else -> "Settings" }, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 24.dp, bottom = 12.dp))
                        when (tab) {
                            0 -> Library(shown, cfg.grid, { opened = it }, { move(it) })
                            1 -> VaultScreen(vault, vtick, { vtick++ }, { playVault(it) }, { suppressLock = it }, { toast(it) })
                            else -> Settings(cfg, unlocked, { cfg = it; it.save(sp) }, { vault.lock(); vtick++ })
                        }
                    }
                    GlassNav(tab, listOf(Icons.Rounded.VideoLibrary to "Library", Icons.Rounded.Lock to "Vault", Icons.Rounded.Tune to "Settings"), { tab = it }, Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 14.dp))
                    opened?.let { Player(it, cfg) { opened = null; tempPlay?.delete(); tempPlay = null } }
                    if (prep) Box(Modifier.fillMaxSize().background(Color(0xAA000000)).pointerInput(Unit) { detectTapGestures { } }, contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                }
            }
        }
    }

    @Composable fun Library(list: List<Vid>, grid: Int, onOpen: (Uri) -> Unit, onVault: (Vid) -> Unit) {
        val ctx = LocalContext.current
        if (list.isEmpty()) Text("No videos found", color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyVerticalGrid(GridCells.Adaptive(grid.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(18.dp), contentPadding = PaddingValues(bottom = 120.dp)) {
            items(list, key = { it.uri }) { v ->
                val thumb by produceState<ImageBitmap?>(THUMBS.get(v.uri), v.uri) {
                    if (value == null) value = thumbSem.withPermit { withContext(Dispatchers.IO) { loadThumb(ctx, v.uri) } }?.also { THUMBS.put(v.uri, it) }
                }
                var menu by remember { mutableStateOf(false) }
                Column {
                    Box(Modifier.fillMaxWidth().aspectRatio(16 / 9f).clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface).clickable { onOpen(v.uri) }) {
                        thumb?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, filterQuality = FilterQuality.High) }
                        Badges(v.h, v.dur)
                    }
                    Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(v.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Box {
                            IconButton({ menu = true }, Modifier.size(28.dp)) { Icon(Icons.Rounded.MoreVert, null, Modifier.size(18.dp)) }
                            DropdownMenu(menu, { menu = false }) { DropdownMenuItem({ Text("Move to vault") }, { menu = false; onVault(v) }) }
                        }
                    }
                }
            }
        }
    }

    @Composable fun Settings(c: Cfg, unlocked: Boolean, upd: (Cfg) -> Unit, lockNow: () -> Unit) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 130.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionTitle("Appearance")
            Lbl("Theme"); Chips(listOf("dark" to "Dark", "amoled" to "AMOLED", "light" to "Light"), c.theme) { upd(c.copy(theme = it)) }
            Lbl("Library grid"); Chips(listOf(130 to "Compact", 160 to "Comfortable", 220 to "Large"), c.grid) { upd(c.copy(grid = it)) }
            Lbl("Sort by"); Chips(listOf("new" to "Newest", "name" to "Name", "dur" to "Longest"), c.sort) { upd(c.copy(sort = it)) }
            SectionTitle("Playback")
            Lbl("Skip interval"); Chips(listOf(5 to "5s", 10 to "10s", 15 to "15s", 30 to "30s"), c.skip) { upd(c.copy(skip = it)) }
            Lbl("Default speed"); Chips(listOf(.5f to "0.5×", 1f to "1×", 1.25f to "1.25×", 1.5f to "1.5×", 2f to "2×"), c.speed) { upd(c.copy(speed = it)) }
            Lbl("Hide controls after"); Chips(listOf(2 to "2s", 3 to "3s", 5 to "5s", 0 to "Never"), c.hide) { upd(c.copy(hide = it)) }
            SwitchRow("Resume where you left off", "Remembers the position of each video", c.resume) { upd(c.copy(resume = it)) }
            SwitchRow("Hardware decoding first", "Falls back to software for 4K the phone can't decode", c.hw) { upd(c.copy(hw = it)) }
            SectionTitle("Vault")
            SwitchRow("Auto-lock when you leave the app", "Asks for your password again next time", c.autoLock) { upd(c.copy(autoLock = it)) }
            if (unlocked) OutlinedButton(lockNow) { Text("Lock vault now") }
        }
    }

    @Composable fun SectionTitle(t: String) = Text(t.uppercase(), Modifier.padding(top = 12.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, letterSpacing = 1.sp)
    @Composable fun Lbl(t: String) = Text(t, fontWeight = FontWeight.SemiBold)

    @Composable fun <T> Chips(opts: List<Pair<T, String>>, sel: T, set: (T) -> Unit) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            opts.forEach { (k, n) -> FilterChip(sel == k, { set(k) }, { Text(n) }) }
        }
    }

    @Composable fun SwitchRow(title: String, sub: String, on: Boolean, set: (Boolean) -> Unit) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            Switch(on, set)
        }
    }

    @Composable fun Player(uri: Uri, cfg: Cfg, onClose: () -> Unit) {
        val ctx = LocalContext.current; val sp = remember { ctx.getSharedPreferences("s", 0) }
        val st = remember(uri) { PState() }
        var ready by remember(uri) { mutableStateOf(false) }
        var pos by remember { mutableDoubleStateOf(0.0) }; var dur by remember { mutableDoubleStateOf(1.0) }
        var paused by remember { mutableStateOf(false) }; var ui by remember { mutableStateOf(true) }
        var zoom by remember { mutableFloatStateOf(1f) }; var px by remember { mutableFloatStateOf(0f) }; var py by remember { mutableFloatStateOf(0f) }
        var w by remember { mutableIntStateOf(1) }; var speed by remember { mutableFloatStateOf(cfg.speed) }; var drag by remember { mutableStateOf<Float?>(null) }
        val posNow by rememberUpdatedState(pos); val durNow by rememberUpdatedState(dur)
        val skip = cfg.skip

        fun openFile() {
            val target = if (uri.scheme == "file") uri.path!! else {
                val fd = ctx.contentResolver.openFileDescriptor(uri, "r")?.detachFd()
                if (fd != null) "fd://$fd" else uri.toString()
            }
            MPVLib.command(arrayOf("loadfile", target))
        }

        DisposableEffect(uri) {
            live = true; window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            val bars = WindowInsetsControllerCompat(window, window.decorView)
            bars.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE; bars.hide(WindowInsetsCompat.Type.systemBars())
            MPVLib.create(ctx)
            mapOf("profile" to "fast", "vo" to "gpu", "gpu-context" to "android", "opengl-es" to "yes",
                "hwdec" to (if (cfg.hw) "mediacodec,mediacodec-copy" else "no"), "hwdec-codecs" to "all",
                "vd-lavc-threads" to Runtime.getRuntime().availableProcessors().toString(), "vd-lavc-skiploopfilter" to "nonref", "vd-lavc-fast" to "yes", "vd-lavc-dr" to "yes",
                "framedrop" to "vo", "video-sync" to "audio", "cache" to "yes", "demuxer-max-bytes" to "64MiB", "demuxer-readahead-secs" to "20",
                "ao" to "audiotrack,opensles", "keep-open" to "yes", "speed" to cfg.speed.toString()).forEach { (k, v) -> MPVLib.setOptionString(k, v) }
            if (cfg.resume) { val last = sp.getFloat("p:$uri", 0f); if (last > 5f) MPVLib.setOptionString("start", last.toString()) }
            MPVLib.init()
            ready = true   // the SurfaceView is only created now; the file is loaded once its surface exists
            onDispose {
                st.alive = false
                sp.edit().apply { if (posNow > 5 && posNow < durNow - 10) putFloat("p:$uri", posNow.toFloat()) else remove("p:$uri") }.apply()
                live = false; window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); bars.show(WindowInsetsCompat.Type.systemBars())
                MPVLib.command(arrayOf("stop")); MPVLib.detachSurface(); MPVLib.destroy()
            }
        }
        // Only poll while the controls are visible: no recomposition during plain playback
        LaunchedEffect(ui, ready) {
            while (ui && ready && st.alive) {
                if (drag == null) pos = MPVLib.getPropertyDouble("time-pos") ?: pos
                dur = MPVLib.getPropertyDouble("duration") ?: dur
                paused = MPVLib.getPropertyBoolean("pause") ?: false
                delay(250)
            }
        }
        LaunchedEffect(ui, paused) { if (ui && !paused && cfg.hide > 0) { delay(cfg.hide * 1000L); ui = false } }
        fun seek(s: Int) = MPVLib.command(arrayOf("seek", s.toString(), "relative"))
        fun applyZoom() { MPVLib.setPropertyDouble("video-zoom", ln(zoom.toDouble()) / ln(2.0)); MPVLib.setPropertyDouble("video-pan-x", (px / w).toDouble()); MPVLib.setPropertyDouble("video-pan-y", (py / w).toDouble()) }
        BackHandler(onBack = onClose)
        Box(Modifier.fillMaxSize().background(Color.Black).onSizeChanged { w = it.width.coerceAtLeast(1) }
            .pointerInput(Unit) { detectTransformGestures { _, pan, z, _ ->
                val nz = (zoom * z).coerceIn(1f, 6f)
                if (nz > 1f) { px += pan.x; py += pan.y } else { px = 0f; py = 0f }
                if (nz != zoom || nz > 1f) { zoom = nz; applyZoom() } } }
            .pointerInput(skip) { detectTapGestures(onDoubleTap = { seek(if (it.x < size.width / 2) -skip else skip) }, onTap = { ui = !ui }) }) {
            if (ready) AndroidView({ c -> SurfaceView(c).apply { holder.addCallback(object : SurfaceHolder.Callback {
                override fun surfaceCreated(h: SurfaceHolder) {
                    if (!st.alive) return
                    MPVLib.attachSurface(h.surface)
                    MPVLib.setOptionString("force-window", "yes")
                    if (!st.loaded) { st.loaded = true; openFile() } else MPVLib.setPropertyString("vo", "gpu")
                }
                override fun surfaceChanged(h: SurfaceHolder, f: Int, a: Int, b: Int) { if (st.alive) MPVLib.setPropertyString("android-surface-size", "${a}x$b") }
                override fun surfaceDestroyed(h: SurfaceHolder) {
                    if (!st.alive) return
                    MPVLib.setPropertyString("vo", "null"); MPVLib.setOptionString("force-window", "no"); MPVLib.detachSurface()
                } }) } }, Modifier.fillMaxSize())
            if (ui) Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x99000000), Color.Transparent, Color(0xB3000000)))).statusBarsPadding().navigationBarsPadding().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
                IconButton(onClose) { Icon(Icons.Rounded.ArrowBackIosNew, null, tint = Color.White) }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ seek(-skip) }) { Icon(Icons.Rounded.Replay10, null, tint = Color.White, modifier = Modifier.size(36.dp)) }
                    Spacer(Modifier.width(24.dp))
                    FilledIconButton({ MPVLib.setPropertyBoolean("pause", !paused); paused = !paused }, Modifier.size(76.dp), colors = IconButtonDefaults.filledIconButtonColors(Color.White, Color.Black)) { Icon(if (paused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause, null, Modifier.size(40.dp)) }
                    Spacer(Modifier.width(24.dp))
                    IconButton({ seek(skip) }) { Icon(Icons.Rounded.Forward10, null, tint = Color.White, modifier = Modifier.size(36.dp)) }
                }
                Column {
                    // Scrub on keyframes (instant), land exactly on release
                    Slider(drag ?: (pos / dur).toFloat().coerceIn(0f, 1f), { drag = it; MPVLib.command(arrayOf("seek", (it * dur).toString(), "absolute+keyframes")) },
                        onValueChangeFinished = { drag?.let { MPVLib.command(arrayOf("seek", (it * dur).toString(), "absolute+exact")) }; drag = null })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${fmt(pos)} / ${fmt(dur)}", color = Color.White, fontSize = 12.sp); Spacer(Modifier.weight(1f))
                        TextButton({ speed = RATES[(RATES.indexOf(speed) + 1) % RATES.size]; MPVLib.setPropertyDouble("speed", speed.toDouble()) }) { Text("${speed}×", color = Color.White) }
                    }
                }
            }
        }
    }
}

/** Glass tab bar: hold and drag the lens. Critically damped springs, so no bounce. */
@Composable fun GlassNav(sel: Int, tabs: List<Pair<ImageVector, String>>, onSel: (Int) -> Unit, m: Modifier) {
    val itemW = 96.dp; val iw = with(LocalDensity.current) { itemW.toPx() }
    val x = remember { Animatable(sel * iw) }; val sx = remember { Animatable(1f) }; val sy = remember { Animatable(1f) }
    val scope = rememberCoroutineScope()
    var held by remember { mutableStateOf(false) }; var hot by remember { mutableIntStateOf(sel) }
    val spPos = spring<Float>(dampingRatio = 1f, stiffness = 120f); val spScale = spring<Float>(dampingRatio = 0.9f, stiffness = 260f)
    val cs = MaterialTheme.colorScheme
    LaunchedEffect(sel, held) { if (!held) x.animateTo(sel * iw, spPos) }
    Box(m.clip(RoundedCornerShape(50)).background(cs.surface.copy(alpha = .9f)).border(1.dp, cs.onSurface.copy(.14f), RoundedCornerShape(50)).padding(6.dp)
        .pointerInput(tabs.size) { awaitEachGesture {
            val down = awaitFirstDown(); held = true; var last = -1f
            fun go(px: Float) { val t = (px - iw / 2).coerceIn(0f, iw * (tabs.size - 1)); hot = (t / iw).roundToInt(); if (kotlin.math.abs(t - last) > 1f) { last = t; scope.launch { x.animateTo(t, spPos) } } }
            scope.launch { sx.animateTo(1.08f, spScale) }; scope.launch { sy.animateTo(1.12f, spScale) }; go(down.position.x)
            do { val e = awaitPointerEvent(); e.changes.firstOrNull()?.let { c -> go(c.position.x); c.consume() } } while (e.changes.any { it.pressed })
            held = false; val t = hot; scope.launch { sx.animateTo(1f, spScale) }; scope.launch { sy.animateTo(1f, spScale) }; onSel(t)
        } }) {
        Box(Modifier.offset { IntOffset(x.value.roundToInt(), 0) }.size(itemW, 52.dp).graphicsLayer { scaleX = sx.value; scaleY = sy.value }
            .clip(RoundedCornerShape(50)).background(cs.primary.copy(if (held) .30f else .20f)))
        Row { tabs.forEachIndexed { i, (ic, n) -> Column(Modifier.size(itemW, 52.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            val on = i == (if (held) hot else sel)
            Icon(ic, n, Modifier.size(22.dp).graphicsLayer { val s = if (held && hot == i) 1.12f else 1f; scaleX = s; scaleY = s }, tint = if (on) cs.onSurface else cs.onSurfaceVariant)
            Text(n, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = if (on) cs.onSurface else cs.onSurfaceVariant) } } }
    }
}
