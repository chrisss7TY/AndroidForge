package app.lumen

import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.TransferListener
import java.io.IOException

/** Feeds ExoPlayer straight from the decrypted VeraCrypt stream (nothing is written to disk). */
@UnstableApi
class VcDataSource : BaseDataSource(false) {
    private var src: ByteSrc? = null
    private var u: Uri? = null
    private var pos = 0L
    private var end = 0L

    override fun open(dataSpec: DataSpec): Long {
        u = dataSpec.uri
        val s = Streams.m[dataSpec.uri.host ?: ""] ?: throw IOException("Vault stream is gone")
        transferInitializing(dataSpec)
        src = s; pos = dataSpec.position
        end = if (dataSpec.length == C.LENGTH_UNSET.toLong()) s.length else minOf(s.length, pos + dataSpec.length)
        transferStarted(dataSpec)
        return end - pos
    }
    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        val s = src ?: return C.RESULT_END_OF_INPUT
        if (pos >= end) return C.RESULT_END_OF_INPUT
        val r = s.read(pos, buffer, offset, minOf(length.toLong(), end - pos).toInt())
        if (r <= 0) return C.RESULT_END_OF_INPUT
        pos += r; bytesTransferred(r); return r
    }
    override fun getUri(): Uri? = u
    override fun close() { if (src != null) { src = null; transferEnded() } }
}

@UnstableApi
private class RouteDS(private val def: DataSource, private val vc: VcDataSource) : DataSource {
    private var cur: DataSource = def
    override fun addTransferListener(l: TransferListener) { def.addTransferListener(l); vc.addTransferListener(l) }
    override fun open(dataSpec: DataSpec): Long { cur = if (dataSpec.uri.scheme == "lumenvc") vc else def; return cur.open(dataSpec) }
    override fun read(buffer: ByteArray, offset: Int, length: Int): Int = cur.read(buffer, offset, length)
    override fun getUri(): Uri? = cur.uri
    override fun close() = cur.close()
}

@UnstableApi
fun routedDataSourceFactory(ctx: android.content.Context): DataSource.Factory =
    DataSource.Factory { RouteDS(DefaultDataSource.Factory(ctx).createDataSource(), VcDataSource()) }
