package app.lumen

import android.content.Context
import android.media.MediaCodecList
import android.media.MediaDataSource
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.Build

/** True only if a real HARDWARE decoder supports this exact video track (codec, profile/bit depth, size, frame rate). */
fun hwCanDecode(ctx: Context, uri: Uri): Boolean {
    val ex = MediaExtractor()
    return try {
        if (uri.scheme == "lumenvc") {
            val s = Streams.m[uri.host ?: ""] ?: return true
            ex.setDataSource(object : MediaDataSource() {
                override fun readAt(p: Long, b: ByteArray, o: Int, n: Int) = s.read(p, b, o, n)
                override fun getSize() = s.length
                override fun close() {}
            })
        } else ex.setDataSource(ctx, uri, null)
        var ok = true
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (!mime.startsWith("video/")) continue
            ok = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { ci ->
                !ci.isEncoder && ci.supportedTypes.any { it.equals(mime, true) } &&
                    (Build.VERSION.SDK_INT < 29 || ci.isHardwareAccelerated) &&
                    !ci.name.startsWith("OMX.google") && !ci.name.startsWith("c2.android") &&
                    runCatching { ci.getCapabilitiesForType(mime).isFormatSupported(f) }.getOrDefault(false)
            }
            break
        }
        ok
    } catch (e: Throwable) { true } finally { runCatching { ex.release() } }
}
