package app.lumen

import android.content.Context
import android.net.Uri
import android.util.LruCache
import java.io.Closeable
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

interface ByteSrc { val length: Long; val mime: String; fun read(pos: Long, buf: ByteArray, off: Int, len: Int): Int }
object Streams { val m = java.util.concurrent.ConcurrentHashMap<String, ByteSrc>() }

private fun u16(b: ByteArray, o: Int) = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)
private fun u32(b: ByteArray, o: Int) = u16(b, o).toLong() or (u16(b, o + 2).toLong() shl 16)
private fun u64(b: ByteArray, o: Int) = u32(b, o) or (u32(b, o + 4) shl 32)

/** Random-access decrypting reader over a VeraCrypt XTS-AES volume. Offsets are relative to the start of the data area. */
class VolIO(ctx: Context, uri: Uri, mk1: ByteArray, mk2: ByteArray, private val dataStart: Long) : Closeable {
    private val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: throw java.io.IOException("open failed")
    private val ch = FileInputStream(pfd.fileDescriptor).channel
    private val dec = Cipher.getInstance("AES/ECB/NoPadding").apply { init(Cipher.DECRYPT_MODE, SecretKeySpec(mk1, "AES")) }
    private val twk = Cipher.getInstance("AES/ECB/NoPadding").apply { init(Cipher.ENCRYPT_MODE, SecretKeySpec(mk2, "AES")) }

    @Synchronized
    fun read(volOff: Long, out: ByteArray, o: Int, len: Int): Int {
        if (len <= 0 || volOff < 0) return 0
        val s = volOff / 512
        val n = (((volOff + len + 511) / 512 - s) * 512).toInt()
        val raw = ByteArray(n); val bb = ByteBuffer.wrap(raw); var got = 0
        while (got < n) { bb.position(got); val r = ch.read(bb, dataStart + s * 512 + got); if (r <= 0) break; got += r }
        val units = got / 512; if (units == 0) return 0
        val bytes = units * 512
        val le = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN)
        val tw = LongArray(units * 64); val seed = ByteBuffer.allocate(16).order(ByteOrder.LITTLE_ENDIAN)
        for (u in 0 until units) {
            seed.putLong(0, dataStart / 512 + s + u).putLong(8, 0L)
            val tb = ByteBuffer.wrap(twk.doFinal(seed.array())).order(ByteOrder.LITTLE_ENDIAN)
            var lo = tb.getLong(0); var hi = tb.getLong(8)
            for (b in 0 until 32) {
                val p = u * 512 + b * 16; val k = (u * 32 + b) * 2
                tw[k] = lo; tw[k + 1] = hi
                le.putLong(p, le.getLong(p) xor lo); le.putLong(p + 8, le.getLong(p + 8) xor hi)
                val c = hi ushr 63
                hi = (hi shl 1) or (lo ushr 63); lo = (lo shl 1) xor (c * 0x87L)
            }
        }
        System.arraycopy(dec.doFinal(raw, 0, bytes), 0, raw, 0, bytes)
        for (u in 0 until units) for (b in 0 until 32) {
            val p = u * 512 + b * 16; val k = (u * 32 + b) * 2
            le.putLong(p, le.getLong(p) xor tw[k]); le.putLong(p + 8, le.getLong(p + 8) xor tw[k + 1])
        }
        val inner = (volOff - s * 512).toInt()
        val m = minOf(len, bytes - inner); if (m <= 0) return 0
        System.arraycopy(raw, inner, out, o, m); return m
    }
    override fun close() { runCatching { ch.close() }; runCatching { pfd.close() } }
}

class VcNode(val name: String, val path: String, val isDir: Boolean, val size: Long, val cluster: Long, val contiguous: Boolean) {
    val ext = name.substringAfterLast('.', "").lowercase()
    val kind: Int get() = if (isDir) 0 else if (ext in IMG) 1 else if (ext in VID) 2 else 3
    companion object {
        val IMG = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif")
        val VID = setOf("mp4", "mkv", "webm", "mov", "avi", "m4v", "ts", "3gp", "flv", "wmv", "mpg", "mpeg")
    }
}

fun mimeOf(ext: String) = when (ext) {
    "mp4", "m4v" -> "video/mp4"; "mkv" -> "video/x-matroska"; "webm" -> "video/webm"; "mov" -> "video/quicktime"
    "avi" -> "video/x-msvideo"; "3gp" -> "video/3gpp"; "ts" -> "video/mp2t"; "jpg", "jpeg" -> "image/jpeg"; "png" -> "image/png"
    "webp" -> "image/webp"; "gif" -> "image/gif"; "pdf" -> "application/pdf"; "txt" -> "text/plain"; else -> "application/octet-stream"
}

/** Lazy FAT16 / FAT32 / exFAT directory + file reader. */
class VcFs(private val io: VolIO, boot: ByteArray, base: Long) {
    val exfat = String(boot, 3, 8, Charsets.US_ASCII).startsWith("EXFAT")
    private val cs: Int; private val fatOff: Long; private val dataOff: Long; private val root: Long
    private var fat32 = false; private var rootOff = 0L; private var rootLen = 0
    private val fatCache = LruCache<Long, ByteArray>(64)
    private val kids = HashMap<String, List<VcNode>>()
    private val chains = LruCache<String, LongArray>(16)

    init {
        if (exfat) {
            val bps = 1 shl (boot[108].toInt() and 0xFF)
            cs = bps * (1 shl (boot[109].toInt() and 0xFF))
            fatOff = base + u32(boot, 80) * bps; dataOff = base + u32(boot, 88) * bps; root = u32(boot, 96)
        } else {
            val bps = u16(boot, 11); cs = bps * (boot[13].toInt() and 0xFF)
            val res = u16(boot, 14); val nf = boot[16].toInt() and 0xFF; val ents = u16(boot, 17)
            fat32 = u16(boot, 22) == 0
            val fsz = if (fat32) u32(boot, 36) else u16(boot, 22).toLong()
            fatOff = base + res.toLong() * bps
            rootOff = base + (res + nf * fsz) * bps; rootLen = ents * 32
            dataOff = rootOff + ((ents * 32 + bps - 1) / bps).toLong() * bps
            root = if (fat32) u32(boot, 44) else 0L
        }
    }

    private fun isEnd(v: Long) = v < 2 || v >= (if (exfat) 0xFFFFFFF7L else if (fat32) 0x0FFFFFF7L else 0xFFF7L)
    private fun next(c: Long): Long {
        val w = if (exfat || fat32) 4 else 2; val pos = c * w; val blk = pos / 4096
        val b = fatCache.get(blk) ?: ByteArray(4096).also { io.read(fatOff + blk * 4096, it, 0, 4096); fatCache.put(blk, it) }
        val o = (pos % 4096).toInt()
        return if (w == 4) u32(b, o) and (if (exfat) 0xFFFFFFFFL else 0x0FFFFFFFL) else u16(b, o).toLong()
    }
    private fun chainEnd(first: Long): LongArray {
        val l = ArrayList<Long>(); var c = first
        while (!isEnd(c) && l.size < 1_000_000) { l.add(c); c = next(c) }
        return l.toLongArray()
    }
    private fun chain(first: Long, contiguous: Boolean, size: Long): LongArray {
        val n = ((size + cs - 1) / cs).toInt().coerceAtMost(4_000_000)
        if (n <= 0) return LongArray(0)
        if (contiguous) return LongArray(n) { first + it }
        val out = LongArray(n); var c = first; var i = 0
        while (i < n && !isEnd(c)) { out[i++] = c; c = next(c) }
        return if (i == n) out else out.copyOf(i)
    }
    private fun readChain(ch: LongArray, size: Long, pos: Long, buf: ByteArray, off: Int, len: Int): Int {
        var rem = minOf(len.toLong(), size - pos).toInt(); if (rem <= 0) return -1
        var p = pos; var o = off; var total = 0
        while (rem > 0) {
            val ci = (p / cs).toInt(); if (ci >= ch.size) break
            var run = 1
            while (ci + run < ch.size && ch[ci + run] == ch[ci] + run && run.toLong() * cs < rem + cs) run++
            val inner = (p % cs).toInt(); val want = minOf(rem, run * cs - inner)
            val n = io.read(dataOff + (ch[ci] - 2) * cs + inner, buf, o, want)
            if (n <= 0) break
            p += n; o += n; rem -= n; total += n
        }
        return if (total == 0) -1 else total
    }
    private fun dirData(n: VcNode?): ByteArray {
        if (n == null && !exfat && !fat32) { val b = ByteArray(rootLen); io.read(rootOff, b, 0, rootLen); return b }
        val ch = if (n == null) chainEnd(root) else if (exfat && n.size > 0) chain(n.cluster, n.contiguous, n.size) else chainEnd(n.cluster)
        val out = ByteArray(ch.size * cs)
        for (i in ch.indices) io.read(dataOff + (ch[i] - 2) * cs, out, i * cs, cs)
        return out
    }

    @Synchronized
    fun children(n: VcNode?): List<VcNode> = kids.getOrPut(n?.path ?: "") {
        val d = dirData(n); val p = n?.path ?: ""
        (if (exfat) parseEx(d, p) else parseFat(d, p)).filter { n != null || (it.name != "System Volume Information" && !it.name.startsWith("\$RECYCLE")) }
    }

    private fun parseFat(d: ByteArray, parent: String): List<VcNode> {
        val out = ArrayList<VcNode>(); val lfn = ArrayList<String>(); var i = 0
        while (i + 32 <= d.size) {
            val b0 = d[i].toInt() and 0xFF; if (b0 == 0) break
            val attr = d[i + 11].toInt() and 0xFF
            if (b0 == 0xE5 || (attr and 0x08) != 0 && attr != 0x0F) { lfn.clear(); i += 32; continue }
            if (attr == 0x0F) {
                val sb = StringBuilder()
                for (o in intArrayOf(1, 3, 5, 7, 9, 14, 16, 18, 20, 22, 24, 28, 30)) { val c = u16(d, i + o); if (c == 0 || c == 0xFFFF) break; sb.append(c.toChar()) }
                lfn.add(0, sb.toString()); i += 32; continue
            }
            val name = if (lfn.isNotEmpty()) lfn.joinToString("") else {
                val bn = String(d, i, 8, Charsets.ISO_8859_1).trimEnd(); val ex = String(d, i + 8, 3, Charsets.ISO_8859_1).trimEnd()
                if (ex.isEmpty()) bn else "$bn.$ex"
            }
            lfn.clear()
            if (name != "." && name != "..") {
                val cl = (u16(d, i + 20).toLong() shl 16) or u16(d, i + 26).toLong(); val dir = (attr and 0x10) != 0
                out += VcNode(name, "$parent/$name", dir, if (dir) 0L else u32(d, i + 28), cl, false)
            }
            i += 32
        }
        return out
    }

    private fun parseEx(d: ByteArray, parent: String): List<VcNode> {
        val out = ArrayList<VcNode>(); var i = 0
        while (i + 32 <= d.size) {
            val t = d[i].toInt() and 0xFF; if (t == 0) break
            if (t == 0x85 && i + 64 <= d.size) {
                val sec = d[i + 1].toInt() and 0xFF; val attr = u16(d, i + 4); val sp = i + 32
                if ((d[sp].toInt() and 0xFF) == 0xC0) {
                    val flags = d[sp + 1].toInt() and 0xFF; val nl = d[sp + 3].toInt() and 0xFF
                    val fc = u32(d, sp + 20); val len = u64(d, sp + 24)
                    val sb = StringBuilder(); var fi = sp + 32; var rem = nl
                    while (rem > 0 && fi + 32 <= d.size && (d[fi].toInt() and 0xFF) == 0xC1) {
                        for (c in 0 until minOf(15, rem)) { val ch = u16(d, fi + 2 + c * 2); if (ch != 0) sb.append(ch.toChar()) }
                        rem -= 15; fi += 32
                    }
                    val name = sb.toString()
                    if (name.isNotEmpty()) out += VcNode(name, "$parent/$name", (attr and 0x10) != 0, len, fc, (flags and 2) != 0)
                }
                i += (1 + sec) * 32; continue
            }
            i += 32
        }
        return out
    }

    fun open(n: VcNode, mt: String): ByteSrc {
        val ch = chains.get(n.path) ?: chain(n.cluster, n.contiguous, n.size).also { chains.put(n.path, it) }
        return object : ByteSrc {
            override val length = n.size
            override val mime = mt
            override fun read(pos: Long, buf: ByteArray, off: Int, len: Int) = readChain(ch, n.size, pos, buf, off, len)
        }
    }
    fun readAll(n: VcNode, max: Int): ByteArray? {
        if (n.size <= 0 || n.size > max) return null
        val s = open(n, ""); val b = ByteArray(n.size.toInt()); var p = 0
        while (p < b.size) { val r = s.read(p.toLong(), b, p, b.size - p); if (r <= 0) break; p += r }
        return if (p == b.size) b else b.copyOf(p)
    }
}

class VcMount(val info: VcContainerInfo, val hashLabel: String, val io: VolIO, val fs: VcFs?) : Closeable {
    override fun close() = io.close()
}

fun mountVolume(ctx: Context, info: VcContainerInfo, label: String, mk1: ByteArray, mk2: ByteArray, mkOffset: Long): VcMount? {
    val io = runCatching { VolIO(ctx, Uri.parse(info.uriString), mk1, mk2, mkOffset) }.getOrNull() ?: return null
    fun sig(b: ByteArray) = (b[510].toInt() and 0xFF) == 0x55 && (b[511].toInt() and 0xFF) == 0xAA
    fun isFs(b: ByteArray) = String(b, 3, 8, Charsets.US_ASCII).startsWith("EXFAT") ||
        (sig(b) && u16(b, 11) in intArrayOf(512, 1024, 2048, 4096) && Integer.bitCount(b[13].toInt() and 0xFF) == 1)
    var boot = ByteArray(512); io.read(0, boot, 0, 512); var base = 0L
    if (!isFs(boot) && sig(boot)) {
        val lba = u32(boot, 454)
        if (lba > 0) { val b2 = ByteArray(512); io.read(lba * 512, b2, 0, 512); if (isFs(b2)) { boot = b2; base = lba * 512 } }
    }
    val fs = if (isFs(boot)) runCatching { VcFs(io, boot, base) }.getOrNull() else null
    return VcMount(info, label, io, fs)
}
