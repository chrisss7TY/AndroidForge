package app.lumen

import android.annotation.SuppressLint
import android.net.Uri
import android.webkit.*
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import java.io.BufferedInputStream
import java.io.FileInputStream
import java.io.InputStream

private class SrcStream(val src: ByteSrc, var pos: Long, val end: Long) : InputStream() {
    override fun read(): Int { val b = ByteArray(1); return if (read(b, 0, 1) <= 0) -1 else b[0].toInt() and 0xFF }
    override fun read(b: ByteArray, o: Int, l: Int): Int {
        if (pos >= end) return -1
        val r = src.read(pos, b, o, minOf(l.toLong(), end - pos).toInt()); if (r > 0) pos += r; return r
    }
}

private class Lim(val ins: InputStream, var left: Long, val done: () -> Unit) : InputStream() {
    override fun read(): Int { if (left <= 0) return -1; val r = ins.read(); if (r >= 0) left--; return r }
    override fun read(b: ByteArray, o: Int, l: Int): Int {
        if (left <= 0) return -1
        val r = ins.read(b, o, minOf(l.toLong(), left).toInt()); if (r > 0) left -= r; return r
    }
    override fun close() { runCatching { ins.close() }; done() }
}

/**
 * Plays through Chromium's media pipeline (the same one your HTML version used):
 * hardware decode when it fits, multithreaded FFmpeg software decode when it doesn't.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebScreen(uri: Uri, cfg: Cfg, onFail: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val sp = remember { ctx.getSharedPreferences("s", 0) }
    val failCb by rememberUpdatedState(onFail)
    var pos by remember { mutableDoubleStateOf(0.0) }; var dur by remember { mutableDoubleStateOf(1.0) }
    var paused by remember { mutableStateOf(false) }; var ui by remember { mutableStateOf(true) }
    var drag by remember { mutableStateOf<Float?>(null) }
    val posNow by rememberUpdatedState(pos); val durNow by rememberUpdatedState(dur)
    val skip = cfg.skip
    val start = remember { if (cfg.resume) sp.getFloat("p:$uri", 0f) else 0f }
    val mime = remember { if (uri.scheme == "lumenvc") "video/mp4" else ctx.contentResolver.getType(uri) ?: "video/mp4" }
    val wv = remember { WebView(ctx) }
    fun js(s: String) = wv.evaluateJavascript(s, null)

    DisposableEffect(Unit) {
        onDispose {
            sp.edit().apply { if (durNow > 0 && posNow > 5 && posNow < durNow - 10) putFloat("p:$uri", posNow.toFloat()) else remove("p:$uri") }.apply()
            wv.loadUrl("about:blank"); wv.destroy()
        }
    }
    LaunchedEffect(ui) {
        while (ui) {
            wv.evaluateJavascript("v.currentTime+','+(v.duration||0)+','+v.paused") { s ->
                val p = s?.trim('"')?.split(',')
                if (p != null && p.size == 3) {
                    if (drag == null) pos = p[0].toDoubleOrNull() ?: pos
                    dur = (p[1].toDoubleOrNull() ?: dur).coerceAtLeast(0.1); paused = p[2] == "true"
                }
            }
            delay(250)
        }
    }
    LaunchedEffect(ui, paused) { if (ui && !paused && cfg.hide > 0) { delay(cfg.hide * 1000L); ui = false } }
    BackHandler(onBack = onClose)

    val html = remember {
        """<!DOCTYPE html><html><body style="margin:0;background:#000;overflow:hidden"><video id="v" src="https://lumen.local/v" autoplay playsinline preload="auto" style="position:fixed;inset:0;width:100%;height:100%;object-fit:contain;background:#000"></video><script>var v=document.getElementById('v');v.onloadedmetadata=function(){if($start>0)v.currentTime=$start;v.playbackRate=${cfg.speed}};v.onerror=function(){L.fail()};</script></body></html>"""
    }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(factory = {
            wv.apply {
                keepScreenOn = true; setBackgroundColor(android.graphics.Color.BLACK)
                settings.javaScriptEnabled = true; settings.mediaPlaybackRequiresUserGesture = false
                addJavascriptInterface(object { @JavascriptInterface fun fail() { wv.post { failCb() } } }, "L")
                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(view: WebView, r: WebResourceRequest): WebResourceResponse? {
                        if (r.url.path != "/v") return null
                        val vs = if (uri.scheme == "lumenvc") Streams.m[uri.host ?: ""] else null
                        if (vs != null) {
                            val len = vs.length
                            val m = Regex("bytes=(\\d*)-(\\d*)").find(r.requestHeaders["Range"] ?: "")
                            val s = m?.groupValues?.get(1)?.toLongOrNull() ?: 0L
                            val e = (m?.groupValues?.get(2)?.toLongOrNull() ?: (len - 1)).coerceAtMost(len - 1)
                            val h = mutableMapOf("Accept-Ranges" to "bytes", "Content-Length" to "${e - s + 1}", "Access-Control-Allow-Origin" to "*")
                            if (m != null) h["Content-Range"] = "bytes $s-$e/$len"
                            return WebResourceResponse(vs.mime, null, if (m != null) 206 else 200, if (m != null) "Partial Content" else "OK", h,
                                BufferedInputStream(SrcStream(vs, s, e + 1), 1 shl 20))
                        }
                        val pfd = runCatching { ctx.contentResolver.openFileDescriptor(uri, "r") }.getOrNull() ?: return null
                        val len = pfd.statSize
                        val m = Regex("bytes=(\\d*)-(\\d*)").find(r.requestHeaders["Range"] ?: "")
                        val s = m?.groupValues?.get(1)?.toLongOrNull() ?: 0L
                        val e = m?.groupValues?.get(2)?.toLongOrNull() ?: (len - 1)
                        val fis = FileInputStream(pfd.fileDescriptor).also { it.channel.position(s) }
                        val h = mutableMapOf("Accept-Ranges" to "bytes", "Content-Length" to "${e - s + 1}", "Access-Control-Allow-Origin" to "*")
                        if (m != null) h["Content-Range"] = "bytes $s-$e/$len"
                        return WebResourceResponse(mime, null, if (m != null) 206 else 200, if (m != null) "Partial Content" else "OK", h,
                            Lim(BufferedInputStream(fis, 1 shl 20), e - s + 1) { runCatching { pfd.close() } })
                    }
                }
                loadDataWithBaseURL("https://lumen.local/", html, "text/html", "utf-8", null)
            }
        }, modifier = Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().pointerInput(skip) {
            detectTapGestures(onDoubleTap = { js("v.currentTime+=${if (it.x < size.width / 2) -skip else skip}") }, onTap = { ui = !ui })
        })
        if (ui) Column(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x99000000), Color.Transparent, Color(0xB3000000))))
                .statusBarsPadding().navigationBarsPadding().padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClose) { Icon(Icons.Rounded.ArrowBackIosNew, null, tint = Color.White) }
            Row(Modifier.fillMaxWidth(), Arrangement.Center, Alignment.CenterVertically) {
                IconButton({ js("v.currentTime-=$skip") }) { Icon(Icons.Rounded.Replay10, null, tint = Color.White, modifier = Modifier.size(36.dp)) }
                Spacer(Modifier.width(24.dp))
                FilledIconButton({ js("v.paused?v.play():v.pause()"); paused = !paused }, Modifier.size(76.dp), colors = IconButtonDefaults.filledIconButtonColors(Color.White, Color.Black)) {
                    Icon(if (paused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause, null, Modifier.size(40.dp))
                }
                Spacer(Modifier.width(24.dp))
                IconButton({ js("v.currentTime+=$skip") }) { Icon(Icons.Rounded.Forward10, null, tint = Color.White, modifier = Modifier.size(36.dp)) }
            }
            Column {
                Slider(drag ?: (pos / dur).toFloat().coerceIn(0f, 1f), { drag = it; js("v.currentTime=${it * dur}") }, onValueChangeFinished = { drag = null })
                Text("${fmt(pos)} / ${fmt(dur)}", color = Color.White, fontSize = 12.sp)
            }
        }
    }
}
