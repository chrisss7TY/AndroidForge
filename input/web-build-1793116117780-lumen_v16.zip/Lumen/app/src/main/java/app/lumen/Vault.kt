package app.lumen

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaDataSource
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.DocumentsContract
import android.util.LruCache
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.util.concurrent.Executors

/** Saved VeraCrypt containers plus the one currently mounted. No local vault: this only opens VeraCrypt volumes. */
class Vault(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("vcs", 0)
    var containers by mutableStateOf(readList()); private set
    var mounted by mutableStateOf<VcMount?>(null); private set
    val unlocked: Boolean get() = mounted != null

    private fun readList(): List<VcContainerInfo> = runCatching {
        val a = JSONArray(sp.getString("list", "[]"))
        (0 until a.length()).map { val o = a.getJSONObject(it); VcContainerInfo(o.getString("u"), o.getString("n"), o.getLong("s"), o.getLong("t")) }
    }.getOrDefault(emptyList())
    private fun writeList(l: List<VcContainerInfo>) {
        containers = l
        val a = JSONArray(); l.forEach { a.put(JSONObject().put("u", it.uriString).put("n", it.displayName).put("s", it.totalSize).put("t", it.addedAt)) }
        sp.edit().putString("list", a.toString()).apply()
    }
    fun add(uri: Uri) {
        runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        if (containers.none { it.uriString == uri.toString() })
            writeList(containers + VcContainerInfo(uri.toString(), nameOf(ctx, uri), sizeOfUri(ctx, uri), System.currentTimeMillis()))
    }
    fun remove(i: VcContainerInfo) { if (mounted?.info?.uriString == i.uriString) lock(); writeList(containers.filter { it.uriString != i.uriString }) }
    fun mount(m: VcMount) { mounted?.close(); mounted = m }
    fun lock() { Streams.m.clear(); mounted?.close(); mounted = null }
}

// ───────────────────────── Containers tab ─────────────────────────

@Composable
fun VaultScreen(vault: Vault, tick: Int, hash: String, onChange: () -> Unit, onPick: (Boolean) -> Unit, onNote: (String) -> Unit) {
    var target by remember { mutableStateOf<VcContainerInfo?>(null) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        onPick(false); if (uri != null) { vault.add(uri); onChange() }
    }
    Column(Modifier.fillMaxSize()) {
        Text("Open a VeraCrypt container to browse its photos, videos and files.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
        Spacer(Modifier.height(14.dp))
        Button({ onPick(true); pick.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp)) {
            Icon(Icons.Rounded.FolderOpen, null); Spacer(Modifier.width(10.dp)); Text("Open VeraCrypt container", fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(18.dp))
        if (vault.containers.isEmpty()) Text("No containers yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 120.dp)) {
            items(vault.containers, key = { it.uriString }) { c ->
                var menu by remember { mutableStateOf(false) }
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(MaterialTheme.colorScheme.surface).clickable { target = c }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(46.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(.18f)), Alignment.Center) { Icon(Icons.Rounded.Lock, null, tint = MaterialTheme.colorScheme.primary) }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(c.displayName, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(if (c.totalSize > 0) "%.1f GB · tap to unlock".format(c.totalSize / 1073741824.0) else "Tap to unlock", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Box {
                        IconButton({ menu = true }) { Icon(Icons.Rounded.MoreVert, null) }
                        DropdownMenu(menu, { menu = false }) { DropdownMenuItem({ Text("Remove from list") }, { menu = false; vault.remove(c); onChange() }) }
                    }
                }
            }
        }
    }
    target?.let { info -> UnlockDialog(info, hash, vault, { target = null }, onNote) }
}

@Composable
private fun UnlockDialog(info: VcContainerInfo, hash: String, vault: Vault, onDone: () -> Unit, onNote: (String) -> Unit) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var pw by remember { mutableStateOf("") }; var pim by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }; var err by remember { mutableStateOf<String?>(null) }; var busy by remember { mutableStateOf(false) }
    fun go() {
        if (pw.isEmpty() || busy) return
        busy = true; err = null
        scope.launch {
            val m = withContext(Dispatchers.Default) {
                val chars = pw.toCharArray()
                try { VeraCryptEngine.openContainer(ctx, info, chars, pim.toIntOrNull() ?: 0, hash) } catch (e: Throwable) { null } finally { chars.fill('\u0000') }
            }
            busy = false
            if (m == null) err = "Wrong password or PIM, or an unsupported volume (AES with SHA-512/SHA-256 only)."
            else { pw = ""; vault.mount(m); if (m.fs == null) onNote("Unlocked, but the file system isn’t supported"); onDone() }
        }
    }
    AlertDialog(
        onDismissRequest = { if (!busy) onDone() },
        title = { Text(info.displayName, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(pw, { pw = it }, label = { Text("Password") }, singleLine = true, enabled = !busy,
                    visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = { IconButton({ show = !show }) { Icon(if (show) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, null) } })
                OutlinedTextField(pim, { pim = it.filter(Char::isDigit).take(7) }, label = { Text("PIM (optional)") }, singleLine = true, enabled = !busy,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                if (busy) { LinearProgressIndicator(Modifier.fillMaxWidth()); Text("Deriving key… this can take a few seconds", fontSize = 12.sp) }
                err?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
            }
        },
        confirmButton = { TextButton(::go, enabled = pw.isNotEmpty() && !busy) { Text("Unlock") } },
        dismissButton = { TextButton(onDone, enabled = !busy) { Text("Cancel") } }
    )
}

// ───────────────────────── Thumbnails ─────────────────────────

private val vcDisp = Executors.newFixedThreadPool(3).asCoroutineDispatcher()
private val VT = object : LruCache<String, ImageBitmap>((Runtime.getRuntime().maxMemory() / 8).toInt()) {
    override fun sizeOf(k: String, v: ImageBitmap) = v.width * v.height * 4
}

private fun decodeSampled(b: ByteArray, target: Int): Bitmap? {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(b, 0, b.size, o)
    var s = 1; while (maxOf(o.outWidth, o.outHeight) / (s * 2) >= target) s *= 2
    val bmp = BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
    val rot = when (runCatching { ExifInterface(ByteArrayInputStream(b)).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) }.getOrDefault(1)) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
    return if (rot == 0f) bmp else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot) }, true)
}

private suspend fun vcThumb(fs: VcFs, n: VcNode, key: String): ImageBitmap? = VT.get(key) ?: withContext(vcDisp) {
    runCatching {
        val bmp: Bitmap? = if (n.kind == 1) fs.readAll(n, 32 * 1024 * 1024)?.let { decodeSampled(it, 360) } else {
            val src = fs.open(n, mimeOf(n.ext)); val mr = MediaMetadataRetriever()
            try {
                mr.setDataSource(object : MediaDataSource() {
                    override fun readAt(p: Long, b: ByteArray, o: Int, s: Int) = src.read(p, b, o, s)
                    override fun getSize() = src.length
                    override fun close() {}
                })
                (mr.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: mr.getFrameAtTime(0))?.let {
                    val sc = 360f / maxOf(it.width, it.height); if (sc < 1f) Bitmap.createScaledBitmap(it, (it.width * sc).toInt(), (it.height * sc).toInt(), true) else it
                }
            } finally { runCatching { mr.release() } }
        }
        bmp?.asImageBitmap()?.also { VT.put(key, it) }
    }.getOrNull()
}

// ───────────────────────── Full-screen browser ─────────────────────────

private fun kindIcon(n: VcNode): ImageVector = when (n.kind) { 0 -> Icons.Rounded.Folder; 1 -> Icons.Rounded.Image; 2 -> Icons.Rounded.Videocam; else -> Icons.Rounded.InsertDriveFile }
private fun sizeStr(b: Long) = if (b >= 1073741824) "%.2f GB".format(b / 1073741824.0) else if (b >= 1048576) "%.1f MB".format(b / 1048576.0) else "%d KB".format(maxOf(1, b / 1024))

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun VaultBrowser(vault: Vault, onPlay: (Uri) -> Unit, onPick: (Boolean) -> Unit, onNote: (String) -> Unit) {
    val m = vault.mounted ?: return
    val fs = m.fs
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var stack by remember(m) { mutableStateOf(listOf<VcNode>()) }
    var filter by remember { mutableIntStateOf(0) }; var grid by remember { mutableStateOf(true) }; var sort by remember { mutableIntStateOf(0) }
    var sel by remember { mutableStateOf(setOf<String>()) }
    var viewer by remember { mutableStateOf<Pair<List<VcNode>, Int>?>(null) }
    var busy by remember { mutableStateOf<String?>(null) }
    var pendingExport by remember { mutableStateOf<List<VcNode>>(emptyList()) }
    val cur = stack.lastOrNull()

    val raw by produceState<List<VcNode>?>(null, m, cur?.path) { value = if (fs == null) emptyList() else withContext(Dispatchers.IO) { runCatching { fs.children(cur) }.getOrDefault(emptyList()) } }
    val items = remember(raw, filter, sort) {
        (raw ?: emptyList()).filter { filter == 0 || it.isDir || it.kind == filter }
            .sortedWith(compareBy<VcNode>({ !it.isDir }).thenBy { when (sort) { 1 -> -it.size; 2 -> it.ext.hashCode().toLong(); else -> 0L } }.thenBy { it.name.lowercase() })
    }
    val tree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { dir ->
        onPick(false)
        if (dir != null && fs != null) scope.launch {
            busy = "Exporting…"
            val n = withContext(Dispatchers.IO) { runCatching { exportNodes(ctx, fs, dir, pendingExport) }.getOrDefault(-1) }
            busy = null; sel = emptySet(); onNote(if (n < 0) "Export failed" else "Exported $n file(s)")
        }
    }
    fun export(nodes: List<VcNode>) { if (nodes.isEmpty()) return; pendingExport = nodes; onPick(true); tree.launch(null) }
    fun play(n: VcNode) {
        val token = "v" + (m.info.uriString + n.path).hashCode().toUInt().toString(16)
        Streams.m[token] = fs!!.open(n, mimeOf(n.ext)); onPlay(Uri.parse("lumenvc://$token/${Uri.encode(n.name)}"))
    }
    fun openNode(n: VcNode) {
        if (sel.isNotEmpty()) { sel = if (n.path in sel) sel - n.path else sel + n.path; return }
        when (n.kind) {
            0 -> stack = stack + n
            1 -> { val imgs = items.filter { it.kind == 1 }; viewer = imgs to imgs.indexOf(n).coerceAtLeast(0) }
            2 -> play(n)
            else -> sel = setOf(n.path)
        }
    }
    BackHandler { when { viewer != null -> viewer = null; sel.isNotEmpty() -> sel = emptySet(); stack.isNotEmpty() -> stack = stack.dropLast(1); else -> vault.lock() } }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            // top bar
            Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                if (sel.isNotEmpty()) {
                    IconButton({ sel = emptySet() }) { Icon(Icons.Rounded.Close, null) }
                    Text("${sel.size} selected", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                    IconButton({ sel = items.map { it.path }.toSet() }) { Icon(Icons.Rounded.SelectAll, null) }
                    IconButton({ export(items.filter { it.path in sel }) }) { Icon(Icons.Rounded.SaveAlt, null) }
                } else {
                    IconButton({ if (stack.isNotEmpty()) stack = stack.dropLast(1) else vault.lock() }) { Icon(if (stack.isEmpty()) Icons.Rounded.Lock else Icons.Rounded.ArrowBackIosNew, null) }
                    Column(Modifier.weight(1f)) {
                        Text(cur?.name ?: m.info.displayName, fontWeight = FontWeight.Bold, fontSize = 19.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(if (cur == null) "${items.size} items · tap lock to close" else cur.path.trimStart('/').replace("/", " › "), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton({ sort = (sort + 1) % 3; onNote(listOf("Sorted by name", "Sorted by size", "Sorted by type")[sort]) }) { Icon(Icons.Rounded.SortByAlpha, null) }
                    IconButton({ grid = !grid }) { Icon(if (grid) Icons.Rounded.ViewList else Icons.Rounded.GridView, null) }
                }
            }
            Row(Modifier.padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("All", "Photos", "Videos").forEachIndexed { i, t -> FilterChip(filter == i, { filter = i }, { Text(t) }) }
            }
            Spacer(Modifier.height(6.dp))
            when {
                fs == null -> Column(Modifier.fillMaxSize().padding(28.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                    Text("Unlocked, but this file system isn’t supported", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("Supported: FAT16, FAT32 and exFAT. NTFS volumes can’t be read yet.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
                    Button({ vault.lock() }, Modifier.padding(top = 16.dp)) { Text("Lock") }
                }
                raw == null -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
                items.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) { Text("Nothing here", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                else -> LazyVerticalGrid(if (grid) GridCells.Adaptive(108.dp) else GridCells.Fixed(1), Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 40.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(items, key = { it.path }) { n ->
                        val on = n.path in sel
                        val thumb by produceState<ImageBitmap?>(VT.get(m.info.uriString + n.path), n.path) { if (value == null && (n.kind == 1 || n.kind == 2)) value = vcThumb(fs, n, m.info.uriString + n.path) }
                        val click = Modifier.combinedClickable(onClick = { openNode(n) }, onLongClick = { sel = sel + n.path })
                        if (grid) Column(Modifier.then(click)) {
                            Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface), Alignment.Center) {
                                if (thumb != null) Image(thumb!!, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                                else Icon(kindIcon(n), null, Modifier.size(38.dp), tint = if (n.isDir) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                                if (n.kind == 2) Icon(Icons.Rounded.PlayCircle, null, Modifier.align(Alignment.BottomStart).padding(6.dp).size(24.dp), tint = Color.White)
                                if (on) Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.primary.copy(.35f)), Alignment.TopEnd) { Icon(Icons.Rounded.CheckCircle, null, Modifier.padding(6.dp), tint = Color.White) }
                            }
                            Text(n.name, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp, start = 2.dp))
                        } else Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(if (on) MaterialTheme.colorScheme.primary.copy(.2f) else MaterialTheme.colorScheme.surface).then(click).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(54.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.background), Alignment.Center) {
                                if (thumb != null) Image(thumb!!, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) else Icon(kindIcon(n), null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(n.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(if (n.isDir) "Folder" else sizeStr(n.size), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (on) Icon(Icons.Rounded.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
        viewer?.let { (list, start) -> ImageViewer(fs!!, list, start, { viewer = null }, { export(listOf(it)) }) }
        busy?.let { msg ->
            Box(Modifier.fillMaxSize().background(Color(0xAA000000)).pointerInput(Unit) { detectTapGestures { } }, Alignment.Center) {
                Column(Modifier.clip(RoundedCornerShape(24.dp)).background(MaterialTheme.colorScheme.surface).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(); Spacer(Modifier.height(12.dp)); Text(msg)
                }
            }
        }
    }
}

private fun exportNodes(ctx: Context, fs: VcFs, tree: Uri, nodes: List<VcNode>): Int {
    val cr = ctx.contentResolver; var done = 0
    val rootDoc = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
    fun put(parent: Uri, n: VcNode) {
        if (n.isDir) { val d = DocumentsContract.createDocument(cr, parent, DocumentsContract.Document.MIME_TYPE_DIR, n.name) ?: return; fs.children(n).forEach { put(d, it) } }
        else {
            val d = DocumentsContract.createDocument(cr, parent, mimeOf(n.ext), n.name) ?: return
            cr.openOutputStream(d)?.use { out ->
                val s = fs.open(n, ""); val buf = ByteArray(1 shl 20); var p = 0L
                while (p < n.size) { val r = s.read(p, buf, 0, buf.size); if (r <= 0) break; out.write(buf, 0, r); p += r }
            }; done++
        }
    }
    nodes.forEach { put(rootDoc, it) }
    return done
}

@Composable
private fun ImageViewer(fs: VcFs, list: List<VcNode>, start: Int, onClose: () -> Unit, onExport: (VcNode) -> Unit) {
    val pager = rememberPagerState(start) { list.size }
    var zoomed by remember { mutableStateOf(false) }; var bars by remember { mutableStateOf(true) }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(pager, Modifier.fillMaxSize(), userScrollEnabled = !zoomed, key = { list[it].path }) { i ->
            val n = list[i]
            val bmp by produceState<ImageBitmap?>(null, n.path) { value = withContext(vcDisp) { runCatching { fs.readAll(n, 64 * 1024 * 1024)?.let { decodeSampled(it, 2400)?.asImageBitmap() } }.getOrNull() } }
            ZoomPage(bmp, { zoomed = it }, { bars = !bars })
        }
        if (bars) Row(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xAA000000), Color.Transparent))).statusBarsPadding().padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClose) { Icon(Icons.Rounded.ArrowBackIosNew, null, tint = Color.White) }
            Text(list[pager.currentPage].name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Text("${pager.currentPage + 1}/${list.size}", color = Color.White, fontSize = 12.sp)
            IconButton({ onExport(list[pager.currentPage]) }) { Icon(Icons.Rounded.SaveAlt, null, tint = Color.White) }
        }
    }
}

@Composable
private fun ZoomPage(bmp: ImageBitmap?, onZoom: (Boolean) -> Unit, onTap: () -> Unit) {
    var z by remember { mutableFloatStateOf(1f) }; var ox by remember { mutableFloatStateOf(0f) }; var oy by remember { mutableFloatStateOf(0f) }
    Box(Modifier.fillMaxSize()
        .pointerInput(Unit) { detectTapGestures(onDoubleTap = { z = if (z > 1f) 1f else 2.5f; ox = 0f; oy = 0f; onZoom(z > 1f) }, onTap = { onTap() }) }
        .pointerInput(Unit) {
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false)
                do {
                    val e = awaitPointerEvent()
                    if (e.changes.size > 1 || z > 1f) {
                        z = (z * e.calculateZoom()).coerceIn(1f, 6f)
                        if (z > 1f) { val p = e.calculatePan(); ox += p.x; oy += p.y } else { ox = 0f; oy = 0f }
                        onZoom(z > 1f)
                        e.changes.forEach { if (it.positionChanged()) it.consume() }
                    }
                } while (e.changes.any { it.pressed })
            }
        }, Alignment.Center) {
        if (bmp != null) Image(bmp, null, Modifier.fillMaxSize().graphicsLayer { scaleX = z; scaleY = z; translationX = ox; translationY = oy }, contentScale = ContentScale.Fit)
        else CircularProgressIndicator(color = Color.White)
    }
}
