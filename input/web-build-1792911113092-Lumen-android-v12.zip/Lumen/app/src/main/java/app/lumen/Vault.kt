package app.lumen

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Base64
import android.util.LruCache
import android.webkit.MimeTypeMap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

@Immutable
data class VItem(val id: String, val name: String, val ext: String, val dur: Long, val h: Int, val size: Long)

/**
 * Password vault + VeraCrypt (.hc / .vc / .tc) container manager.
 * Password -> PBKDF2-SHA256 (150k) -> AES-256 key.
 * Videos and thumbnails: AES-CTR with a random IV per file. Index (names etc.): AES-GCM.
 */
@Stable
class Vault(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("vault", 0)
    private val dir = File(ctx.filesDir, "vault").apply { mkdirs() }
    private var key: SecretKeySpec? = null
    var items: List<VItem> = emptyList(); private set
    var vcContainers: List<VcContainerInfo> = emptyList(); private set
    var mountedVc by mutableStateOf<MountedVeraCrypt?>(null)

    // Decrypted thumbnails kept in memory only while unlocked
    private val thumbCache = object : LruCache<String, Bitmap>(32 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    init {
        loadVcList()
    }

    fun cachedThumb(id: String): Bitmap? = thumbCache.get(id)

    val exists: Boolean get() = sp.contains("salt")
    val unlocked: Boolean get() = key != null

    private fun derive(pw: CharArray, salt: ByteArray): SecretKeySpec {
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return SecretKeySpec(f.generateSecret(PBEKeySpec(pw, salt, 150_000, 256)).encoded, "AES")
    }

    private fun seal(k: SecretKeySpec, data: ByteArray): String {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, k, GCMParameterSpec(128, iv))
        return Base64.encodeToString(iv + c.doFinal(data), Base64.NO_WRAP)
    }

    private fun unseal(k: SecretKeySpec, s: String): ByteArray? = try {
        val all = Base64.decode(s, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, k, GCMParameterSpec(128, all, 0, 12))
        c.doFinal(all, 12, all.size - 12)
    } catch (e: Exception) {
        null
    }

    fun setup(pw: CharArray) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val k = derive(pw, salt)
        sp.edit()
            .putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("ver", seal(k, "lumen".toByteArray()))
            .apply()
        key = k; items = emptyList(); save()
    }

    fun unlock(pw: CharArray): Boolean {
        val salt = Base64.decode(sp.getString("salt", "") ?: "", Base64.NO_WRAP)
        val k = derive(pw, salt)
        val v = unseal(k, sp.getString("ver", "") ?: "")
        return if (v != null && String(v) == "lumen") {
            key = k; load(); loadVcList(); true
        } else false
    }

    fun lock() {
        key = null
        items = emptyList()
        mountedVc = null
        thumbCache.evictAll()
    }

    private fun loadVcList() {
        val raw = sp.getString("vc_list", null) ?: return
        runCatching {
            val arr = JSONArray(raw)
            vcContainers = (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                VcContainerInfo(
                    o.getString("uri"),
                    o.getString("name"),
                    o.optLong("size", 0L),
                    o.optLong("ts", 0L)
                )
            }
        }
    }

    private fun saveVcList() {
        val arr = JSONArray()
        vcContainers.forEach {
            arr.put(
                JSONObject()
                    .put("uri", it.uriString)
                    .put("name", it.displayName)
                    .put("size", it.totalSize)
                    .put("ts", it.addedAt)
            )
        }
        sp.edit().putString("vc_list", arr.toString()).apply()
    }

    fun addVcContainer(uri: Uri): VcContainerInfo {
        runCatching {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val name = nameOf(ctx, uri)
        val size = sizeOfUri(ctx, uri)
        val info = VcContainerInfo(uri.toString(), name, size, System.currentTimeMillis())
        vcContainers = listOf(info) + vcContainers.filterNot { it.uriString == info.uriString }
        saveVcList()
        return info
    }

    fun removeVcContainer(info: VcContainerInfo) {
        if (mountedVc?.info?.uriString == info.uriString) mountedVc = null
        vcContainers = vcContainers.filterNot { it.uriString == info.uriString }
        saveVcList()
    }

    private fun load() {
        val k = key ?: return
        val arr = sp.getString("idx", null)?.let { unseal(k, it) }?.let { JSONArray(String(it)) } ?: JSONArray()
        items = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            VItem(o.getString("id"), o.getString("name"), o.getString("ext"), o.getLong("dur"), o.getInt("h"), o.getLong("size"))
        }
    }

    private fun save() {
        val k = key ?: return
        val arr = JSONArray()
        items.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("name", it.name)
                    .put("ext", it.ext)
                    .put("dur", it.dur)
                    .put("h", it.h)
                    .put("size", it.size)
            )
        }
        sp.edit().putString("idx", seal(k, arr.toString().toByteArray())).apply()
    }

    private fun ctr(mode: Int, iv: ByteArray): Cipher =
        Cipher.getInstance("AES/CTR/NoPadding").apply { init(mode, key!!, IvParameterSpec(iv)) }

    private fun encryptTo(src: InputStream, f: File) {
        val iv = ByteArray(16).also { SecureRandom().nextBytes(it) }
        f.outputStream().use { raw ->
            raw.write(iv)
            CipherOutputStream(raw, ctr(Cipher.ENCRYPT_MODE, iv)).use { src.copyTo(it, 256 * 1024) }
        }
    }

    private fun decryptTo(f: File, out: OutputStream) {
        f.inputStream().use { raw ->
            val iv = ByteArray(16)
            var n = 0
            while (n < 16) {
                val r = raw.read(iv, n, 16 - n)
                if (r < 0) break
                n += r
            }
            CipherInputStream(raw, ctr(Cipher.DECRYPT_MODE, iv)).use { it.copyTo(out, 256 * 1024) }
        }
    }

    @Synchronized
    fun add(src: Uri, fileName: String) {
        val id = java.util.UUID.randomUUID().toString()
        val vf = File(dir, "$id.lvf"); val tf = File(dir, "$id.thm")
        try {
            (ctx.contentResolver.openInputStream(src) ?: error("cannot open")).use { encryptTo(it, vf) }
            frameOf(ctx, src, 720)?.let { b ->
                val bo = ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.JPEG, 85, bo)
                encryptTo(ByteArrayInputStream(bo.toByteArray()), tf)
            }
            val (dur, h) = probe(ctx, src)
            val ext = fileName.substringAfterLast('.', "mp4").lowercase().take(5)
            items = listOf(VItem(id, fileName.substringBeforeLast('.'), ext, dur, h, vf.length())) + items
            save()
        } catch (e: Exception) {
            vf.delete(); tf.delete(); throw e
        }
    }

    fun thumb(id: String): Bitmap? = thumbCache.get(id) ?: try {
        val f = File(dir, "$id.thm")
        if (f.exists()) {
            val bo = ByteArrayOutputStream(); decryptTo(f, bo)
            val b = bo.toByteArray()
            val opts = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.RGB_565 }
            BitmapFactory.decodeByteArray(b, 0, b.size, opts)?.also { thumbCache.put(id, it) }
        } else null
    } catch (e: Exception) {
        null
    }

    /** Decrypts to cache for playback; the caller deletes it when the player closes. */
    fun playFile(v: VItem): File {
        val d = File(ctx.cacheDir, "play").apply { mkdirs() }
        val out = File(d, "${v.id}.${v.ext}")
        if (!out.exists() || out.length() == 0L) {
            try {
                out.outputStream().use { decryptTo(File(dir, "${v.id}.lvf"), it) }
            } catch (e: Exception) {
                out.delete(); throw e
            }
        }
        return out
    }

    /** Extracts a video entry from a mounted VeraCrypt volume into cacheDir/play for playback. */
    fun playVeraCryptEntry(mounted: MountedVeraCrypt, entry: VcFileEntry): File? {
        val d = File(ctx.cacheDir, "play").apply { mkdirs() }
        val out = File(d, "vc_${entry.id}.${entry.ext}")
        if (out.exists() && out.length() == entry.size) return out
        val ok = mounted.extractToFile(entry, out)
        if (!ok || !out.exists() || out.length() == 0L) {
            out.delete()
            return null
        }
        return out
    }

    fun export(v: VItem): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "${v.name}.${v.ext}")
            put(MediaStore.Video.Media.MIME_TYPE, MimeTypeMap.getSingleton().getMimeTypeFromExtension(v.ext) ?: "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Lumen")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val col = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val uri = ctx.contentResolver.insert(col, cv) ?: return false
        return try {
            (ctx.contentResolver.openOutputStream(uri) ?: error("no stream")).use { decryptTo(File(dir, "${v.id}.lvf"), it) }
            val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            ctx.contentResolver.update(uri, done, null, null)
            true
        } catch (e: Exception) {
            ctx.contentResolver.delete(uri, null, null); false
        }
    }

    @Synchronized
    fun remove(v: VItem) {
        File(dir, "${v.id}.lvf").delete(); File(dir, "${v.id}.thm").delete(); thumbCache.remove(v.id)
        items = items.filter { it.id != v.id }; save()
    }
}

@Composable
fun PasswordField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier
) {
    var showPassword by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier,
        label = { Text(label) },
        singleLine = true,
        visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        trailingIcon = {
            IconButton(onClick = { showPassword = !showPassword }) {
                Icon(
                    imageVector = if (showPassword) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                    contentDescription = if (showPassword) "Hide password" else "Show password"
                )
            }
        },
        shape = RoundedCornerShape(14.dp)
    )
}

@Composable
fun VaultScreen(
    vault: Vault,
    tick: Int,
    vcHashPref: String,
    onChange: () -> Unit,
    onPlay: (VItem) -> Unit,
    onPlayFile: (File) -> Unit,
    onPicking: (Boolean) -> Unit,
    notify: (String) -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var vcPromptTarget by remember { mutableStateOf<VcContainerInfo?>(null) }
    var busy by remember { mutableStateOf<String?>(null) }

    val pickVc = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        onPicking(false)
        if (uri != null) {
            val info = vault.addVcContainer(uri)
            onChange()
            vcPromptTarget = info
        }
    }

    if (vcPromptTarget != null) {
        VeraCryptUnlockDialog(
            info = vcPromptTarget!!,
            defaultHash = vcHashPref,
            onDismiss = { vcPromptTarget = null },
            onUnlocked = { mounted ->
                vault.mountedVc = mounted
                vcPromptTarget = null
                onChange()
                notify("Mounted ${mounted.info.displayName} (${mounted.files.size} video(s))")
            }
        )
    }

    if (!vault.unlocked) {
        VaultAuth(
            vault = vault,
            onDone = onChange,
            onOpenVeraCrypt = {
                onPicking(true)
                pickVc.launch(arrayOf("*/*"))
            },
            mountedVc = vault.mountedVc,
            onSelectVc = { vcPromptTarget = it },
            onUnmountVc = { vault.mountedVc = null; onChange() },
            onPlayVcEntry = { mounted, entry ->
                scope.launch {
                    busy = "Decrypting ${entry.name} from VeraCrypt…"
                    val f = withContext(Dispatchers.IO) { vault.playVeraCryptEntry(mounted, entry) }
                    busy = null
                    if (f != null) onPlayFile(f) else notify("Couldn't read video from container")
                }
            },
            busy = busy
        )
        return
    }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        onPicking(false)
        if (uris.isNotEmpty()) scope.launch {
            var fails = 0
            uris.forEachIndexed { i, u ->
                busy = "Encrypting ${i + 1} of ${uris.size}…"
                val ok = withContext(Dispatchers.IO) { runCatching { vault.add(u, nameOf(ctx, u)) }.isSuccess }
                if (!ok) fails++
                onChange()
            }
            busy = null
            notify(if (fails == 0) "Added to vault" else "$fails file(s) couldn’t be added")
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { onPicking(true); pick.launch(arrayOf("video/*")) },
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Rounded.Add, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Add videos")
            }
            FilledTonalButton(
                onClick = { onPicking(true); pickVc.launch(arrayOf("*/*")) },
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Rounded.FolderSpecial, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("VeraCrypt")
            }
            Spacer(Modifier.weight(1f))
            OutlinedButton(
                onClick = { vault.lock(); onChange() },
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Rounded.Lock, null, Modifier.size(17.dp))
                Spacer(Modifier.width(5.dp))
                Text("Lock")
            }
        }

        AnimatedVisibility(visible = busy != null, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
            Column(Modifier.fillMaxWidth().padding(top = 12.dp)) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(busy ?: "", fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }

        val list = vault.items
        val vcList = vault.vcContainers
        val mounted = vault.mountedVc

        if (list.isEmpty() && vcList.isEmpty() && mounted == null && busy == null) {
            Text(
                "Nothing here yet. Tap Add videos, open a VeraCrypt (.hc / .vc) container, or use ⋮ → Move to vault on a video in the Library.",
                Modifier.padding(top = 24.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        LazyVerticalGrid(
            columns = GridCells.Adaptive(160.dp),
            modifier = Modifier.padding(top = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
            contentPadding = PaddingValues(bottom = 120.dp)
        ) {
            // Mounted VeraCrypt Volume Banner & Files
            if (mounted != null) {
                item(span = { GridItemSpan(maxLineSpan) }, key = "vc_mounted_hdr") {
                    MountedVeraCryptCard(
                        mounted = mounted,
                        onUnmount = { vault.mountedVc = null; onChange(); notify("VeraCrypt container unmounted") },
                        onPlayEntry = { entry ->
                            scope.launch {
                                busy = "Decrypting “${entry.name}” from VeraCrypt…"
                                val f = withContext(Dispatchers.IO) { vault.playVeraCryptEntry(mounted, entry) }
                                busy = null
                                if (f != null) onPlayFile(f) else notify("Couldn't decrypt file")
                            }
                        },
                        onImportToVault = { entry ->
                            scope.launch {
                                busy = "Importing “${entry.name}” to Vault…"
                                val ok = withContext(Dispatchers.IO) {
                                    val tmp = vault.playVeraCryptEntry(mounted, entry) ?: return@withContext false
                                    try {
                                        vault.add(Uri.fromFile(tmp), "${entry.name}.${entry.ext}")
                                        true
                                    } catch (e: Exception) {
                                        false
                                    } finally {
                                        tmp.delete()
                                    }
                                }
                                busy = null
                                onChange()
                                notify(if (ok) "Imported to Vault" else "Import failed")
                            }
                        }
                    )
                }
            }

            // Saved VeraCrypt Containers List
            if (vcList.isNotEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }, key = "vc_saved_section") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            "VERACRYPT CONTAINERS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        vcList.forEach { info ->
                            val isMounted = mounted?.info?.uriString == info.uriString
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(MaterialTheme.colorScheme.surface)
                                    .clickable {
                                        if (isMounted) vault.mountedVc = null else vcPromptTarget = info
                                        onChange()
                                    }
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    Modifier.size(38.dp).clip(CircleShape).background(Color(0xFFF59B95)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        if (isMounted) Icons.Rounded.LockOpen else Icons.Rounded.EnhancedEncryption,
                                        null,
                                        tint = Color(0xFF1A1C20),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(info.displayName, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    val mb = info.totalSize / (1024 * 1024)
                                    Text(
                                        if (isMounted) "Mounted • Tap to lock" else "${if (mb > 0) "${mb} MB • " else ""}Tap to unlock with password",
                                        fontSize = 12.sp,
                                        color = if (isMounted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(onClick = { vault.removeVcContainer(info); onChange() }) {
                                    Icon(Icons.Rounded.Close, "Remove from list", Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }

            items(list, key = { it.id }) { v ->
                VaultCard(vault, v, { onPlay(v) }, onChange, notify)
            }
        }
    }
}

@Composable
private fun MountedVeraCryptCard(
    mounted: MountedVeraCrypt,
    onUnmount: () -> Unit,
    onPlayEntry: (VcFileEntry) -> Unit,
    onImportToVault: (VcFileEntry) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f), RoundedCornerShape(20.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(Color(0xFF63D2EB)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.LockOpen, null, tint = Color(0xFF1A1C20), modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(mounted.info.displayName, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "VeraCrypt XTS-AES-256 (${mounted.hashAlgo}) • ${mounted.files.size} video(s)",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            TextButton(onClick = onUnmount) { Text("Unmount") }
        }
        mounted.files.forEach { f ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.background.copy(alpha = 0.6f))
                    .clickable { onPlayEntry(f) }
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.PlayCircleFilled, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(26.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("${f.name}.${f.ext}", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    val mb = "%.1f MB".format(f.size / (1024.0 * 1024.0))
                    Text(mb, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { onImportToVault(f) }) {
                    Icon(Icons.Rounded.Download, "Import to Vault", Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
fun VeraCryptUnlockDialog(
    info: VcContainerInfo,
    defaultHash: String,
    onDismiss: () -> Unit,
    onUnlocked: (MountedVeraCrypt) -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pw by remember { mutableStateOf("") }
    var pimText by remember { mutableStateOf("") }
    var hashMode by remember { mutableStateOf(defaultHash) }
    var err by remember { mutableStateOf<String?>(null) }
    var working by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = { if (!working) onDismiss() },
        icon = {
            Box(Modifier.size(48.dp).clip(CircleShape).background(Color(0xFFF59B95)), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.EnhancedEncryption, null, tint = Color(0xFF1A1C20))
            }
        },
        title = { Text("Open VeraCrypt Container", fontWeight = FontWeight.Bold, fontSize = 19.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    info.displayName,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )
                PasswordField(
                    value = pw,
                    onValueChange = { pw = it; err = null },
                    label = "Container password",
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = pimText,
                    onValueChange = { pimText = it.filter { c -> c.isDigit() } },
                    label = { Text("PIM (Optional, leave blank for default)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("auto" to "Auto", "sha512" to "SHA-512", "sha256" to "SHA-256").forEach { (k, label) ->
                        FilterChip(
                            selected = hashMode == k,
                            onClick = { hashMode = k },
                            label = { Text(label, fontSize = 12.sp) }
                        )
                    }
                }
                if (working) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        Text("Deriving XTS-AES-256 key (PBKDF2)…", fontSize = 12.sp)
                    }
                }
                err?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
            }
        },
        confirmButton = {
            Button(
                enabled = !working && pw.isNotEmpty(),
                onClick = {
                    working = true; err = null
                    val pim = pimText.toIntOrNull() ?: 0
                    scope.launch {
                        val mounted = withContext(Dispatchers.Default) {
                            VeraCryptEngine.openContainer(ctx, info, pw.toCharArray(), pim, hashMode)
                        }
                        working = false
                        if (mounted != null) onUnlocked(mounted)
                        else err = "Invalid password, PIM, or unsupported volume header."
                    }
                }
            ) {
                Text(if (working) "Mounting…" else "Mount")
            }
        },
        dismissButton = {
            TextButton(enabled = !working, onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun VaultAuth(
    vault: Vault,
    onDone: () -> Unit,
    onOpenVeraCrypt: () -> Unit,
    mountedVc: MountedVeraCrypt?,
    onSelectVc: (VcContainerInfo) -> Unit,
    onUnmountVc: () -> Unit,
    onPlayVcEntry: (MountedVeraCrypt, VcFileEntry) -> Unit,
    busy: String?
) {
    val exists = vault.exists
    var pw by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var working by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(
        Modifier.fillMaxWidth().padding(top = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.size(48.dp).clip(CircleShape).background(Color(0xFF63D2EB)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Lock, null, Modifier.size(24.dp), tint = Color(0xFF1A1C20))
            }
            Column {
                Text(if (exists) "Vault is locked" else "Create your vault", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (exists) "Enter your password to unlock." else "AES-256 encrypted local vault + VeraCrypt support.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        PasswordField(
            value = pw,
            onValueChange = { pw = it; err = null },
            label = "Password",
            modifier = Modifier.fillMaxWidth()
        )
        if (!exists) {
            PasswordField(
                value = pw2,
                onValueChange = { pw2 = it; err = null },
                label = "Repeat password",
                modifier = Modifier.fillMaxWidth()
            )
        }
        err?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            Button(
                onClick = {
                    if (!exists && pw.length < 6) err = "Use at least 6 characters"
                    else if (!exists && pw != pw2) err = "Passwords don’t match"
                    else {
                        working = true; err = null
                        scope.launch {
                            val ok = withContext(Dispatchers.Default) {
                                if (exists) vault.unlock(pw.toCharArray()) else { vault.setup(pw.toCharArray()); true }
                            }
                            working = false
                            if (ok) onDone() else err = "Wrong password"
                        }
                    }
                },
                enabled = !working && pw.isNotEmpty(),
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(if (working) "Please wait…" else if (exists) "Unlock Vault" else "Create Vault")
            }

            OutlinedButton(
                onClick = onOpenVeraCrypt,
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Rounded.FolderSpecial, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Open VeraCrypt")
            }
        }

        if (busy != null) {
            LinearProgressIndicator(Modifier.fillMaxWidth())
            Text(busy, fontSize = 12.sp)
        }

        if (mountedVc != null) {
            MountedVeraCryptCard(
                mounted = mountedVc,
                onUnmount = onUnmountVc,
                onPlayEntry = { onPlayVcEntry(mountedVc, it) },
                onImportToVault = {}
            )
        } else if (vault.vcContainers.isNotEmpty()) {
            Text(
                "RECENT VERACRYPT CONTAINERS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 8.dp)
            )
            vault.vcContainers.take(3).forEach { info ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .clickable { onSelectVc(info) }
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(36.dp).clip(CircleShape).background(Color(0xFFF59B95)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.EnhancedEncryption, null, tint = Color(0xFF1A1C20), modifier = Modifier.size(18.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(info.displayName, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("Tap to mount container", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun VaultCard(vault: Vault, v: VItem, onPlay: () -> Unit, onChange: () -> Unit, notify: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val thumb by produceState<ImageBitmap?>(vault.cachedThumb(v.id)?.asImageBitmap(), v.id) {
        if (value == null) value = withContext(Dispatchers.IO) { vault.thumb(v.id)?.asImageBitmap() }
    }
    var menu by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.pressBounce()) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(16 / 9f)
                .clip(RoundedCornerShape(20.dp))
                .background(MaterialTheme.colorScheme.surface)
                .clickable { onPlay() }
        ) {
            thumb?.let {
                Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, filterQuality = FilterQuality.Low)
            }
            Badges(v.h, v.dur)
        }
        Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(v.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Box {
                IconButton({ menu = true }, Modifier.size(28.dp)) { Icon(Icons.Rounded.MoreVert, null, Modifier.size(18.dp)) }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem({ Text("Restore to gallery") }, {
                        menu = false
                        scope.launch {
                            notify("Restoring…")
                            val ok = withContext(Dispatchers.IO) { vault.export(v) }
                            if (ok) {
                                withContext(Dispatchers.IO) { vault.remove(v) }
                                onChange()
                                notify("Saved to Movies/Lumen")
                            } else notify("Couldn’t restore (needs Android 10+)")
                        }
                    })
                    DropdownMenuItem({ Text("Delete permanently") }, { menu = false; confirm = true })
                }
            }
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Delete “${v.name}”?") },
        text = { Text("This removes the encrypted copy for good.") },
        confirmButton = {
            TextButton({
                confirm = false
                scope.launch { withContext(Dispatchers.IO) { vault.remove(v) }; onChange() }
            }) { Text("Delete") }
        },
        dismissButton = { TextButton({ confirm = false }) { Text("Cancel") } }
    )
}
