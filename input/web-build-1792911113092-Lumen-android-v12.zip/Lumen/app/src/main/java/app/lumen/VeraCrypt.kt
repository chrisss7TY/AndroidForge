package app.lumen

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets
import java.util.zip.CRC32
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

@androidx.compose.runtime.Immutable
data class VcFileEntry(
    val id: String,
    val name: String,
    val ext: String,
    val size: Long,
    val startCluster: Long,
    val contiguous: Boolean = false,
    val directOffset: Long = -1L
)

@androidx.compose.runtime.Immutable
data class VcContainerInfo(
    val uriString: String,
    val displayName: String,
    val totalSize: Long,
    val addedAt: Long
)

/**
 * Pure Kotlin VeraCrypt (XTS-AES-256) Container Reader & Mount Engine.
 * Supports:
 * - Standard VeraCrypt volumes (.hc, .vc, .tc, .img, .bin) with PBKDF2-HMAC-SHA512 / SHA256 and custom PIM
 * - Primary header (offset 0) and backup header (offset EOF - 128 KB)
 * - XTS-AES-256 sector decryption (IEEE P1619)
 * - Embedded FAT16 / FAT32 (with VFAT Long File Names) and exFAT filesystems
 * - Direct Lumen-VeraCrypt container archives & raw encrypted streams
 */
class MountedVeraCrypt(
    val info: VcContainerInfo,
    val hashAlgo: String,
    private val ctx: Context,
    private val masterKey1: ByteArray,
    private val masterKey2: ByteArray,
    private val masterKeyOffset: Long,
    private val volumeDataSize: Long,
    private val sectorSize: Int,
    val files: List<VcFileEntry>,
    private val fsReader: ((VcFileEntry, File) -> Boolean)?
) {
    fun extractToFile(entry: VcFileEntry, dest: File): Boolean {
        val reader = fsReader ?: return false
        return runCatching { reader(entry, dest) }.getOrDefault(false)
    }
}

object VeraCryptEngine {
    private val VIDEO_EXTS = setOf("mp4", "mkv", "webm", "mov", "avi", "m4v", "ts", "3gp", "flv", "wmv")

    private fun deriveXtsKey(password: CharArray, salt: ByteArray, algo: String, iterations: Int): ByteArray {
        val factory = SecretKeyFactory.getInstance(algo)
        val spec = PBEKeySpec(password, salt, iterations, 512)
        return try {
            factory.generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    /** Multiply 128-bit little-endian tweak by alpha in GF(2^128) with polynomial x^128 + x^7 + x^2 + x + 1 (0x87). */
    private fun gf128MulAlpha(tweak: ByteArray) {
        var carry = 0
        for (i in 0 until 16) {
            val b = tweak[i].toInt() and 0xFF
            val nextCarry = (b ushr 7) and 1
            tweak[i] = (((b shl 1) or carry) and 0xFF).toByte()
            carry = nextCarry
        }
        if (carry != 0) {
            tweak[0] = (tweak[0].toInt() xor 0x87).toByte()
        }
    }

    /** Decrypts a single sector/unit in-place using XTS-AES-256. */
    fun xtsDecryptUnit(
        data: ByteArray,
        offset: Int,
        length: Int,
        dataUnitNo: Long,
        decCipher: Cipher,
        tweakCipher: Cipher
    ) {
        val tweak = ByteArray(16)
        var u = dataUnitNo
        for (i in 0 until 8) {
            tweak[i] = (u and 0xFF).toByte()
            u = u ushr 8
        }
        val t = tweakCipher.doFinal(tweak)
        val n = length / 16
        val tw = ByteArray(n * 16)
        for (b in 0 until n) { System.arraycopy(t, 0, tw, b * 16, 16); gf128MulAlpha(t) }
        val buf = ByteArray(n * 16)
        for (i in buf.indices) buf[i] = (data[offset + i].toInt() xor tw[i].toInt()).toByte()
        val out = decCipher.doFinal(buf)
        for (i in buf.indices) data[offset + i] = (out[i].toInt() xor tw[i].toInt()).toByte()
    }

    private fun readBeU64(buf: ByteArray, off: Int): Long =
        ByteBuffer.wrap(buf, off, 8).order(ByteOrder.BIG_ENDIAN).long

    private fun readBeU32(buf: ByteArray, off: Int): Long =
        ByteBuffer.wrap(buf, off, 4).order(ByteOrder.BIG_ENDIAN).int.toLong() and 0xFFFFFFFFL

    private fun readLeU16(buf: ByteArray, off: Int): Int =
        (buf[off].toInt() and 0xFF) or ((buf[off + 1].toInt() and 0xFF) shl 8)

    private fun readLeU32(buf: ByteArray, off: Int): Long =
        ByteBuffer.wrap(buf, off, 4).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xFFFFFFFFL

    private fun readLeU64(buf: ByteArray, off: Int): Long =
        ByteBuffer.wrap(buf, off, 8).order(ByteOrder.LITTLE_ENDIAN).long

    /**
     * Unlocks and mounts a VeraCrypt container URI.
     * Supports SHA-512, SHA-256, custom PIM, primary & backup headers, FAT16/FAT32/exFAT, and direct encrypted streams.
     */
    fun openContainer(
        ctx: Context,
        info: VcContainerInfo,
        password: CharArray,
        pim: Int = 0,
        preferredHash: String = "auto"
    ): MountedVeraCrypt? {
        val uri = Uri.parse(info.uriString)
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: return null
        pfd.use { fd ->
            val fis = FileInputStream(fd.fileDescriptor)
            val ch = fis.channel
            val fileSize = ch.size()
            if (fileSize < 131072L) return null

            val algos = when (preferredHash) {
                "sha512" -> listOf("PBKDF2WithHmacSHA512" to "HMAC-SHA-512")
                "sha256" -> listOf("PBKDF2WithHmacSHA256" to "HMAC-SHA-256")
                else -> listOf(
                    "PBKDF2WithHmacSHA512" to "HMAC-SHA-512",
                    "PBKDF2WithHmacSHA256" to "HMAC-SHA-256"
                )
            }
            val iterList = if (pim > 0) listOf(15_000 + pim * 1_000) else listOf(500_000)
            val headerOffsets = listOf(0L, fileSize - 131072L)

            for (hdrOff in headerOffsets) {
                if (hdrOff < 0 || hdrOff + 512 > fileSize) continue
                val hdrBuf = ByteArray(512)
                ch.position(hdrOff)
                var read = 0
                while (read < 512) {
                    val r = fis.read(hdrBuf, read, 512 - read)
                    if (r <= 0) break
                    read += r
                }
                if (read < 512) continue

                val salt = hdrBuf.copyOfRange(0, 64)
                val encPayload = hdrBuf.copyOfRange(64, 512)

                for ((jceAlgo, label) in algos) {
                    for (iters in iterList) {
                        val derived = runCatching { deriveXtsKey(password, salt, jceAlgo, iters) }.getOrNull() ?: continue
                        val k1 = derived.copyOfRange(0, 32)
                        val k2 = derived.copyOfRange(32, 64)
                        val decCipher = Cipher.getInstance("AES/ECB/NoPadding").apply {
                            init(Cipher.DECRYPT_MODE, SecretKeySpec(k1, "AES"))
                        }
                        val tweakCipher = Cipher.getInstance("AES/ECB/NoPadding").apply {
                            init(Cipher.ENCRYPT_MODE, SecretKeySpec(k2, "AES"))
                        }

                        val candidate = encPayload.clone()
                        xtsDecryptUnit(candidate, 0, candidate.size, 0L, decCipher, tweakCipher)

                        // Check "VERA" magic at decrypted bytes 0..3
                        if (candidate[0] == 0x56.toByte() &&
                            candidate[1] == 0x45.toByte() &&
                            candidate[2] == 0x52.toByte() &&
                            candidate[3] == 0x41.toByte()
                        ) {
                            val expectedCrc = readBeU32(candidate, 252 - 64)
                            val crc = CRC32().apply { update(candidate, 0, 188) }.value
                            if (crc != expectedCrc) continue

                            val mkOffset = readBeU64(candidate, 108 - 64).let { if (it >= 512L) it else 131072L }
                            val volSize = readBeU64(candidate, 100 - 64).let { if (it > 0L) it else (fileSize - mkOffset * 2) }
                            val secSize = readBeU32(candidate, 128 - 64).toInt().let { if (it in setOf(512, 1024, 2048, 4096)) it else 512 }
                            val mk1 = candidate.copyOfRange(256 - 64, 288 - 64)
                            val mk2 = candidate.copyOfRange(288 - 64, 320 - 64)

                            return buildMountedVolume(ctx, info, label, mk1, mk2, mkOffset, volSize, secSize)
                        }
                    }
                }
            }
        }
        return null
    }

    private fun buildMountedVolume(
        ctx: Context,
        info: VcContainerInfo,
        hashLabel: String,
        mk1: ByteArray,
        mk2: ByteArray,
        mkOffset: Long,
        volSize: Long,
        sectorSize: Int
    ): MountedVeraCrypt {
        val uri = Uri.parse(info.uriString)

        fun readDecryptedBytes(volByteOffset: Long, len: Int): ByteArray? = runCatching {
            ctx.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                val fis = FileInputStream(pfd.fileDescriptor)
                val ch = fis.channel
                val decCipher = Cipher.getInstance("AES/ECB/NoPadding").apply {
                    init(Cipher.DECRYPT_MODE, SecretKeySpec(mk1, "AES"))
                }
                val tweakCipher = Cipher.getInstance("AES/ECB/NoPadding").apply {
                    init(Cipher.ENCRYPT_MODE, SecretKeySpec(mk2, "AES"))
                }
                val startSec = volByteOffset / 512L
                val endSec = (volByteOffset + len + 511L) / 512L
                val totalSecBytes = ((endSec - startSec) * 512L).toInt()
                val raw = ByteArray(totalSecBytes)
                ch.position(mkOffset + startSec * 512L)
                var n = 0
                while (n < totalSecBytes) {
                    val r = fis.read(raw, n, totalSecBytes - n)
                    if (r <= 0) break
                    n += r
                }
                val startUnit = (mkOffset / 512L) + startSec
                val numUnits = (totalSecBytes / 512)
                for (u in 0 until numUnits) {
                    xtsDecryptUnit(raw, u * 512, 512, startUnit + u, decCipher, tweakCipher)
                }
                val innerOff = (volByteOffset - startSec * 512L).toInt()
                raw.copyOfRange(innerOff, (innerOff + len).coerceAtMost(raw.size))
            }
        }.getOrNull()

        var partOffset = 0L
        val boot0 = readDecryptedBytes(0L, 512) ?: ByteArray(512)
        if (!isFatOrExfatBoot(boot0) && boot0.size >= 512 &&
            (boot0[510].toInt() and 0xFF) == 0x55 && (boot0[511].toInt() and 0xFF) == 0xAA
        ) {
            val lbaStart = readLeU32(boot0, 446 + 8)
            if (lbaStart > 0 && lbaStart * 512L < volSize) {
                val cand = readDecryptedBytes(lbaStart * 512L, 512)
                if (cand != null && isFatOrExfatBoot(cand)) {
                    partOffset = lbaStart * 512L
                }
            }
        }

        val boot = if (partOffset == 0L) boot0 else (readDecryptedBytes(partOffset, 512) ?: boot0)
        val oem = String(boot, 3, 8, StandardCharsets.US_ASCII)

        if (oem.startsWith("EXFAT")) {
            val parsed = parseExFat(boot, partOffset, ::readDecryptedBytes)
            if (parsed.first.isNotEmpty()) {
                return MountedVeraCrypt(info, hashLabel, ctx, mk1, mk2, mkOffset, volSize, sectorSize, parsed.first, parsed.second)
            }
        } else if (isFatOrExfatBoot(boot)) {
            val parsed = parseFat(boot, partOffset, ::readDecryptedBytes)
            if (parsed.first.isNotEmpty()) {
                return MountedVeraCrypt(info, hashLabel, ctx, mk1, mk2, mkOffset, volSize, sectorSize, parsed.first, parsed.second)
            }
        }

        val fallbackEntry = VcFileEntry(
            id = "raw_0",
            name = info.displayName.substringBeforeLast('.'),
            ext = "mp4",
            size = volSize.coerceAtLeast(0L),
            startCluster = 0L,
            contiguous = true,
            directOffset = 0L
        )
        val rawExtractor: (VcFileEntry, File) -> Boolean = { e, dest ->
            streamDecryptRange(ctx, uri, mk1, mk2, mkOffset + e.directOffset.coerceAtLeast(0L), e.size, dest)
        }
        return MountedVeraCrypt(info, hashLabel, ctx, mk1, mk2, mkOffset, volSize, sectorSize, listOf(fallbackEntry), rawExtractor)
    }

    private fun isFatOrExfatBoot(b: ByteArray): Boolean {
        if (b.size < 512) return false
        val oem = String(b, 3, 8, StandardCharsets.US_ASCII)
        if (oem.startsWith("EXFAT")) return true
        val bps = readLeU16(b, 11)
        val spc = b[13].toInt() and 0xFF
        return bps in setOf(512, 1024, 2048, 4096) && spc > 0 && (spc and (spc - 1)) == 0
    }

    private fun parseExFat(
        boot: ByteArray,
        partOffset: Long,
        readBytes: (Long, Int) -> ByteArray?
    ): Pair<List<VcFileEntry>, (VcFileEntry, File) -> Boolean> {
        val bpsShift = boot[108].toInt() and 0xFF
        val spcShift = boot[109].toInt() and 0xFF
        val bps = 1L shl bpsShift
        val clusterSize = (1L shl (bpsShift + spcShift)).toInt()
        val fatOffsetSec = readLeU32(boot, 80)
        val clusterHeapSec = readLeU32(boot, 88)
        val rootCluster = readLeU32(boot, 96)
        val heapByteOffset = partOffset + clusterHeapSec * bps
        val fatByteOffset = partOffset + fatOffsetSec * bps

        fun clusterOffset(c: Long): Long = heapByteOffset + (c - 2L) * clusterSize

        fun nextCluster(c: Long): Long {
            val b = readBytes(fatByteOffset + c * 4L, 4) ?: return 0xFFFFFFFFL
            return readLeU32(b, 0)
        }

        val out = mutableListOf<VcFileEntry>()
        fun scanDir(startCluster: Long, depth: Int) {
            if (depth > 4 || startCluster < 2) return
            var cur = startCluster
            var steps = 0
            val dirBytes = java.io.ByteArrayOutputStream()
            while (cur in 2L..0xFFFFFFF0L && steps < 64) {
                val chunk = readBytes(clusterOffset(cur), clusterSize) ?: break
                dirBytes.write(chunk)
                cur = nextCluster(cur)
                steps++
            }
            val data = dirBytes.toByteArray()
            var i = 0
            while (i + 32 <= data.size) {
                val type = data[i].toInt() and 0xFF
                if (type == 0x00) break
                if (type == 0x85 && i + 64 <= data.size) {
                    val secCount = data[i + 1].toInt() and 0xFF
                    val attr = readLeU16(data, i + 4)
                    val isDir = (attr and 0x10) != 0
                    val streamPos = i + 32
                    if ((data[streamPos].toInt() and 0xFF) == 0xC0) {
                        val flags = data[streamPos + 1].toInt() and 0xFF
                        val noFatChain = (flags and 0x02) != 0
                        val nameLen = data[streamPos + 3].toInt() and 0xFF
                        val firstClust = readLeU32(data, streamPos + 20)
                        val dataLen = readLeU64(data, streamPos + 24)
                        val sb = StringBuilder()
                        var fnIdx = streamPos + 32
                        var remChars = nameLen
                        while (remChars > 0 && fnIdx + 32 <= data.size && (data[fnIdx].toInt() and 0xFF) == 0xC1) {
                            val take = minOf(15, remChars)
                            for (c in 0 until take) {
                                val chCode = readLeU16(data, fnIdx + 2 + c * 2)
                                if (chCode != 0) sb.append(chCode.toChar())
                            }
                            remChars -= take
                            fnIdx += 32
                        }
                        val fullName = sb.toString().trim()
                        if (isDir && fullName.isNotEmpty() && !fullName.startsWith(".")) {
                            scanDir(firstClust, depth + 1)
                        } else if (!isDir && fullName.isNotEmpty() && !fullName.startsWith(".")) {
                            val ext = fullName.substringAfterLast('.', "").lowercase()
                            if (ext in VIDEO_EXTS && dataLen > 0) {
                                out += VcFileEntry(
                                    id = "exfat_${firstClust}_${out.size}",
                                    name = fullName.substringBeforeLast('.'),
                                    ext = ext,
                                    size = dataLen,
                                    startCluster = firstClust,
                                    contiguous = noFatChain,
                                    directOffset = if (noFatChain) (clusterOffset(firstClust)) else -1L
                                )
                            }
                        }
                        i += (1 + secCount) * 32
                        continue
                    }
                }
                i += 32
            }
        }
        scanDir(rootCluster, 0)

        val extractor: (VcFileEntry, File) -> Boolean = { entry, dest ->
            FileOutputStream(dest).use { fos ->
                var rem = entry.size
                var cur = entry.startCluster
                while (rem > 0 && cur >= 2L && cur < 0xFFFFFFF0L) {
                    val toRead = minOf(rem, clusterSize.toLong()).toInt()
                    val buf = readBytes(clusterOffset(cur), toRead) ?: return@use false
                    fos.write(buf, 0, toRead)
                    rem -= toRead
                    cur = if (entry.contiguous) cur + 1 else nextCluster(cur)
                }
                rem <= 0L
            }
        }
        return out to extractor
    }

    private fun parseFat(
        boot: ByteArray,
        partOffset: Long,
        readBytes: (Long, Int) -> ByteArray?
    ): Pair<List<VcFileEntry>, (VcFileEntry, File) -> Boolean> {
        val bps = readLeU16(boot, 11).coerceAtLeast(512)
        val spc = (boot[13].toInt() and 0xFF).coerceAtLeast(1)
        val clusterSize = bps * spc
        val reservedSec = readLeU16(boot, 14)
        val numFats = (boot[16].toInt() and 0xFF).coerceAtLeast(1)
        val rootEntries = readLeU16(boot, 17)
        val spf16 = readLeU16(boot, 22)
        val spf32 = readLeU32(boot, 36)
        val isFat32 = spf16 == 0 && spf32 > 0
        val sectorsPerFat = if (isFat32) spf32 else spf16.toLong()
        val rootDirSectors = ((rootEntries * 32) + (bps - 1)) / bps
        val firstDataSector = reservedSec + (numFats * sectorsPerFat) + rootDirSectors
        val fatByteOffset = partOffset + reservedSec.toLong() * bps
        val dataByteOffset = partOffset + firstDataSector * bps
        val rootCluster = if (isFat32) readLeU32(boot, 44) else 0L

        fun clusterOffset(c: Long): Long = dataByteOffset + (c - 2L) * clusterSize

        fun nextCluster(c: Long): Long {
            return if (isFat32) {
                val b = readBytes(fatByteOffset + c * 4L, 4) ?: return 0x0FFFFFFFL
                readLeU32(b, 0) and 0x0FFFFFFFL
            } else {
                val b = readBytes(fatByteOffset + c * 2L, 2) ?: return 0xFFFFL
                val v = readLeU16(b, 0).toLong()
                if (v >= 0xFFF8L) 0x0FFFFFFFL else v
            }
        }

        val out = mutableListOf<VcFileEntry>()
        fun parseDirEntries(data: ByteArray, depth: Int) {
            val lfnParts = sortedMapOf<Int, String>()
            var i = 0
            while (i + 32 <= data.size) {
                val firstByte = data[i].toInt() and 0xFF
                if (firstByte == 0x00) break
                if (firstByte == 0xE5) {
                    lfnParts.clear()
                    i += 32
                    continue
                }
                val attr = data[i + 11].toInt() and 0xFF
                if (attr == 0x0F) {
                    val ord = firstByte and 0x1F
                    val sb = StringBuilder()
                    val offsets = intArrayOf(1, 3, 5, 7, 9, 14, 16, 18, 20, 22, 24, 28, 30)
                    for (off in offsets) {
                        val ch = readLeU16(data, i + off)
                        if (ch == 0x0000 || ch == 0xFFFF) break
                        sb.append(ch.toChar())
                    }
                    lfnParts[ord] = sb.toString()
                    i += 32
                    continue
                }
                val isVolId = (attr and 0x08) != 0
                val isDir = (attr and 0x10) != 0
                val fullName = if (lfnParts.isNotEmpty()) {
                    lfnParts.values.joinToString("").trim()
                } else {
                    val base = String(data, i, 8, StandardCharsets.US_ASCII).trim()
                    val ext = String(data, i + 8, 3, StandardCharsets.US_ASCII).trim()
                    if (ext.isNotEmpty()) "$base.$ext" else base
                }
                lfnParts.clear()

                val hiClust = if (isFat32) readLeU16(data, i + 20).toLong() else 0L
                val loClust = readLeU16(data, i + 26).toLong()
                val startClust = (hiClust shl 16) or loClust
                val fileSize = readLeU32(data, i + 28)

                if (!isVolId && fullName.isNotEmpty() && !fullName.startsWith(".")) {
                    if (isDir && depth < 3 && startClust >= 2L) {
                        val sub = java.io.ByteArrayOutputStream()
                        var c = startClust
                        var steps = 0
                        while (c in 2L..0x0FFFFFF0L && steps < 64) {
                            val b = readBytes(clusterOffset(c), clusterSize) ?: break
                            sub.write(b)
                            c = nextCluster(c)
                            steps++
                        }
                        parseDirEntries(sub.toByteArray(), depth + 1)
                    } else if (!isDir && fileSize > 0 && startClust >= 2L) {
                        val ext = fullName.substringAfterLast('.', "").lowercase()
                        if (ext in VIDEO_EXTS) {
                            out += VcFileEntry(
                                id = "fat_${startClust}_${out.size}",
                                name = fullName.substringBeforeLast('.'),
                                ext = ext,
                                size = fileSize,
                                startCluster = startClust
                            )
                        }
                    }
                }
                i += 32
            }
        }

        if (isFat32) {
            val rootStream = java.io.ByteArrayOutputStream()
            var c = rootCluster
            var steps = 0
            while (c in 2L..0x0FFFFFF0L && steps < 64) {
                val b = readBytes(clusterOffset(c), clusterSize) ?: break
                rootStream.write(b)
                c = nextCluster(c)
                steps++
            }
            parseDirEntries(rootStream.toByteArray(), 0)
        } else {
            val rootOffset = partOffset + (reservedSec + numFats * sectorsPerFat) * bps
            val rootBytes = readBytes(rootOffset, (rootEntries * 32).coerceAtLeast(512))
            if (rootBytes != null) parseDirEntries(rootBytes, 0)
        }

        val extractor: (VcFileEntry, File) -> Boolean = { entry, dest ->
            FileOutputStream(dest).use { fos ->
                var rem = entry.size
                var cur = entry.startCluster
                while (rem > 0 && cur in 2L..0x0FFFFFF0L) {
                    val toRead = minOf(rem, clusterSize.toLong()).toInt()
                    val buf = readBytes(clusterOffset(cur), toRead) ?: return@use false
                    fos.write(buf, 0, toRead)
                    rem -= toRead
                    cur = nextCluster(cur)
                }
                rem <= 0L
            }
        }
        return out to extractor
    }

    private fun streamDecryptRange(
        ctx: Context,
        uri: Uri,
        mk1: ByteArray,
        mk2: ByteArray,
        startByteOffset: Long,
        length: Long,
        dest: File
    ): Boolean = runCatching {
        ctx.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
            val fis = FileInputStream(pfd.fileDescriptor)
            val ch = fis.channel
            val decCipher = Cipher.getInstance("AES/ECB/NoPadding").apply {
                init(Cipher.DECRYPT_MODE, SecretKeySpec(mk1, "AES"))
            }
            val tweakCipher = Cipher.getInstance("AES/ECB/NoPadding").apply {
                init(Cipher.ENCRYPT_MODE, SecretKeySpec(mk2, "AES"))
            }
            FileOutputStream(dest).use { fos ->
                val chunkBytes = 256 * 1024
                val buf = ByteArray(chunkBytes)
                var curUnit = startByteOffset / 512L
                ch.position(curUnit * 512L)
                var rem = length
                while (rem > 0) {
                    val toRead = minOf(rem, chunkBytes.toLong()).toInt()
                    val alignedRead = ((toRead + 511) / 512) * 512
                    var n = 0
                    while (n < alignedRead) {
                        val r = fis.read(buf, n, alignedRead - n)
                        if (r <= 0) break
                        n += r
                    }
                    if (n <= 0) break
                    val units = n / 512
                    for (u in 0 until units) {
                        xtsDecryptUnit(buf, u * 512, 512, curUnit + u, decCipher, tweakCipher)
                    }
                    curUnit += units
                    val writeLen = minOf(toRead, n)
                    fos.write(buf, 0, writeLen)
                    rem -= writeLen
                }
            }
            true
        } ?: false
    }.getOrDefault(false)
}
