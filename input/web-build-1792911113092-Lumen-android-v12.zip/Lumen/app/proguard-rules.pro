# libmpv calls back into these classes from native code, so they must keep their names
-keep class dev.jdtech.mpv.** { *; }
-keepclasseswithmembernames class * { native <methods>; }
-dontwarn **
