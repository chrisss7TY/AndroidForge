package app.lumen

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.view.Display
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import dev.jdtech.mpv.MPVLib
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.roundToInt

@Immutable
data class Vid(val uri: Uri, val name: String, val file: String, val dur: Long, val h: Int)

@Immutable
data class Cfg(
    val theme: String = "dark", val skip: Int = 10, val speed: Float = 1f, val hide: Int = 3,
    val resume: Boolean = true, val hw: Boolean = true, val grid: Int = 160, val sort: String = "new", val autoLock: Boolean = true,
    val accent: String = "mint", val filter: String = "off", val info: Boolean = false, val showNames: Boolean = true
) {
    fun save(sp: SharedPreferences) = sp.edit().putString("theme", theme).putInt("skip", skip).putFloat("speed", speed).putInt("hide", hide)
        .putBoolean("resume", resume).putBoolean("hw", hw).putInt("grid", grid).putString("sort", sort).putBoolean("autolock", autoLock)
        .putString("accent", accent).putString("filter", filter).putBoolean("info", info).putBoolean("names", showNames).apply()

    companion object {
        fun load(sp: SharedPreferences) = Cfg(
            sp.getString("theme", "dark") ?: "dark", sp.getInt("skip", 10), sp.getFloat("speed", 1f), sp.getInt("hide", 3),
            sp.getBoolean("resume", true), sp.getBoolean("hw", true), sp.getInt("grid", 160), sp.getString("sort", "new") ?: "new", sp.getBoolean("autolock", true),
            sp.getString("accent", "mint") ?: "mint", sp.getString("filter", "off") ?: "off", sp.getBoolean("info", false), sp.getBoolean("names", true)
        )
    }
}

private val ACCENTS = listOf(
    "mint" to (0xFF8FD9C9 to 0xFF17695B), "violet" to (0xFFB69CFF to 0xFF5B3FC4), "rose" to (0xFFFF9DB5 to 0xFFB3244F),
    "amber" to (0xFFFFC66B to 0xFF9A6200), "sky" to (0xFF8CC8FF to 0xFF1B64A8), "lime" to (0xFFC5E86C to 0xFF5B7A0A), "coral" to (0xFFFF9A85 to 0xFFB8421F)
)
private val THEMES = listOf("dark" to "Dark", "amoled" to "AMOLED", "midnight" to "Midnight", "forest" to "Forest", "mocha" to "Mocha", "light" to "Light")
private fun bgOf(t: String): Pair<Long, Long> = when (t) {
    "amoled" -> 0xFF000000 to 0xFF111213; "midnight" -> 0xFF080C1A to 0xFF121A30
    "forest" -> 0xFF08110C to 0xFF11201A; "mocha" -> 0xFF110D0B to 0xFF1E1713
    else -> 0xFF0A0F11 to 0xFF121A1D
}
private val FILTERS = listOf("off" to "Off", "smooth" to "HDR Smooth", "strong" to "HDR Strong", "cine" to "Cinematic")

/** Look overlays: a translucent tint over the video layer. mpv never processes it, so no extra GPU/CPU work per frame (same trick as the HTML player). */
private fun tintOf(f: String): List<Color>? = when (f) {
    "smooth" -> listOf(Color(0x0D38BDF8), Color(0x2E000000))
    "strong" -> listOf(Color(0x177CACF8), Color(0x52000000))
    "cine" -> listOf(Color(0x14FBBF24), Color(0x4D000000))
    else -> null
}

private class Snap(val pos: Double?, val dur: Double?, val paused: Boolean?, val info: String?)

private class PState { @Volatile var alive = true; @Volatile var loaded = false; @Volatile var target = ""; val lock = Any() }

/** Wrapper so the video list counts as stable and Library can be skipped when nothing changed. */
@Immutable
class VList(val v: List<Vid>)

/**
 * Every mpv call that can block (create/init/destroy, seek, pause, zoom...) runs on this ONE thread, in order.
 * The UI thread never waits for mpv, so taps, scrubbing and opening/closing the player stay instant.
 */
private val mpvQ = Executors.newSingleThreadExecutor { r -> Thread(r, "lumen-mpv") }
@Volatile private var mpvUp = false     // mpv is created, initialised and not being torn down
@Volatile private var mpvMade = false   // MPVLib.create() ran and destroy() hasn't yet

private fun mpv(block: () -> Unit) {
    mpvQ.execute { if (mpvUp) try { block() } catch (e: Throwable) { } }
}

/** Keeps only the newest value while mpv is busy (scrubbing, pinch-zoom): no backlog, no lag after release. */
private fun <T : Any> mpvLatest(slot: AtomicReference<T?>, v: T, run: (T) -> Unit) {
    if (slot.getAndSet(v) == null) mpvQ.execute {
        val x = slot.getAndSet(null)
        if (x != null && mpvUp) try { run(x) } catch (e: Throwable) { }
    }
}
private val scrubSlot = AtomicReference<String?>(null)
private val zoomSlot = AtomicReference<DoubleArray?>(null)

/** A callback whose identity never changes, so composables receiving it can be skipped. */
@Composable private fun <A> stableCb(f: (A) -> Unit): (A) -> Unit {
    val s = rememberUpdatedState(f)
    return remember { { a: A -> s.value(a) } }
}
@Composable private fun stableCb0(f: () -> Unit): () -> Unit {
    val s = rememberUpdatedState(f)
    return remember { { s.value() } }
}

/** Keeps a tab composed once built. Hidden tabs are measured but not placed: not drawn, not touchable, no rebuild when shown. */
@Composable private fun TabHost(show: Boolean, content: @Composable () -> Unit) {
    Layout({ Box(Modifier.fillMaxSize()) { content() } }) { ms, c ->
        val ps = ms.map { it.measure(c) }
        layout(c.maxWidth, c.maxHeight) { if (show) ps.forEach { it.place(0, 0) } }
    }
}

private val RATES = listOf(1f, 1.25f, 1.5f, 2f, .5f, .75f)
private val THUMBS = object : LruCache<Uri, ImageBitmap>((Runtime.getRuntime().maxMemory() / 8).toInt()) {
    override fun sizeOf(key: Uri, value: ImageBitmap): Int = value.asAndroidBitmap().byteCount
}
private val thumbDisp = Executors.newFixedThreadPool(2).asCoroutineDispatcher()

fun fmt(s: Double) = "%d:%02d".format((s / 60).toInt(), (s % 60).toInt())

private fun loadThumb(ctx: Context, uri: Uri): ImageBitmap? {
    Process.setThreadPriority(Process.THREAD_PRIORITY_DEFAULT + 4)   // below the UI thread, but not in the throttled background group
    val f = File(File(ctx.cacheDir, "thumbs").apply { mkdirs() }, "${uri.toString().hashCode()}.jpg")
    if (f.exists()) BitmapFactory.decodeFile(f.path)?.let { return it.asImageBitmap() }
    val b = frameOf(ctx, uri, 560)
    if (b != null) {
        runCatching { f.outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 85, it) } }
        return b.asImageBitmap()
    }
    if (Build.VERSION.SDK_INT >= 29) {
        try { return ctx.contentResolver.loadThumbnail(uri, Size(640, 360), null).asImageBitmap() } catch (e: Exception) { }
    }
    return null
}

@Composable fun BoxScope.Badges(h: Int, dur: Long) {
    val k = h >= 2000
    if (h > 0) Text(
        if (k) "4K" else "${h}p",
        Modifier.align(Alignment.BottomStart).padding(8.dp).clip(RoundedCornerShape(7.dp)).background(if (k) Color(0xFFFFC66B) else Color(0x99000000)).padding(horizontal = 7.dp, vertical = 3.dp),
        fontSize = 11.sp, color = if (k) Color(0xFF2B1B00) else Color.White, fontWeight = FontWeight.SemiBold
    )
    Text(
        fmt(dur / 1000.0),
        Modifier.align(Alignment.BottomEnd).padding(8.dp).clip(RoundedCornerShape(7.dp)).background(Color(0x99000000)).padding(horizontal = 7.dp, vertical = 3.dp),
        fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.SemiBold
    )
}

class MainActivity : ComponentActivity() {
    private var opened by mutableStateOf<Uri?>(null)
    private var vtick by mutableIntStateOf(0)
    private var live = false
    private var autoLock = true
    private var suppressLock = false
    private var tempPlay: File? = null
    private val vault by lazy { Vault(this) }
    private val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        @Suppress("DEPRECATION") run { window.statusBarColor = android.graphics.Color.TRANSPARENT; window.navigationBarColor = android.graphics.Color.TRANSPARENT }
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        runCatching {   // run the UI at the panel's highest refresh rate instead of 60 Hz
            @Suppress("DEPRECATION") val d = windowManager.defaultDisplay
            val cur = d.mode
            sameRes = d.supportedModes.filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
            maxMode = sameRes.maxByOrNull { it.refreshRate }
            setMode(null)
        }
        File(cacheDir, "play").deleteRecursively()
        opened = intent?.data
        setContent { App() }
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); i.data?.let { opened = it } }

    private var sameRes: List<Display.Mode> = emptyList()
    private var maxMode: Display.Mode? = null

    /** null = the panel's fastest mode (smooth UI). */
    private fun setMode(m: Display.Mode?) {
        val t = m ?: maxMode ?: return
        runCatching {
            val lp = window.attributes
            if (lp.preferredDisplayModeId != t.modeId) {
                lp.preferredDisplayModeId = t.modeId; lp.preferredRefreshRate = t.refreshRate
                window.attributes = lp
            }
        }
    }

    /** Panel mode whose refresh rate is a whole multiple of the video's fps (24 -> 120, 30 -> 60...), so frames show evenly instead of judder. */
    private fun modeFor(fps: Double): Display.Mode? {
        val hits = sameRes.filter { m -> val n = (m.refreshRate / fps).roundToInt(); n >= 1 && abs(m.refreshRate / fps - n) < 0.015 * n }
        return hits.filter { it.refreshRate >= 47f }.minByOrNull { it.refreshRate } ?: hits.minByOrNull { it.refreshRate }
    }

    override fun onStop() {
        super.onStop()
        if (live) mpv { MPVLib.setPropertyBoolean("pause", true) }
        if (autoLock && !suppressLock && vault.unlocked) { vault.lock(); vtick++ }
    }

    override fun onDestroy() { super.onDestroy(); if (isFinishing) File(cacheDir, "play").deleteRecursively() }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private suspend fun scan(): List<Vid> = withContext(Dispatchers.IO) {
        val out = ArrayList<Vid>(); val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        contentResolver.query(base, arrayOf("_id", "_display_name", "duration", "height"), null, null, "date_added DESC")?.use {
            while (it.moveToNext()) {
                val file = it.getString(1) ?: "video.mp4"
                out += Vid(ContentUris.withAppendedId(base, it.getLong(0)), file.substringBeforeLast('.'), file, it.getLong(2), it.getInt(3))
            }
        }
        out
    }

    @Composable fun App() {
        val sp = remember { getSharedPreferences("s", 0) }
        var cfg by remember { mutableStateOf(Cfg.load(sp)) }
        var tab by remember { mutableIntStateOf(0) }
        var list by remember { mutableStateOf(listOf<Vid>()) }
        var prep by remember { mutableStateOf(false) }
        var built by remember { mutableStateOf(setOf(0)) }   // tabs that have been composed; they stay alive afterwards
        val unlocked = vtick >= 0 && vault.unlocked
        val scope = rememberCoroutineScope()
        val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) scope.launch { list = scan() } }
        val del = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { suppressLock = false; scope.launch { list = scan() } }
        LaunchedEffect(Unit) { if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) list = scan() else ask.launch(perm) }
        // Build the other tabs once, one at a time, shortly after start-up, so switching to them later is instant
        LaunchedEffect(Unit) { delay(600); built = built + 2; delay(400); built = built + 1 }
        LaunchedEffect(tab) { built = built + tab }
        SideEffect { autoLock = cfg.autoLock }

        val light = cfg.theme == "light"
        val cs = remember(cfg.theme, cfg.accent) {
            val lt = cfg.theme == "light"
            val acc = ACCENTS.firstOrNull { it.first == cfg.accent } ?: ACCENTS[0]
            val prim = Color(if (lt) acc.second.second else acc.second.first)
            val (bgc, sfc) = bgOf(cfg.theme)
            if (!lt) darkColorScheme(
                primary = prim, onPrimary = Color.Black, background = Color(bgc), surface = Color(sfc),
                onBackground = Color(0xFFE8F0EE), onSurface = Color(0xFFE8F0EE), onSurfaceVariant = Color(0xFF9DB0AC),
                secondaryContainer = prim.copy(alpha = .28f).compositeOver(Color(sfc)), onSecondaryContainer = Color(0xFFE8F0EE)
            ) else lightColorScheme(
                primary = prim, onPrimary = Color.White, background = Color(0xFFF3F7F6), surface = Color.White,
                onBackground = Color(0xFF101514), onSurface = Color(0xFF101514), onSurfaceVariant = Color(0xFF55615E),
                secondaryContainer = prim.copy(alpha = .18f).compositeOver(Color.White), onSecondaryContainer = Color(0xFF101514)
            )
        }
        LaunchedEffect(light) {
            val c = WindowInsetsControllerCompat(window, window.decorView)
            c.isAppearanceLightStatusBars = light; c.isAppearanceLightNavigationBars = light
        }
        val shown = remember(list, cfg.sort) {
            VList(when (cfg.sort) { "name" -> list.sortedBy { it.name.lowercase() }; "dur" -> list.sortedByDescending { it.dur }; else -> list })
        }
        fun move(v: Vid) {
            if (!vault.unlocked) { tab = 1; toast("Unlock your vault first"); return }
            scope.launch {
                toast("Encrypting “${v.name}”…")
                val ok = withContext(Dispatchers.IO) { runCatching { vault.add(v.uri, v.file) }.isSuccess }
                vtick++
                if (!ok) { toast("Couldn’t add to vault"); return@launch }
                if (Build.VERSION.SDK_INT >= 30) {
                    suppressLock = true
                    del.launch(IntentSenderRequest.Builder(MediaStore.createDeleteRequest(contentResolver, listOf(v.uri)).intentSender).build())
                } else toast("Added to vault. Original kept; delete it manually.")
            }
        }
        fun playVault(v: VItem) {
            scope.launch {
                prep = true
                val f = withContext(Dispatchers.IO) { runCatching { vault.playFile(v) }.getOrNull() }
                prep = false
                if (f == null) toast("Couldn’t open video") else { tempPlay = f; opened = Uri.fromFile(f) }
            }
        }
        // identity-stable callbacks: children whose inputs didn't change are skipped instead of rebuilt
        val onOpen = stableCb<Uri> { opened = it }
        val onMove = stableCb<Vid> { move(it) }
        val onPlayVault = stableCb<VItem> { playVault(it) }
        val onNote = stableCb<String> { toast(it) }
        val onPick = stableCb<Boolean> { suppressLock = it }
        val onChange = stableCb0 { vtick++ }
        val onLock = stableCb0 { vault.lock(); vtick++ }
        val onUpd = stableCb<Cfg> { cfg = it; it.save(sp) }
        val navTabs = remember { listOf(Icons.Rounded.VideoLibrary to "Library", Icons.Rounded.Lock to "Vault", Icons.Rounded.Tune to "Settings") }

        MaterialTheme(cs) {
            Surface(Modifier.fillMaxSize(), color = cs.background, contentColor = cs.onBackground) {
                Box(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 18.dp)) {
                        Text(when (tab) { 0 -> "Library"; 1 -> "Vault"; else -> "Settings" }, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 24.dp, bottom = 12.dp))
                        Box(Modifier.weight(1f).fillMaxWidth()) {
                            TabHost(tab == 0) { Library(shown, cfg.grid, cfg.showNames, onOpen, onMove) }
                            if (1 in built) TabHost(tab == 1) { VaultScreen(vault, vtick, onChange, onPlayVault, onPick, onNote) }
                            if (2 in built) TabHost(tab == 2) { Settings(cfg, unlocked, onUpd, onLock) }
                        }
                    }
                    GlassNav(tab, navTabs, { tab = it }, Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 14.dp))
                    opened?.let { u -> key(u) { Player(u, cfg) { opened = null; tempPlay?.delete(); tempPlay = null } } }
                    if (prep) Box(Modifier.fillMaxSize().background(Color(0xAA000000)).pointerInput(Unit) { detectTapGestures { } }, contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                }
            }
        }
    }

    @Composable fun Player(uri: Uri, cfg: Cfg, onClose: () -> Unit) {
        val ctx = LocalContext.current; val sp = remember { ctx.getSharedPreferences("s", 0) }
        val st = remember { PState() }
        var ready by remember { mutableStateOf(false) }
        var pos by remember { mutableDoubleStateOf(0.0) }; var dur by remember { mutableDoubleStateOf(1.0) }
        var paused by remember { mutableStateOf(false) }; var ui by remember { mutableStateOf(true) }
        var zoom by remember { mutableFloatStateOf(1f) }; var px by remember { mutableFloatStateOf(0f) }; var py by remember { mutableFloatStateOf(0f) }
        var w by remember { mutableIntStateOf(1) }; var speed by remember { mutableFloatStateOf(cfg.speed) }; var drag by remember { mutableStateOf<Float?>(null) }
        var filter by remember { mutableStateOf(cfg.filter) }; var info by remember { mutableStateOf("") }
        val skip = cfg.skip

        DisposableEffect(Unit) {
            live = true; window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            val bars = WindowInsetsControllerCompat(window, window.decorView)
            bars.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE; bars.hide(WindowInsetsCompat.Type.systemBars())
            val appCtx = ctx.applicationContext
            val hw = cfg.hw; val speed0 = cfg.speed
            val resumeAt = if (cfg.resume) sp.getFloat("p:$uri", 0f) else 0f
            // Start-up (mpv create/init, opening the file) happens on the mpv thread: the player appears instantly and the UI never freezes.
            mpvQ.execute {
                if (!st.alive) return@execute
                try {
                    st.target = if (uri.scheme == "file") uri.path!! else {
                        val fd = runCatching { appCtx.contentResolver.openFileDescriptor(uri, "r")?.detachFd() }.getOrNull()
                        if (fd != null) "fd://$fd" else uri.toString()
                    }
                    MPVLib.create(appCtx); mpvMade = true
                    val opts = mapOf("profile" to "fast", "vo" to "gpu", "gpu-context" to "android", "opengl-es" to "yes",
                        "hwdec" to (if (hw) "mediacodec,mediacodec-copy" else "no"), "hwdec-codecs" to "h264,hevc,mpeg4,mpeg2video,vp8,vp9,av1",
                        // 4K on phones without a 4K decoder = software decode. Use every fast core, skip the deblocking filter (invisible at screen size) and drop frames BEFORE decoding when behind.
                        "vd-lavc-threads" to minOf(Runtime.getRuntime().availableProcessors(), 8).toString(), "vd-lavc-skiploopfilter" to "all", "vd-lavc-fast" to "yes", "vd-lavc-dr" to "yes",
                        "scale" to "bilinear", "dscale" to "bilinear", "cscale" to "bilinear", "correct-downscaling" to "no", "sigmoid-upscaling" to "no",
                        "deband" to "no", "dither-depth" to "no", "interpolation" to "no", "blend-subtitles" to "no", "hdr-compute-peak" to "no", "tone-mapping" to "hable",
                        "opengl-pbo" to "yes", "framedrop" to "decoder+vo", "video-sync" to "audio", "cache" to "yes", "demuxer-max-bytes" to "96MiB", "demuxer-readahead-secs" to "20",
                        "ao" to "audiotrack,opensles", "keep-open" to "yes", "speed" to speed0.toString())
                    opts.forEach { (k, v) -> MPVLib.setOptionString(k, v) }
                    if (resumeAt > 5f) MPVLib.setOptionString("start", resumeAt.toString())
                    MPVLib.init()
                    if (st.alive) { mpvUp = true; ready = true }   // the SurfaceView is only created now; the file loads once its surface exists
                } catch (e: Throwable) {
                    runOnUiThread { toast("Couldn’t start the player"); onClose() }
                }
            }
            onDispose {
                st.alive = false; mpvUp = false
                live = false; window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); bars.show(WindowInsetsCompat.Type.systemBars())
                setMode(null)
                val key = "p:$uri"
                // Teardown can take a few hundred ms; do it off the UI thread. Read the real position first (the polled one is stale while controls are hidden).
                mpvQ.execute {
                    if (!mpvMade) return@execute
                    try {
                        synchronized(st.lock) {   // waits for an in-flight poll to finish
                            val p = MPVLib.getPropertyDouble("time-pos"); val d = MPVLib.getPropertyDouble("duration")
                            sp.edit().apply { if (p != null && d != null && p > 5 && p < d - 10) putFloat(key, p.toFloat()) else remove(key) }.apply()
                            MPVLib.command(arrayOf("stop")); MPVLib.detachSurface(); MPVLib.destroy()
                        }
                    } catch (e: Throwable) { } finally { mpvMade = false; mpvUp = false }
                }
            }
        }
        // Only poll while the controls are visible: no recomposition during plain playback
        LaunchedEffect(ui, ready) {
            var n = 0
            while (ui && ready && st.alive) {
                val wantInfo = cfg.info && n % 4 == 0; n++
                // mpv calls can block while it is busy, so never make them on the UI thread
                val r = withContext(Dispatchers.Default) {
                    synchronized(st.lock) {
                        if (!st.alive || !mpvUp) null else Snap(
                            MPVLib.getPropertyDouble("time-pos"), MPVLib.getPropertyDouble("duration"), MPVLib.getPropertyBoolean("pause"),
                            if (wantInfo) {
                                fun p(k: String) = MPVLib.getPropertyString(k) ?: "?"
                                "hw: ${p("hwdec-current")} · ${p("video-format")} ${p("width")}x${p("height")} · ${p("container-fps").take(6)}fps · dropped dec ${p("decoder-frame-drop-count")} / vo ${p("frame-drop-count")}"
                            } else null
                        )
                    }
                }
                if (r != null) {
                    if (drag == null) pos = r.pos ?: pos
                    dur = r.dur ?: dur; paused = r.paused ?: false
                    r.info?.let { info = it }
                }
                delay(250)
            }
        }
        // Once the video's frame rate is known, switch the panel to a refresh rate that is a whole multiple of it (even frame pacing)
        LaunchedEffect(ready) {
            if (!ready) return@LaunchedEffect
            repeat(40) {
                delay(250)
                val fps = withContext(Dispatchers.Default) { synchronized(st.lock) { if (st.alive && mpvUp) MPVLib.getPropertyDouble("container-fps") else null } }
                if (!st.alive) return@LaunchedEffect
                if (fps != null && fps > 1.0) { setMode(modeFor(fps)); return@LaunchedEffect }
            }
        }
        LaunchedEffect(ui, paused) { if (ui && !paused && cfg.hide > 0) { delay(cfg.hide * 1000L); ui = false } }
        fun seek(s: Int) { mpv { MPVLib.command(arrayOf("seek", s.toString(), "relative")) } }
        fun applyZoom() {
            mpvLatest(zoomSlot, doubleArrayOf(ln(zoom.toDouble()) / ln(2.0), (px / w).toDouble(), (py / w).toDouble())) {
                MPVLib.setPropertyDouble("video-zoom", it[0]); MPVLib.setPropertyDouble("video-pan-x", it[1]); MPVLib.setPropertyDouble("video-pan-y", it[2])
            }
        }
        BackHandler(onBack = onClose)
        Box(Modifier.fillMaxSize().background(Color.Black).onSizeChanged { w = it.width.coerceAtLeast(1) }
            .pointerInput(Unit) { detectTransformGestures { _, pan, z, _ ->
                val nz = (zoom * z).coerceIn(1f, 6f)
                if (nz > 1f) { px += pan.x; py += pan.y } else { px = 0f; py = 0f }
                if (nz != zoom || nz > 1f) { zoom = nz; applyZoom() } } }
            .pointerInput(skip) { detectTapGestures(onDoubleTap = { seek(if (it.x < size.width / 2) -skip else skip) }, onTap = { ui = !ui }) }) {
            if (ready) AndroidView({ c -> SurfaceView(c).apply { holder.addCallback(object : SurfaceHolder.Callback {
                override fun surfaceCreated(h: SurfaceHolder) {
                    if (!st.alive || !mpvUp) return
                    val sf = h.surface
                    mpv {
                        if (!sf.isValid) return@mpv
                        MPVLib.attachSurface(sf)
                        MPVLib.setOptionString("force-window", "yes")
                        if (!st.loaded) { st.loaded = true; MPVLib.command(arrayOf("loadfile", st.target)) } else MPVLib.setPropertyString("vo", "gpu")
                    }
                }
                override fun surfaceChanged(h: SurfaceHolder, f: Int, a: Int, b: Int) { if (st.alive && mpvUp) mpv { MPVLib.setPropertyString("android-surface-size", "${a}x$b") } }
                // must finish before the surface goes away, so this one stays synchronous
                override fun surfaceDestroyed(h: SurfaceHolder) {
                    if (!st.alive || !mpvUp) return
                    MPVLib.setPropertyString("vo", "null"); MPVLib.setOptionString("force-window", "no"); MPVLib.detachSurface()
                } }) } }, Modifier.fillMaxSize())
            tintOf(filter)?.let { t -> Box(Modifier.fillMaxSize().background(Brush.radialGradient(t))) }
            if (ui) Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x99000000), Color.Transparent, Color(0xB3000000)))).statusBarsPadding().navigationBarsPadding().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClose) { Icon(Icons.Rounded.ArrowBackIosNew, null, tint = Color.White) }
                    if (cfg.info) Text(info, Modifier.weight(1f).padding(start = 8.dp), color = Color.White.copy(.85f), fontSize = 10.sp, lineHeight = 13.sp)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ seek(-skip) }) { Icon(Icons.Rounded.Replay10, null, tint = Color.White, modifier = Modifier.size(36.dp)) }
                    Spacer(Modifier.width(24.dp))
                    FilledIconButton({ val np = !paused; paused = np; mpv { MPVLib.setPropertyBoolean("pause", np) } }, Modifier.size(76.dp), colors = IconButtonDefaults.filledIconButtonColors(Color.White, Color.Black)) { Icon(if (paused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause, null, Modifier.size(40.dp)) }
                    Spacer(Modifier.width(24.dp))
                    IconButton({ seek(skip) }) { Icon(Icons.Rounded.Forward10, null, tint = Color.White, modifier = Modifier.size(36.dp)) }
                }
                Column {
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FILTERS.forEach { (k, n) ->
                            val on = filter == k
                            Text(n, Modifier.clip(RoundedCornerShape(50)).background(if (on) Color.White else Color(0x33FFFFFF)).clickable { filter = k }.padding(horizontal = 14.dp, vertical = 7.dp),
                                color = if (on) Color.Black else Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    // Scrub on keyframes (instant, newest position only), land exactly on release
                    Slider(drag ?: (pos / dur).toFloat().coerceIn(0f, 1f), { drag = it; mpvLatest(scrubSlot, (it * dur).toString()) { s -> MPVLib.command(arrayOf("seek", s, "absolute+keyframes")) } },
                        onValueChangeFinished = { drag?.let { f -> val s = (f * dur).toString(); mpv { MPVLib.command(arrayOf("seek", s, "absolute+exact")) } }; drag = null })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${fmt(pos)} / ${fmt(dur)}", color = Color.White, fontSize = 12.sp); Spacer(Modifier.weight(1f))
                        TextButton({ speed = RATES[(RATES.indexOf(speed) + 1) % RATES.size]; val sp2 = speed.toDouble(); mpv { MPVLib.setPropertyDouble("speed", sp2) } }) { Text("${speed}×", color = Color.White) }
                    }
                }
            }
        }
    }
}

@Composable fun Library(list: VList, grid: Int, showNames: Boolean, onOpen: (Uri) -> Unit, onVault: (Vid) -> Unit) {
    if (list.v.isEmpty()) Text("No videos found", color = MaterialTheme.colorScheme.onSurfaceVariant)
    LazyVerticalGrid(GridCells.Adaptive(grid.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(if (showNames) 18.dp else 14.dp), contentPadding = PaddingValues(bottom = 120.dp)) {
        items(list.v, key = { it.uri }, contentType = { 0 }) { v -> LibCard(v, showNames, onOpen, onVault) }
    }
}

@Composable private fun LibCard(v: Vid, showNames: Boolean, onOpen: (Uri) -> Unit, onVault: (Vid) -> Unit) {
    val ctx = LocalContext.current
    val thumb by produceState<ImageBitmap?>(THUMBS.get(v.uri), v.uri) {
        if (value == null) value = withContext(thumbDisp) { loadThumb(ctx, v.uri) }?.also { THUMBS.put(v.uri, it) }
    }
    var menu by remember { mutableStateOf(false) }
    Column {
        Box(Modifier.fillMaxWidth().aspectRatio(16 / 9f).clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface).clickable { onOpen(v.uri) }) {
            thumb?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
            Badges(v.h, v.dur)
            Box(Modifier.align(Alignment.TopEnd).padding(6.dp)) {
                Box(Modifier.size(28.dp).clip(CircleShape).background(Color(0x66000000)).clickable { menu = true }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.MoreVert, null, Modifier.size(18.dp), tint = Color.White)
                }
                DropdownMenu(menu, { menu = false }) { DropdownMenuItem({ Text("Move to vault") }, { menu = false; onVault(v) }) }
            }
        }
        if (showNames) Text(v.name, Modifier.padding(top = 6.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable fun Settings(c: Cfg, unlocked: Boolean, upd: (Cfg) -> Unit, lockNow: () -> Unit) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 130.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SectionTitle("Appearance")
        Lbl("Theme"); Chips(THEMES, c.theme) { upd(c.copy(theme = it)) }
        Lbl("Accent colour"); Swatches(c.accent, c.theme == "light") { upd(c.copy(accent = it)) }
        Lbl("Library grid"); Chips(listOf(130 to "Compact", 160 to "Comfortable", 220 to "Large"), c.grid) { upd(c.copy(grid = it)) }
        SwitchRow("Show file names in library", "Hides the title under each video", c.showNames) { upd(c.copy(showNames = it)) }
        Lbl("Sort by"); Chips(listOf("new" to "Newest", "name" to "Name", "dur" to "Longest"), c.sort) { upd(c.copy(sort = it)) }
        SectionTitle("Playback")
        Lbl("Skip interval"); Chips(listOf(5 to "5s", 10 to "10s", 15 to "15s", 30 to "30s"), c.skip) { upd(c.copy(skip = it)) }
        Lbl("Default speed"); Chips(listOf(.5f to "0.5×", 1f to "1×", 1.25f to "1.25×", 1.5f to "1.5×", 2f to "2×"), c.speed) { upd(c.copy(speed = it)) }
        Lbl("Hide controls after"); Chips(listOf(2 to "2s", 3 to "3s", 5 to "5s", 0 to "Never"), c.hide) { upd(c.copy(hide = it)) }
        Lbl("Default video filter"); Chips(FILTERS, c.filter) { upd(c.copy(filter = it)) }
        SwitchRow("Resume where you left off", "Remembers the position of each video", c.resume) { upd(c.copy(resume = it)) }
        SwitchRow("Hardware decoding first", "Falls back to software for 4K the phone can't decode", c.hw) { upd(c.copy(hw = it)) }
        SwitchRow("Show playback info", "Decoder, fps and dropped frames in the player", c.info) { upd(c.copy(info = it)) }
        SectionTitle("Vault")
        SwitchRow("Auto-lock when you leave the app", "Asks for your password again next time", c.autoLock) { upd(c.copy(autoLock = it)) }
        if (unlocked) OutlinedButton(lockNow) { Text("Lock vault now") }
    }
}

@Composable fun Swatches(sel: String, light: Boolean, set: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        ACCENTS.forEach { (k, p) ->
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(Color(if (light) p.second else p.first))
                    .then(if (sel == k) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape) else Modifier)
                    .clickable { set(k) },
                contentAlignment = Alignment.Center
            ) { if (sel == k) Icon(Icons.Rounded.Check, null, tint = Color.Black.copy(.7f)) }
        }
    }
}

@Composable fun SectionTitle(t: String) = Text(t.uppercase(), Modifier.padding(top = 12.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, letterSpacing = 1.sp)
@Composable fun Lbl(t: String) = Text(t, fontWeight = FontWeight.SemiBold)

private val CHIP = RoundedCornerShape(12.dp)

/** Light-weight replacement for Material's FilterChip (which is very expensive to compose ~40 times). */
@Composable fun Chip(on: Boolean, label: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Text(
        label,
        Modifier.clip(CHIP).background(if (on) cs.secondaryContainer else Color.Transparent)
            .then(if (on) Modifier else Modifier.border(1.dp, cs.onSurface.copy(.22f), CHIP))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
        fontSize = 14.sp, fontWeight = FontWeight.Medium, color = if (on) cs.onSecondaryContainer else cs.onSurface
    )
}

@Composable fun <T> Chips(opts: List<Pair<T, String>>, sel: T, set: (T) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        opts.forEach { (k, n) -> Chip(sel == k, n) { set(k) } }
    }
}

@Composable fun SwitchRow(title: String, sub: String, on: Boolean, set: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        Switch(on, set)
    }
}


/** Liquid-glass tab bar. All motion happens in graphicsLayer (draw phase): no recomposition or relayout while dragging. */
@Composable fun GlassNav(sel: Int, tabs: List<Pair<ImageVector, String>>, onSel: (Int) -> Unit, m: Modifier) {
    val itemW = 92.dp; val iw = with(LocalDensity.current) { itemW.toPx() }
    val x = remember { Animatable(sel * iw) }; val dragX = remember { mutableFloatStateOf(sel * iw) }
    val sx = remember { Animatable(1f) }; val sy = remember { Animatable(1f) }
    val scope = rememberCoroutineScope()
    var held by remember { mutableStateOf(false) }; var hot by remember { mutableIntStateOf(sel) }
    val settle = spring<Float>(dampingRatio = 0.72f, stiffness = 280f)   // slight liquid wobble
    val squish = spring<Float>(dampingRatio = 0.6f, stiffness = 320f)
    val cs = MaterialTheme.colorScheme; val ink = cs.onSurface
    val shape = RoundedCornerShape(50)
    LaunchedEffect(sel, held) { if (!held) { hot = sel; x.animateTo(sel * iw, settle) } }
    Box(
        m.shadow(14.dp, shape, ambientColor = Color.Black.copy(.25f), spotColor = Color.Black.copy(.35f))
            .clip(shape)
            .background(cs.surface.copy(alpha = .58f))
            .background(Brush.verticalGradient(listOf(ink.copy(.18f), ink.copy(.03f))))
            .border(1.dp, Brush.verticalGradient(listOf(ink.copy(.50f), ink.copy(.06f))), shape)
            .padding(6.dp)
            .pointerInput(tabs.size) { awaitEachGesture {
                val down = awaitFirstDown(); held = true
                dragX.floatValue = x.value
                fun go(px: Float, k: Float) {
                    val t = (px - iw / 2).coerceIn(0f, iw * (tabs.size - 1))
                    dragX.floatValue += (t - dragX.floatValue) * k          // light smoothing, no coroutine per event
                    val nh = (t / iw).roundToInt(); if (nh != hot) hot = nh
                }
                scope.launch { sx.animateTo(1.10f, squish) }; scope.launch { sy.animateTo(1.16f, squish) }
                go(down.position.x, .5f)
                do { val e = awaitPointerEvent(); e.changes.firstOrNull()?.let { c -> go(c.position.x, .55f); c.consume() } } while (e.changes.any { it.pressed })
                val t = hot
                scope.launch { x.snapTo(dragX.floatValue); held = false }
                scope.launch { sx.animateTo(1f, squish) }; scope.launch { sy.animateTo(1f, squish) }
                onSel(t)
            } }
    ) {
        // the glass lens
        Box(
            Modifier.size(itemW, 52.dp)
                .graphicsLayer { translationX = if (held) dragX.floatValue else x.value; scaleX = sx.value; scaleY = sy.value }
                .clip(shape)
                .background(Brush.verticalGradient(listOf(cs.primary.copy(.45f), cs.primary.copy(.16f))))
                .border(1.dp, Brush.verticalGradient(listOf(ink.copy(.45f), ink.copy(.05f))), shape)
        )
        Row { tabs.forEachIndexed { i, (ic, n) ->
            val on = i == (if (held) hot else sel)
            Column(Modifier.size(itemW, 52.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                Icon(ic, n, Modifier.size(22.dp).graphicsLayer { val s = if (held && hot == i) 1.12f else 1f; scaleX = s; scaleY = s }, tint = if (on) ink else cs.onSurfaceVariant)
                Text(n, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = if (on) ink else cs.onSurfaceVariant)
            }
        } }
    }
}
