package com.senje.darkfantasyascii

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * 1:1 Micro-ASCII Renderer for the Knight Character ("Senje"), his glowing flaming longsword,
 * his Bloody Mail Coif & dark crimson surcoat, directional shadow, and the White ASCII Warhorse Mount.
 *
 * Matches Video 1 (1000461713.mp4 - Chainmail test) and Video 2 (1000461712.mp4 - Tower high ground).
 */
class SenjeCharacterRenderer {

    private val microPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }

    private val namePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val charBuf = CharArray(1)

    // Pre-allocated ember particle buffers (zero GC allocation during gameplay)
    private val maxSparks = 42
    private val sparkX = FloatArray(maxSparks)
    private val sparkY = FloatArray(maxSparks)
    private val sparkZ = FloatArray(maxSparks)
    private val sparkVx = FloatArray(maxSparks)
    private val sparkVy = FloatArray(maxSparks)
    private val sparkVz = FloatArray(maxSparks)
    private val sparkLife = FloatArray(maxSparks)
    private val sparkMaxLife = FloatArray(maxSparks)
    private val sparkGlyph = CharArray(maxSparks)
    private var sparkSeed = 1337

    // Micro-ASCII rows for the Bloody Mail Coif + Crimson Surcoat + Chainmail Sleeves & Greaves
    // Exactly replicates the silhouette and glyph density of v1_01.png and v2_09.png:
    // Legend:
    //  'M','S','$','3','@','8','%','(' ,')' -> Silver chainmail coif & mantle with 3D cylindrical shading
    //  'V' -> Dark recessed visor slit
    //  'R','r','=','+',':','|' -> Dark crimson/burgundy woven surcoat/tabard (lit on left by sword)
    //  'L','l' -> Silver chainmail sleeve / lower hem / greaves
    private val knightRowsFront = arrayOf(
        "    ($3%S)    ",
        "   ($8$$3%)   ",
        "  ($SVVVV3$)  ",
        "  ($$VVVV%$)  ",
        " ($3%$88$%3$) ",
        "($8$3$%%$3$8$)",
        "/#@$3%$$%3$@#\\",
        "|%$3$3333$3$%|",
        " \\%$$3883$$%/ ",
        "  |RR=++=rr|L ",
        "  |RR#%&%rr|l ",
        "  |RR=::=rr/  ",
        "  |RR+||+rr|  ",
        "  |RR=::=rrL  ",
        "  |RR#==#rrl  ",
        "  |RR=::=rrL  ",
        "  |RR+||+rrl  ",
        "  |RR=..=rr|  ",
        "  |rr:  :rrL  ",
        "  |r/    \\8$  ",
        "  |#      #@\\ ",
        "           8$ "
    )

    private val knightRowsBack = arrayOf(
        "    ($3%S)    ",
        "   ($8$$3%)   ",
        "  ($$3%%3$$)  ",
        "  ($3%88%3$)  ",
        " ($3%$88$%3$) ",
        "($8$3$%%$3$8$)",
        "/#@$3%$$%3$@#\\",
        "|%$3$3333$3$%|",
        " \\%$$3883$$%/ ",
        "  |rr=++=RR|  ",
        "  |rr#%&%RR|  ",
        "  |rr=::=RR|  ",
        "  |rr+||+RR|  ",
        "  |rr=::=RR|  ",
        "  |rr#==#RR|  ",
        "  |rr=::=RR|  ",
        "  |rr+||+RR|  ",
        "  |rr=..=RR|  ",
        "  |rr:  :rr|  ",
        "  |8\\    /8|  ",
        "  /@#    #@\\  ",
        "  $8      8$  "
    )

    // White ASCII Warhorse Mount rows (matching Video 2 00:00 - 00:05)
    private val horseRowsRight = arrayOf(
        "                  /@Q%\\   ",
        "                 /Q08@Q\\  ",
        "       ~*#%@@QQQ088Q@*    ",
        "     ~*%@Q00888800Q@%     ",
        "    ~*@Q0888%%%%880Q#     ",
        "      \\@08%/    \\%80@\\    ",
        "      /Q8/        \\8Q\\    ",
        "     /0/            \\0\\   ",
        "    /#/              \\#\\  "
    )

    private val mailGlyphs = charArrayOf('$', '3', '%', '@', '#', '8', 'S', '&', '(', ')')
    private val surcoatGlyphs = charArrayOf('#', '%', '&', '=', '+', ':', '|', '-')
    private val swordCoreGlyphs = charArrayOf('*', '#', '@', '+', '=', ':')

    fun updateSparks(
        dt: Float,
        swordTipWorldX: Float,
        swordTipWorldY: Float,
        swordBaseWorldX: Float,
        swordBaseWorldY: Float,
        swordZ: Float,
        isSlashing: Boolean
    ) {
        val spawnChance = if (isSlashing) 0.92f else 0.55f
        for (i in 0 until maxSparks) {
            sparkLife[i] -= dt
            if (sparkLife[i] <= 0f) {
                sparkSeed = sparkSeed * 1664525 + 1013904223
                val r0 = ((sparkSeed ushr 8) and 0xFFFF) / 65535f
                if (r0 < spawnChance) {
                    sparkSeed = sparkSeed * 1664525 + 1013904223
                    val t = ((sparkSeed ushr 8) and 0xFFFF) / 65535f
                    sparkX[i] = swordBaseWorldX + (swordTipWorldX - swordBaseWorldX) * t
                    sparkY[i] = swordBaseWorldY + (swordTipWorldY - swordBaseWorldY) * t
                    sparkZ[i] = swordZ + 8f + t * 6f

                    sparkSeed = sparkSeed * 1664525 + 1013904223
                    val rx = (((sparkSeed ushr 8) and 0xFF) / 127.5f) - 1f
                    val ry = (((sparkSeed ushr 16) and 0xFF) / 127.5f) - 1f
                    sparkVx[i] = rx * (if (isSlashing) 36f else 14f)
                    sparkVy[i] = ry * (if (isSlashing) 36f else 14f)
                    sparkVz[i] = 22f + abs(rx) * 18f
                    sparkMaxLife[i] = 0.28f + (t * 0.35f)
                    sparkLife[i] = sparkMaxLife[i]
                    sparkGlyph[i] = swordCoreGlyphs[i % swordCoreGlyphs.size]
                }
            } else {
                sparkX[i] += sparkVx[i] * dt
                sparkY[i] += sparkVy[i] * dt
                sparkZ[i] += sparkVz[i] * dt
            }
        }
    }

    /**
     * Renders an inverted water reflection of Senje (and horse if mounted) when standing near/in water,
     * matching Video 2 (00:02 - 00:05).
     */
    fun drawWaterReflection(
        canvas: Canvas,
        screenX: Float,
        screenY: Float,
        zoom: Float,
        time: Float,
        isMounted: Boolean
    ) {
        val microStepX = 4.2f * zoom
        val microStepY = 5.2f * zoom
        microPaint.textSize = (6.8f * zoom).coerceAtLeast(4f)

        val rows = knightRowsFront
        val reflectOffsetY = (if (isMounted) 46f else 32f) * zoom

        for (r in rows.indices step 2) {
            val rowStr = rows[r]
            val waveShift = sin(time * 4.2f + r * 0.7f) * 3.5f * zoom
            val ry = screenY + reflectOffsetY + (rows.size - r) * microStepY * 0.72f
            for (c in rowStr.indices step 2) {
                val ch = rowStr[c]
                if (ch == ' ') continue
                val rx = screenX + (c - rowStr.length * 0.5f) * microStepX + waveShift
                charBuf[0] = if (r % 4 == 0) '~' else ch
                microPaint.color = if (ch == 'R' || ch == 'r') {
                    0x554E1814
                } else {
                    0x666E7F91
                }
                canvas.drawText(charBuf, 0, 1, rx, ry, microPaint)
            }
        }
    }

    /**
     * Renders the Unmounted White ASCII Horse standing in the world when the player dismounts
     * (just like Video 2 00:05 when Senje dismounts at the base of the Watchtower).
     */
    fun drawWildHorse(
        canvas: Canvas,
        screenX: Float,
        screenY: Float,
        zoom: Float,
        time: Float,
        emberLight: Float
    ) {
        drawHorseBody(
            canvas = canvas,
            screenX = screenX,
            screenY = screenY,
            zoom = zoom,
            time = time,
            moveSpeed = 0f,
            facingX = 1f,
            emberLight = emberLight
        )
    }

    private fun drawHorseBody(
        canvas: Canvas,
        screenX: Float,
        screenY: Float,
        zoom: Float,
        time: Float,
        moveSpeed: Float,
        facingX: Float,
        emberLight: Float
    ) {
        val microStepX = 4.4f * zoom
        val microStepY = 5.4f * zoom
        microPaint.textSize = (7.2f * zoom).coerceAtLeast(4.5f)

        // Soft horse shadow on ground
        glowPaint.color = 0x77020305
        canvas.drawOval(
            screenX - 42f * zoom,
            screenY - 6f * zoom,
            screenX + 46f * zoom,
            screenY + 16f * zoom,
            glowPaint
        )

        val dirSign = if (facingX >= 0f) 1f else -1f
        val gallopBob = if (moveSpeed > 0.1f) sin(time * 13f) * 3.5f * zoom else sin(time * 2.2f) * 0.8f * zoom

        for (r in horseRowsRight.indices) {
            val line = horseRowsRight[r]
            val isLegRow = r >= 5
            val legStride = if (isLegRow && moveSpeed > 0.1f) {
                sin(time * 15f + r * 1.1f) * 5.5f * zoom
            } else {
                0f
            }
            val py = screenY - (horseRowsRight.size - 1 - r) * microStepY + gallopBob

            for (c in line.indices) {
                val ch = line[c]
                if (ch == ' ') continue
                val relC = (c - line.length * 0.5f) * dirSign
                val px = screenX + relC * microStepX + (if (c < 10) legStride else -legStride * 0.6f)

                val baseCol = when (ch) {
                    '@', 'Q', '0' -> WorldConfig.COL_MAIL_SPECULAR
                    '8', '#', '%' -> WorldConfig.COL_MAIL_SILVER
                    else -> WorldConfig.COL_MAIL_MID
                }
                microPaint.color = WorldConfig.applyDynamicLight(baseCol, 1.0f, emberLight * 0.7f, 0f)
                charBuf[0] = ch
                canvas.drawText(charBuf, 0, 1, px, py, microPaint)
            }
        }
    }

    /**
     * Renders the complete Senje Knight character with:
     * 1. Elongated directional ground shadow cast to the right/bottom-right (v1_01.png)
     * 2. Optional White ASCII Warhorse mount (v2_01.png / v2_02.png)
     * 3. Micro-ASCII Bloody Mail Coif & Crimson Surcoat/Tabard with animated leg stride
     * 4. Blazing Ember Longsword with dynamic slash arc, white-hot core, orange glow, and spark trail
     * 5. Floating "Senje" nameplate above the head
     */
    fun drawSenje(
        canvas: Canvas,
        screenX: Float,
        screenY: Float,
        zoom: Float,
        time: Float,
        facingX: Float,
        facingY: Float,
        moveSpeed: Float,
        slashTimer: Float,
        isMounted: Boolean,
        flameBoost: Boolean,
        worldToScreenX: (Float) -> Float,
        worldToScreenY: (Float, Float) -> Float
    ) {
        // 1. Directional elongated shadow cast to the right/bottom-right (exactly like v1_01.png)
        val shadowLenX = 56f * zoom
        val shadowLenY = 22f * zoom
        glowPaint.color = 0x88020305.toInt()
        canvas.drawOval(
            screenX - 12f * zoom,
            screenY - 9f * zoom,
            screenX + shadowLenX,
            screenY + shadowLenY,
            glowPaint
        )
        glowPaint.color = 0x55020305
        canvas.drawOval(
            screenX + 6f * zoom,
            screenY - 5f * zoom,
            screenX + shadowLenX * 1.35f,
            screenY + shadowLenY * 1.18f,
            glowPaint
        )

        // 2. If mounted on the White ASCII Warhorse (Video 2), draw horse first
        val mountLiftY = if (isMounted) 22f * zoom else 0f
        if (isMounted) {
            drawHorseBody(
                canvas = canvas,
                screenX = screenX,
                screenY = screenY + 4f * zoom,
                zoom = zoom,
                time = time,
                moveSpeed = moveSpeed,
                facingX = facingX,
                emberLight = 0.55f
            )
        }

        // 3. Micro-ASCII Knight Body (Bloody Mail Coif + Crimson Tabard + Mail Greaves)
        val microStepX = 3.7f * zoom
        val microStepY = 4.5f * zoom
        microPaint.textSize = (6.3f * zoom).coerceAtLeast(4.2f)

        val walkBob = if (moveSpeed > 0.08f) {
            abs(sin(time * (if (isMounted) 13f else 9.5f))) * 3.2f * zoom
        } else {
            sin(time * 2.4f) * 0.7f * zoom
        }

        val rows = if (facingY < -0.35f) knightRowsBack else knightRowsFront
        val totalRows = rows.size
        val baseKnightY = screenY - mountLiftY - walkBob
        val shimmerTick = (time * 5.5f).toInt()

        for (r in 0 until totalRows) {
            val rowStr = rows[r]
            val isLowerSkirt = r >= 15
            val strideShift = if (isLowerSkirt && moveSpeed > 0.08f) {
                sin(time * 10.5f + r * 0.6f) * 2.6f * zoom
            } else {
                0f
            }
            val py = baseKnightY - (totalRows - 1 - r) * microStepY

            for (c in rowStr.indices) {
                val rawCh = rowStr[c]
                if (rawCh == ' ') continue

                val colOffset = c - rowStr.length * 0.5f
                val px = screenX + colOffset * microStepX + (if (colOffset < 0) strideShift else -strideShift)

                // Dynamic left-side sword flame illumination on the knight's mail & crimson surcoat
                val distFromSwordSide = ((colOffset + 5f) / 10f).coerceIn(0f, 1f)
                val swordRimLight = (1f - distFromSwordSide) * (if (flameBoost) 0.95f else 0.68f)

                var renderChar = rawCh
                val color: Int = when (rawCh) {
                    'V' -> {
                        renderChar = ' '
                        0xFF05070A.toInt()
                    }
                    '$', '3', '%', 'S', '8', '(', ')' -> {
                        // Subtle metallic chainmail shimmer when moving
                        val h = (r * 17 + c * 31 + (if (moveSpeed > 0.08f) shimmerTick else 0)) and 0x7FFFFFFF
                        renderChar = if (rawCh == '(' || rawCh == ')') rawCh else mailGlyphs[h % mailGlyphs.size]
                        // Cylindrical 3D shading across the coif & mantle (bright top-left, shadowed bottom-right)
                        val cylShade = (1.12f - (colOffset * 0.055f) - (r * 0.025f)).coerceIn(0.42f, 1.25f)
                        val baseMail = when {
                            cylShade > 0.98f -> WorldConfig.COL_MAIL_SPECULAR
                            cylShade > 0.74f -> WorldConfig.COL_MAIL_SILVER
                            cylShade > 0.54f -> WorldConfig.COL_MAIL_MID
                            else -> WorldConfig.COL_MAIL_SHADOW
                        }
                        WorldConfig.applyDynamicLight(baseMail, cylShade, swordRimLight * 0.42f, 0f)
                    }
                    'R', 'r', '=', '+', ':', '|' -> {
                        // Dark crimson/burgundy surcoat weave with warm orange sword glow on left edge
                        val h = (r * 13 + c * 7) and 0x7FFFFFFF
                        renderChar = if (rawCh == '|' || rawCh == ':') rawCh else surcoatGlyphs[h % surcoatGlyphs.size]
                        val baseCloth = if (rawCh == 'R' || colOffset < -1.5f) {
                            WorldConfig.COL_SURCOAT_CRIMSON
                        } else {
                            WorldConfig.COL_SURCOAT_DARK
                        }
                        WorldConfig.applyDynamicLight(baseCloth, 0.95f, swordRimLight * 0.88f, 0f)
                    }
                    'L', 'l', '@', '#', '/', '\\' -> {
                        // Right-side silver chainmail sleeve and lower mail greaves
                        WorldConfig.applyDynamicLight(WorldConfig.COL_MAIL_SILVER, 0.92f, swordRimLight * 0.25f, 0f)
                    }
                    else -> WorldConfig.COL_MAIL_MID
                }

                if (renderChar != ' ') {
                    microPaint.color = color
                    charBuf[0] = renderChar
                    canvas.drawText(charBuf, 0, 1, px, py, microPaint)
                }
            }
        }

        // 4. Blazing Ember Longsword (Video 1 00:00, 00:43 & Video 2 00:18)
        // Default stance: held in the knight's left hand pointing diagonally down-left (~142 deg)
        // During slash: sweeps in a wide 160-degree fiery arc across the front!
        val handX = screenX - 11f * zoom
        val handY = baseKnightY - 46f * zoom

        val baseSwordAngle = if (slashTimer > 0f) {
            val p = 1f - (slashTimer / 0.38f).coerceIn(0f, 1f)
            // Wide slash sweep from upper-left to lower-right
            2.45f - p * 3.1f
        } else {
            // Iconic diagonal down-left ember blade angle from v1_01.png + subtle breathing sway
            2.42f + sin(time * 2.7f) * 0.04f
        }

        val swordLen = (if (flameBoost) 66f else 54f) * zoom
        val cosA = cos(baseSwordAngle)
        val sinA = sin(baseSwordAngle)

        // Draw crossguard & pommel in gold/bronze ASCII
        microPaint.color = 0xFFD99B42.toInt()
        charBuf[0] = '+'
        canvas.drawText(charBuf, 0, 1, handX - sinA * 4f * zoom, handY + cosA * 4f * zoom, microPaint)
        canvas.drawText(charBuf, 0, 1, handX + sinA * 4f * zoom, handY - cosA * 4f * zoom, microPaint)

        // Soft fiery orange bloom halo around the blade
        val tipX = handX + cosA * swordLen
        val tipY = handY + sinA * swordLen
        val midBladeX = (handX + tipX) * 0.5f
        val midBladeY = (handY + tipY) * 0.5f

        glowPaint.color = if (flameBoost || slashTimer > 0f) 0x38FF6A10 else 0x26FF6A10
        canvas.drawCircle(midBladeX, midBladeY, 26f * zoom, glowPaint)
        glowPaint.color = 0x22FF4500
        canvas.drawCircle(tipX, tipY, 18f * zoom, glowPaint)

        // Draw the multi-layered ASCII flaming blade (*, #, @, +, =, :)
        val bladeSteps = 15
        for (s in 0..bladeSteps) {
            val t = s.toFloat() / bladeSteps.toFloat()
            val bx = handX + cosA * (swordLen * t)
            val by = handY + sinA * (swordLen * t)

            val flicker = sin(time * 24f + s * 1.7f) * 1.4f * zoom
            val perpX = -sinA * flicker
            val perpY = cosA * flicker

            // Outer red-orange ember aura glyphs
            val outerGlyph = if ((s + shimmerTick) % 2 == 0) ':' else '.'
            microPaint.color = WorldConfig.COL_SWORD_EMBER
            charBuf[0] = outerGlyph
            canvas.drawText(charBuf, 0, 1, bx - sinA * 3.6f * zoom, by + cosA * 3.6f * zoom, microPaint)
            canvas.drawText(charBuf, 0, 1, bx + sinA * 3.6f * zoom, by - cosA * 3.6f * zoom, microPaint)

            // Mid blazing orange flame glyphs
            val midGlyph = swordCoreGlyphs[(s + shimmerTick) % swordCoreGlyphs.size]
            microPaint.color = WorldConfig.COL_SWORD_FLAME
            charBuf[0] = midGlyph
            canvas.drawText(charBuf, 0, 1, bx + perpX * 1.3f, by + perpY * 1.3f, microPaint)

            // White-hot inner core
            charBuf[0] = if (t > 0.85f) '*' else if (s % 2 == 0) '#' else '+'
            microPaint.color = WorldConfig.COL_SWORD_CORE
            canvas.drawText(charBuf, 0, 1, bx, by, microPaint)
        }

        // Draw floating ember sparks in screen space
        for (i in 0 until maxSparks) {
            val life = sparkLife[i]
            if (life <= 0f) continue
            val ratio = (life / sparkMaxLife[i]).coerceIn(0f, 1f)
            val sx = worldToScreenX(sparkX[i])
            val sy = worldToScreenY(sparkY[i], sparkZ[i])
            microPaint.color = if (ratio > 0.6f) {
                WorldConfig.COL_SWORD_CORE
            } else if (ratio > 0.3f) {
                WorldConfig.COL_SWORD_FLAME
            } else {
                WorldConfig.COL_SWORD_EMBER
            }
            charBuf[0] = if (ratio < 0.35f) '.' else sparkGlyph[i]
            canvas.drawText(charBuf, 0, 1, sx, sy, microPaint)
        }

        // 5. Floating "Senje" Nameplate above the coif (v1_01.png)
        namePaint.textSize = (11.5f * zoom).coerceIn(9f, 22f)
        val nameY = baseKnightY - totalRows * microStepY - 12f * zoom
        namePaint.color = 0xAA05070A.toInt()
        canvas.drawText("Senje", screenX + 1.5f, nameY + 1.5f, namePaint)
        namePaint.color = 0xFFDCE6F0.toInt()
        canvas.drawText("Senje", screenX, nameY, namePaint)
    }

    /**
     * Draws ambient sentinel knights on the marsh bank and tower battlements
     * (seen in Video 2 00:00, 00:04, 00:31).
     */
    fun drawAmbientSentinel(
        canvas: Canvas,
        screenX: Float,
        screenY: Float,
        zoom: Float,
        time: Float,
        phaseOffset: Float,
        emberLight: Float
    ) {
        val microStepX = 3.2f * zoom
        val microStepY = 4.0f * zoom
        microPaint.textSize = (5.6f * zoom).coerceAtLeast(3.8f)

        val bob = sin(time * 2.5f + phaseOffset) * 1.2f * zoom
        for (r in knightRowsFront.indices step 2) {
            val rowStr = knightRowsFront[r]
            val py = screenY - (knightRowsFront.size - 1 - r) * microStepY + bob
            for (c in rowStr.indices step 2) {
                val ch = rowStr[c]
                if (ch == ' ' || ch == 'V') continue
                val px = screenX + (c - rowStr.length * 0.5f) * microStepX
                val baseCol = if (ch == 'R' || ch == 'r') {
                    WorldConfig.COL_SURCOAT_DARK
                } else {
                    WorldConfig.COL_MAIL_MID
                }
                microPaint.color = WorldConfig.applyDynamicLight(baseCol, 0.85f, emberLight, 0f)
                charBuf[0] = ch
                canvas.drawText(charBuf, 0, 1, px, py, microPaint)
            }
        }
    }
}
