# Hero animation + human body (added)

All in `MainActivity.java` (search `HERO RIG BEGIN`).

- Body: ~7.7 heads tall. Head + neck, hair cap, tapered torso (pelvis / abdomen / chest / shoulders / belt),
  upper arm + forearm + hand, thigh + shin + calf + boot + foot. Depth-sorted (near limbs in front, far limbs behind).
- Idle: breathing (chest + shoulders, lagged), slow weight shift, occasional head glance, sword arm sways.
- Walk -> run: gait clock is distance-driven (`heroCycleDist`), so planted feet match ground speed (no sliding).
  Heel strike -> toe-off foot roll, hip bob lowest at double support, arms counter-swing, run adds forward lean,
  bent elbows, longer lift and a flight phase.
- Dodge: crouch -> tucked ball roll with a hop -> unfold -> short recovery crouch. Vertical dodges squash into a low dive.
- Slash: wind-up overhead, sweep, recovery, with a lunge step.
- Mounted rider uses the same human proportions (seated, reins hand, sword arm).
- The hero glyph grid is now 64x58 cells with 1.3 aspect (same as the horse grid) and is drawn by `drawHeroGlyphs`,
  so the body is no longer squeezed. Use [DISMOUNT] to see the foot hero; the horse rider is the default.

Not compiled against the Android SDK (none available). The rig + rider code were compiled and rendered on desktop.

# 3D first, then ASCII (knight + horse/rider)

The knight and the horse (with its rider) are now real 3D models. The glyphs are produced *from* a 3D render.

    Rig3D (3D skeleton + animation)  ->  Render3D (meshes, z-buffer, lighting)  ->  Render3D.toAscii (glyph cells)

- `Render3D.java`  pure-Java software renderer: ellipsoids, tapered limbs, boxes, blades; orthographic camera tilted
                   down by `Rig3D.PITCH`; per-pixel normals, key + fill + rim light, specular on steel/gold, emissive
                   ember blade. Renders super-sampled (3x3 knight, 2x2 horse; `ss` arg), then `toAscii` collapses each
                   block into one glyph: lit surfaces -> density ramp (`DENSE_RAMP`), silhouettes -> ( ) / \ - _,
                   depth edges (arm over torso) -> | / \, hair -> curly glyphs, blade -> * # % @.
- `Rig3D.java`     `Rig3D.Foot` (knight on foot) and `Rig3D.Horse` (horse + seated knight). Same animation maths as
                   before (planted-foot gait, idle layers, run lean, tuck-and-roll dodge, slash, 4-beat walk -> gallop,
                   grazing / pawing / ear flicks), now solved in a 3D local frame (f forward, y down, l right-hand
                   side) and drawn as meshes. `drawKnight` is shared, so the rider is the same model as the foot knight.
- Heading is a real 3D yaw (smoothed along the shortest arc): the knight / horse pivot through front, side and back
  views, the sword stays in his right hand, dodge is a forward roll along the heading.
- Knight: steel breastplate, pauldrons with gold rim, gorget, gauntlets, greaves, crimson tabard + hose, belt + buckle,
  silver hair with circlet, sword with crossguard + pommel. Horse: barrel / haunch / chest, neck, head with muzzle, eyes
  and ears, 4 jointed legs with hooves, saddle, blanket, stirrups, reins to the bit.
- Still strand-based: verlet hair (`plotHeroHair`), horse tail / mane (`HairFx`), rider hair. Their anchors are now
  the 3D head / tail / mane points projected to the screen (`Rig3D.*.headX` etc.).
- Horse glyph grid is now 96x64 (was 96x58), ground anchor row = `HORSE_CY_FRAC` (0.60) so the taller rider fits.
- The old 2D capsule rigs (`HERO RIG` block, `plotHeroCap`, `hcap`, ...) are left in the file but no longer called.

Perf (desktop JIT): horse + rider ~1.8 ms/frame, knight ~0.7 ms/frame. If a phone is slow, lower `ss` in the two
`new Render3D(...)` calls in MainActivity, or call the rasteriser every 2nd frame.

Not compiled against the Android SDK (none available): `Render3D` / `Rig3D` compile and run on desktop, and every
remaining error from compiling MainActivity is a missing android.* class. Preview sheets: preview/knight.png, horse.png.

# Horse remodel (matches the reference photo)

- Model: pale dapple-grey coat, charcoal lower legs (coat fades to dark at mid forearm / gaskin) with fetlocks, pasterns and
  near-black hooves, deep chest + shoulder / thigh muscles, withers, long arched neck, refined head with dark muzzle,
  nostrils, brown eyes and pointed ears, grey 3D mane (both sides of the crest) and a long full tail.
- Saddle: dark charcoal leather - seat, raised cantle, horn with brown tip, skirts / fenders, girth strap with buckle, stirrups.
  No blanket (the photo has none).
- New materials in `Render3D`: `T_LEG`, `T_SADDLE` (T_COUNT = 12); coat / muzzle / hoof albedo retuned.
- Animation: 4-beat walk -> gallop (legs now longer / straighter), idle breathing, grazing dip, pawing, resting a hind leg,
  occasional head toss, blinking, ear flicks (ears pin back at speed), mane flutter, tail that hangs at rest, swishes when idle
  and streams back at gallop, empty stirrups swinging when riderless.
- `Rig3D.Horse.riderless = true` draws the horse alone (exactly like the picture); default is still mounted.
- Horse glyph grid is now 96x72 (HORSE_BUF_H), ground anchor 0.58, so the longer legs fit.
- ASCII is still the last step: Rig3D -> Render3D -> toAscii. See preview/horse.png and preview/horse_ascii.txt.

# Horse = the supplied walking model (Walk.abc + texture)

- `reference/Walk.abc` (Alembic, 32 looping frames @24 fps, 10,362 verts) was decoded and baked into
  `app/src/main/assets/horse_walk.bin` (positions per frame, triangles, texture colour per corner).
- `HorseMesh.java` loads it and, every frame, turns a fractional walk frame into the rig frame, then adds layers:
  head yaw / nod (look-around, grazing dip, head toss), tail sway, body pitch / lift (gallop bounce, dodge leap),
  breathing. Standing pose = the walk frame with the feet closest together, blended into the walk by speed.
- `Render3D.mesh(...)` draws the mesh with per-corner texture colour (dark legs/hooves get sparser glyphs).
- Walk phase is distance driven (`STRIDE_D` in `Rig3D.Horse`) so hooves stay planted at walking pace; above that the
  cycle just plays faster (capped at 2.4 cycles/s). There is no real gallop in the source animation.
- Dark leather saddle sits on the back height measured from the mesh each frame; rider is unchanged.
- If `horse_walk.bin` is missing, the old procedural horse is used automatically (`Rig3D.Horse.mesh == null`).
- Colours come from the supplied texture (tan coat, dark legs), not the earlier grey photo.
