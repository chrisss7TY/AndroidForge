package com.ashveil.abyss;

/**
 * Tiny software 3D renderer + 3D -> ASCII converter (pure Java, no Android classes).
 *
 * Pipeline:  1) model parts (ellipsoids, tapered limbs, boxes, blades) are tessellated and rasterised into a
 *               super-sampled z-buffer with per-pixel normals, key + fill light, rim light and specular
 *            2) {@link #toAscii} collapses every ss x ss block of samples into one glyph cell:
 *               shading -> glyph density ramp, silhouette / depth edges -> / \ | - ( ) outline glyphs.
 *
 * Model space is "local": f = forward, y = DOWN, l = the character's right-hand side.
 * {@link #setView} turns the local frame by the heading and tilts the camera down by 'pitch', so a character
 * that turns around really turns around (front, side and back are all actual 3D views).
 * View space: x = screen right, y = screen down, z = toward the viewer.  Orthographic.
 */
final class Render3D {
    static final int T_STEEL = 0, T_SKIN = 1, T_CLOTH = 2, T_LEATHER = 3, T_HAIR = 4, T_FIRE = 5,
            T_HORSE = 6, T_HORSE_DARK = 7, T_HOOF = 8, T_GOLD = 9, T_LEG = 10, T_SADDLE = 11, T_COUNT = 12;

    // albedo (0..1) per material; lighting is applied on top
    private static final float[][] ALB = {
            {0.82f, 0.86f, 0.96f},   // steel (silver-white armour)
            {0.97f, 0.72f, 0.56f},   // skin
            {1.00f, 0.17f, 0.14f},   // crimson cloth
            {0.66f, 0.45f, 0.26f},   // leather
            {0.88f, 0.91f, 1.00f},   // silver hair
            {1.00f, 0.64f, 0.20f},   // ember blade
            {0.86f, 0.89f, 0.95f},   // horse coat (pale dapple grey)
            {0.42f, 0.45f, 0.52f},   // horse dark (muzzle, ears, nostril)
            {0.17f, 0.18f, 0.22f},   // hoof (near black)
            {1.00f, 0.80f, 0.32f},   // gold trim
            {0.13f, 0.16f, 0.21f},   // horse lower legs (charcoal)
            {0.16f, 0.18f, 0.20f},   // saddle (dark grey leather)
    };
    private static final float[] SPEC = {0.60f, 0.05f, 0.03f, 0.10f, 0.18f, 0.0f, 0.10f, 0.04f, 0.12f, 0.50f, 0.06f, 0.16f};
    private static final float[] SHINE = {26f, 10f, 6f, 12f, 16f, 4f, 14f, 8f, 10f, 22f, 10f, 14f};
    private static final float[] EMIT = {0f, 0f, 0f, 0f, 0f, 0.80f, 0f, 0f, 0f, 0f, 0f, 0f};

    // lights in view space (x right, y down, z toward viewer)
    private static final float LX, LY, LZ, FX, FY, FZ, HX, HY, HZ;

    static {
        float[] l = norm3(-0.50f, -0.58f, 0.64f);
        LX = l[0]; LY = l[1]; LZ = l[2];
        float[] f = norm3(0.65f, 0.25f, 0.45f);
        FX = f[0]; FY = f[1]; FZ = f[2];
        float[] h = norm3(l[0], l[1], l[2] + 1.0f);
        HX = h[0]; HY = h[1]; HZ = h[2];
    }

    private static float[] norm3(float x, float y, float z) {
        float n = (float) Math.sqrt(x * x + y * y + z * z);
        return new float[]{x / n, y / n, z / n};
    }

    // ---- buffers -------------------------------------------------------------------------------
    final int cols, rows, ss, W, H;
    final float cx, cy, cpu, rpu;          // cell-space origin, cells per rig unit (x / y)
    private final float[] zb;
    private final float[] lumB;
    private final int[] rgbB;
    private final byte[] toneB;

    // cell-level scratch for toAscii
    private final float[] cCov, cZ, cLum;
    private final int[] cCol;
    private final byte[] cTone;

    // model -> view rotation
    private float m00 = 1, m01 = 0, m02 = 0, m10 = 0, m11 = 1, m12 = 0, m20 = 0, m21 = 0, m22 = 1;

    Render3D(int cols, int rows, int ss, float colsPerUnit, float rowsPerUnit, float cxCells, float cyCells) {
        this.cols = cols;
        this.rows = rows;
        this.ss = ss;
        this.W = cols * ss;
        this.H = rows * ss;
        this.cpu = colsPerUnit;
        this.rpu = rowsPerUnit;
        this.cx = cxCells;
        this.cy = cyCells;
        zb = new float[W * H];
        lumB = new float[W * H];
        rgbB = new int[W * H];
        toneB = new byte[W * H];
        cCov = new float[cols * rows];
        cZ = new float[cols * rows];
        cLum = new float[cols * rows];
        cCol = new int[cols * rows];
        cTone = new byte[cols * rows];
    }

    void clear() {
        java.util.Arrays.fill(zb, -1.0e9f);
    }

    /** Heading (hx,hz) = forward direction on the ground (hz > 0 = toward the camera), camera pitched down by 'pitch'. */
    void setView(float hx, float hz, float pitch) {
        float l = (float) Math.sqrt(hx * hx + hz * hz);
        if (l < 1e-4f) {
            hx = 1.0f;
            hz = 0.0f;
        } else {
            hx /= l;
            hz /= l;
        }
        float sa = (float) Math.sin(pitch);
        float ca = (float) Math.cos(pitch);
        m00 = hx;      m01 = 0.0f; m02 = -hz;
        m10 = sa * hz; m11 = ca;   m12 = sa * hx;
        m20 = ca * hz; m21 = -sa;  m22 = ca * hx;
    }

    /** local (f, y, l) -> (screen x, screen y, depth) in rig units. */
    void project(float f, float y, float l, float[] out) {
        out[0] = m00 * f + m01 * y + m02 * l;
        out[1] = m10 * f + m11 * y + m12 * l;
        out[2] = m20 * f + m21 * y + m22 * l;
    }

    // ---- primitive tessellation scratch -----------------------------------------------------------
    private static final int MAXV = 24 * 17;
    private final float[] vx = new float[MAXV], vy = new float[MAXV], vz = new float[MAXV];
    private final float[] nxs = new float[MAXV], nys = new float[MAXV], nzs = new float[MAXV];
    private final float[] spx = new float[MAXV], spy = new float[MAXV];
    private final float[] pA = new float[32], pR = new float[32], pNA = new float[32], pNR = new float[32];
    private final float[] cosT = new float[17], sinT = new float[17];
    private int cosSeg = -1;
    private final float[] vcr = new float[4], vcg = new float[4], vcb = new float[4];
    private boolean vcOn;
    private final float[] tmpU = new float[3], tmpW = new float[3];

    private void trig(int seg) {
        if (cosSeg == seg) return;
        cosSeg = seg;
        for (int s = 0; s <= seg; s++) {
            double a = 2.0 * Math.PI * s / seg;
            cosT[s] = (float) Math.cos(a);
            sinT[s] = (float) Math.sin(a);
        }
    }

    private int segFor(float radius) {
        float cells = radius * cpu;
        if (cells < 1.6f) return 6;
        if (cells < 4.0f) return 8;
        if (cells < 8.0f) return 12;
        return 16;
    }

    /** Orthonormal frame for an axis: u = axis, w = lateral direction made perpendicular to u, v = u x w. */
    private void frame(float ux, float uy, float uz) {
        float l = (float) Math.sqrt(ux * ux + uy * uy + uz * uz);
        if (l < 1e-6f) {
            ux = 1.0f; uy = 0.0f; uz = 0.0f;
        } else {
            ux /= l; uy /= l; uz /= l;
        }
        float rx = 0.0f, ry = 0.0f, rz = 1.0f;              // lateral reference
        float d = uz;
        float wx = rx - d * ux, wy = ry - d * uy, wz = rz - d * uz;
        float wl = (float) Math.sqrt(wx * wx + wy * wy + wz * wz);
        if (wl < 1e-3f) {                                    // axis is lateral: use forward as reference
            rx = 1.0f; ry = 0.0f; rz = 0.0f;
            d = ux;
            wx = rx - d * ux; wy = ry - d * uy; wz = rz - d * uz;
            wl = (float) Math.sqrt(wx * wx + wy * wy + wz * wz);
        }
        tmpU[0] = ux; tmpU[1] = uy; tmpU[2] = uz;
        tmpW[0] = wx / wl; tmpW[1] = wy / wl; tmpW[2] = wz / wl;
    }

    // ---- public primitives -------------------------------------------------------------------------

    /** Tapered capsule from a to b. Cross-section: radius along 'v', radius*flat along the lateral axis. */
    void limb(float ax, float ay, float az, float bx, float by, float bz,
              float r0, float r1, float flat, int tone, float dim) {
        float dx = bx - ax, dy = by - ay, dz = bz - az;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        frame(dx, dy, dz);
        final int K = (Math.max(r0, r1) * cpu > 3.0f) ? 4 : 2;
        int n = 0;
        for (int i = 0; i <= K; i++) {                       // start cap: pole -> equator
            float psi = 1.5707963f * (1.0f - i / (float) K);
            pA[n] = -r0 * (float) Math.sin(psi);
            pR[n] = r0 * (float) Math.cos(psi);
            pNA[n] = -(float) Math.sin(psi);
            pNR[n] = (float) Math.cos(psi);
            n++;
        }
        for (int i = 0; i <= K; i++) {                       // end cap: equator -> pole
            float psi = 1.5707963f * (i / (float) K);
            pA[n] = len + r1 * (float) Math.sin(psi);
            pR[n] = r1 * (float) Math.cos(psi);
            pNA[n] = (float) Math.sin(psi);
            pNR[n] = (float) Math.cos(psi);
            n++;
        }
        // taper: tilt the cylindrical part's normals so the shading follows the cone
        if (len > 1e-4f) {
            float slope = (r0 - r1) / len;
            float sl = (float) Math.sqrt(1.0f + slope * slope);
            pNA[K] = slope / sl; pNR[K] = 1.0f / sl;
            pNA[K + 1] = slope / sl; pNR[K + 1] = 1.0f / sl;
        }
        revolved(ax, ay, az, n, flat, segFor(Math.max(r0, r1)), tone, dim);
    }

    /** Ellipsoid: semi-axis ru along 'axis', rv across (v), rv*flat across (lateral). */
    void ell(float cx0, float cy0, float cz0, float axx, float axy, float axz,
             float ru, float rv, float flat, int tone, float dim) {
        frame(axx, axy, axz);
        final int M = (Math.max(ru, rv) * cpu > 3.0f) ? 8 : 6;
        int n = 0;
        for (int i = 0; i <= M; i++) {
            float psi = -1.5707963f + 3.1415927f * i / M;
            float sp = (float) Math.sin(psi), cp = (float) Math.cos(psi);
            pA[n] = ru * sp;
            pR[n] = rv * cp;
            float na = sp / ru, nr = cp / rv;
            float nl = (float) Math.sqrt(na * na + nr * nr);
            pNA[n] = na / nl;
            pNR[n] = nr / nl;
            n++;
        }
        // origin of the profile is the ellipsoid centre
        revolved(cx0, cy0, cz0, n, flat, segFor(Math.max(ru, rv)), tone, dim);
    }

    /** Sword-like blade: axis a->b, half width rw, thickness ratio 'flat', pointed tip. */
    void blade(float ax, float ay, float az, float bx, float by, float bz, float rw, float flat, int tone, float dim) {
        float dx = bx - ax, dy = by - ay, dz = bz - az;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        frame(dx, dy, dz);
        float[] a = {0.0f, 0.012f, 0.05f * len, 0.70f * len, 0.90f * len, len};
        float[] r = {0.0f, rw, rw, rw * 0.92f, rw * 0.55f, 0.0f};
        int n = a.length;
        for (int i = 0; i < n; i++) {
            pA[i] = a[i];
            pR[i] = r[i];
        }
        for (int i = 0; i < n; i++) {                        // normals from the profile slope
            int i0 = Math.max(0, i - 1), i1 = Math.min(n - 1, i + 1);
            float tA = pA[i1] - pA[i0], tR = pR[i1] - pR[i0];
            float l = (float) Math.sqrt(tA * tA + tR * tR) + 1e-6f;
            pNA[i] = -tR / l;
            pNR[i] = tA / l;
        }
        revolved(ax, ay, az, n, flat, 8, tone, dim);
    }

    private void revolved(float ox, float oy, float oz, int n, float flat, int seg, int tone, float dim) {
        trig(seg);
        float ux = tmpU[0], uy = tmpU[1], uz = tmpU[2];
        float wx = tmpW[0], wy = tmpW[1], wz = tmpW[2];
        float vx_ = uy * wz - uz * wy, vy_ = uz * wx - ux * wz, vz_ = ux * wy - uy * wx;
        // to view space
        float Ux = m00 * ux + m01 * uy + m02 * uz, Uy = m10 * ux + m11 * uy + m12 * uz, Uz = m20 * ux + m21 * uy + m22 * uz;
        float Vx = m00 * vx_ + m01 * vy_ + m02 * vz_, Vy = m10 * vx_ + m11 * vy_ + m12 * vz_, Vz = m20 * vx_ + m21 * vy_ + m22 * vz_;
        float Wx = m00 * wx + m01 * wy + m02 * wz, Wy = m10 * wx + m11 * wy + m12 * wz, Wz = m20 * wx + m21 * wy + m22 * wz;
        float Ox = m00 * ox + m01 * oy + m02 * oz, Oy = m10 * ox + m11 * oy + m12 * oz, Oz = m20 * ox + m21 * oy + m22 * oz;
        final float invFlat = 1.0f / flat;
        final int stride = seg + 1;
        for (int i = 0; i < n; i++) {
            float A = pA[i], R = pR[i], nA = pNA[i], nR = pNR[i];
            for (int s = 0; s <= seg; s++) {
                float c = cosT[s], sn = sinT[s];
                int k = i * stride + s;
                float rc = R * c, rs = R * flat * sn;
                float px = Ox + Ux * A + Vx * rc + Wx * rs;
                float py = Oy + Uy * A + Vy * rc + Wy * rs;
                float pz = Oz + Uz * A + Vz * rc + Wz * rs;
                float nc = nR * c, ns = nR * sn * invFlat;
                float qx = Ux * nA + Vx * nc + Wx * ns;
                float qy = Uy * nA + Vy * nc + Wy * ns;
                float qz = Uz * nA + Vz * nc + Wz * ns;
                float ql = (float) Math.sqrt(qx * qx + qy * qy + qz * qz) + 1e-9f;
                vx[k] = px; vy[k] = py; vz[k] = pz;
                nxs[k] = qx / ql; nys[k] = qy / ql; nzs[k] = qz / ql;
                spx[k] = (cx + px * cpu) * ss;
                spy[k] = (cy + py * rpu) * ss;
            }
        }
        for (int i = 0; i < n - 1; i++) {
            for (int s = 0; s < seg; s++) {
                int a = i * stride + s, b = a + 1, c2 = a + stride, d = c2 + 1;
                tri(a, b, c2, tone, dim, false);
                tri(b, d, c2, tone, dim, false);
            }
        }
    }

    /** Box centred at c: half-size hu along 'axis', hv along v (= axis x lateral), hw along lateral. */
    void box(float cx0, float cy0, float cz0, float axx, float axy, float axz,
             float hu, float hv, float hw, int tone, float dim) {
        frame(axx, axy, axz);
        float ux = tmpU[0], uy = tmpU[1], uz = tmpU[2];
        float wx = tmpW[0], wy = tmpW[1], wz = tmpW[2];
        float vx_ = uy * wz - uz * wy, vy_ = uz * wx - ux * wz, vz_ = ux * wy - uy * wx;
        float[][] ax = {
                {m00 * ux + m01 * uy + m02 * uz, m10 * ux + m11 * uy + m12 * uz, m20 * ux + m21 * uy + m22 * uz},
                {m00 * vx_ + m01 * vy_ + m02 * vz_, m10 * vx_ + m11 * vy_ + m12 * vz_, m20 * vx_ + m21 * vy_ + m22 * vz_},
                {m00 * wx + m01 * wy + m02 * wz, m10 * wx + m11 * wy + m12 * wz, m20 * wx + m21 * wy + m22 * wz}};
        float[] hs = {hu, hv, hw};
        float Ox = m00 * cx0 + m01 * cy0 + m02 * cz0, Oy = m10 * cx0 + m11 * cy0 + m12 * cz0, Oz = m20 * cx0 + m21 * cy0 + m22 * cz0;
        for (int k = 0; k < 3; k++) {
            int k1 = (k + 1) % 3, k2 = (k + 2) % 3;
            for (int sg = -1; sg <= 1; sg += 2) {
                float fx = Ox + sg * hs[k] * ax[k][0], fy = Oy + sg * hs[k] * ax[k][1], fz = Oz + sg * hs[k] * ax[k][2];
                float qx = sg * ax[k][0], qy = sg * ax[k][1], qz = sg * ax[k][2];
                int q = 0;
                for (int a = -1; a <= 1; a += 2) {
                    for (int b = -1; b <= 1; b += 2) {
                        float px = fx + a * hs[k1] * ax[k1][0] + b * hs[k2] * ax[k2][0];
                        float py = fy + a * hs[k1] * ax[k1][1] + b * hs[k2] * ax[k2][1];
                        float pz = fz + a * hs[k1] * ax[k1][2] + b * hs[k2] * ax[k2][2];
                        vx[q] = px; vy[q] = py; vz[q] = pz;
                        nxs[q] = qx; nys[q] = qy; nzs[q] = qz;
                        spx[q] = (cx + px * cpu) * ss;
                        spy[q] = (cy + py * rpu) * ss;
                        q++;
                    }
                }
                tri(0, 1, 2, tone, dim, true);
                tri(1, 3, 2, tone, dim, true);
            }
        }
    }

    // ---- rasteriser --------------------------------------------------------------------------------
    private void tri(int i0, int i1, int i2, int tone, float dim, boolean flatFace) {
        // cull faces that point away from the viewer
        float cullT = flatFace ? 0.0f : -0.25f;
        if (nzs[i0] < cullT && nzs[i1] < cullT && nzs[i2] < cullT) return;
        float x0 = spx[i0], y0 = spy[i0], x1 = spx[i1], y1 = spy[i1], x2 = spx[i2], y2 = spy[i2];
        float area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
        if (area > -1e-5f && area < 1e-5f) return;
        float inv = 1.0f / area;
        int minX = (int) Math.floor(Math.min(x0, Math.min(x1, x2)));
        int maxX = (int) Math.ceil(Math.max(x0, Math.max(x1, x2)));
        int minY = (int) Math.floor(Math.min(y0, Math.min(y1, y2)));
        int maxY = (int) Math.ceil(Math.max(y0, Math.max(y1, y2)));
        if (minX < 0) minX = 0;
        if (minY < 0) minY = 0;
        if (maxX > W - 1) maxX = W - 1;
        if (maxY > H - 1) maxY = H - 1;
        if (minX > maxX || minY > maxY) return;
        float z0 = vz[i0], z1 = vz[i1], z2 = vz[i2];
        float ax = nxs[i0], ay = nys[i0], az = nzs[i0];
        float bx = nxs[i1], by = nys[i1], bz = nzs[i1];
        float cxn = nxs[i2], cyn = nys[i2], czn = nzs[i2];
        final float alb0 = ALB[tone][0], alb1 = ALB[tone][1], alb2 = ALB[tone][2];
        final boolean vc = vcOn;
        final float r0c = vcr[0], r1c = vcr[1], r2c = vcr[2], g0c = vcg[0], g1c = vcg[1], g2c = vcg[2], b0c = vcb[0], b1c = vcb[1], b2c = vcb[2];
        final float spec = SPEC[tone], shine = SHINE[tone], emit = EMIT[tone];
        final byte tb = (byte) tone;
        final float eps = -0.002f;
        for (int y = minY; y <= maxY; y++) {
            float py = y + 0.5f;
            for (int x = minX; x <= maxX; x++) {
                float px = x + 0.5f;
                float w0 = ((x1 - px) * (y2 - py) - (x2 - px) * (y1 - py)) * inv;
                float w1 = ((x2 - px) * (y0 - py) - (x0 - px) * (y2 - py)) * inv;
                float w2 = 1.0f - w0 - w1;
                if (w0 < eps || w1 < eps || w2 < eps) continue;
                float z = w0 * z0 + w1 * z1 + w2 * z2;
                int idx = y * W + x;
                if (z <= zb[idx]) continue;
                float nx = w0 * ax + w1 * bx + w2 * cxn;
                float ny = w0 * ay + w1 * by + w2 * cyn;
                float nz = w0 * az + w1 * bz + w2 * czn;
                float nl = (float) Math.sqrt(nx * nx + ny * ny + nz * nz) + 1e-9f;
                nx /= nl; ny /= nl; nz /= nl;
                float ndl = nx * LX + ny * LY + nz * LZ;
                if (ndl < 0.0f) ndl = 0.0f;
                float ndf = nx * FX + ny * FY + nz * FZ;
                if (ndf < 0.0f) ndf = 0.0f;
                float amb = 0.30f - 0.13f * ny;                          // sky-ish: up-facing surfaces catch more
                float lit = amb + 0.74f * ndl + 0.16f * ndf;
                float rimT = 1.0f - Math.max(0.0f, nz);
                lit += 0.20f * rimT * rimT * rimT;
                lit *= dim;
                float sp = 0.0f;
                if (spec > 0.0f) {
                    float nh = nx * HX + ny * HY + nz * HZ;
                    if (nh > 0.0f) sp = spec * (float) Math.pow(nh, shine);
                }
                float val = lit + emit;
                float lum = val > 1.0f ? 1.0f : (val < 0.0f ? 0.0f : val);
                float ar = alb0, ag = alb1, ab = alb2;
                if (vc) {                                               // baked texture colour (also darkens dark areas' glyphs)
                    ar = w0 * r0c + w1 * r1c + w2 * r2c;
                    ag = w0 * g0c + w1 * g1c + w2 * g2c;
                    ab = w0 * b0c + w1 * b1c + w2 * b2c;
                    float luma = 0.30f * ar + 0.59f * ag + 0.11f * ab;
                    lum *= Math.min(1.0f, 0.40f + 0.95f * luma);
                }
                float k = 0.16f + 0.92f * lum;
                int r = (int) (255.0f * Math.min(1.0f, ar * k + sp));
                int g = (int) (255.0f * Math.min(1.0f, ag * k + sp));
                int b = (int) (255.0f * Math.min(1.0f, ab * k + sp));
                zb[idx] = z;
                lumB[idx] = Math.min(1.0f, lum + sp * 0.5f);
                rgbB[idx] = 0xFF000000 | (r << 16) | (g << 8) | b;
                toneB[idx] = tb;
            }
        }
    }

    // ---- baked triangle mesh (per-corner colours) ---------------------------------------------------------
    private float[] mvx, mvy, mvz, mnx, mny, mnz, msx, msy;

    void mesh(float[] lx, float[] ly, float[] lz, float[] nx, float[] ny, float[] nz, int nV,
              int[] tris, int nT, int[] cornerSrc, int[] cornerRgb, int tone, float dim) {
        if (mvx == null || mvx.length < nV) {
            mvx = new float[nV]; mvy = new float[nV]; mvz = new float[nV];
            mnx = new float[nV]; mny = new float[nV]; mnz = new float[nV];
            msx = new float[nV]; msy = new float[nV];
        }
        for (int v = 0; v < nV; v++) {
            float f = lx[v], y = ly[v], l = lz[v];
            float px = m00 * f + m01 * y + m02 * l, py = m10 * f + m11 * y + m12 * l, pz = m20 * f + m21 * y + m22 * l;
            mvx[v] = px; mvy[v] = py; mvz[v] = pz;
            msx[v] = (cx + px * cpu) * ss;
            msy[v] = (cy + py * rpu) * ss;
            float a = nx[v], b = ny[v], c = nz[v];
            mnx[v] = m00 * a + m01 * b + m02 * c;
            mny[v] = m10 * a + m11 * b + m12 * c;
            mnz[v] = m20 * a + m21 * b + m22 * c;
        }
        vcOn = true;
        for (int t = 0; t < nT; t++) {
            for (int k = 0; k < 3; k++) {
                int c = tris[3 * t + k];
                int sv = cornerSrc[c];
                vx[k] = mvx[sv]; vy[k] = mvy[sv]; vz[k] = mvz[sv];
                nxs[k] = mnx[sv]; nys[k] = mny[sv]; nzs[k] = mnz[sv];
                spx[k] = msx[sv]; spy[k] = msy[sv];
                int rgb = cornerRgb[c];
                vcr[k] = ((rgb >> 16) & 255) * (1.0f / 255.0f);
                vcg[k] = ((rgb >> 8) & 255) * (1.0f / 255.0f);
                vcb[k] = (rgb & 255) * (1.0f / 255.0f);
            }
            tri(0, 1, 2, tone, dim, false);
        }
        vcOn = false;
    }

    // ---- debug / preview access ----------------------------------------------------------------------
    boolean covered(int x, int y) {
        return zb[y * W + x] > -1.0e8f;
    }

    int sampleRgb(int x, int y) {
        return rgbB[y * W + x];
    }

    // ---- 3D -> ASCII ----------------------------------------------------------------------------------
    private static final String HAIR_GLYPHS = "S8(3)~5s&${}";
    private static final String FIRE_GLYPHS = "*#%@&8";

    /**
     * Collapse the super-sampled render into glyph cells.
     * Outputs: glyph, luminance (-1 = empty), colour, depth marker (1 = body, -9 = empty; used to keep hair behind).
     */
    void toAscii(char[] g, float[] lumOut, int[] colOut, float[] zOut, String ramp) {
        final int area = ss * ss;
        final int rampMax = ramp.length() - 1;
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int ci = r * cols + c;
                int n = 0;
                float sl = 0.0f, sz = 0.0f, bestZ = -1.0e9f;
                int sr = 0, sg = 0, sb = 0;
                byte tone = 0;
                for (int j = 0; j < ss; j++) {
                    int row = (r * ss + j) * W + c * ss;
                    for (int i = 0; i < ss; i++) {
                        int idx = row + i;
                        float z = zb[idx];
                        if (z <= -1.0e8f) continue;
                        n++;
                        sl += lumB[idx];
                        sz += z;
                        int p = rgbB[idx];
                        sr += (p >> 16) & 255;
                        sg += (p >> 8) & 255;
                        sb += p & 255;
                        if (z > bestZ) {
                            bestZ = z;
                            tone = toneB[idx];
                        }
                    }
                }
                if (n == 0) {
                    cCov[ci] = 0.0f;
                    cZ[ci] = -1.0e9f;
                    continue;
                }
                cCov[ci] = n / (float) area;
                cZ[ci] = sz / n;
                cLum[ci] = sl / n;
                cCol[ci] = ((sr / n) << 16) | ((sg / n) << 8) | (sb / n);
                cTone[ci] = tone;
            }
        }
        final float gradScaleX = cpu * 0.5f;     // d(cov)/d(unit) with a +-1 cell stencil
        final float gradScaleY = rpu * 0.5f;
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int ci = r * cols + c;
                float cov = cCov[ci];
                if (cov < 0.20f) {
                    g[ci] = ' ';
                    lumOut[ci] = -1.0f;
                    zOut[ci] = -9.0f;
                    continue;
                }
                float lum = cLum[ci];
                byte tone = cTone[ci];
                char glyph;
                // coverage gradient (points toward the filled side)
                float covL = c > 0 ? cCov[ci - 1] : 0.0f, covR = c < cols - 1 ? cCov[ci + 1] : 0.0f;
                float covU = r > 0 ? cCov[ci - cols] : 0.0f, covD = r < rows - 1 ? cCov[ci + cols] : 0.0f;
                float gx = (covR - covL) * gradScaleX;
                float gy = (covD - covU) * gradScaleY;
                float gl = (float) Math.sqrt(gx * gx + gy * gy);

                // depth edge: this cell is clearly in front of a neighbour (an arm over the torso, ...)
                float dEdgeX = 0.0f, dEdgeY = 0.0f, dBest = 0.0f;
                final float zi = cZ[ci];
                if (c > 0 && cCov[ci - 1] > 0.3f && zi - cZ[ci - 1] > dBest + 0.0f && zi - cZ[ci - 1] > 0.085f) {
                    dBest = zi - cZ[ci - 1]; dEdgeX = -1.0f; dEdgeY = 0.0f;
                }
                if (c < cols - 1 && cCov[ci + 1] > 0.3f && zi - cZ[ci + 1] > dBest && zi - cZ[ci + 1] > 0.085f) {
                    dBest = zi - cZ[ci + 1]; dEdgeX = 1.0f; dEdgeY = 0.0f;
                }
                if (r > 0 && cCov[ci - cols] > 0.3f && zi - cZ[ci - cols] > dBest && zi - cZ[ci - cols] > 0.085f) {
                    dBest = zi - cZ[ci - cols]; dEdgeX = 0.0f; dEdgeY = -1.0f;
                }
                if (r < rows - 1 && cCov[ci + cols] > 0.3f && zi - cZ[ci + cols] > dBest && zi - cZ[ci + cols] > 0.085f) {
                    dBest = zi - cZ[ci + cols]; dEdgeX = 0.0f; dEdgeY = 1.0f;
                }

                boolean silhouette = cov < 0.66f && gl > 0.02f;
                if (silhouette) {
                    glyph = edgeGlyph(-gx, -gy, true);        // outward = away from the filled side
                } else if (dBest > 0.0f && lum < 0.93f) {
                    glyph = edgeGlyph(dEdgeX, dEdgeY, false);
                } else if (tone == Render3D.T_HAIR) {
                    glyph = HAIR_GLYPHS.charAt(((r * 7 + c * 13) & 0x7fffffff) % HAIR_GLYPHS.length());
                } else if (tone == Render3D.T_FIRE) {
                    glyph = FIRE_GLYPHS.charAt(((r * 5 + c * 11) & 0x7fffffff) % FIRE_GLYPHS.length());
                } else {
                    float l2 = (float) Math.pow(lum * (0.75f + 0.25f * cov), 0.62);   // gamma lift: denser glyphs in the mid-tones
                    int ri = (int) (l2 * rampMax);
                    if (ri < 4) ri = 4;
                    if (ri > rampMax) ri = rampMax;
                    glyph = ramp.charAt(ri);
                }
                g[ci] = glyph;
                lumOut[ci] = lum;
                zOut[ci] = 1.0f;
                // colour: mean sample colour, kept readable on dark ground
                int p = cCol[ci];
                int rr = (p >> 16) & 255, gg = (p >> 8) & 255, bb = p & 255;
                int mx = Math.max(rr, Math.max(gg, bb));
                if (mx < 150) {
                    float k = 150.0f / Math.max(1, mx);
                    if (k > 2.6f) k = 2.6f;
                    rr = Math.min(255, (int) (rr * k));
                    gg = Math.min(255, (int) (gg * k));
                    bb = Math.min(255, (int) (bb * k));
                }
                colOut[ci] = 0xFF000000 | (rr << 16) | (gg << 8) | bb;
            }
        }
    }

    /** (ox, oy) = outward normal of the edge in screen space (y down). */
    private static char edgeGlyph(float ox, float oy, boolean silhouette) {
        float ax = Math.abs(ox), ay = Math.abs(oy);
        float ang = (float) Math.atan2(ay, ax);       // 0 = normal horizontal (vertical edge), pi/2 = horizontal edge
        if (ang < 0.42f) {
            if (silhouette) return ox < 0.0f ? '(' : ')';
            return '|';
        }
        if (ang > 1.15f) {
            return oy < 0.0f ? '-' : '_';
        }
        return (ox * oy > 0.0f) ? '/' : '\\';
    }
}
