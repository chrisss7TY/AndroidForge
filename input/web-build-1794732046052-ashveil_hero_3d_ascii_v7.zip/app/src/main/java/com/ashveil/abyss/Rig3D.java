package com.ashveil.abyss;

/**
 * 3D rigs for the knight (on foot) and the horse + mounted knight. Pure Java.
 *
 * Both animators keep the original animation maths (planted-foot gait, idle layers, tuck-and-roll dodge, slash,
 * 4-beat walk -> gallop) but solve it in a real 3D local frame (f = forward, y = down, l = right-hand side) and
 * draw it as 3D meshes through {@link Render3D}. The heading turns the whole model in 3D.
 */
final class Rig3D {
    private Rig3D() {
    }

    static final float DODGE_DUR = 0.28f;
    static final float PITCH = 0.38f;           // camera tilt (radians) - the same gentle top-down tilt for both rigs

    static final class In {
        float t, velX, velY, facingX, facingY, gaitPhase, dodgeTimer, slashTimer;
    }

    // ---- helpers ---------------------------------------------------------------------------------------
    static float smooth01(float a, float b, float x) {
        float t = Math.max(0.0f, Math.min(1.0f, (x - a) / (b - a)));
        return t * t * (3.0f - 2.0f * t);
    }

    static float mix(float a, float b, float t) {
        return a + (b - a) * t;
    }

    static float wrapPi(float a) {
        final float TAU = 6.2831853f;
        while (a > Math.PI) a -= TAU;
        while (a < -Math.PI) a += TAU;
        return a;
    }

    /** Distance covered per full gait cycle (two steps). */
    static float cycleDist(float spd) {
        return Math.max(0.55f, Math.min(1.65f, 0.5f + 0.55f * spd));
    }

    private static final class Foot2 {
        float off, lift, heel, pitch;
    }

    /** Foot trajectory: stance slides back at ground speed, swing lifts and rolls through. */
    private static void footTraj(Foot2 o, float theta, float duty, float stride, float lift) {
        float u = theta / 6.2831853f;
        u -= (float) Math.floor(u);
        if (u < duty) {
            float q = u / duty;
            o.off = stride * (1.0f - 2.0f * q);
            o.lift = 0.0f;
            o.heel = 0.075f * smooth01(0.72f, 1.0f, q);
            o.pitch = 0.30f * (1.0f - smooth01(0.0f, 0.30f, q)) - 0.55f * smooth01(0.72f, 1.0f, q);
        } else {
            float s = (u - duty) / (1.0f - duty);
            float e = s * s * (3.0f - 2.0f * s);
            o.off = -stride + 2.0f * stride * e;
            o.lift = (float) Math.sin(Math.PI * Math.pow(s, 0.8)) * lift;
            o.heel = 0.0f;
            o.pitch = -0.55f * (1.0f - smooth01(0.0f, 0.35f, s)) + 0.30f * smooth01(0.6f, 1.0f, s);
        }
    }

    /** Planar two-bone IK in the (f, y) plane. bend > 0: joint points forward (+f), bend < 0: backward. Result in out[0..1]. */
    private static void ik2(float[] out, float hx, float hy, float fx, float fy, float l1, float l2, float bend) {
        float dx = fx - hx, dy = fy - hy;
        float d = (float) Math.sqrt(dx * dx + dy * dy + 1e-6f);
        float dc = Math.min(d, l1 + l2 - 0.01f);
        float a = (l1 * l1 - l2 * l2 + dc * dc) / (2.0f * dc);
        float h = (float) Math.sqrt(Math.max(0.0f, l1 * l1 - a * a));
        float ux = dx / d, uy = dy / d;
        float nx = -uy, ny = ux;
        if (nx * bend < 0.0f) {
            nx = -nx;
            ny = -ny;
        }
        float sc = Math.abs(bend);
        out[0] = hx + ux * a + nx * h * sc;
        out[1] = hy + uy * a + ny * h * sc;
    }

    // =============================================================================================
    // KNIGHT MODEL (shared by the foot rig and the rider)
    // =============================================================================================
    static final int PELVIS = 0, WAIST = 1, CHEST = 2, NECK = 3, HEAD = 4, SHR = 5, SHL = 6, ELR = 7, ELL = 8,
            WRR = 9, WRL = 10, HDR = 11, HDL = 12, HIPR = 13, HIPL = 14, KNR = 15, KNL = 16, ANR = 17, ANL = 18,
            TOER = 19, TOEL = 20, TIP = 21, NJ = 22;

    /** Joint positions in local (f, y, l). Right side (l > 0) is the sword side. */
    static final class Pose {
        final float[][] j = new float[NJ][3];
        float headYaw = 0.0f;       // head turn (radians, + = toward the right shoulder)
        float skirtSwing = 0.0f;    // tabard swing along f
        float breastY = 0.0f;       // chest rise (breathing)

        void set(int i, float f, float y, float l) {
            j[i][0] = f;
            j[i][1] = y;
            j[i][2] = l;
        }
    }

    private static void L(Render3D r, float[] a, float[] b, float r0, float r1, float flat, int tone, float dim) {
        r.limb(a[0], a[1], a[2], b[0], b[1], b[2], r0, r1, flat, tone, dim);
    }

    private static void E(Render3D r, float[] c, float ax, float ay, float az, float ru, float rv, float flat, int tone, float dim) {
        r.ell(c[0], c[1], c[2], ax, ay, az, ru, rv, flat, tone, dim);
    }

    /** Draw the knight from a pose. */
    static void drawKnight(Render3D r, Pose p) {
        final float[][] j = p.j;
        final float[] tmp = new float[3];
        final float[] tm2 = new float[3];
        final float[] P = j[PELVIS], W = j[WAIST], C = j[CHEST], N = j[NECK], H = j[HEAD];

        // ---- legs ----
        for (int side = 0; side < 2; side++) {
            boolean rt = side == 0;
            float[] hip = j[rt ? HIPR : HIPL], kn = j[rt ? KNR : KNL], an = j[rt ? ANR : ANL], toe = j[rt ? TOER : TOEL];
            float dim = rt ? 1.0f : 0.92f;
            L(r, hip, kn, 0.088f, 0.064f, 1.0f, Render3D.T_CLOTH, dim);                         // thigh (crimson hose)
            E(r, kn, 0, 0, 1, 0.052f, 0.056f, 1.0f, Render3D.T_STEEL, dim);                      // knee cop
            L(r, kn, an, 0.060f, 0.046f, 1.0f, Render3D.T_STEEL, dim);                          // greave
            tmp[0] = (an[0] + toe[0]) * 0.5f + 0.012f;
            tmp[1] = (an[1] + toe[1]) * 0.5f + 0.018f;
            tmp[2] = (an[2] + toe[2]) * 0.5f;
            E(r, tmp, toe[0] - an[0], toe[1] - an[1] + 0.001f, 0, 0.085f, 0.048f, 0.95f, Render3D.T_LEATHER, dim);   // boot
        }

        // ---- pelvis, tabard, torso ----
        E(r, P, 0, 0, 1, 0.128f, 0.090f, 0.95f, Render3D.T_CLOTH, 0.95f);                      // hips
        // tabard front + back panels hang from the belt
        tmp[0] = W[0] + 0.105f; tmp[1] = W[1] + 0.02f; tmp[2] = W[2];
        tm2[0] = P[0] + 0.125f + p.skirtSwing; tm2[1] = P[1] + 0.27f; tm2[2] = P[2];
        r.box((tmp[0] + tm2[0]) * 0.5f, (tmp[1] + tm2[1]) * 0.5f, (tmp[2] + tm2[2]) * 0.5f,
                tm2[0] - tmp[0], tm2[1] - tmp[1], tm2[2] - tmp[2], 0.5f * (float) Math.hypot(tm2[0] - tmp[0], tm2[1] - tmp[1]), 0.014f, 0.082f, Render3D.T_CLOTH, 1.0f);
        tmp[0] = W[0] - 0.105f; tm2[0] = P[0] - 0.125f - p.skirtSwing * 0.6f;
        r.box((tmp[0] + tm2[0]) * 0.5f, (tmp[1] + tm2[1]) * 0.5f, (tmp[2] + tm2[2]) * 0.5f,
                tm2[0] - tmp[0], tm2[1] - tmp[1], tm2[2] - tmp[2], 0.5f * (float) Math.hypot(tm2[0] - tmp[0], tm2[1] - tmp[1]), 0.014f, 0.082f, Render3D.T_CLOTH, 0.85f);
        L(r, P, W, 0.098f, 0.100f, 1.25f, Render3D.T_CLOTH, 0.95f);                                  // abdomen
        // breastplate (steel) over the chest, slightly proud of the cloth
        tmp[0] = (C[0] + j[SHR][0] + j[SHL][0]) / 3.0f + 0.012f;
        tmp[1] = (C[1] + j[SHR][1]) * 0.5f - 0.01f + p.breastY;
        tmp[2] = (C[2] + j[SHR][2] + j[SHL][2]) / 3.0f;
        E(r, tmp, C[0] - W[0] + 0.001f, C[1] - W[1] - 0.12f, 0, 0.155f, 0.118f, 1.38f, Render3D.T_STEEL, 1.0f);
        L(r, W, C, 0.108f, 0.114f, 1.30f, Render3D.T_CLOTH, 0.95f);                                  // lower chest cloth
        // belt + buckle
        tmp[0] = W[0] + 0.002f; tmp[1] = W[1] + 0.02f; tmp[2] = W[2];
        E(r, tmp, 0, 1, 0, 0.034f, 0.118f, 1.28f, Render3D.T_LEATHER, 1.0f);
        tmp[0] = W[0] + 0.118f; tmp[1] = W[1] + 0.02f; tmp[2] = W[2];
        E(r, tmp, 0, 1, 0, 0.026f, 0.020f, 1.5f, Render3D.T_GOLD, 1.0f);
        // pauldrons + gorget + neck
        for (int side = 0; side < 2; side++) {
            float[] sh = j[side == 0 ? SHR : SHL];
            tmp[0] = sh[0]; tmp[1] = sh[1] - 0.02f; tmp[2] = sh[2] + (side == 0 ? 0.022f : -0.022f);
            E(r, tmp, 0.0f, 1.0f, 0.18f * (side == 0 ? 1 : -1), 0.060f, 0.092f, 1.0f, Render3D.T_STEEL, 1.0f);
            tmp[1] = sh[1] - 0.015f;
            E(r, tmp, 0, 1, 0, 0.030f, 0.100f, 1.0f, Render3D.T_GOLD, 0.85f);                       // gold rim ring (flat disc)
        }
        L(r, N, H, 0.042f, 0.040f, 1.0f, Render3D.T_SKIN, 0.9f);                                      // neck
        tmp[0] = N[0]; tmp[1] = N[1] + 0.012f; tmp[2] = N[2];
        E(r, tmp, 0, 1, 0, 0.026f, 0.075f, 1.0f, Render3D.T_STEEL, 1.0f);                             // gorget

        // ---- head ----
        final float cy = (float) Math.cos(p.headYaw), sy = (float) Math.sin(p.headYaw);
        tmp[0] = H[0] + 0.012f * cy; tmp[1] = H[1]; tmp[2] = H[2] + 0.012f * sy;
        E(r, tmp, 0, 1, 0, 0.100f, 0.086f, 0.90f, Render3D.T_SKIN, 1.0f);                             // face / skull
        tmp[0] = H[0] + 0.088f * cy; tmp[1] = H[1] + 0.018f; tmp[2] = H[2] + 0.088f * sy;
        E(r, tmp, cy, 0.25f, sy, 0.032f, 0.026f, 0.85f, Render3D.T_SKIN, 1.0f);                       // nose
        // hair: cap on top / back / sides, long fall behind
        tmp[0] = H[0] - 0.034f * cy; tmp[1] = H[1] - 0.034f; tmp[2] = H[2] - 0.034f * sy;
        E(r, tmp, 0, 1, 0, 0.100f, 0.096f, 1.0f, Render3D.T_HAIR, 1.0f);
        tmp[0] = H[0] - 0.068f * cy; tmp[1] = H[1] + 0.02f; tmp[2] = H[2] - 0.068f * sy;
        tm2[0] = H[0] - 0.095f * cy; tm2[1] = H[1] + 0.17f; tm2[2] = H[2] - 0.095f * sy;
        L(r, tmp, tm2, 0.070f, 0.052f, 1.25f, Render3D.T_HAIR, 0.95f);
        // thin gold circlet
        tmp[0] = H[0] - 0.004f * cy; tmp[1] = H[1] - 0.066f; tmp[2] = H[2] - 0.004f * sy;
        E(r, tmp, 0, 1, 0, 0.012f, 0.100f, 0.90f, Render3D.T_GOLD, 1.0f);

        // ---- arms ----
        for (int side = 0; side < 2; side++) {
            boolean rt = side == 0;
            float[] sh = j[rt ? SHR : SHL], el = j[rt ? ELR : ELL], wr = j[rt ? WRR : WRL], hd = j[rt ? HDR : HDL];
            float dim = rt ? 1.0f : 0.90f;
            L(r, sh, el, 0.054f, 0.047f, 1.0f, Render3D.T_CLOTH, dim);                                // sleeve
            E(r, el, 0, 0, 1, 0.044f, 0.046f, 1.0f, Render3D.T_STEEL, dim);                           // couter
            L(r, el, wr, 0.046f, 0.040f, 1.0f, Render3D.T_STEEL, dim);                                // vambrace
            E(r, hd, wr[0] - hd[0] + 0.001f, wr[1] - hd[1], wr[2] - hd[2], 0.050f, 0.040f, 0.9f, Render3D.T_STEEL, dim);   // gauntlet
        }

        // ---- sword (right hand) ----
        float[] hd = j[HDR];
        float bdx = j[TIP][0] - hd[0], bdy = j[TIP][1] - hd[1], bdz = j[TIP][2] - hd[2];
        float bl = (float) Math.sqrt(bdx * bdx + bdy * bdy + bdz * bdz) + 1e-6f;
        bdx /= bl; bdy /= bl; bdz /= bl;
        r.limb(hd[0] - bdx * 0.085f, hd[1] - bdy * 0.085f, hd[2] - bdz * 0.085f, hd[0] + bdx * 0.05f, hd[1] + bdy * 0.05f, hd[2] + bdz * 0.05f,
                0.020f, 0.020f, 1.0f, Render3D.T_LEATHER, 1.0f);                                      // grip
        r.ell(hd[0] - bdx * 0.105f, hd[1] - bdy * 0.105f, hd[2] - bdz * 0.105f, bdx, bdy, bdz, 0.030f, 0.030f, 1.0f, Render3D.T_GOLD, 1.0f);  // pommel
        r.box(hd[0] + bdx * 0.062f, hd[1] + bdy * 0.062f, hd[2] + bdz * 0.062f, bdx, bdy, bdz, 0.011f, 0.085f, 0.014f, Render3D.T_GOLD, 1.0f);  // crossguard
        r.blade(hd[0] + bdx * 0.072f, hd[1] + bdy * 0.072f, hd[2] + bdz * 0.072f, j[TIP][0], j[TIP][1], j[TIP][2], 0.034f, 0.36f, Render3D.T_FIRE, 1.0f);
    }

    // =============================================================================================
    // KNIGHT ON FOOT
    // =============================================================================================
    static final class Foot {
        private float walkS, runS, rec, lastT = -1.0f, hAng;
        private boolean init;
        private final Pose pose = new Pose();
        private final Foot2 fo = new Foot2();
        private final float[] ik = new float[2];
        private final float[] pr = new float[3];
        // outputs: hair anchor (rig screen units, same space as the old rig)
        float headX, headY;

        void update(Render3D r, In in) {
            final float PI = (float) Math.PI;
            final float t = in.t;
            float dt = lastT < 0.0f ? 0.016f : Math.max(0.0f, Math.min(0.05f, t - lastT));
            lastT = t;

            float spd = (float) Math.sqrt(in.velX * in.velX + in.velY * in.velY);
            boolean dodging = in.dodgeTimer > 0.0f;
            float p = dodging ? Math.max(0.0f, 1.0f - in.dodgeTimer / DODGE_DUR) : 0.0f;
            walkS += (smooth01(0.15f, 1.5f, spd) - walkS) * Math.min(1.0f, dt * 10.0f);
            runS += (smooth01(2.3f, 3.9f, spd) - runS) * Math.min(1.0f, dt * 7.0f);
            final float walk = walkS, idle = 1.0f - walk, run = runS;

            // heading: turns through the shortest arc, so the knight visibly pivots (front / side / back)
            float tgt = (in.facingX * in.facingX + in.facingY * in.facingY > 1e-6f) ? (float) Math.atan2(in.facingY, in.facingX) : hAng;
            if (!init) {
                hAng = tgt;
                init = true;
            } else {
                hAng += wrapPi(tgt - hAng) * Math.min(1.0f, dt * 14.0f);
            }
            r.setView((float) Math.cos(hAng), (float) Math.sin(hAng), PITCH);

            final float ph = in.gaitPhase;
            final float breath = (float) Math.sin(t * 2.0f);
            final float breathLag = (float) Math.sin(t * 2.0f - 0.7f);
            final float shift = (float) Math.sin(t * 0.62f);
            final float gl = (float) Math.sin(t * 0.41f);
            final float glance = gl > 0.0f ? (float) Math.pow(gl, 6.0) : 0.0f;
            final float look = (float) Math.sin(t * 0.5f);

            // slash
            float slashProg = (in.slashTimer > 0.0f) ? (1.0f - in.slashTimer / 0.26f) : -1.0f;
            float slashE = slashProg >= 0.0f ? slashProg * slashProg * (3.0f - 2.0f * slashProg) : 0.0f;
            float lunge = slashProg >= 0.0f ? (float) Math.sin(Math.PI * slashProg) : 0.0f;
            float wS = slashProg >= 0.0f ? smooth01(0.0f, 0.12f, slashProg) * (1.0f - smooth01(0.82f, 1.0f, slashProg)) : 0.0f;

            // dodge: crouch -> tucked forward roll -> unfold -> short recovery crouch
            final float k = dodging ? smooth01(0.0f, 0.17f, p) * (1.0f - smooth01(0.78f, 0.97f, p)) : 0.0f;
            if (dodging) rec = 1.0f;
            else rec = Math.max(0.0f, rec - dt / 0.22f);
            final float recS = dodging ? smooth01(0.80f, 1.0f, p) : smooth01(0.0f, 1.0f, rec);
            final float ang = dodging ? 2.0f * PI * smooth01(0.10f, 0.92f, p) : 0.0f;
            final float hop = dodging ? 0.15f * (float) Math.sin(PI * smooth01(0.06f, 0.94f, p)) : 0.0f;

            // gait
            final float ground = 0.82f;
            float cycle = cycleDist(spd);
            float duty = 0.60f - 0.14f * run;
            float stride = 0.5f * duty * cycle * 1.06f;
            float liftMax = 0.07f + 0.09f * run;
            float bobAmp = 0.018f + 0.034f * run;
            float stepBob = bobAmp * walk * (float) Math.cos(2.0f * ph);
            float bodyY = stepBob + 0.020f * walk + 0.040f * run + 0.008f * breath * idle + 0.010f * shift * shift * idle
                    + 0.07f * lunge + 0.10f * recS;
            float hipLat = 0.022f * shift * idle + 0.030f * (float) Math.cos(ph - 1.9f) * walk;
            float hipY = -0.005f + bodyY;

            // spine
            float lean = 0.015f + 0.04f * walk + 0.075f * run + 0.11f * lunge + 0.08f * recS;
            float tw = slashProg >= 0.0f ? (slashE - 0.5f) * 0.55f : 0.0f;
            float stw = (float) Math.sin(tw), ctw = (float) Math.cos(tw);
            float Px = 0.0f, Py = hipY, Pl = hipLat;
            float Wx = 0.30f * lean, Wy = Py - 0.17f, Wl = hipLat * 0.7f;
            float Cx = 0.65f * lean, Cy = Py - 0.36f - 0.012f * breath * idle, Cl = hipLat * 0.4f;
            float Sx = lean, Sy = Py - 0.50f - 0.012f * breathLag * idle, Sl = hipLat * 0.2f;
            float Nx = Sx + 0.20f * lean, Ny = Sy - 0.06f;
            float Hx = Nx + 0.02f, Hy = Ny - 0.115f - 0.5f * stepBob - 0.004f * breath + 0.02f * recS;
            float shRx = Sx + 0.19f * stw, shRl = Sl + 0.19f * ctw, shY = Sy + 0.02f;
            float shLx = Sx - 0.19f * stw, shLl = Sl - 0.19f * ctw;

            Pose ps = pose;
            ps.headYaw = 0.45f * look * idle + 0.60f * glance * idle - 0.25f * tw;
            ps.skirtSwing = 0.05f * lunge - 0.03f * walk * (float) Math.sin(ph) + 0.05f * run;
            ps.breastY = -0.006f * breath * idle;
            ps.set(PELVIS, Px, Py, Pl);
            ps.set(WAIST, Wx, Wy, Wl);
            ps.set(CHEST, Cx, Cy, Cl);
            ps.set(NECK, Nx, Ny, Sl);
            ps.set(HEAD, Hx, Hy, Sl);
            ps.set(SHR, shRx, shY, shRl);
            ps.set(SHL, shLx, shY, shLl);

            // legs (planted-foot IK in the f-y plane)
            for (int leg = 0; leg < 2; leg++) {
                boolean rt = leg == 0;
                float sd = rt ? 1.0f : -1.0f;
                float theta = ph + (rt ? 0.0f : PI);
                footTraj(fo, theta, duty, stride, liftMax);
                float stance = rt ? (0.10f + 0.20f * lunge) : (-0.08f - 0.12f * lunge);
                float off = mix(stance, fo.off + (rt ? 0.10f * lunge : 0.0f), walk);
                float lift = fo.lift * walk, heel = fo.heel * walk, pitch = fo.pitch * walk;
                float hjl = hipLat + sd * 0.078f, hjy = hipY + 0.01f;
                float ankF = off, ankY = ground - 0.05f - lift - heel, ankL = hipLat * 0.4f + sd * 0.085f;
                ik2(ik, 0.0f, hjy, ankF, ankY, 0.40f, 0.40f, 1.0f);
                float toeF = ankF + 0.13f * (float) Math.cos(pitch), toeY = ankY + 0.035f - 0.10f * (float) Math.sin(pitch);
                ps.set(rt ? HIPR : HIPL, 0.0f, hjy, hjl);
                ps.set(rt ? KNR : KNL, ik[0], ik[1], mix(hjl, ankL, 0.5f) + sd * 0.012f);
                ps.set(rt ? ANR : ANL, ankF, ankY, ankL);
                ps.set(rt ? TOER : TOEL, toeF, toeY, ankL);
            }

            // arms: forward kinematics in the f-y plane (angle from forward toward down)
            final float UL = 0.29f, FL = 0.26f;
            float cw = (float) Math.cos(ph - 0.35f);
            float aF = PI * 0.5f - 0.05f + 0.02f * breathLag * idle - (0.28f * walk + 0.50f * run) * cw - 0.5f * recS;
            float bF = 0.12f + 0.02f * breath * idle + 0.15f * walk + (0.90f + 0.25f * cw) * run;
            float aNidle = 1.22f + 0.02f * breathLag, bNidle = 0.95f + 0.03f * breath;
            float aNmove = 1.05f - 0.08f * cw * walk, bNmove = 1.00f + 0.15f * run;
            float aN = mix(aNidle, aNmove, walk), bN = mix(bNidle, bNmove, walk);
            float sRelIdle = 0.45f + 0.04f * (float) Math.sin(t * 1.1f), sRelMove = 0.15f - 0.50f * run;
            float aS = (aN - bN) + mix(sRelIdle, sRelMove, walk);
            if (wS > 0.0f) {
                float aSs = -1.7f + 3.5f * slashE;
                float aFs = aSs - 0.10f;
                float bs = 0.10f + 0.45f * (1.0f - (float) Math.sin(PI * slashProg));
                aN = mix(aN, aFs + bs, wS);
                bN = mix(bN, bs, wS);
                aS = mix(aS, aSs, wS);
            }
            // far (left) arm
            float lEx = shLx + UL * (float) Math.cos(aF), lEy = shY + UL * (float) Math.sin(aF);
            float lWx = lEx + FL * (float) Math.cos(aF - bF), lWy = lEy + FL * (float) Math.sin(aF - bF);
            float lHx = lWx + 0.05f * (float) Math.cos(aF - bF), lHy = lWy + 0.05f * (float) Math.sin(aF - bF);
            ps.set(ELL, lEx, lEy, shLl - 0.035f);
            ps.set(WRL, lWx, lWy, shLl * 0.9f);
            ps.set(HDL, lHx, lHy, shLl * 0.85f);
            // near (right / sword) arm
            float rEx = shRx + UL * (float) Math.cos(aN), rEy = shY + UL * (float) Math.sin(aN);
            float rWx = rEx + FL * (float) Math.cos(aN - bN), rWy = rEy + FL * (float) Math.sin(aN - bN);
            float rHx = rWx + 0.05f * (float) Math.cos(aN - bN), rHy = rWy + 0.05f * (float) Math.sin(aN - bN);
            ps.set(ELR, rEx, rEy, shRl + 0.035f);
            ps.set(WRR, rWx, rWy, shRl * 0.9f);
            ps.set(HDR, rHx, rHy, shRl * 0.8f);
            float bladeLen = 0.60f;
            ps.set(TIP, rHx + (float) Math.cos(aS) * bladeLen, rHy + (float) Math.sin(aS) * bladeLen, shRl * 0.8f);

            // dodge tuck: blend every joint toward a curled ball (forward roll)
            if (k > 0.0f) {
                tuck(ps, PELVIS, -0.16f, 0.62f, k);
                tuck(ps, WAIST, -0.24f, 0.46f, k);
                tuck(ps, CHEST, -0.14f, 0.26f, k);
                tuck(ps, NECK, 0.16f, 0.27f, k);
                tuck(ps, HEAD, 0.26f, 0.42f, k);
                tuck(ps, SHR, 0.06f, 0.24f, k);
                tuck(ps, SHL, 0.00f, 0.24f, k);
                tuck(ps, HIPR, -0.12f, 0.62f, k);
                tuck(ps, HIPL, -0.20f, 0.62f, k);
                tuck(ps, KNR, 0.24f, 0.50f, k);
                tuck(ps, KNL, 0.20f, 0.44f, k);
                tuck(ps, ANR, -0.02f, 0.70f, k);
                tuck(ps, ANL, 0.02f, 0.66f, k);
                tuck(ps, TOER, 0.08f, 0.72f, k);
                tuck(ps, TOEL, 0.12f, 0.68f, k);
                tuck(ps, ELR, 0.18f, 0.40f, k);
                tuck(ps, WRR, 0.26f, 0.54f, k);
                tuck(ps, HDR, 0.24f, 0.58f, k);
                tuck(ps, ELL, 0.10f, 0.38f, k);
                tuck(ps, WRL, 0.22f, 0.56f, k);
                tuck(ps, HDL, 0.22f, 0.62f, k);
                tuck(ps, TIP, ps.j[HDR][0] - 0.50f, ps.j[HDR][1] - 0.26f, k);
                ps.skirtSwing = mix(ps.skirtSwing, -0.04f, k);
            }

            // roll / hop transform about the pivot (forward roll about the lateral axis)
            if (ang != 0.0f || hop != 0.0f) {
                float c = (float) Math.cos(ang), s = (float) Math.sin(ang);
                final float pvx = 0.05f, pvy = 0.47f;
                for (int i = 0; i < NJ; i++) {
                    float dx = ps.j[i][0] - pvx, dy = ps.j[i][1] - pvy;
                    ps.j[i][0] = pvx + dx * c - dy * s;
                    ps.j[i][1] = pvy + dx * s + dy * c - hop;
                }
            }

            r.clear();
            drawKnight(r, ps);

            // hair anchor: back of the (possibly rolling) head, projected to the screen
            r.project(ps.j[HEAD][0] - 0.08f, ps.j[HEAD][1] - 0.01f, ps.j[HEAD][2], pr);
            headX = pr[0];
            headY = pr[1];
        }

        private static float bobPhase(float v) {
            return v * 4.0f;
        }

        private static void tuck(Pose ps, int i, float f, float y, float k) {
            ps.j[i][0] = mix(ps.j[i][0], f, k);
            ps.j[i][1] = mix(ps.j[i][1], y, k);
            ps.j[i][2] = ps.j[i][2];
        }
    }

    // =============================================================================================
    // HORSE + MOUNTED KNIGHT
    // =============================================================================================
    static final class Horse {
        private float hAng, lastT = -1.0f;
        private boolean init;
        private final Pose pose = new Pose();
        private final float[] ik = new float[2];
        private final float[] pr = new float[3];
        private final float[] legF = new float[4], legY = new float[4], legL = new float[4];
        private final float[] kneeF = new float[4], kneeY = new float[4];
        private final Foot2 fo = new Foot2();
        // anchors for the strand-based mane / tail / hair (rig screen units relative to the horse origin)
        float tailX, tailY, maneX, maneY, headX, headY, neckBaseX, neckBaseY, neckTopX, neckTopY;
        /** true = draw only the horse + saddle (like the reference picture), no mounted knight. */
        boolean riderless = false;
        /** the baked 3D walking horse; when null the procedural primitive horse below is used instead */
        HorseMesh mesh;
        private float cyc;                 // mesh walk cycle (distance driven)
        private static final float STRIDE_D = 0.95f;   // rig units covered per mesh walk cycle (no foot sliding at walk pace)

        void update(Render3D r, In in) {
            final float PI = (float) Math.PI;
            final float t = in.t;
            float dt = lastT < 0.0f ? 0.016f : Math.max(0.0f, Math.min(0.05f, t - lastT));
            lastT = t;

            float tgt = (in.facingX * in.facingX + in.facingY * in.facingY > 1e-6f) ? (float) Math.atan2(in.facingY, in.facingX) : hAng;
            if (!init) {
                hAng = tgt;
                init = true;
            } else {
                hAng += wrapPi(tgt - hAng) * Math.min(1.0f, dt * 10.0f);
            }
            r.setView((float) Math.cos(hAng), (float) Math.sin(hAng), PITCH);
            r.clear();

            float spd = (float) Math.sqrt(in.velX * in.velX + in.velY * in.velY);
            float sf = Math.min(1.0f, spd / 4.6f);
            float g = smooth01(0.40f, 0.82f, sf);          // 0 = walk, 1 = gallop
            float mv = Math.min(1.0f, spd / 1.4f);         // 0 = standing
            float ph = in.gaitPhase;

            boolean dodging = in.dodgeTimer > 0.0f;
            float p = dodging ? Math.max(0.0f, 1.0f - in.dodgeTimer / DODGE_DUR) : 0.0f;
            float k = dodging ? smooth01(0.05f, 0.20f, p) * (1.0f - smooth01(0.82f, 0.97f, p)) : 0.0f;
            float leap = dodging ? (float) Math.sin(Math.PI * p) * 0.30f : 0.0f;

            // body motion
            float bob = 0.035f * mv * (1.0f - g) * (float) Math.cos(2.0f * ph) + 0.070f * mv * g * (float) Math.cos(ph + 0.6f);
            float pitch = (float) Math.sin(ph) * 0.07f * g * mv;
            float breathe = (float) Math.sin(t * 1.8f) * 0.012f * (1.0f - mv);
            float bodyOff = bob + breathe - leap;

            float rearF = -0.56f, rearY = -0.05f + bodyOff + pitch;
            float frontF = 0.52f + 0.08f * k, frontY = -0.08f + bodyOff - pitch - 0.05f * k;

            // legs
            final float ground = 1.04f;
            float[] legHip = {-0.58f, 0.52f, -0.46f, 0.62f};       // 0 hind far, 1 front far, 2 hind near, 3 front near
            float[] walkFrac = {0.50f, 0.75f, 0.00f, 0.25f};
            float[] gallopFrac = {0.00f, 0.50f, 0.12f, 0.62f};
            float strideS = (0.18f + 0.22f * g) * mv;
            float liftL = (0.13f + 0.13f * g) * mv;
            float duty = mix(0.62f, 0.38f, g);
            float pawT = t % 8.0f;
            float paw = 0.0f;
            if (mv < 0.15f && pawT < 1.6f) {
                paw = Math.max(0.0f, (float) Math.sin(pawT * 10.0f)) * 0.18f * (float) Math.sin(Math.PI * pawT / 1.6f);
            }
            final Foot2 fo = this.fo;
            if (mesh == null) {
            float restC = (t % 15.0f) / 15.0f;
            float restEnv = smooth01(0.06f, 0.14f, restC) * (1.0f - smooth01(0.55f, 0.63f, restC)) * (1.0f - mv);
            for (int leg = 0; leg < 4; leg++) {
                boolean front = (leg & 1) == 1;
                boolean near = leg >= 2;
                float frac = mix(walkFrac[leg], gallopFrac[leg], g);
                footTraj(fo, ph + frac * 6.2831853f, duty, strideS, liftL);
                float lat = (near ? 1.0f : -1.0f) * (front ? 0.145f : 0.175f);
                float hipF = legHip[leg];
                float hipY = 0.08f + bodyOff + (front ? -pitch : pitch);
                float footF = hipF + fo.off;
                float footY = ground - fo.lift;
                if (leg == 3) footY -= paw;
                if (leg == 0) {                                    // idle: rest the far hind leg on its toe
                    footY -= 0.075f * restEnv;
                    footF -= 0.07f * restEnv;
                }
                if (k > 0.0f) {
                    footF = mix(footF, hipF + (front ? 0.52f : -0.50f), k);
                    footY = mix(footY, hipY + (front ? 0.50f : 0.46f), k);
                }
                ik2(ik, hipF, hipY, footF, footY, 0.48f, 0.49f, front ? 1.0f : -1.0f);
                legF[leg] = footF;
                legY[leg] = footY;
                legL[leg] = lat;
                kneeF[leg] = ik[0];
                kneeY[leg] = ik[1];
                float[] hipP = {hipF, hipY, lat * 0.85f}, kn = {ik[0], ik[1], lat}, ft = {footF, footY, lat};
                float dim = near ? 1.0f : 0.84f;
                float r0 = front ? 0.100f : 0.122f;
                // upper leg: pale coat down to mid-forearm / gaskin, then the charcoal "socks" like the reference
                float sp = front ? 0.46f : 0.56f;
                float[] sm = {mix(hipP[0], kn[0], sp), mix(hipP[1], kn[1], sp), mix(hipP[2], kn[2], sp)};
                float rm = mix(r0, 0.056f, sp);
                L(r, hipP, sm, r0, rm, 1.0f, Render3D.T_HORSE, dim);
                L(r, sm, kn, rm * 1.02f, 0.056f, 1.0f, Render3D.T_LEG, dim);
                E(r, sm, 1, 0, 0, rm * 1.15f, rm * 1.05f, 0.95f, Render3D.T_HORSE, dim * 0.97f);            // blend patch (ragged coat edge)
                E(r, kn, 0, 0, 1, 0.056f, 0.058f, 1.0f, Render3D.T_LEG, dim);                               // knee / hock
                if (!front) {                                                                                // point of the hock
                    E(r, new float[]{kn[0] - 0.035f, kn[1] + 0.01f, kn[2]}, 0, 1, 0, 0.040f, 0.030f, 0.9f, Render3D.T_LEG, dim);
                }
                float fy0 = footY - 0.045f;
                L(r, kn, new float[]{footF, fy0, lat}, 0.044f, 0.034f, 1.0f, Render3D.T_LEG, dim * 0.98f);   // cannon
                E(r, new float[]{footF, fy0, lat}, 0, 0, 1, 0.038f, 0.040f, 1.0f, Render3D.T_LEG, dim);      // fetlock
                float[] hf = {footF + 0.016f, footY + 0.014f, lat};
                L(r, new float[]{footF, fy0, lat}, hf, 0.032f, 0.036f, 1.0f, Render3D.T_LEG, dim);           // pastern
                E(r, new float[]{hf[0] + 0.012f, hf[1] + 0.008f, lat}, 0.0f, 1.0f, 0.0f, 0.040f, 0.060f, 1.0f, Render3D.T_HOOF, dim); // hoof
            }
            }

            // barrel, haunch, chest, shoulder + hip muscles (deep chest, rounded croup like the reference)
            float midY, nod = 0.0f, neckTopF = 0.0f, neckTopY = 0.0f, muzzleF = 0.0f, muzzleY = 0.0f, tailRootF = 0.0f, tailRootY = 0.0f;
            if (mesh == null) {
            midY = (rearY + frontY) * 0.5f;
            float[] rear = {rearF, rearY, 0}, front = {frontF, frontY, 0};
            r.limb(rear[0], rear[1], 0, front[0], front[1], 0, 0.30f, 0.30f, 0.86f, Render3D.T_HORSE, 1.0f);          // barrel
            r.ell(rearF * 0.92f, rearY - 0.03f, 0, 1, 0, 0, 0.31f, 0.28f, 0.92f, Render3D.T_HORSE, 1.0f);            // croup / haunch
            r.ell(frontF - 0.02f, frontY + 0.03f, 0, 1, 0, 0, 0.28f, 0.28f, 0.88f, Render3D.T_HORSE, 1.0f);          // chest
            for (int sd = -1; sd <= 1; sd += 2) {
                float dm = sd > 0 ? 1.0f : 0.86f;
                r.ell(frontF - 0.10f, frontY + 0.02f, sd * 0.19f, 1, 0.45f, 0, 0.20f, 0.15f, 0.50f, Render3D.T_HORSE, dm);       // shoulder
                r.ell(rearF * 0.80f, rearY + 0.04f, sd * 0.20f, 1, 0.25f, 0, 0.22f, 0.20f, 0.50f, Render3D.T_HORSE, dm);          // thigh muscle
            }
            r.ell(frontF + 0.02f, frontY - 0.27f, 0, 1, 0, 0, 0.12f, 0.05f, 1.2f, Render3D.T_HORSE, 1.0f);              // withers

            // neck + head (long arched neck, long refined head)
            nod = (float) Math.sin(ph - 0.8f) * 0.07f * (0.3f + 0.7f * mv) * mv;
            float dipEnv = Math.max(0.0f, (float) Math.sin(t * 0.45f));
            float dip = dipEnv * dipEnv * 0.30f * (1.0f - mv);
            float tossC = t % 11.0f;                                                   // occasional head toss when standing
            float toss = tossC < 0.7f ? (float) Math.sin(Math.PI * tossC / 0.7f) * 0.11f * (1.0f - mv) : 0.0f;
            neckTopF = frontF + (0.30f + 0.10f * g + 0.12f * k - dip * 0.4f - 0.04f * toss);
            neckTopY = frontY - 0.80f + 0.16f * g + nod + dip + 0.20f * k - toss;
            r.limb(frontF - 0.04f, frontY - 0.04f, 0, neckTopF, neckTopY, 0, 0.30f, 0.140f, 0.74f, Render3D.T_HORSE, 1.0f);
            muzzleF = neckTopF + 0.31f; muzzleY = neckTopY + 0.32f + 0.08f * g + dip * 0.35f;
            r.limb(neckTopF + 0.00f, neckTopY - 0.01f, 0, muzzleF, muzzleY, 0, 0.150f, 0.095f, 0.80f, Render3D.T_HORSE, 1.0f);   // head
            r.ell(neckTopF + 0.07f, neckTopY + 0.10f, 0, 1, 0.5f, 0, 0.12f, 0.115f, 0.82f, Render3D.T_HORSE, 1.0f);                // jaw / cheek
            r.ell(muzzleF + 0.012f, muzzleY + 0.004f, 0, 1.0f, 0.15f, 0, 0.085f, 0.078f, 0.88f, Render3D.T_HORSE_DARK, 1.0f);    // dark muzzle
            for (int sd = -1; sd <= 1; sd += 2) {                                                                               // nostrils
                r.ell(muzzleF + 0.045f, muzzleY - 0.015f, sd * 0.050f, 1, 0, 0, 0.016f, 0.014f, 1.0f, Render3D.T_HOOF, 1.0f);
            }
            float blinkC = t % 4.3f;
            float blink = blinkC < 0.14f ? 0.15f : 1.0f;
            float eyeF = neckTopF + 0.14f, eyeY = neckTopY + 0.07f + (muzzleY - neckTopY) * 0.20f;
            r.ell(eyeF, eyeY, 0.098f, 1, 0, 0, 0.022f, 0.022f * blink, 1.0f, Render3D.T_LEATHER, 0.55f);
            r.ell(eyeF, eyeY, -0.098f, 1, 0, 0, 0.022f, 0.022f * blink, 1.0f, Render3D.T_LEATHER, 0.55f);
            // ears: pointed, flick when idle, pin back when galloping
            float earPhase = t % 3.7f;
            float flick = earPhase < 0.25f ? (float) Math.sin(earPhase * 25.0f) * 0.05f : 0.0f;
            float earBack = 0.09f * g + 0.04f * k;
            r.limb(neckTopF - 0.04f, neckTopY - 0.06f, 0.055f, neckTopF - 0.01f + flick - earBack, neckTopY - 0.27f + 0.03f * g, 0.05f, 0.046f, 0.010f, 0.9f, Render3D.T_HORSE, 1.0f);
            r.limb(neckTopF - 0.04f, neckTopY - 0.06f, -0.055f, neckTopF - 0.01f - flick - earBack, neckTopY - 0.27f + 0.03f * g, -0.05f, 0.046f, 0.010f, 0.9f, Render3D.T_HORSE, 0.86f);

            // mane: soft grey strands along the crest, falling to both sides, fluttering (more when galloping)
            {
                float ax = frontF - 0.04f, ay = frontY - 0.04f;
                float dF = neckTopF - ax, dY = neckTopY - ay;
                float dl = (float) Math.sqrt(dF * dF + dY * dY) + 1e-5f;
                float pF = dY / dl, pY = -dF / dl;                                     // crest side (up / back)
                final int MS = 11;
                for (int i = 0; i < MS; i++) {
                    float u = i / (float) (MS - 1);
                    float rad = mix(0.30f, 0.140f, u) * 0.96f;
                    float rf = ax + dF * u + pF * rad, ry = ay + dY * u + pY * rad;
                    float len = 0.20f + 0.05f * (float) Math.sin(i * 1.9f) - 0.04f * u;
                    float ph2 = t * 2.4f + i * 0.55f;
                    float flutter = (float) Math.sin(ph2) * (0.015f + 0.03f * mv + 0.05f * g);
                    float back = -0.05f - 0.16f * g * mv + flutter;
                    for (int sd = -1; sd <= 1; sd += 2) {
                        float mF = rf + back * 0.5f - pF * 0.04f, mY = ry + len * 0.5f - pY * 0.0f;
                        float tF = rf + back - pF * 0.02f, tY = ry + len - 0.05f * g * mv;
                        float side = sd * (0.045f + 0.012f * (float) Math.sin(ph2 * 0.8f));
                        r.limb(rf, ry, sd * 0.02f, mF, mY, sd * 0.115f + side * 0.3f, 0.050f, 0.040f, 1.0f, Render3D.T_HAIR, sd > 0 ? 1.0f : 0.85f);
                        r.limb(mF, mY, sd * 0.115f + side * 0.3f, tF, tY, sd * 0.125f + side, 0.040f, 0.016f, 1.0f, Render3D.T_HAIR, sd > 0 ? 1.0f : 0.85f);
                    }
                }
                // forelock
                r.limb(neckTopF + 0.03f, neckTopY - 0.07f, 0, neckTopF + 0.10f, neckTopY + 0.03f, 0, 0.040f, 0.014f, 1.2f, Render3D.T_HAIR, 1.0f);
            }

            // tail: long grey plume from the croup; hangs at rest, streams back at speed, swishes while idle
            tailRootF = rearF * 0.92f - 0.29f; tailRootY = rearY - 0.12f;
            {
                final int TS = 8;
                float swishC = t % 7.0f;
                float swish = swishC < 1.6f ? (float) Math.sin(swishC * 7.0f) * (float) Math.sin(Math.PI * swishC / 1.6f) * 0.55f : 0.0f;
                for (int cs = 0; cs < 3; cs++) {
                    float lat0 = (cs - 1) * 0.045f;
                    float f0 = tailRootF, y0 = tailRootY, l0 = lat0 * 0.4f;
                    float segLen = 0.145f - 0.012f * cs;
                    for (int i = 0; i < TS; i++) {
                        float uu = i / (float) (TS - 1);
                        float a = 0.28f + 0.18f * uu + (0.75f + 0.45f * uu) * g * mv + 0.12f * mv
                                + (float) Math.sin(t * 1.7f - i * 0.65f + cs) * (0.05f + 0.07f * mv) * (0.4f + uu)
                                - pitch * 0.8f;
                        float f1 = f0 - (float) Math.sin(a) * segLen;
                        float y1 = y0 + (float) Math.cos(a) * segLen;
                        float l1 = lat0 + swish * (0.04f + 0.30f * uu * uu) + (float) Math.sin(t * 1.3f - i * 0.5f + cs * 2.0f) * 0.04f * uu * (1.0f + mv);
                        float rr0 = (0.080f - 0.040f * uu) * (cs == 1 ? 1.0f : 0.82f);
                        float rr1 = (0.080f - 0.040f * (uu + 1.0f / (TS - 1))) * (cs == 1 ? 1.0f : 0.82f);
                        r.limb(f0, y0, l0, f1, y1, l1, rr0, Math.max(0.014f, rr1), 1.0f, Render3D.T_HAIR, cs == 1 ? 1.0f : 0.88f);
                        f0 = f1; y0 = y1; l0 = l1;
                    }
                }
            }

            } else {
                // ---- baked 3D walking horse (vertex-animated mesh) ----
                final HorseMesh hm = mesh;
                float rate = Math.min(2.4f, spd / STRIDE_D);                 // cycles / s, distance driven so hooves stay planted
                cyc += rate * dt;
                cyc -= (float) Math.floor(cyc);
                float idle = 1.0f - smooth01(0.02f, 0.22f, mv);
                float dipEnv2 = Math.max(0.0f, (float) Math.sin(t * 0.45f));
                float dip2 = dipEnv2 * dipEnv2 * (1.0f - mv);
                float tossC2 = t % 11.0f;
                float toss2 = tossC2 < 0.7f ? (float) Math.sin(Math.PI * tossC2 / 0.7f) : 0.0f;
                float yaw = (float) Math.sin(t * 0.5f) * 0.30f * (1.0f - mv) + (float) Math.sin(t * 0.37f + 1.0f) * 0.06f * mv;
                float nodA = dip2 * 0.38f - toss2 * 0.22f * (1.0f - mv) + (float) Math.sin(2.0f * 3.14159f * cyc * 2.0f) * 0.05f * mv + 0.12f * g;
                float tailAmp = 0.35f + 0.55f * mv + 0.7f * g;
                float pitchA = (float) Math.sin(2.0f * 3.14159f * cyc) * 0.05f * g * mv - 0.30f * k;
                float liftA = leap + 0.05f * g * mv * Math.abs((float) Math.sin(2.0f * 3.14159f * cyc * 2.0f));
                hm.eval(cyc * hm.nF, idle, yaw, nodA, tailAmp, t, pitchA, liftA, (float) Math.sin(t * 1.8f) * (1.0f - mv));
                r.mesh(hm.lx, hm.ly, hm.lz, hm.nx, hm.ny, hm.nz, hm.nV, hm.tris, hm.nT, hm.cornerSrc, hm.cornerRgb, Render3D.T_HORSE, 1.0f);
                midY = hm.topY + 0.295f;
                bodyOff = hm.topY - hm.restTopY;
                muzzleF = hm.noseF; muzzleY = hm.noseY;
                nod = nodA * 0.6f;
                neckTopF = hm.noseF - 0.28f; neckTopY = hm.noseY - 0.22f;
                tailRootF = -1.0f; tailRootY = hm.topY + 0.08f;
            }

            // saddle (dark leather: seat, raised cantle, horn, skirts, girth strap, stirrup)
            float topY = midY - 0.295f;
            for (int sd = -1; sd <= 1; sd += 2) {
                float dm = sd > 0 ? 1.0f : 0.86f;
                r.ell(-0.05f, topY + 0.115f, sd * 0.215f, 1, 0.05f, 0, 0.27f, 0.135f, 0.22f, Render3D.T_SADDLE, dm);     // skirt / flap
                r.ell(-0.02f, topY + 0.205f, sd * 0.235f, 0.2f, 1, 0, 0.060f, 0.100f, 0.30f, Render3D.T_SADDLE, dm * 0.95f); // fender (hangs lower)
            }
            r.ell(-0.07f, topY - 0.004f, 0, 1, 0, 0, 0.24f, 0.055f, 2.7f, Render3D.T_SADDLE, 1.0f);                      // seat
            r.ell(0.12f, topY - 0.050f, 0, 0, 1, 0, 0.048f, 0.042f, 1.5f, Render3D.T_SADDLE, 1.0f);                      // swell / pommel
            r.ell(0.125f, topY - 0.105f, 0, 0, 1, 0, 0.028f, 0.020f, 1.0f, Render3D.T_LEATHER, 0.85f);                   // horn tip (brown)
            r.ell(-0.27f, topY - 0.040f, 0, 0, 1, 0, 0.055f, 0.072f, 3.0f, Render3D.T_SADDLE, 1.0f);                     // cantle
            float sway = (float) Math.sin(ph) * 0.02f * mv;
            for (int sd = -1; sd <= 1; sd += 2) {
                float dm = sd > 0 ? 1.0f : 0.86f;
                // girth strap with buckle
                r.limb(0.04f, topY + 0.16f, sd * 0.255f, 0.06f, topY + 0.50f, sd * 0.268f, 0.022f, 0.020f, 0.5f, Render3D.T_SADDLE, dm * 0.9f);
                r.ell(0.048f, topY + 0.28f, sd * 0.262f, 0, 1, 0, 0.020f, 0.014f, 0.7f, Render3D.T_STEEL, dm);
            }
            if (riderless) {                                                           // empty stirrups swing gently
                for (int sd = -1; sd <= 1; sd += 2) {
                    float dm = sd > 0 ? 1.0f : 0.86f;
                    float sx = -0.03f + sway * 2.0f * sd;
                    r.limb(-0.05f, topY + 0.14f, sd * 0.275f, sx, topY + 0.50f, sd * 0.292f, 0.012f, 0.012f, 1.0f, Render3D.T_SADDLE, dm);
                    r.ell(sx, topY + 0.55f, sd * 0.292f, 0, 1, 0, 0.016f, 0.050f, 0.5f, Render3D.T_STEEL, dm * 0.9f);
                }
            }

            // ---- rider (same knight model, seated) ----
            Pose ps = pose;
            float saddleF = -0.06f;
            float saddleY = topY - 0.085f + bodyOff * 0.1f;
            float lean = 0.04f * sf + 0.26f * k;
            float spring = bob * 0.5f;
            float rPy = saddleY;
            float rWf = saddleF + lean * 0.30f, rWy = rPy - 0.17f + spring * 0.3f;
            float rCf = saddleF + lean * 0.65f, rCy = rPy - 0.36f + spring * 0.6f - 0.24f * breathe;
            float rSf = saddleF + lean, rSy = rPy - 0.50f + spring + 0.10f * k;
            float rNf = rSf + lean * 0.2f, rNy = rSy - 0.06f;
            float rHf = rNf + 0.035f + (float) Math.sin(t * 0.5f) * 0.012f * (1.0f - mv), rHy = rNy - 0.115f - spring * 0.5f + 0.02f * k;
            ps.headYaw = (float) Math.sin(t * 0.5f) * 0.35f * (1.0f - mv);
            ps.skirtSwing = 0.02f + 0.06f * sf;
            ps.breastY = -0.005f * breathe * 20.0f;
            ps.set(PELVIS, saddleF, rPy, 0);
            ps.set(WAIST, rWf, rWy, 0);
            ps.set(CHEST, rCf, rCy, 0);
            ps.set(NECK, rNf, rNy, 0);
            ps.set(HEAD, rHf, rHy, 0);
            ps.set(SHR, rSf, rSy + 0.02f, 0.19f);
            ps.set(SHL, rSf, rSy + 0.02f, -0.19f);

            // thighs wrap the barrel, boots in the stirrups
            float swing = 0.02f * (float) Math.sin(ph) * mv;
            for (int side = 0; side < 2; side++) {
                boolean rt = side == 0;
                float sd = rt ? 1.0f : -1.0f;
                float kF = saddleF + 0.26f, kY = rPy + 0.20f + swing;
                float stF = kF - 0.02f, stY = kY + 0.34f + 0.015f * (float) Math.sin(ph + 1.0f) * mv;
                ps.set(rt ? HIPR : HIPL, saddleF, rPy + 0.02f, sd * 0.10f);
                ps.set(rt ? KNR : KNL, kF, kY, sd * 0.255f);
                ps.set(rt ? ANR : ANL, stF, stY, sd * 0.275f);
                ps.set(rt ? TOER : TOEL, stF + 0.10f, stY + 0.03f, sd * 0.275f);
                // stirrup leather + iron
                if (!riderless) {
                    float[] a = {saddleF + 0.02f, topY + 0.01f, sd * 0.255f}, b = {stF + 0.03f, stY + 0.05f, sd * 0.285f};
                    r.limb(a[0], a[1], a[2], b[0], b[1], b[2], 0.012f, 0.012f, 1.0f, Render3D.T_SADDLE, 0.9f);
                    r.ell(stF + 0.045f, stY + 0.07f, sd * 0.285f, 0, 1, 0, 0.015f, 0.055f, 0.5f, Render3D.T_STEEL, 0.9f);
                }
            }

            // reins hand (left) follows the horse's head nod, sword arm (right) ready / slashing
            float lHf = rSf + 0.30f, lHy = rSy + 0.42f + nod * 0.6f;
            ik2(ik, rSf, rSy + 0.02f, lHf, lHy, 0.29f, 0.26f, -1.0f);
            ps.set(ELL, ik[0], ik[1], -0.25f);
            ps.set(WRL, lHf - 0.04f, lHy - 0.03f, -0.115f);
            ps.set(HDL, lHf, lHy, -0.105f);

            float slashProgR = (in.slashTimer > 0.0f) ? (1.0f - in.slashTimer / 0.26f) : -1.0f;
            float slashER = slashProgR >= 0.0f ? slashProgR * slashProgR * (3.0f - 2.0f * slashProgR) : 0.0f;
            float wSR = slashProgR >= 0.0f ? smooth01(0.0f, 0.12f, slashProgR) * (1.0f - smooth01(0.82f, 1.0f, slashProgR)) : 0.0f;
            float aBlade = mix(-1.05f + 0.05f * (float) Math.sin(t * 1.1f), -1.7f + 3.5f * slashER, wSR);
            float bx0 = (float) Math.cos(aBlade), by0 = (float) Math.sin(aBlade);
            float rhF = mix(rSf + 0.30f, rSf + bx0 * 0.45f, wSR);
            float rhY = mix(rSy + 0.18f + nod * 0.3f, rSy + 0.02f + by0 * 0.45f, wSR);
            ik2(ik, rSf, rSy + 0.02f, rhF, rhY, 0.29f, 0.26f, -1.0f);
            ps.set(ELR, ik[0], ik[1], 0.25f);
            ps.set(WRR, rhF - bx0 * 0.04f, rhY - by0 * 0.04f, 0.17f);
            ps.set(HDR, rhF, rhY, 0.16f);
            ps.set(TIP, rhF + bx0 * 0.62f, rhY + by0 * 0.62f, 0.16f);
            if (!riderless) drawKnight(r, ps);

            // reins: hand -> bit, with a little sag
            float[] hand = ps.j[HDL];
            float bitF = muzzleF - 0.03f, bitY = muzzleY + 0.05f;
            float midF = (hand[0] + bitF) * 0.5f, midY2 = (hand[1] + bitY) * 0.5f + 0.06f;
            if (!riderless) {
                r.limb(hand[0], hand[1], -0.10f, midF, midY2, -0.13f, 0.007f, 0.007f, 1.0f, Render3D.T_LEATHER, 1.0f);
                r.limb(midF, midY2, -0.13f, bitF, bitY, -0.075f, 0.007f, 0.007f, 1.0f, Render3D.T_LEATHER, 1.0f);
            }

            // anchors for the strand effects
            r.project(tailRootF, tailRootY, 0, pr);
            tailX = pr[0]; tailY = pr[1];
            r.project((frontF + neckTopF) * 0.5f, (frontY + neckTopY) * 0.5f - 0.05f, 0, pr);
            maneX = pr[0]; maneY = pr[1];
            r.project(rHf - 0.08f, rHy - 0.01f, 0, pr);
            headX = pr[0]; headY = pr[1];
            r.project(frontF - 0.02f, frontY - 0.12f, 0, pr);
            neckBaseX = pr[0]; neckBaseY = pr[1];
            r.project(neckTopF - 0.06f, neckTopY - 0.04f, 0, pr);
            neckTopX = pr[0]; neckTopY = pr[1];
        }
    }
}
