package com.ashveil.abyss;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * The baked 3D walking horse (vertex-animated mesh exported from the supplied Walk.abc, texture colours baked per
 * corner). 32 looping walk frames. Pure Java (no Android classes).
 *
 * Model space: X lateral, Y up, Z forward (head at +Z). {@link #eval} turns a (fractional) walk frame into the rig's
 * local frame (f = forward, y = DOWN, l = right-hand side), adds procedural layers (head yaw / nod, tail sway,
 * body pitch / lift, breathing) and rebuilds smooth normals.
 */
final class HorseMesh {
    static final float S = 0.10f;        // model unit -> rig unit
    static final float ZC = 2.6f;        // model Z that sits at rig f = 0
    static final float XC = -0.55f;      // model X centre line
    static final float GY = 1.08f;       // rig y of the ground

    final int nF, nV, nC, nT;
    private final short[] q;             // [frame][vert][3] quantised
    private final float qs, qox, qoy, qoz;
    final int[] cornerSrc;               // corner -> source vertex
    final int[] cornerRgb;               // corner -> 0xRRGGBB
    final int[] tris;                    // 3 corner ids per triangle
    private final int[] triV;            // 3 source vertex ids per triangle

    // evaluated pose (rig local frame)
    final float[] lx, ly, lz, nx, ny, nz;
    private final float[] mx, my, mz;    // model-space scratch
    private final float[] wHead, wTail;
    private int[] back;            // vertices used to find the back height under the saddle
    private float normSign = 1.0f;
    int idleFrame;
    int noseV;
    float topY, restTopY, noseF, noseY;            // back height under the saddle, nose position (rig local)

    private HorseMesh(int nF, int nV, int nC, int nT, float[] qp, short[] q, int[] cs, int[] cr, int[] tr) {
        this.nF = nF; this.nV = nV; this.nC = nC; this.nT = nT;
        this.qs = qp[0]; this.qox = qp[1]; this.qoy = qp[2]; this.qoz = qp[3];
        this.q = q; this.cornerSrc = cs; this.cornerRgb = cr; this.tris = tr;
        triV = new int[tr.length];
        for (int i = 0; i < tr.length; i++) triV[i] = cs[tr[i]];
        lx = new float[nV]; ly = new float[nV]; lz = new float[nV];
        nx = new float[nV]; ny = new float[nV]; nz = new float[nV];
        mx = new float[nV]; my = new float[nV]; mz = new float[nV];
        wHead = new float[nV]; wTail = new float[nV];
    }

    static HorseMesh load(InputStream is) throws IOException {
        DataInputStream in = new DataInputStream(new java.io.BufferedInputStream(is, 1 << 16));
        byte[] all = readAll(in);
        ByteBuffer b = ByteBuffer.wrap(all).order(ByteOrder.LITTLE_ENDIAN);
        if (b.get() != 'H' || b.get() != 'R' || b.get() != 'S' || b.get() != '1') throw new IOException("bad horse mesh");
        int nF = b.getInt(), nV = b.getInt(), nC = b.getInt(), nT = b.getInt();
        float[] qp = {b.getFloat(), b.getFloat(), b.getFloat(), b.getFloat()};
        short[] q = new short[nF * nV * 3];
        for (int i = 0; i < q.length; i++) q[i] = b.getShort();
        int[] cs = new int[nC];
        for (int i = 0; i < nC; i++) cs[i] = b.getShort() & 0xFFFF;
        int[] cr = new int[nC];
        for (int i = 0; i < nC; i++) {
            int r = b.get() & 255, g = b.get() & 255, bl = b.get() & 255;
            cr[i] = (r << 16) | (g << 8) | bl;
        }
        int[] tr = new int[nT * 3];
        for (int i = 0; i < tr.length; i++) tr[i] = b.getShort() & 0xFFFF;
        HorseMesh m = new HorseMesh(nF, nV, nC, nT, qp, q, cs, cr, tr);
        m.prepare();
        return m;
    }

    private static byte[] readAll(DataInputStream in) throws IOException {
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream(1 << 21);
        byte[] buf = new byte[1 << 16];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        return bo.toByteArray();
    }

    private float mdl(int frame, int v, int axis) {
        float o = axis == 0 ? qox : (axis == 1 ? qoy : qoz);
        return q[(frame * nV + v) * 3 + axis] * qs + o;
    }

    private static float sm(float a, float b, float x) {
        float t = Math.max(0.0f, Math.min(1.0f, (x - a) / (b - a)));
        return t * t * (3.0f - 2.0f * t);
    }

    private void prepare() {
        // region weights from the first frame
        float bestZ = -1e9f;
        for (int v = 0; v < nV; v++) {
            float X = mdl(0, v, 0), Y = mdl(0, v, 1), Z = mdl(0, v, 2);
            wHead[v] = sm(4.5f, 8.5f, Z) * sm(8.0f, 11.0f, Y);
            wTail[v] = sm(8.2f, 10.4f, -Z) * sm(2.0f, 6.0f, Y);
            if (Z > bestZ) { bestZ = Z; noseV = v; }
        }
        // idle pose: the walk frame whose left / right feet are closest together
        float best = 1e9f;
        for (int fr = 0; fr < nF; fr++) {
            float[] sum = new float[4];
            int[] cnt = new int[4];
            for (int v = 0; v < nV; v++) {
                if (mdl(0, v, 1) > 1.4f) continue;                 // hoof / fetlock vertices (frame 0 set)
                int g = (mdl(0, v, 2) > 1.0f ? 2 : 0) + (mdl(0, v, 0) > XC ? 1 : 0);
                sum[g] += mdl(fr, v, 2);
                cnt[g]++;
            }
            float cost = 0.0f;
            if (cnt[0] > 0 && cnt[1] > 0) cost += Math.abs(sum[0] / cnt[0] - sum[1] / cnt[1]);
            if (cnt[2] > 0 && cnt[3] > 0) cost += Math.abs(sum[2] / cnt[2] - sum[3] / cnt[3]);
            if (cost < best) { best = cost; idleFrame = fr; }
        }
        eval(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f);   // fix the normal sign + pick back vertices
        int cnt = 0;
        int[] tmp = new int[nV];
        for (int v = 0; v < nV; v++) {
            if (lx[v] > -0.26f && lx[v] < -0.02f && Math.abs(lz[v]) < 0.09f && ly[v] < -0.10f) tmp[cnt++] = v;
        }
        back = java.util.Arrays.copyOf(tmp, Math.max(1, cnt));
        eval(0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f);
        restTopY = topY;
    }

    /**
     * @param frame      fractional walk frame (0..nF), wraps
     * @param idleBlend  1 = standing pose, 0 = the walk frame
     * @param yaw,nod    head turn / nod (radians)
     * @param tail       tail sway amplitude (model units)
     * @param t          time (s) for the tail wave
     * @param pitch      body pitch (radians, + = nose up) about the saddle
     * @param lift       body lift (rig units, + = up)
     * @param breathe    -1..1 chest breathing
     */
    void eval(float frame, float idleBlend, float yaw, float nod, float tail, float t, float pitch, float lift, float breathe) {
        float fw = frame - (float) Math.floor(frame / nF) * nF;
        int f0 = (int) fw % nF, f1 = (f0 + 1) % nF;
        float a = fw - (float) Math.floor(fw);
        float ib = idleBlend;
        final float cy = (float) Math.cos(yaw), sy = (float) Math.sin(yaw);
        final float cn = (float) Math.cos(nod), sn = (float) Math.sin(nod);
        final float cp = (float) Math.cos(pitch), sp = (float) Math.sin(pitch);
        final float pf = -0.06f, py = -0.25f;
        for (int v = 0; v < nV; v++) {
            float X = mdl(f0, v, 0) * (1 - a) + mdl(f1, v, 0) * a;
            float Y = mdl(f0, v, 1) * (1 - a) + mdl(f1, v, 1) * a;
            float Z = mdl(f0, v, 2) * (1 - a) + mdl(f1, v, 2) * a;
            if (ib > 0.0f) {
                X += (mdl(idleFrame, v, 0) - X) * ib;
                Y += (mdl(idleFrame, v, 1) - Y) * ib;
                Z += (mdl(idleFrame, v, 2) - Z) * ib;
            }
            float wh = wHead[v];
            if (wh > 0.0f) {                                        // head yaw about the vertical axis, nod about the neck base
                float dx = X, dz = Z - 6.5f;
                float ang = yaw * wh;
                float c = (float) Math.cos(ang), s = (float) Math.sin(ang);
                X = dx * c - dz * s;
                Z = 6.5f + dx * s + dz * c;
                float dy = Y - 11.0f, dz2 = Z - 6.5f;
                float an = nod * wh;
                float c2 = (float) Math.cos(an), s2 = (float) Math.sin(an);
                Y = 11.0f + dy * c2 + dz2 * s2;
                Z = 6.5f - dy * s2 + dz2 * c2;
            }
            float wt = wTail[v];
            if (wt > 0.0f) X += (float) Math.sin(t * 2.1f - (14.0f - Y) * 0.32f) * tail * wt * (1.0f + (14.0f - Y) * 0.10f);
            float f = (Z - ZC) * S, y = GY - Y * S, l = -(X - XC) * S;
            if (breathe != 0.0f) y -= breathe * 0.006f * Math.max(0.0f, (GY - y)) * Math.max(0.0f, 1.0f - Math.abs(f) * 0.9f);
            if (pitch != 0.0f) {
                float df = f - pf, dy = y - py;
                float nf = pf + df * cp + dy * sp, ny2 = py - df * sp + dy * cp;
                f = nf; y = ny2;
            }
            lx[v] = f; ly[v] = y - lift; lz[v] = l;
        }
        // smooth normals
        java.util.Arrays.fill(nx, 0.0f); java.util.Arrays.fill(ny, 0.0f); java.util.Arrays.fill(nz, 0.0f);
        for (int i = 0; i < nT; i++) {
            int a0 = triV[3 * i], b0 = triV[3 * i + 1], c0 = triV[3 * i + 2];
            float ux = lx[b0] - lx[a0], uy = ly[b0] - ly[a0], uz = lz[b0] - lz[a0];
            float vx = lx[c0] - lx[a0], vy = ly[c0] - ly[a0], vz = lz[c0] - lz[a0];
            float cx = uy * vz - uz * vy, cyy = uz * vx - ux * vz, cz = ux * vy - uy * vx;
            nx[a0] += cx; ny[a0] += cyy; nz[a0] += cz;
            nx[b0] += cx; ny[b0] += cyy; nz[b0] += cz;
            nx[c0] += cx; ny[c0] += cyy; nz[c0] += cz;
        }
        if (normSign == 0.0f) normSign = 1.0f;
        float up = 0.0f;
        for (int v = 0; v < nV; v++) {
            float l = (float) Math.sqrt(nx[v] * nx[v] + ny[v] * ny[v] + nz[v] * nz[v]) + 1e-12f;
            nx[v] /= l; ny[v] /= l; nz[v] /= l;
        }
        if (back == null) {                                        // first call: decide the winding sign from the topmost vertex
            int top = 0;
            for (int v = 1; v < nV; v++) if (ly[v] < ly[top]) top = v;
            normSign = ny[top] < 0.0f ? 1.0f : -1.0f;
        }
        if (normSign < 0.0f) for (int v = 0; v < nV; v++) { nx[v] = -nx[v]; ny[v] = -ny[v]; nz[v] = -nz[v]; }
        if (back != null) {
            float m = 1e9f;
            for (int i = 0; i < back.length; i++) m = Math.min(m, ly[back[i]]);
            topY = m + 0.025f;
        }
        noseF = lx[noseV];
        noseY = ly[noseV];
    }
}
