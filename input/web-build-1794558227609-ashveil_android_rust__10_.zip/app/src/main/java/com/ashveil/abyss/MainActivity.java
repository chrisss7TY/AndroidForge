package com.ashveil.abyss;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.opengl.GLES30;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.opengl.Matrix;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MainActivity extends Activity {
    private static boolean sRustLoaded = false;
    static {
        try {
            System.loadLibrary("ashveil_ascii_3d");
            sRustLoaded = true;
        } catch (Throwable ignored) {
            sRustLoaded = false;
        }
    }

    public static native long nativeInit(long seed);
    public static native int nativeStep(long handle, float dt);
    public static native void nativeTouch(long handle, int action, long pointerId, float normX, float normY);
    public static native void nativeDestroy(long handle);

    private GLSurfaceView mGlView;
    private HudOverlayView mHudView;
    private GameState mState;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );

        mState = new GameState();
        FrameLayout root = new FrameLayout(this);

        mGlView = new GLSurfaceView(this);
        mGlView.setEGLContextClientVersion(3);
        mGlView.setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        AsciiGlRenderer renderer = new AsciiGlRenderer(mState);
        mGlView.setRenderer(renderer);
        mGlView.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);

        mHudView = new HudOverlayView(this, mState);

        root.addView(mGlView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));
        root.addView(mHudView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mGlView != null) mGlView.onResume();
    }

    @Override
    protected void onPause() {
        if (mGlView != null) mGlView.onPause();
        super.onPause();
    }

    // =========================================================================
    // SHARED REAL-TIME 3D RPG & MULTIPLAYER-READY WORLD STATE
    // =========================================================================
    private static final class GameState {
        // Starts directly in the playable 3D ASCII world (Stage 1 requirement!)
        volatile int screenMode = 1; // 1 = 3D World, 2 = 3D Chainmail & Rune Equipment Menu
        volatile boolean mounted = false;
        volatile boolean cursorViewMode = true;
        volatile boolean debugSolidMode = false; // Stage 7 Visual Debugging Mode: false=ASCII, true=Solid 3D Normals
        volatile int qualityPreset = 2; // 0=Low (8k grass), 1=Med (16k), 2=Ultra (24k instanced grass)
        volatile int zoomPreset = 1;
        volatile float cameraZoom = 1.0f;
        volatile float camYaw = 0.0f;

        // Player 3D Transform & Physics
        volatile float playerX = 0.0f;
        volatile float playerY = 0.0f;
        volatile float playerZ = 4.0f;
        volatile float velX = 0.0f;
        volatile float velY = 0.0f;
        volatile float velZ = 0.0f;
        volatile float facingX = 0.0f;
        volatile float facingZ = -1.0f;
        volatile float bodyYaw = (float) Math.PI;
        volatile float turnVel = 0.0f;
        volatile float gaitPhase = 0.0f;
        volatile float timeSec = 0.0f;
        volatile float slashTimer = 0.0f;
        volatile float slashCooldown = 0.0f;
        volatile float dodgeTimer = 0.0f;
        volatile float dodgeCooldown = 0.0f;
        volatile float dodgeDirX = 0.0f;
        volatile float dodgeDirZ = -1.0f;
        volatile float hurtFlash = 0.0f;

        // Cursor View offset (normalized screen coords)
        volatile float cursorX = 0.56f;
        volatile float cursorY = 0.46f;
        volatile float inputX = 0.0f;
        volatile float inputZ = 0.0f;

        // RPG Progression & Stats (Matching `Senje` screenshot: HP 1612/1612, MP 134/134, LV 13, 5194g)
        volatile String playerName = "Senje";
        volatile int level = 13;
        volatile int xp = 1943;
        volatile int xpNext = 6995;
        volatile int hp = 1612;
        volatile int maxHp = 1612;
        volatile int mp = 134;
        volatile int maxMp = 134;
        volatile int gold = 5194;
        volatile int statPoints = 3;
        volatile int vit = 18;
        volatile int str = 22;
        volatile int dex = 16;
        volatile int potions = 3;
        volatile int herbMoon = 3;
        volatile int herbMoss = 2;
        volatile int cinderShards = 2;

        // Quest System
        volatile int questKills = 0;
        volatile int questTarget = 5;
        volatile boolean questCompleted = false;

        // Equipment & Material System (Helm, Shoulders, Chest, Gloves, Legs, Boots + 10 Metals + Runes)
        volatile int selectedSlot = 0; // 0=Helm, 1=Shoulders, 2=Chest, 3=Gloves, 4=Legs, 5=Boots
        final int[] slotMetal = new int[]{0, 1, 1, 0, 1, 0}; // Iron/Steel default per slot
        volatile int activeMetal = 0; // 0=Iron..9=Emberstone
        volatile int runeSlot1 = -1;
        volatile int runeSlot2 = -1;
        volatile float previewYaw = 0.4f;
        volatile float previewZoom = 1.0f;

        static final String[] SLOT_NAMES = {"Helm", "Shoulders", "Chest", "Gloves", "Legs", "Boots"};
        static final String[] RUNE_GLYPHS = {"^", "*", "z", "~", ">", "/", "x", "v", "o", "\u00a7", "+"};
        static final String[] METAL_NAMES = {
                "#%: Iron", "@%. Steel", "&o, Bronze", "$s. Silver", "0o. Gold",
                "O*. Moonsteel", "Nightglass", "88: Bloodiron", "=-. Ossite", "*+. Emberstone"
        };
        static final String[] METAL_SHORT = {
                "Iron", "Steel", "Bronze", "Silver", "Gold",
                "Moonsteel", "Nightglass", "Bloodiron", "Ossite", "Emberstone"
        };
        static final float[][] METAL_RGB = {
                {0.76f, 0.79f, 0.82f}, // Iron
                {0.88f, 0.91f, 0.95f}, // Steel
                {0.84f, 0.60f, 0.38f}, // Bronze
                {0.95f, 0.97f, 1.00f}, // Silver
                {0.98f, 0.84f, 0.36f}, // Gold
                {0.62f, 0.84f, 1.00f}, // Moonsteel
                {0.58f, 0.50f, 0.82f}, // Nightglass
                {0.90f, 0.30f, 0.34f}, // Bloodiron
                {0.90f, 0.87f, 0.78f}, // Ossite
                {1.00f, 0.56f, 0.28f}  // Emberstone
        };

        // 3D Enemies (Idle at post until player within 7.5 units)
        static final int NUM_ENEMIES = 10;
        final float[] enemyX = new float[NUM_ENEMIES];
        final float[] enemyZ = new float[NUM_ENEMIES];
        final float[] enemyHomeX = new float[NUM_ENEMIES];
        final float[] enemyHomeZ = new float[NUM_ENEMIES];
        final float[] enemyYaw = new float[NUM_ENEMIES];
        final float[] enemyGait = new float[NUM_ENEMIES];
        final float[] enemyWindup = new float[NUM_ENEMIES];
        final float[] enemyCooldown = new float[NUM_ENEMIES];
        final float[] enemyHurt = new float[NUM_ENEMIES];
        final int[] enemyHp = new int[NUM_ENEMIES];
        final int[] enemyMaxHp = new int[NUM_ENEMIES];
        final int[] enemyMetal = new int[NUM_ENEMIES];
        final boolean[] enemyAggro = new boolean[NUM_ENEMIES];

        // 3D Loot Drops
        static final int MAX_LOOT = 12;
        final float[] lootX = new float[MAX_LOOT];
        final float[] lootZ = new float[MAX_LOOT];
        final int[] lootMetal = new int[MAX_LOOT];
        final boolean[] lootActive = new boolean[MAX_LOOT];

        // Status & Floating Popups
        volatile String statusBanner = "Explore the 3D ASCII World • Moonlit Cave North • River South";
        volatile float bannerTimer = 4.5f;

        // Server-Authoritative Multiplayer Sync Queue (Ready for WebSocket/UDP Packet Relay)
        static final class NetEntityPacket {
            long entityId;
            float x, y, z, yaw;
            int animState, hp, maxHp;
        }
        final NetEntityPacket[] netPeers = new NetEntityPacket[8];
        volatile int connectedPeers = 0;

        GameState() {
            for (int i = 0; i < 8; i++) netPeers[i] = new NetEntityPacket();
            for (int i = 0; i < NUM_ENEMIES; i++) {
                spawnEnemy(i, i < 3);
            }
        }

        float riverCenterZ(float wx) {
            return -6.5f + (float) Math.sin(wx * 0.14f) * 2.2f;
        }

        boolean isInsideCave(float wx, float wz) {
            float dx = wx - 0.0f;
            float dz = wz - (-18.0f);
            return (dx * dx + dz * dz) < 11.0f * 11.0f;
        }

        boolean isBlocked(float wx, float wz) {
            for (int i = 0; i < AsciiGlRenderer.ROCK_FORMATIONS.length; i++) {
                float[] rf = AsciiGlRenderer.ROCK_FORMATIONS[i];
                float dx = (wx - rf[0]) / (rf[2] * 0.55f);
                float dz = (wz - rf[1]) / (rf[4] * 0.55f);
                if (dx * dx + dz * dz < 1.0f) return true;
            }
            for (int t = 0; t < AsciiGlRenderer.FOREST_TREES.length; t++) {
                float[] tr = AsciiGlRenderer.FOREST_TREES[t];
                float dx = wx - tr[0];
                float dz = wz - tr[1];
                if (dx * dx + dz * dz < 0.65f * 0.65f) return true;
            }
            return false;
        }

        void spawnEnemy(int i, boolean near) {
            float ang = i * 0.95f + 0.6f;
            float dist = near ? (6.5f + i * 2.2f) : (10.5f + (i % 5) * 3.5f);
            float ex = (float) Math.cos(ang) * dist;
            float ez = 4.0f + (float) Math.sin(ang) * dist;
            if (isBlocked(ex, ez)) {
                ex = 5.5f + (i % 3) * 2.0f;
                ez = 6.5f + (i / 3) * 2.0f;
            }
            enemyX[i] = enemyHomeX[i] = ex;
            enemyZ[i] = enemyHomeZ[i] = ez;
            enemyYaw[i] = (float) Math.PI;
            enemyGait[i] = i * 0.8f;
            enemyWindup[i] = 0.0f;
            enemyCooldown[i] = 0.5f;
            enemyHurt[i] = 0.0f;
            enemyMaxHp[i] = 120 + level * 16 + (i % 3) * 40;
            enemyHp[i] = enemyMaxHp[i];
            enemyMetal[i] = (i + 1) % METAL_RGB.length;
            enemyAggro[i] = false;
        }

        void triggerSlash() {
            if (slashCooldown > 0.0f) return;
            slashTimer = 0.28f;
            slashCooldown = 0.34f;

            int weaponBonus = (slotMetal[0] + slotMetal[1] + slotMetal[2]) * 6;
            int runeBonus = (runeSlot1 >= 0 ? 18 : 0) + (runeSlot2 >= 0 ? 18 : 0);
            int dmg = 42 + str * 3 + weaponBonus + runeBonus;

            for (int i = 0; i < NUM_ENEMIES; i++) {
                float dx = enemyX[i] - playerX;
                float dz = enemyZ[i] - playerZ;
                float d2 = dx * dx + dz * dz;
                if (d2 < 3.6f * 3.6f) {
                    enemyHp[i] -= dmg;
                    enemyHurt[i] = 0.25f;
                    enemyAggro[i] = true;
                    float d = (float) Math.sqrt(d2 + 0.001f);
                    enemyX[i] += (dx / d) * 0.65f;
                    enemyZ[i] += (dz / d) * 0.65f;
                    if (enemyHp[i] <= 0) {
                        int xpGain = 185 + level * 35;
                        int goldGain = 65 + (i * 23) % 80;
                        xp += xpGain;
                        gold += goldGain;
                        cinderShards++;
                        if (!questCompleted) {
                            questKills++;
                            if (questKills >= questTarget) {
                                questCompleted = true;
                                gold += 500;
                                xp += 1000;
                                statusBanner = "QUEST COMPLETE: Moonlit Wardens (+500g, +1000 XP)";
                                bannerTimer = 4.0f;
                            }
                        }
                        if (xp >= xpNext) {
                            xp -= xpNext;
                            level++;
                            xpNext = (int) (xpNext * 1.25f);
                            statPoints += 3;
                            maxHp += 110;
                            hp = maxHp;
                            maxMp += 18;
                            mp = maxMp;
                            statusBanner = "LEVEL UP! LV " + level + " (+3 Stat Pts)";
                            bannerTimer = 3.5f;
                        } else if (!questCompleted) {
                            statusBanner = "Slain Ash-Stalker (+" + xpGain + " XP, +" + goldGain + "g)";
                            bannerTimer = 2.6f;
                        }
                        for (int l = 0; l < MAX_LOOT; l++) {
                            if (!lootActive[l]) {
                                lootActive[l] = true;
                                lootX[l] = enemyX[i];
                                lootZ[l] = enemyZ[i];
                                lootMetal[l] = (enemyMetal[i] + 1) % METAL_RGB.length;
                                break;
                            }
                        }
                        spawnEnemy(i, false);
                    }
                }
            }
        }

        void triggerJump() {
            if (playerY <= 0.01f) {
                velY = 6.2f;
            }
        }

        void triggerDodge() {
            if (dodgeCooldown > 0.0f) return;
            dodgeTimer = 0.28f;
            dodgeCooldown = 0.85f;
            float len = (float) Math.sqrt(inputX * inputX + inputZ * inputZ);
            if (len > 0.15f) {
                dodgeDirX = inputX / len;
                dodgeDirZ = inputZ / len;
            } else {
                dodgeDirX = facingX;
                dodgeDirZ = facingZ;
            }
            facingX = dodgeDirX;
            facingZ = dodgeDirZ;
        }

        void stepSimulation(float dt) {
            timeSec += dt;
            if (bannerTimer > 0.0f) bannerTimer -= dt;
            if (slashTimer > 0.0f) slashTimer -= dt;
            if (slashCooldown > 0.0f) slashCooldown -= dt;
            if (dodgeTimer > 0.0f) dodgeTimer -= dt;
            if (dodgeCooldown > 0.0f) dodgeCooldown -= dt;
            if (hurtFlash > 0.0f) hurtFlash -= dt;

            if (screenMode == 2) {
                previewYaw += dt * 0.65f;
                return;
            }

            // Camera-relative movement vector
            float cosY = (float) Math.cos(camYaw);
            float sinY = (float) Math.sin(camYaw);
            float worldInX = inputX * cosY - inputZ * sinY;
            float worldInZ = inputX * sinY + inputZ * cosY;

            if (dodgeTimer > 0.0f) {
                float dashSpd = mounted ? 14.5f : 11.8f;
                velX = dodgeDirX * dashSpd;
                velZ = dodgeDirZ * dashSpd;
            } else {
                float topSpd = mounted ? 7.2f : 4.8f;
                float accel = Math.min(1.0f, dt * 11.0f);
                velX += (worldInX * topSpd - velX) * accel;
                velZ += (worldInZ * topSpd - velZ) * accel;
            }

            float nx = playerX + velX * dt;
            float nz = playerZ + velZ * dt;
            if (!isBlocked(nx, playerZ)) playerX = nx;
            if (!isBlocked(playerX, nz)) playerZ = nz;

            // Vertical Jump & Gravity Physics
            if (playerY > 0.0f || velY > 0.0f) {
                playerY += velY * dt;
                velY -= 16.5f * dt;
                if (playerY < 0.0f) {
                    playerY = 0.0f;
                    velY = 0.0f;
                }
            }

            float spd = (float) Math.sqrt(velX * velX + velZ * velZ);
            if (spd > 0.20f) {
                facingX = velX / spd;
                facingZ = velZ / spd;
                float targetYaw = (float) Math.atan2(facingX, facingZ);
                float diff = targetYaw - bodyYaw;
                while (diff > Math.PI) diff -= (float) (Math.PI * 2.0);
                while (diff < -Math.PI) diff += (float) (Math.PI * 2.0);
                turnVel = diff;
                bodyYaw += diff * Math.min(1.0f, dt * 12.0f);
                gaitPhase += dt * (mounted ? 5.8f + spd * 1.9f : 5.2f + spd * 2.5f);
            } else {
                turnVel *= 0.85f;
                gaitPhase += dt * 1.8f;
            }

            // Loot pickup
            for (int l = 0; l < MAX_LOOT; l++) {
                if (lootActive[l]) {
                    float dx = lootX[l] - playerX;
                    float dz = lootZ[l] - playerZ;
                    if (dx * dx + dz * dz < 1.35f * 1.35f) {
                        lootActive[l] = false;
                        int m = lootMetal[l];
                        slotMetal[m % 6] = m;
                        activeMetal = m;
                        statusBanner = "Equipped " + METAL_SHORT[m] + " " + SLOT_NAMES[m % 6] + "!";
                        bannerTimer = 3.0f;
                    }
                }
            }

            // Enemy AI (Guard post until player within 7.5 units)
            for (int i = 0; i < NUM_ENEMIES; i++) {
                if (enemyHurt[i] > 0.0f) enemyHurt[i] -= dt;
                if (enemyCooldown[i] > 0.0f) enemyCooldown[i] -= dt;

                float dx = playerX - enemyX[i];
                float dz = playerZ - enemyZ[i];
                float dist = (float) Math.sqrt(dx * dx + dz * dz + 0.001f);

                if (!enemyAggro[i] && dist < 7.2f) {
                    enemyAggro[i] = true;
                } else if (enemyAggro[i] && dist > 13.5f) {
                    enemyAggro[i] = false;
                }

                if (!enemyAggro[i]) {
                    float hx = enemyHomeX[i] - enemyX[i];
                    float hz = enemyHomeZ[i] - enemyZ[i];
                    float hd = (float) Math.sqrt(hx * hx + hz * hz);
                    if (hd > 0.35f) {
                        enemyYaw[i] = (float) Math.atan2(hx, hz);
                        enemyGait[i] += dt * 5.0f;
                        enemyX[i] += (hx / hd) * 1.4f * dt;
                        enemyZ[i] += (hz / hd) * 1.4f * dt;
                    } else {
                        enemyGait[i] += dt * 1.4f;
                    }
                    continue;
                }

                enemyYaw[i] = (float) Math.atan2(dx, dz);
                if (enemyWindup[i] > 0.0f) {
                    enemyWindup[i] -= dt;
                    if (enemyWindup[i] <= 0.0f) {
                        if (dist < 2.3f && dodgeTimer <= 0.0f) {
                            int eDmg = 22 + level * 2 + (i % 3) * 6;
                            hp = Math.max(0, hp - eDmg);
                            hurtFlash = 0.25f;
                            if (hp <= 0) {
                                hp = maxHp;
                                playerX = 0.0f;
                                playerZ = 4.0f;
                                statusBanner = "Revived at Meadow Sanctuary";
                                bannerTimer = 3.0f;
                            }
                        }
                        enemyCooldown[i] = 1.25f;
                    }
                } else if (dist > 1.55f) {
                    enemyGait[i] += dt * 8.2f;
                    float ex = enemyX[i] + (dx / dist) * 2.2f * dt;
                    float ez = enemyZ[i] + (dz / dist) * 2.2f * dt;
                    if (!isBlocked(ex, ez)) {
                        enemyX[i] = ex;
                        enemyZ[i] = ez;
                    }
                } else if (enemyCooldown[i] <= 0.0f) {
                    enemyWindup[i] = 0.42f;
                }
            }
        }
    }

    // =========================================================================
    // OPENGL ES 3.0 REAL-TIME 3D ASCII ENGINE (GPU VBO/IBO + DELIBERATE LANDSCAPE)
    // =========================================================================
    private static final class AsciiGlRenderer implements GLSurfaceView.Renderer {
        private final GameState mState;
        private long mLastNs = System.nanoTime();
        private int mWidth = 1280;
        private int mHeight = 720;

        // OpenGL Shader Programs
        private int mProgMeshAscii = 0;
        private int mProgGrassInstanced = 0;
        private int mProgWaterAscii = 0;

        // 16x6 Character Glyph Atlas Texture
        private int mGlyphAtlasTex = 0;

        // Planar Water Reflection Framebuffer Object (FBO)
        private int mReflectFbo = 0;
        private int mReflectTex = 0;
        private int mReflectDepthRb = 0;
        private static final int REFLECT_W = 512;
        private static final int REFLECT_H = 512;

        // ALL Meshes stored in GPU VBOs/IBOs (Fixes client-side FloatBuffer position corruption!)
        private int mSphereVbo = 0;
        private int mSphereIbo = 0;
        private int mSphereIndexCount = 0;
        private int mQuadVbo = 0;

        // GPU Instanced 3D Grass & Wildflower Buffer
        private static final int MAX_GRASS_INSTANCES = 24000;
        private int mGrassRibbonVbo = 0;
        private int mGrassInstanceVbo = 0;

        // Matrices
        private final float[] mProjMatrix = new float[16];
        private final float[] mViewMatrix = new float[16];
        private final float[] mVpMatrix = new float[16];
        private final float[] mReflectViewMatrix = new float[16];
        private final float[] mReflectVpMatrix = new float[16];
        private final float[] mModelMatrix = new float[16];
        private final float[] mMvpMatrix = new float[16];

        // Deliberate, Ground-Anchored 3D Rock Formations & Trees (Matching `1000461482.jpg`!)
        // Each formation is a cohesive, grounded cluster (x, z, radiusX, heightY, radiusZ)
        private static final float[][] ROCK_FORMATIONS = new float[][]{
                // Left canyon cliff wall (seen on left of `1000461482.jpg`)
                {-5.2f,  1.5f, 2.2f, 5.8f, 2.4f},
                {-5.6f,  4.2f, 2.5f, 6.4f, 2.6f},
                {-5.0f,  6.8f, 2.1f, 5.2f, 2.2f},
                // Top-left recessed cliff outcrop
                {-3.2f, -2.5f, 2.8f, 5.5f, 2.4f},
                {-1.4f, -3.2f, 2.2f, 4.6f, 2.0f},
                // Right canyon cliff pillar & wall (seen on right of `1000461482.jpg`)
                { 4.6f,  0.8f, 2.3f, 6.2f, 2.3f},
                { 5.2f,  3.4f, 2.6f, 5.8f, 2.5f},
                { 7.2f,  4.8f, 2.8f, 5.4f, 2.6f},
                // Foreground twin boulders (seen at bottom of `1000461482.jpg`)
                {-1.8f,  8.2f, 1.85f, 2.2f, 1.45f},
                { 3.0f,  7.8f, 1.65f, 2.0f, 1.35f},
                // Northern Moonlit Cave Archway Pillars (around z = -12..-18)
                {-3.8f, -11.5f, 2.6f, 7.2f, 2.6f},
                { 3.8f, -11.5f, 2.6f, 7.2f, 2.6f},
                {-5.5f, -15.5f, 3.2f, 8.0f, 3.2f},
                { 5.5f, -15.5f, 3.2f, 8.0f, 3.2f},
                { 0.0f, -20.5f, 6.5f, 8.5f, 3.0f},
                // Outer perimeter ridge
                {-11.5f,  2.0f, 3.4f, 7.0f, 3.4f},
                { 11.5f,  1.5f, 3.4f, 7.0f, 3.4f},
                {-10.0f, 11.0f, 3.0f, 6.0f, 3.0f},
                { 10.5f, 11.5f, 3.0f, 6.0f, 3.0f}
        };

        // Deliberate Grounded Trees (x, z, trunkHeight, canopyRadius)
        private static final float[][] FOREST_TREES = new float[][]{
                {-8.2f,  5.5f, 3.6f, 2.2f},
                {-8.8f, -1.5f, 4.0f, 2.5f},
                { 8.6f, -1.2f, 3.8f, 2.4f},
                { 9.2f,  7.5f, 3.5f, 2.1f},
                {-6.8f, 10.5f, 3.8f, 2.3f},
                { 6.4f, 10.8f, 3.6f, 2.2f},
                {-7.5f, -9.2f, 4.2f, 2.6f},
                { 7.8f, -9.0f, 4.0f, 2.5f}
        };

        AsciiGlRenderer(GameState state) {
            mState = state;
        }

        @Override
        public void onSurfaceCreated(GL10 gl, EGLConfig config) {
            GLES30.glClearColor(0.024f, 0.038f, 0.034f, 1.0f);
            GLES30.glEnable(GLES30.GL_DEPTH_TEST);
            GLES30.glDepthFunc(GLES30.GL_LEQUAL);
            GLES30.glDisable(GLES30.GL_CULL_FACE);

            mGlyphAtlasTex = createAsciiGlyphAtlasTexture();
            buildUnitSphereVbo(14, 18);
            buildQuadVbo();
            buildInstancedGrassBuffers();
            initReflectionFbo();
            compileAllShaders();
        }

        @Override
        public void onSurfaceChanged(GL10 gl, int width, int height) {
            mWidth = Math.max(1, width);
            mHeight = Math.max(1, height);
            GLES30.glViewport(0, 0, mWidth, mHeight);
        }

        @Override
        public void onDrawFrame(GL10 gl) {
            long nowNs = System.nanoTime();
            float dt = (nowNs - mLastNs) / 1_000_000_000.0f;
            mLastNs = nowNs;
            if (dt > 0.05f) dt = 0.05f;
            if (dt < 0.001f) dt = 0.001f;

            mState.stepSimulation(dt);

            if (mState.screenMode == 2) {
                render3DChainmailEquipmentScene();
            } else {
                render3DOpenWorldScene();
            }
        }

        private int createAsciiGlyphAtlasTexture() {
            int cols = 16;
            int rows = 6;
            int cellW = 32;
            int cellH = 32;
            Bitmap bmp = Bitmap.createBitmap(cols * cellW, rows * cellH, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bmp);
            c.drawColor(Color.TRANSPARENT);

            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
            p.setTextSize(25.0f);
            p.setColor(Color.WHITE);
            p.setTextAlign(Paint.Align.CENTER);

            String atlasChars =
                    " .,:;-=+*oahkbdp" +
                    "qwmZOQ0N$%&8B#MW" +
                    "@S8$#c()350Qo*+=" +
                    "|/\\*o+.,:;~^v<>#" +
                    "0Q8B@WM#%&80aaqQ" +
                    "()[]{}$#@*+=-~:;.";

            Paint.FontMetrics fm = p.getFontMetrics();
            float baselineOff = -(fm.ascent + fm.descent) * 0.5f;

            for (int r = 0; r < rows; r++) {
                for (int col = 0; col < cols; col++) {
                    int idx = r * cols + col;
                    char ch = (idx < atlasChars.length()) ? atlasChars.charAt(idx) : '@';
                    float cx = col * cellW + cellW * 0.5f;
                    float cy = r * cellH + cellH * 0.5f + baselineOff;
                    c.drawText(String.valueOf(ch), cx, cy, p);
                }
            }

            int[] tex = new int[1];
            GLES30.glGenTextures(1, tex, 0);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex[0]);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);
            GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0);
            bmp.recycle();
            return tex[0];
        }

        private void buildUnitSphereVbo(int latBands, int lonBands) {
            int vertCount = (latBands + 1) * (lonBands + 1);
            float[] verts = new float[vertCount * 8];
            int vPtr = 0;
            for (int lat = 0; lat <= latBands; lat++) {
                float theta = (float) (lat * Math.PI / latBands);
                float sinT = (float) Math.sin(theta);
                float cosT = (float) Math.cos(theta);
                for (int lon = 0; lon <= lonBands; lon++) {
                    float phi = (float) (lon * 2.0 * Math.PI / lonBands);
                    float nx = (float) Math.cos(phi) * sinT;
                    float ny = cosT;
                    float nz = (float) Math.sin(phi) * sinT;
                    verts[vPtr++] = nx * 0.5f;
                    verts[vPtr++] = ny * 0.5f;
                    verts[vPtr++] = nz * 0.5f;
                    verts[vPtr++] = nx;
                    verts[vPtr++] = ny;
                    verts[vPtr++] = nz;
                    verts[vPtr++] = lon / (float) lonBands;
                    verts[vPtr++] = lat / (float) latBands;
                }
            }

            short[] indices = new short[latBands * lonBands * 6];
            int iPtr = 0;
            for (int lat = 0; lat < latBands; lat++) {
                for (int lon = 0; lon < lonBands; lon++) {
                    int first = (lat * (lonBands + 1)) + lon;
                    int second = first + lonBands + 1;
                    indices[iPtr++] = (short) first;
                    indices[iPtr++] = (short) second;
                    indices[iPtr++] = (short) (first + 1);
                    indices[iPtr++] = (short) second;
                    indices[iPtr++] = (short) (second + 1);
                    indices[iPtr++] = (short) (first + 1);
                }
            }
            mSphereIndexCount = indices.length;

            FloatBuffer vb = ByteBuffer.allocateDirect(verts.length * 4)
                    .order(ByteOrder.nativeOrder()).asFloatBuffer();
            vb.put(verts).position(0);

            ShortBuffer ib = ByteBuffer.allocateDirect(indices.length * 2)
                    .order(ByteOrder.nativeOrder()).asShortBuffer();
            ib.put(indices).position(0);

            int[] bufs = new int[2];
            GLES30.glGenBuffers(2, bufs, 0);
            mSphereVbo = bufs[0];
            mSphereIbo = bufs[1];

            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, mSphereVbo);
            GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, verts.length * 4, vb, GLES30.GL_STATIC_DRAW);
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0);

            GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, mSphereIbo);
            GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, indices.length * 2, ib, GLES30.GL_STATIC_DRAW);
            GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, 0);
        }

        private void buildQuadVbo() {
            float[] q = new float[]{
                    -1f, 0f, -1f, 0f, 1f, 0f, 0f, 0f,
                     1f, 0f, -1f, 0f, 1f, 0f, 1f, 0f,
                    -1f, 0f,  1f, 0f, 1f, 0f, 0f, 1f,
                     1f, 0f, -1f, 0f, 1f, 0f, 1f, 0f,
                     1f, 0f,  1f, 0f, 1f, 0f, 1f, 1f,
                    -1f, 0f,  1f, 0f, 1f, 0f, 0f, 1f
            };
            FloatBuffer qb = ByteBuffer.allocateDirect(q.length * 4)
                    .order(ByteOrder.nativeOrder()).asFloatBuffer();
            qb.put(q).position(0);

            int[] bufs = new int[1];
            GLES30.glGenBuffers(1, bufs, 0);
            mQuadVbo = bufs[0];
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, mQuadVbo);
            GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, q.length * 4, qb, GLES30.GL_STATIC_DRAW);
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0);
        }

        private void buildInstancedGrassBuffers() {
            // Crisp 3D grass blade quad anchored strictly at y=0 on terrain
            float[] ribbon = new float[]{
                    -0.5f, 0.0f, 0.0f, 1.0f,
                     0.5f, 0.0f, 1.0f, 1.0f,
                    -0.5f, 1.0f, 0.0f, 0.0f,
                     0.5f, 0.0f, 1.0f, 1.0f,
                     0.5f, 1.0f, 1.0f, 0.0f,
                    -0.5f, 1.0f, 0.0f, 0.0f
            };
            FloatBuffer rb = ByteBuffer.allocateDirect(ribbon.length * 4)
                    .order(ByteOrder.nativeOrder()).asFloatBuffer();
            rb.put(ribbon).position(0);

            float[] inst = new float[MAX_GRASS_INSTANCES * 4];
            int seed = 918273645;
            for (int i = 0; i < MAX_GRASS_INSTANCES; i++) {
                seed = seed * 1664525 + 1013904223;
                float rx = (((seed >>> 16) & 0xFFFF) / 65535.0f - 0.5f) * 28.0f;
                seed = seed * 1664525 + 1013904223;
                float rz = (((seed >>> 16) & 0xFFFF) / 65535.0f - 0.5f) * 28.0f;
                seed = seed * 1664525 + 1013904223;
                boolean isFlower = ((i % 28) == 0);
                float hScale = isFlower ? 0.24f : (0.32f + ((seed >>> 12) & 15) * 0.018f);
                float typeSeed = isFlower ? (100.0f + (i % 5)) : (i % 16);

                int o = i * 4;
                inst[o] = rx;
                inst[o + 1] = rz;
                inst[o + 2] = hScale;
                inst[o + 3] = typeSeed;
            }
            FloatBuffer ib = ByteBuffer.allocateDirect(inst.length * 4)
                    .order(ByteOrder.nativeOrder()).asFloatBuffer();
            ib.put(inst).position(0);

            int[] vbos = new int[2];
            GLES30.glGenBuffers(2, vbos, 0);
            mGrassRibbonVbo = vbos[0];
            mGrassInstanceVbo = vbos[1];

            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, mGrassRibbonVbo);
            GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, ribbon.length * 4, rb, GLES30.GL_STATIC_DRAW);

            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, mGrassInstanceVbo);
            GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, inst.length * 4, ib, GLES30.GL_STATIC_DRAW);
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0);
        }

        private void initReflectionFbo() {
            int[] fbo = new int[1];
            int[] tex = new int[1];
            int[] rb = new int[1];
            GLES30.glGenFramebuffers(1, fbo, 0);
            GLES30.glGenTextures(1, tex, 0);
            GLES30.glGenRenderbuffers(1, rb, 0);

            mReflectFbo = fbo[0];
            mReflectTex = tex[0];
            mReflectDepthRb = rb[0];

            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, mReflectTex);
            GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, REFLECT_W, REFLECT_H, 0,
                    GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);

            GLES30.glBindRenderbuffer(GLES30.GL_RENDERBUFFER, mReflectDepthRb);
            GLES30.glRenderbufferStorage(GLES30.GL_RENDERBUFFER, GLES30.GL_DEPTH_COMPONENT16, REFLECT_W, REFLECT_H);

            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, mReflectFbo);
            GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, mReflectTex, 0);
            GLES30.glFramebufferRenderbuffer(GLES30.GL_FRAMEBUFFER, GLES30.GL_DEPTH_ATTACHMENT, GLES30.GL_RENDERBUFFER, mReflectDepthRb);
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
        }

        private void compileAllShaders() {
            // 1. 3D Mesh Shader with inverse-transpose normal transform & Debug Solid Mode
            String vsMesh =
                    "#version 300 es\n" +
                    "layout(location = 0) in vec3 aPos;\n" +
                    "layout(location = 1) in vec3 aNormal;\n" +
                    "layout(location = 2) in vec2 aUv;\n" +
                    "uniform mat4 uMVP;\n" +
                    "uniform mat4 uModel;\n" +
                    "out vec3 vWorldPos;\n" +
                    "out vec3 vNormal;\n" +
                    "out vec2 vUv;\n" +
                    "void main() {\n" +
                    "    vec4 wp = uModel * vec4(aPos, 1.0);\n" +
                    "    vWorldPos = wp.xyz;\n" +
                    "    mat3 normalMat = transpose(inverse(mat3(uModel)));\n" +
                    "    vNormal = normalize(normalMat * aNormal);\n" +
                    "    vUv = aUv;\n" +
                    "    gl_Position = uMVP * vec4(aPos, 1.0);\n" +
                    "}\n";

            String fsMesh =
                    "#version 300 es\n" +
                    "precision mediump float;\n" +
                    "in vec3 vWorldPos;\n" +
                    "in vec3 vNormal;\n" +
                    "in vec2 vUv;\n" +
                    "uniform sampler2D uAtlas;\n" +
                    "uniform vec3 uBaseColor;\n" +
                    "uniform vec3 uCamPos;\n" +
                    "uniform float uCellScale;\n" +
                    "uniform int uMaterialMode;\n" + // 0=Cliff/Tree ASCII, 1=Chainmail Coif, 2=Ground Soil, 3=Dark-Armored 3D Character
                    "uniform int uDebugSolid;\n" +
                    "uniform float uTime;\n" +
                    "out vec4 fragColor;\n" +
                    "void main() {\n" +
                    "    vec3 N = normalize(vNormal);\n" +
                    "    vec3 L = normalize(vec3(-0.52, 0.80, 0.32));\n" +
                    "    vec3 V = normalize(uCamPos - vWorldPos);\n" +
                    "    vec3 H = normalize(L + V);\n" +
                    "    float diff = max(0.08, dot(N, L));\n" +
                    "    float spec = pow(max(0.0, dot(N, H)), 18.0);\n" +
                    "    float rim = pow(1.0 - max(0.0, dot(N, V)), 2.4);\n" +
                    "    if (uDebugSolid == 1) {\n" +
                    "        vec3 solidCol = uBaseColor * (0.25 + 0.75 * diff) + vec3(spec * 0.35 + rim * 0.2);\n" +
                    "        fragColor = vec4(solidCol, 1.0);\n" +
                    "        return;\n" +
                    "    }\n" +
                    "    if (uMaterialMode == 2) {\n" +
                    "        vec2 gCoord = vWorldPos.xz * 2.2;\n" +
                    "        vec2 cId = floor(gCoord);\n" +
                    "        vec2 cUv = fract(gCoord);\n" +
                    "        float h = fract(sin(dot(cId, vec2(37.1, 61.7))) * 43758.5453);\n" +
                    "        vec3 soil = vec3(0.024, 0.038, 0.034);\n" +
                    "        if (h < 0.55) { fragColor = vec4(soil, 1.0); return; }\n" +
                    "        float gCol = floor(h * 16.0);\n" +
                    "        vec2 aUv = (vec2(gCol, 4.0) + cUv) / vec2(16.0, 6.0);\n" +
                    "        float m = texture(uAtlas, aUv).a;\n" +
                    "        vec3 col = mix(soil, vec3(0.20, 0.27, 0.32), m * 0.65);\n" +
                    "        fragColor = vec4(col, 1.0);\n" +
                    "        return;\n" +
                    "    }\n" +
                    "    vec2 scGrid = gl_FragCoord.xy / max(6.0, uCellScale);\n" +
                    "    vec2 cellId = floor(scGrid);\n" +
                    "    vec2 cellUv = fract(scGrid);\n" +
                    "    cellUv.y = 1.0 - cellUv.y;\n" +
                    "    if (uMaterialMode == 3) {\n" +
                    "        float lum = clamp(diff * 0.48 + spec * 0.92 + rim * 0.52, 0.04, 0.99);\n" +
                    "        float idx = (spec > 0.35 || rim > 0.58) ? (22.0 + floor(lum * 9.0))\n" +
                    "                  : (diff > 0.38 ? (8.0 + floor(lum * 13.0)) : (2.0 + floor(lum * 6.0)));\n" +
                    "        vec2 atlasUv = (vec2(mod(idx, 16.0), floor(idx / 16.0)) + cellUv) / vec2(16.0, 6.0);\n" +
                    "        float mask = texture(uAtlas, atlasUv).a;\n" +
                    "        vec3 obsidianBack = vec3(0.014, 0.018, 0.022);\n" +
                    "        vec3 glyphRgb = (spec > 0.35 || rim > 0.58) ? vec3(0.95, 0.98, 1.0) : (uBaseColor * (0.32 + 0.78 * lum));\n" +
                    "        fragColor = vec4(mix(obsidianBack, glyphRgb, mask), 1.0);\n" +
                    "        return;\n" +
                    "    }\n" +
                    "    float lum = clamp(diff * 0.80 + rim * 0.42, 0.06, 0.99);\n" +
                    "    float glyphCol;\n" +
                    "    float glyphRow;\n" +
                    "    if (uMaterialMode == 1) {\n" +
                    "        float h = fract(sin(dot(cellId, vec2(12.9898, 78.233))) * 43758.5453);\n" +
                    "        glyphCol = floor(h * 16.0);\n" +
                    "        glyphRow = 2.0;\n" +
                    "    } else {\n" +
                    "        float h = fract(sin(dot(cellId, vec2(19.19, 73.73))) * 43758.5453);\n" +
                    "        float idx = clamp(floor((lum * 0.76 + h * 0.24) * 31.0), 2.0, 31.0);\n" +
                    "        glyphCol = mod(idx, 16.0);\n" +
                    "        glyphRow = floor(idx / 16.0);\n" +
                    "    }\n" +
                    "    vec2 atlasUv = (vec2(glyphCol, glyphRow) + cellUv) / vec2(16.0, 6.0);\n" +
                    "    float mask = texture(uAtlas, atlasUv).a;\n" +
                    "    vec3 darkBack = vec3(0.020, 0.026, 0.032);\n" +
                    "    vec3 litGlyph = uBaseColor * (0.28 + 0.84 * lum);\n" +
                    "    vec3 col = mix(darkBack, litGlyph, mask);\n" +
                    "    float dist = length(vWorldPos.xz - uCamPos.xz);\n" +
                    "    float fog = clamp((dist - 15.0) / 24.0, 0.0, 0.52);\n" +
                    "    fragColor = vec4(mix(col, vec3(0.46, 0.54, 0.56), fog), 1.0);\n" +
                    "}\n";

            // 2. GPU Instanced 3D Grass & Wildflower Shader (Strictly grounded at y=0, excluded from rocks & river!)
            String vsGrass =
                    "#version 300 es\n" +
                    "layout(location = 0) in vec4 aRibbon;\n" +
                    "layout(location = 1) in vec4 aInst;\n" +
                    "uniform mat4 uVP;\n" +
                    "uniform vec3 uPlayerPos;\n" +
                    "uniform vec3 uCamRight;\n" +
                    "uniform float uTime;\n" +
                    "out vec2 vUv;\n" +
                    "out vec3 vColor;\n" +
                    "out vec2 vAtlasCell;\n" +
                    "out float vFog;\n" +
                    "void main() {\n" +
                    "    vec2 tile = floor((uPlayerPos.xz - aInst.xy + 14.0) / 28.0) * 28.0 + aInst.xy;\n" +
                    "    float riverZ = -6.5 + sin(tile.x * 0.14) * 2.2;\n" +
                    "    if (abs(tile.y - riverZ) < 2.65) {\n" +
                    "        gl_Position = vec4(0.0, 0.0, -2.0, 1.0);\n" +
                    "        return;\n" +
                    "    }\n" +
                    "    bool isFlower = (aInst.w >= 100.0);\n" +
                    "    float sway = sin(tile.x * 0.55 + tile.y * 0.45 - uTime * 2.5) * 0.12 * aRibbon.y;\n" +
                    "    float wScale = isFlower ? 0.18 : 0.12;\n" +
                    "    vec3 worldPos = vec3(tile.x, 0.0, tile.y)\n" +
                    "                  + uCamRight * (aRibbon.x * wScale + sway)\n" +
                    "                  + vec3(0.0, aRibbon.y * aInst.z, 0.0);\n" +
                    "    float dPlayer = length(tile - (uPlayerPos.xz + vec2(0.30, 0.20)));\n" +
                    "    float shadow = smoothstep(0.35, 1.25, dPlayer);\n" +
                    "    if (isFlower) {\n" +
                    "        float fType = mod(aInst.w - 100.0, 5.0);\n" +
                    "        vAtlasCell = vec2(3.0 + mod(fType, 3.0), 3.0);\n" +
                    "        vec3 fCol = (fType < 1.5) ? vec3(0.76, 0.62, 0.94)\n" +
                    "                  : (fType < 3.5 ? vec3(0.95, 0.96, 0.90) : vec3(0.68, 0.54, 0.86));\n" +
                    "        vColor = fCol * (0.45 + 0.55 * shadow);\n" +
                    "    } else {\n" +
                    "        vAtlasCell = vec2(mod(aInst.w, 3.0), 3.0);\n" +
                    "        float shade = fract(aInst.w * 0.173);\n" +
                    "        vec3 rootCol = vec3(0.04, 0.12, 0.06);\n" +
                    "        vec3 tipCol = mix(vec3(0.14, 0.38, 0.17), vec3(0.38, 0.66, 0.33), shade);\n" +
                    "        vColor = mix(rootCol, tipCol, aRibbon.y) * (0.30 + 0.70 * shadow);\n" +
                    "    }\n" +
                    "    vUv = aRibbon.zw;\n" +
                    "    float distCam = length(tile - uPlayerPos.xz);\n" +
                    "    vFog = clamp((distCam - 11.0) / 18.0, 0.0, 0.45);\n" +
                    "    gl_Position = uVP * vec4(worldPos, 1.0);\n" +
                    "}\n";

            String fsGrass =
                    "#version 300 es\n" +
                    "precision mediump float;\n" +
                    "in vec2 vUv;\n" +
                    "in vec3 vColor;\n" +
                    "in vec2 vAtlasCell;\n" +
                    "in float vFog;\n" +
                    "uniform sampler2D uAtlas;\n" +
                    "out vec4 fragColor;\n" +
                    "void main() {\n" +
                    "    vec2 atlasUv = (vAtlasCell + vUv) / vec2(16.0, 6.0);\n" +
                    "    float a = texture(uAtlas, atlasUv).a;\n" +
                    "    if (a < 0.25) discard;\n" +
                    "    vec3 col = mix(vColor, vec3(0.46, 0.54, 0.56), vFog);\n" +
                    "    fragColor = vec4(col, 1.0);\n" +
                    "}\n";

            // 3. Normal-Mapped 3D Water & Planar ASCII Reflection Shader
            String vsWater =
                    "#version 300 es\n" +
                    "layout(location = 0) in vec3 aPos;\n" +
                    "uniform mat4 uMVP;\n" +
                    "uniform mat4 uModel;\n" +
                    "out vec3 vWorldPos;\n" +
                    "out vec4 vClipPos;\n" +
                    "void main() {\n" +
                    "    vec4 wp = uModel * vec4(aPos, 1.0);\n" +
                    "    vWorldPos = wp.xyz;\n" +
                    "    vClipPos = uMVP * vec4(aPos, 1.0);\n" +
                    "    gl_Position = vClipPos;\n" +
                    "}\n";

            String fsWater =
                    "#version 300 es\n" +
                    "precision mediump float;\n" +
                    "in vec3 vWorldPos;\n" +
                    "in vec4 vClipPos;\n" +
                    "uniform sampler2D uAtlas;\n" +
                    "uniform sampler2D uReflectTex;\n" +
                    "uniform float uTime;\n" +
                    "out vec4 fragColor;\n" +
                    "void main() {\n" +
                    "    vec2 p = vWorldPos.xz;\n" +
                    "    float w1 = sin(p.x * 1.4 + p.y * 0.9 - uTime * 2.4);\n" +
                    "    float w2 = cos(p.x * 0.8 - p.y * 1.7 + uTime * 1.8);\n" +
                    "    vec3 N = normalize(vec3(w1 * 0.25, 1.0, w2 * 0.25));\n" +
                    "    vec3 L = normalize(vec3(-0.45, 0.65, 0.60));\n" +
                    "    float spec = pow(max(0.0, dot(N, L)), 14.0);\n" +
                    "    vec2 ndc = (vClipPos.xy / max(0.001, vClipPos.w)) * 0.5 + 0.5;\n" +
                    "    vec2 reflUv = clamp(vec2(ndc.x, 1.0 - ndc.y) + N.xz * 0.03, 0.01, 0.99);\n" +
                    "    vec3 reflCol = texture(uReflectTex, reflUv).rgb;\n" +
                    "    vec2 cellUv = fract(p * 3.6);\n" +
                    "    float glyphIdx = floor(clamp((spec * 1.5 + length(reflCol) * 0.45), 0.0, 0.99) * 15.0);\n" +
                    "    vec2 atlasUv = (vec2(glyphIdx, 5.0) + cellUv) / vec2(16.0, 6.0);\n" +
                    "    float gMask = texture(uAtlas, atlasUv).a;\n" +
                    "    vec3 deepWater = vec3(0.022, 0.034, 0.056);\n" +
                    "    vec3 streakCol = vec3(0.76, 0.84, 0.94) * gMask * smoothstep(0.35, 0.88, spec + w1 * 0.22);\n" +
                    "    vec3 col = deepWater + reflCol * (0.42 + 0.35 * gMask) + streakCol;\n" +
                    "    fragColor = vec4(col, 1.0);\n" +
                    "}\n";

            mProgMeshAscii = linkProgram(vsMesh, fsMesh);
            mProgGrassInstanced = linkProgram(vsGrass, fsGrass);
            mProgWaterAscii = linkProgram(vsWater, fsWater);
        }

        private int linkProgram(String vsSrc, String fsSrc) {
            int vs = GLES30.glCreateShader(GLES30.GL_VERTEX_SHADER);
            GLES30.glShaderSource(vs, vsSrc);
            GLES30.glCompileShader(vs);

            int fs = GLES30.glCreateShader(GLES30.GL_FRAGMENT_SHADER);
            GLES30.glShaderSource(fs, fsSrc);
            GLES30.glCompileShader(fs);

            int prog = GLES30.glCreateProgram();
            GLES30.glAttachShader(prog, vs);
            GLES30.glAttachShader(prog, fs);
            GLES30.glLinkProgram(prog);
            return prog;
        }

        private void render3DOpenWorldScene() {
            float aspect = mWidth / (float) mHeight;
            Matrix.perspectiveM(mProjMatrix, 0, 40.0f / mState.cameraZoom, aspect, 0.5f, 80.0f);

            float cursorOffX = mState.cursorViewMode ? (mState.cursorX - 0.5f) * 2.4f : 0.0f;
            float cursorOffZ = mState.cursorViewMode ? (mState.cursorY - 0.5f) * 2.4f : 0.0f;
            float targetX = mState.playerX + cursorOffX;
            float targetZ = mState.playerZ + cursorOffZ;

            float camDist = 9.8f / mState.cameraZoom;
            float camHeight = 9.0f / mState.cameraZoom;
            float eyeX = targetX + (float) Math.sin(mState.camYaw) * camDist;
            float eyeY = camHeight;
            float eyeZ = targetZ + (float) Math.cos(mState.camYaw) * camDist;

            // 1. Planar Water Reflection FBO Pass
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, mReflectFbo);
            GLES30.glViewport(0, 0, REFLECT_W, REFLECT_H);
            GLES30.glClearColor(0.018f, 0.028f, 0.042f, 1.0f);
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT | GLES30.GL_DEPTH_BUFFER_BIT);

            Matrix.setLookAtM(mReflectViewMatrix, 0,
                    eyeX, -eyeY * 0.65f, eyeZ,
                    targetX, 0.0f, targetZ,
                    0f, 1f, 0f);
            Matrix.multiplyMM(mReflectVpMatrix, 0, mProjMatrix, 0, mReflectViewMatrix, 0);
            draw3DEntitiesAndLandscape(mReflectVpMatrix, eyeX, -eyeY * 0.65f, eyeZ);

            // 2. Main Screen Pass
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
            GLES30.glViewport(0, 0, mWidth, mHeight);
            GLES30.glClearColor(0.024f, 0.038f, 0.034f, 1.0f);
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT | GLES30.GL_DEPTH_BUFFER_BIT);

            Matrix.setLookAtM(mViewMatrix, 0,
                    eyeX, eyeY, eyeZ,
                    targetX, 0.45f, targetZ,
                    0f, 1f, 0f);
            Matrix.multiplyMM(mVpMatrix, 0, mProjMatrix, 0, mViewMatrix, 0);

            drawGroundPlane(mVpMatrix, eyeX, eyeY, eyeZ);
            drawWaterSurface(mVpMatrix);
            draw3DEntitiesAndLandscape(mVpMatrix, eyeX, eyeY, eyeZ);
            if (!mState.debugSolidMode) {
                drawInstanced3DGrass(mVpMatrix);
            }
        }

        private void bindQuadVbo() {
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, mQuadVbo);
            GLES30.glEnableVertexAttribArray(0);
            GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 32, 0);
            GLES30.glEnableVertexAttribArray(1);
            GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 32, 12);
            GLES30.glEnableVertexAttribArray(2);
            GLES30.glVertexAttribPointer(2, 2, GLES30.GL_FLOAT, false, 32, 24);
        }

        private void bindSphereVbo() {
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, mSphereVbo);
            GLES30.glEnableVertexAttribArray(0);
            GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 32, 0);
            GLES30.glEnableVertexAttribArray(1);
            GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 32, 12);
            GLES30.glEnableVertexAttribArray(2);
            GLES30.glVertexAttribPointer(2, 2, GLES30.GL_FLOAT, false, 32, 24);
            GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, mSphereIbo);
        }

        private void drawGroundPlane(float[] vp, float eyeX, float eyeY, float eyeZ) {
            GLES30.glUseProgram(mProgMeshAscii);
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, mGlyphAtlasTex);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgMeshAscii, "uAtlas"), 0);
            GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uCamPos"), eyeX, eyeY, eyeZ);
            GLES30.glUniform1f(GLES30.glGetUniformLocation(mProgMeshAscii, "uCellScale"), 8.0f);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgMeshAscii, "uMaterialMode"), 2);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgMeshAscii, "uDebugSolid"), mState.debugSolidMode ? 1 : 0);
            GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uBaseColor"), 0.08f, 0.16f, 0.10f);

            Matrix.setIdentityM(mModelMatrix, 0);
            Matrix.translateM(mModelMatrix, 0, mState.playerX, -0.02f, mState.playerZ);
            Matrix.scaleM(mModelMatrix, 0, 36.0f, 1.0f, 36.0f);
            Matrix.multiplyMM(mMvpMatrix, 0, vp, 0, mModelMatrix, 0);

            GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(mProgMeshAscii, "uMVP"), 1, false, mMvpMatrix, 0);
            GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(mProgMeshAscii, "uModel"), 1, false, mModelMatrix, 0);

            bindQuadVbo();
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 6);
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0);
        }

        private void drawWaterSurface(float[] vp) {
            GLES30.glUseProgram(mProgWaterAscii);
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, mGlyphAtlasTex);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgWaterAscii, "uAtlas"), 0);

            GLES30.glActiveTexture(GLES30.GL_TEXTURE1);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, mReflectTex);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgWaterAscii, "uReflectTex"), 1);
            GLES30.glUniform1f(GLES30.glGetUniformLocation(mProgWaterAscii, "uTime"), mState.timeSec);

            bindQuadVbo();
            for (int seg = -4; seg <= 4; seg++) {
                float wx = mState.playerX + seg * 6.0f;
                float wz = mState.riverCenterZ(wx);
                Matrix.setIdentityM(mModelMatrix, 0);
                Matrix.translateM(mModelMatrix, 0, wx, 0.01f, wz);
                Matrix.scaleM(mModelMatrix, 0, 3.2f, 1.0f, 2.65f);
                Matrix.multiplyMM(mMvpMatrix, 0, vp, 0, mModelMatrix, 0);

                GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(mProgWaterAscii, "uMVP"), 1, false, mMvpMatrix, 0);
                GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(mProgWaterAscii, "uModel"), 1, false, mModelMatrix, 0);
                GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 6);
            }
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0);
        }

        private void draw3DEntitiesAndLandscape(float[] vp, float eyeX, float eyeY, float eyeZ) {
            GLES30.glUseProgram(mProgMeshAscii);
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, mGlyphAtlasTex);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgMeshAscii, "uAtlas"), 0);
            GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uCamPos"), eyeX, eyeY, eyeZ);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgMeshAscii, "uDebugSolid"), mState.debugSolidMode ? 1 : 0);

            bindSphereVbo();

            // 1. Deliberate Ground-Anchored 3D Rock Formations & Canyon Walls
            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgMeshAscii, "uMaterialMode"), 0);
            GLES30.glUniform1f(GLES30.glGetUniformLocation(mProgMeshAscii, "uCellScale"), 9.5f);
            GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uBaseColor"), 0.80f, 0.85f, 0.90f);
            for (int i = 0; i < ROCK_FORMATIONS.length; i++) {
                float[] rf = ROCK_FORMATIONS[i];
                float dx = rf[0] - mState.playerX;
                float dz = rf[1] - mState.playerZ;
                if (dx * dx + dz * dz > 30.0f * 30.0f) continue;
                // Anchor base firmly below ground (centerY = height * 0.35f) so NO rock ever floats!
                drawSpherePart(vp, rf[0], rf[3] * 0.35f, rf[1], 0f, rf[2], rf[3], rf[4]);
            }

            // 2. Deliberate Ground-Anchored 3D Forest Trees (Trunk + Layered Canopy)
            for (int t = 0; t < FOREST_TREES.length; t++) {
                float[] tr = FOREST_TREES[t];
                float dx = tr[0] - mState.playerX;
                float dz = tr[1] - mState.playerZ;
                if (dx * dx + dz * dz > 28.0f * 28.0f) continue;
                // Grounded Trunk
                GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uBaseColor"), 0.42f, 0.34f, 0.26f);
                drawSpherePart(vp, tr[0], tr[2] * 0.45f, tr[1], 0f, 0.55f, tr[2], 0.55f);
                // Layered 3D Leaf Canopy
                GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uBaseColor"), 0.24f, 0.58f, 0.28f);
                drawSpherePart(vp, tr[0], tr[2] * 0.92f, tr[1], 0f, tr[3], tr[3] * 0.85f, tr[3]);
                drawSpherePart(vp, tr[0] - 0.4f, tr[2] * 1.15f, tr[1] + 0.3f, 0f, tr[3] * 0.78f, tr[3] * 0.72f, tr[3] * 0.78f);
            }

            // 3. Cohesive, Connected 3D Humanoid Player Adventurer
            float spd = (float) Math.sqrt(mState.velX * mState.velX + mState.velZ * mState.velZ);
            drawConnected3DHumanoid(vp, mState.playerX, mState.playerY, mState.playerZ, mState.bodyYaw,
                    mState.gaitPhase, Math.min(1.1f, spd / 4.2f), mState.slashTimer / 0.28f,
                    mState.dodgeTimer > 0.0f, mState.playerY > 0.05f,
                    mState.slotMetal, mState.mounted, mState.hurtFlash > 0.0f, true);

            // 4. Cohesive, Connected 3D Humanoid Enemies
            for (int i = 0; i < GameState.NUM_ENEMIES; i++) {
                float dx = mState.enemyX[i] - mState.playerX;
                float dz = mState.enemyZ[i] - mState.playerZ;
                if (dx * dx + dz * dz > 24.0f * 24.0f) continue;
                float eMove = (mState.enemyAggro[i] && mState.enemyWindup[i] <= 0.0f) ? 0.85f : 0.0f;
                int eMet = mState.enemyMetal[i];
                int[] eSlots = new int[]{eMet, eMet, eMet, eMet, eMet, eMet};
                drawConnected3DHumanoid(vp, mState.enemyX[i], 0.0f, mState.enemyZ[i], mState.enemyYaw[i],
                        mState.enemyGait[i], eMove, mState.enemyWindup[i] / 0.42f,
                        false, false, eSlots, false, mState.enemyHurt[i] > 0.0f, false);
            }

            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0);
            GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, 0);
        }

        // ---------------------------------------------------------------------
        // CONNECTED, PROPORTIONAL 3D HUMANOID MODEL (NO FLOATING LIMBS OR GIANT SPHERES!)
        // ---------------------------------------------------------------------
        private void drawConnected3DHumanoid(
                float[] vp, float wx, float wy, float wz, float yawRad,
                float gait, float moveAmt, float slashProg, boolean dodging,
                boolean jumping, int[] slotMetals, boolean mounted,
                boolean hurtFlash, boolean isPlayer
        ) {
            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgMeshAscii, "uMaterialMode"), 3);
            GLES30.glUniform1f(GLES30.glGetUniformLocation(mProgMeshAscii, "uCellScale"), isPlayer ? 6.8f : 7.8f);

            float s = isPlayer ? 1.25f : 1.12f;
            float yawDeg = (float) Math.toDegrees(yawRad);
            float sinY = (float) Math.sin(yawRad);
            float cosY = (float) Math.cos(yawRad);
            float rightX = cosY;
            float rightZ = -sinY;

            float breathe = (float) Math.sin(mState.timeSec * 2.5f) * 0.02f;
            float bounce = (float) Math.abs(Math.sin(gait)) * 0.08f * moveAmt;
            float crouch = dodging ? 0.20f : 0.0f;
            float mountH = mounted ? 0.78f : 0.0f;
            float baseH = wy + mountH - crouch;

            // Ground contact shadow
            GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uBaseColor"), 0.02f, 0.03f, 0.03f);
            drawSpherePart(vp, wx + 0.18f * s, 0.015f, wz + 0.12f * s, yawDeg, 0.72f * s, 0.03f, 0.56f * s);

            if (mounted) {
                GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uBaseColor"), 0.88f, 0.91f, 0.95f);
                drawSpherePart(vp, wx, wy + 0.68f + bounce, wz, yawDeg, 0.62f, 0.54f, 1.38f);
                drawSpherePart(vp, wx + sinY * 0.62f, wy + 1.08f + bounce, wz + cosY * 0.62f, yawDeg, 0.38f, 0.58f, 0.44f);
                for (int leg = 0; leg < 4; leg++) {
                    float lx = (leg % 2 == 0 ? -0.24f : 0.24f);
                    float lz = (leg < 2 ? 0.44f : -0.44f);
                    float sw = (float) Math.sin(gait + leg * 1.57f) * 0.26f * moveAmt;
                    drawSpherePart(vp, wx + rightX * lx + sinY * (lz + sw), wy + 0.34f, wz + rightZ * lx + cosY * (lz + sw),
                            yawDeg, 0.18f, 0.68f, 0.18f);
                }
            }

            // 1. Overlapping Thigh + Shin + Boot (Continuous connected leg column!)
            for (int leg = 0; leg < 2; leg++) {
                float side = (leg == 0 ? -0.15f : 0.15f) * s;
                float ph = gait + (leg == 1 ? (float) Math.PI : 0.0f);
                float swing = jumping ? (leg == 0 ? 0.18f : -0.14f) : ((float) Math.sin(ph) * 0.28f * moveAmt);
                float lift = jumping ? 0.16f : (Math.max(0.0f, (float) Math.cos(ph)) * 0.14f * moveAmt);

                setPartColor(slotMetals[4], hurtFlash);
                float tx = wx + rightX * side + sinY * (swing * 0.5f) * s;
                float ty = baseH + (0.58f + lift * 0.4f) * s;
                float tz = wz + rightZ * side + cosY * (swing * 0.5f) * s;
                drawSpherePart(vp, tx, ty, tz, yawDeg, 0.22f * s, 0.46f * s, 0.24f * s);

                float sx = wx + rightX * side + sinY * (swing * 0.85f) * s;
                float sy = baseH + (0.28f + lift * 0.8f) * s;
                float sz = wz + rightZ * side + cosY * (swing * 0.85f) * s;
                drawSpherePart(vp, sx, sy, sz, yawDeg, 0.19f * s, 0.42f * s, 0.20f * s);

                setPartColor(slotMetals[5], hurtFlash);
                drawSpherePart(vp, sx + sinY * 0.06f * s, baseH + (0.09f + lift) * s, sz + cosY * 0.06f * s,
                        yawDeg, 0.20f * s, 0.18f * s, 0.28f * s);
            }

            // 2. Connected Pelvis, Waist & Chest Cuirass (Overlapping vertical spine!)
            float pelvisY = baseH + (0.80f + bounce) * s;
            float chestY = pelvisY + (0.34f + breathe) * s;
            setPartColor(slotMetals[2], hurtFlash);
            drawSpherePart(vp, wx, pelvisY, wz, yawDeg, 0.40f * s, 0.32f * s, 0.30f * s);
            drawSpherePart(vp, wx, chestY, wz, yawDeg, 0.46f * s, 0.52f * s, 0.34f * s);

            // 3. Traveler Cloak / Pack snugly attached to upper back (Matches `6df93fa4.jpeg`!)
            GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uBaseColor"), 0.38f, 0.42f, 0.46f);
            drawSpherePart(vp, wx - sinY * 0.14f * s - rightX * 0.08f * s, chestY - 0.04f * s,
                    wz - cosY * 0.14f * s - rightZ * 0.08f * s, yawDeg, 0.42f * s, 0.58f * s, 0.28f * s);

            // 4. Connected Pauldrons & Arms (Slot 1 & Slot 3)
            setPartColor(slotMetals[1], hurtFlash);
            float shSpan = 0.28f * s;
            for (int side = -1; side <= 1; side += 2) {
                drawSpherePart(vp, wx + rightX * (side * shSpan), chestY + 0.14f * s, wz + rightZ * (side * shSpan),
                        yawDeg, 0.22f * s, 0.24f * s, 0.22f * s);
            }

            // Left Arm connected to Left Shoulder
            setPartColor(slotMetals[3], hurtFlash);
            float armSw = (float) Math.sin(gait) * 0.20f * moveAmt;
            drawSpherePart(vp, wx - rightX * (shSpan + 0.04f * s) - sinY * armSw * s, chestY - 0.10f * s,
                    wz - rightZ * (shSpan + 0.04f * s) - cosY * armSw * s, yawDeg, 0.17f * s, 0.44f * s, 0.18f * s);

            // Right Sword Arm connected to Right Shoulder + Extended Blade
            float slashAng = (slashProg > 0.0f) ? (-1.35f + (1.0f - slashProg) * 2.7f) : (0.48f + armSw * 0.4f);
            float sDirX = (float) Math.sin(yawRad + slashAng);
            float sDirZ = (float) Math.cos(yawRad + slashAng);
            float rArmX = wx + rightX * (shSpan + 0.04f * s) + sDirX * 0.14f * s;
            float rArmY = chestY - 0.08f * s;
            float rArmZ = wz + rightZ * (shSpan + 0.04f * s) + sDirZ * 0.14f * s;
            drawSpherePart(vp, rArmX, rArmY, rArmZ, yawDeg, 0.17f * s, 0.44f * s, 0.18f * s);

            // Gleaming Sword Blade extending from right hand
            GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uBaseColor"), 0.95f, 0.98f, 1.0f);
            float swordYawDeg = (float) Math.toDegrees(yawRad + slashAng);
            drawSpherePart(vp, rArmX + sDirX * 0.52f * s, rArmY - 0.12f * s, rArmZ + sDirZ * 0.52f * s,
                    swordYawDeg, 0.08f * s, 0.08f * s, 0.92f * s);

            // 5. Connected Neck & Helmeted Head (Slot 0)
            setPartColor(slotMetals[0], hurtFlash);
            float headY = chestY + 0.38f * s;
            drawSpherePart(vp, wx, headY, wz, yawDeg, 0.28f * s, 0.34f * s, 0.30f * s);

            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgMeshAscii, "uMaterialMode"), 0);
        }

        private void setPartColor(int metalIdx, boolean hurtFlash) {
            if (hurtFlash) {
                GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uBaseColor"), 1.0f, 0.28f, 0.28f);
            } else {
                float[] rgb = GameState.METAL_RGB[Math.max(0, Math.min(9, metalIdx))];
                GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uBaseColor"), rgb[0], rgb[1], rgb[2]);
            }
        }

        private void drawSpherePart(float[] vp, float x, float y, float z, float yawDeg, float sx, float sy, float sz) {
            Matrix.setIdentityM(mModelMatrix, 0);
            Matrix.translateM(mModelMatrix, 0, x, y, z);
            if (yawDeg != 0.0f) {
                Matrix.rotateM(mModelMatrix, 0, yawDeg, 0f, 1f, 0f);
            }
            Matrix.scaleM(mModelMatrix, 0, sx, sy, sz);
            Matrix.multiplyMM(mMvpMatrix, 0, vp, 0, mModelMatrix, 0);

            GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(mProgMeshAscii, "uMVP"), 1, false, mMvpMatrix, 0);
            GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(mProgMeshAscii, "uModel"), 1, false, mModelMatrix, 0);
            GLES30.glDrawElements(GLES30.GL_TRIANGLES, mSphereIndexCount, GLES30.GL_UNSIGNED_SHORT, 0);
        }

        private void drawInstanced3DGrass(float[] vp) {
            GLES30.glUseProgram(mProgGrassInstanced);
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, mGlyphAtlasTex);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgGrassInstanced, "uAtlas"), 0);
            GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(mProgGrassInstanced, "uVP"), 1, false, vp, 0);
            GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgGrassInstanced, "uPlayerPos"), mState.playerX, 0.0f, mState.playerZ);
            GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgGrassInstanced, "uCamRight"),
                    (float) Math.cos(mState.camYaw), 0.0f, -(float) Math.sin(mState.camYaw));
            GLES30.glUniform1f(GLES30.glGetUniformLocation(mProgGrassInstanced, "uTime"), mState.timeSec);

            GLES30.glDisableVertexAttribArray(2);
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, mGrassRibbonVbo);
            GLES30.glEnableVertexAttribArray(0);
            GLES30.glVertexAttribPointer(0, 4, GLES30.GL_FLOAT, false, 16, 0);
            GLES30.glVertexAttribDivisor(0, 0);

            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, mGrassInstanceVbo);
            GLES30.glEnableVertexAttribArray(1);
            GLES30.glVertexAttribPointer(1, 4, GLES30.GL_FLOAT, false, 16, 0);
            GLES30.glVertexAttribDivisor(1, 1);

            int count = (mState.qualityPreset == 0) ? 8000 : (mState.qualityPreset == 1 ? 16000 : MAX_GRASS_INSTANCES);
            GLES30.glDrawArraysInstanced(GLES30.GL_TRIANGLES, 0, 6, count);

            GLES30.glVertexAttribDivisor(1, 0);
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0);
        }

        private void render3DChainmailEquipmentScene() {
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
            GLES30.glViewport(0, 0, mWidth, mHeight);
            GLES30.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT | GLES30.GL_DEPTH_BUFFER_BIT);

            float aspect = mWidth / (float) mHeight;
            Matrix.perspectiveM(mProjMatrix, 0, 38.0f / mState.previewZoom, aspect, 0.5f, 30.0f);
            Matrix.setLookAtM(mViewMatrix, 0, 0.65f, 0.35f, 4.2f, 0.45f, -0.15f, 0.0f, 0f, 1f, 0f);
            Matrix.multiplyMM(mVpMatrix, 0, mProjMatrix, 0, mViewMatrix, 0);

            GLES30.glUseProgram(mProgMeshAscii);
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, mGlyphAtlasTex);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgMeshAscii, "uAtlas"), 0);
            GLES30.glUniform3f(GLES30.glGetUniformLocation(mProgMeshAscii, "uCamPos"), 0.65f, 0.35f, 4.2f);
            GLES30.glUniform1f(GLES30.glGetUniformLocation(mProgMeshAscii, "uCellScale"), 8.5f);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgMeshAscii, "uMaterialMode"), 1);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(mProgMeshAscii, "uDebugSolid"), mState.debugSolidMode ? 1 : 0);

            bindSphereVbo();
            setPartColor(mState.activeMetal, false);
            float yawDeg = (float) Math.toDegrees(mState.previewYaw);

            drawSpherePart(mVpMatrix, -0.35f, 0.28f, 0.0f, yawDeg, 0.95f, 1.05f, 0.95f);
            drawSpherePart(mVpMatrix, -0.35f, -0.38f, 0.0f, yawDeg, 1.55f, 0.85f, 1.35f);
            drawSpherePart(mVpMatrix, -0.35f, -0.68f, 0.0f, yawDeg, 1.95f, 0.45f, 1.65f);

            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0);
            GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, 0);
        }
    }

    // =========================================================================
    // CRISP MONOSPACE HUD, HOTBAR & EQUIPMENT OVERLAY (MATCHING SCREENSHOTS!)
    // =========================================================================
    private static final class HudOverlayView extends View {
        private final GameState mState;
        private final Paint mTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mBoxPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF mRect = new RectF();

        private static final String[] SENJE_PORTRAIT = {
                "  .---.  ",
                "  |===|  ",
                " .|===|. ",
                " ||===|| ",
                " ||===|| ",
                "  || ||  ",
                "  || ||  "
        };

        private int mMovePointerId = -1;
        private int mCamPointerId = -1;
        private float mJoyBaseX = 0f, mJoyBaseY = 0f, mJoyCurrX = 0f, mJoyCurrY = 0f;
        private float mLastCamX = 0f;

        HudOverlayView(Context context, GameState state) {
            super(context);
            mState = state;
            mTextPaint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
            mBoxPaint.setStyle(Paint.Style.FILL);
            mBorderPaint.setStyle(Paint.Style.STROKE);
            mBorderPaint.setStrokeWidth(2.0f);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();

            if (mState.screenMode == 2) {
                drawEquipmentMenuOverlay(canvas, w, h);
            } else {
                drawWorldHudOverlay(canvas, w, h);
            }
            postInvalidateOnAnimation();
        }

        private void drawWorldHudOverlay(Canvas canvas, int w, int h) {
            // 1. Top-Left `Senje` Portrait & Status Box (Exact clone of 1000461482.jpg!)
            float boxW = Math.min(w * 0.38f, 420.0f);
            float boxH = Math.min(h * 0.22f, 138.0f);
            float x0 = 16.0f;
            float y0 = 16.0f;

            mBoxPaint.setColor(Color.argb(235, 6, 8, 9));
            canvas.drawRect(x0, y0, x0 + boxW, y0 + boxH, mBoxPaint);
            mBorderPaint.setColor(Color.rgb(175, 182, 180));
            canvas.drawRect(x0, y0, x0 + boxW, y0 + boxH, mBorderPaint);

            // ASCII Portrait on left
            float pSize = boxH * 0.115f;
            mTextPaint.setTextAlign(Paint.Align.LEFT);
            mTextPaint.setTextSize(pSize);
            mTextPaint.setColor(Color.rgb(205, 212, 210));
            for (int r = 0; r < SENJE_PORTRAIT.length; r++) {
                canvas.drawText(SENJE_PORTRAIT[r], x0 + 10f, y0 + 24f + r * (pSize * 1.05f), mTextPaint);
            }

            float tx = x0 + boxW * 0.24f;
            float titleSize = boxH * 0.17f;
            mTextPaint.setTextSize(titleSize);
            mTextPaint.setColor(Color.rgb(242, 245, 244));
            canvas.drawText(mState.playerName, tx, y0 + titleSize * 1.35f, mTextPaint);

            float barSize = boxH * 0.135f;
            mTextPaint.setTextSize(barSize);
            mTextPaint.setColor(Color.rgb(222, 228, 226));
            canvas.drawText("HP |||||||||||||||||||| " + mState.hp + "/" + mState.maxHp, tx, y0 + titleSize * 2.55f, mTextPaint);
            canvas.drawText("MP |||||||||||||||||||| " + mState.mp + "/" + mState.maxMp, tx, y0 + titleSize * 3.65f, mTextPaint);
            canvas.drawText("LV " + mState.level + "  \u00b7  " + mState.gold + "g", tx, y0 + titleSize * 4.85f, mTextPaint);

            // 2. Cursor-View Crosshair `+` & Player Nameplate in 3D World
            mTextPaint.setTextAlign(Paint.Align.CENTER);
            mTextPaint.setTextSize(15.0f);
            mTextPaint.setColor(Color.rgb(235, 240, 238));
            canvas.drawText(mState.playerName, w * 0.5f, h * 0.41f, mTextPaint);

            if (mState.cursorViewMode) {
                mTextPaint.setTextSize(24.0f);
                mTextPaint.setColor(Color.argb(220, 235, 242, 240));
                canvas.drawText("+", mState.cursorX * w, mState.cursorY * h, mTextPaint);
            }

            // 3. Top-Right Minimalist Monospace Controls: [FORGE / EQUIP], [ZOOM], [STEED], [QUALITY]
            float pillW = Math.min(w * 0.16f, 158.0f);
            float pillH = 34.0f;
            float px = w - pillW - 16.0f;
            String modeLabel = mState.debugSolidMode ? "SOLID 3D" : "ASCII 3D";
            String[] pills = {"[EQUIP / FORGE]", "[ZOOM]", mState.mounted ? "[DISMOUNT]" : "[STEED]", "[VIEW: " + modeLabel + "]"};
            mTextPaint.setTextSize(13.0f);
            for (int i = 0; i < pills.length; i++) {
                float py = y0 + i * (pillH + 6.0f);
                mBoxPaint.setColor(Color.argb(220, 8, 10, 11));
                canvas.drawRect(px, py, px + pillW, py + pillH, mBoxPaint);
                mBorderPaint.setColor(Color.rgb(135, 145, 142));
                canvas.drawRect(px, py, px + pillW, py + pillH, mBorderPaint);
                mTextPaint.setColor(Color.rgb(235, 240, 238));
                canvas.drawText(pills[i], px + pillW * 0.5f, py + pillH * 0.66f, mTextPaint);
            }

            // 4. Bottom XP Bar + 1..0 Numbered Hotbar (Exact clone of 1000461485.jpg!)
            float hbW = Math.min(w * 0.54f, 520.0f);
            float hbX = (w - hbW) * 0.5f;
            float hbY = h - 48.0f;

            mBoxPaint.setColor(Color.argb(230, 8, 10, 11));
            canvas.drawRect(hbX, hbY - 18.0f, hbX + hbW, hbY - 3.0f, mBoxPaint);
            mBorderPaint.setColor(Color.rgb(115, 125, 122));
            canvas.drawRect(hbX, hbY - 18.0f, hbX + hbW, hbY - 3.0f, mBorderPaint);

            float xpRatio = Math.max(0f, Math.min(1f, mState.xp / (float) Math.max(1, mState.xpNext)));
            mBoxPaint.setColor(Color.rgb(205, 165, 78));
            canvas.drawRect(hbX + 2f, hbY - 16.0f, hbX + (hbW - 4f) * xpRatio, hbY - 5.0f, mBoxPaint);

            mTextPaint.setTextSize(11.0f);
            mTextPaint.setColor(Color.rgb(238, 242, 240));
            canvas.drawText("LV " + mState.level + " \u00b7 " + mState.xp + " / " + mState.xpNext + " XP", w * 0.5f, hbY - 6.5f, mTextPaint);

            float slotW = hbW / 10.0f;
            for (int s = 0; s < 10; s++) {
                float sx = hbX + s * slotW;
                mBoxPaint.setColor(Color.argb(235, 6, 8, 9));
                canvas.drawRect(sx, hbY, sx + slotW, hbY + 38.0f, mBoxPaint);
                mBorderPaint.setColor(Color.rgb(105, 115, 112));
                canvas.drawRect(sx, hbY, sx + slotW, hbY + 38.0f, mBorderPaint);
                mTextPaint.setColor(Color.rgb(210, 218, 215));
                canvas.drawText(String.valueOf((s + 1) % 10), sx + slotW * 0.5f, hbY + 13.0f, mTextPaint);
                if (s == 0 && mState.potions > 0) {
                    mTextPaint.setColor(Color.rgb(218, 92, 92));
                    canvas.drawText("HPx" + mState.potions, sx + slotW * 0.5f, hbY + 30.0f, mTextPaint);
                } else {
                    canvas.drawText("\u00b7", sx + slotW * 0.5f, hbY + 28.0f, mTextPaint);
                }
            }

            // 5. Bottom-Right Mobile Action Buttons: [ATK] & [DODGE]
            float atkR = Math.min(w, h) * 0.085f;
            float atkCx = w - atkR - 24.0f;
            float atkCy = h - atkR - 24.0f;
            mBoxPaint.setColor(mState.slashTimer > 0f ? Color.argb(235, 48, 82, 62) : Color.argb(220, 8, 11, 10));
            mBorderPaint.setColor(Color.rgb(195, 208, 202));
            canvas.drawCircle(atkCx, atkCy, atkR, mBoxPaint);
            canvas.drawCircle(atkCx, atkCy, atkR, mBorderPaint);
            mTextPaint.setTextSize(15.0f);
            mTextPaint.setColor(Color.rgb(242, 246, 244));
            canvas.drawText("[ATK]", atkCx, atkCy + 5.0f, mTextPaint);

            float dodgeR = Math.min(w, h) * 0.068f;
            float dodgeCx = atkCx - atkR - dodgeR - 18.0f;
            float dodgeCy = h - dodgeR - 24.0f;
            mBoxPaint.setColor(mState.dodgeTimer > 0f ? Color.argb(235, 36, 82, 88) : Color.argb(220, 8, 11, 12));
            mBorderPaint.setColor(Color.rgb(165, 215, 210));
            canvas.drawCircle(dodgeCx, dodgeCy, dodgeR, mBoxPaint);
            canvas.drawCircle(dodgeCx, dodgeCy, dodgeR, mBorderPaint);
            mTextPaint.setTextSize(13.0f);
            String dTxt = mState.dodgeCooldown > 0f ? (((int) (mState.dodgeCooldown * 10f + 0.9f) / 10f) + "s") : "[DODGE]";
            canvas.drawText(dTxt, dodgeCx, dodgeCy + 4.5f, mTextPaint);

            float jumpR = Math.min(w, h) * 0.062f;
            float jumpCx = atkCx - jumpR * 0.35f;
            float jumpCy = atkCy - atkR - jumpR - 14.0f;
            mBoxPaint.setColor(mState.playerY > 0.02f ? Color.argb(235, 52, 78, 96) : Color.argb(220, 8, 11, 12));
            mBorderPaint.setColor(Color.rgb(185, 215, 235));
            canvas.drawCircle(jumpCx, jumpCy, jumpR, mBoxPaint);
            canvas.drawCircle(jumpCx, jumpCy, jumpR, mBorderPaint);
            mTextPaint.setTextSize(12.5f);
            canvas.drawText("[JUMP]", jumpCx, jumpCy + 4.5f, mTextPaint);

            // Virtual Joystick Ring
            if (mMovePointerId != -1) {
                mBorderPaint.setColor(Color.argb(145, 205, 225, 215));
                canvas.drawCircle(mJoyBaseX, mJoyBaseY, Math.min(w, h) * 0.11f, mBorderPaint);
                canvas.drawCircle(mJoyCurrX, mJoyCurrY, Math.min(w, h) * 0.035f, mBorderPaint);
            }

            if (mState.bannerTimer > 0f) {
                mTextPaint.setTextSize(14.0f);
                mTextPaint.setColor(Color.rgb(235, 232, 195));
                canvas.drawText(mState.statusBanner, w * 0.5f, hbY - 26.0f, mTextPaint);
            }
        }

        private void drawEquipmentMenuOverlay(Canvas canvas, int w, int h) {
            // Exact Dark Minimalist Monospace Equipment & Chainmail Interface (1000461485.jpg!)
            mTextPaint.setTextAlign(Paint.Align.LEFT);
            mTextPaint.setTextSize(14.0f);
            mTextPaint.setColor(Color.rgb(225, 230, 228));
            canvas.drawText(GameState.METAL_SHORT[mState.activeMetal] + " Mail " + GameState.SLOT_NAMES[mState.selectedSlot], 18f, 24f, mTextPaint);

            // Slot Tabs: Helm, Shoulders, Chest, Gloves, Legs, Boots
            float slotW = (w * 0.72f) / 6.0f;
            for (int i = 0; i < 6; i++) {
                float sx = 18f + i * slotW;
                mBoxPaint.setColor(i == mState.selectedSlot ? Color.rgb(32, 38, 28) : Color.rgb(10, 12, 14));
                canvas.drawRect(sx, 34f, sx + slotW - 6f, 64f, mBoxPaint);
                mBorderPaint.setColor(i == mState.selectedSlot ? Color.rgb(210, 205, 138) : Color.rgb(75, 82, 86));
                canvas.drawRect(sx, 34f, sx + slotW - 6f, 64f, mBorderPaint);
                mTextPaint.setTextAlign(Paint.Align.CENTER);
                mTextPaint.setColor(Color.rgb(235, 238, 236));
                canvas.drawText(GameState.SLOT_NAMES[i], sx + (slotW - 6f) * 0.5f, 54f, mTextPaint);
            }

            // Rune Row: ^ * z ~ > / x v o § +
            mTextPaint.setTextAlign(Paint.Align.LEFT);
            mTextPaint.setColor(Color.rgb(155, 165, 162));
            canvas.drawText("- tap a rune to inscribe into enchant slot", 18f, 82f, mTextPaint);
            float rW = (w * 0.66f) / 11.0f;
            for (int i = 0; i < 11; i++) {
                float rx = 18f + i * rW;
                mBoxPaint.setColor(Color.rgb(8, 10, 12));
                canvas.drawRect(rx, 90f, rx + rW - 4f, 124f, mBoxPaint);
                mBorderPaint.setColor(Color.rgb(65, 72, 76));
                canvas.drawRect(rx, 90f, rx + rW - 4f, 124f, mBorderPaint);
                mTextPaint.setTextAlign(Paint.Align.CENTER);
                mTextPaint.setColor(i % 2 == 0 ? Color.rgb(110, 225, 165) : Color.rgb(215, 145, 235));
                canvas.drawText(GameState.RUNE_GLYPHS[i], rx + (rW - 4f) * 0.5f, 112f, mTextPaint);
            }

            // Metal Selector Rows (Iron, Steel, Bronze, Silver, Gold / Moonsteel, Nightglass, Bloodiron, Ossite, Emberstone)
            float mW = (w * 0.72f) / 5.0f;
            for (int i = 0; i < 10; i++) {
                int row = i / 5;
                int col = i % 5;
                float mx = 18f + col * mW;
                float my = 136f + row * 34f;
                mBoxPaint.setColor(i == mState.activeMetal ? Color.rgb(28, 34, 26) : Color.rgb(8, 10, 12));
                canvas.drawRect(mx, my, mx + mW - 6f, my + 28f, mBoxPaint);
                float[] rgb = GameState.METAL_RGB[i];
                int mCol = Color.rgb((int) (rgb[0] * 255), (int) (rgb[1] * 255), (int) (rgb[2] * 255));
                mBorderPaint.setColor(i == mState.activeMetal ? mCol : Color.rgb(62, 68, 72));
                canvas.drawRect(mx, my, mx + mW - 6f, my + 28f, mBorderPaint);
                mTextPaint.setTextAlign(Paint.Align.CENTER);
                mTextPaint.setColor(mCol);
                canvas.drawText(GameState.METAL_NAMES[i], mx + (mW - 6f) * 0.5f, my + 19f, mTextPaint);
            }

            // Right Divider & Enchant Slots Panel
            float divX = w * 0.75f;
            mBorderPaint.setColor(Color.rgb(75, 82, 86));
            canvas.drawLine(divX, 34f, divX, h - 50f, mBorderPaint);

            mTextPaint.setTextAlign(Paint.Align.LEFT);
            mTextPaint.setColor(Color.rgb(185, 195, 192));
            canvas.drawText("Enchant slots", divX + 18f, 60f, mTextPaint);
            for (int e = 0; e < 2; e++) {
                float ex = divX + 18f + e * 64f;
                canvas.drawRect(ex, 72f, ex + 52f, 124f, mBorderPaint);
                int rIdx = (e == 0) ? mState.runeSlot1 : mState.runeSlot2;
                mTextPaint.setTextAlign(Paint.Align.CENTER);
                mTextPaint.setColor(rIdx >= 0 ? Color.rgb(145, 245, 205) : Color.rgb(115, 125, 122));
                canvas.drawText(rIdx >= 0 ? GameState.RUNE_GLYPHS[rIdx] : "+", ex + 26f, 104f, mTextPaint);
            }

            mTextPaint.setTextAlign(Paint.Align.LEFT);
            mTextPaint.setColor(Color.rgb(175, 185, 182));
            canvas.drawText("Metal: " + GameState.METAL_SHORT[mState.activeMetal], divX + 18f, 152f, mTextPaint);
            int rCount = (mState.runeSlot1 >= 0 ? 1 : 0) + (mState.runeSlot2 >= 0 ? 1 : 0);
            canvas.drawText("Runes: " + rCount + " / 2", divX + 18f, 174f, mTextPaint);
            canvas.drawText("Quest: " + mState.questKills + "/" + mState.questTarget + " Wardens", divX + 18f, 204f, mTextPaint);

            // Return to 3D World Button
            mBoxPaint.setColor(Color.rgb(22, 42, 32));
            canvas.drawRect(divX + 18f, h - 76f, w - 18f, h - 24f, mBoxPaint);
            mBorderPaint.setColor(Color.rgb(165, 225, 185));
            canvas.drawRect(divX + 18f, h - 76f, w - 18f, h - 24f, mBorderPaint);
            mTextPaint.setTextAlign(Paint.Align.CENTER);
            mTextPaint.setColor(Color.rgb(238, 245, 240));
            canvas.drawText("[ RETURN TO WORLD ]", (divX + w) * 0.5f, h - 44f, mTextPaint);

            mTextPaint.setTextAlign(Paint.Align.LEFT);
            mTextPaint.setColor(Color.rgb(145, 155, 152));
            canvas.drawText("drag center to turn 3D ASCII coif \u00b7 tap metal or rune to forge", 18f, h - 18f, mTextPaint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            int action = event.getActionMasked();
            int idx = event.getActionIndex();
            int pId = event.getPointerId(idx);
            float x = event.getX(idx);
            float y = event.getY(idx);
            float w = Math.max(1f, getWidth());
            float h = Math.max(1f, getHeight());

            if (mState.screenMode == 2) {
                if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                    if (x > w * 0.75f && y > h - 84f) {
                        mState.screenMode = 1;
                        return true;
                    }
                    if (y >= 34f && y <= 64f && x < w * 0.73f) {
                        int s = (int) ((x - 18f) / ((w * 0.72f) / 6.0f));
                        if (s >= 0 && s < 6) {
                            mState.selectedSlot = s;
                            mState.activeMetal = mState.slotMetal[s];
                        }
                        return true;
                    }
                    if (y >= 90f && y <= 124f && x < w * 0.68f) {
                        int r = (int) ((x - 18f) / ((w * 0.66f) / 11.0f));
                        if (r >= 0 && r < 11) {
                            if (mState.runeSlot1 == -1) mState.runeSlot1 = r;
                            else if (mState.runeSlot2 == -1) mState.runeSlot2 = r;
                            else { mState.runeSlot1 = r; mState.runeSlot2 = -1; }
                            mState.str += 2;
                        }
                        return true;
                    }
                    if (y >= 136f && y <= 204f && x < w * 0.73f) {
                        int col = (int) ((x - 18f) / ((w * 0.72f) / 5.0f));
                        int row = (y >= 170f) ? 1 : 0;
                        int m = row * 5 + Math.max(0, Math.min(4, col));
                        mState.activeMetal = m;
                        mState.slotMetal[mState.selectedSlot] = m;
                        return true;
                    }
                    mLastCamX = x;
                } else if (action == MotionEvent.ACTION_MOVE) {
                    mState.previewYaw += (x - mLastCamX) * 0.01f;
                    mLastCamX = x;
                }
                return true;
            }

            // World Mode Controls
            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                float pillW = Math.min(w * 0.16f, 158.0f);
                float pillH = 34.0f;
                float px = w - pillW - 16.0f;
                float y0 = 16.0f;

                if (x >= px && x <= px + pillW && y <= y0 + 4 * (pillH + 6f)) {
                    int btn = (int) ((y - y0) / (pillH + 6f));
                    if (btn == 0) {
                        mMovePointerId = -1;
                        mState.inputX = 0f;
                        mState.inputZ = 0f;
                        mState.screenMode = 2;
                    } else if (btn == 1) {
                        mState.zoomPreset = (mState.zoomPreset + 1) % 3;
                        mState.cameraZoom = (mState.zoomPreset == 0) ? 1.35f : (mState.zoomPreset == 1 ? 1.0f : 0.75f);
                    } else if (btn == 2) {
                        mState.mounted = !mState.mounted;
                    } else if (btn == 3) {
                        mState.debugSolidMode = !mState.debugSolidMode;
                        mState.statusBanner = mState.debugSolidMode ? "Visual Debug Mode: Solid 3D Geometry" : "Visual Mode: Real-Time 3D ASCII";
                        mState.bannerTimer = 2.5f;
                    }
                    return true;
                }

                // Tap Senje Portrait Box -> Open 3D Equipment & Chainmail Forge
                if (x < w * 0.38f && y < h * 0.24f) {
                    mMovePointerId = -1;
                    mState.inputX = 0f;
                    mState.inputZ = 0f;
                    mState.screenMode = 2;
                    return true;
                }

                // Bottom Hotbar Slot 1 -> Drink Potion
                float hbW = Math.min(w * 0.54f, 520.0f);
                float hbX = (w - hbW) * 0.5f;
                float hbY = h - 48.0f;
                if (y >= hbY && x >= hbX && x <= hbX + hbW) {
                    int s = (int) ((x - hbX) / (hbW / 10.0f));
                    if (s == 0 && mState.potions > 0) {
                        mState.potions--;
                        mState.hp = Math.min(mState.maxHp, mState.hp + 450);
                        mState.mp = Math.min(mState.maxMp, mState.mp + 60);
                        mState.statusBanner = "Restored +450 HP, +60 MP";
                        mState.bannerTimer = 2.0f;
                    }
                    return true;
                }

                // Bottom-Right [ATK] & [DODGE]
                float atkR = Math.min(w, h) * 0.085f;
                float atkCx = w - atkR - 24.0f;
                float atkCy = h - atkR - 24.0f;
                if ((x - atkCx) * (x - atkCx) + (y - atkCy) * (y - atkCy) <= (atkR * 1.25f) * (atkR * 1.25f)) {
                    mState.triggerSlash();
                    return true;
                }

                float dodgeR = Math.min(w, h) * 0.068f;
                float dodgeCx = atkCx - atkR - dodgeR - 18.0f;
                float dodgeCy = h - dodgeR - 24.0f;
                if ((x - dodgeCx) * (x - dodgeCx) + (y - dodgeCy) * (y - dodgeCy) <= (dodgeR * 1.25f) * (dodgeR * 1.25f)) {
                    mState.triggerDodge();
                    return true;
                }

                float jumpR = Math.min(w, h) * 0.062f;
                float jumpCx = atkCx - jumpR * 0.35f;
                float jumpCy = atkCy - atkR - jumpR - 14.0f;
                if ((x - jumpCx) * (x - jumpCx) + (y - jumpCy) * (y - jumpCy) <= (jumpR * 1.25f) * (jumpR * 1.25f)) {
                    mState.triggerJump();
                    return true;
                }

                // Left Half -> Virtual Movement Joystick; Right Half -> Cursor-View & Camera Orbit
                if (x < w * 0.48f) {
                    mMovePointerId = pId;
                    mJoyBaseX = mJoyCurrX = x;
                    mJoyBaseY = mJoyCurrY = y;
                    mState.inputX = 0f;
                    mState.inputZ = 0f;
                } else {
                    mCamPointerId = pId;
                    mLastCamX = x;
                    mState.cursorX = x / w;
                    mState.cursorY = y / h;
                }
            } else if (action == MotionEvent.ACTION_MOVE) {
                int count = event.getPointerCount();
                for (int i = 0; i < count; i++) {
                    int id = event.getPointerId(i);
                    float px = event.getX(i);
                    float py = event.getY(i);
                    if (id == mMovePointerId) {
                        mJoyCurrX = px;
                        mJoyCurrY = py;
                        float dx = px - mJoyBaseX;
                        float dy = py - mJoyBaseY;
                        float maxR = Math.min(w, h) * 0.12f;
                        float len = (float) Math.sqrt(dx * dx + dy * dy);
                        if (len > 4f) {
                            float mag = Math.min(1f, len / maxR);
                            mState.inputX = (dx / len) * mag;
                            mState.inputZ = (dy / len) * mag;
                        } else {
                            mState.inputX = 0f;
                            mState.inputZ = 0f;
                        }
                    } else if (id == mCamPointerId) {
                        mState.camYaw -= (px - mLastCamX) * 0.0045f;
                        mLastCamX = px;
                        mState.cursorX = px / w;
                        mState.cursorY = py / h;
                    }
                }
            } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP || action == MotionEvent.ACTION_CANCEL) {
                if (pId == mMovePointerId) {
                    mMovePointerId = -1;
                    mState.inputX = 0f;
                    mState.inputZ = 0f;
                } else if (pId == mCamPointerId) {
                    mCamPointerId = -1;
                }
            }
            return true;
        }
    }
}
