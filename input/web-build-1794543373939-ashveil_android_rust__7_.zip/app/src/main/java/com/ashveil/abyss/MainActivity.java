package com.ashveil.abyss;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
    private static boolean sRustLoaded = false;
    static {
        try {
            System.loadLibrary("ashveil_ascii_3d");
            sRustLoaded = true;
        } catch (Throwable ignored) {
            sRustLoaded = false;
        }
    }

    public static native long nativeInit(long seed);
    public static native int nativeStep(long handle, float dt);
    public static native void nativeTouch(long handle, int action, long pointerId, float normX, float normY);
    public static native void nativeDestroy(long handle);

    private AshveilView mView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );
        mView = new AshveilView(this);
        setContentView(mView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mView != null) mView.resumeGame();
    }

    @Override
    protected void onPause() {
        if (mView != null) mView.pauseGame();
        super.onPause();
    }

    private static final class AshveilView extends SurfaceView implements Runnable, SurfaceHolder.Callback {
        private static final String DENSE_RAMP = " .,:;-=+*oahkbdpqwmZOQ0N$%&8B#MW@";
        private static final String CLIFF_CHARS = "@WM#B8&%$N0QOZmwqpdbkhao*+=-:;,.";
        private static final String[] GROUND_ASCII = new String[]{
                "0Q8B", "QQ0O", "80aa", "qQ80", "b0Q8", "O08Q"
        };

        // Handcrafted ASCII House / Cottage (warm hearth + shingled roof)
        private static final String[] HOUSE_ART = new String[]{
                "      .::::::::::.      ",
                "    .:////////////:.    ",
                "  .:////////////////:.  ",
                " .====================. ",
                " |  [##]        [##]  | ",
                " |  |..|  .--.  |..|  | ",
                " |______| |**| |______| ",
                " |######| |**| |######| "
        };

        private Thread mThread;
        private volatile boolean mRunning = false;
        private long mRustHandle = 0;

        // Reusable Paints (zero per-frame allocations)
        private final Paint mAsciiPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mGrassPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mShadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mUiPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mUiSubPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mPanelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint mBitmapPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
        private final Paint mGlowPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
        private final Paint mChunkBgPaint = new Paint();
        private final Paint mChunkTxtPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final char[] mSingleChar = new char[1];
        private final RectF mTmpRect = new RectF();
        private final Rect mSrcRect = new Rect();

        // Pre-baked World & Glow Caches (64 chunks = zero thrashing in landscape!)
        private static final int MEADOW_TILE_PX = 1024;
        private static final float CHUNK_WORLD_UNITS = 4.0f;
        private static final int CHUNK_PX = 256;
        private static final int CHUNK_CACHE_CAP = 64;

        private Bitmap mMeadowTileBitmap = null;
        private Bitmap mFogBitmap = null;
        private Bitmap mAmberGlowBitmap = null;
        private Bitmap mCyanGlowBitmap = null;
        private Bitmap mVignetteBitmap = null;

        private final int[] mChunkKeys = new int[CHUNK_CACHE_CAP];
        private final Bitmap[] mChunkBitmaps = new Bitmap[CHUNK_CACHE_CAP];
        private final Canvas[] mChunkCanvases = new Canvas[CHUNK_CACHE_CAP];
        private final int[] mChunkAge = new int[CHUNK_CACHE_CAP];
        private int mChunkTick = 1;

        // Batched dynamic wind-swaying grass tips
        private static final int WIND_BLADES_PER_LAYER = 200;
        private final float[] mWindPtsDark = new float[WIND_BLADES_PER_LAYER * 4];
        private final float[] mWindPtsBright = new float[WIND_BLADES_PER_LAYER * 4];

        // World Houses & Glowing Lanterns/Runestones
        private static final float[] HOUSE_X = new float[]{-4.2f, 6.8f, -10.5f, 12.2f};
        private static final float[] HOUSE_Y = new float[]{2.5f, -1.8f, -3.2f, 5.4f};
        private static final float[] GLOW_X = new float[]{-4.2f, 6.8f, -10.5f, 12.2f, 0.8f, -2.5f, 4.4f};
        private static final float[] GLOW_Y = new float[]{3.3f, -1.0f, -2.4f, 6.2f, -3.6f, 5.2f, 3.8f};
        private static final boolean[] GLOW_IS_CYAN = new boolean[]{false, false, false, false, true, true, true};

        // Screen mode: 0 = Start Menu, 1 = Gameplay, 2 = Character / Inventory / Forge Modal
        private int mScreenMode = 0;
        private boolean mMounted = false;
        private boolean mAttackButtonOnly = true;
        private int mZoomPreset = 1;
        private float mCameraZoom = 1.15f;
        private int mWindPreset = 1;

        // World & Camera State
        private float mPlayerX = 0.0f;
        private float mPlayerY = 0.0f;
        private float mCamX = 0.0f;
        private float mCamY = 0.0f;
        private float mVelX = 0.0f;
        private float mVelY = 0.0f;
        private float mFacingX = 0.85f;
        private float mFacingY = 0.52f;
        private float mGaitPhase = 0.0f;
        private float mTimeSec = 0.0f;
        private float mSlashTimer = 0.0f;
        private float mSlashCooldown = 0.0f;
        private float mDodgeTimer = 0.0f;
        private float mDodgeCooldown = 0.0f;
        private float mDodgeDirX = 1.0f;
        private float mDodgeDirY = 0.0f;
        private float mPlayerHurtFlash = 0.0f;

        private static final int MAX_AFTERIMAGES = 5;
        private final float[] mGhostX = new float[MAX_AFTERIMAGES];
        private final float[] mGhostY = new float[MAX_AFTERIMAGES];
        private final float[] mGhostLife = new float[MAX_AFTERIMAGES];
        private float mGhostSpawnAccum = 0.0f;

        private float mCursorX = 0.54f;
        private float mCursorY = 0.52f;

        // Touch Controls
        private int mMovePointerId = -1;
        private float mJoyBaseX = 0.0f;
        private float mJoyBaseY = 0.0f;
        private float mJoyCurrX = 0.0f;
        private float mJoyCurrY = 0.0f;
        private float mInputX = 0.0f;
        private float mInputY = 0.0f;

        // Offline Single-Player RPG State
        private int mLevel = 13;
        private int mXp = 420;
        private int mXpNext = 900;
        private int mHp = 1612;
        private int mMaxHp = 1612;
        private int mMp = 134;
        private int mMaxMp = 134;
        private int mGold = 5194;
        private int mStatPoints = 3;
        private int mVit = 18;
        private int mStr = 21;
        private int mDex = 16;
        private int mForgeLevel = 2;
        private int mForgeSlot = 0; // 0=Helm, 1=Shoulders, 2=Chest, 3=Gloves, 4=Legs, 5=Boots
        private int mForgeMetal = 0; // 0=Iron..9=Emberstone
        private int mRuneSlot1 = -1;
        private int mRuneSlot2 = -1;
        private float mCoifRot = 0.0f;
        private String mEquippedWeapon = "Pale-Moon Greatsword";
        private String mEquippedArmor = "Silver-Weave Mail";
        private final String[] mInventory = new String[16];
        private int mInvCount = 2;

        // Toast Banner
        private String mStatusBanner = "Move with left thumb • [ATK] Slash • [DODGE] Dash";
        private float mBannerTimer = 4.0f;

        // Verlet Hair / Mane / Tail / Cloak Physics
        private static final int TAIL_STRANDS = 12;
        private static final int TAIL_NODES = 10;
        private final float[][] mTailX = new float[TAIL_STRANDS][TAIL_NODES];
        private final float[][] mTailY = new float[TAIL_STRANDS][TAIL_NODES];
        private final float[][] mTailPrevX = new float[TAIL_STRANDS][TAIL_NODES];
        private final float[][] mTailPrevY = new float[TAIL_STRANDS][TAIL_NODES];

        private static final int MANE_STRANDS = 14;
        private static final int MANE_NODES = 7;
        private final float[][] mManeX = new float[MANE_STRANDS][MANE_NODES];
        private final float[][] mManeY = new float[MANE_STRANDS][MANE_NODES];
        private final float[][] mManePrevX = new float[MANE_STRANDS][MANE_NODES];
        private final float[][] mManePrevY = new float[MANE_STRANDS][MANE_NODES];

        private static final int HAIR_STRANDS = 10;
        private static final int HAIR_NODES = 9;
        private final float[][] mHairX = new float[HAIR_STRANDS][HAIR_NODES];
        private final float[][] mHairY = new float[HAIR_STRANDS][HAIR_NODES];
        private final float[][] mHairPrevX = new float[HAIR_STRANDS][HAIR_NODES];
        private final float[][] mHairPrevY = new float[HAIR_STRANDS][HAIR_NODES];

        // High-Resolution ASCII Entity Buffers
        private static final int HORSE_BUF_W = 56;
        private static final int HORSE_BUF_H = 44;
        private final char[] mHorseGlyphBuf = new char[HORSE_BUF_W * HORSE_BUF_H];
        private final float[] mHorseLumBuf = new float[HORSE_BUF_W * HORSE_BUF_H];
        private final int[] mHorseColorBuf = new int[HORSE_BUF_W * HORSE_BUF_H];

        private static final int FOOT_BUF_W = 52;
        private static final int FOOT_BUF_H = 58;
        private final char[] mFootGlyphBuf = new char[FOOT_BUF_W * FOOT_BUF_H];
        private final float[] mFootLumBuf = new float[FOOT_BUF_W * FOOT_BUF_H];
        private final int[] mFootColorBuf = new int[FOOT_BUF_W * FOOT_BUF_H];

        private static final int ENEMY_BUF_W = 38;
        private static final int ENEMY_BUF_H = 44;
        private final char[] mEnemyGlyphBuf = new char[ENEMY_BUF_W * ENEMY_BUF_H];
        private final float[] mEnemyLumBuf = new float[ENEMY_BUF_W * ENEMY_BUF_H];
        private final int[] mEnemyColorBuf = new int[ENEMY_BUF_W * ENEMY_BUF_H];

        // Humanoid Enemies (stay at guard post until player approaches!)
        private static final int NUM_ENEMIES = 10;
        private final float[] mEnemyX = new float[NUM_ENEMIES];
        private final float[] mEnemyY = new float[NUM_ENEMIES];
        private final float[] mEnemyHomeX = new float[NUM_ENEMIES];
        private final float[] mEnemyHomeY = new float[NUM_ENEMIES];
        private final float[] mEnemyFacingX = new float[NUM_ENEMIES];
        private final float[] mEnemyFacingY = new float[NUM_ENEMIES];
        private final float[] mEnemyGait = new float[NUM_ENEMIES];
        private final float[] mEnemyAtkWindup = new float[NUM_ENEMIES];
        private final float[] mEnemyAtkCooldown = new float[NUM_ENEMIES];
        private final boolean[] mEnemyAggro = new boolean[NUM_ENEMIES];
        private final int[] mEnemyHp = new int[NUM_ENEMIES];
        private final int[] mEnemyMaxHp = new int[NUM_ENEMIES];
        private final float[] mEnemyHurt = new float[NUM_ENEMIES];
        private final int[] mEnemyKind = new int[NUM_ENEMIES];

        private static final int MAX_LOOT = 16;
        private final float[] mLootX = new float[MAX_LOOT];
        private final float[] mLootY = new float[MAX_LOOT];
        private final boolean[] mLootActive = new boolean[MAX_LOOT];
        private final int[] mLootRarity = new int[MAX_LOOT];

        // Ash / Spark / Firefly Particles
        private static final int MAX_PARTICLES = 64;
        private final float[] mPartX = new float[MAX_PARTICLES];
        private final float[] mPartY = new float[MAX_PARTICLES];
        private final float[] mPartVx = new float[MAX_PARTICLES];
        private final float[] mPartVy = new float[MAX_PARTICLES];
        private final float[] mPartLife = new float[MAX_PARTICLES];
        private final int[] mPartColor = new int[MAX_PARTICLES];
        private int mPartCursor = 0;

        // Crafting Materials & Potions
        private int mHerbMoon = 3;
        private int mHerbCinder = 2;
        private int mHerbMoss = 2;
        private int mCinderShards = 2;
        private int mPotions = 2;

        // Harvestable Flora Nodes
        private static final int NUM_FLORA = 14;
        private final float[] mFloraX = new float[NUM_FLORA];
        private final float[] mFloraY = new float[NUM_FLORA];
        private final int[] mFloraKind = new int[NUM_FLORA]; // 0=Moonpetal, 1=Cinderbloom, 2=Ashmoss
        private final float[] mFloraRegrow = new float[NUM_FLORA];

        // Ambient Fauna (Deer, Rabbits, Birds, River Koi)
        private static final int NUM_FAUNA = 12;
        private final float[] mFaunaX = new float[NUM_FAUNA];
        private final float[] mFaunaY = new float[NUM_FAUNA];
        private final float[] mFaunaVx = new float[NUM_FAUNA];
        private final float[] mFaunaVy = new float[NUM_FAUNA];
        private final int[] mFaunaKind = new int[NUM_FAUNA]; // 0=Deer, 1=Rabbit, 2=Bird, 3=RiverKoi
        private final float[] mFaunaPhase = new float[NUM_FAUNA];

        // Floating Damage Popups
        private static final int MAX_POPUPS = 12;
        private final float[] mPopX = new float[MAX_POPUPS];
        private final float[] mPopY = new float[MAX_POPUPS];
        private final float[] mPopLife = new float[MAX_POPUPS];
        private final String[] mPopText = new String[MAX_POPUPS];
        private final int[] mPopColor = new int[MAX_POPUPS];
        private int mPopCursor = 0;

        public AshveilView(Context context) {
            super(context);
            getHolder().addCallback(this);
            setFocusable(true);
            setKeepScreenOn(true);

            mAsciiPaint.setTypeface(Typeface.MONOSPACE);
            mAsciiPaint.setFakeBoldText(true);
            mGrassPaint.setStyle(Paint.Style.STROKE);
            mGrassPaint.setStrokeCap(Paint.Cap.ROUND);
            mShadowPaint.setStyle(Paint.Style.FILL);
            mUiPaint.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
            mUiSubPaint.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL));
            mPanelPaint.setStyle(Paint.Style.FILL);
            mBorderPaint.setStyle(Paint.Style.STROKE);
            mBorderPaint.setStrokeWidth(2.2f);
            mGlowPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));
            mChunkBgPaint.setStyle(Paint.Style.FILL);
            mChunkTxtPaint.setTypeface(Typeface.MONOSPACE);
            mChunkTxtPaint.setFakeBoldText(true);

            mInventory[0] = mEquippedWeapon;
            mInventory[1] = mEquippedArmor;

            for (int i = 0; i < CHUNK_CACHE_CAP; i++) {
                mChunkKeys[i] = Integer.MIN_VALUE;
            }
            initWorld();
        }

        private void initWorld() {
            for (int s = 0; s < TAIL_STRANDS; s++) {
                for (int n = 0; n < TAIL_NODES; n++) {
                    mTailX[s][n] = mTailPrevX[s][n] = mPlayerX - 1.1f - n * 0.14f;
                    mTailY[s][n] = mTailPrevY[s][n] = mPlayerY + n * 0.12f;
                }
            }
            for (int s = 0; s < MANE_STRANDS; s++) {
                for (int n = 0; n < MANE_NODES; n++) {
                    mManeX[s][n] = mManePrevX[s][n] = mPlayerX + 0.4f;
                    mManeY[s][n] = mManePrevY[s][n] = mPlayerY - 0.6f + n * 0.08f;
                }
            }
            for (int s = 0; s < HAIR_STRANDS; s++) {
                for (int n = 0; n < HAIR_NODES; n++) {
                    mHairX[s][n] = mHairPrevX[s][n] = mPlayerX - 0.1f - n * 0.10f;
                    mHairY[s][n] = mHairPrevY[s][n] = mPlayerY - 1.25f + n * 0.08f;
                }
            }
            for (int i = 0; i < NUM_ENEMIES; i++) {
                spawnEnemy(i, i < 3);
            }
            for (int i = 0; i < NUM_FLORA; i++) {
                float ang = i * 2.15f + 0.3f;
                float dist = 2.8f + (i % 5) * 2.2f;
                mFloraX[i] = (float) Math.cos(ang) * dist;
                mFloraY[i] = (float) Math.sin(ang) * dist;
                mFloraKind[i] = i % 3;
                mFloraRegrow[i] = 0.0f;
            }
            for (int i = 0; i < NUM_FAUNA; i++) {
                mFaunaKind[i] = i % 4;
                if (mFaunaKind[i] == 3) {
                    mFaunaX[i] = (i - 6) * 2.4f;
                    mFaunaY[i] = riverCenterY(mFaunaX[i]);
                } else {
                    float ang = i * 1.7f + 0.9f;
                    float dist = 3.2f + (i % 4) * 2.5f;
                    mFaunaX[i] = (float) Math.cos(ang) * dist;
                    mFaunaY[i] = (float) Math.sin(ang) * dist;
                }
                mFaunaVx[i] = (i % 2 == 0) ? 0.6f : -0.6f;
                mFaunaVy[i] = 0.2f;
                mFaunaPhase[i] = i * 1.1f;
            }
        }

        private void ensureStaticCaches() {
            if (mMeadowTileBitmap == null) {
                mMeadowTileBitmap = Bitmap.createBitmap(MEADOW_TILE_PX, MEADOW_TILE_PX, Bitmap.Config.ARGB_8888);
                Canvas mc = new Canvas(mMeadowTileBitmap);
                mc.drawColor(Color.rgb(7, 11, 10));

                Paint pPatch = new Paint(Paint.ANTI_ALIAS_FLAG);
                int seed = 1337420;
                for (int i = 0; i < 65; i++) {
                    seed = seed * 1664525 + 1013904223;
                    float px = ((seed >>> 16) & 1023);
                    seed = seed * 1664525 + 1013904223;
                    float py = ((seed >>> 16) & 1023);
                    float rad = 45.0f + ((seed >>> 8) & 63);
                    boolean dark = (i % 2 == 0);
                    int cIn = dark ? Color.argb(95, 4, 8, 7) : Color.argb(65, 18, 44, 24);
                    pPatch.setShader(new RadialGradient(px, py, rad, cIn, Color.argb(0, 0, 0, 0), Shader.TileMode.CLAMP));
                    mc.drawCircle(px, py, rad, pPatch);
                }
                pPatch.setShader(null);

                Paint pText = new Paint(Paint.ANTI_ALIAS_FLAG);
                pText.setTypeface(Typeface.MONOSPACE);
                pText.setFakeBoldText(true);
                pText.setTextSize(13.0f);
                for (int y = 14; y < MEADOW_TILE_PX; y += 22) {
                    for (int x = 6; x < MEADOW_TILE_PX; x += 22) {
                        int h = Math.abs((x * 73856093) ^ (y * 19349663));
                        if ((h % 5) < 3) {
                            String gTxt = GROUND_ASCII[h % GROUND_ASCII.length];
                            pText.setColor((h % 3 == 0) ? Color.rgb(74, 92, 110) : Color.rgb(46, 62, 76));
                            mc.drawText(gTxt, x + (h % 7) - 3, y + ((h >> 3) % 7) - 3, pText);
                        }
                    }
                }

                Paint pBlade = new Paint(Paint.ANTI_ALIAS_FLAG);
                pBlade.setStyle(Paint.Style.STROKE);
                pBlade.setStrokeCap(Paint.Cap.ROUND);
                pBlade.setStrokeWidth(1.25f);

                int[] colors = new int[]{
                        Color.rgb(10, 26, 14),
                        Color.rgb(18, 48, 22),
                        Color.rgb(32, 84, 38),
                        Color.rgb(54, 124, 56),
                        Color.rgb(86, 158, 82),
                        Color.rgb(116, 188, 102)
                };

                int totalBlades = 45000;
                int perBucket = totalBlades / colors.length;
                float[] pts = new float[perBucket * 4];
                for (int cIdx = 0; cIdx < colors.length; cIdx++) {
                    pBlade.setColor(colors[cIdx]);
                    for (int i = 0; i < perBucket; i += 3) {
                        seed = seed * 1664525 + 1013904223;
                        float tx = ((seed >>> 16) & 1023);
                        seed = seed * 1664525 + 1013904223;
                        float ty = ((seed >>> 16) & 1023);
                        for (int b = 0; b < 3 && (i + b) < perBucket; b++) {
                            seed = seed * 1664525 + 1013904223;
                            float bx = tx + (b - 1) * 1.8f;
                            float by = ty + ((b == 1) ? -0.8f : 0.4f);
                            float lean = (b - 1) * 1.35f + (((seed >>> 20) & 7) - 3) * 0.35f + 0.9f;
                            float len = 4.8f + ((seed >>> 12) & 7) * 0.78f;
                            int o = (i + b) * 4;
                            pts[o] = bx;
                            pts[o + 1] = by;
                            pts[o + 2] = bx + lean;
                            pts[o + 3] = by - len;
                        }
                    }
                    mc.drawLines(pts, pBlade);
                }

                // 850+ tiny multi-color wildflowers (ivory daisies, lavender bluebells, golden buttercups, rose buds) + pebbles
                int[] flowerColors = new int[]{
                        Color.rgb(186, 152, 232), // moonlit lavender (ansenjeo)
                        Color.rgb(246, 248, 235), // ivory blossom
                        Color.rgb(164, 132, 214), // violet cluster
                        Color.rgb(228, 214, 248), // pale lilac
                        Color.rgb(244, 220, 140)  // golden dot
                };
                String[] flowerGlyphs = new String[]{"*", "o", "+", ".", "*"};
                pText.setTextSize(9.0f);
                for (int i = 0; i < 860; i++) {
                    seed = seed * 1664525 + 1013904223;
                    float fx = ((seed >>> 16) & 1023);
                    seed = seed * 1664525 + 1013904223;
                    float fy = ((seed >>> 16) & 1023);
                    // Tiny dark stem/shadow under flower so it pops cleanly
                    pText.setColor(Color.rgb(8, 16, 10));
                    mc.drawText(".", fx + 0.8f, fy + 1.4f, pText);
                    pText.setColor(flowerColors[i % flowerColors.length]);
                    mc.drawText(flowerGlyphs[i % flowerGlyphs.length], fx, fy, pText);
                }
                // Subtle mossy pebbles & clover dots
                pText.setTextSize(8.0f);
                for (int i = 0; i < 260; i++) {
                    seed = seed * 1664525 + 1013904223;
                    float px = ((seed >>> 16) & 1023);
                    seed = seed * 1664525 + 1013904223;
                    float py = ((seed >>> 16) & 1023);
                    pText.setColor(Color.rgb(74, 86, 92));
                    mc.drawText((i % 2 == 0) ? "," : ":", px, py, pText);
                }
            }

            if (mFogBitmap == null) {
                mFogBitmap = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888);
                Canvas fc = new Canvas(mFogBitmap);
                Paint fp = new Paint(Paint.ANTI_ALIAS_FLAG);
                fp.setShader(new RadialGradient(
                        128f, 128f, 128f,
                        Color.argb(62, 205, 222, 228),
                        Color.argb(0, 205, 222, 228),
                        Shader.TileMode.CLAMP
                ));
                fc.drawCircle(128f, 128f, 128f, fp);
            }

            if (mAmberGlowBitmap == null) {
                mAmberGlowBitmap = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888);
                Canvas ac = new Canvas(mAmberGlowBitmap);
                Paint ap = new Paint(Paint.ANTI_ALIAS_FLAG);
                ap.setShader(new RadialGradient(
                        128f, 128f, 128f,
                        new int[]{Color.argb(150, 255, 195, 90), Color.argb(60, 235, 130, 45), Color.argb(0, 0, 0, 0)},
                        new float[]{0.0f, 0.45f, 1.0f},
                        Shader.TileMode.CLAMP
                ));
                ac.drawCircle(128f, 128f, 128f, ap);
            }

            if (mCyanGlowBitmap == null) {
                mCyanGlowBitmap = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888);
                Canvas cc = new Canvas(mCyanGlowBitmap);
                Paint cp = new Paint(Paint.ANTI_ALIAS_FLAG);
                cp.setShader(new RadialGradient(
                        128f, 128f, 128f,
                        new int[]{Color.argb(140, 120, 245, 220), Color.argb(55, 60, 190, 175), Color.argb(0, 0, 0, 0)},
                        new float[]{0.0f, 0.45f, 1.0f},
                        Shader.TileMode.CLAMP
                ));
                cc.drawCircle(128f, 128f, 128f, cp);
            }

            if (mVignetteBitmap == null) {
                mVignetteBitmap = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888);
                Canvas vc = new Canvas(mVignetteBitmap);
                Paint vp = new Paint(Paint.ANTI_ALIAS_FLAG);
                vp.setShader(new RadialGradient(
                        128f, 128f, 168f,
                        new int[]{Color.argb(0, 0, 0, 0), Color.argb(30, 3, 6, 6), Color.argb(135, 2, 5, 5)},
                        new float[]{0.50f, 0.80f, 1.0f},
                        Shader.TileMode.CLAMP
                ));
                vc.drawRect(0, 0, 256, 256, vp);
            }
        }

        private float riverCenterY(float wx) {
            return -5.8f + (float) Math.sin(wx * 0.16f) * 2.1f;
        }

        private float cliffDensity(float wx, float wy) {
            if (wx * wx + wy * wy < 14.0f) return 0.0f;
            float n = (float) (Math.sin(wx * 0.24f + 0.7f) * Math.cos(wy * 0.21f - 0.4f)
                    + 0.45f * Math.sin(wx * 0.52f - wy * 0.37f));
            return n;
        }

        private boolean isCliff(float wx, float wy) {
            if (cliffDensity(wx, wy) > 0.68f) return true;
            for (int h = 0; h < HOUSE_X.length; h++) {
                if (Math.abs(wx - HOUSE_X[h]) < 1.55f && Math.abs(wy - HOUSE_Y[h]) < 1.05f) {
                    return true;
                }
            }
            return false;
        }

        private void spawnEnemy(int i, boolean close) {
            float ang = i * 1.15f + 0.5f;
            float dist = close ? (4.8f + i * 1.6f) : (7.8f + (i % 5) * 2.4f);
            float ex = mPlayerX + (float) Math.cos(ang) * dist;
            float ey = mPlayerY + (float) Math.sin(ang) * dist;
            if (isCliff(ex, ey)) {
                ex = mPlayerX + 4.2f;
                ey = mPlayerY + 3.2f;
            }
            mEnemyX[i] = ex;
            mEnemyY[i] = ey;
            mEnemyHomeX[i] = ex;
            mEnemyHomeY[i] = ey;
            mEnemyFacingX[i] = -1.0f;
            mEnemyFacingY[i] = 0.0f;
            mEnemyGait[i] = i * 0.7f;
            mEnemyAtkWindup[i] = 0.0f;
            mEnemyAtkCooldown[i] = 0.6f;
            mEnemyAggro[i] = false;
            mEnemyKind[i] = i % 4;
            mEnemyMaxHp[i] = 95 + mLevel * 14 + (i % 3) * 35;
            mEnemyHp[i] = mEnemyMaxHp[i];
            mEnemyHurt[i] = 0.0f;
        }

        private void spawnParticles(float wx, float wy, int count, int color) {
            for (int k = 0; k < count; k++) {
                int idx = mPartCursor;
                mPartCursor = (mPartCursor + 1) % MAX_PARTICLES;
                float ang = (float) ((k * 2.399f) + mTimeSec * 3.7f);
                float spd = 1.4f + (k % 4) * 0.85f;
                mPartX[idx] = wx;
                mPartY[idx] = wy;
                mPartVx[idx] = (float) Math.cos(ang) * spd;
                mPartVy[idx] = (float) Math.sin(ang) * spd - 0.6f;
                mPartLife[idx] = 0.42f + (k % 3) * 0.10f;
                mPartColor[idx] = color;
            }
        }

        private void spawnPopup(float wx, float wy, String text, int color) {
            int idx = mPopCursor;
            mPopCursor = (mPopCursor + 1) % MAX_POPUPS;
            mPopX[idx] = wx;
            mPopY[idx] = wy;
            mPopLife[idx] = 0.85f;
            mPopText[idx] = text;
            mPopColor[idx] = color;
        }

        @Override
        public void surfaceCreated(SurfaceHolder holder) {
            if (sRustLoaded && mRustHandle == 0) {
                try {
                    mRustHandle = nativeInit(0xA547E11L);
                } catch (Throwable ignored) {
                    mRustHandle = 0;
                }
            }
            resumeGame();
        }

        @Override
        public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        }

        @Override
        public void surfaceDestroyed(SurfaceHolder holder) {
            pauseGame();
            if (sRustLoaded && mRustHandle != 0) {
                try {
                    nativeDestroy(mRustHandle);
                } catch (Throwable ignored) {
                }
                mRustHandle = 0;
            }
        }

        public void resumeGame() {
            if (mRunning) return;
            mRunning = true;
            mThread = new Thread(this, "AshveilRenderLoop");
            mThread.setPriority(Thread.MAX_PRIORITY);
            mThread.start();
        }

        public void pauseGame() {
            mRunning = false;
            if (mThread != null) {
                try {
                    mThread.join(400);
                } catch (InterruptedException ignored) {
                }
                mThread = null;
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            int action = event.getActionMasked();
            int idx = event.getActionIndex();
            int pointerId = event.getPointerId(idx);
            float x = event.getX(idx);
            float y = event.getY(idx);
            float w = Math.max(1.0f, getWidth());
            float h = Math.max(1.0f, getHeight());

            if (sRustLoaded && mRustHandle != 0) {
                try {
                    nativeTouch(mRustHandle, action, pointerId, x / w, y / h);
                } catch (Throwable ignored) {
                }
            }

            if (mScreenMode == 0) {
                if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                    handleStartMenuTap(x, y, w, h);
                }
                return true;
            }

            if (mScreenMode == 2) {
                if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                    handleModalTap(x, y, w, h);
                }
                return true;
            }

            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                float boxH = Math.min(h * 0.14f, 156.0f);
                float pillW = Math.min(w * 0.18f, 172.0f);
                float pillH = Math.max(36.0f, boxH * 0.34f);
                float px = w - pillW - 18.0f;
                float y0 = 18.0f;

                if (x >= px && x <= px + pillW) {
                    if (y >= y0 && y <= y0 + pillH) {
                        mMovePointerId = -1;
                        mInputX = 0.0f;
                        mInputY = 0.0f;
                        mScreenMode = 0;
                        return true;
                    }
                    float py2 = y0 + pillH + 8.0f;
                    if (y >= py2 && y <= py2 + pillH) {
                        mZoomPreset = (mZoomPreset + 1) % 3;
                        mCameraZoom = (mZoomPreset == 0) ? 1.55f : (mZoomPreset == 1 ? 1.15f : 0.78f);
                        showBanner(mZoomPreset == 0 ? "Camera: Close-up" : (mZoomPreset == 1 ? "Camera: Meadow" : "Camera: Wide"));
                        return true;
                    }
                    float py3 = py2 + pillH + 8.0f;
                    if (y >= py3 && y <= py3 + pillH) {
                        mMounted = !mMounted;
                        spawnParticles(mPlayerX, mPlayerY, 14, Color.rgb(220, 235, 228));
                        showBanner(mMounted ? "Mounted White Steed" : "Dismounted (Foot Knight)");
                        return true;
                    }
                }

                if (x < w * 0.34f && y < h * 0.18f) {
                    mMovePointerId = -1;
                    mInputX = 0.0f;
                    mInputY = 0.0f;
                    mScreenMode = 2;
                    return true;
                }

                // Bottom Hotbar Slot 1 tap -> drink Healing Draught
                float hbW = Math.min(w * 0.46f, 440.0f);
                float hbX = (w - hbW) * 0.5f;
                float hbY = h - 54.0f;
                if (y >= hbY - 6.0f && y <= hbY + 38.0f && x >= hbX && x <= hbX + hbW) {
                    float slotW = hbW / 10.0f;
                    int slotIdx = (int) ((x - hbX) / slotW);
                    if (slotIdx == 0) {
                        if (mPotions > 0 && mHp < mMaxHp) {
                            mPotions--;
                            mHp = Math.min(mMaxHp, mHp + 450);
                            mMp = Math.min(mMaxMp, mMp + 60);
                            spawnParticles(mPlayerX, mPlayerY - 0.2f, 12, Color.rgb(145, 245, 200));
                            spawnPopup(mPlayerX, mPlayerY - 0.9f, "+450 HP", Color.rgb(145, 245, 200));
                        } else if (mPotions <= 0) {
                            showBanner("No Healing Draughts left (craft in Forge)");
                        }
                    }
                    return true;
                }

                float atkR = Math.min(w, h) * 0.088f;
                float atkCx = w - atkR - 26.0f;
                float atkCy = h - atkR - 26.0f;
                float dxA = x - atkCx;
                float dyA = y - atkCy;
                if (dxA * dxA + dyA * dyA <= (atkR * 1.25f) * (atkR * 1.25f)) {
                    triggerSlash();
                    return true;
                }

                float dodgeR = Math.min(w, h) * 0.070f;
                float dodgeCx = atkCx - atkR - dodgeR - 22.0f;
                float dodgeCy = h - dodgeR - 26.0f;
                float dxD = x - dodgeCx;
                float dyD = y - dodgeCy;
                if (dxD * dxD + dyD * dyD <= (dodgeR * 1.25f) * (dodgeR * 1.25f)) {
                    triggerDodge();
                    return true;
                }

                if (x < w * 0.50f) {
                    mMovePointerId = pointerId;
                    mJoyBaseX = x;
                    mJoyBaseY = y;
                    mJoyCurrX = x;
                    mJoyCurrY = y;
                    mInputX = 0.0f;
                    mInputY = 0.0f;
                } else {
                    mCursorX = x / w;
                    mCursorY = y / h;
                    if (!mAttackButtonOnly) {
                        triggerSlash();
                    }
                }
            } else if (action == MotionEvent.ACTION_MOVE) {
                int count = event.getPointerCount();
                for (int i = 0; i < count; i++) {
                    int pId = event.getPointerId(i);
                    float px = event.getX(i);
                    float py = event.getY(i);
                    if (pId == mMovePointerId) {
                        mJoyCurrX = px;
                        mJoyCurrY = py;
                        float dx = px - mJoyBaseX;
                        float dy = py - mJoyBaseY;
                        float maxR = Math.min(w, h) * 0.14f;
                        float len = (float) Math.sqrt(dx * dx + dy * dy);
                        if (len > 4.0f) {
                            float mag = Math.min(1.0f, len / maxR);
                            mInputX = (dx / len) * mag;
                            mInputY = (dy / len) * mag;
                        } else {
                            mInputX = 0.0f;
                            mInputY = 0.0f;
                        }
                    } else {
                        mCursorX = px / w;
                        mCursorY = py / h;
                    }
                }
            } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP || action == MotionEvent.ACTION_CANCEL) {
                if (pointerId == mMovePointerId) {
                    mMovePointerId = -1;
                    mInputX = 0.0f;
                    mInputY = 0.0f;
                }
            }
            return true;
        }

        private void handleStartMenuTap(float x, float y, float w, float h) {
            if (x >= w * 0.18f && x <= w * 0.82f) {
                if (y >= h * 0.39f && y <= h * 0.47f) {
                    mScreenMode = 1;
                    showBanner(mAttackButtonOnly ? "Left Thumb: Move  |  ATK: Slash  |  DODGE: Dash" : "Left Thumb: Move  |  Tap Right: Slash");
                } else if (y >= h * 0.49f && y <= h * 0.57f) {
                    mZoomPreset = (mZoomPreset + 1) % 3;
                    mCameraZoom = (mZoomPreset == 0) ? 1.55f : (mZoomPreset == 1 ? 1.15f : 0.78f);
                } else if (y >= h * 0.59f && y <= h * 0.67f) {
                    mMounted = !mMounted;
                } else if (y >= h * 0.69f && y <= h * 0.77f) {
                    mAttackButtonOnly = !mAttackButtonOnly;
                } else if (y >= h * 0.79f && y <= h * 0.87f) {
                    mScreenMode = 2;
                }
            }
        }

        private void handleModalTap(float x, float y, float w, float h) {
            if (y > h * 0.88f && x > w * 0.72f) {
                mScreenMode = 1;
                return;
            }
            // Top slot tabs: Helm, Shoulders, Chest, Gloves, Legs, Boots
            if (y >= h * 0.05f && y <= h * 0.12f) {
                int s = (int) ((x - w * 0.06f) / ((w * 0.88f) / 6.0f));
                if (s >= 0 && s < 6) mForgeSlot = s;
                return;
            }
            // Rune selector row (^ * z ~ > / x v o § +)
            if (y >= h * 0.13f && y <= h * 0.21f) {
                int r = (int) ((x - w * 0.06f) / ((w * 0.88f) / 11.0f));
                if (r >= 0 && r < 11) {
                    if (mRuneSlot1 == -1) mRuneSlot1 = r;
                    else if (mRuneSlot2 == -1) mRuneSlot2 = r;
                    else { mRuneSlot1 = r; mRuneSlot2 = -1; }
                    mStr += 1;
                    showBanner("Inscribed Rune onto Armor (+1 STR)");
                }
                return;
            }
            // Metal selector row
            if (y >= h * 0.22f && y <= h * 0.30f) {
                int m = (int) ((x - w * 0.06f) / ((w * 0.88f) / 5.0f));
                int row = (y > h * 0.26f) ? 1 : 0;
                int idx = row * 5 + Math.max(0, Math.min(4, m));
                mForgeMetal = idx;
                mForgeLevel = Math.max(mForgeLevel, idx + 1);
                showBanner("Forged Metal Tier " + (idx + 1));
                return;
            }
            // Bottom-left action buttons: Upgrade Stats / Craft Potion / Return
            if (y >= h * 0.88f && x <= w * 0.36f && mStatPoints > 0) {
                mStatPoints--;
                mVit += 2; mStr += 2; mDex += 1;
                mMaxHp += 48; mHp = mMaxHp;
                showBanner("Upgraded Stats (" + mStatPoints + " pts left)");
            } else if (y >= h * 0.88f && x > w * 0.36f && x <= w * 0.72f) {
                if (mHerbMoon >= 2 && mHerbMoss >= 1) {
                    mHerbMoon -= 2; mHerbMoss -= 1;
                    mPotions++; mHp = Math.min(mMaxHp, mHp + 450);
                    showBanner("Crafted Healing Draught (+450 HP)");
                } else {
                    showBanner("Need 2 Moonpetal + 1 Ashmoss");
                }
            }
        }

        private void showBanner(String msg) {
            mStatusBanner = msg;
            mBannerTimer = 2.6f;
        }

        private void triggerDodge() {
            if (mDodgeCooldown > 0.0f) return;
            mDodgeTimer = 0.28f;
            mDodgeCooldown = 0.85f;
            float len = (float) Math.sqrt(mInputX * mInputX + mInputY * mInputY);
            if (len > 0.15f) {
                mDodgeDirX = mInputX / len;
                mDodgeDirY = mInputY / len;
            } else {
                mDodgeDirX = mFacingX;
                mDodgeDirY = mFacingY;
            }
            mFacingX = mDodgeDirX;
            mFacingY = mDodgeDirY;
            mGhostSpawnAccum = 0.06f;
            spawnParticles(mPlayerX, mPlayerY + 0.15f, 12, Color.rgb(165, 240, 230));
        }

        private void triggerSlash() {
            if (mSlashCooldown > 0.0f) return;
            mSlashTimer = 0.26f;
            mSlashCooldown = 0.32f;

            float dmg = 34 + mStr * 3 + mForgeLevel * 14;
            for (int i = 0; i < NUM_ENEMIES; i++) {
                float dx = mEnemyX[i] - mPlayerX;
                float dy = mEnemyY[i] - mPlayerY;
                float d2 = dx * dx + dy * dy;
                if (d2 < 3.4f * 3.4f) {
                    int dealt = (int) dmg;
                    mEnemyHp[i] -= dealt;
                    mEnemyHurt[i] = 0.24f;
                    mEnemyAggro[i] = true;
                    float len = (float) Math.sqrt(d2 + 0.001f);
                    mEnemyX[i] += (dx / len) * 0.55f;
                    mEnemyY[i] += (dy / len) * 0.55f;
                    spawnParticles(mEnemyX[i], mEnemyY[i] - 0.3f, 8, Color.rgb(245, 210, 120));
                    spawnPopup(mEnemyX[i], mEnemyY[i] - 0.8f, "-" + dealt, Color.rgb(255, 224, 125));
                    if (mEnemyHp[i] <= 0) {
                        onEnemyDefeated(i);
                    }
                }
            }
        }

        private void onEnemyDefeated(int i) {
            spawnParticles(mEnemyX[i], mEnemyY[i] - 0.2f, 18, Color.rgb(220, 235, 240));
            int gainedXp = 140 + mLevel * 28;
            int gainedGold = 45 + (i * 17) % 60;
            mXp += gainedXp;
            mGold += gainedGold;
            mCinderShards += 1;
            if (mXp >= mXpNext) {
                mXp -= mXpNext;
                mLevel++;
                mXpNext = (int) (mXpNext * 1.28f);
                mStatPoints += 3;
                mMaxHp += 95;
                mHp = mMaxHp;
                mMaxMp += 16;
                mMp = mMaxMp;
                showBanner("Level Up! LV." + mLevel + " (+3 Stat Points)");
            } else {
                showBanner("Defeated Wanderer (+" + gainedXp + " XP, +" + gainedGold + "g)");
            }

            for (int l = 0; l < MAX_LOOT; l++) {
                if (!mLootActive[l]) {
                    mLootActive[l] = true;
                    mLootX[l] = mEnemyX[i];
                    mLootY[l] = mEnemyY[i];
                    mLootRarity[l] = (i + mLevel) % 4;
                    break;
                }
            }
            spawnEnemy(i, false);
        }

        @Override
        public void run() {
            long lastNs = System.nanoTime();
            while (mRunning) {
                long nowNs = System.nanoTime();
                float dt = (nowNs - lastNs) / 1_000_000_000.0f;
                lastNs = nowNs;
                if (dt > 0.05f) dt = 0.05f;
                if (dt < 0.001f) dt = 0.001f;

                if (sRustLoaded && mRustHandle != 0) {
                    try {
                        nativeStep(mRustHandle, dt);
                    } catch (Throwable ignored) {
                    }
                }

                updateSimulation(dt);
                drawFrame();

                try {
                    Thread.sleep(4);
                } catch (InterruptedException ignored) {
                }
            }
        }

        private void updateSimulation(float dt) {
            mTimeSec += dt;
            if (mBannerTimer > 0.0f) mBannerTimer -= dt;
            if (mSlashTimer > 0.0f) mSlashTimer -= dt;
            if (mSlashCooldown > 0.0f) mSlashCooldown -= dt;
            if (mDodgeTimer > 0.0f) mDodgeTimer -= dt;
            if (mDodgeCooldown > 0.0f) mDodgeCooldown -= dt;
            if (mPlayerHurtFlash > 0.0f) mPlayerHurtFlash -= dt;

            for (int g = 0; g < MAX_AFTERIMAGES; g++) {
                if (mGhostLife[g] > 0.0f) mGhostLife[g] -= dt;
            }

            if (mScreenMode == 0) {
                mCamX = (float) Math.sin(mTimeSec * 0.25f) * 1.8f;
                mCamY = (float) Math.cos(mTimeSec * 0.18f) * 1.1f;
                mFacingX = 0.88f;
                mFacingY = 0.42f;
                mGaitPhase += dt * 4.0f;
            } else if (mScreenMode == 1) {
                if (mDodgeTimer > 0.0f) {
                    float dashSpeed = mMounted ? 13.5f : 11.2f;
                    mVelX = mDodgeDirX * dashSpeed;
                    mVelY = mDodgeDirY * dashSpeed;
                    mGhostSpawnAccum += dt;
                    if (mGhostSpawnAccum >= 0.045f) {
                        mGhostSpawnAccum = 0.0f;
                        for (int g = 0; g < MAX_AFTERIMAGES; g++) {
                            if (mGhostLife[g] <= 0.0f) {
                                mGhostX[g] = mPlayerX;
                                mGhostY[g] = mPlayerY;
                                mGhostLife[g] = 0.24f;
                                break;
                            }
                        }
                    }
                } else {
                    float topSpeed = mMounted ? 5.6f : 3.9f;
                    float targetVx = mInputX * topSpeed;
                    float targetVy = mInputY * topSpeed;
                    float accel = Math.min(1.0f, dt * 11.0f);
                    mVelX += (targetVx - mVelX) * accel;
                    mVelY += (targetVy - mVelY) * accel;
                }

                float nx = mPlayerX + mVelX * dt;
                float ny = mPlayerY + mVelY * dt;
                if (!isCliff(nx, mPlayerY)) mPlayerX = nx;
                if (!isCliff(mPlayerX, ny)) mPlayerY = ny;

                float spd = (float) Math.sqrt(mVelX * mVelX + mVelY * mVelY);
                if (spd > 0.25f) {
                    mFacingX = mVelX / spd;
                    mFacingY = mVelY / spd;
                    mGaitPhase += dt * (mMounted ? 5.2f + spd * 2.1f : 4.8f + spd * 3.1f);
                } else {
                    mGaitPhase += dt * 1.6f;
                }

                mCamX += (mPlayerX - mCamX) * Math.min(1.0f, dt * 8.0f);
                mCamY += (mPlayerY - mCamY) * Math.min(1.0f, dt * 8.0f);

                // Harvest nearby Flora automatically when walking over
                for (int f = 0; f < NUM_FLORA; f++) {
                    if (mFloraRegrow[f] > 0.0f) {
                        mFloraRegrow[f] -= dt;
                    } else {
                        float dx = mFloraX[f] - mPlayerX;
                        float dy = mFloraY[f] - mPlayerY;
                        if (dx * dx + dy * dy < 1.05f * 1.05f) {
                            mFloraRegrow[f] = 18.0f;
                            if (mFloraKind[f] == 0) {
                                mHerbMoon++;
                                spawnPopup(mFloraX[f], mFloraY[f] - 0.5f, "+1 Moonpetal", Color.rgb(175, 225, 255));
                            } else if (mFloraKind[f] == 1) {
                                mHerbCinder++;
                                spawnPopup(mFloraX[f], mFloraY[f] - 0.5f, "+1 Cinderbloom", Color.rgb(255, 185, 105));
                            } else {
                                mHerbMoss++;
                                spawnPopup(mFloraX[f], mFloraY[f] - 0.5f, "+1 Ashmoss", Color.rgb(145, 240, 170));
                            }
                            spawnParticles(mFloraX[f], mFloraY[f], 8, Color.rgb(210, 248, 220));
                        }
                    }
                }

                // Update Ambient Fauna (Deer, Rabbits, Birds, River Koi)
                for (int a = 0; a < NUM_FAUNA; a++) {
                    mFaunaPhase[a] += dt * (mFaunaKind[a] == 1 ? 7.5f : 4.2f);
                    if (mFaunaKind[a] == 3) {
                        mFaunaX[a] += mFaunaVx[a] * dt;
                        if (mFaunaX[a] > mPlayerX + 14.0f) mFaunaVx[a] = -0.8f;
                        if (mFaunaX[a] < mPlayerX - 14.0f) mFaunaVx[a] = 0.8f;
                        mFaunaY[a] = riverCenterY(mFaunaX[a]) + (float) Math.sin(mFaunaPhase[a] * 0.5f) * 0.45f;
                    } else {
                        float dx = mFaunaX[a] - mPlayerX;
                        float dy = mFaunaY[a] - mPlayerY;
                        float d2 = dx * dx + dy * dy;
                        if (d2 < 3.5f * 3.5f) {
                            float d = (float) Math.sqrt(d2 + 0.001f);
                            float fleeSpd = (mFaunaKind[a] == 2) ? 4.4f : 3.4f;
                            mFaunaVx[a] = (dx / d) * fleeSpd;
                            mFaunaVy[a] = (dy / d) * fleeSpd;
                        } else if (((int) (mTimeSec * 2.0f + a)) % 7 == 0) {
                            mFaunaVx[a] = (float) Math.cos(mTimeSec * 0.8f + a) * 0.65f;
                            mFaunaVy[a] = (float) Math.sin(mTimeSec * 0.7f + a) * 0.65f;
                        }
                        float nxF = mFaunaX[a] + mFaunaVx[a] * dt;
                        float nyF = mFaunaY[a] + mFaunaVy[a] * dt;
                        if (mFaunaKind[a] == 2 || !isCliff(nxF, nyF)) {
                            mFaunaX[a] = nxF;
                            mFaunaY[a] = nyF;
                        } else {
                            mFaunaVx[a] = -mFaunaVx[a];
                            mFaunaVy[a] = -mFaunaVy[a];
                        }
                    }
                }

                // Pick up loot drops
                for (int l = 0; l < MAX_LOOT; l++) {
                    if (mLootActive[l]) {
                        float dx = mLootX[l] - mPlayerX;
                        float dy = mLootY[l] - mPlayerY;
                        if (dx * dx + dy * dy < 1.15f * 1.15f) {
                            mLootActive[l] = false;
                            String[] pool = {
                                    "Pale-Moon Greatsword",
                                    "Wraith-Weave Cloak",
                                    "Crown of the First Kiln",
                                    "Obsidian Courser Barding",
                                    "Starlight Signet Ring"
                            };
                            String item = pool[mLootRarity[l] % pool.length] + " +" + (1 + mLevel / 4);
                            if (mInvCount < mInventory.length) {
                                mInventory[mInvCount++] = item;
                            }
                            mEquippedWeapon = item;
                            showBanner("Equipped: " + item);
                        }
                    }
                }

                // Enemies stay in their spot until player gets close (< 6.2 units)!
                for (int i = 0; i < NUM_ENEMIES; i++) {
                    if (mEnemyHurt[i] > 0.0f) mEnemyHurt[i] -= dt;
                    if (mEnemyAtkCooldown[i] > 0.0f) mEnemyAtkCooldown[i] -= dt;

                    float dx = mPlayerX - mEnemyX[i];
                    float dy = mPlayerY - mEnemyY[i];
                    float dist = (float) Math.sqrt(dx * dx + dy * dy + 0.001f);

                    if (!mEnemyAggro[i] && dist < 6.2f) {
                        mEnemyAggro[i] = true;
                    } else if (mEnemyAggro[i] && dist > 11.5f) {
                        mEnemyAggro[i] = false;
                    }

                    if (!mEnemyAggro[i]) {
                        float hx = mEnemyHomeX[i] - mEnemyX[i];
                        float hy = mEnemyHomeY[i] - mEnemyY[i];
                        float hd = (float) Math.sqrt(hx * hx + hy * hy);
                        if (hd > 0.35f) {
                            mEnemyFacingX[i] = hx / hd;
                            mEnemyFacingY[i] = hy / hd;
                            mEnemyGait[i] += dt * 5.0f;
                            mEnemyX[i] += mEnemyFacingX[i] * 1.15f * dt;
                            mEnemyY[i] += mEnemyFacingY[i] * 1.15f * dt;
                        } else {
                            mEnemyGait[i] += dt * 1.2f;
                        }
                        continue;
                    }

                    mEnemyFacingX[i] = dx / dist;
                    mEnemyFacingY[i] = dy / dist;

                    if (mEnemyAtkWindup[i] > 0.0f) {
                        mEnemyAtkWindup[i] -= dt;
                        if (mEnemyAtkWindup[i] <= 0.0f) {
                            // Execute enemy strike!
                            if (dist < 2.15f && mDodgeTimer <= 0.0f) {
                                int enemyDmg = 18 + mLevel * 2 + (mEnemyKind[i] * 5);
                                mHp -= enemyDmg;
                                mPlayerHurtFlash = 0.22f;
                                spawnParticles(mPlayerX, mPlayerY - 0.2f, 10, Color.rgb(245, 78, 78));
                                spawnPopup(mPlayerX, mPlayerY - 0.9f, "-" + enemyDmg, Color.rgb(255, 88, 88));
                                if (mHp <= 0) {
                                    mHp = mMaxHp;
                                    mPlayerX = 0.0f;
                                    mPlayerY = 0.0f;
                                    showBanner("Revived at Ashveil Meadow");
                                }
                            } else if (dist < 2.15f && mDodgeTimer > 0.0f) {
                                spawnPopup(mPlayerX, mPlayerY - 0.9f, "DODGED!", Color.rgb(150, 245, 230));
                            }
                            mEnemyAtkCooldown[i] = 1.25f;
                        }
                    } else if (dist > 1.45f) {
                        mEnemyGait[i] += dt * 8.5f;
                        float ex = mEnemyX[i] + mEnemyFacingX[i] * 1.95f * dt;
                        float ey = mEnemyY[i] + mEnemyFacingY[i] * 1.95f * dt;
                        if (!isCliff(ex, ey)) {
                            mEnemyX[i] = ex;
                            mEnemyY[i] = ey;
                        }
                    } else if (mEnemyAtkCooldown[i] <= 0.0f) {
                        // Start visible weapon-raise telegraph!
                        mEnemyAtkWindup[i] = 0.42f;
                    }
                }
            }

            // Ambient firefly motes & drifting flower petals
            if (((int) (mTimeSec * 60.0f)) % 8 == 0) {
                float fx = mCamX + ((float) Math.sin(mTimeSec * 3.1f) * 6.5f);
                float fy = mCamY + ((float) Math.cos(mTimeSec * 2.3f) * 4.5f);
                boolean petal = (((int) (mTimeSec * 12.0f)) % 2 == 0);
                spawnParticles(fx, fy, 1, petal ? Color.rgb(245, 240, 215) : Color.rgb(165, 245, 175));
            }

            for (int pIdx = 0; pIdx < MAX_PARTICLES; pIdx++) {
                if (mPartLife[pIdx] > 0.0f) {
                    mPartLife[pIdx] -= dt;
                    mPartX[pIdx] += mPartVx[pIdx] * dt;
                    mPartY[pIdx] += mPartVy[pIdx] * dt;
                }
            }
            for (int k = 0; k < MAX_POPUPS; k++) {
                if (mPopLife[k] > 0.0f) {
                    mPopLife[k] -= dt;
                    mPopY[k] -= 0.9f * dt;
                }
            }

            mCoifRot += dt * 1.15f;
            updateVerletHairAndCloak(dt);
            if (mMounted) {
                rasterizeHorseAndRiderAscii();
            } else {
                rasterizeFootKnightAscii();
            }
        }

        private void updateVerletHairAndCloak(float dt) {
            float windMult = (mWindPreset == 0) ? 0.55f : (mWindPreset == 1 ? 1.0f : 1.75f);
            float windX = (float) Math.sin(mTimeSec * 2.1f) * 4.2f * windMult - mVelX * 0.50f;
            float windY = (float) Math.cos(mTimeSec * 1.6f) * 1.8f * windMult + 1.2f;

            float tailAnchorX = mPlayerX - mFacingX * 0.65f;
            float tailAnchorY = mPlayerY - mFacingY * 0.25f - 0.10f;
            stepVerletChain(mTailX, mTailY, mTailPrevX, mTailPrevY, TAIL_STRANDS, TAIL_NODES,
                    tailAnchorX, tailAnchorY, 0.14f, windX, windY, dt, 0.06f);

            float neckX = mPlayerX + mFacingX * 0.45f;
            float neckY = mPlayerY + mFacingY * 0.15f - 0.65f;
            stepVerletChain(mManeX, mManeY, mManePrevX, mManePrevY, MANE_STRANDS, MANE_NODES,
                    neckX, neckY, 0.085f, windX * 0.7f, windY * 0.8f, dt, 0.045f);

            float headX = mMounted ? (mPlayerX - mFacingX * 0.10f) : (mPlayerX - mFacingX * 0.14f);
            float headY = mMounted ? (mPlayerY - 1.25f) : (mPlayerY - 1.02f);
            stepVerletChain(mHairX, mHairY, mHairPrevX, mHairPrevY, HAIR_STRANDS, HAIR_NODES,
                    headX, headY, mMounted ? 0.10f : 0.13f, windX * 1.2f, windY, dt, 0.032f);
        }

        private void stepVerletChain(
                float[][] x, float[][] y, float[][] px, float[][] py,
                int strands, int nodes, float ax, float ay, float segLen,
                float windX, float windY, float dt, float spread
        ) {
            float dt2 = dt * dt;
            for (int s = 0; s < strands; s++) {
                float sOff = (s - strands * 0.5f) * spread;
                x[s][0] = ax + sOff * 0.35f;
                y[s][0] = ay + Math.abs(sOff) * 0.25f;
                for (int n = 1; n < nodes; n++) {
                    float vx = (x[s][n] - px[s][n]) * 0.91f;
                    float vy = (y[s][n] - py[s][n]) * 0.91f;
                    px[s][n] = x[s][n];
                    py[s][n] = y[s][n];
                    float gust = (float) Math.sin(mTimeSec * 4.2f + s * 0.9f + n * 0.5f) * 0.9f;
                    x[s][n] += vx + (windX + gust) * dt2;
                    y[s][n] += vy + windY * dt2;
                }
                for (int iter = 0; iter < 3; iter++) {
                    x[s][0] = ax + sOff * 0.35f;
                    y[s][0] = ay + Math.abs(sOff) * 0.25f;
                    for (int n = 0; n < nodes - 1; n++) {
                        int j = n + 1;
                        float dx = x[s][j] - x[s][n];
                        float dy = y[s][j] - y[s][n];
                        float dist = (float) Math.sqrt(dx * dx + dy * dy + 1e-6f);
                        float diff = (dist - segLen) / dist;
                        if (n == 0) {
                            x[s][j] -= dx * diff;
                            y[s][j] -= dy * diff;
                        } else {
                            x[s][n] += dx * diff * 0.30f;
                            y[s][n] += dy * diff * 0.30f;
                            x[s][j] -= dx * diff * 0.70f;
                            y[s][j] -= dy * diff * 0.70f;
                        }
                    }
                }
            }
        }

        // =========================================================================
        // FLUID ANIMATED FOOT KNIGHT (CRISP ARMOR + VERLET CAPE + 3-STAGE SLASH)
        // =========================================================================
        private void rasterizeFootKnightAscii() {
            int total = FOOT_BUF_W * FOOT_BUF_H;
            for (int i = 0; i < total; i++) {
                mFootGlyphBuf[i] = ' ';
                mFootLumBuf[i] = -1.0f;
            }

            float sx = 20.0f;
            float sy = 20.0f;
            float cx = FOOT_BUF_W * 0.5f;
            float cy = FOOT_BUF_H * 0.55f;

            float spd = (float) Math.sqrt(mVelX * mVelX + mVelY * mVelY);
            float moveAmt = Math.min(1.0f, spd / 3.2f);
            float bob = (float) Math.abs(Math.sin(mGaitPhase)) * 0.085f * moveAmt
                    + (float) Math.sin(mTimeSec * 2.5f) * 0.025f;

            float fx = mFacingX;
            float fy = mFacingY;
            boolean dodging = (mDodgeTimer > 0.0f);
            float crouchY = dodging ? 0.24f : 0.0f;
            float leanX = fx * (dodging ? 0.36f : 0.14f * moveAmt);
            bob -= crouchY;

            // 1. Flowing Verlet Cape & Silver Hair
            for (int hs = 0; hs < HAIR_STRANDS; hs++) {
                float lumBase = 0.76f + (hs % 3) * 0.07f;
                for (int hn = 0; hn < HAIR_NODES - 1; hn++) {
                    float lx0 = mHairX[hs][hn] - mPlayerX;
                    float ly0 = mHairY[hs][hn] - mPlayerY + 0.52f;
                    float lx1 = mHairX[hs][hn + 1] - mPlayerX;
                    float ly1 = mHairY[hs][hn + 1] - mPlayerY + 0.52f;
                    plotHairToBuf(mFootGlyphBuf, mFootLumBuf, mFootColorBuf, FOOT_BUF_W, FOOT_BUF_H,
                            cx, cy, sx, sy, lx0, ly0, lx1, ly1, 0.075f, lumBase - hn * 0.05f);
                }
            }

            // 2. Smooth 2-Leg Run Stride
            for (int leg = 0; leg < 2; leg++) {
                float ph = mGaitPhase + (leg == 1 ? (float) Math.PI : 0.0f);
                float side = (leg == 0 ? -0.15f : 0.15f);
                float stride = (float) Math.sin(ph) * 0.36f * moveAmt;
                float lift = Math.max(0.0f, (float) Math.cos(ph)) * 0.20f * moveAmt;

                float hipX = side + leanX * 0.3f;
                float hipY = 0.15f - bob;
                float kneeX = hipX + fx * stride * 0.65f;
                float kneeY = hipY + 0.32f - lift * 0.6f;
                float bootX = hipX + fx * stride;
                float bootY = hipY + 0.66f + fy * stride * 0.35f - lift;

                float lLum = (leg == 0) ? 0.72f : 0.88f;
                plotCapsuleToBuf(mFootGlyphBuf, mFootLumBuf, mFootColorBuf, FOOT_BUF_W, FOOT_BUF_H,
                        cx, cy, sx, sy, hipX, hipY, kneeX, kneeY, 0.095f, lLum);
                plotCapsuleToBuf(mFootGlyphBuf, mFootLumBuf, mFootColorBuf, FOOT_BUF_W, FOOT_BUF_H,
                        cx, cy, sx, sy, kneeX, kneeY, bootX, bootY, 0.085f, lLum * 0.96f);
            }

            // 3. Sleek Armored Torso + Pauldrons + Plumed Helm
            float twist = (mSlashTimer > 0.0f) ? ((1.0f - mSlashTimer / 0.26f) - 0.5f) * 0.22f : 0.0f;
            float chestX = leanX + twist;
            float chestY = -0.34f - bob;
            plotCapsuleToBuf(mFootGlyphBuf, mFootLumBuf, mFootColorBuf, FOOT_BUF_W, FOOT_BUF_H,
                    cx, cy, sx, sy, 0.0f, 0.14f - bob, chestX, chestY, 0.19f, 0.90f);
            plotCapsuleToBuf(mFootGlyphBuf, mFootLumBuf, mFootColorBuf, FOOT_BUF_W, FOOT_BUF_H,
                    cx, cy, sx, sy, chestX - 0.23f, chestY + 0.04f, chestX + 0.23f, chestY + 0.04f, 0.11f, 0.95f);

            float headX = chestX + fx * 0.06f;
            float headY = chestY - 0.30f;
            plotCapsuleToBuf(mFootGlyphBuf, mFootLumBuf, mFootColorBuf, FOOT_BUF_W, FOOT_BUF_H,
                    cx, cy, sx, sy, headX, headY + 0.06f, headX, headY - 0.11f, 0.13f, 0.99f);

            // 4. Shield Arm
            float armSwing = (float) Math.sin(mGaitPhase) * 0.30f * moveAmt;
            float lShX = chestX - 0.24f;
            float lShY = chestY + 0.05f;
            float lHandX = lShX - 0.09f - armSwing * 0.4f;
            float lHandY = lShY + 0.34f - armSwing * 0.3f;
            plotCapsuleToBuf(mFootGlyphBuf, mFootLumBuf, mFootColorBuf, FOOT_BUF_W, FOOT_BUF_H,
                    cx, cy, sx, sy, lShX, lShY, lHandX, lHandY, 0.08f, 0.80f);

            // 5. Greatsword Arm + Blade (3-phase slash sweep)
            float rShX = chestX + 0.24f;
            float rShY = chestY + 0.05f;
            float slashProg = (mSlashTimer > 0.0f) ? (1.0f - (mSlashTimer / 0.26f)) : -1.0f;
            float swordAngle = (slashProg >= 0.0f)
                    ? ((float) Math.atan2(fy, fx) - 1.55f + slashProg * 3.1f)
                    : ((float) Math.atan2(fy, fx) + 0.42f + armSwing * 0.65f);
            float rHandX = rShX + (float) Math.cos(swordAngle) * 0.26f;
            float rHandY = rShY + (float) Math.sin(swordAngle) * 0.26f;
            float tipX = rHandX + (float) Math.cos(swordAngle) * 0.72f;
            float tipY = rHandY + (float) Math.sin(swordAngle) * 0.72f;

            plotCapsuleToBuf(mFootGlyphBuf, mFootLumBuf, mFootColorBuf, FOOT_BUF_W, FOOT_BUF_H,
                    cx, cy, sx, sy, rShX, rShY, rHandX, rHandY, 0.08f, 0.90f);
            plotCapsuleToBuf(mFootGlyphBuf, mFootLumBuf, mFootColorBuf, FOOT_BUF_W, FOOT_BUF_H,
                    cx, cy, sx, sy, rHandX, rHandY, tipX, tipY, 0.05f, 1.0f);
        }

        private void rasterizeEnemyHumanoidAscii(int eIdx) {
            int total = ENEMY_BUF_W * ENEMY_BUF_H;
            for (int i = 0; i < total; i++) {
                mEnemyGlyphBuf[i] = ' ';
                mEnemyLumBuf[i] = -1.0f;
            }

            float sx = 18.0f;
            float sy = 18.0f;
            float cx = ENEMY_BUF_W * 0.5f;
            float cy = ENEMY_BUF_H * 0.55f;

            float g = mEnemyGait[eIdx];
            boolean moving = mEnemyAggro[eIdx] && (mEnemyAtkWindup[eIdx] <= 0.0f);
            float bob = moving ? (float) Math.abs(Math.sin(g)) * 0.07f : (float) Math.sin(g) * 0.025f;
            float fx = mEnemyFacingX[eIdx];
            float fy = mEnemyFacingY[eIdx];

            for (int leg = 0; leg < 2; leg++) {
                float ph = g + (leg == 1 ? (float) Math.PI : 0.0f);
                float side = (leg == 0 ? -0.14f : 0.14f);
                float st = moving ? (float) Math.sin(ph) * 0.28f : 0.0f;
                float lift = moving ? Math.max(0.0f, (float) Math.cos(ph)) * 0.15f : 0.0f;
                plotCapsuleToBuf(mEnemyGlyphBuf, mEnemyLumBuf, mEnemyColorBuf, ENEMY_BUF_W, ENEMY_BUF_H,
                        cx, cy, sx, sy, side, 0.14f - bob, side + st, 0.70f - lift, 0.085f, 0.70f);
            }

            plotCapsuleToBuf(mEnemyGlyphBuf, mEnemyLumBuf, mEnemyColorBuf, ENEMY_BUF_W, ENEMY_BUF_H,
                    cx, cy, sx, sy, 0.0f, 0.12f - bob, fx * 0.08f, -0.32f - bob, 0.18f, 0.82f);
            plotCapsuleToBuf(mEnemyGlyphBuf, mEnemyLumBuf, mEnemyColorBuf, ENEMY_BUF_W, ENEMY_BUF_H,
                    cx, cy, sx, sy, -0.20f, -0.28f - bob, 0.20f, -0.28f - bob, 0.10f, 0.88f);
            plotCapsuleToBuf(mEnemyGlyphBuf, mEnemyLumBuf, mEnemyColorBuf, ENEMY_BUF_W, ENEMY_BUF_H,
                    cx, cy, sx, sy, fx * 0.08f, -0.50f - bob, fx * 0.08f, -0.64f - bob, 0.12f, 0.94f);

            // Weapon arm raises high during windup telegraph!
            float windupRaise = (mEnemyAtkWindup[eIdx] > 0.0f) ? -1.45f * (mEnemyAtkWindup[eIdx] / 0.42f) : 0.25f;
            float wAng = (float) Math.atan2(fy, fx) + windupRaise;
            float hx = 0.20f + (float) Math.cos(wAng) * 0.24f;
            float hy = -0.26f - bob + (float) Math.sin(wAng) * 0.24f;
            float tx = hx + (float) Math.cos(wAng) * 0.58f;
            float ty = hy + (float) Math.sin(wAng) * 0.58f;
            plotCapsuleToBuf(mEnemyGlyphBuf, mEnemyLumBuf, mEnemyColorBuf, ENEMY_BUF_W, ENEMY_BUF_H,
                    cx, cy, sx, sy, 0.20f, -0.26f - bob, hx, hy, 0.075f, 0.78f);
            plotCapsuleToBuf(mEnemyGlyphBuf, mEnemyLumBuf, mEnemyColorBuf, ENEMY_BUF_W, ENEMY_BUF_H,
                    cx, cy, sx, sy, hx, hy, tx, ty, 0.048f, 0.98f);
        }

        private void rasterizeHorseAndRiderAscii() {
            for (int i = 0; i < HORSE_BUF_W * HORSE_BUF_H; i++) {
                mHorseGlyphBuf[i] = ' ';
                mHorseLumBuf[i] = -1.0f;
            }

            float scaleX = 18.0f;
            float scaleY = 18.0f;
            float cx = HORSE_BUF_W * 0.5f;
            float cy = HORSE_BUF_H * 0.56f;

            float fx = mFacingX;
            float fy = mFacingY;
            float bob = (float) Math.abs(Math.sin(mGaitPhase)) * 0.045f;

            float[] legHipOff = {-0.58f, 0.52f, -0.46f, 0.62f};
            float[] legPhaseOff = {0.0f, (float) Math.PI, (float) (Math.PI * 0.5), (float) (Math.PI * 1.5)};
            float[] legBrightness = {0.42f, 0.45f, 0.72f, 0.76f};
            float speedFactor = Math.min(1.0f, (float) Math.sqrt(mVelX * mVelX + mVelY * mVelY) / 3.5f);

            for (int leg = 0; leg < 4; leg++) {
                float ph = mGaitPhase + legPhaseOff[leg];
                float swing = (float) Math.sin(ph) * 0.28f * speedFactor;
                float lift = Math.max(0.0f, (float) Math.cos(ph)) * 0.18f * speedFactor;

                float hipX = fx * legHipOff[leg];
                float hipY = fy * legHipOff[leg] * 0.35f + 0.08f - bob;
                float kneeX = hipX + fx * (swing * 0.5f + 0.04f);
                float kneeY = hipY + 0.36f - lift * 0.5f;
                float hoofX = kneeX + fx * swing;
                float hoofY = hipY + 0.74f - lift;

                plotCapsuleToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                        cx, cy, scaleX, scaleY, hipX, hipY, kneeX, kneeY, 0.11f, legBrightness[leg]);
                plotCapsuleToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                        cx, cy, scaleX, scaleY, kneeX, kneeY, hoofX, hoofY, 0.085f, legBrightness[leg] * 0.9f);
            }

            float rearX = -fx * 0.56f;
            float rearY = -fy * 0.22f - 0.05f - bob;
            float frontX = fx * 0.52f;
            float frontY = fy * 0.22f - 0.08f - bob;
            plotCapsuleToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                    cx, cy, scaleX, scaleY, rearX, rearY, frontX, frontY, 0.34f, 0.88f);
            plotCapsuleToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                    cx, cy, scaleX, scaleY, rearX, rearY - 0.06f, rearX * 0.5f, rearY - 0.08f, 0.26f, 0.96f);

            float neckTopX = frontX + fx * 0.42f;
            float neckTopY = frontY - 0.52f;
            plotCapsuleToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                    cx, cy, scaleX, scaleY, frontX, frontY - 0.05f, neckTopX, neckTopY, 0.22f, 0.92f);

            float muzzleX = neckTopX + fx * 0.38f;
            float muzzleY = neckTopY + 0.14f;
            plotCapsuleToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                    cx, cy, scaleX, scaleY, neckTopX, neckTopY, muzzleX, muzzleY, 0.14f, 0.95f);
            plotCapsuleToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                    cx, cy, scaleX, scaleY, neckTopX - fx * 0.05f, neckTopY - 0.08f, neckTopX - fx * 0.02f, neckTopY - 0.24f, 0.06f, 0.98f);

            float saddleX = -fx * 0.06f;
            float saddleY = -0.32f - bob;
            plotCapsuleToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                    cx, cy, scaleX, scaleY, saddleX, saddleY + 0.18f, saddleX + fx * 0.12f, saddleY + 0.58f, 0.10f, 0.38f);
            plotCapsuleToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                    cx, cy, scaleX, scaleY, saddleX, saddleY, saddleX - fx * 0.04f, saddleY - 0.52f, 0.21f, 0.62f);
            plotCapsuleToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                    cx, cy, scaleX, scaleY, saddleX - fx * 0.04f, saddleY - 0.66f, saddleX - fx * 0.02f, saddleY - 0.80f, 0.13f, 0.84f);
            plotCapsuleToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                    cx, cy, scaleX, scaleY, saddleX + fx * 0.05f, saddleY - 0.36f, frontX + fx * 0.20f, frontY - 0.25f, 0.08f, 0.70f);

            for (int ts = 0; ts < TAIL_STRANDS; ts++) {
                float tLum = 0.80f + (ts % 4) * 0.05f;
                for (int tn = 0; tn < TAIL_NODES - 1; tn++) {
                    plotHairToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                            cx, cy, scaleX, scaleY,
                            mTailX[ts][tn] - mPlayerX, mTailY[ts][tn] - mPlayerY,
                            mTailX[ts][tn + 1] - mPlayerX, mTailY[ts][tn + 1] - mPlayerY,
                            0.095f - tn * 0.007f, tLum - tn * 0.04f);
                }
            }
            for (int ms = 0; ms < MANE_STRANDS; ms++) {
                float mLum = 0.88f + (ms % 3) * 0.04f;
                for (int mn = 0; mn < MANE_NODES - 1; mn++) {
                    plotHairToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                            cx, cy, scaleX, scaleY,
                            mManeX[ms][mn] - mPlayerX, mManeY[ms][mn] - mPlayerY,
                            mManeX[ms][mn + 1] - mPlayerX, mManeY[ms][mn + 1] - mPlayerY,
                            0.075f, mLum - mn * 0.03f);
                }
            }
            for (int hs = 0; hs < HAIR_STRANDS; hs++) {
                for (int hn = 0; hn < HAIR_NODES - 1; hn++) {
                    plotHairToBuf(mHorseGlyphBuf, mHorseLumBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                            cx, cy, scaleX, scaleY,
                            mHairX[hs][hn] - mPlayerX, mHairY[hs][hn] - mPlayerY,
                            mHairX[hs][hn + 1] - mPlayerX, mHairY[hs][hn + 1] - mPlayerY,
                            0.070f, 0.96f - hn * 0.04f);
                }
            }
        }

        private void plotCapsuleToBuf(
                char[] gBuf, float[] lBuf, int[] cBuf, int bufW, int bufH,
                float cx, float cy, float sx, float sy,
                float ax, float ay, float bx, float by,
                float radius, float baseLum
        ) {
            int minC = Math.max(0, (int) (cx + (Math.min(ax, bx) - radius) * sx) - 1);
            int maxC = Math.min(bufW - 1, (int) (cx + (Math.max(ax, bx) + radius) * sx) + 1);
            int minR = Math.max(0, (int) (cy + (Math.min(ay, by) - radius) * sy) - 1);
            int maxR = Math.min(bufH - 1, (int) (cy + (Math.max(ay, by) + radius) * sy) + 1);

            float abx = bx - ax;
            float aby = by - ay;
            float ab2 = abx * abx + aby * aby + 1e-6f;
            float r2 = radius * radius;

            for (int r = minR; r <= maxR; r++) {
                float py = (r - cy) / sy;
                for (int c = minC; c <= maxC; c++) {
                    float px = (c - cx) / sx;
                    float t = ((px - ax) * abx + (py - ay) * aby) / ab2;
                    if (t < 0.0f) t = 0.0f;
                    else if (t > 1.0f) t = 1.0f;
                    float qx = ax + t * abx;
                    float qy = ay + t * aby;
                    float dx = px - qx;
                    float dy = py - qy;
                    float d2 = dx * dx + dy * dy;
                    if (d2 <= r2) {
                        float distNorm = (float) Math.sqrt(d2) / radius;
                        float nz = (float) Math.sqrt(Math.max(0.0f, 1.0f - distNorm * distNorm));
                        float ny = dy / radius;
                        float light = (nz * 0.72f - ny * 0.38f + 0.15f) * baseLum;
                        if (distNorm > 0.80f) light *= 0.25f;
                        int idx = r * bufW + c;
                        if (light > lBuf[idx]) {
                            lBuf[idx] = light;
                            int rampIdx = Math.max(1, Math.min(DENSE_RAMP.length() - 1, (int) (light * (DENSE_RAMP.length() - 1))));
                            gBuf[idx] = DENSE_RAMP.charAt(rampIdx);
                            int v = Math.max(20, Math.min(250, (int) (light * 255.0f)));
                            cBuf[idx] = Color.rgb(v, v, Math.min(255, v + 6));
                        }
                    }
                }
            }
        }

        private void plotHairToBuf(
                char[] gBuf, float[] lBuf, int[] cBuf, int bufW, int bufH,
                float cx, float cy, float sx, float sy,
                float ax, float ay, float bx, float by,
                float radius, float lum
        ) {
            int steps = 4;
            for (int i = 0; i <= steps; i++) {
                float t = i / (float) steps;
                float px = ax + (bx - ax) * t;
                float py = ay + (by - ay) * t;
                int c0 = Math.round(cx + px * sx);
                int r0 = Math.round(cy + py * sy);
                int radCells = Math.max(1, Math.round(radius * sx));
                for (int dr = -radCells; dr <= radCells; dr++) {
                    for (int dc = -radCells; dc <= radCells; dc++) {
                        int c = c0 + dc;
                        int r = r0 + dr;
                        if (c >= 0 && c < bufW && r >= 0 && r < bufH) {
                            float falloff = 1.0f - ((float) Math.sqrt(dc * dc + dr * dr) / (radCells + 0.6f));
                            if (falloff > 0.0f) {
                                float l = lum * (0.65f + 0.35f * falloff);
                                int idx = r * bufW + c;
                                if (l >= lBuf[idx]) {
                                    lBuf[idx] = l;
                                    int rIdx = Math.max(4, Math.min(DENSE_RAMP.length() - 1, (int) (l * (DENSE_RAMP.length() - 1))));
                                    gBuf[idx] = DENSE_RAMP.charAt(rIdx);
                                    int v = Math.max(95, Math.min(252, (int) (l * 255.0f)));
                                    cBuf[idx] = Color.rgb(v, v, Math.min(255, v + 5));
                                }
                            }
                        }
                    }
                }
            }
        }

        private Bitmap getOrBuildChunk(int cxIdx, int cyIdx, int[] builtThisFrame) {
            int key = ((cxIdx & 0xFFFF) << 16) | (cyIdx & 0xFFFF);
            int lruIdx = 0;
            int minAge = Integer.MAX_VALUE;
            for (int i = 0; i < CHUNK_CACHE_CAP; i++) {
                if (mChunkKeys[i] == key && mChunkBitmaps[i] != null) {
                    mChunkAge[i] = ++mChunkTick;
                    return mChunkBitmaps[i];
                }
                if (mChunkBitmaps[i] == null) {
                    lruIdx = i;
                    minAge = -1;
                } else if (minAge != -1 && mChunkAge[i] < minAge) {
                    minAge = mChunkAge[i];
                    lruIdx = i;
                }
            }

            if (builtThisFrame[0] >= 6) {
                return null;
            }
            builtThisFrame[0]++;

            if (mChunkBitmaps[lruIdx] == null) {
                mChunkBitmaps[lruIdx] = Bitmap.createBitmap(CHUNK_PX, CHUNK_PX, Bitmap.Config.ARGB_8888);
                mChunkCanvases[lruIdx] = new Canvas(mChunkBitmaps[lruIdx]);
            }
            mChunkKeys[lruIdx] = key;
            mChunkAge[lruIdx] = ++mChunkTick;

            Canvas cc = mChunkCanvases[lruIdx];
            int qx = ((cxIdx % 4) + 4) % 4;
            int qy = ((cyIdx % 4) + 4) % 4;
            mSrcRect.set(qx * 256, qy * 256, qx * 256 + 256, qy * 256 + 256);
            mTmpRect.set(0, 0, CHUNK_PX, CHUNK_PX);
            cc.drawBitmap(mMeadowTileBitmap, mSrcRect, mTmpRect, null);

            float cellPx = 10.666f;
            int cells = (int) (CHUNK_PX / cellPx) + 1;
            float baseWx = cxIdx * CHUNK_WORLD_UNITS;
            float baseWy = cyIdx * CHUNK_WORLD_UNITS;
            float unitsPerCell = CHUNK_WORLD_UNITS / (CHUNK_PX / cellPx);

            Paint cBg = mChunkBgPaint;
            Paint cTxt = mChunkTxtPaint;
            cTxt.setTextSize(cellPx * 1.05f);

            for (int r = 0; r < cells; r++) {
                float wy = baseWy + r * unitsPerCell;
                float py = r * cellPx;
                for (int c = 0; c < cells; c++) {
                    float wx = baseWx + c * unitsPerCell;
                    float px = c * cellPx;
                    float distRiver = Math.abs(wy - riverCenterY(wx));
                    if (distRiver < 2.15f) {
                        int dShade = (distRiver < 1.35f) ? 7 : 12;
                        cBg.setColor(Color.rgb(dShade, dShade + 5, dShade + 13));
                        cc.drawRect(px, py, px + cellPx + 1.0f, py + cellPx + 1.0f, cBg);
                    } else {
                        // Riverbank reeds & pebbles near water edge
                        if (distRiver < 2.65f && distRiver >= 2.15f) {
                            int rHash = Math.abs(((cxIdx * 31 + c) * 73856093) ^ ((cyIdx * 31 + r) * 19349663));
                            if (rHash % 3 == 0) {
                                cTxt.setColor(Color.rgb(92, 138, 86));
                                cc.drawText((rHash % 2 == 0) ? "|" : "i", px, py + cellPx * 0.85f, cTxt);
                            } else if (rHash % 5 == 0) {
                                cTxt.setColor(Color.rgb(108, 118, 126));
                                cc.drawText("o", px, py + cellPx * 0.85f, cTxt);
                            }
                        }
                        // Worn cobblestone/dirt path leading to house doors
                        for (int hIdx = 0; hIdx < HOUSE_X.length; hIdx++) {
                            if (Math.abs(wx - HOUSE_X[hIdx]) < 0.72f && wy > HOUSE_Y[hIdx] + 0.5f && wy < HOUSE_Y[hIdx] + 2.8f) {
                                int pHash = Math.abs((c * 131) ^ (r * 97));
                                cBg.setColor(Color.argb(150, 26, 22, 18));
                                cc.drawRect(px, py, px + cellPx + 1.0f, py + cellPx + 1.0f, cBg);
                                cTxt.setColor((pHash % 2 == 0) ? Color.rgb(112, 102, 88) : Color.rgb(86, 78, 68));
                                cc.drawText((pHash % 3 == 0) ? ":" : ".", px, py + cellPx * 0.85f, cTxt);
                            }
                        }
                        float dens = cliffDensity(wx, wy);
                        if (dens > 0.68f) {
                            cBg.setColor(Color.rgb(7, 9, 11));
                            cc.drawRect(px, py, px + cellPx + 1.0f, py + cellPx + 1.0f, cBg);
                            float gx = cliffDensity(wx + 0.12f, wy) - cliffDensity(wx - 0.12f, wy);
                            float gy = cliffDensity(wx, wy + 0.12f) - cliffDensity(wx, wy - 0.12f);
                            float sun = Math.max(-0.4f, Math.min(1.0f, (-gx - gy) * 2.6f + 0.48f));
                            int cHash = Math.abs(((cxIdx * 37 + c) * 73856093) ^ ((cyIdx * 37 + r) * 19349663));
                            char ch = CLIFF_CHARS.charAt(cHash % CLIFF_CHARS.length());
                            int lum = Math.max(58, Math.min(242, (int) (82 + sun * 135 + (cHash % 28))));
                            cTxt.setColor(Color.rgb(lum - 4, lum, Math.min(255, lum + 10)));
                            mSingleChar[0] = ch;
                            cc.drawText(mSingleChar, 0, 1, px, py + cellPx * 0.86f, cTxt);
                        } else if (dens > 0.56f) {
                            int alpha = (int) (((dens - 0.56f) / 0.12f) * 145.0f);
                            cBg.setColor(Color.argb(alpha, 3, 6, 5));
                            cc.drawRect(px, py, px + cellPx + 1.0f, py + cellPx + 1.0f, cBg);
                        }
                    }
                }
            }
            return mChunkBitmaps[lruIdx];
        }

        private void drawAsciiBufferSpanBatched(
                Canvas canvas, char[] gBuf, int[] cBuf, int bufW, int bufH,
                float originX, float originY, float cellPx,
                boolean darkBacking, int overrideColor
        ) {
            mAsciiPaint.setTextSize(Math.max(5.5f, cellPx * 1.18f));
            mAsciiPaint.setTextAlign(Paint.Align.LEFT);
            for (int r = 0; r < bufH; r++) {
                float drawY = originY + r * cellPx;
                int rowOff = r * bufW;
                int c = 0;
                while (c < bufW) {
                    if (gBuf[rowOff + c] == ' ') {
                        c++;
                        continue;
                    }
                    int startC = c;
                    int firstColor = (overrideColor != 0) ? overrideColor : cBuf[rowOff + c];
                    while (c < bufW && gBuf[rowOff + c] != ' ') {
                        if (overrideColor == 0 && Math.abs(Color.red(cBuf[rowOff + c]) - Color.red(firstColor)) > 36) {
                            break;
                        }
                        c++;
                    }
                    int spanLen = c - startC;
                    float sx = originX + startC * cellPx;
                    if (darkBacking) {
                        mPanelPaint.setColor(Color.argb(230, 5, 7, 9));
                        canvas.drawRect(sx - 1.0f, drawY - cellPx * 0.88f, sx + spanLen * cellPx + 1.0f, drawY + cellPx * 0.16f, mPanelPaint);
                    }
                    mAsciiPaint.setColor(firstColor);
                    canvas.drawText(gBuf, rowOff + startC, spanLen, sx, drawY, mAsciiPaint);
                }
            }
        }

        private void drawFrame() {
            SurfaceHolder holder = getHolder();
            Canvas canvas = null;
            try {
                if (Build.VERSION.SDK_INT >= 26) {
                    canvas = holder.lockHardwareCanvas();
                } else {
                    canvas = holder.lockCanvas();
                }
                if (canvas == null) return;

                ensureStaticCaches();

                int screenW = canvas.getWidth();
                int screenH = canvas.getHeight();
                canvas.drawColor(Color.rgb(7, 11, 10));

                float pixelsPerUnit = Math.min(screenW, screenH) * 0.095f * mCameraZoom;
                float centerX = screenW * 0.5f;
                float centerY = screenH * 0.48f;

                float halfUnitsW = (screenW * 0.5f) / pixelsPerUnit + 1.5f;
                float halfUnitsH = (screenH * 0.5f) / pixelsPerUnit + 1.5f;

                // 1. Pre-baked Chunk Cache (64-slot = zero thrashing, uniform grass scale)
                int minCx = (int) Math.floor((mCamX - halfUnitsW) / CHUNK_WORLD_UNITS);
                int maxCx = (int) Math.floor((mCamX + halfUnitsW) / CHUNK_WORLD_UNITS);
                int minCy = (int) Math.floor((mCamY - halfUnitsH) / CHUNK_WORLD_UNITS);
                int maxCy = (int) Math.floor((mCamY + halfUnitsH) / CHUNK_WORLD_UNITS);
                int[] builtThisFrame = new int[]{0};

                for (int cy = minCy; cy <= maxCy; cy++) {
                    for (int cx = minCx; cx <= maxCx; cx++) {
                        float sx0 = centerX + (cx * CHUNK_WORLD_UNITS - mCamX) * pixelsPerUnit;
                        float sy0 = centerY + (cy * CHUNK_WORLD_UNITS - mCamY) * pixelsPerUnit;
                        float chunkScreenPx = CHUNK_WORLD_UNITS * pixelsPerUnit;
                        mTmpRect.set(sx0, sy0, sx0 + chunkScreenPx + 1.5f, sy0 + chunkScreenPx + 1.5f);
                        Bitmap chunk = getOrBuildChunk(cx, cy, builtThisFrame);
                        if (chunk != null) {
                            canvas.drawBitmap(chunk, null, mTmpRect, mBitmapPaint);
                        } else {
                            int qx = ((cx % 4) + 4) % 4;
                            int qy = ((cy % 4) + 4) % 4;
                            mSrcRect.set(qx * 256, qy * 256, qx * 256 + 256, qy * 256 + 256);
                            canvas.drawBitmap(mMeadowTileBitmap, mSrcRect, mTmpRect, mBitmapPaint);
                        }
                    }
                }

                // 2. Batched Dynamic Wind Grass Tips
                float windScale = (mWindPreset == 0) ? 0.6f : (mWindPreset == 1 ? 1.0f : 1.75f);
                float bladeScreenLen = Math.max(4.5f, pixelsPerUnit * 0.11f);
                mGrassPaint.setStrokeWidth(Math.max(1.2f, pixelsPerUnit * 0.015f));
                int minWx = (int) Math.floor(mCamX - halfUnitsW);
                int maxWx = (int) Math.ceil(mCamX + halfUnitsW);
                int minWy = (int) Math.floor(mCamY - halfUnitsH);
                int maxWy = (int) Math.ceil(mCamY + halfUnitsH);

                int dCount = 0;
                int bCount = 0;
                for (int wy = minWy; wy <= maxWy && (dCount < WIND_BLADES_PER_LAYER || bCount < WIND_BLADES_PER_LAYER); wy++) {
                    for (int wx = minWx; wx <= maxWx; wx++) {
                        if (Math.abs(wy - riverCenterY(wx)) < 2.1f || isCliff(wx, wy)) continue;
                        float sx = centerX + (wx - mCamX) * pixelsPerUnit;
                        float sy = centerY + (wy - mCamY) * pixelsPerUnit;
                        float sway = (float) Math.sin(wx * 0.45f + wy * 0.30f - mTimeSec * 3.4f * windScale) * bladeScreenLen * 0.55f;
                        int h = Math.abs((wx * 19349663) ^ (wy * 83492791));
                        if (dCount < WIND_BLADES_PER_LAYER) {
                            int o = dCount * 4;
                            float ox = ((h & 15) / 15.0f - 0.5f) * pixelsPerUnit * 0.8f;
                            float oy = (((h >> 4) & 15) / 15.0f - 0.5f) * pixelsPerUnit * 0.8f;
                            mWindPtsDark[o] = sx + ox;
                            mWindPtsDark[o + 1] = sy + oy;
                            mWindPtsDark[o + 2] = sx + ox + sway;
                            mWindPtsDark[o + 3] = sy + oy - bladeScreenLen;
                            dCount++;
                        }
                        if (bCount < WIND_BLADES_PER_LAYER && (h % 2 == 0)) {
                            int o = bCount * 4;
                            float ox = (((h >> 8) & 15) / 15.0f - 0.5f) * pixelsPerUnit * 0.8f;
                            float oy = (((h >> 12) & 15) / 15.0f - 0.5f) * pixelsPerUnit * 0.8f;
                            mWindPtsBright[o] = sx + ox;
                            mWindPtsBright[o + 1] = sy + oy;
                            mWindPtsBright[o + 2] = sx + ox + sway * 1.15f;
                            mWindPtsBright[o + 3] = sy + oy - bladeScreenLen * 1.1f;
                            bCount++;
                        }
                    }
                }
                if (dCount > 0) {
                    mGrassPaint.setColor(Color.rgb(42, 104, 48));
                    canvas.drawLines(mWindPtsDark, 0, dCount * 4, mGrassPaint);
                }
                if (bCount > 0) {
                    mGrassPaint.setColor(Color.rgb(98, 172, 92));
                    canvas.drawLines(mWindPtsBright, 0, bCount * 4, mGrassPaint);
                }

                // Moonlit Cave Entrance carved into northern cliff (matching 1000461481.jpg)
                float caveWx = 2.5f;
                float caveWy = -9.2f;
                float caveSx = centerX + (caveWx - mCamX) * pixelsPerUnit;
                float caveSy = centerY + (caveWy - mCamY) * pixelsPerUnit;
                if (caveSx > -260 && caveSx < screenW + 260 && caveSy > -260 && caveSy < screenH + 260) {
                    mShadowPaint.setColor(Color.rgb(4, 6, 9));
                    mTmpRect.set(caveSx - pixelsPerUnit * 1.5f, caveSy - pixelsPerUnit * 1.2f, caveSx + pixelsPerUnit * 1.5f, caveSy + pixelsPerUnit * 1.0f);
                    canvas.drawOval(mTmpRect, mShadowPaint);
                    mTmpRect.set(caveSx - pixelsPerUnit * 2.2f, caveSy - pixelsPerUnit * 2.2f, caveSx + pixelsPerUnit * 2.2f, caveSy + pixelsPerUnit * 2.2f);
                    canvas.drawBitmap(mCyanGlowBitmap, null, mTmpRect, mGlowPaint);
                }

                // Upside-Down Water Reflection of Hero in River (matching 1000461484.jpg!)
                if (Math.abs(mPlayerY - riverCenterY(mPlayerX)) < 3.6f) {
                    float rx = centerX + (mPlayerX - mCamX) * pixelsPerUnit;
                    float ry = centerY + (riverCenterY(mPlayerX) + 0.35f - mCamY) * pixelsPerUnit;
                    int reflCol = Color.argb(95, 140, 175, 205);
                    if (mMounted) {
                        float hCellPx = (pixelsPerUnit * 2.6f) / HORSE_BUF_W;
                        drawAsciiBufferSpanBatched(canvas, mHorseGlyphBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                                rx - (HORSE_BUF_W * 0.5f) * hCellPx, ry, hCellPx, false, reflCol);
                    } else {
                        float fCellPx = (pixelsPerUnit * 2.0f) / FOOT_BUF_W;
                        drawAsciiBufferSpanBatched(canvas, mFootGlyphBuf, mFootColorBuf, FOOT_BUF_W, FOOT_BUF_H,
                                rx - (FOOT_BUF_W * 0.5f) * fCellPx, ry, fCellPx, false, reflCol);
                    }
                }

                // River foam streaks
                mAsciiPaint.setTextSize(Math.max(10.0f, pixelsPerUnit * 0.22f));
                mAsciiPaint.setTextAlign(Paint.Align.LEFT);
                for (int wx = minWx; wx <= maxWx; wx++) {
                    float ry = riverCenterY(wx);
                    float wave = (float) Math.sin(wx * 0.6f - mTimeSec * 2.8f);
                    if (wave > 0.25f) {
                        float sx = centerX + (wx - mCamX) * pixelsPerUnit;
                        float sy = centerY + (ry + (wave - 0.5f) * 0.8f - mCamY) * pixelsPerUnit;
                        mAsciiPaint.setColor(wave > 0.7f ? Color.rgb(215, 225, 235) : Color.rgb(88, 108, 134));
                        canvas.drawText("0Q8~=", sx, sy, mAsciiPaint);
                    }
                }

                // 3. Handcrafted ASCII Houses & Glowing Runestones
                float houseFontPx = Math.max(8.5f, pixelsPerUnit * 0.19f);
                mAsciiPaint.setTextSize(houseFontPx);
                mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                for (int hIdx = 0; hIdx < HOUSE_X.length; hIdx++) {
                    float hx = centerX + (HOUSE_X[hIdx] - mCamX) * pixelsPerUnit;
                    float hy = centerY + (HOUSE_Y[hIdx] - mCamY) * pixelsPerUnit;
                    if (hx < -320 || hx > screenW + 320 || hy < -260 || hy > screenH + 260) continue;

                    float hW = houseFontPx * 13.8f;
                    float hH = HOUSE_ART.length * houseFontPx * 0.90f;
                    mShadowPaint.setColor(Color.argb(180, 4, 7, 6));
                    mTmpRect.set(hx - hW * 0.48f, hy + hH * 0.28f, hx + hW * 0.56f, hy + hH * 0.52f);
                    canvas.drawOval(mTmpRect, mShadowPaint);

                    for (int hr = 0; hr < HOUSE_ART.length; hr++) {
                        float ry = hy - hH * 0.5f + hr * houseFontPx * 0.90f;
                        mPanelPaint.setColor(Color.rgb(7, 9, 11));
                        canvas.drawRect(hx - hW * 0.5f, ry - houseFontPx * 0.82f, hx + hW * 0.5f, ry + houseFontPx * 0.14f, mPanelPaint);
                        mAsciiPaint.setColor(hr < 4 ? Color.rgb(165, 178, 192) : (hr >= 6 ? Color.rgb(248, 200, 110) : Color.rgb(210, 214, 218)));
                        canvas.drawText(HOUSE_ART[hr], hx, ry, mAsciiPaint);
                    }
                }

                // Glowing Shrines (cyan) & Hearth Lantern Braziers + Fences beside houses
                mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                for (int gIdx = 0; gIdx < GLOW_X.length; gIdx++) {
                    float gx = centerX + (GLOW_X[gIdx] - mCamX) * pixelsPerUnit;
                    float gy = centerY + (GLOW_Y[gIdx] - mCamY) * pixelsPerUnit;
                    if (GLOW_IS_CYAN[gIdx]) {
                        mAsciiPaint.setColor(Color.rgb(125, 245, 220));
                        canvas.drawText("[*]", gx, gy, mAsciiPaint);
                    } else {
                        // Flickering hearth brazier & wooden fence beside house
                        boolean flick = ((int) (mTimeSec * 8.0f + gIdx)) % 2 == 0;
                        mAsciiPaint.setColor(flick ? Color.rgb(255, 198, 92) : Color.rgb(242, 146, 68));
                        canvas.drawText(flick ? "(^)" : "(*)", gx + pixelsPerUnit * 1.45f, gy - pixelsPerUnit * 0.15f, mAsciiPaint);
                        mAsciiPaint.setColor(Color.rgb(138, 114, 86));
                        canvas.drawText("|--|--|", gx - pixelsPerUnit * 1.55f, gy + pixelsPerUnit * 0.15f, mAsciiPaint);
                    }
                }

                // Harvestable Flora Nodes
                mAsciiPaint.setTextSize(Math.max(10.0f, pixelsPerUnit * 0.20f));
                mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                for (int f = 0; f < NUM_FLORA; f++) {
                    if (mFloraRegrow[f] > 0.0f) continue;
                    float fx = centerX + (mFloraX[f] - mCamX) * pixelsPerUnit;
                    float fy = centerY + (mFloraY[f] - mCamY) * pixelsPerUnit;
                    if (fx < -80 || fx > screenW + 80 || fy < -80 || fy > screenH + 80) continue;
                    if (mFloraKind[f] == 0) {
                        mAsciiPaint.setColor(Color.rgb(175, 225, 255));
                        canvas.drawText("(*)", fx, fy, mAsciiPaint);
                    } else if (mFloraKind[f] == 1) {
                        mAsciiPaint.setColor(Color.rgb(255, 175, 95));
                        canvas.drawText("{@}", fx, fy, mAsciiPaint);
                    } else {
                        mAsciiPaint.setColor(Color.rgb(135, 238, 165));
                        canvas.drawText("[#]", fx, fy, mAsciiPaint);
                    }
                }

                // Ambient Fauna (Deer, Rabbits, Birds, River Koi)
                mAsciiPaint.setTextSize(Math.max(9.5f, pixelsPerUnit * 0.19f));
                for (int a = 0; a < NUM_FAUNA; a++) {
                    float ax = centerX + (mFaunaX[a] - mCamX) * pixelsPerUnit;
                    float ay = centerY + (mFaunaY[a] - mCamY) * pixelsPerUnit;
                    if (ax < -100 || ax > screenW + 100 || ay < -100 || ay > screenH + 100) continue;
                    float hop = Math.abs((float) Math.sin(mFaunaPhase[a])) * pixelsPerUnit * 0.14f;
                    if (mFaunaKind[a] == 0) {
                        mAsciiPaint.setColor(Color.rgb(212, 178, 134));
                        canvas.drawText(mFaunaVx[a] >= 0 ? "^..^>" : "<^..^", ax, ay - hop * 0.6f, mAsciiPaint);
                    } else if (mFaunaKind[a] == 1) {
                        mAsciiPaint.setColor(Color.rgb(238, 240, 235));
                        canvas.drawText("()o", ax, ay - hop, mAsciiPaint);
                    } else if (mFaunaKind[a] == 2) {
                        boolean flap = ((int) (mFaunaPhase[a] * 1.8f)) % 2 == 0;
                        mAsciiPaint.setColor(Color.rgb(185, 198, 215));
                        canvas.drawText(flap ? "\\v/" : "-v-", ax, ay - pixelsPerUnit * 0.35f - hop, mAsciiPaint);
                    } else {
                        mAsciiPaint.setColor(Color.rgb(245, 165, 115));
                        canvas.drawText(mFaunaVx[a] >= 0 ? "<><" : "><>", ax, ay, mAsciiPaint);
                    }
                }

                // 4. Loot + Animated Humanoid Enemies + Hero + Afterimages
                mAsciiPaint.setTextAlign(Paint.Align.LEFT);
                for (int lIdx = 0; lIdx < MAX_LOOT; lIdx++) {
                    if (mLootActive[lIdx]) {
                        float lx = centerX + (mLootX[lIdx] - mCamX) * pixelsPerUnit;
                        float ly = centerY + (mLootY[lIdx] - mCamY) * pixelsPerUnit;
                        mAsciiPaint.setColor(Color.rgb(245, 212, 98));
                        canvas.drawText("@WM#*+", lx - pixelsPerUnit * 0.3f, ly, mAsciiPaint);
                    }
                }

                float enemyCellPx = (pixelsPerUnit * 2.25f) / ENEMY_BUF_W;
                for (int eIdx = 0; eIdx < NUM_ENEMIES; eIdx++) {
                    float ex = centerX + (mEnemyX[eIdx] - mCamX) * pixelsPerUnit;
                    float ey = centerY + (mEnemyY[eIdx] - mCamY) * pixelsPerUnit;
                    if (ex < -140 || ex > screenW + 140 || ey < -140 || ey > screenH + 140) continue;

                    mShadowPaint.setColor(Color.argb(175, 5, 8, 7));
                    mTmpRect.set(ex - pixelsPerUnit * 0.36f, ey + pixelsPerUnit * 0.14f, ex + pixelsPerUnit * 0.56f, ey + pixelsPerUnit * 0.44f);
                    canvas.drawOval(mTmpRect, mShadowPaint);

                    rasterizeEnemyHumanoidAscii(eIdx);
                    int tint = 0;
                    if (mEnemyHurt[eIdx] > 0.0f) tint = Color.rgb(242, 82, 82);
                    else if (mEnemyAtkWindup[eIdx] > 0.0f) tint = Color.rgb(255, 175, 95);
                    drawAsciiBufferSpanBatched(
                            canvas, mEnemyGlyphBuf, mEnemyColorBuf, ENEMY_BUF_W, ENEMY_BUF_H,
                            ex - (ENEMY_BUF_W * 0.5f) * enemyCellPx,
                            ey - (ENEMY_BUF_H * 0.65f) * enemyCellPx,
                            enemyCellPx, true, tint
                    );
                }

                // Dodge Afterimage Ghosts
                for (int g = 0; g < MAX_AFTERIMAGES; g++) {
                    if (mGhostLife[g] > 0.0f) {
                        float gx = centerX + (mGhostX[g] - mCamX) * pixelsPerUnit;
                        float gy = centerY + (mGhostY[g] - mCamY) * pixelsPerUnit;
                        int alpha = Math.max(30, Math.min(180, (int) ((mGhostLife[g] / 0.24f) * 165.0f)));
                        int gCol = Color.argb(alpha, 150, 240, 225);
                        if (mMounted) {
                            float hCellPx = (pixelsPerUnit * 3.15f) / HORSE_BUF_W;
                            drawAsciiBufferSpanBatched(
                                    canvas, mHorseGlyphBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                                    gx - (HORSE_BUF_W * 0.5f) * hCellPx,
                                    gy - (HORSE_BUF_H * 0.56f) * hCellPx,
                                    hCellPx, false, gCol
                            );
                        } else {
                            float fCellPx = (pixelsPerUnit * 2.45f) / FOOT_BUF_W;
                            drawAsciiBufferSpanBatched(
                                    canvas, mFootGlyphBuf, mFootColorBuf, FOOT_BUF_W, FOOT_BUF_H,
                                    gx - (FOOT_BUF_W * 0.5f) * fCellPx,
                                    gy - (FOOT_BUF_H * 0.62f) * fCellPx,
                                    fCellPx, false, gCol
                            );
                        }
                    }
                }

                if (mMounted) {
                    float hCellPx = (pixelsPerUnit * 3.15f) / HORSE_BUF_W;
                    float hx = centerX + (mPlayerX - mCamX) * pixelsPerUnit;
                    float hy = centerY + (mPlayerY - mCamY) * pixelsPerUnit;
                    mShadowPaint.setColor(Color.argb(185, 4, 7, 6));
                    mTmpRect.set(hx - pixelsPerUnit * 0.9f, hy + pixelsPerUnit * 0.15f, hx + pixelsPerUnit * 1.0f, hy + pixelsPerUnit * 0.78f);
                    canvas.drawOval(mTmpRect, mShadowPaint);
                    drawAsciiBufferSpanBatched(
                            canvas, mHorseGlyphBuf, mHorseColorBuf, HORSE_BUF_W, HORSE_BUF_H,
                            hx - (HORSE_BUF_W * 0.5f) * hCellPx,
                            hy - (HORSE_BUF_H * 0.56f) * hCellPx,
                            hCellPx, true, mPlayerHurtFlash > 0.0f ? Color.rgb(255, 95, 95) : 0
                    );
                } else {
                    float fCellPx = (pixelsPerUnit * 2.45f) / FOOT_BUF_W;
                    float hx = centerX + (mPlayerX - mCamX) * pixelsPerUnit;
                    float hy = centerY + (mPlayerY - mCamY) * pixelsPerUnit;
                    mShadowPaint.setColor(Color.argb(185, 4, 7, 6));
                    mTmpRect.set(hx - pixelsPerUnit * 0.35f, hy + pixelsPerUnit * 0.18f, hx + pixelsPerUnit * 0.75f, hy + pixelsPerUnit * 0.52f);
                    canvas.drawOval(mTmpRect, mShadowPaint);

                    mAsciiPaint.setTextSize(Math.max(11.0f, pixelsPerUnit * 0.18f));
                    mAsciiPaint.setColor(Color.rgb(232, 236, 234));
                    mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                    canvas.drawText("Ashveil", hx, hy - (FOOT_BUF_H * 0.68f) * fCellPx, mAsciiPaint);

                    drawAsciiBufferSpanBatched(
                            canvas, mFootGlyphBuf, mFootColorBuf, FOOT_BUF_W, FOOT_BUF_H,
                            hx - (FOOT_BUF_W * 0.5f) * fCellPx,
                            hy - (FOOT_BUF_H * 0.62f) * fCellPx,
                            fCellPx, true, mPlayerHurtFlash > 0.0f ? Color.rgb(255, 95, 95) : 0
                    );
                }

                // Ash / Spark / Firefly Particles
                mAsciiPaint.setTextSize(Math.max(10.0f, pixelsPerUnit * 0.17f));
                mAsciiPaint.setTextAlign(Paint.Align.LEFT);
                for (int pIdx = 0; pIdx < MAX_PARTICLES; pIdx++) {
                    if (mPartLife[pIdx] > 0.0f) {
                        float px = centerX + (mPartX[pIdx] - mCamX) * pixelsPerUnit;
                        float py = centerY + (mPartY[pIdx] - mCamY) * pixelsPerUnit;
                        mAsciiPaint.setColor(mPartColor[pIdx]);
                        canvas.drawText("*", px, py, mAsciiPaint);
                    }
                }

                // Multi-layered Greatsword Slash Crescent
                if (mSlashTimer > 0.0f) {
                    mAsciiPaint.setTextSize(Math.max(13.0f, pixelsPerUnit * 0.26f));
                    float hx = centerX + (mPlayerX - mCamX) * pixelsPerUnit;
                    float hy = centerY + (mPlayerY - mCamY) * pixelsPerUnit;
                    float baseAng = (float) Math.atan2(mFacingY, mFacingX);
                    for (int a = -6; a <= 6; a++) {
                        float ang = baseAng + a * 0.21f;
                        float rx = hx + (float) Math.cos(ang) * pixelsPerUnit * 1.50f;
                        float ry = hy + (float) Math.sin(ang) * pixelsPerUnit * 1.20f;
                        mAsciiPaint.setColor(Math.abs(a) <= 2 ? Color.rgb(245, 252, 248) : Color.rgb(145, 235, 220));
                        int sIdx = (a + 6) % 4;
                        canvas.drawText("@W#*+", sIdx, sIdx + 1, rx, ry, mAsciiPaint);
                    }
                }

                // Floating Damage Popups
                mUiPaint.setTextAlign(Paint.Align.CENTER);
                mUiPaint.setTextSize(Math.max(14.0f, pixelsPerUnit * 0.22f));
                for (int k = 0; k < MAX_POPUPS; k++) {
                    if (mPopLife[k] > 0.0f && mPopText[k] != null) {
                        float px = centerX + (mPopX[k] - mCamX) * pixelsPerUnit;
                        float py = centerY + (mPopY[k] - mCamY) * pixelsPerUnit;
                        mUiPaint.setColor(mPopColor[k]);
                        canvas.drawText(mPopText[k], px, py, mUiPaint);
                    }
                }

                // 5. Additive Glowing Lanterns & Runestones + Misty Fog + Vignette
                for (int gIdx = 0; gIdx < GLOW_X.length; gIdx++) {
                    float gx = centerX + (GLOW_X[gIdx] - mCamX) * pixelsPerUnit;
                    float gy = centerY + (GLOW_Y[gIdx] - mCamY) * pixelsPerUnit;
                    float gRad = pixelsPerUnit * (2.6f + 0.25f * (float) Math.sin(mTimeSec * 3.5f + gIdx));
                    mTmpRect.set(gx - gRad, gy - gRad, gx + gRad, gy + gRad);
                    canvas.drawBitmap(GLOW_IS_CYAN[gIdx] ? mCyanGlowBitmap : mAmberGlowBitmap, null, mTmpRect, mGlowPaint);
                }

                for (int fIdx = 0; fIdx < 4; fIdx++) {
                    float fx = (float) (((mTimeSec * (18.0f + fIdx * 7.0f) + fIdx * 310.0f) % (screenW + 400)) - 200.0f);
                    float fy = screenH * (0.20f + fIdx * 0.22f) + (float) Math.sin(mTimeSec * 0.4f + fIdx) * 45.0f;
                    float fRad = Math.min(screenW, screenH) * (0.28f + (fIdx % 2) * 0.10f);
                    mTmpRect.set(fx - fRad, fy - fRad, fx + fRad, fy + fRad);
                    canvas.drawBitmap(mFogBitmap, null, mTmpRect, mBitmapPaint);
                }

                mTmpRect.set(0, 0, screenW, screenH);
                canvas.drawBitmap(mVignetteBitmap, null, mTmpRect, mBitmapPaint);

                // 6. Clean Modern Non-ASCII GUI Overlays
                if (mScreenMode == 0) {
                    drawStartMenuOverlay(canvas, screenW, screenH);
                } else if (mScreenMode == 1) {
                    drawModernHud(canvas, screenW, screenH);
                } else if (mScreenMode == 2) {
                    drawCharacterAndInventoryModal(canvas, screenW, screenH);
                }
            } finally {
                if (canvas != null) {
                    holder.unlockCanvasAndPost(canvas);
                }
            }
        }

        private void drawStartMenuOverlay(Canvas canvas, int w, int h) {
            mPanelPaint.setColor(Color.argb(120, 5, 9, 8));
            canvas.drawRect(0, 0, w, h, mPanelPaint);

            mUiPaint.setTextAlign(Paint.Align.CENTER);
            float titleSize = Math.min(w, h) * 0.085f;
            mUiPaint.setTextSize(titleSize);
            mUiPaint.setColor(Color.rgb(244, 248, 245));
            canvas.drawText("A S H V E I L", w * 0.5f, h * 0.25f, mUiPaint);

            mUiSubPaint.setTextAlign(Paint.Align.CENTER);
            mUiSubPaint.setTextSize(titleSize * 0.36f);
            mUiSubPaint.setColor(Color.rgb(185, 204, 194));
            canvas.drawText("Offline Dark-Fantasy ASCII RPG", w * 0.5f, h * 0.31f, mUiSubPaint);

            float btnTextSize = Math.min(w, h) * 0.033f;
            mUiPaint.setTextSize(btnTextSize);

            String zoomLabel = (mZoomPreset == 0) ? "Close-up" : (mZoomPreset == 1 ? "Medium" : "Wide");
            String modeLabel = mMounted ? "Mounted Steed" : "Foot Knight";
            String atkLabel = mAttackButtonOnly ? "Action Button" : "Tap Anywhere";

            String[] buttons = {
                    "Enter the World",
                    "Camera Zoom: " + zoomLabel,
                    "Style: " + modeLabel,
                    "Attack Mode: " + atkLabel,
                    "Character, Inventory & Forge (Lv." + mLevel + ")"
            };
            float[] yTops = {0.39f, 0.49f, 0.59f, 0.69f, 0.79f};
            for (int b = 0; b < buttons.length; b++) {
                float top = h * yTops[b];
                float bot = top + h * 0.078f;
                mTmpRect.set(w * 0.22f, top, w * 0.78f, bot);
                mPanelPaint.setColor(b == 0 ? Color.argb(235, 24, 56, 40) : Color.argb(220, 12, 18, 16));
                canvas.drawRoundRect(mTmpRect, 14f, 14f, mPanelPaint);
                mBorderPaint.setColor(b == 0 ? Color.rgb(155, 232, 185) : Color.rgb(85, 110, 98));
                canvas.drawRoundRect(mTmpRect, 14f, 14f, mBorderPaint);
                mUiPaint.setColor(Color.rgb(242, 246, 244));
                canvas.drawText(buttons[b], w * 0.5f, (top + bot) * 0.5f + btnTextSize * 0.35f, mUiPaint);
            }
        }

        private void drawModernHud(Canvas canvas, int w, int h) {
            // Top-Left Modern Status Card (Non-ASCII!)
            float cardW = Math.min(w * 0.36f, 390.0f);
            float cardH = Math.min(h * 0.145f, 148.0f);
            float x0 = 18.0f;
            float y0 = 18.0f;

            mTmpRect.set(x0, y0, x0 + cardW, y0 + cardH);
            mPanelPaint.setColor(Color.argb(215, 11, 16, 15));
            canvas.drawRoundRect(mTmpRect, 16f, 16f, mPanelPaint);
            mBorderPaint.setColor(Color.argb(180, 110, 140, 125));
            canvas.drawRoundRect(mTmpRect, 16f, 16f, mBorderPaint);

            float pad = 14.0f;
            float titlePx = cardH * 0.19f;
            mUiPaint.setTextAlign(Paint.Align.LEFT);
            mUiPaint.setTextSize(titlePx);
            mUiPaint.setColor(Color.rgb(242, 246, 244));
            canvas.drawText("Ashveil", x0 + pad, y0 + pad + titlePx * 0.85f, mUiPaint);

            mUiSubPaint.setTextAlign(Paint.Align.RIGHT);
            mUiSubPaint.setTextSize(titlePx * 0.72f);
            mUiSubPaint.setColor(Color.rgb(235, 206, 118));
            canvas.drawText("LV " + mLevel + "  •  " + mGold + "g", x0 + cardW - pad, y0 + pad + titlePx * 0.85f, mUiSubPaint);

            // Smooth HP Bar
            float barX = x0 + pad;
            float barW = cardW - pad * 2.0f;
            float barH = Math.max(10.0f, cardH * 0.13f);
            float hpY = y0 + pad + titlePx * 1.35f;
            float hpRatio = Math.max(0.0f, Math.min(1.0f, mHp / (float) Math.max(1, mMaxHp)));

            mTmpRect.set(barX, hpY, barX + barW, hpY + barH);
            mPanelPaint.setColor(Color.rgb(34, 18, 20));
            canvas.drawRoundRect(mTmpRect, 6f, 6f, mPanelPaint);
            mTmpRect.set(barX, hpY, barX + barW * hpRatio, hpY + barH);
            mPanelPaint.setColor(Color.rgb(212, 68, 76));
            canvas.drawRoundRect(mTmpRect, 6f, 6f, mPanelPaint);

            mUiSubPaint.setTextAlign(Paint.Align.LEFT);
            mUiSubPaint.setTextSize(barH * 0.85f);
            mUiSubPaint.setColor(Color.rgb(245, 245, 245));
            canvas.drawText("HP " + mHp + " / " + mMaxHp, barX + 6f, hpY + barH * 0.82f, mUiSubPaint);

            // Smooth MP Bar
            float mpY = hpY + barH + 8.0f;
            float mpRatio = Math.max(0.0f, Math.min(1.0f, mMp / (float) Math.max(1, mMaxMp)));
            mTmpRect.set(barX, mpY, barX + barW, mpY + barH);
            mPanelPaint.setColor(Color.rgb(16, 26, 38));
            canvas.drawRoundRect(mTmpRect, 6f, 6f, mPanelPaint);
            mTmpRect.set(barX, mpY, barX + barW * mpRatio, mpY + barH);
            mPanelPaint.setColor(Color.rgb(66, 152, 224));
            canvas.drawRoundRect(mTmpRect, 6f, 6f, mPanelPaint);
            canvas.drawText("MP " + mMp + " / " + mMaxMp, barX + 6f, mpY + barH * 0.82f, mUiSubPaint);

            mUiSubPaint.setTextSize(titlePx * 0.62f);
            mUiSubPaint.setColor(Color.rgb(165, 210, 185));
            canvas.drawText("Tap card for Inventory & Forge" + (mStatPoints > 0 ? " (" + mStatPoints + " pts!)" : ""), barX, y0 + cardH - 10.0f, mUiSubPaint);

            // Top-Right Modern Pill Buttons: Menu, Zoom, Steed
            float pillW = Math.min(w * 0.18f, 172.0f);
            float pillH = Math.max(36.0f, cardH * 0.34f);
            float px = w - pillW - 18.0f;

            String[] pills = {"Menu", "Zoom", mMounted ? "Dismount" : "Steed"};
            for (int i = 0; i < 3; i++) {
                float py = y0 + i * (pillH + 8.0f);
                mTmpRect.set(px, py, px + pillW, py + pillH);
                boolean activeSteed = (i == 2 && mMounted);
                mPanelPaint.setColor(activeSteed ? Color.argb(230, 26, 62, 44) : Color.argb(215, 12, 18, 16));
                canvas.drawRoundRect(mTmpRect, 12f, 12f, mPanelPaint);
                mBorderPaint.setColor(activeSteed ? Color.rgb(155, 232, 185) : Color.rgb(95, 118, 108));
                canvas.drawRoundRect(mTmpRect, 12f, 12f, mBorderPaint);
                mUiPaint.setTextAlign(Paint.Align.CENTER);
                mUiPaint.setTextSize(pillH * 0.42f);
                mUiPaint.setColor(Color.rgb(240, 245, 242));
                canvas.drawText(pills[i], px + pillW * 0.5f, py + pillH * 0.64f, mUiPaint);
            }

            // Bottom-Right Modern Action Buttons: ATK and DODGE
            float atkR = Math.min(w, h) * 0.088f;
            float atkCx = w - atkR - 26.0f;
            float atkCy = h - atkR - 26.0f;
            mPanelPaint.setColor(mSlashTimer > 0.0f ? Color.argb(235, 62, 108, 82) : Color.argb(215, 14, 22, 18));
            mBorderPaint.setColor(mSlashCooldown > 0.0f ? Color.rgb(110, 128, 120) : Color.rgb(195, 235, 210));
            canvas.drawCircle(atkCx, atkCy, atkR, mPanelPaint);
            canvas.drawCircle(atkCx, atkCy, atkR, mBorderPaint);
            mUiPaint.setTextSize(atkR * 0.42f);
            mUiPaint.setColor(Color.rgb(245, 248, 246));
            canvas.drawText("ATK", atkCx, atkCy + atkR * 0.15f, mUiPaint);

            float dodgeR = Math.min(w, h) * 0.070f;
            float dodgeCx = atkCx - atkR - dodgeR - 22.0f;
            float dodgeCy = h - dodgeR - 26.0f;
            mPanelPaint.setColor(mDodgeTimer > 0.0f ? Color.argb(235, 42, 98, 106) : Color.argb(215, 12, 18, 20));
            mBorderPaint.setColor(mDodgeCooldown > 0.0f ? Color.rgb(95, 112, 118) : Color.rgb(145, 228, 220));
            canvas.drawCircle(dodgeCx, dodgeCy, dodgeR, mPanelPaint);
            canvas.drawCircle(dodgeCx, dodgeCy, dodgeR, mBorderPaint);
            mUiPaint.setTextSize(dodgeR * 0.36f);
            mUiPaint.setColor(mDodgeCooldown > 0.0f ? Color.rgb(145, 162, 166) : Color.rgb(210, 246, 242));
            canvas.drawText(mDodgeCooldown > 0.0f ? (((int) (mDodgeCooldown * 10.0f + 0.9f) / 10.0f) + "s") : "DODGE", dodgeCx, dodgeCy + dodgeR * 0.14f, mUiPaint);

            // Virtual Joystick Ring
            if (mMovePointerId != -1) {
                mBorderPaint.setColor(Color.argb(130, 195, 228, 210));
                canvas.drawCircle(mJoyBaseX, mJoyBaseY, Math.min(w, h) * 0.11f, mBorderPaint);
                mPanelPaint.setColor(Color.argb(150, 215, 240, 225));
                canvas.drawCircle(mJoyCurrX, mJoyCurrY, Math.min(w, h) * 0.036f, mPanelPaint);
            }

            // Bottom XP Bar + 1..0 Quick Hotbar (matching reference!)
            float hbW = Math.min(w * 0.46f, 440.0f);
            float hbX = (w - hbW) * 0.5f;
            float hbY = h - 54.0f;
            float xpRatio = Math.max(0.0f, Math.min(1.0f, mXp / (float) Math.max(1, mXpNext)));
            mTmpRect.set(hbX, hbY - 16.0f, hbX + hbW, hbY - 6.0f);
            mPanelPaint.setColor(Color.rgb(22, 26, 24));
            canvas.drawRect(mTmpRect, mPanelPaint);
            mTmpRect.set(hbX, hbY - 16.0f, hbX + hbW * xpRatio, hbY - 6.0f);
            mPanelPaint.setColor(Color.rgb(218, 182, 92));
            canvas.drawRect(mTmpRect, mPanelPaint);

            mUiSubPaint.setTextAlign(Paint.Align.CENTER);
            mUiSubPaint.setTextSize(11.0f);
            mUiSubPaint.setColor(Color.rgb(232, 236, 234));
            canvas.drawText("LV " + mLevel + " · " + mXp + " / " + mXpNext + " XP", w * 0.5f, hbY - 20.0f, mUiSubPaint);

            float slotW = hbW / 10.0f;
            for (int s = 0; s < 10; s++) {
                float sx0 = hbX + s * slotW;
                mTmpRect.set(sx0 + 1.5f, hbY, sx0 + slotW - 1.5f, hbY + 34.0f);
                mPanelPaint.setColor(Color.argb(215, 10, 14, 13));
                canvas.drawRect(mTmpRect, mPanelPaint);
                mBorderPaint.setColor(s == 0 ? Color.rgb(145, 225, 195) : Color.rgb(75, 90, 84));
                canvas.drawRect(mTmpRect, mBorderPaint);
                mUiSubPaint.setColor(Color.rgb(175, 185, 180));
                canvas.drawText(String.valueOf((s + 1) % 10), sx0 + slotW * 0.5f, hbY + 13.0f, mUiSubPaint);
                if (s == 0 && mPotions > 0) {
                    mUiSubPaint.setColor(Color.rgb(155, 245, 215));
                    canvas.drawText("x" + mPotions, sx0 + slotW * 0.5f, hbY + 28.0f, mUiSubPaint);
                }
            }

            if (mBannerTimer > 0.0f) {
                mUiSubPaint.setTextAlign(Paint.Align.CENTER);
                mUiSubPaint.setTextSize(Math.min(w, h) * 0.026f);
                mUiSubPaint.setColor(Color.rgb(245, 238, 195));
                canvas.drawText(mStatusBanner, w * 0.5f, hbY - 38.0f, mUiSubPaint);
            }
        }

        private void drawCharacterAndInventoryModal(Canvas canvas, int w, int h) {
            // Pure Black Forge Canvas matching `1000461485.jpg` (Chainmail test)!
            mPanelPaint.setColor(Color.rgb(4, 5, 6));
            canvas.drawRect(0, 0, w, h, mPanelPaint);

            String[] slots = {"Helm", "Shoulders", "Chest", "Gloves", "Legs", "Boots"};
            String[] runes = {"^", "*", "z", "~", ">", "/", "x", "v", "o", "\u00a7", "+"};
            String[] metals = {"Iron", "Steel", "Bronze", "Silver", "Gold", "Moonsteel", "Nightglass", "Bloodiron", "Ossite", "Emberstone"};
            int[] metalCols = {
                    Color.rgb(185, 192, 198), Color.rgb(218, 226, 234), Color.rgb(208, 152, 96),
                    Color.rgb(238, 242, 248), Color.rgb(246, 212, 92), Color.rgb(156, 208, 250),
                    Color.rgb(142, 128, 196), Color.rgb(220, 78, 86), Color.rgb(225, 218, 196),
                    Color.rgb(248, 146, 72)
            };

            float ts = Math.min(w, h) * 0.025f;
            mUiPaint.setTextSize(ts);
            mUiSubPaint.setTextSize(ts * 0.88f);

            // 1. Slot Tabs
            float slotW = (w * 0.88f) / 6.0f;
            for (int i = 0; i < 6; i++) {
                float sx = w * 0.06f + i * slotW;
                mTmpRect.set(sx + 2f, h * 0.05f, sx + slotW - 2f, h * 0.11f);
                mPanelPaint.setColor(i == mForgeSlot ? Color.rgb(34, 42, 32) : Color.rgb(12, 14, 16));
                canvas.drawRect(mTmpRect, mPanelPaint);
                mBorderPaint.setColor(i == mForgeSlot ? Color.rgb(218, 212, 145) : Color.rgb(68, 74, 78));
                canvas.drawRect(mTmpRect, mBorderPaint);
                mUiPaint.setTextAlign(Paint.Align.CENTER);
                mUiPaint.setColor(Color.rgb(235, 238, 236));
                canvas.drawText(slots[i], sx + slotW * 0.5f, h * 0.088f, mUiPaint);
            }

            // 2. Rune Palette Row
            float rW = (w * 0.88f) / 11.0f;
            for (int i = 0; i < 11; i++) {
                float rx = w * 0.06f + i * rW;
                mTmpRect.set(rx + 2f, h * 0.13f, rx + rW - 2f, h * 0.20f);
                mPanelPaint.setColor(Color.rgb(10, 12, 14));
                canvas.drawRect(mTmpRect, mPanelPaint);
                mBorderPaint.setColor(Color.rgb(65, 72, 76));
                canvas.drawRect(mTmpRect, mBorderPaint);
                mAsciiPaint.setTextAlign(Paint.Align.CENTER);
                mAsciiPaint.setTextSize(ts * 1.1f);
                mAsciiPaint.setColor(i % 2 == 0 ? Color.rgb(228, 232, 236) : Color.rgb(145, 228, 190));
                canvas.drawText(runes[i], rx + rW * 0.5f, h * 0.178f, mAsciiPaint);
            }

            // 3. Metal Material Grid (2 rows x 5)
            float mW = (w * 0.88f) / 5.0f;
            for (int i = 0; i < 10; i++) {
                int row = i / 5;
                int col = i % 5;
                float mx = w * 0.06f + col * mW;
                float my = h * (0.22f + row * 0.042f);
                mTmpRect.set(mx + 2f, my, mx + mW - 2f, my + h * 0.038f);
                mPanelPaint.setColor(i == mForgeMetal ? Color.rgb(28, 34, 28) : Color.rgb(10, 12, 13));
                canvas.drawRect(mTmpRect, mPanelPaint);
                mBorderPaint.setColor(i == mForgeMetal ? metalCols[i] : Color.rgb(55, 60, 64));
                canvas.drawRect(mTmpRect, mBorderPaint);
                mUiSubPaint.setTextAlign(Paint.Align.CENTER);
                mUiSubPaint.setColor(metalCols[i]);
                canvas.drawText(metals[i], mx + mW * 0.5f, my + h * 0.026f, mUiSubPaint);
            }

            // 4. Live Rotating 3D ASCII Chainmail Coif / Armor Preview (Center-Left, matching 1000461485.jpg!)
            float coifCx = w * 0.40f;
            float coifCy = h * 0.58f;
            float coifR = Math.min(w, h) * 0.20f;
            String chainChars = "S8$#c( )35";
            mAsciiPaint.setTextAlign(Paint.Align.CENTER);
            mAsciiPaint.setTextSize(Math.max(9.0f, coifR * 0.09f));
            int rings = 16;
            for (int yr = -rings; yr <= rings; yr++) {
                float ny = yr / (float) rings;
                float profile = (ny < -0.15f) ? (float) Math.sqrt(Math.max(0.0f, 1.0f - ((ny + 0.35f) * (ny + 0.35f)) * 1.4f)) * 0.58f
                        : (0.56f + (ny + 0.15f) * 0.48f);
                int cols = Math.max(4, (int) (profile * 22));
                for (int xc = -cols; xc <= cols; xc++) {
                    float angle = (xc / (float) Math.max(1, cols)) * (float) Math.PI + mCoifRot;
                    float nz = (float) Math.cos(angle);
                    if (nz < -0.15f) continue;
                    // Dark visor opening in upper-front
                    if (ny > -0.45f && ny < -0.12f && Math.abs((float) Math.sin(angle)) < 0.32f && nz > 0.4f) continue;
                    float sx = coifCx + (float) Math.sin(angle) * profile * coifR;
                    float sy = coifCy + ny * coifR * 1.05f;
                    int lum = Math.max(60, Math.min(250, (int) (nz * 195 + 55)));
                    int baseC = metalCols[mForgeMetal];
                    mAsciiPaint.setColor(Color.rgb(
                            (Color.red(baseC) * lum) / 255,
                            (Color.green(baseC) * lum) / 255,
                            (Color.blue(baseC) * lum) / 255
                    ));
                    mSingleChar[0] = chainChars.charAt(Math.abs(yr * 7 + xc * 3) % chainChars.length());
                    canvas.drawText(mSingleChar, 0, 1, sx, sy, mAsciiPaint);
                }
            }

            // 5. Right Panel: Enchant Slots & Stats
            float rpX = w * 0.72f;
            mUiSubPaint.setTextAlign(Paint.Align.LEFT);
            mUiSubPaint.setColor(Color.rgb(185, 195, 192));
            canvas.drawText("Enchant slots", rpX, h * 0.36f, mUiSubPaint);
            for (int e = 0; e < 2; e++) {
                float ex = rpX + e * (w * 0.11f);
                mTmpRect.set(ex, h * 0.38f, ex + w * 0.09f, h * 0.47f);
                mPanelPaint.setColor(Color.rgb(12, 14, 16));
                canvas.drawRect(mTmpRect, mPanelPaint);
                mBorderPaint.setColor(Color.rgb(95, 105, 108));
                canvas.drawRect(mTmpRect, mBorderPaint);
                int rIdx = (e == 0) ? mRuneSlot1 : mRuneSlot2;
                mAsciiPaint.setTextSize(ts * 1.3f);
                mAsciiPaint.setColor(rIdx >= 0 ? Color.rgb(165, 245, 220) : Color.rgb(110, 120, 122));
                canvas.drawText(rIdx >= 0 ? runes[rIdx] : "+", ex + w * 0.045f, h * 0.435f, mAsciiPaint);
            }
            canvas.drawText("Metal: " + metals[mForgeMetal], rpX, h * 0.53f, mUiSubPaint);
            int rCount = (mRuneSlot1 >= 0 ? 1 : 0) + (mRuneSlot2 >= 0 ? 1 : 0);
            canvas.drawText("Runes: " + rCount + " / 2", rpX, h * 0.58f, mUiSubPaint);
            canvas.drawText("LV " + mLevel + " · " + mGold + "g", rpX, h * 0.65f, mUiSubPaint);
            canvas.drawText("HP " + mHp + "/" + mMaxHp, rpX, h * 0.70f, mUiSubPaint);
            canvas.drawText("Moonpetal: " + mHerbMoon, rpX, h * 0.76f, mUiSubPaint);
            canvas.drawText("Ashmoss: " + mHerbMoss, rpX, h * 0.81f, mUiSubPaint);

            // Bottom Action Bar
            String[] botLabels = {"+Stat (" + mStatPoints + ")", "Craft Potion", "Return to World"};
            float[] botX0 = {w * 0.06f, w * 0.38f, w * 0.72f};
            float[] botX1 = {w * 0.36f, w * 0.70f, w * 0.94f};
            for (int b = 0; b < 3; b++) {
                mTmpRect.set(botX0[b], h * 0.88f, botX1[b], h * 0.95f);
                mPanelPaint.setColor(b == 2 ? Color.rgb(26, 48, 38) : Color.rgb(16, 22, 20));
                canvas.drawRect(mTmpRect, mPanelPaint);
                mBorderPaint.setColor(Color.rgb(95, 118, 108));
                canvas.drawRect(mTmpRect, mBorderPaint);
                mUiPaint.setTextAlign(Paint.Align.CENTER);
                mUiPaint.setColor(Color.rgb(238, 244, 240));
                canvas.drawText(botLabels[b], (botX0[b] + botX1[b]) * 0.5f, h * 0.925f, mUiPaint);
            }
        }
    }
}
