# Ashveil rendering overhaul — patch notes

This is a source-level repair pass based on the supplied Android project.

## Changes
- Replaced the sphere-only player mannequin with a segmented armored humanoid built from indexed box geometry (torso, pelvis, thighs, greaves, boots, shoulders, arms, gauntlets, helmet, visor, crest, belt and sword).
- Added a 64-cell terrain grid with deterministic low-amplitude terrain elevation and a carved river channel.
- Matched grass blade base height and character/tree/rock placement to the terrain height function.
- Expanded the deterministic grass field and changed its edge handling to radial fading to hide the hard square boundary.
- Kept grass visible in solid debug mode and added a solid-color grass debug path.
- Changed world-object ASCII glyph placement from screen-space cells to surface-projected cells.
- Replaced tree trunks with box geometry and added layered canopy clusters and more deterministic tree placements.
- Added shader compile/link diagnostics so GLSL failures are logged rather than silently producing a broken scene.
- Removed the private signing keystore from the archive and removed hardcoded signing passwords from Gradle.

## Build / verification status
- Java source passed a syntax-diagnostic check with `javac`; Android framework symbols were unavailable in this environment, so this was not a full Android compilation.
- No Android SDK / Gradle executable was available here, so no APK was built and no emulator/device visual test was performed.
- Open the project in Android Studio, let Gradle sync, build the `debug` variant, then test both `VIEW: SOLID 3D` and `VIEW: ASCII 3D`.
- If any GLSL compile error occurs, capture the `AshveilGL` logcat entries and send them with the screenshot.

## Security
The original archive contained a keystore and hardcoded signing credentials. The keystore is intentionally omitted from this patched archive. Debug builds use Android's standard debug signing. Configure a new private release key locally if you need signed release builds; do not commit it or its passwords.
