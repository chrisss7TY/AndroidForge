package app.lumen

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Base64
import android.webkit.MimeTypeMap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

@Immutable
data class VItem(val id: String, val name: String, val ext: String, val dur: Long, val h: Int, val size: Long)

/**
 * Password vault. Password -> PBKDF2-SHA256 (150k) -> AES-256 key.
 * Videos and thumbnails: AES-CTR with a random IV per file. Index (names etc.): AES-GCM.
 */
class Vault(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("vault", 0)
    private val dir = File(ctx.filesDir, "vault").apply { mkdirs() }
    private var key: SecretKeySpec? = null
    var items: List<VItem> = emptyList(); private set

    val exists: Boolean get() = sp.contains("salt")
    val unlocked: Boolean get() = key != null

    private fun derive(pw: CharArray, salt: ByteArray): SecretKeySpec {
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return SecretKeySpec(f.generateSecret(PBEKeySpec(pw, salt, 150_000, 256)).encoded, "AES")
    }

    private fun seal(k: SecretKeySpec, data: ByteArray): String {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, k, GCMParameterSpec(128, iv))
        return Base64.encodeToString(iv + c.doFinal(data), Base64.NO_WRAP)
    }

    private fun unseal(k: SecretKeySpec, s: String): ByteArray? = try {
        val all = Base64.decode(s, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, k, GCMParameterSpec(128, all, 0, 12))
        c.doFinal(all, 12, all.size - 12)
    } catch (e: Exception) {
        null
    }

    fun setup(pw: CharArray) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val k = derive(pw, salt)
        sp.edit().putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP)).putString("ver", seal(k, "lumen".toByteArray())).apply()
        key = k; items = emptyList(); save()
    }

    fun unlock(pw: CharArray): Boolean {
        val salt = Base64.decode(sp.getString("salt", "") ?: "", Base64.NO_WRAP)
        val k = derive(pw, salt)
        val v = unseal(k, sp.getString("ver", "") ?: "")
        return if (v != null && String(v) == "lumen") { key = k; load(); true } else false
    }

    fun lock() { key = null; items = emptyList() }

    private fun load() {
        val k = key ?: return
        val arr = sp.getString("idx", null)?.let { unseal(k, it) }?.let { JSONArray(String(it)) } ?: JSONArray()
        items = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            VItem(o.getString("id"), o.getString("name"), o.getString("ext"), o.getLong("dur"), o.getInt("h"), o.getLong("size"))
        }
    }

    private fun save() {
        val k = key ?: return
        val arr = JSONArray()
        items.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name).put("ext", it.ext).put("dur", it.dur).put("h", it.h).put("size", it.size)) }
        sp.edit().putString("idx", seal(k, arr.toString().toByteArray())).apply()
    }

    private fun ctr(mode: Int, iv: ByteArray): Cipher =
        Cipher.getInstance("AES/CTR/NoPadding").apply { init(mode, key!!, IvParameterSpec(iv)) }

    private fun encryptTo(src: InputStream, f: File) {
        val iv = ByteArray(16).also { SecureRandom().nextBytes(it) }
        f.outputStream().use { raw ->
            raw.write(iv)
            CipherOutputStream(raw, ctr(Cipher.ENCRYPT_MODE, iv)).use { src.copyTo(it, 256 * 1024) }
        }
    }

    private fun decryptTo(f: File, out: OutputStream) {
        f.inputStream().use { raw ->
            val iv = ByteArray(16)
            var n = 0
            while (n < 16) { val r = raw.read(iv, n, 16 - n); if (r < 0) break; n += r }
            CipherInputStream(raw, ctr(Cipher.DECRYPT_MODE, iv)).use { it.copyTo(out, 256 * 1024) }
        }
    }

    @Synchronized
    fun add(src: Uri, fileName: String) {
        val id = java.util.UUID.randomUUID().toString()
        val vf = File(dir, "$id.lvf"); val tf = File(dir, "$id.thm")
        try {
            (ctx.contentResolver.openInputStream(src) ?: error("cannot open")).use { encryptTo(it, vf) }
            frameOf(ctx, src, 960)?.let { b ->
                val bo = ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.JPEG, 88, bo)
                encryptTo(ByteArrayInputStream(bo.toByteArray()), tf)
            }
            val (dur, h) = probe(ctx, src)
            val ext = fileName.substringAfterLast('.', "mp4").lowercase().take(5)
            items = listOf(VItem(id, fileName.substringBeforeLast('.'), ext, dur, h, vf.length())) + items
            save()
        } catch (e: Exception) {
            vf.delete(); tf.delete(); throw e
        }
    }

    fun thumb(id: String): Bitmap? = try {
        val f = File(dir, "$id.thm")
        if (f.exists()) {
            val bo = ByteArrayOutputStream(); decryptTo(f, bo)
            val b = bo.toByteArray(); BitmapFactory.decodeByteArray(b, 0, b.size)
        } else null
    } catch (e: Exception) {
        null
    }

    /** Decrypts to cache for playback; the caller deletes it when the player closes. */
    fun playFile(v: VItem): File {
        val d = File(ctx.cacheDir, "play").apply { mkdirs() }
        val out = File(d, "${v.id}.${v.ext}")
        if (!out.exists() || out.length() == 0L) {
            try { out.outputStream().use { decryptTo(File(dir, "${v.id}.lvf"), it) } } catch (e: Exception) { out.delete(); throw e }
        }
        return out
    }

    fun export(v: VItem): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "${v.name}.${v.ext}")
            put(MediaStore.Video.Media.MIME_TYPE, MimeTypeMap.getSingleton().getMimeTypeFromExtension(v.ext) ?: "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Lumen")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val col = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val uri = ctx.contentResolver.insert(col, cv) ?: return false
        return try {
            (ctx.contentResolver.openOutputStream(uri) ?: error("no stream")).use { decryptTo(File(dir, "${v.id}.lvf"), it) }
            val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            ctx.contentResolver.update(uri, done, null, null)
            true
        } catch (e: Exception) {
            ctx.contentResolver.delete(uri, null, null); false
        }
    }

    @Synchronized
    fun remove(v: VItem) {
        File(dir, "${v.id}.lvf").delete(); File(dir, "${v.id}.thm").delete()
        items = items.filter { it.id != v.id }; save()
    }
}

@Composable
fun VaultScreen(vault: Vault, tick: Int, onChange: () -> Unit, onPlay: (VItem) -> Unit, onPicking: (Boolean) -> Unit, notify: (String) -> Unit) {
    if (!vault.unlocked) { VaultAuth(vault, onChange); return }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf<String?>(null) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        onPicking(false)
        if (uris.isNotEmpty()) scope.launch {
            var fails = 0
            uris.forEachIndexed { i, u ->
                busy = "Encrypting ${i + 1} of ${uris.size}…"
                val ok = withContext(Dispatchers.IO) { runCatching { vault.add(u, nameOf(ctx, u)) }.isSuccess }
                if (!ok) fails++
                onChange()
            }
            busy = null
            notify(if (fails == 0) "Added to vault" else "$fails file(s) couldn’t be added")
        }
    }
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button({ onPicking(true); pick.launch(arrayOf("video/*")) }) { Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(6.dp)); Text("Add videos") }
            OutlinedButton({ vault.lock(); onChange() }) { Icon(Icons.Rounded.Lock, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Lock") }
        }
        busy?.let {
            LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 12.dp))
            Text(it, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        }
        val list = vault.items
        if (list.isEmpty() && busy == null) {
            Text("Nothing here yet. Tap Add videos, or use ⋮ → Move to vault on a video in the Library.", Modifier.padding(top = 24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        LazyVerticalGrid(GridCells.Adaptive(160.dp), Modifier.padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(18.dp), contentPadding = PaddingValues(bottom = 120.dp)) {
            items(list, key = { it.id }) { v -> VaultCard(vault, v, { onPlay(v) }, onChange, notify) }
        }
    }
}

@Composable
private fun VaultAuth(vault: Vault, onDone: () -> Unit) {
    val exists = vault.exists
    var pw by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var working by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxWidth().padding(top = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Icon(Icons.Rounded.Lock, null, Modifier.size(40.dp), tint = MaterialTheme.colorScheme.primary)
        Text(if (exists) "Vault is locked" else "Create your vault", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(
            if (exists) "Enter your password to open it." else "Videos you add are encrypted with AES-256. If you forget this password they can’t be recovered.",
            fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        OutlinedTextField(pw, { pw = it }, Modifier.fillMaxWidth(), label = { Text("Password") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
        if (!exists) OutlinedTextField(pw2, { pw2 = it }, Modifier.fillMaxWidth(), label = { Text("Repeat password") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
        err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(
            onClick = {
                if (!exists && pw.length < 6) err = "Use at least 6 characters"
                else if (!exists && pw != pw2) err = "Passwords don’t match"
                else {
                    working = true; err = null
                    scope.launch {
                        val ok = withContext(Dispatchers.Default) { if (exists) vault.unlock(pw.toCharArray()) else { vault.setup(pw.toCharArray()); true } }
                        working = false
                        if (ok) onDone() else err = "Wrong password"
                    }
                }
            },
            enabled = !working && pw.isNotEmpty(), modifier = Modifier.fillMaxWidth()
        ) { Text(if (working) "Please wait…" else if (exists) "Unlock" else "Create vault") }
    }
}

@Composable
private fun VaultCard(vault: Vault, v: VItem, onPlay: () -> Unit, onChange: () -> Unit, notify: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val thumb by produceState<ImageBitmap?>(null, v.id) { value = withContext(Dispatchers.IO) { vault.thumb(v.id)?.asImageBitmap() } }
    var menu by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    Column {
        Box(Modifier.fillMaxWidth().aspectRatio(16 / 9f).clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface).clickable { onPlay() }) {
            thumb?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, filterQuality = FilterQuality.High) }
            Badges(v.h, v.dur)
        }
        Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(v.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Box {
                IconButton({ menu = true }, Modifier.size(28.dp)) { Icon(Icons.Rounded.MoreVert, null, Modifier.size(18.dp)) }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem({ Text("Restore to gallery") }, {
                        menu = false
                        scope.launch {
                            notify("Restoring…")
                            val ok = withContext(Dispatchers.IO) { vault.export(v) }
                            if (ok) { withContext(Dispatchers.IO) { vault.remove(v) }; onChange(); notify("Saved to Movies/Lumen") }
                            else notify("Couldn’t restore (needs Android 10+)")
                        }
                    })
                    DropdownMenuItem({ Text("Delete permanently") }, { menu = false; confirm = true })
                }
            }
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Delete “${v.name}”?") },
        text = { Text("This removes the encrypted copy for good.") },
        confirmButton = { TextButton({ confirm = false; scope.launch { withContext(Dispatchers.IO) { vault.remove(v) }; onChange() } }) { Text("Delete") } },
        dismissButton = { TextButton({ confirm = false }) { Text("Cancel") } }
    )
}
