package com.senje.asciirpg.ui

import android.opengl.GLES30
import com.senje.asciirpg.engine.ShaderProgram
import com.senje.asciirpg.entities.PlayerController
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

class TerminalHudRenderer(private val atlasTexId: Int) {

    private val hudShader = ShaderProgram(HUD_VERT, HUD_FRAG)
    private val uScreenSizeLoc = hudShader.getUniformLocation("uScreenSize")
    private val uAtlasLoc = hudShader.getUniformLocation("uAtlas")

    private val maxQuads = 1200
    private val vertexBuffer: FloatBuffer = ByteBuffer
        .allocateDirect(maxQuads * 6 * 8 * 4)
        .order(ByteOrder.nativeOrder())
        .asFloatBuffer()
    private var quadCount = 0

    private val vboIds = IntArray(1)

    init {
        GLES30.glGenBuffers(1, vboIds, 0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vboIds[0])
        GLES30.glBufferData(
            GLES30.GL_ARRAY_BUFFER,
            maxQuads * 6 * 8 * 4,
            null,
            GLES30.GL_DYNAMIC_DRAW
        )
    }

    fun render(
        screenW: Float,
        screenH: Float,
        player: PlayerController,
        zoomLabel: String,
        playerScreenX: Float,
        playerScreenY: Float,
        joyCenterX: Float,
        joyCenterY: Float,
        joyKnobX: Float,
        joyKnobY: Float,
        joyActive: Boolean,
        forgeOpen: Boolean
    ) {
        quadCount = 0
        vertexBuffer.clear()

        val scale = (screenH / 540f).coerceIn(1.0f, 3.0f)

        // Floating 'Senje' overhead tag just like in the screenshots
        if (playerScreenX in 40f..(screenW - 40f) && playerScreenY in 40f..(screenH - 40f)) {
            val tagSize = 11f * scale
            val tagW = player.name.length * tagSize * 0.56f
            drawText(
                player.name,
                playerScreenX - tagW * 0.5f,
                playerScreenY - 46f * scale,
                tagSize,
                0.95f,
                0.96f,
                0.92f
            )
        }

        // Top-Left Status Frame
        val boxX = 16f * scale
        val boxY = 16f * scale
        val boxW = 290f * scale
        val boxH = 82f * scale
        drawPanel(boxX, boxY, boxW, boxH)

        val charX = boxX + 12f * scale
        drawText(" O ", charX, boxY + 14f * scale, 11f * scale, 0.85f, 0.88f, 0.92f)
        drawText("/|\\", charX, boxY + 26f * scale, 11f * scale, 0.85f, 0.88f, 0.92f)
        drawText(" | ", charX, boxY + 38f * scale, 11f * scale, 0.85f, 0.88f, 0.92f)
        drawText("/ \\", charX, boxY + 50f * scale, 11f * scale, 0.85f, 0.88f, 0.92f)

        val infoX = boxX + 54f * scale
        drawText(player.name, infoX, boxY + 10f * scale, 14f * scale, 0.95f, 0.95f, 0.95f)

        val hpBars = ((player.hp.toFloat() / player.maxHp) * 14).toInt().coerceIn(0, 14)
        val hpStr = "HP " + "|".repeat(hpBars) + ".".repeat(14 - hpBars) + " ${player.hp}/${player.maxHp}"
        drawText(hpStr, infoX, boxY + 28f * scale, 11f * scale, 0.88f, 0.82f, 0.65f)

        val mpBars = ((player.mp.toFloat() / player.maxMp) * 14).toInt().coerceIn(0, 14)
        val mpStr = "MP " + "|".repeat(mpBars) + ".".repeat(14 - mpBars) + " ${player.mp}/${player.maxMp}"
        drawText(mpStr, infoX, boxY + 42f * scale, 11f * scale, 0.65f, 0.80f, 0.95f)

        val mountTag = if (player.isMounted) "*STEED*" else "*FOOT*"
        drawText(
            "LV ${player.level} - ${player.gold}g $mountTag",
            infoX,
            boxY + 58f * scale,
            11f * scale,
            0.85f,
            0.85f,
            0.85f
        )

        // Top-Right Tactical Buttons: [FORGE], [ZOOM], [STEED], [RAIN]
        val btnW = 92f * scale
        val btnH = 28f * scale
        val rightX = screenW - btnW - 16f * scale
        drawButton(rightX, 16f * scale, btnW, btnH, "[FORGE]", scale, forgeOpen)
        drawButton(rightX, 48f * scale, btnW, btnH, "[$zoomLabel]", scale, false)
        drawButton(rightX, 80f * scale, btnW, btnH, "[STEED]", scale, player.isMounted)
        drawButton(rightX, 112f * scale, btnW, btnH, "[RAIN]", scale, player.weatherRain)

        // Optional Equipment Forge Overlay
        if (forgeOpen) {
            val fx = screenW * 0.5f - 210f * scale
            val fy = 40f * scale
            val fw = 420f * scale
            val fh = 290f * scale
            drawPanel(fx, fy, fw, fh)
            drawText("Chainmail Coif  [Metal: ${player.equippedHelmMetal}]", fx + 14f * scale, fy + 12f * scale, 12f * scale, 0.95f, 0.9f, 0.75f)
            drawText("Runes: [ ^ ] [ * ] [ / ] [ + ]", fx + 14f * scale, fy + 30f * scale, 11f * scale, 0.7f, 0.9f, 0.8f)

            val coifLines = arrayOf(
                "      .o88888o.      ",
                "    .88855555888.    ",
                "   d8553335353358b   ",
                "   855555555333))8   ",
                "   85555885(5((((8   ",
                "   |535335553))))|   ",
                "  .d8585(58((((((b.  ",
                " .8855533))00((((88. ",
                "d88855885588(((((888b",
                "855533333))(((((55558"
            )
            for (i in coifLines.indices) {
                drawText(coifLines[i], fx + 65f * scale, fy + (56f + i * 16f) * scale, 13f * scale, 0.88f, 0.90f, 0.94f)
            }
            drawText("Tap [FORGE] again to close", fx + 14f * scale, fy + fh - 22f * scale, 10f * scale, 0.65f, 0.65f, 0.65f)
        }

        // Bottom Skill Hotbar (Slots 1..0 + XP Bar)
        val slotW = 36f * scale
        val slotH = 32f * scale
        val barW = slotW * 10f
        val barX = (screenW - barW) * 0.5f
        val barY = screenH - slotH - 12f * scale

        drawPanel(barX, barY - 14f * scale, barW, 12f * scale)
        val xpRatio = (player.xp.toFloat() / player.maxXp).coerceIn(0f, 1f)
        drawRect(barX + 2f, barY - 12f * scale, (barW - 4f) * xpRatio, 8f * scale, 0.78f, 0.64f, 0.25f, 0.85f)
        drawText("LV ${player.level} - ${player.xp} / ${player.maxXp} XP", barX + barW * 0.32f, barY - 13f * scale, 9f * scale, 1f, 1f, 1f)

        val skillIcons = arrayOf("/+\\", "(o)", "~*~", "[#]", "\\|/", "<*>", "{@}", "=+=", "(!)", "...")
        for (i in 0 until 10) {
            val sx = barX + i * slotW
            drawPanel(sx, barY, slotW - 2f, slotH)
            val label = if (i == 9) "0" else "${i + 1}"
            drawText(label, sx + slotW * 0.38f, barY + 2f * scale, 9f * scale, 0.75f, 0.75f, 0.75f)
            drawText(skillIcons[i], sx + 4f * scale, barY + 15f * scale, 10f * scale, 0.65f, 0.82f, 0.95f)
        }

        // Bottom-Right Combat Controls
        val atkSize = 78f * scale
        val atkX = screenW - atkSize - 22f * scale
        val atkY = screenH - atkSize - 24f * scale
        drawButton(atkX, atkY, atkSize, atkSize, "[ATK]", scale, player.attackTimer > 0f)

        val dodgeSize = 62f * scale
        val dodgeX = atkX - dodgeSize - 14f * scale
        val dodgeY = screenH - dodgeSize - 24f * scale
        drawButton(dodgeX, dodgeY, dodgeSize, dodgeSize, "[DODGE]", scale, player.dodgeTimer > 0f)

        // Bottom-Left Virtual Joystick
        val baseJx = if (joyActive) joyCenterX else 95f * scale
        val baseJy = if (joyActive) joyCenterY else screenH - 95f * scale
        val knobJx = if (joyActive) joyKnobX else baseJx
        val knobJy = if (joyActive) joyKnobY else baseJy
        drawPanel(baseJx - 42f * scale, baseJy - 42f * scale, 84f * scale, 84f * scale)
        drawButton(knobJx - 16f * scale, knobJy - 16f * scale, 32f * scale, 32f * scale, "+", scale, joyActive)

        flush(screenW, screenH)
    }

    private fun drawPanel(x: Float, y: Float, w: Float, h: Float) {
        drawRect(x, y, w, h, 0.04f, 0.05f, 0.06f, 0.82f)
        val b = 2f
        drawRect(x, y, w, b, 0.45f, 0.48f, 0.52f, 0.9f)
        drawRect(x, y + h - b, w, b, 0.45f, 0.48f, 0.52f, 0.9f)
        drawRect(x, y, b, h, 0.45f, 0.48f, 0.52f, 0.9f)
        drawRect(x + w - b, y, b, h, 0.45f, 0.48f, 0.52f, 0.9f)
    }

    private fun drawButton(x: Float, y: Float, w: Float, h: Float, label: String, scale: Float, active: Boolean) {
        if (active) {
            drawRect(x, y, w, h, 0.22f, 0.28f, 0.34f, 0.92f)
        } else {
            drawRect(x, y, w, h, 0.05f, 0.06f, 0.07f, 0.85f)
        }
        val b = 2f
        drawRect(x, y, w, b, 0.65f, 0.68f, 0.72f, 0.95f)
        drawRect(x, y + h - b, w, b, 0.65f, 0.68f, 0.72f, 0.95f)
        drawRect(x, y, b, h, 0.65f, 0.68f, 0.72f, 0.95f)
        drawRect(x + w - b, y, b, h, 0.65f, 0.68f, 0.72f, 0.95f)

        val fontSize = 11f * scale
        val textW = label.length * fontSize * 0.58f
        val tx = x + (w - textW) * 0.5f
        val ty = y + (h - fontSize) * 0.5f
        drawText(label, tx, ty, fontSize, 0.95f, 0.95f, 0.95f)
    }

    private fun drawRect(x: Float, y: Float, w: Float, h: Float, r: Float, g: Float, b: Float, a: Float) {
        pushQuad(x, y, w, h, -1f, -1f, -1f, -1f, r, g, b, a)
    }

    private fun drawText(text: String, startX: Float, y: Float, size: Float, r: Float, g: Float, b: Float) {
        val advance = size * 0.58f
        val cellU = 1f / 32f
        val cellV = 1f / 16f
        for (i in text.indices) {
            val code = text[i].code
            if (code in 33..126) {
                val idx = code - 32
                val col = idx % 32
                val row = 2 + (idx / 32)
                val u0 = col * cellU
                val v0 = row * cellV
                pushQuad(startX + i * advance, y, size * 0.85f, size, u0, v0, u0 + cellU, v0 + cellV, r, g, b, 1f)
            }
        }
    }

    private fun pushQuad(
        x: Float, y: Float, w: Float, h: Float,
        u0: Float, v0: Float, u1: Float, v1: Float,
        r: Float, g: Float, b: Float, a: Float
    ) {
        if (quadCount >= maxQuads) return
        val x1 = x + w
        val y1 = y + h

        putVert(x, y, u0, v0, r, g, b, a)
        putVert(x, y1, u0, v1, r, g, b, a)
        putVert(x1, y1, u1, v1, r, g, b, a)

        putVert(x, y, u0, v0, r, g, b, a)
        putVert(x1, y1, u1, v1, r, g, b, a)
        putVert(x1, y, u1, v0, r, g, b, a)
        quadCount++
    }

    private fun putVert(x: Float, y: Float, u: Float, v: Float, r: Float, g: Float, b: Float, a: Float) {
        vertexBuffer.put(x)
        vertexBuffer.put(y)
        vertexBuffer.put(u)
        vertexBuffer.put(v)
        vertexBuffer.put(r)
        vertexBuffer.put(g)
        vertexBuffer.put(b)
        vertexBuffer.put(a)
    }

    private fun flush(screenW: Float, screenH: Float) {
        if (quadCount == 0) return
        vertexBuffer.position(0)

        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)

        hudShader.use()
        GLES30.glUniform2f(uScreenSizeLoc, screenW, screenH)

        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, atlasTexId)
        GLES30.glUniform1i(uAtlasLoc, 0)

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vboIds[0])
        GLES30.glBufferSubData(GLES30.GL_ARRAY_BUFFER, 0, quadCount * 6 * 8 * 4, vertexBuffer)

        val stride = 8 * 4
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, stride, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, stride, 2 * 4)
        GLES30.glEnableVertexAttribArray(2)
        GLES30.glVertexAttribPointer(2, 4, GLES30.GL_FLOAT, false, stride, 4 * 4)

        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, quadCount * 6)

        GLES30.glDisableVertexAttribArray(0)
        GLES30.glDisableVertexAttribArray(1)
        GLES30.glDisableVertexAttribArray(2)
        GLES30.glDisable(GLES30.GL_BLEND)
    }

    companion object {
        private const val HUD_VERT = """#version 300 es
            layout(location = 0) in vec2 aPos;
            layout(location = 1) in vec2 aUv;
            layout(location = 2) in vec4 aColor;
            uniform vec2 uScreenSize;
            out vec2 vUv;
            out vec4 vColor;
            void main() {
                vec2 ndc = (aPos / uScreenSize) * 2.0 - 1.0;
                gl_Position = vec4(ndc.x, -ndc.y, 0.0, 1.0);
                vUv = aUv;
                vColor = aColor;
            }
        """

        private const val HUD_FRAG = """#version 300 es
            precision mediump float;
            in vec2 vUv;
            in vec4 vColor;
            uniform sampler2D uAtlas;
            out vec4 fragColor;
            void main() {
                if (vUv.x < 0.0) {
                    fragColor = vColor;
                } else {
                    float alpha = texture(uAtlas, vUv).r;
                    if (alpha < 0.15) discard;
                    fragColor = vec4(vColor.rgb, vColor.a * alpha);
                }
            }
        """
    }
}
