package com.senje.asciirpg.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.opengl.GLES30
import android.opengl.GLUtils

object AsciiGlyphAtlas {

    // Exact dark-fantasy character palette seen in screenshots:
    // sparse dots/colons in shadow -> dashes/slashes/parens -> dense Q, 0, 8, B, W, M, #, @
    const val LUMINANCE_RAMP = " .,:;~-=/\\+*o0Q8BWM#@"
    const val EDGE_GLYPHS = "|-/\\()"

    fun createAtlasTexture(): Int {
        val cols = 32
        val rows = 16
        val cellSize = 28
        val bmp = Bitmap.createBitmap(cols * cellSize, rows * cellSize, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.BLACK)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 23f
            typeface = Typeface.MONOSPACE
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val fm = paint.fontMetrics
        val baseline = -(fm.ascent + fm.descent) * 0.5f

        // Row 0: 21-step Luminance Ramp (cols 0..20)
        for (i in LUMINANCE_RAMP.indices) {
            val cx = i * cellSize + cellSize * 0.5f
            val cy = cellSize * 0.5f + baseline
            canvas.drawText(LUMINANCE_RAMP[i].toString(), cx, cy, paint)
        }

        // Row 1: Directional Sobel Edge Glyphs (cols 0..5)
        for (i in EDGE_GLYPHS.indices) {
            val cx = i * cellSize + cellSize * 0.5f
            val cy = cellSize * 1.5f + baseline
            canvas.drawText(EDGE_GLYPHS[i].toString(), cx, cy, paint)
        }

        // Rows 2..5: Printable ASCII (32..126) for crisp HUD text & floating 'Senje' label
        for (ascii in 32..126) {
            val idx = ascii - 32
            val col = idx % 32
            val row = 2 + (idx / 32)
            val cx = col * cellSize + cellSize * 0.5f
            val cy = row * cellSize + cellSize * 0.5f + baseline
            canvas.drawText(ascii.toChar().toString(), cx, cy, paint)
        }

        val texIds = IntArray(1)
        GLES30.glGenTextures(1, texIds, 0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, texIds[0])
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0)
        bmp.recycle()

        return texIds[0]
    }
}
