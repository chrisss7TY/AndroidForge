package com.senje.asciirpg.engine

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Builds smooth sculpted 3D meshes (capsules, ellipsoids, tapered armor plates, equine neck/muzzle)
 * so the ASCII + Sobel shader resolves curved contours like (, ), /, \, o, 8, Q, # instead of cubes.
 */
object MeshBuilder {

    data class MeshRange(val offset: Int, val count: Int)

    class Builder {
        private val data = ArrayList<Float>(16384)
        var vertexCount = 0
            private set

        fun currentVertexOffset(): Int = vertexCount

        /**
         * Adds a smooth tapered capsule/limb along Y from y0 to y1 with radii (rx0, rz0) at bottom
         * and (rx1, rz1) at top, with rounded hemisphere caps.
         */
        fun addSculptedLimb(
            y0: Float, y1: Float,
            rx0: Float, rz0: Float,
            rx1: Float, rz1: Float,
            rings: Int = 8,
            sectors: Int = 14
        ) {
            val totalRings = rings + 4 // 2 bottom cap + body + 2 top cap
            val ringY = FloatArray(totalRings + 1)
            val ringRx = FloatArray(totalRings + 1)
            val ringRz = FloatArray(totalRings + 1)

            val capH0 = (rx0 + rz0) * 0.35f
            val capH1 = (rx1 + rz1) * 0.35f

            // Bottom cap
            ringY[0] = y0 - capH0; ringRx[0] = 0.001f; ringRz[0] = 0.001f
            ringY[1] = y0 - capH0 * 0.55f; ringRx[1] = rx0 * 0.72f; ringRz[1] = rz0 * 0.72f

            // Tapered body rings
            for (r in 0..rings) {
                val t = r.toFloat() / rings
                // Slight organic muscle bulge in middle
                val bulge = 1.0f + sin(t * 3.14159f) * 0.08f
                ringY[2 + r] = y0 + (y1 - y0) * t
                ringRx[2 + r] = (rx0 + (rx1 - rx0) * t) * bulge
                ringRz[2 + r] = (rz0 + (rz1 - rz0) * t) * bulge
            }

            // Top cap
            ringY[totalRings - 1] = y1 + capH1 * 0.55f; ringRx[totalRings - 1] = rx1 * 0.72f; ringRz[totalRings - 1] = rz1 * 0.72f
            ringY[totalRings] = y1 + capH1; ringRx[totalRings] = 0.001f; ringRz[totalRings] = 0.001f

            for (r in 0 until totalRings) {
                val ya = ringY[r]; val rxa = ringRx[r]; val rza = ringRz[r]
                val yb = ringY[r + 1]; val rxb = ringRx[r + 1]; val rzb = ringRz[r + 1]

                for (s in 0 until sectors) {
                    val a0 = (s.toFloat() / sectors) * 6.2831853f
                    val a1 = ((s + 1).toFloat() / sectors) * 6.2831853f
                    val c0 = cos(a0); val s0 = sin(a0)
                    val c1 = cos(a1); val s1 = sin(a1)

                    val x00 = c0 * rxa; val z00 = s0 * rza
                    val x10 = c1 * rxa; val z10 = s1 * rza
                    val x01 = c0 * rxb; val z01 = s0 * rzb
                    val x11 = c1 * rxb; val z11 = s1 * rzb

                    putTri(x00, ya, z00, x10, ya, z10, x11, yb, z11)
                    putTri(x00, ya, z00, x11, yb, z11, x01, yb, z01)
                }
            }
        }

        fun addEllipsoid(cx: Float, cy: Float, cz: Float, rx: Float, ry: Float, rz: Float, stacks: Int = 8, sectors: Int = 14) {
            for (i in 0 until stacks) {
                val phi0 = (i.toFloat() / stacks - 0.5f) * 3.1415926f
                val phi1 = ((i + 1).toFloat() / stacks - 0.5f) * 3.1415926f
                val y0 = cy + sin(phi0) * ry
                val y1 = cy + sin(phi1) * ry
                val r0 = cos(phi0)
                val r1 = cos(phi1)

                for (j in 0 until sectors) {
                    val th0 = (j.toFloat() / sectors) * 6.2831853f
                    val th1 = ((j + 1).toFloat() / sectors) * 6.2831853f

                    val x00 = cx + cos(th0) * r0 * rx; val z00 = cz + sin(th0) * r0 * rz
                    val x10 = cx + cos(th1) * r0 * rx; val z10 = cz + sin(th1) * r0 * rz
                    val x01 = cx + cos(th0) * r1 * rx; val z01 = cz + sin(th0) * r1 * rz
                    val x11 = cx + cos(th1) * r1 * rx; val z11 = cz + sin(th1) * r1 * rz

                    putTri(x00, y0, z00, x10, y0, z10, x11, y1, z11)
                    putTri(x00, y0, z00, x11, y1, z11, x01, y1, z01)
                }
            }
        }

        private fun putTri(
            x0: Float, y0: Float, z0: Float,
            x1: Float, y1: Float, z1: Float,
            x2: Float, y2: Float, z2: Float
        ) {
            val ux = x1 - x0; val uy = y1 - y0; val uz = z1 - z0
            val vx = x2 - x0; val vy = y2 - y0; val vz = z2 - z0
            var nx = uy * vz - uz * vy
            var ny = uz * vx - ux * vz
            var nz = ux * vy - uy * vx
            val len = sqrt(nx * nx + ny * ny + nz * nz).coerceAtLeast(0.0001f)
            nx /= len; ny /= len; nz /= len

            putVert(x0, y0, z0, nx, ny, nz)
            putVert(x1, y1, z1, nx, ny, nz)
            putVert(x2, y2, z2, nx, ny, nz)
        }

        private fun putVert(x: Float, y: Float, z: Float, nx: Float, ny: Float, nz: Float) {
            data.add(x); data.add(y); data.add(z)
            data.add(nx); data.add(ny); data.add(nz)
            data.add(1f); data.add(1f); data.add(1f)
            vertexCount++
        }

        fun buildBuffer(): FloatBuffer {
            val buf = ByteBuffer.allocateDirect(data.size * 4)
                .order(ByteOrder.nativeOrder())
                .asFloatBuffer()
            for (v in data) buf.put(v)
            buf.position(0)
            return buf
        }
    }
}
