package com.senje.asciirpg.world

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Generates high-density dark-fantasy terrain matching the screenshots:
 * - 18,000+ fine swaying grass blades + white/lavender wildflowers + crimson autumn specks
 * - Cobblestone patches & winding stone trails ('Q', '8', '0', 'B' glyphs)
 * - Reflective dark water river with circular glowing arcane water rune
 * - Cracked stone monolith ruins & warm campfire hearth
 */
class WorldGenerator(val seed: Int) {

    companion object {
        const val GRID_SIZE = 84
        const val TILE_SCALE = 0.55f
        const val GRASS_INSTANCE_COUNT = 18000
        const val PILLAR_COUNT = 16
    }

    val terrainVertexBuffer: FloatBuffer
    val terrainVertexCount: Int

    val grassInstanceBuffer: FloatBuffer
    val pillarData = FloatArray(PILLAR_COUNT * 4) // x, z, radius, height

    val campfireX = -2.2f
    val campfireZ = -1.8f

    init {
        val rng = Random(seed)

        val half = GRID_SIZE * 0.5f
        val quads = GRID_SIZE * GRID_SIZE
        terrainVertexCount = quads * 6
        terrainVertexBuffer = ByteBuffer.allocateDirect(terrainVertexCount * 10 * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()

        for (gz in 0 until GRID_SIZE) {
            for (gx in 0 until GRID_SIZE) {
                val x0 = (gx - half) * TILE_SCALE
                val z0 = (gz - half) * TILE_SCALE
                val x1 = x0 + TILE_SCALE
                val z1 = z0 + TILE_SCALE

                putTerrainVertex(x0, z0)
                putTerrainVertex(x0, z1)
                putTerrainVertex(x1, z1)

                putTerrainVertex(x0, z0)
                putTerrainVertex(x1, z1)
                putTerrainVertex(x1, z0)
            }
        }
        terrainVertexBuffer.position(0)

        // Generate weathered stone monolith ruins around the meadow & river
        for (i in 0 until PILLAR_COUNT) {
            val angle = (i.toFloat() / PILLAR_COUNT) * 6.28318f + rng.nextFloat() * 0.3f
            val dist = 6.2f + rng.nextFloat() * 12.5f
            pillarData[i * 4] = cos(angle) * dist
            pillarData[i * 4 + 1] = sin(angle) * dist
            pillarData[i * 4 + 2] = 0.52f + rng.nextFloat() * 0.42f
            pillarData[i * 4 + 3] = 2.4f + rng.nextFloat() * 2.8f
        }

        // Populate 18,000 GPU-instanced grass blades, wildflowers, and autumn leaf specks
        // Layout: x, y, z, scale, phase, variant (0=grass, 1=white flower, 2=crimson autumn speck)
        grassInstanceBuffer = ByteBuffer.allocateDirect(GRASS_INSTANCE_COUNT * 6 * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()

        var placed = 0
        var attempts = 0
        val worldRadius = half * TILE_SCALE * 0.94f
        while (placed < GRASS_INSTANCE_COUNT && attempts < GRASS_INSTANCE_COUNT * 3) {
            attempts++
            val wx = (rng.nextFloat() * 2f - 1f) * worldRadius
            val wz = (rng.nextFloat() * 2f - 1f) * worldRadius
            val surface = getSurfaceType(wx, wz)
            if (surface < 0.35f) {
                val wy = getTerrainHeight(wx, wz)
                val scale = 0.70f + rng.nextFloat() * 0.85f
                val phase = rng.nextFloat() * 6.28318f
                val roll = rng.nextFloat()
                val variant = when {
                    roll < 0.055f -> 1.0f // White/silver wildflower ('o * o')
                    roll < 0.085f -> 2.0f // Crimson/amber autumn speck
                    else -> 0.0f          // Lush dark-emerald grass blade
                }
                grassInstanceBuffer.put(wx)
                grassInstanceBuffer.put(wy)
                grassInstanceBuffer.put(wz)
                grassInstanceBuffer.put(scale)
                grassInstanceBuffer.put(phase)
                grassInstanceBuffer.put(variant)
                placed++
            }
        }
        grassInstanceBuffer.position(0)
    }

    fun getTerrainHeight(x: Float, z: Float): Float {
        val riverDist = getRiverSignedDistance(x, z)
        if (riverDist < 0f) {
            return -0.26f
        }
        val n1 = sin(x * 0.20f + seed * 0.01f) * cos(z * 0.18f) * 0.32f
        val n2 = sin((x + z) * 0.42f) * 0.10f
        val bankBlend = (riverDist / 1.6f).coerceIn(0f, 1f)
        return (n1 + n2) * bankBlend
    }

    /**
     * 0.0 = Deep Dark Fantasy Meadow
     * 1.0 = Cobblestone Patches & Trail ('Q 8 0 B' glyphs)
     * 2.0 = Reflective Dark River Water + Arcane Rune Circle
     */
    fun getSurfaceType(x: Float, z: Float): Float {
        val riverDist = getRiverSignedDistance(x, z)
        if (riverDist < 0.0f) return 2.0f

        val roadCenter = sin(z * 0.17f) * 3.0f
        val roadDist = kotlin.math.abs(x - roadCenter)
        val cobblePatch = sin(x * 0.55f) * cos(z * 0.55f)
        if (roadDist < 1.25f || cobblePatch > 0.72f) return 1.0f

        return 0.0f
    }

    private fun getRiverSignedDistance(x: Float, z: Float): Float {
        val riverZ = -8.2f + sin(x * 0.15f) * 2.2f
        return kotlin.math.abs(z - riverZ) - 2.4f
    }

    private fun putTerrainVertex(x: Float, z: Float) {
        val y = getTerrainHeight(x, z)
        val surface = getSurfaceType(x, z)

        val eps = 0.15f
        val hL = getTerrainHeight(x - eps, z)
        val hR = getTerrainHeight(x + eps, z)
        val hD = getTerrainHeight(x, z - eps)
        val hU = getTerrainHeight(x, z + eps)
        var nx = hL - hR
        var ny = 2f * eps
        var nz = hD - hU
        val len = sqrt(nx * nx + ny * ny + nz * nz).coerceAtLeast(0.001f)
        nx /= len; ny /= len; nz /= len

        val r: Float
        val g: Float
        val b: Float
        when {
            surface > 1.5f -> {
                r = 0.05f; g = 0.08f; b = 0.11f
            }
            surface > 0.5f -> {
                // High-contrast cobblestone blocks so ASCII shader outputs Q, 8, 0, B, #
                val cobble = 0.34f + 0.22f * sin(x * 5.2f) * cos(z * 5.2f)
                r = cobble * 0.96f; g = cobble * 1.0f; b = cobble * 1.06f
            }
            else -> {
                // Rich dark forest soil base under dense blades
                r = 0.03f; g = 0.09f; b = 0.04f
            }
        }

        terrainVertexBuffer.put(x)
        terrainVertexBuffer.put(y)
        terrainVertexBuffer.put(z)
        terrainVertexBuffer.put(nx)
        terrainVertexBuffer.put(ny)
        terrainVertexBuffer.put(nz)
        terrainVertexBuffer.put(r)
        terrainVertexBuffer.put(g)
        terrainVertexBuffer.put(b)
        terrainVertexBuffer.put(surface)
    }
}
