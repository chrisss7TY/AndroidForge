package com.senje.asciirpg.entities

import com.senje.asciirpg.data.SaveManager
import com.senje.asciirpg.world.WorldGenerator
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Articulated Knight & White Warhorse controller:
 * - Smooth 4-beat equine gallop cycle (forelegs & hindlegs phase-offset + knee flexion)
 * - Multi-strand Verlet hair physics: 10 mane strands along the arched neck + 8 tail plume strands
 * - Dismounted warrior stride, cloak physics, dodge dash, and greatsword slash
 */
class PlayerController(initial: SaveManager.PlayerSaveData) {

    companion object {
        const val MANE_STRANDS = 10
        const val MANE_NODES = 5
        const val TAIL_STRANDS = 8
        const val TAIL_NODES = 7
    }

    var name: String = initial.name
    var level: Int = initial.level
    var xp: Int = initial.xp
    var maxXp: Int = initial.maxXp
    var hp: Int = initial.hp
    var maxHp: Int = initial.maxHp
    var mp: Int = initial.mp
    var maxMp: Int = initial.maxMp
    var gold: Int = initial.gold
    var equippedHelmMetal: String = initial.equippedHelmMetal

    var posX: Float = initial.posX
    var posY: Float = 0f
    var posZ: Float = initial.posZ
    var facingAngle: Float = 1.57f // Start facing profile/three-quarter so horse silhouette shines
    var isMounted: Boolean = initial.isMounted
    var weatherRain: Boolean = initial.weatherRain

    var moveInputX: Float = 0f
    var moveInputZ: Float = 0f

    var animTime: Float = 0f
    var attackTimer: Float = 0f
    var dodgeTimer: Float = 0f
    var currentSpeed: Float = 0f

    // Multi-strand Verlet hair simulation arrays
    val maneX = Array(MANE_STRANDS) { FloatArray(MANE_NODES) { posX } }
    val maneY = Array(MANE_STRANDS) { FloatArray(MANE_NODES) { 1.2f } }
    val maneZ = Array(MANE_STRANDS) { FloatArray(MANE_NODES) { posZ } }

    val tailX = Array(TAIL_STRANDS) { FloatArray(TAIL_NODES) { posX } }
    val tailY = Array(TAIL_STRANDS) { FloatArray(TAIL_NODES) { 0.9f } }
    val tailZ = Array(TAIL_STRANDS) { FloatArray(TAIL_NODES) { posZ } }

    fun triggerAttack() {
        if (attackTimer <= 0f) {
            attackTimer = 0.42f
            mp = (mp - 6).coerceAtLeast(0)
        }
    }

    fun triggerDodge() {
        if (dodgeTimer <= 0f) {
            dodgeTimer = 0.34f
        }
    }

    fun toggleSteed() {
        isMounted = !isMounted
    }

    fun toggleWeather() {
        weatherRain = !weatherRain
    }

    fun update(dt: Float, world: WorldGenerator) {
        animTime += dt
        if (attackTimer > 0f) attackTimer = (attackTimer - dt).coerceAtLeast(0f)
        if (dodgeTimer > 0f) dodgeTimer = (dodgeTimer - dt).coerceAtLeast(0f)

        if (mp < maxMp && (animTime * 10f).toInt() % 8 == 0) {
            mp = (mp + 1).coerceAtMost(maxMp)
        }

        val inputLen = sqrt(moveInputX * moveInputX + moveInputZ * moveInputZ)
        val baseSpeed = if (isMounted) 5.8f else 3.6f
        val dashBoost = if (dodgeTimer > 0f) 2.25f else 1.0f

        if (inputLen > 0.05f || dodgeTimer > 0f) {
            val dirX: Float
            val dirZ: Float
            if (inputLen > 0.05f) {
                dirX = moveInputX / inputLen
                dirZ = moveInputZ / inputLen
                val targetAngle = atan2(dirX, dirZ)
                facingAngle = lerpAngle(facingAngle, targetAngle, (12f * dt).coerceIn(0f, 1f))
            } else {
                dirX = sin(facingAngle)
                dirZ = cos(facingAngle)
            }

            currentSpeed = baseSpeed * dashBoost * (if (inputLen > 0.05f) inputLen.coerceAtMost(1f) else 1f)
            posX = (posX + dirX * currentSpeed * dt).coerceIn(-20f, 20f)
            posZ = (posZ + dirZ * currentSpeed * dt).coerceIn(-20f, 20f)
        } else {
            currentSpeed = 0f
        }

        posY = world.getTerrainHeight(posX, posZ)

        val fwdX = sin(facingAngle)
        val fwdZ = cos(facingAngle)
        val rightX = cos(facingAngle)
        val rightZ = -sin(facingAngle)
        val backX = -fwdX
        val backZ = -fwdZ

        val gallopBob = if (currentSpeed > 0.1f) sin(animTime * 12f) * 0.09f else sin(animTime * 2.2f) * 0.02f
        val windX = cos(animTime * 1.7f) * 0.25f
        val windZ = sin(animTime * 1.3f) * 0.25f

        // 1. Update 10-strand Flowing Equine Mane along the arched neck crest
        for (s in 0 until MANE_STRANDS) {
            val tNeck = s.toFloat() / (MANE_STRANDS - 1) // 0 = withers, 1 = poll/ears
            val neckFwd = 0.28f + tNeck * 0.38f
            val neckUp = posY + 0.96f + tNeck * 0.46f + gallopBob
            val sideSpread = (if (s % 2 == 0) 1f else -1f) * 0.07f

            maneX[s][0] = posX + fwdX * neckFwd + rightX * sideSpread
            maneY[s][0] = neckUp
            maneZ[s][0] = posZ + fwdZ * neckFwd + rightZ * sideSpread

            val segLen = 0.11f
            for (n in 1 until MANE_NODES) {
                val flutter = sin(animTime * 7.5f + s * 0.9f + n * 1.1f) * 0.035f
                val tx = maneX[s][n - 1] + backX * segLen * 0.85f + rightX * (sideSpread * 1.3f + flutter) + windX * 0.05f
                val ty = maneY[s][n - 1] - segLen * 0.55f + sin(animTime * 11f + n) * 0.015f
                val tz = maneZ[s][n - 1] + backZ * segLen * 0.85f + rightZ * (sideSpread * 1.3f + flutter) + windZ * 0.05f

                val k = (16f * dt).coerceIn(0.2f, 0.85f)
                maneX[s][n] += (tx - maneX[s][n]) * k
                maneY[s][n] += (ty - maneY[s][n]) * k
                maneZ[s][n] += (tz - maneZ[s][n]) * k
            }
        }

        // 2. Update 8-strand Lush Tail Plume (or Knight Cloak when dismounted)
        val anchorFwd = if (isMounted) -0.58f else -0.18f
        val anchorUp = if (isMounted) posY + 0.92f + gallopBob else posY + 0.88f + gallopBob

        for (s in 0 until TAIL_STRANDS) {
            val fanAngle = ((s.toFloat() / (TAIL_STRANDS - 1)) - 0.5f) * 0.75f
            val spreadSide = sin(fanAngle) * 0.14f
            val spreadUp = cos(fanAngle) * 0.08f

            tailX[s][0] = posX + fwdX * anchorFwd + rightX * spreadSide
            tailY[s][0] = anchorUp + spreadUp
            tailZ[s][0] = posZ + fwdZ * anchorFwd + rightZ * spreadSide

            val segLen = if (isMounted) 0.13f else 0.11f
            for (n in 1 until TAIL_NODES) {
                val wave = sin(animTime * 6.5f + s * 0.7f + n * 0.8f) * 0.045f
                val flare = 1.0f + n * 0.14f
                val tx = tailX[s][n - 1] + backX * segLen + rightX * (spreadSide * flare + wave) + windX * 0.07f
                val ty = (tailY[s][n - 1] - segLen * (0.58f - spreadUp * 1.5f) + sin(animTime * 10f + n) * 0.02f)
                    .coerceAtLeast(posY + 0.14f)
                val tz = tailZ[s][n - 1] + backZ * segLen + rightZ * (spreadSide * flare + wave) + windZ * 0.07f

                val k = (15f * dt).coerceIn(0.2f, 0.85f)
                tailX[s][n] += (tx - tailX[s][n]) * k
                tailY[s][n] += (ty - tailY[s][n]) * k
                tailZ[s][n] += (tz - tailZ[s][n]) * k
            }
        }
    }

    private fun lerpAngle(a: Float, b: Float, t: Float): Float {
        var diff = (b - a) % 6.2831853f
        if (diff > 3.1415926f) diff -= 6.2831853f
        if (diff < -3.1415926f) diff += 6.2831853f
        return a + diff * t
    }
}
