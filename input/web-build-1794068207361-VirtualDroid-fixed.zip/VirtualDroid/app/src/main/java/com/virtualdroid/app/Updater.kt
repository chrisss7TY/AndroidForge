package com.virtualdroid.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class UpdateInfo(val versionName: String, val apkUrl: String, val notes: String)

/**
 * Checks the latest GitHub Release of BuildConfig.UPDATE_REPO. If its tag (e.g. "v1.0.7")
 * is newer than the installed versionName, downloads the .apk asset and hands it to the
 * system installer. Android shows its normal "Update?" prompt; user data is kept because
 * the APK is signed with the same key.
 */
object Updater {

    /** Returns the newer release, or null when up to date or the check fails (offline, rate limit, bad repo). */
    suspend fun check(): UpdateInfo? = withContext(Dispatchers.IO) {
        try {
            val url = URL("https://api.github.com/repos/${BuildConfig.UPDATE_REPO}/releases/latest")
            val conn = url.openConnection() as HttpURLConnection
            try {
                conn.setRequestProperty("Accept", "application/vnd.github+json")
                conn.connectTimeout = 10_000
                conn.readTimeout = 10_000
                if (conn.responseCode != 200) return@withContext null
                val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                val tag = json.getString("tag_name").removePrefix("v")
                val assets = json.getJSONArray("assets")
                var apk: String? = null
                for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (a.getString("name").endsWith(".apk")) {
                        apk = a.getString("browser_download_url")
                        break
                    }
                }
                if (apk != null && isNewer(tag, BuildConfig.VERSION_NAME)) {
                    UpdateInfo(tag, apk, json.optString("body"))
                } else null
            } finally {
                conn.disconnect()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }

    /** Downloads the APK and opens the system installer. Returns an error message, or null on success. */
    suspend fun downloadAndInstall(context: Context, info: UpdateInfo): String? = withContext(Dispatchers.IO) {
        if (!context.packageManager.canRequestPackageInstalls()) {
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return@withContext "Allow \"Install unknown apps\" for VirtualDroid, then tap Update again."
        }

        val dir = File(context.cacheDir, "updates").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() } // drop older downloads
        val out = File(dir, "VirtualDroid-${info.versionName}.apk")

        try {
            val conn = URL(info.apkUrl).openConnection() as HttpURLConnection
            try {
                conn.instanceFollowRedirects = true
                conn.connectTimeout = 15_000
                conn.readTimeout = 30_000
                if (conn.responseCode != 200) return@withContext "Download failed (HTTP ${conn.responseCode})"
                conn.inputStream.use { input -> out.outputStream().use { input.copyTo(it) } }
            } finally {
                conn.disconnect()
            }
        } catch (e: CancellationException) {
            out.delete()
            throw e
        } catch (e: Exception) {
            out.delete()
            return@withContext e.message ?: "Download failed"
        }

        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", out)
        context.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        null
    }

    internal fun isNewer(remote: String, local: String): Boolean {
        val r = remote.split(".").map { it.toIntOrNull() ?: 0 }
        val l = local.split(".").map { it.toIntOrNull() ?: 0 }
        for (i in 0 until maxOf(r.size, l.size)) {
            val a = r.getOrElse(i) { 0 }
            val b = l.getOrElse(i) { 0 }
            if (a != b) return a > b
        }
        return false
    }
}
