package com.virtualdroid.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {

    /** An .apk the user opened with "Open with VirtualDroid"; consumed by the UI. */
    private val pendingApk = mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Engines.init(this)
        // Only on a fresh start: after rotation the same intent would otherwise be imported again.
        if (savedInstanceState == null) pendingApk.value = apkFrom(intent)
        setContent { VirtualDroidTheme { Home(pendingApk) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        apkFrom(intent)?.let { pendingApk.value = it }
    }

    private fun apkFrom(intent: Intent?): Uri? =
        intent?.takeIf { it.action == Intent.ACTION_VIEW }?.data
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Home(pendingApk: MutableState<Uri?>) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val engine = Engines.current
    val versions = AndroidVersion.values()

    var versionIndex by rememberSaveable { mutableIntStateOf(versions.lastIndex) }
    val version = versions[versionIndex]
    val preview = remember(version) { VirtualProfile.preset(version) }

    var apps by remember { mutableStateOf<List<VirtualApp>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var importing by remember { mutableStateOf(false) }
    var update by remember { mutableStateOf<UpdateInfo?>(null) }
    var updating by remember { mutableStateOf(false) }
    var toRemove by remember { mutableStateOf<VirtualApp?>(null) }

    val scrollBehavior = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()

    suspend fun reload() {
        apps = withContext(Dispatchers.IO) { engine.list() }
    }

    suspend fun importApk(uri: Uri) {
        importing = true
        val chosen = version
        val result = withContext(Dispatchers.IO) {
            val tmp = File(context.cacheDir, "import.apk")
            try {
                tmp.delete() // never reuse a stale file if the copy below fails
                val input = context.contentResolver.openInputStream(uri)
                    ?: return@withContext Result.failure<VirtualApp>(IllegalStateException("Can't open that file"))
                input.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                engine.install(tmp, VirtualProfile.preset(chosen))
            } catch (e: Exception) {
                Result.failure<VirtualApp>(e)
            } finally {
                tmp.delete()
            }
        }
        importing = false
        result.onSuccess {
            reload()
            snackbar.showSnackbar("Added ${it.label} to ${chosen.label}")
        }.onFailure {
            snackbar.showSnackbar(it.message ?: "Import failed")
        }
    }

    LaunchedEffect(Unit) {
        reload()
        loading = false
        update = Updater.check()
    }

    LaunchedEffect(pendingApk.value) {
        val uri = pendingApk.value ?: return@LaunchedEffect
        pendingApk.value = null
        importApk(uri)
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { importApk(uri) }
    }

    Scaffold(
        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = { LargeTopAppBar(title = { Text("VirtualDroid") }, scrollBehavior = scrollBehavior) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    if (!importing) {
                        // Some file managers report APKs as octet-stream, so allow both.
                        picker.launch(arrayOf("application/vnd.android.package-archive", "application/octet-stream"))
                    }
                },
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("Add APK") },
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        LazyColumn(
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = padding.calculateTopPadding() + 8.dp,
                bottom = padding.calculateBottomPadding() + 96.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            update?.let { u ->
                item(key = "update") {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    ) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Update ${u.versionName} available", style = MaterialTheme.typography.titleMedium)
                            if (updating) LinearProgressIndicator(Modifier.fillMaxWidth())
                            Button(
                                enabled = !updating,
                                onClick = {
                                    scope.launch {
                                        updating = true
                                        val error = Updater.downloadAndInstall(context, u)
                                        updating = false
                                        if (error != null) snackbar.showSnackbar(error)
                                    }
                                },
                            ) { Text(if (updating) "Downloading…" else "Update now") }
                        }
                    }
                }
            }

            if (!engine.isReady) {
                item(key = "engine") {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.onErrorContainer)
                            Text(
                                "No sandbox engine connected yet. You can add APKs, but they can't run.",
                                modifier = Modifier.padding(start = 12.dp),
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                    }
                }
            }

            item(key = "device") {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Virtual device", style = MaterialTheme.typography.titleMedium)
                        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                            versions.forEachIndexed { index, v ->
                                SegmentedButton(
                                    selected = index == versionIndex,
                                    onClick = { versionIndex = index },
                                    shape = SegmentedButtonDefaults.itemShape(index, versions.size),
                                ) { Text(v.label.removePrefix("Android ")) }
                            }
                        }
                        Text(
                            "Apps see ${preview.manufacturer} ${preview.model} on Android ${version.release} " +
                                "(API ${version.sdkInt}), with random device IDs for each added app.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            item(key = "header") {
                Text("Apps", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
            }

            if (loading || importing) {
                item(key = "loading") {
                    Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
            } else if (apps.isEmpty()) {
                item(key = "empty") {
                    Text(
                        "Nothing here yet. Tap Add APK to import one.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 16.dp),
                    )
                }
            }

            items(apps, key = { it.profile.id + it.packageName }) { app ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(44.dp)) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    app.label.take(1).uppercase(),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                )
                            }
                        }
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(app.label, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                "${app.profile.androidVersion.label} · v${app.versionName}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        IconButton(onClick = {
                            scope.launch {
                                engine.launch(app).onFailure { snackbar.showSnackbar(it.message ?: "Can't open ${app.label}") }
                            }
                        }) { Icon(Icons.Filled.PlayArrow, contentDescription = "Open ${app.label}") }
                        IconButton(onClick = { toRemove = app }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Remove ${app.label}")
                        }
                    }
                }
            }
        }
    }

    toRemove?.let { app ->
        AlertDialog(
            onDismissRequest = { toRemove = null },
            title = { Text("Remove ${app.label}?") },
            text = { Text("Its imported copy and sandbox data will be deleted. Your real phone isn't affected.") },
            confirmButton = {
                TextButton(onClick = {
                    toRemove = null
                    scope.launch {
                        withContext(Dispatchers.IO) { engine.uninstall(app) }
                        reload()
                    }
                }) { Text("Remove") }
            },
            dismissButton = { TextButton(onClick = { toRemove = null }) { Text("Cancel") } },
        )
    }
}
