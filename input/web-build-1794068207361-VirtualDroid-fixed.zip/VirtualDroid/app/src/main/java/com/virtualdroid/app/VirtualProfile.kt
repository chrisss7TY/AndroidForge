package com.virtualdroid.app

import java.util.UUID

/**
 * The identity a sandboxed app sees instead of the real phone.
 * Each virtual instance gets its own randomly generated IDs so apps cannot
 * link the sandbox to the real device or to each other.
 */
data class VirtualProfile(
    val id: String = UUID.randomUUID().toString(),
    val androidVersion: AndroidVersion,
    val manufacturer: String,
    val brand: String,
    val model: String,
    val device: String,
    val fingerprint: String,
    val androidId: String = randomHex(16),
    val serial: String = randomHex(10).uppercase(),
) {
    companion object {
        fun randomHex(len: Int): String {
            val chars = "0123456789abcdef"
            return buildString { repeat(len) { append(chars.random()) } }
        }

        /** Built-in presets. Fingerprints are plausible stock-style strings for each release. */
        fun preset(version: AndroidVersion): VirtualProfile = when (version) {
            AndroidVersion.A10 -> VirtualProfile(
                androidVersion = version, manufacturer = "Google", brand = "google",
                model = "Pixel 3", device = "blueline",
                fingerprint = "google/blueline/blueline:10/QQ3A.200805.001/6578210:user/release-keys",
            )
            AndroidVersion.A11 -> VirtualProfile(
                androidVersion = version, manufacturer = "Google", brand = "google",
                model = "Pixel 4a", device = "sunfish",
                fingerprint = "google/sunfish/sunfish:11/RQ3A.210805.001.A1/7474174:user/release-keys",
            )
            AndroidVersion.A12 -> VirtualProfile(
                androidVersion = version, manufacturer = "Google", brand = "google",
                model = "Pixel 5", device = "redfin",
                fingerprint = "google/redfin/redfin:12/SQ1A.220105.002/7961164:user/release-keys",
            )
        }
    }
}

enum class AndroidVersion(val label: String, val release: String, val sdkInt: Int) {
    A10("Android 10", "10", 29),
    A11("Android 11", "11", 30),
    A12("Android 12", "12", 31),
}
