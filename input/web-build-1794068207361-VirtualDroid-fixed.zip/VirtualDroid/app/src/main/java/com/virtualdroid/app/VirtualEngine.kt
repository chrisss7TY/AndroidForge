package com.virtualdroid.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class VirtualApp(
    val packageName: String,
    val label: String,
    val versionName: String,
    val profile: VirtualProfile,
    val apkPath: String,
)

/**
 * The seam between the app UI and the virtualization engine.
 *
 * A real engine (VirtualApp-style) runs the guest APK in a separate process,
 * hooks Binder/PackageManager/Build so the guest sees [VirtualProfile] instead of the
 * real phone, and redirects the guest's data directory into private storage.
 * Plug one in by implementing this interface and swapping it in [Engines.current].
 */
interface VirtualEngine {
    val isReady: Boolean
    fun install(apk: File, profile: VirtualProfile): Result<VirtualApp>
    fun list(): List<VirtualApp>
    fun launch(app: VirtualApp): Result<Unit>
    fun uninstall(app: VirtualApp)
}

object Engines {
    lateinit var current: VirtualEngine
    fun init(context: Context) {
        if (!::current.isInitialized) current = StubEngine(context.applicationContext)
    }
}

/**
 * Placeholder engine: imports APKs into the app's private storage and tracks them with
 * their chosen profile, but cannot execute them yet (launch() reports that).
 * Replace with a real sandbox engine to actually run the guest apps.
 */
class StubEngine(private val context: Context) : VirtualEngine {
    private val root = File(context.filesDir, "virtual").apply { mkdirs() }
    private val index = File(root, "index.json")

    override val isReady = false

    override fun install(apk: File, profile: VirtualProfile): Result<VirtualApp> = runCatching {
        val pm = context.packageManager
        val info = pm.getPackageArchiveInfo(apk.absolutePath, 0)
            ?: error("That file isn't a valid APK")
        val appInfo = info.applicationInfo ?: error("That APK has no application info")
        appInfo.sourceDir = apk.absolutePath
        appInfo.publicSourceDir = apk.absolutePath
        val label = appInfo.loadLabel(pm).toString().ifBlank { info.packageName }
        val dest = File(root, "${profile.id}/${info.packageName}.apk")
        dest.parentFile?.mkdirs()
        apk.copyTo(dest, overwrite = true)
        val app = VirtualApp(info.packageName, label, info.versionName ?: "?", profile, dest.absolutePath)
        save(list() + app)
        app
    }

    override fun list(): List<VirtualApp> = runCatching {
        if (!index.exists()) return emptyList()
        val arr = JSONArray(index.readText())
        (0 until arr.length()).map { arr.getJSONObject(it).toApp() }
    }.getOrDefault(emptyList())

    override fun launch(app: VirtualApp): Result<Unit> =
        Result.failure(IllegalStateException(
            "No virtualization engine is connected yet. ${app.label} is imported but can't run."))

    override fun uninstall(app: VirtualApp) {
        val apk = File(app.apkPath)
        apk.delete()
        apk.parentFile?.takeIf { it.listFiles().isNullOrEmpty() }?.delete()
        save(list().filterNot { it.packageName == app.packageName && it.profile.id == app.profile.id })
    }

    private fun save(apps: List<VirtualApp>) {
        index.writeText(JSONArray(apps.map { it.toJson() }).toString())
    }

    private fun VirtualApp.toJson() = JSONObject()
        .put("pkg", packageName).put("label", label).put("ver", versionName).put("apk", apkPath)
        .put("pid", profile.id).put("av", profile.androidVersion.name)
        .put("mf", profile.manufacturer).put("br", profile.brand).put("md", profile.model)
        .put("dv", profile.device).put("fp", profile.fingerprint)
        .put("aid", profile.androidId).put("ser", profile.serial)

    private fun JSONObject.toApp() = VirtualApp(
        getString("pkg"), getString("label"), getString("ver"),
        VirtualProfile(
            id = getString("pid"), androidVersion = AndroidVersion.valueOf(getString("av")),
            manufacturer = getString("mf"), brand = getString("br"), model = getString("md"),
            device = getString("dv"), fingerprint = getString("fp"),
            androidId = getString("aid"), serial = getString("ser"),
        ),
        getString("apk"),
    )
}
