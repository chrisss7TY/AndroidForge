# VirtualDroid

Kotlin / Jetpack Compose app that imports APKs into a private sandbox, each tied to a virtual
device profile (Android 10, 11 or 12; Pixel model, build fingerprint, and random Android ID/serial per
sandbox) so guest apps see that identity instead of your real phone.

## Honest status

| Part | State |
|---|---|
| UI, version picker, profile presets, APK import/list/remove | Written |
| In-app updater (GitHub Releases) + CI that builds signed APKs | Written |
| **Sandbox engine that actually runs guest apps** | **Not included.** `StubEngine` imports APKs but `launch()` reports no engine. |

Nothing here has been compiled or run yet (my environment had no Android SDK or network).
Expect to fix small build errors on first build.

### About the engine
Running another APK "as Android 12 on a different phone" means hooking Binder/PackageManager/Build
inside a separate guest process (the VirtualApp technique). That is a large native + Java project
that is fragile across Android versions. Implement `VirtualEngine` (see `VirtualEngine.kt`) using an
open-source VirtualApp-style library you are licensed to use, then set `Engines.current` to it.
Note this is a compatibility sandbox: it does not install a real Android 10/11/12 system. The guest
still runs on your phone's real OS, with the version/device values spoofed. Apps that use hardware
attestation (e.g. banking or Play Integrity checks) will still see the real device.

## Build the first APK
1. Install Android Studio, open this folder, let it sync, press Run (or `gradle :app:assembleDebug`).
2. In `gradle.properties` set `updateRepo=<your github user>/VirtualDroid`.

## Ship updates as APKs
1. Create a keystore once and keep it forever (changing it breaks updates):
   `keytool -genkeypair -v -keystore release.jks -alias virtualdroid -keyalg RSA -keysize 2048 -validity 10000`
2. Push the project to GitHub and add these repository secrets:
   `KEYSTORE_BASE64` (`base64 -w0 release.jks`), `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
3. Each release: `git tag v1.0.1 && git push --tags`. CI builds `VirtualDroid-v1.0.1.apk` and publishes it.
4. Installed apps check the latest release on launch and show an **Update** button; Android's
   installer then updates in place and keeps your data (same signing key).
