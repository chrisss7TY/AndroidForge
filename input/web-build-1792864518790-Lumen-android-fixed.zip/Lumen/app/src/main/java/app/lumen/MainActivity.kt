package app.lumen

import android.Manifest
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import dev.jdtech.mpv.MPVLib
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.ln
import kotlin.math.roundToInt

data class Vid(val uri: Uri, val name: String, val dur: Long, val h: Int)

private val RATES = listOf(1f, 1.25f, 1.5f, 2f, .5f, .75f)
private val THUMBS = LruCache<Uri, ImageBitmap>(48)
private fun fmt(s: Double) = "%d:%02d".format((s / 60).toInt(), (s % 60).toInt())

class MainActivity : ComponentActivity() {
    private var opened by mutableStateOf<Uri?>(null)
    private var live = false
    private val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE

    override fun onCreate(b: Bundle?) { super.onCreate(b); opened = intent?.data; setContent { App() } }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); i.data?.let { opened = it } }
    override fun onStop() { super.onStop(); if (live) MPVLib.setPropertyBoolean("pause", true) }

    private suspend fun scan(): List<Vid> = withContext(Dispatchers.IO) {
        val out = ArrayList<Vid>(); val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        contentResolver.query(base, arrayOf("_id", "_display_name", "duration", "height"), null, null, "date_added DESC")?.use {
            while (it.moveToNext()) out += Vid(ContentUris.withAppendedId(base, it.getLong(0)), it.getString(1).substringBeforeLast('.'), it.getLong(2), it.getInt(3))
        }; out
    }

    @Composable fun App() {
        val sp = remember { getSharedPreferences("s", 0) }
        var theme by remember { mutableStateOf(sp.getString("theme", "dark")!!) }
        var skip by remember { mutableIntStateOf(sp.getInt("skip", 10)) }
        var hw by remember { mutableStateOf(sp.getBoolean("hw", true)) }
        var tab by remember { mutableIntStateOf(0) }
        var list by remember { mutableStateOf(listOf<Vid>()) }
        val scope = rememberCoroutineScope()
        val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) scope.launch { list = scan() } }
        LaunchedEffect(Unit) { if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) list = scan() else ask.launch(perm) }
        val amoled = theme == "amoled"
        val cs = if (theme != "light") darkColorScheme(primary = Color(0xFF8FD9C9), background = if (amoled) Color.Black else Color(0xFF0A0F11), surface = if (amoled) Color(0xFF0B0B0C) else Color(0xFF121A1D))
                 else lightColorScheme(primary = Color(0xFF17695B), background = Color(0xFFF3F7F6))
        MaterialTheme(cs) {
            Box(Modifier.fillMaxSize().background(cs.background)) {
                Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 18.dp)) {
                    Text(if (tab == 0) "Library" else "Settings", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 24.dp, bottom = 12.dp))
                    if (tab == 0) Library(list) { opened = it } else Settings(theme, skip, hw,
                        { theme = it; sp.edit().putString("theme", it).apply() },
                        { skip = it; sp.edit().putInt("skip", it).apply() },
                        { hw = it; sp.edit().putBoolean("hw", it).apply() })
                }
                GlassNav(tab, listOf(Icons.Rounded.VideoLibrary to "Library", Icons.Rounded.Tune to "Settings"), { tab = it }, Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 14.dp))
                opened?.let { Player(it, skip, hw) { opened = null } }
            }
        }
    }

    @Composable fun Library(list: List<Vid>, onOpen: (Uri) -> Unit) {
        val ctx = LocalContext.current
        LazyVerticalGrid(GridCells.Adaptive(160.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(18.dp), contentPadding = PaddingValues(bottom = 120.dp)) {
            items(list, key = { it.uri }) { v ->
                val thumb by produceState(THUMBS.get(v.uri), v.uri) {
                    if (value == null) value = withContext(Dispatchers.IO) { runCatching { ctx.contentResolver.loadThumbnail(v.uri, Size(480, 270), null).asImageBitmap() }.getOrNull() }?.also { THUMBS.put(v.uri, it) }
                }
                Column(Modifier.clickable { onOpen(v.uri) }) {
                    Box(Modifier.fillMaxWidth().aspectRatio(16 / 9f).clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface)) {
                        thumb?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                        Text(if (v.h >= 2000) "4K" else "${v.h}p", Modifier.align(Alignment.BottomStart).padding(8.dp).clip(RoundedCornerShape(7.dp)).background(if (v.h >= 2000) Color(0xFFFFC66B) else Color(0x88000000)).padding(horizontal = 7.dp, vertical = 3.dp), fontSize = 11.sp, color = if (v.h >= 2000) Color(0xFF2B1B00) else Color.White, fontWeight = FontWeight.SemiBold)
                        Text(fmt(v.dur / 1000.0), Modifier.align(Alignment.BottomEnd).padding(10.dp), fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
                    }
                    Text(v.name, Modifier.padding(top = 8.dp), maxLines = 1, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                }
            }
        }
    }

    @Composable fun Settings(theme: String, skip: Int, hw: Boolean, setTheme: (String) -> Unit, setSkip: (Int) -> Unit, setHw: (Boolean) -> Unit) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Theme", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("dark" to "Dark", "amoled" to "AMOLED", "light" to "Light").forEach { (k, n) -> FilterChip(theme == k, { setTheme(k) }, { Text(n) }) } }
            Text("Skip interval", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(5, 10, 15, 30).forEach { FilterChip(skip == it, { setSkip(it) }, { Text("${it}s") }) } }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("Hardware decoding first", fontWeight = FontWeight.SemiBold); Text("Falls back to software for 4K the phone can't decode", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                Switch(hw, setHw)
            }
        }
    }

    @Composable fun Player(uri: Uri, skip: Int, hw: Boolean, onClose: () -> Unit) {
        val ctx = LocalContext.current; val sp = remember { ctx.getSharedPreferences("s", 0) }
        var pos by remember { mutableDoubleStateOf(0.0) }; var dur by remember { mutableDoubleStateOf(1.0) }
        var paused by remember { mutableStateOf(false) }; var ui by remember { mutableStateOf(true) }
        var zoom by remember { mutableFloatStateOf(1f) }; var px by remember { mutableFloatStateOf(0f) }; var py by remember { mutableFloatStateOf(0f) }
        var w by remember { mutableIntStateOf(1) }; var speed by remember { mutableFloatStateOf(1f) }; var drag by remember { mutableStateOf<Float?>(null) }
        val posNow by rememberUpdatedState(pos); val durNow by rememberUpdatedState(dur)
        DisposableEffect(Unit) {
            live = true; window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            val bars = WindowInsetsControllerCompat(window, window.decorView)
            bars.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE; bars.hide(WindowInsetsCompat.Type.systemBars())
            MPVLib.create(ctx)
            mapOf("profile" to "fast", "vo" to "gpu", "gpu-context" to "android", "opengl-es" to "yes",
                "hwdec" to (if (hw) "mediacodec,mediacodec-copy" else "no"), "hwdec-codecs" to "all",
                "vd-lavc-threads" to Runtime.getRuntime().availableProcessors().toString(), "vd-lavc-skiploopfilter" to "nonref", "vd-lavc-fast" to "yes", "vd-lavc-dr" to "yes",
                "framedrop" to "vo", "video-sync" to "audio", "cache" to "yes", "demuxer-max-bytes" to "64MiB", "demuxer-readahead-secs" to "20",
                "ao" to "audiotrack,opensles", "force-window" to "yes", "keep-open" to "yes").forEach { (k, v) -> MPVLib.setOptionString(k, v) }
            val last = sp.getFloat("p:$uri", 0f); if (last > 5f) MPVLib.setOptionString("start", last.toString())
            MPVLib.init()
            val fd = ctx.contentResolver.openFileDescriptor(uri, "r")?.detachFd()
            MPVLib.command(arrayOf("loadfile", if (fd != null) "fd://$fd" else uri.toString()))
            onDispose {
                sp.edit().apply { if (posNow > 5 && posNow < durNow - 10) putFloat("p:$uri", posNow.toFloat()) else remove("p:$uri") }.apply()
                live = false; window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); bars.show(WindowInsetsCompat.Type.systemBars())
                MPVLib.command(arrayOf("stop")); MPVLib.detachSurface(); MPVLib.destroy()
            }
        }
        // Only poll while the controls are visible: no recomposition during plain playback
        LaunchedEffect(ui) { while (ui) { if (drag == null) pos = MPVLib.getPropertyDouble("time-pos") ?: pos; dur = MPVLib.getPropertyDouble("duration") ?: dur; paused = MPVLib.getPropertyBoolean("pause") ?: false; delay(250) } }
        LaunchedEffect(ui, paused) { if (ui && !paused) { delay(3000); ui = false } }
        fun seek(s: Int) = MPVLib.command(arrayOf("seek", s.toString(), "relative"))
        fun applyZoom() { MPVLib.setPropertyDouble("video-zoom", ln(zoom.toDouble()) / ln(2.0)); MPVLib.setPropertyDouble("video-pan-x", (px / w).toDouble()); MPVLib.setPropertyDouble("video-pan-y", (py / w).toDouble()) }
        BackHandler(onBack = onClose)
        Box(Modifier.fillMaxSize().background(Color.Black).onSizeChanged { w = it.width.coerceAtLeast(1) }
            .pointerInput(Unit) { detectTransformGestures { _, pan, z, _ ->
                val nz = (zoom * z).coerceIn(1f, 6f)
                if (nz > 1f) { px += pan.x; py += pan.y } else { px = 0f; py = 0f }
                if (nz != zoom || nz > 1f) { zoom = nz; applyZoom() } } }
            .pointerInput(skip) { detectTapGestures(onDoubleTap = { seek(if (it.x < size.width / 2) -skip else skip) }, onTap = { ui = !ui }) }) {
            AndroidView({ c -> SurfaceView(c).apply { holder.addCallback(object : SurfaceHolder.Callback {
                override fun surfaceCreated(h: SurfaceHolder) { MPVLib.attachSurface(h.surface) }
                override fun surfaceChanged(h: SurfaceHolder, f: Int, a: Int, b: Int) { MPVLib.setPropertyString("android-surface-size", "${a}x$b") }
                override fun surfaceDestroyed(h: SurfaceHolder) { MPVLib.detachSurface() } }) } }, Modifier.fillMaxSize())
            if (ui) Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x99000000), Color.Transparent, Color(0xB3000000)))).statusBarsPadding().navigationBarsPadding().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
                IconButton(onClose) { Icon(Icons.Rounded.ArrowBackIosNew, null, tint = Color.White) }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ seek(-skip) }) { Icon(Icons.Rounded.Replay10, null, tint = Color.White, modifier = Modifier.size(36.dp)) }
                    Spacer(Modifier.width(24.dp))
                    FilledIconButton({ MPVLib.setPropertyBoolean("pause", !paused); paused = !paused }, Modifier.size(76.dp), colors = IconButtonDefaults.filledIconButtonColors(Color.White, Color.Black)) { Icon(if (paused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause, null, Modifier.size(40.dp)) }
                    Spacer(Modifier.width(24.dp))
                    IconButton({ seek(skip) }) { Icon(Icons.Rounded.Forward10, null, tint = Color.White, modifier = Modifier.size(36.dp)) }
                }
                Column {
                    // Scrub on keyframes (instant), land exactly on release
                    Slider(drag ?: (pos / dur).toFloat().coerceIn(0f, 1f), { drag = it; MPVLib.command(arrayOf("seek", (it * dur).toString(), "absolute+keyframes")) },
                        onValueChangeFinished = { drag?.let { MPVLib.command(arrayOf("seek", (it * dur).toString(), "absolute+exact")) }; drag = null })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${fmt(pos)} / ${fmt(dur)}", color = Color.White, fontSize = 12.sp); Spacer(Modifier.weight(1f))
                        TextButton({ speed = RATES[(RATES.indexOf(speed) + 1) % RATES.size]; MPVLib.setPropertyDouble("speed", speed.toDouble()) }) { Text("${speed}×", color = Color.White) }
                    }
                }
            }
        }
    }
}

/** Glass tab bar: hold and drag the lens. Critically damped springs, so no bounce. */
@Composable fun GlassNav(sel: Int, tabs: List<Pair<ImageVector, String>>, onSel: (Int) -> Unit, m: Modifier) {
    val itemW = 96.dp; val iw = with(LocalDensity.current) { itemW.toPx() }
    val x = remember { Animatable(sel * iw) }; val sx = remember { Animatable(1f) }; val sy = remember { Animatable(1f) }
    val scope = rememberCoroutineScope()
    var held by remember { mutableStateOf(false) }; var hot by remember { mutableIntStateOf(sel) }
    val spPos = spring<Float>(dampingRatio = 1f, stiffness = 120f); val spScale = spring<Float>(dampingRatio = 0.9f, stiffness = 260f)
    LaunchedEffect(sel, held) { if (!held) x.animateTo(sel * iw, spPos) }
    Box(m.clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.surface.copy(alpha = .72f)).border(1.dp, Color.White.copy(.12f), RoundedCornerShape(50)).padding(6.dp)
        .pointerInput(tabs.size) { awaitEachGesture {
            val down = awaitFirstDown(); held = true; var last = -1f
            fun go(px: Float) { val t = (px - iw / 2).coerceIn(0f, iw * (tabs.size - 1)); hot = (t / iw).roundToInt(); if (kotlin.math.abs(t - last) > 1f) { last = t; scope.launch { x.animateTo(t, spPos) } } }
            scope.launch { sx.animateTo(1.08f, spScale) }; scope.launch { sy.animateTo(1.12f, spScale) }; go(down.position.x)
            do { val e = awaitPointerEvent(); e.changes.firstOrNull()?.let { c -> go(c.position.x); c.consume() } } while (e.changes.any { it.pressed })
            held = false; val t = hot; scope.launch { sx.animateTo(1f, spScale) }; scope.launch { sy.animateTo(1f, spScale) }; onSel(t)
        } }) {
        Box(Modifier.offset { IntOffset(x.value.roundToInt(), 0) }.size(itemW, 52.dp).graphicsLayer { scaleX = sx.value; scaleY = sy.value }
            .clip(RoundedCornerShape(50)).background(Color.White.copy(if (held) .26f else .16f)))
        Row { tabs.forEachIndexed { i, (ic, n) -> Column(Modifier.size(itemW, 52.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Icon(ic, n, Modifier.size(22.dp).graphicsLayer { val s = if (held && hot == i) 1.12f else 1f; scaleX = s; scaleY = s }, tint = if (i == (if (held) hot else sel)) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant)
            Text(n, fontSize = 10.sp, fontWeight = FontWeight.SemiBold) } } }
    }
}
